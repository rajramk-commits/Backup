package com.fedex.emea.sd.da.exceptions;

public class PrAuditsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5952334728341897683L;

	/**
	 * Method 'PrAuditsDaoException'
	 * 
	 * @param message
	 */
	public PrAuditsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrAuditsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrAuditsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
