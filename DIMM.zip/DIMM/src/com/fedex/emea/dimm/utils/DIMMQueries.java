package com.fedex.emea.dimm.utils;

public class DIMMQueries {
	
	public static final String OPEN_CASES_FROM_ANTC_QUERYSTRING = "SELECT distinct casesysid FROM dimminterface  WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is not null and logicalkey in(?)";
	
	//public static final String OPENALERTLOGICALKEYIF9 = "SELECT distinct logicalkey FROM  external_interface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid in null and alertprocessed=9 and logicalkey in(?)";
	
	//public static final String CASESTATUS_FROM_NEXUS_QUERYSTRING = "SELECT case_id, rc_status, TO_CHAR(row_added_dttm , 'DD-Mon-YYYY HH:MI:SS PM') createdtime FROM SYSADM.ps_rc_case WHERE casestatus IN ('RESOL', 'CLOS', 'OOS', 'DUP') and case_id IN ()";
		
	//public static final String UPDATE_CASESTATUS_TO_ANTC_QUERYSTRING = "UPDATE EXTERNAL_INTERFACE SET casestatus = 'RESOL' WHERE casesysid = ?";

	public static final String UPDATE_CASESTATUS_TO_DIMM_QUERYSTRING = "UPDATE dimminterface SET casestatus='RESOL' WHERE casesysid = ?";
	
	public static final String PHYSICALALERTS_WITHOUTSNOWCASE_QUERYSTRING = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime FROM dimminterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is null and logicalkey is null";
	
	public static final String PHYSICALALERTS_WITHOUTSNOWCASE_QUERYSTRINGANDWITHLOGICALKEY = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime FROM dimminterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is null and logicalkey is not null";
	public static final String update2foraddnote ="update DIMMinterface set alertprocessed=2 where alertid in (select alertid from dimminterface where casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed =0 and logicalkey in(select logicalkey from dimminterface where casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed =1))";
	
	public static final String PHYSICALALERTSFORNEWCASECREATION = "SELECT alertid,logicalkey,recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime  FROM dimminterface WHERE alertid IN ( SELECT MIN(alertid) FROM dimminterface WHERE  casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and logicalkey is not null and caseid is null and alertprocessed =0 GROUP BY logicalkey)";
	public static final String PHYSICALALERTSWHICHCASENEEDTOBEUPDATED = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime FROM dimminterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is null and alertprocessed=1";
	public static final String UPDATE_LOGICALKEY_TO_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET logicalkey = ?, casestatus = ? WHERE alertid = ?";
	
	public static final String PHYSICALALERTSFORADDNOTE = "SELECT alertid,logicalkey,recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime  FROM dimminterface WHERE  casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is null and alertprocessed =2";
	//changed for to implement 9
	public static final String INSERT_LOGICALALERT_QUERYSTRING = "INSERT into external_interface (alertid,recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9,creationtime) VALUES (SEQ_ALERTID.NEXTVAL ,?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?,current_date)";
	public static final String UPDATEALERTPROCESSEDTODIMMINTERFACE="update dimminterface set alertprocessed=1 where alertid=?";
	//public static final String INSERT_LOGICALALERT_QUERYSTRING = "MERGE INTO EXTERNAL_INTERFACE a USING (select count(*) recordcount from EXTERNAL_INTERFACE where logicalkey = ? and recordsource = ? and (casestatus not in ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed !='9')) b ON (b.recordcount > 0) WHEN NOT MATCHED THEN INSERT (alertid,recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9,creationtime) VALUES (SEQ_ALERTID.NEXTVAL ,?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?,sysdate)";
	//changed for to implement 9
	public static final String GET_CASENUM_FROM_ANTC_QUERYSTRING = "SELECT logicalkey, caseid FROM EXTERNAL_INTERFACE WHERE alertid in ( SELECT MAX(alertid) FROM EXTERNAL_INTERFACE WHERE alertprocessed=1 and logicalkey IN ()";
	public static final String GET_CASENUM_FROM_ANTC_QUERYSTRINGFORADDNOTE = "SELECT logicalkey, caseid FROM dimminterface WHERE alertid in ( SELECT MAX(alertid) FROM dimminterface WHERE alertprocessed=1 and casestatus='WORK'and logicalkey IN ()";
	
	//public static final String GET_CASENUM_FROM_ANTC_QUERYSTRING = "SELECT distinct logicalkey, caseid FROM EXTERNAL_INTERFACE WHERE (casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed !='9') AND logicalkey IN ()";
	//changed for to implement 9
	public static final String GET_CASESYSID_FROM_ANTC_QUERYSTRING = "SELECT distinct logicalkey, casesysid FROM EXTERNAL_INTERFACE WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey IN ()";
	//public static final String GET_CASESYSID_FROM_ANTC_QUERYSTRING = "SELECT distinct logicalkey, casesysid FROM EXTERNAL_INTERFACE WHERE (casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed !='9') AND logicalkey IN ()";
	public static final String INSERT_ALERT_FOR_ADDNOTE_QUERYSTRING = "INSERT INTO EXTERNAL_INTERFACE (alertid, recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, caseid,creationtime) VALUES (SEQ_ALERTID.NEXTVAL,'ADD-NOTE', ?, 'Similar Alert received', ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,current_date)";
	
	public static final String UPDATE_CASENUM_FOR_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET caseid = ? WHERE alertid = ?";
	
	public static final String UPDATE_CASESYSID_FOR_PHYSICALALERT_QUERYSTRING = "update dimminterface set casesysid = (select distinct casesysid from external_interface where caseid = ?) where caseid = ? and casesysid is null";
	public static final String UPDATE_CASESYSID_FOR_PHYSICALALERT_QUERYSTRING2 = "update external_interface set casesysid = (select distinct casesysid from external_interface where caseid = ? and casesysid is not null) where caseid = ? and casesysid is null";
	
	
	
	
	public static final String NEXUSCASE_FROM_OVO_QUERYSTRING = "SELECT distinct caseid FROM EXTERNAL_INTERFACE WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid = (SELECT nexuscaseid FROM (SELECT * FROM ovomessages WHERE ovonode = ? ORDER BY creationtime DESC) ovomessagesdesc WHERE ROWNUM = 1)";
	
	//These queries are used if ANTC is down
	public static final String GET_TIMESTAMP_FROM_ANTC_QUERYSTRING = "SELECT logicalkey, creationtime FROM EXTERNAL_INTERFACE WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey IN ()";

	public static final String UPDATECASESTATUSLOGICALKEYIFALERTPROCESSED="update dimminterface set casestatus='RESOL' where casestatus='WORK' and caseid is null  and alertprocessed in (1,2) and logicalkey in (select logicalkey from external_interface where alertprocessed=9 and recordsourceid=? and processedtime <= (select TO_CHAR(current_date - 10/(24*60),'DD-MON-YY HH:MI:SS') from DUAL))";
	
	
	
/*
 * //public static final String PHYSICALALERTS_WITHOUTNEXUSCASE_QUERYSTRING = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9 FROM dimminterface WHERE caseid is null and casedescription1 not like '%Component[ServerResponseDetection]%' and casedescription1 not like '%Component[FILE_SYSTEM]%' and casedescription1 not like '%Component[ServerRebootDetection]%' and casedescription1 not like '%Component[ServerReachableDetection]%'";
	//public static final String PHYSICALALERTS_WITHOUTNEXUSCASE_QUERYSTRING = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime FROM dimminterface WHERE casestatus NOT IN ('RESOL', 'CLOS') and caseid is null and logicalkey != 'NOLOGICALKEY' or logicalkey is null";
	public static final String PHYSICALALERTS_WITHOUTNEXUSCASE_QUERYSTRING = "SELECT alertid, logicalkey, recordsource, recordsourceid, casesummary, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, creationtime FROM dimminterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is null";
	public static final String INSERT_LOGICALALERT_QUERYSTRING = "MERGE INTO nexusinterface a USING (select count(*) recordcount from nexusinterface where logicalkey = ? and recordsource = ? and casestatus not in ('RESOL', 'CLOS', 'OOS', 'DUP')) b ON (b.recordcount > 0) WHEN NOT MATCHED THEN INSERT (recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	//public static final String MERGE_LOGICALALERT_QUERYSTRING = "MERGE INTO nexusinterface a USING (select count(*) recordcount from nexusinterface where logicalkey = ? and casestatus not in ('RESOL', 'CLOS')) b ON (b.recordcount > 0) WHEN MATCHED THEN UPDATE set recordsource = 'ADD-NOTE', recordsourceid = ?, casesummary = ?, casedescription1 = ?, casedescription2 = ?, casedescription3 = ?, casedescription4 = ?, casedescription5 = ?, casedescription6 = ?, casedescription7 = ?, casedescription8 = ?, casedescription9 = ? where logicalkey = ? and casestatus not in ('RESOL', 'CLOS') WHEN NOT MATCHED THEN INSERT (recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9) VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String INSERT_ALERT_FOR_ADDNOTE_QUERYSTRING = "INSERT INTO nexusinterface (recordsource, recordsourceid, casesummary, logicalkey, alertprocessed, casedescription1, casedescription2, casedescription3, casedescription4, casedescription5, casedescription6, casedescription7, casedescription8, casedescription9, caseid) VALUES ('ADD-NOTE', ?, 'Similar Alert received', ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	public static final String UPDATE_LOGICALKEY_TO_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET logicalkey = ?, casestatus = ? WHERE alertid = ?";
	//public static final String UPDATE_LOGICALKEY_TO_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET logicalkey = ? WHERE alertid = ?";
	//public static final String UPDATE_LOGICALKEY_FOR_COMPONENT3_QUERYSTRING = "UPDATE dimminterface SET logicalkey = ?, casestatus = 'RESOL' WHERE alertid = ?";
	//public static final String GET_CASENUM_FROM_ANTC_QUERYSTRING = "SELECT caseid FROM nexusinterface WHERE logicalkey = ? AND casestatus NOT IN ('RESOL', 'CLOS') AND recordsource = ? AND ROWNUM = 1 ORDER BY creationtime DESC";
	//public static final String GET_CASENUM_FROM_ANTC_QUERYSTRING = "SELECT caseid FROM nexusinterface WHERE logicalkey = ? AND casestatus NOT IN ('RESOL', 'CLOS') AND recordsource = ?";
	public static String GET_CASENUM_FROM_ANTC_QUERYSTRING = "SELECT distinct logicalkey, caseid FROM nexusinterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey IN ()";
	public static final String UPDATE_CASENUM_FOR_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET caseid = ? WHERE alertid = ?";
	//public static final String UPDATE_CASENUM_FOR_PHYSICALALERT_QUERYSTRING = "UPDATE dimminterface SET caseid = ? WHERE logicalkey = ? AND casestatus NOT IN ('RESOL', 'CLOS')";
	public static final String OPEN_CASES_FROM_ANTC_QUERYSTRING = "SELECT distinct caseid FROM nexusinterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP')";
	
	
	public static final String UPDATE_CASESTATUS_TO_ANTC_QUERYSTRING = "UPDATE nexusinterface SET casestatus = ? WHERE caseid = ?";
	public static final String UPDATE_CASESTATUS_TO_DIMM_QUERYSTRING = "UPDATE dimminterface SET casestatus = ? WHERE caseid = ?";
	//public static String CASESTATUS_FROM_NEXUS_QUERYSTRING = "SELECT case_id, rc_status FROM SYSADM.ps_rc_case WHERE rc_status IN ('RESOL', 'CLOS', 'OOS', 'DUP') and case_id IN ()";
	public static String CASESTATUS_FROM_NEXUS_QUERYSTRING = "SELECT case_id, rc_status, TO_CHAR(row_added_dttm , 'DD-Mon-YYYY HH:MI:SS PM') createdtime FROM SYSADM.ps_rc_case WHERE casestatus IN ('RESOL', 'CLOS', 'OOS', 'DUP') and case_id IN ()";
	//public static final String NEXUSCASE_FROM_OVO_QUERYSTRING = "SELECT nexuscaseid FROM (SELECT * FROM ovomessages WHERE ovonode = ? ORDER BY creationtime DESC) ovomessagesdesc WHERE ROWNUM = 1";
	
	public static final String NEXUSCASE_FROM_OVO_QUERYSTRING = "SELECT distinct caseid FROM nexusinterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid = (SELECT nexuscaseid FROM (SELECT * FROM ovomessages WHERE ovonode = ? ORDER BY creationtime DESC) ovomessagesdesc WHERE ROWNUM = 1)";
	
	//These queries are used if ANTC is down
	public static String GET_TIMESTAMP_FROM_ANTC_QUERYSTRING = "SELECT logicalkey, creationtime FROM nexusinterface WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey IN ()";
	//public static String UPDATE_CASESTATUS_IN_ANTC_IF_ANTCDOWN_QUERYSTRING = "UPDATE nexusinterface SET casestatus = 'RESOL' WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey = ?";
	//public static String UPDATE_CASESTATUS_IN_DIMM_IF_ANTCDOWN_QUERYSTRING = "UPDATE dimminterface SET casestatus = 'RESOL', logicalkey = 'ANTCISDOWN' WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey = ?";
	//public static String UPDATE_CASESTATUS_IN_ANTC_IF_ANTCDOWN_QUERYSTRING = "UPDATE nexusinterface SET casestatus = 'RESOL', logicalkey = 'ANTCDOWN', alertprocessed=9 WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey = ?";
	//public static String UPDATE_CASESTATUS_IN_DIMM_IF_ANTCDOWN_QUERYSTRING = "UPDATE dimminterface SET casestatus = 'RESOL', logicalkey = 'ANTCDOWN' WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') AND logicalkey = ?";
	
*/	
	
}