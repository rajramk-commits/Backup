package com.fedex.emea.sabreReport.ldap;

public interface LoggingInterface {
	public void logInfo(String message);
	public void logDebug(String message);
	public void logError(String message);
	public void logException(String message, Exception e);
	public void logFatal(String message);
}
