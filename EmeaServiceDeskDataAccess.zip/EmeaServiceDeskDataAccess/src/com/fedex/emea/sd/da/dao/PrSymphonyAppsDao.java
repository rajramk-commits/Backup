package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrSymphonyAppsDaoException;
import com.fedex.emea.sd.da.objects.PrSymphonyApps;
import com.fedex.emea.sd.da.objects.PrSymphonyAppsPk;

public interface PrSymphonyAppsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSymphonyAppsPk
	 */
	public PrSymphonyAppsPk insert(PrSymphonyApps dto);

	/** 
	 * Updates a single row in the PR_SYMPHONY_APPS table.
	 */
	public void update(PrSymphonyAppsPk pk, PrSymphonyApps dto) throws PrSymphonyAppsDaoException;

	/** 
	 * Deletes a single row in the PR_SYMPHONY_APPS table.
	 */
	public void delete(PrSymphonyAppsPk pk) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	public PrSymphonyApps findByPrimaryKey(String symEaiId) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria ''.
	 */
	public List<PrSymphonyApps> findAll() throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	public List<PrSymphonyApps> findWhereSymEaiIdEquals(String symEaiId) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	public List<PrSymphonyApps> findWhereSymAppNameEquals(String symAppName) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PROF_NAME = :symProfName'.
	 */
	public List<PrSymphonyApps> findWhereSymProfNameEquals(String symProfName) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_IT_LEAD = :symItLead'.
	 */
	public List<PrSymphonyApps> findWhereSymItLeadEquals(String symItLead) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PROJ_DISPO = :symProjDispo'.
	 */
	public List<PrSymphonyApps> findWhereSymProjDispoEquals(String symProjDispo) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_DOMAIN = :symDomain'.
	 */
	public List<PrSymphonyApps> findWhereSymDomainEquals(String symDomain) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_TIER = :symTier'.
	 */
	public List<PrSymphonyApps> findWhereSymTierEquals(String symTier) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_APP_STATE = :symAppState'.
	 */
	public List<PrSymphonyApps> findWhereSymAppStateEquals(String symAppState) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_FRMWRK = :symFrmwrk'.
	 */
	public List<PrSymphonyApps> findWhereSymFrmwrkEquals(String symFrmwrk) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_DWN_IMP = :symDwnImp'.
	 */
	public List<PrSymphonyApps> findWhereSymDwnImpEquals(String symDwnImp) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_AVG_TX_DAY = :symAvgTxDay'.
	 */
	public List<PrSymphonyApps> findWhereSymAvgTxDayEquals(String symAvgTxDay) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_RPO = :symRpo'.
	 */
	public List<PrSymphonyApps> findWhereSymRpoEquals(String symRpo) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_RTO = :symRto'.
	 */
	public List<PrSymphonyApps> findWhereSymRtoEquals(String symRto) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_ACCESS_TYP = :symAccessTyp'.
	 */
	public List<PrSymphonyApps> findWhereSymAccessTypEquals(String symAccessTyp) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PLATFORM = :symPlatform'.
	 */
	public List<PrSymphonyApps> findWhereSymPlatformEquals(String symPlatform) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_ARCH_DSGN = :symArchDsgn'.
	 */
	public List<PrSymphonyApps> findWhereSymArchDsgnEquals(String symArchDsgn) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_BACKLOG_METH = :symBacklogMeth'.
	 */
	public List<PrSymphonyApps> findWhereSymBacklogMethEquals(String symBacklogMeth) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_BUS_FUNC = :symBusFunc'.
	 */
	public List<PrSymphonyApps> findWhereSymBusFuncEquals(String symBusFunc) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EXT_USR = :symExtUsr'.
	 */
	public List<PrSymphonyApps> findWhereSymExtUsrEquals(String symExtUsr) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_INT_USR = :symIntUsr'.
	 */
	public List<PrSymphonyApps> findWhereSymIntUsrEquals(String symIntUsr) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_REGL_LEGAL_FLG = :symReglLegalFlg'.
	 */
	public List<PrSymphonyApps> findWhereSymReglLegalFlgEquals(String symReglLegalFlg) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_LAST_UPD_DTTM = :symLastUpdDttm'.
	 */
	public List<PrSymphonyApps> findWhereSymLastUpdDttmEquals(Date symLastUpdDttm) throws PrSymphonyAppsDaoException;

	/** 
	 * Returns the rows from the PR_SYMPHONY_APPS table that matches the specified primary-key value.
	 */
	public PrSymphonyApps findByPrimaryKey(PrSymphonyAppsPk pk) throws PrSymphonyAppsDaoException;

}
