package com.fedex.emea.sd.da.exceptions;

public class PrCorrActionsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7120657451187143906L;

	/**
	 * Method 'PrCorrActionsDaoException'
	 * 
	 * @param message
	 */
	public PrCorrActionsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrCorrActionsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrCorrActionsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
