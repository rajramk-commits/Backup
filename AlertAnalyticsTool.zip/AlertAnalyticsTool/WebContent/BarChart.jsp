<%@ page language="java" contentType="text/html; charset=UTF-8"	pageEncoding="UTF-8"%>
<%@ page import="java.util.*,java.sql.*" %>
<%@ page import="com.google.gson.*"%>
<%@page import="com.fedex.emea.sabreReport.model.*"%>
 
<%
Gson gsonObj = new Gson();
Map<Object,Object> map = null;
List<Map<Object,Object>> list = null;
String alertDataPoints = null;
String processStoppedDataPoints = null;
String fileSystemDataPoints = null;
boolean isFileSys = false;

//String Username = "";
String userID = "";
String userRole = "";
if(session.getAttribute("sessionName")==null)
{
	userID = (String)request.getSession().getAttribute("sessionName");
	userRole = (String)request.getSession().getAttribute("Sessionid");
	System.out.println("userID request GSS Home:"+userID);
	 if(userID == null && userRole == null)
    	{
		System.out.println("userID userRole are null");
    	} 
}
else
{
	userID = (String) session.getAttribute("sessionName");
	System.out.println("userID GSS Home:"+userID);
	userRole = (String) session.getAttribute("Sessionid");
}

try{
	@SuppressWarnings("unchecked")
   	List<SabreBean> data = (List<SabreBean>) request.getSession().getAttribute("sabreList");
	if(data != null && data.size() != 0)
	{
		// FileSystem alerts
		Map<String, Integer> fileSystemData = new HashMap<>();
		for(int i=0; i< data.size();i++)
		{
			String fileAlert = data.get(i).getAlertType();			
			if(fileAlert.equalsIgnoreCase("FileSystem"))
			{
				String shrtDesc = data.get(i).getShortDescr();
				System.out.println("shrtDesc :"+ shrtDesc);
				
				if(shrtDesc.contains(".emea.fedex.com"))
				{
					System.out.println("Contains!!! :");
					String filysys = shrtDesc.substring(shrtDesc.indexOf("Impacted Node  : ")+17, shrtDesc.indexOf(".emea.fedex.com"));
					System.out.println("filysys!!! :"+filysys);
					if(filysys != null && !filysys.equalsIgnoreCase(""))
					{
						if(fileSystemData.containsKey(filysys))
						{
							fileSystemData.put(filysys, fileSystemData.get(filysys)+1);
						}
						else
						{
							fileSystemData.put(filysys, 1);
						}
					}
				}
			}
		}
		//
		System.out.println("fileSystemData jsp:"+fileSystemData);
		Iterator<Map.Entry<String, Integer>> fsitr = fileSystemData.entrySet().iterator();
		list = new ArrayList<Map<Object,Object>>();
		int totFileSysCount = 0;
		while(fsitr.hasNext())
		{
			Map.Entry<String, Integer> entry = fsitr.next(); 
			map = new HashMap<Object,Object>();
			map.put("label", entry.getKey());
			map.put("y", entry.getValue());
			totFileSysCount += entry.getValue();
			list.add(map);
		}
		if(list.size()>0)
		{
			fileSystemDataPoints = gsonObj.toJson(list);
			isFileSys = true;
		}
		
		// All type alerts Graphs
		Map<String, Integer> alltypeAlertData = new HashMap<>();
		for(int i=0; i< data.size();i++)
		{
			String alert = data.get(i).getAlertType();
			if(alltypeAlertData.containsKey(alert))
			{
				alltypeAlertData.put(alert, alltypeAlertData.get(alert)+1);
			}
			else
			{
				alltypeAlertData.put(alert, 1);
			}
		}
		if(totFileSysCount != 0)
			alltypeAlertData.put("FileSystem",totFileSysCount);
		
		//
		
		System.out.println("alltypeAlertData jsp:"+alltypeAlertData);
		Iterator<Map.Entry<String, Integer>> itr = alltypeAlertData.entrySet().iterator();
		list = new ArrayList<Map<Object,Object>>();
		while(itr.hasNext())
		{
			Map.Entry<String, Integer> entry = itr.next(); 
			map = new HashMap<Object,Object>();
			map.put("label", entry.getKey());
			map.put("y", entry.getValue());
			list.add(map);
		}
		alertDataPoints = gsonObj.toJson(list);
		
		// ProcessStopped alerts
		Map<String, Integer> processStoppedData = new HashMap<>();
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc != null && !loc.equalsIgnoreCase(""))
			{
				if(processStoppedData.containsKey(loc))
				{
					processStoppedData.put(loc, processStoppedData.get(loc)+1);
				}
				else
				{
					processStoppedData.put(loc, 1);
				}
			}
		}
		
		System.out.println("processStoppedData jsp:"+processStoppedData);
		Iterator<Map.Entry<String, Integer>> psitr = processStoppedData.entrySet().iterator();
		list = new ArrayList<Map<Object,Object>>();
		while(psitr.hasNext())
		{
			Map.Entry<String, Integer> entry = psitr.next(); 
			map = new HashMap<Object,Object>();
			map.put("label", entry.getKey());
			map.put("y", entry.getValue());
			list.add(map);
		}
		processStoppedDataPoints = gsonObj.toJson(list);		
		
	}
	else
	{
		out.println("<div  style='width: 50%; margin-left: auto; margin-right: auto; margin-top: 200px;'>No Data found to render the graphs</div>");
	}
}
catch(Exception e){
	e.printStackTrace();
	out.println("<div  style='width: 50%; margin-left: auto; margin-right: auto; margin-top: 200px;'>Could not connect to the database. Please check if you have mySQL Connector installed on the machine - if not, try installing the same.</div>");
	alertDataPoints = null;
}
%>
 
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<script type="text/javascript">
function goBack() 
{
	window.location = "reportType.jsp";
}
window.onload = function() { 
 
<% if(alertDataPoints != null) { %>
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	exportEnabled: true,
	title: {
		text: "All Types",
		fontSize: 22
	},
	axisX:{
	     
	     labelAngle: -30// change to false
	 },
	data: [{
		type: "column", //change type to bar, line, area, pie, etc
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: <%out.print(alertDataPoints);%>
	}]
});
chart.render();
<% } %>

<% if(processStoppedDataPoints != null) { %>
var chart = new CanvasJS.Chart("chartContainer2", {
	animationEnabled: true,
	exportEnabled: true,
	title: {
		text: "Process Stopped",
		fontSize: 22
	},
	data: [{
		type: "column", //change type to bar, line, area, pie, etc
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: <%out.print(processStoppedDataPoints);%>
	}]
});
chart.render();
<% } %>

<% if(fileSystemDataPoints != null ) {%>
var chart = new CanvasJS.Chart("chartContainer3", {
	animationEnabled: true,
	exportEnabled: true,
	title: {
		text: "File System",
		fontSize: 22
	},
	data: [{
		type: "column", //change type to bar, line, area, pie, etc
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: <%out.print(fileSystemDataPoints);%>
	}]
});
chart.render();
<% } %>
//Weekly Trends
<% if(true) { %>
var chart = new CanvasJS.Chart("chartContainer4", {
	animationEnabled: true,
	exportEnabled: true,
	title: {
		text: "Weekly Trends",
		fontSize: 22
	},
	data: [{
		type: "column",
		showInLegend: true,
		name: "Current Week",
		color: "#4F81BC",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 5, label: "ProcessStopped" },
			{ y: 4, label: "FileSystem" },
			{ y: 0, label: "Database" },
			{ y: 13, label: "JMS Queue" },
			{ y: 0, label: "Others" }
		]
	},
	{
		type: "column",
		showInLegend: true,
		name: "Prev Week",
		color: "#C0504E",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 43, label: "ProcessStopped" },
			{ y: 1, label: "FileSystem" },
			{ y: 5, label: "Database" },
			{ y: 28, label: "JMS Queue" },
			{ y: 0, label: "Others" }
		]
	},
	{
		type: "column",
		showInLegend: true,
		name: "2nd Prev Week",
		color: "silver",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 169, label: "ProcessStopped" },
			{ y: 5, label: "FileSystem" },
			{ y: 7, label: "Database" },
			{ y: 26, label: "JMS Queue" },
			{ y: 0, label: "Others" }
		]
	},
	{
		type: "column",
		showInLegend: true,
		name: "3rd Prev Week",
		color: "gold",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 22, label: "ProcessStopped" },
			{ y: 6, label: "FileSystem" },
			{ y: 5, label: "Database" },
			{ y: 25, label: "JMS Queue" },
			{ y: 2, label: "Others" }
		]
	}]
});
chart.render();
<% } %>
//Monthly Trends
<% if(true) { %>
var chart = new CanvasJS.Chart("chartContainer5", {
	animationEnabled: true,
	exportEnabled: true,
	title: {
		text: "Monthly Trends",
		fontSize: 22
	},
	data: [{
		type: "column",
		showInLegend: true,
		name: "Jun",
		color: "#4F81BC",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 218, label: "ProcessStopped" },
			{ y: 10, label: "FileSystem" },
			{ y: 13, label: "Database" },
			{ y: 71, label: "JMS Queue" },
			{ y: 0, label: "Others" }
		]
	},
	{
		type: "column",
		showInLegend: true,
		name: "May",
		color: "#C0504E",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 108, label: "ProcessStopped" },
			{ y: 43, label: "FileSystem" },
			{ y: 34, label: "Database" },
			{ y: 162, label: "JMS Queue" },
			{ y: 5, label: "Others" }
		]
	},
	{
		type: "column",
		showInLegend: true,
		name: "Apr",
		color: "silver",
		indexLabel: " {y}",
		indexLabelFontColor: "black",
		dataPoints: [
			{ y: 72, label: "ProcessStopped" },
			{ y: 61, label: "FileSystem" },
			{ y: 56, label: "Database" },
			{ y: 177, label: "JMS Queue" },
			{ y: 15, label: "Others" }
		]
	}]
});
chart.render();
<% } %>

}
function toolTipFormatter(e) {
	var str = "";
	var total = 0 ;
	var str3;
	var str2 ;
	for (var i = 0; i < e.entries.length; i++){
		var str1 = "<span style= \"color:"+e.entries[i].dataSeries.color + "\">" + e.entries[i].dataSeries.name + "</span>: <strong>"+  e.entries[i].dataPoint.y + "</strong> <br/>" ;
		total = e.entries[i].dataPoint.y + total;
		str = str.concat(str1);
	}
	str2 = "<strong>" + e.entries[0].dataPoint.label + "</strong> <br/>";
	str3 = "<span style = \"color:Tomato\">Total: </span><strong>" + total + "</strong><br/>";
	return (str2.concat(str)).concat(str3);
}
function saveReport()
{
	window.location = "saveExcel.jsp";
	//window.close("SabreHomePage.jsp");
	//window.open("saveExcel.jsp");
	return false;
}

</script>
<style type="text/css">
.head{
		height :40px;
		background-color: #7030a0;
		margin:0;
		margin-left: 5%;
	}
.container
{
	display:flex;
	justify-content:center;
}
.toolbar {
    height: 75px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .out{
  float: right;
  font-size: 20px;
  color: white;
  margin: 1px;
  border-radius: 1px;
  border: 2px solid #eee;
  background-color: rgb(154 81 150); 
  width: 130px;
  height: 30px;
}
.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:1%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:30%;
	
	}
	.toolbar {
    height: 70px;
    
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
</style>
</head>
<body>
<div class="toolbar" role="banner">
<button class="out"  onclick="goBack()" >Home</button>
    <img
      width="143"
      alt="Angular Logo"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR4h9OKkNpZrtc-Z6l80kuRFy9wn3DPFOHaIncREOOreXAWEKLG"
      title= "FedEx"
      />
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
     
     <div style="margin-left: 40%">&nbsp;&nbsp;
     <label style = "color: white;" for="uID"><b> <%=userID %></b></label>
    <br>
     <button class="out" onclick="logout()" >Logout</button>
     </div>
</div>
<div class="head">
       	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:5px 0 0 0;margin-left: 5%;">
       	Sabre Alert Analytics  	 </p>
</div>
   		
<% 
if(isFileSys) {%>
<div id="chartContainer" style="height: 340px; width: 30%;display: inline-block;"></div>
<div id="chartContainerSpace" style="height: 340px; width: 4%;display: inline-block;"></div>
<div id="chartContainer2" style="height: 340px; width: 30%;display: inline-block;"></div>
<div id="chartContainerSpace" style="height: 340px; width: 4%;display: inline-block;"></div>
<div id="chartContainer3" style="height: 340px; width: 30%;display: inline-block;"></div>
<%}
else {%>
<div id="chartContainer" style="height: 340px; width: 40%;display: inline-block;"></div>
<div id="chartContainerSpace" style="height: 340px; width: 5%;display: inline-block;"></div>
<div id="chartContainer2" style="height: 340px; width: 40%;display: inline-block;"></div>
<%} %>
<div id="chartContainer4" style="height: 340px; width: 40%;display: inline-block;"></div>
<div id="chartContainerSpace" style="height: 340px; width: 5%;display: inline-block;"></div>
<div id="chartContainer5" style="height: 340px; width: 40%;display: inline-block;"></div>

<script src="canvas/canvasjs.min.js"></script>  <!-- https://cdnjs.cloudflare.com/ajax/libs/canvasjs/1.7.0/canvasjs.min.js -->
<div class="container">
<button class="buttonFont" onclick="return saveReport()"><a href="#" style="text-decoration:none; color: white" download="data.csv" id="btnSave" >Export data into Excel</a></button>
<!-- <button class="buttonFont" onclick="return saveReport()" > Export </button> -->
</div>
</body>
</html>                        