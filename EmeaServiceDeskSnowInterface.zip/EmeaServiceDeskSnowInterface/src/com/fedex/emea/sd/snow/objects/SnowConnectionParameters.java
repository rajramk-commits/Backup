package com.fedex.emea.sd.snow.objects;

public class SnowConnectionParameters {
	private String  snowDNS;
	private int     snowPort;
	private String  snowType;
	private String  snowUid;
	private String  snowPwd;
	private String  snowQueryTableURL;
	private String  snowQueryIncidentURL;
	private String  snowQueryAstcIncidentUpdateURL;
	private String  snowQuerySysJournalFieldURL;
	private boolean useProxy;
	private String  snowQueryStatsURL;
	
	public SnowConnectionParameters() {
	}
	
	public SnowConnectionParameters(String snowDNS, int snowPort, String snowType, String snowUid, String snowPwd, String snowQueryTableURL, String snowQueryIncidentURL, String snowQuerySysJournalFieldURL, boolean useProxy, String snowQueryStatsURL, String snowQueryAstcIncidentUpdateURL) {
		this.setSnowDNS(snowDNS);
		this.setSnowPort(snowPort);
		this.setSnowType(snowType);
		this.setSnowUid(snowUid);
		this.setSnowPwd(snowPwd); 
		this.setSnowQueryTableURL(snowQueryTableURL);
		this.setSnowQueryIncidentURL(snowQueryIncidentURL);
		this.setSnowQueryAstcIncidentUpdateURL(snowQueryAstcIncidentUpdateURL);
		this.setSnowQuerySysJournalFieldURL(snowQuerySysJournalFieldURL);
		this.setUseProxy(useProxy);
		this.setSnowQueryStatsURL(snowQueryStatsURL);
	}

	public String getSnowDNS() {
		return snowDNS;
	}

	public void setSnowDNS(String snowDNS) {
		this.snowDNS = snowDNS;
	}

	public int getSnowPort() {
		return snowPort;
	}

	public void setSnowPort(int snowPort) {
		this.snowPort = snowPort;
	}

	public String getSnowType() {
		return snowType;
	}

	public void setSnowType(String snowType) {
		this.snowType = snowType;
	}

	public String getSnowUid() {
		return snowUid;
	}

	public void setSnowUid(String snowUid) {
		this.snowUid = snowUid;
	}

	public String getSnowPwd() {
		return snowPwd;
	}

	public void setSnowPwd(String snowPwd) {
		this.snowPwd = snowPwd;
	}

	public String getSnowQueryTableURL() {
		return snowQueryTableURL;
	}

	public void setSnowQueryTableURL(String snowQueryTableURL) {
		this.snowQueryTableURL = snowQueryTableURL;
	}

	public String getSnowQueryIncidentURL() {
		return snowQueryIncidentURL;
	}

	public void setSnowQueryIncidentURL(String snowQueryIncidentURL) {
		this.snowQueryIncidentURL = snowQueryIncidentURL;
	}

	public String getSnowQuerySysJournalFieldURL() {
		return snowQuerySysJournalFieldURL;
	}

	public void setSnowQuerySysJournalFieldURL(String snowQuerySysJournalFieldURL) {
		this.snowQuerySysJournalFieldURL = snowQuerySysJournalFieldURL;
	}

	public boolean isUseProxy() {
		return useProxy;
	}

	public void setUseProxy(boolean useProxy) {
		this.useProxy = useProxy;
	}

	public String getSnowQueryStatsURL() {
		return snowQueryStatsURL;
	}

	public void setSnowQueryStatsURL(String snowQueryStatsURL) {
		this.snowQueryStatsURL = snowQueryStatsURL;
	}

	public String getSnowQueryAstcIncidentUpdateURL() {
		return snowQueryAstcIncidentUpdateURL;
	}

	public void setSnowQueryAstcIncidentUpdateURL(String snowQueryAstcIncidentUpdateURL) {
		this.snowQueryAstcIncidentUpdateURL = snowQueryAstcIncidentUpdateURL;
	}
	
}
