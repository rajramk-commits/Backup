package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.sql.SQLException;
import java.sql.Timestamp;

import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowCompositeIncidentData implements Serializable
{
	private static final long serialVersionUID = 1L;

	private String    caseSysId;
	private String    caseNumber;
	private String    caseSummary;
	private String    caseDescription;
	private String    caseBusinessUnit;
	private String    caseAssignedTo;
	private String    caseAssignedToName;
	private String    caseContact;
	private String    caseContactName;
	private String    casePriority;
	private String    caseStatus;
	private String    caseSource; 
	private String    caseType;
	private String    casePriorityDescr;
	private String    caseStatusDescr;
	private String    caseSourceDescr;
	private String    caseTypeDescr;
	private String    caseLocation;
	private String    caseActionTaken;
	private String    caseBusinessImpact;
	private String    caseCause;
	private String    providerGroupId;
	private String    providerGroupDescr;
	private String    providerGroupMail;
	private String    providerGroupMgr;
	private String    providerGroupChange;
	private Timestamp providerGroupChangeDateTime;
	private String    caseAreaId;
	private String    caseServiceId;
	private String    caseServiceCompId;
	private String    caseServiceFuncId;
	private String    caseAreaDescr;
	private String    caseServiceDescr;
	private String    caseServiceCompDescr;
	private String    caseServiceFuncDescr;
	private Timestamp caseCreationDate;
	private Timestamp caseClosedDate;
	private Timestamp caseResolvedDate;
	private Timestamp casePendClientDateTime;
	private String    caseVendor;
	private String    caseNode;
	private String    caseSystem;
	private String    caseApplication;
	private String    caseOperationalGroup;
	private String    caseOperationalGroupDescr;
	private Timestamp caseAddedDateTime;
	private Timestamp caseCloseDateTime; 
	private Timestamp caseTimeSlaDue;
	private String    caseKiAvailable;
	private String    caseCreatedBy;
	
	// Additional Fields
	
	private long      caseTimeUnassigned;
	private long      caseTimeOwnedByHelpdesk;
	private long      caseTimeOwnedByApplicationSupport;
	private long      caseTimeOwnedByOthers;
	private long      caseTimeOwnedByLevel3;
	private long      caseTimeToClosure;
	private long      caseTimeToResolution;
	private long      caseTimeNotHandled;
	private boolean   caseEscalatedToSdApp;
	private boolean   caseEscalatedToLevel3;
	private boolean   caseEscalatedToOther;
	private boolean   caseInSLA;
	
	private String    caseProviderGroupsList;
		
	public SnowCompositeIncidentData()
	{
	}
	
	public SnowCompositeIncidentData(SnowRequestMetrics scrMetric) throws SQLException {
		this.setCaseSysId(scrMetric.getSnowScrSysId());
		this.setCaseBusinessUnit("SDESK");									// DEFAULTED
		this.setCaseNumber(scrMetric.getSnowScrNumber());
		this.setCaseSummary(scrMetric.getSnowScrShortDescription());
		this.setCaseDescription(scrMetric.getSnowScrDescription());
		this.setCaseAssignedTo(scrMetric.getSnowScrAssignedTo());
		this.setCaseAssignedToName(null);									// Will be retrieved once used
		this.setCaseContact(scrMetric.getSnowScrU_AffectedUser());
		this.setCaseContactName(null);										// Will be retrieved once used
		
		this.setCasePriority(scrMetric.getSnowScrPriority());
		this.setCaseStatus(scrMetric.getSnowScrState());
		this.setCaseSource(scrMetric.getSnowScrContactType());
		this.setCaseType(scrMetric.getSnowScrCategory());
		
		this.setCasePriorityDescr(null);									// Will be retrieved once used
		this.setCaseStatusDescr(null);										// Will be retrieved once used
		this.setCaseSourceDescr(null);										// Will be retrieved once used
		this.setCaseTypeDescr(null);										// Will be retrieved once used
		
		this.setCaseLocation(scrMetric.getSnowScrLocation());
		this.setCaseActionTaken(scrMetric.getSnowScrU_ResolvedBy());
		this.setCaseBusinessImpact(null);									// Not Available
		this.setCaseCause(scrMetric.getSnowScrU_CausedBy());
		
		this.setProviderGroupId(scrMetric.getSnowScrAssignmentGroup());
		this.setProviderGroupDescr(null);									// Will be retrieved once used
		this.setProviderGroupMail(null);									// Not Available
		this.setProviderGroupMgr(null);										// Not Available
		this.setProviderGroupChange(null);				// MULTIPLE OCCURS
		this.setProviderGroupChangeDateTime(null);		// MULTIPLE OCCURS
		
		this.setCaseAreaId(null);											// Retrieved from Business Service
		this.setCaseServiceId(scrMetric.getSnowScrU_BusinessService());
		this.setCaseServiceCompId(null);									// Not Available
		this.setCaseServiceFuncId(null);									// Not Available
		
		this.setCaseAreaDescr(null);										// Will be retrieved once used
		this.setCaseServiceDescr(null);										// Will be retrieved once used
		this.setCaseServiceCompDescr(null);									// Not Available
		this.setCaseServiceFuncDescr(null);									// Not Available
		
		if (scrMetric.getSnowScrSysCreatedOn() != null && !scrMetric.getSnowScrSysCreatedOn().isEmpty()) {
			this.setCaseCreationDate(new Timestamp(SnowUtilities.formatToDateFromSNOW(scrMetric.getSnowScrSysCreatedOn()).getTime()));
		} else {
			this.setCaseCreationDate(null);
		}
		if (scrMetric.getSnowScrClosedAt() != null && !scrMetric.getSnowScrClosedAt().isEmpty()) {
			this.setCaseClosedDate(new Timestamp(SnowUtilities.formatToDateFromSNOW(scrMetric.getSnowScrClosedAt()).getTime()));
		} else {
			this.setCaseClosedDate(null);
		}
		if (scrMetric.getSnowScrSysCreatedOn() != null && !scrMetric.getSnowScrSysCreatedOn().isEmpty()) {
			this.setCaseAddedDateTime(new Timestamp(SnowUtilities.formatToDateFromSNOW(scrMetric.getSnowScrSysCreatedOn()).getTime()));
		} else {
			this.setCaseAddedDateTime(null);
		}
		if (scrMetric.getSnowScrClosedAt() != null && !scrMetric.getSnowScrClosedAt().isEmpty()) {
			this.setCaseCloseDateTime(new Timestamp(SnowUtilities.formatToDateFromSNOW(scrMetric.getSnowScrClosedAt()).getTime()));
		} else {
			this.setCaseCloseDateTime(null);
		}
		
		// Resolve Date not PRESENT in Request Metrics
		//
		this.setCaseResolvedDate(null);										// Will be retrieved once used
		
		if (scrMetric.getSnowScrSlaDue() != null && !scrMetric.getSnowScrSlaDue().isEmpty()) {
			this.setCaseTimeSlaDue(new Timestamp(SnowUtilities.formatToDateFromSNOW(scrMetric.getSnowScrSlaDue()).getTime()));
		} else {
			this.setCaseTimeSlaDue(null);
		}
		
		this.setCasePendClientDateTime(null);								// Not Available
		this.setCaseVendor(null);											// Not Available
		this.setCaseNode(null);												// Not Available
		this.setCaseSystem(null);											// Not Available
		this.setCaseApplication(null);										// Not Available
		this.setCaseOperationalGroup(scrMetric.getSnowScrU_SupportStructure());
		this.setCaseOperationalGroupDescr(scrMetric.getSnowScrU_SupportStructure());
		this.setCaseKiAvailable(scrMetric.getSnowScrU_KnowledgeAvailable());
		this.setCaseCreatedBy(scrMetric.getSnowScrSysCreatedBy());
	}
	
	public SnowCompositeIncidentData(SnowIncidentMetrics incMetric) throws SQLException {
		this.setCaseSysId(incMetric.getSnowIncSysId());
		this.setCaseBusinessUnit("SDESK");									// DEFAULTED
		this.setCaseNumber(incMetric.getSnowIncNumber());
		this.setCaseSummary(incMetric.getSnowIncShortDescription());
		this.setCaseDescription(incMetric.getSnowIncDescription());
		this.setCaseAssignedTo(incMetric.getSnowIncAssignedTo());
		this.setCaseAssignedToName(null);									// Will be retrieved once used
		this.setCaseContact(incMetric.getSnowIncU_AffectedUser());
		this.setCaseContactName(null);										// Will be retrieved once used
		
		this.setCasePriority(incMetric.getSnowIncPriority());
		this.setCaseStatus(incMetric.getSnowIncState());
		this.setCaseSource(incMetric.getSnowIncContactType());
		this.setCaseType(incMetric.getSnowIncCategory());
		
		this.setCasePriorityDescr(null);									// Will be retrieved once used
		this.setCaseStatusDescr(null);										// Will be retrieved once used
		this.setCaseSourceDescr(null);										// Will be retrieved once used
		this.setCaseTypeDescr(null);										// Will be retrieved once used
		
		this.setCaseLocation(incMetric.getSnowIncLocation());
		this.setCaseActionTaken(incMetric.getSnowIncU_ResolvedBy());
		this.setCaseBusinessImpact(null);									// Not Available
		this.setCaseCause(incMetric.getSnowIncU_CausedBy());
		
		this.setProviderGroupId(incMetric.getSnowIncAssignmentGroup());
		this.setProviderGroupDescr(null);									// Will be retrieved once used
		this.setProviderGroupMail(null);									// Not Available
		this.setProviderGroupMgr(null);										// Not Available
		this.setProviderGroupChange(null);				// MULTIPLE OCCURS
		this.setProviderGroupChangeDateTime(null);		// MULTIPLE OCCURS
		
		this.setCaseAreaId(null);											// Retrieved from Business Service
		this.setCaseServiceId(incMetric.getSnowIncU_BusinessService());
		this.setCaseServiceCompId(null);									// Not Available
		this.setCaseServiceFuncId(null);									// Not Available
		
		this.setCaseAreaDescr(null);										// Will be retrieved once used
		this.setCaseServiceDescr(null);										// Will be retrieved once used
		this.setCaseServiceCompDescr(null);									// Not Available
		this.setCaseServiceFuncDescr(null);									// Not Available
		
		if (incMetric.getSnowIncSysCreatedOn() != null && !incMetric.getSnowIncSysCreatedOn().isEmpty()) {
			this.setCaseCreationDate(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncSysCreatedOn()).getTime()));
		} else {
			this.setCaseCreationDate(null);
		}
		if (incMetric.getSnowIncClosedAt() != null && !incMetric.getSnowIncClosedAt().isEmpty()) {
			this.setCaseClosedDate(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncClosedAt()).getTime()));
		} else {
			this.setCaseClosedDate(null);
		}
		if (incMetric.getSnowIncSysCreatedOn() != null && !incMetric.getSnowIncSysCreatedOn().isEmpty()) {
			this.setCaseAddedDateTime(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncSysCreatedOn()).getTime()));
		} else {
			this.setCaseAddedDateTime(null);
		}
		if (incMetric.getSnowIncClosedAt() != null && !incMetric.getSnowIncClosedAt().isEmpty()) {
			this.setCaseCloseDateTime(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncClosedAt()).getTime()));
		} else {
			this.setCaseCloseDateTime(null);
		}
		if (incMetric.getSnowIncResolvedAt() != null && !incMetric.getSnowIncResolvedAt().isEmpty()) {
			this.setCaseResolvedDate(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncResolvedAt()).getTime()));
		} else {
			this.setCaseResolvedDate(null);
		}
		
		if (incMetric.getSnowIncSlaDue() != null && !incMetric.getSnowIncSlaDue().isEmpty()) {
			this.setCaseTimeSlaDue(new Timestamp(SnowUtilities.formatToDateFromSNOW(incMetric.getSnowIncSlaDue()).getTime()));
		} else {
			this.setCaseTimeSlaDue(null);
		}
		
		this.setCasePendClientDateTime(null);								// Not Available
		this.setCaseVendor(null);											// Not Available
		this.setCaseNode(null);												// Not Available
		this.setCaseSystem(null);											// Not Available
		this.setCaseApplication(null);										// Not Available
		this.setCaseOperationalGroup(incMetric.getSnowIncU_SupportStructure());
		this.setCaseOperationalGroupDescr(incMetric.getSnowIncU_SupportStructure());
		this.setCaseKiAvailable(incMetric.getSnowIncU_KnowledgeAvailable());
		this.setCaseCreatedBy(incMetric.getSnowIncSysCreatedBy());
	}
	
	public SnowCompositeIncidentData(SnowTasks incident) throws SQLException
	{
		this.setCaseSysId(incident.getSnowSysId());									// caseId
		this.setCaseNumber(incident.getSnowNumber());								// caseId
		this.setCaseSummary(incident.getSnowShortDescription());					// caseSummary
		this.setCaseDescription(incident.getSnowDescription()); 					// caseDescription					
		this.setCaseBusinessUnit(null);					// caseBu (ID)
		this.setCaseAssignedTo(incident.getSnowAssignedTo());						// caseAssignedTo (PIN)
		this.setCaseAssignedToName(incident.getSnowAssignedTo());					// caseAssignedToName
		this.setCaseContact(incident.getSnowU_AffectedUser());						// caseContact (PIN)
		this.setCaseContactName(incident.getSnowU_AffectedUser());					// caseContactName
		
		
		this.setCasePriority(incident.getSnowPriority());							// casePriority (ID)
		this.setCaseStatus(incident.getSnowState());								// caseStatus (ID)
		this.setCaseSource(incident.getSnowContactType()); 							// caseSource (ID)
		this.setCaseType(incident.getSnowCategory());								// caseType (ID)
		
		this.setCasePriorityDescr(null);										// Will be retrieved once used
		this.setCaseStatusDescr(null);											// Will be retrieved once used
		this.setCaseSourceDescr(null);											// Will be retrieved once used
		this.setCaseTypeDescr(null);											// Will be retrieved once used
		
		this.setCaseLocation(incident.getSnowLocation());							// caseLocation
		this.setCaseActionTaken(incident.getSnowU_ResolvedBy());					// caseActionTaken
		this.setCaseBusinessImpact(null);				// caseBusinessImpact
		this.setCaseCause(incident.getSnowU_CausedBy());							// caseCause
		
		this.setProviderGroupId(incident.getSnowAssignmentGroup());					// providerGroupId
		this.setProviderGroupDescr(null);				// providerGroupDescr
		this.setProviderGroupMail(null);				// providerGroupMail
		this.setProviderGroupMgr(null);					// providerGroupMgr
		this.setProviderGroupChange(null);				// providerGroupChange - MULTIPLE OCCURS
		this.setProviderGroupChangeDateTime(null);		// providerGroupChangeDateTime - MULTIPLE OCCURS
		
		
		this.setCaseAreaId(incident.getSnowU_Classification());						// caseAreaId
		this.setCaseServiceId(incident.getSnowU_BusinessService());					// caseServiceId
		this.setCaseServiceCompId(null);				// caseServiceCompId
		this.setCaseServiceFuncId(null);				// caseServiceFuncId
		
		this.setCaseAreaDescr(null);					// caseAreaDescr
		this.setCaseServiceDescr(null);					// caseServiceDescr
		this.setCaseServiceCompDescr(null);				// caseServiceCompDescr
		this.setCaseServiceFuncDescr(null);				// caseServiceFuncDescr
		
		
		this.setCaseCreationDate(new Timestamp(incident.getDtSnowOpenedAt().getTime()));		// caseCreationDate
		this.setCaseClosedDate(new Timestamp(incident.getDtSnowClosedAt().getTime()));			// caseClosedDate
		this.setCasePendClientDateTime(null);			// casePendClientDateTime
		this.setCaseVendor(null);						// caseVendor
		this.setCaseNode(null);							// caseNode
		this.setCaseSystem(null);						// caseSystem
		this.setCaseApplication(null);					// caseApplication
		this.setCaseOperationalGroup(incident.getSnowU_SupportStructure());						// caseOperationalGroup
		this.setCaseOperationalGroupDescr(incident.getSnowU_SupportStructure());				// caseOperationalGroupDescr
		this.setCaseAddedDateTime(new Timestamp(incident.getDtSnowSysCreatedOn().getTime()));	// caseAddedDateTime
		this.setCaseCloseDateTime(new Timestamp(incident.getDtSnowClosedAt().getTime())); 		// caseCloseDateTime
		this.setCaseKiAvailable(incident.getSnowU_KnowledgeAvailable());						// caseKiAvailable
		this.setCaseCreatedBy(incident.getSnowSysCreatedBy());									// caseCreatedBy
	}
	
	public void setIncidentDetails(SnowIncident incident) throws SQLException {
		this.setCaseSysId(null);						// caseId
		this.setCaseNumber(null);						// caseId
		this.setCaseSummary(null);						// caseSummary
		this.setCaseDescription(null);					// caseDescription					
		this.setCaseBusinessUnit(null);					// caseBu (ID)
		this.setCaseAssignedTo(null);					// caseAssignedTo (PIN)
		this.setCaseAssignedToName(null);				// caseAssignedToName
		this.setCaseContact(null);						// caseContact (PIN)
		this.setCaseContactName(null);					// caseContactName
		this.setCasePriority(null);						// casePriority (ID)
		this.setCaseStatus(null);						// caseStatus (ID)
		this.setCaseSource(null); 						// caseSource (ID)
		this.setCaseType(null);							// caseType (ID)
		this.setCasePriorityDescr(null);				// casePriorityDescr
		this.setCaseStatusDescr(null);					// caseStatusDescr
		this.setCaseSourceDescr(null);					// caseSourceDescr
		this.setCaseTypeDescr(null);					// caseTypeDescr
		this.setCaseLocation(null);						// caseLocation
		this.setCaseActionTaken(null);					// caseActionTaken
		this.setCaseBusinessImpact(null);				// caseBusinessImpact
		this.setCaseCause(null);						// caseCause
		this.setProviderGroupId(null);					// providerGroupId
		this.setProviderGroupDescr(null);				// providerGroupDescr
		this.setProviderGroupMail(null);				// providerGroupMail
		this.setProviderGroupMgr(null);					// providerGroupMgr
		this.setCaseAreaId(null);						// caseAreaId
		this.setCaseServiceId(null);					// caseServiceId
		this.setCaseServiceCompId(null);				// caseServiceCompId
		this.setCaseServiceFuncId(null);				// caseServiceFuncId
		this.setCaseAreaDescr(null);					// caseAreaDescr
		this.setCaseServiceDescr(null);					// caseServiceDescr
		this.setCaseServiceCompDescr(null);				// caseServiceCompDescr
		this.setCaseServiceFuncDescr(null);				// caseServiceFuncDescr
		this.setCaseCreationDate(null);				// caseCreationDate
		this.setCaseAddedDateTime(null);				// caseAddedDateTime
		this.setCaseCloseDateTime(null); 			// caseCloseDateTime
		this.setCaseCreatedBy(null);					// caseCreatedBy
	}

	public String getCaseSysId() {
		return caseSysId;
	}

	public void setCaseSysId(String caseId) {
		this.caseSysId = caseId;
	}

	public String getCaseSummary() {
		return caseSummary;
	}

	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}

	public String getCaseDescription() {
		return caseDescription;
	}

	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}

	public String getCaseBusinessUnit() {
		return caseBusinessUnit;
	}

	public void setCaseBusinessUnit(String caseBusinessUnit) {
		this.caseBusinessUnit = caseBusinessUnit;
	}

	public String getCaseAssignedTo() {
		return caseAssignedTo;
	}

	public void setCaseAssignedTo(String caseAssignedTo) {
		this.caseAssignedTo = caseAssignedTo;
	}

	public String getCaseAssignedToName() {
		return caseAssignedToName;
	}

	public void setCaseAssignedToName(String caseAssignedToName) {
		this.caseAssignedToName = caseAssignedToName;
	}

	public String getCaseContact() {
		return caseContact;
	}

	public void setCaseContact(String caseContact) {
		this.caseContact = caseContact;
	}

	public String getCaseContactName() {
		return caseContactName;
	}

	public void setCaseContactName(String caseContactName) {
		this.caseContactName = caseContactName;
	}

	public String getCasePriority() {
		return casePriority;
	}

	public void setCasePriority(String casePriority) {
		this.casePriority = casePriority;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getCaseSource() {
		return caseSource;
	}

	public void setCaseSource(String caseSource) {
		this.caseSource = caseSource;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getCasePriorityDescr() {
		return casePriorityDescr;
	}

	public void setCasePriorityDescr(String casePriorityDescr) {
		this.casePriorityDescr = casePriorityDescr;
	}

	public String getCaseStatusDescr() {
		return caseStatusDescr;
	}

	public void setCaseStatusDescr(String caseStatusDescr) {
		this.caseStatusDescr = caseStatusDescr;
	}

	public String getCaseSourceDescr() {
		return caseSourceDescr;
	}

	public void setCaseSourceDescr(String caseSourceDescr) {
		this.caseSourceDescr = caseSourceDescr;
	}

	public String getCaseTypeDescr() {
		return caseTypeDescr;
	}

	public void setCaseTypeDescr(String caseTypeDescr) {
		this.caseTypeDescr = caseTypeDescr;
	}

	public String getCaseLocation() {
		return caseLocation;
	}

	public void setCaseLocation(String caseLocation) {
		this.caseLocation = caseLocation;
	}

	public String getCaseActionTaken() {
		return caseActionTaken;
	}

	public void setCaseActionTaken(String caseActionTaken) {
		this.caseActionTaken = caseActionTaken;
	}

	public String getCaseBusinessImpact() {
		return caseBusinessImpact;
	}

	public void setCaseBusinessImpact(String caseBusinessImpact) {
		this.caseBusinessImpact = caseBusinessImpact;
	}

	public String getCaseCause() {
		return caseCause;
	}

	public void setCaseCause(String caseCause) {
		this.caseCause = caseCause;
	}

	public String getProviderGroupId() {
		return providerGroupId;
	}

	public void setProviderGroupId(String providerGroupId) {
		this.providerGroupId = providerGroupId;
	}

	public String getProviderGroupDescr() {
		return providerGroupDescr;
	}

	public void setProviderGroupDescr(String providerGroupDescr) {
		this.providerGroupDescr = providerGroupDescr;
	}

	public String getProviderGroupMail() {
		return providerGroupMail;
	}

	public void setProviderGroupMail(String providerGroupMail) {
		this.providerGroupMail = providerGroupMail;
	}

	public String getProviderGroupMgr() {
		return providerGroupMgr;
	}

	public void setProviderGroupMgr(String providerGroupMgr) {
		this.providerGroupMgr = providerGroupMgr;
	}

	public String getProviderGroupChange() {
		return providerGroupChange;
	}

	public void setProviderGroupChange(String providerGroupChange) {
		this.providerGroupChange = providerGroupChange;
	}

	public Timestamp getProviderGroupChangeDateTime() {
		return providerGroupChangeDateTime;
	}

	public void setProviderGroupChangeDateTime(Timestamp providerGroupChangeDateTime) {
		this.providerGroupChangeDateTime = providerGroupChangeDateTime;
	}

	public String getCaseAreaId() {
		return caseAreaId;
	}

	public void setCaseAreaId(String caseAreaId) {
		this.caseAreaId = caseAreaId;
	}

	public String getCaseServiceId() {
		return caseServiceId;
	}

	public void setCaseServiceId(String caseServiceId) {
		this.caseServiceId = caseServiceId;
	}

	public String getCaseServiceCompId() {
		return caseServiceCompId;
	}

	public void setCaseServiceCompId(String caseServiceCompId) {
		this.caseServiceCompId = caseServiceCompId;
	}

	public String getCaseServiceFuncId() {
		return caseServiceFuncId;
	}

	public void setCaseServiceFuncId(String caseServiceFuncId) {
		this.caseServiceFuncId = caseServiceFuncId;
	}

	public String getCaseAreaDescr() {
		return caseAreaDescr;
	}

	public void setCaseAreaDescr(String caseAreaDescr) {
		this.caseAreaDescr = caseAreaDescr;
	}

	public String getCaseServiceDescr() {
		return caseServiceDescr;
	}

	public void setCaseServiceDescr(String caseServiceDescr) {
		this.caseServiceDescr = caseServiceDescr;
	}

	public String getCaseServiceCompDescr() {
		return caseServiceCompDescr;
	}

	public void setCaseServiceCompDescr(String caseServiceCompDescr) {
		this.caseServiceCompDescr = caseServiceCompDescr;
	}

	public String getCaseServiceFuncDescr() {
		return caseServiceFuncDescr;
	}

	public void setCaseServiceFuncDescr(String caseServiceFuncDescr) {
		this.caseServiceFuncDescr = caseServiceFuncDescr;
	}

	public Timestamp getCaseCreationDate() {
		return caseCreationDate;
	}

	public void setCaseCreationDate(Timestamp caseCreationDate) {
		this.caseCreationDate = caseCreationDate;
	}

	public Timestamp getCaseClosedDate() {
		return caseClosedDate;
	}

	public void setCaseClosedDate(Timestamp caseClosedDate) {
		this.caseClosedDate = caseClosedDate;
	}

	public Timestamp getCasePendClientDateTime() {
		return casePendClientDateTime;
	}

	public void setCasePendClientDateTime(Timestamp casePendClientDateTime) {
		this.casePendClientDateTime = casePendClientDateTime;
	}

	public String getCaseVendor() {
		return caseVendor;
	}

	public void setCaseVendor(String caseVendor) {
		this.caseVendor = caseVendor;
	}

	public String getCaseNode() {
		return caseNode;
	}

	public void setCaseNode(String caseNode) {
		this.caseNode = caseNode;
	}

	public String getCaseSystem() {
		return caseSystem;
	}

	public void setCaseSystem(String caseSystem) {
		this.caseSystem = caseSystem;
	}

	public String getCaseApplication() {
		return caseApplication;
	}

	public void setCaseApplication(String caseApplication) {
		this.caseApplication = caseApplication;
	}

	public String getCaseOperationalGroup() {
		return caseOperationalGroup;
	}

	public void setCaseOperationalGroup(String caseOperationalGroup) {
		this.caseOperationalGroup = caseOperationalGroup;
	}

	public String getCaseOperationalGroupDescr() {
		return caseOperationalGroupDescr;
	}

	public void setCaseOperationalGroupDescr(String caseOperationalGroupDescr) {
		this.caseOperationalGroupDescr = caseOperationalGroupDescr;
	}

	public Timestamp getCaseAddedDateTime() {
		return caseAddedDateTime;
	}

	public void setCaseAddedDateTime(Timestamp caseAddedDateTime) {
		this.caseAddedDateTime = caseAddedDateTime;
	}

	public Timestamp getCaseCloseDateTime() {
		return caseCloseDateTime;
	}

	public void setCaseCloseDateTime(Timestamp caseCloseDateTime) {
		this.caseCloseDateTime = caseCloseDateTime;
	}

	public String getCaseKiAvailable() {
		return caseKiAvailable;
	}

	public void setCaseKiAvailable(String caseKiAvailable) {
		this.caseKiAvailable = caseKiAvailable;
	}

	public long getCaseTimeUnassigned() {
		return caseTimeUnassigned;
	}

	public void setCaseTimeUnassigned(long caseTimeUnassigned) {
		this.caseTimeUnassigned = caseTimeUnassigned;
	}

	public long getCaseTimeOwnedByHelpdesk() {
		return caseTimeOwnedByHelpdesk;
	}

	public void setCaseTimeOwnedByHelpdesk(long caseTimeOwnedByHelpdesk) {
		this.caseTimeOwnedByHelpdesk = caseTimeOwnedByHelpdesk;
	}

	public long getCaseTimeOwnedByApplicationSupport() {
		return caseTimeOwnedByApplicationSupport;
	}

	public void setCaseTimeOwnedByApplicationSupport(
			long caseTimeOwnedByApplicationSupport) {
		this.caseTimeOwnedByApplicationSupport = caseTimeOwnedByApplicationSupport;
	}

	public long getCaseTimeOwnedByOthers() {
		return caseTimeOwnedByOthers;
	}

	public void setCaseTimeOwnedByOthers(long caseTimeOwnedByOthers) {
		this.caseTimeOwnedByOthers = caseTimeOwnedByOthers;
	}

	public long getCaseTimeOwnedByLevel3() {
		return caseTimeOwnedByLevel3;
	}

	public void setCaseTimeOwnedByLevel3(long caseTimeOwnedByLevel3) {
		this.caseTimeOwnedByLevel3 = caseTimeOwnedByLevel3;
	}

	public long getCaseTimeToClosure() {
		return caseTimeToClosure;
	}

	public void setCaseTimeToClosure(long caseTimeToClosure) {
		this.caseTimeToClosure = caseTimeToClosure;
	}

	public long getCaseTimeToResolution() {
		return caseTimeToResolution;
	}

	public void setCaseTimeToResolution(long caseTimeToResolution) {
		this.caseTimeToResolution = caseTimeToResolution;
	}

	public long getCaseTimeNotHandled() {
		return caseTimeNotHandled;
	}

	public void setCaseTimeNotHandled(long caseTimeNotHandled) {
		this.caseTimeNotHandled = caseTimeNotHandled;
	}

	public boolean isCaseEscalatedToSdApp() {
		return caseEscalatedToSdApp;
	}

	public void setCaseEscalatedToSdApp(boolean caseEscalatedToSdApp) {
		this.caseEscalatedToSdApp = caseEscalatedToSdApp;
	}

	public boolean isCaseEscalatedToLevel3() {
		return caseEscalatedToLevel3;
	}

	public void setCaseEscalatedToLevel3(boolean caseEscalatedToLevel3) {
		this.caseEscalatedToLevel3 = caseEscalatedToLevel3;
	}

	public boolean isCaseEscalatedToOther() {
		return caseEscalatedToOther;
	}

	public void setCaseEscalatedToOther(boolean caseEscalatedToOther) {
		this.caseEscalatedToOther = caseEscalatedToOther;
	}

	public String getCaseProviderGroupsList() {
		return caseProviderGroupsList;
	}

	public void setCaseProviderGroupsList(String caseProviderGroupsList) {
		this.caseProviderGroupsList = caseProviderGroupsList;
	}

	public String getCaseCreatedBy() {
		return caseCreatedBy;
	}

	public void setCaseCreatedBy(String caseCreatedBy) {
		this.caseCreatedBy = caseCreatedBy;
	}

	public String getCaseNumber() {
		return caseNumber;
	}

	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}

	public Timestamp getCaseResolvedDate() {
		return caseResolvedDate;
	}

	public void setCaseResolvedDate(Timestamp caseResolvedDate) {
		this.caseResolvedDate = caseResolvedDate;
	}

	public boolean isCaseInSLA() {
		return caseInSLA;
	}

	public void setCaseInSLA(boolean caseInSLA) {
		this.caseInSLA = caseInSLA;
	}

	public Timestamp getCaseTimeSlaDue() {
		return caseTimeSlaDue;
	}

	public void setCaseTimeSlaDue(Timestamp caseTimeSlaDue) {
		this.caseTimeSlaDue = caseTimeSlaDue;
	}

}
