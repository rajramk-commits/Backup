package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;

public class PrMitigations implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6571073286823588701L;

	protected String cy;
	protected String eaiId;
	protected String symAppName;
	protected String ni2AppId;
	protected String ni2AppName;
	protected String respMdPin;
	protected String respMgrPin;
	protected String item;
	protected String question;
	protected String answer;
	protected String mitigationStatus;
	protected Date lastUpdateDttm;
	protected int auditId;
	protected boolean auditIdNull = true;
	protected String org;

	/**
	 * Method 'PrMitigations'
	 * 
	 */
	public PrMitigations()
	{
	}

	/**
	 * Method 'getCy'
	 * 
	 * @return String
	 */
	public String getCy()
	{
		return cy;
	}

	/**
	 * Method 'setCy'
	 * 
	 * @param cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/**
	 * Method 'getEaiId'
	 * 
	 * @return String
	 */
	public String getEaiId()
	{
		return eaiId;
	}

	/**
	 * Method 'setEaiId'
	 * 
	 * @param eaiId
	 */
	public void setEaiId(String eaiId)
	{
		this.eaiId = eaiId;
	}

	/**
	 * Method 'getSymAppName'
	 * 
	 * @return String
	 */
	public String getSymAppName()
	{
		return symAppName;
	}

	/**
	 * Method 'setSymAppName'
	 * 
	 * @param symAppName
	 */
	public void setSymAppName(String symAppName)
	{
		this.symAppName = symAppName;
	}

	/**
	 * Method 'getNi2AppId'
	 * 
	 * @return String
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'setNi2AppId'
	 * 
	 * @param ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'getNi2AppName'
	 * 
	 * @return String
	 */
	public String getNi2AppName()
	{
		return ni2AppName;
	}

	/**
	 * Method 'setNi2AppName'
	 * 
	 * @param ni2AppName
	 */
	public void setNi2AppName(String ni2AppName)
	{
		this.ni2AppName = ni2AppName;
	}

	/**
	 * Method 'getRespMdPin'
	 * 
	 * @return String
	 */
	public String getRespMdPin()
	{
		return respMdPin;
	}

	/**
	 * Method 'setRespMdPin'
	 * 
	 * @param respMdPin
	 */
	public void setRespMdPin(String respMdPin)
	{
		this.respMdPin = respMdPin;
	}

	/**
	 * Method 'getRespMgrPin'
	 * 
	 * @return String
	 */
	public String getRespMgrPin()
	{
		return respMgrPin;
	}

	/**
	 * Method 'setRespMgrPin'
	 * 
	 * @param respMgrPin
	 */
	public void setRespMgrPin(String respMgrPin)
	{
		this.respMgrPin = respMgrPin;
	}

	/**
	 * Method 'getItem'
	 * 
	 * @return String
	 */
	public String getItem()
	{
		return item;
	}

	/**
	 * Method 'setItem'
	 * 
	 * @param item
	 */
	public void setItem(String item)
	{
		this.item = item;
	}

	/**
	 * Method 'getQuestion'
	 * 
	 * @return String
	 */
	public String getQuestion()
	{
		return question;
	}

	/**
	 * Method 'setQuestion'
	 * 
	 * @param question
	 */
	public void setQuestion(String question)
	{
		this.question = question;
	}

	/**
	 * Method 'getAnswer'
	 * 
	 * @return String
	 */
	public String getAnswer()
	{
		return answer;
	}

	/**
	 * Method 'setAnswer'
	 * 
	 * @param answer
	 */
	public void setAnswer(String answer)
	{
		this.answer = answer;
	}

	/**
	 * Method 'getMitigationStatus'
	 * 
	 * @return String
	 */
	public String getMitigationStatus()
	{
		return mitigationStatus;
	}

	/**
	 * Method 'setMitigationStatus'
	 * 
	 * @param mitigationStatus
	 */
	public void setMitigationStatus(String mitigationStatus)
	{
		this.mitigationStatus = mitigationStatus;
	}

	/**
	 * Method 'getLastUpdateDttm'
	 * 
	 * @return Date
	 */
	public Date getLastUpdateDttm()
	{
		return lastUpdateDttm;
	}

	/**
	 * Method 'setLastUpdateDttm'
	 * 
	 * @param lastUpdateDttm
	 */
	public void setLastUpdateDttm(Date lastUpdateDttm)
	{
		this.lastUpdateDttm = lastUpdateDttm;
	}

	/**
	 * Method 'getAuditId'
	 * 
	 * @return int
	 */
	public int getAuditId()
	{
		return auditId;
	}

	/**
	 * Method 'setAuditId'
	 * 
	 * @param auditId
	 */
	public void setAuditId(int auditId)
	{
		this.auditId = auditId;
		this.auditIdNull = false;
	}

	/**
	 * Method 'setAuditIdNull'
	 * 
	 * @param value
	 */
	public void setAuditIdNull(boolean value)
	{
		this.auditIdNull = value;
	}

	/**
	 * Method 'isAuditIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isAuditIdNull()
	{
		return auditIdNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrMitigations)) {
			return false;
		}
		
		final PrMitigations _cast = (PrMitigations) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (eaiId == null ? _cast.eaiId != eaiId : !eaiId.equals( _cast.eaiId )) {
			return false;
		}
		
		if (symAppName == null ? _cast.symAppName != symAppName : !symAppName.equals( _cast.symAppName )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		if (ni2AppName == null ? _cast.ni2AppName != ni2AppName : !ni2AppName.equals( _cast.ni2AppName )) {
			return false;
		}
		
		if (respMdPin == null ? _cast.respMdPin != respMdPin : !respMdPin.equals( _cast.respMdPin )) {
			return false;
		}
		
		if (respMgrPin == null ? _cast.respMgrPin != respMgrPin : !respMgrPin.equals( _cast.respMgrPin )) {
			return false;
		}
		
		if (item == null ? _cast.item != item : !item.equals( _cast.item )) {
			return false;
		}
		
		if (question == null ? _cast.question != question : !question.equals( _cast.question )) {
			return false;
		}
		
		if (answer == null ? _cast.answer != answer : !answer.equals( _cast.answer )) {
			return false;
		}
		
		if (mitigationStatus == null ? _cast.mitigationStatus != mitigationStatus : !mitigationStatus.equals( _cast.mitigationStatus )) {
			return false;
		}
		
		if (lastUpdateDttm == null ? _cast.lastUpdateDttm != lastUpdateDttm : !lastUpdateDttm.equals( _cast.lastUpdateDttm )) {
			return false;
		}
		
		if (auditId != _cast.auditId) {
			return false;
		}
		
		if (auditIdNull != _cast.auditIdNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (eaiId != null) {
			_hashCode = 29 * _hashCode + eaiId.hashCode();
		}
		
		if (symAppName != null) {
			_hashCode = 29 * _hashCode + symAppName.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		if (ni2AppName != null) {
			_hashCode = 29 * _hashCode + ni2AppName.hashCode();
		}
		
		if (respMdPin != null) {
			_hashCode = 29 * _hashCode + respMdPin.hashCode();
		}
		
		if (respMgrPin != null) {
			_hashCode = 29 * _hashCode + respMgrPin.hashCode();
		}
		
		if (item != null) {
			_hashCode = 29 * _hashCode + item.hashCode();
		}
		
		if (question != null) {
			_hashCode = 29 * _hashCode + question.hashCode();
		}
		
		if (answer != null) {
			_hashCode = 29 * _hashCode + answer.hashCode();
		}
		
		if (mitigationStatus != null) {
			_hashCode = 29 * _hashCode + mitigationStatus.hashCode();
		}
		
		if (lastUpdateDttm != null) {
			_hashCode = 29 * _hashCode + lastUpdateDttm.hashCode();
		}
		
		_hashCode = 29 * _hashCode + auditId;
		_hashCode = 29 * _hashCode + (auditIdNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrMitigationsPk
	 */
	public PrMitigationsPk createPk()
	{
		return new PrMitigationsPk(cy, eaiId, ni2AppId, item);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrMitigations: " );
		ret.append( "cy=" + cy );
		ret.append( ", eaiId=" + eaiId );
		ret.append( ", symAppName=" + symAppName );
		ret.append( ", ni2AppId=" + ni2AppId );
		ret.append( ", ni2AppName=" + ni2AppName );
		ret.append( ", respMdPin=" + respMdPin );
		ret.append( ", respMgrPin=" + respMgrPin );
		ret.append( ", item=" + item );
		ret.append( ", question=" + question );
		ret.append( ", answer=" + answer );
		ret.append( ", mitigationStatus=" + mitigationStatus );
		ret.append( ", lastUpdateDttm=" + lastUpdateDttm );
		ret.append( ", auditId=" + auditId );
		return ret.toString();
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

}
