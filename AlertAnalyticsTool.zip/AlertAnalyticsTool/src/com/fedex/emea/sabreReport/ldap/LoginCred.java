package com.fedex.emea.sabreReport.ldap;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fedex.emea.sabreReport.dao.ReportDao;
import com.fedex.emea.sabreReport.ldap.LDAPAbstractAuthenticator.AuthenticateResult;
import com.fedex.emea.sabreReport.ldap.LDAPUserInfo;
import com.fedex.emea.sabreReport.ldap.LoginAuthenticator;



/**
 * Servlet implementation class LoginCred
 */
@WebServlet()
public class LoginCred extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public LoginCred() {
        super();
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("Inside Login Creds...!!!");
		 
		  response.setContentType("text/html");  
		String userPin=request.getParameter("userPin");  
		String userPassword=request.getParameter("userPassword");  
		String hidden = request.getParameter("inputName");
		
		LDAPUserInfo userInfo;
		LoginAuthenticator loginAuthenticator = new LoginAuthenticator();
		
		 String page="";
		String errorMessage;
		
		try {
			
			AuthenticateResult arr = loginAuthenticator.isUserAuthenticated(userPin,userPassword);
			
		       if(userPassword.length()>0)
				{
		    	   
		    	   
		       if (arr.isAuthenticated()) {
		             userInfo = arr.getUserInfo();          
		             String access1=ReportDao.getRole(userInfo.getUid());
					System.out.println(access1);
		     		
		             //String access1 = "3585744";
		     		
		     		if(access1!=null)
		     		{
		     			System.out.println("userInfo.getUid() :"+userInfo.getUid());
			         	System.out.println("userInfo.getGivenName() :"+userInfo.getGivenName());
			         	System.out.println("userPin :"+userPin);
			         	
			     		if(access1.equalsIgnoreCase("user"))
			     		{
			     			 HttpSession session = request.getSession(false);
					         
					         if(session!=null)
					               session.setAttribute("sessionName", userInfo.getGivenName());
					         		session.setAttribute("UserMail", userInfo.getMail());
					         		session.setAttribute("Sessionid", "User");
					         		session.setAttribute("userPin", userPin);
					            	page = hidden;
			     		
			     		}
			     		if(access1.equalsIgnoreCase("admin"))
			     		{
			     			System.out.println("inside"+access1);
			     			 HttpSession session = request.getSession(false);
					         
					         if(session!=null)
					               session.setAttribute("sessionName", userInfo.getGivenName()+" ("+userInfo.getUid()+" )");
					         		session.setAttribute("UserMail", userInfo.getMail());
					         		session.setAttribute("Userid", userInfo.getGivenName());
					         		session.setAttribute("Sessionid", "Admin");
					         		session.setAttribute("userPin", userPin);
					            	page = "reportType.jsp";
			     		}
		     		}	
		     		else{
		     			 request.setAttribute("errorMessage", "Not authorized to visit this site");
		                 page = "Login.jsp";
		     		}

		       }
		       else {
		             if (arr.getErrorDesc().indexOf("error code 32") > 0) {
		                    errorMessage = "error.authentication";
		                    request.setAttribute("errorMessage", "Invalid username or password");
		                    page = "Login.jsp";
		             } else if (arr.getErrorDesc().indexOf("error code 49") > 0) {
		                    errorMessage = "error.passwordproblem";
		                    request.setAttribute("errorMessage", "Invalid username or password");
		                    page = "Login.jsp";
		             } else {
		                    errorMessage = "error.ldapissue";
		                    request.setAttribute("errorMessage", "Invalid username or password");
		                    page = "Login.jsp";
		             		}
		             System.out.println("errorMessage :"+errorMessage);
		       		}
				}
		       else
		       {
		    	   request.setAttribute("errorMessage", "Invalid username or password");
	               page = "Login.jsp";
		       }
		      
		}
		  catch (Exception e) {
			hidden="Exception.jsp";
		}
		RequestDispatcher dd=request.getRequestDispatcher(page);
		dd.forward(request, response);
	}
}
