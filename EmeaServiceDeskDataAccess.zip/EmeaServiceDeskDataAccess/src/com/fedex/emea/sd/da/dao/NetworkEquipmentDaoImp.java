package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.AppsOnServerRowMapper;
import com.fedex.emea.sd.da.mappers.NetworkEquipmentSecondRowMapper;
import com.fedex.emea.sd.da.objects.AppsOnServer;
import com.fedex.emea.sd.da.objects.NetworkEquipments;

public class NetworkEquipmentDaoImp implements NetworkEquipmentDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public NetworkEquipments createValueObject() {
		return new NetworkEquipments();
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<AppsOnServer> getApplicationsOnServer(String serverName) throws SQLException {
		
		String sql = "select APP.NAME AppName, APP.DESCRIPTION AppDesc, APP.BUSINESS_CRITICALITY AppBc, APP.STATUS AppStatus, " +
	                 "       APP.LOCATION_NAME AppLocation, APP.VENDOR AppRespMgr, APP.CUSTOM_1 AppRole, " +
				     "       SRVTYPE.DESCRIPTION AppEnviron, " +
	                 "       NE.NAME SrvName, NE.LOCAL_DOMAIN_NAME SrvDc, " +
				     "       NETYP.TYPE SrvType, NETYP.DESCRIPTION SrvTypeDesc, NE.STATUS SrvStatus, " +
                     "       NE.OPERATING_SYSTEM SrvOs, NE.SOFTWARE_REVISION SrvSoftRev, NE.SOFTWARE_VERSION SrvSoftVer " +
				     "from FIT_SCHEMA.APPLICATION APP " +
                     "  left join FIT_SCHEMA.RELATEDTOASSOCIATION RTA " +
				     "    on RTA.ITEM_Z_KEY_TYPE = 'com.ni2.core.ApplicationValue' and RTA.ITEM_Z_KEY_PK = APP.ID " +
                     "       and RTA.ITEM_A_KEY_TYPE = 'com.ni2.core.ServiceValue' " + 
                     "  left join FIT_SCHEMA.SERVICE SRV " +
                     "    on SRV.ID = RTA.ITEM_A_KEY_PK and SRV.DEFINING_TYPE_KEY_TYPE = 'com.ni2.core.ServiceTypeValue' " +
                     "  left join FIT_SCHEMA.SERVICETYPE SRVTYPE " +
                     "    on SRVTYPE.ID = SRV.DEFINING_TYPE_KEY_PK " +
                     "  left join FIT_SCHEMA.RELATEDTOASSOCIATION RTA2 " +
                     "    on RTA2.ITEM_Z_KEY_TYPE = 'com.ni2.core.ServiceValue' and RTA2.ITEM_Z_KEY_PK = SRV.ID " +
                     "       and RTA2.ITEM_A_KEY_TYPE = 'com.ni2.core.NetworkEquipmentValue' " +
                     "  left join FIT_SCHEMA.NETWORKEQUIPMENT NE " +
                     "    on NE.ID = RTA2.ITEM_A_KEY_PK and NE.DEFINING_TYPE_KEY_TYPE = 'com.ni2.core.NetworkEquipmentTypeValue' " +
                     "  left join FIT_SCHEMA.NETWORKEQUIPMENTTYPE NETYP " +
                     "    on NETYP.ID = NE.DEFINING_TYPE_KEY_PK " +
                     "where upper(NE.NAME) like ? " +
                     "order by APP.NAME";
		return jdbcTemplate.query(sql, new Object[] {serverName}, new AppsOnServerRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<NetworkEquipments> getActiveServerDetails(String serverName) throws SQLException {
		String sql = "select NE.NAME ServerName, NE.OPERATING_SYSTEM OperatingSystem, " +
	                 "  NE.SOFTWARE_VERSION OperatingSystemVersion, NE.STATUS ServerStatus, " +
	                 "  NE.SOFTWARE_REVISION OperatingSystemRevision, " +
				     "  NE.HOSTNAME AppHosted, NE.CUSTOM_11 ServerFunction " +
	                 "from FIT_SCHEMA.NETWORKEQUIPMENT NE " +
				     "  inner join FIT_SCHEMA.NETWORKEQUIPMENTTYPE NET on NE.DEFINING_TYPE_KEY_PK = NET.ID and upper(NET.TYPE) in ('SERVER', 'VIRTUALSERVER') " +
	                 "where upper(NE.NAME) like ? and NE.STATUS <> 'Retired'";
		
		return jdbcTemplate.query(sql, new Object[] {serverName}, new NetworkEquipmentSecondRowMapper());
	}
}
