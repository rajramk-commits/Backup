package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowProblemMetrics implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowMdActive;
	private String snowMdDescription;
	private String snowMdField;
	private String snowMdName;
	private String snowMdNumber;
	private String snowMdOrder;
	private String snowMdSysClassName;
	private String snowMdSysCreatedBy;
	private String snowMdSysCreatedOn;
	private String snowMdSysCustomerUpdate;
	private String snowMdSysId;
	private String snowMdSysModCount;
	private String snowMdSysName;
	private String snowMdSysPackage;
	private String snowMdSysPolicy;
	private String snowMdSysReplaceOnUpgrade;
	private String snowMdSysTags;
	private String snowMdSysUpdateName;
	private String snowMdSysUpdatedBy;
	private String snowMdSysUpdatedOn;
	private String snowMdTable;
	private String snowMdTimeline;
	private String snowMdType;
	private String snowMiBusinessDuration;
	private String snowMiCalculationComplete;
	private String snowMiDefinition;
	private String snowMiDuration;
	private String snowMiEnd;
	private String snowMiField;
	private String snowMiFieldValue;
	private String snowMiId;
	private String snowMiStart;
	private String snowMiSysCreatedBy;
	private String snowMiSysCreatedOn;
	private String snowMiSysId;
	private String snowMiSysModCount;
	private String snowMiSysUpdatedBy;
	private String snowMiSysUpdatedOn;
	private String snowMiTable;
	private String snowMiValue;
	private String snowPrbActive;
	private String snowPrbActivityDue;
	private String snowPrbAdditionalAssigneeList;
	private String snowPrbApproval;
	private String snowPrbApprovalHistory;
	private String snowPrbApprovalSet;
	private String snowPrbAssignedTo;
	private String snowPrbAssignmentGroup;
	private String snowPrbBusinessDuration;
	private String snowPrbBusinessService;
	private String snowPrbCalendarDuration;
	private String snowPrbCallerId;
	private String snowPrbCategory;
	private String snowPrbCloseCode;
	private String snowPrbCloseNotes;
	private String snowPrbClosedAt;
	private String snowPrbClosedBy;
	private String snowPrbCmdbCi;
	private String snowPrbComments;
	private String snowPrbCompany;
	private String snowPrbContactType;
	private String snowPrbContract;
	private String snowPrbCorrelationDisplay;
	private String snowPrbCorrelationId;
	private String snowPrbDeliveryPlan;
	private String snowPrbDescription;
	private String snowPrbDueDate;
	private String snowPrbEffort;
	private String snowPrbEndDate;
	private String snowPrbEscalation;
	private String snowPrbExpectedStart;
	private String snowPrbFollowUp;
	private String snowPrbGroupList;
	private String snowPrbImpact;
	private String snowPrbKnowledge;
	private String snowPrbLocation;
	private String snowPrbMadeSla;
	private String snowPrbNotify;
	private String snowPrbNumber;
	private String snowPrbOpenedAt;
	private String snowPrbOpenedBy;
	private String snowPrbOrder;
	private String snowPrbParent;
	private String snowPrbPriority;
	private String snowPrbReassignmentCount;
	private String snowPrbRfc;
	private String snowPrbShortDescription;
	private String snowPrbSkills;
	private String snowPrbSlaDue;
	private String snowPrbStartDate;
	private String snowPrbState;
	private String snowPrbStatus;
	private String snowPrbSubcategory;
	private String snowPrbSysClassName;
	private String snowPrbSysCreatedBy;
	private String snowPrbSysCreatedOn;
	private String snowPrbSysDomain;
	private String snowPrbSysId;
	private String snowPrbSysModCount;
	private String snowPrbSysTags;
	private String snowPrbSysUpdatedBy;
	private String snowPrbSysUpdatedOn;
	private String snowPrbTimeWorked;
	private String snowPrbU_1StLine;
	private String snowPrbU_2NdLine;
	private String snowPrbU_3RdLineSrt;
	private String snowPrbU_AcceptTime;
	private String snowPrbU_AcknowldgeFeedback;
	private String snowPrbU_Acknowledged;
	private String snowPrbU_ActiveProbInc;
	private String snowPrbU_ActualEffort;
	private String snowPrbU_ActualFinish;
	private String snowPrbU_ActualFixDate;
	private String snowPrbU_ActualImpDate;
	private String snowPrbU_ActualImpFinish;
	private String snowPrbU_ActualStart;
	private String snowPrbU_AffectedAsset;
	private String snowPrbU_AffectedUser;
	private String snowPrbU_AgreedFixImplementationDa;
	private String snowPrbU_AgreementOnPriority;
	private String snowPrbU_AgreementOnProposedFixAn;
	private String snowPrbU_AgreementOnWorkaround;
	private String snowPrbU_AofDateTime;
	private String snowPrbU_AofState;
	private String snowPrbU_AofWorkgroup;
	private String snowPrbU_AosDateTime;
	private String snowPrbU_AosState;
	private String snowPrbU_AosWorkgroup;
	private String snowPrbU_AssetCode;
	private String snowPrbU_AssetString;
	private String snowPrbU_AssignedToBladelogic;
	private String snowPrbU_AssignmentStatus;
	private String snowPrbU_AttachmentsAdded;
	private String snowPrbU_AuditCode;
	private String snowPrbU_AutoClose;
	private String snowPrbU_AutoCloseTicket;
	private String snowPrbU_AutoParm1;
	private String snowPrbU_AutoParm2;
	private String snowPrbU_AutoParm3;
	private String snowPrbU_AutoParm4;
	private String snowPrbU_AutoParm5;
	private String snowPrbU_AutoTarget;
	private String snowPrbU_AutoType;
	private String snowPrbU_AvailAddComments;
	private String snowPrbU_AvailTechSvc;
	private String snowPrbU_AvailabilityReport;
	private String snowPrbU_BriefSummary;
	private String snowPrbU_BsdResolutionBy;
	private String snowPrbU_BusinessImpact;
	private String snowPrbU_BusinessService;
	private String snowPrbU_CallCaptureComments;
	private String snowPrbU_CallHandlingComments;
	private String snowPrbU_Category;
	private String snowPrbU_CauseItem;
	private String snowPrbU_CausedBy;
	private String snowPrbU_ChangeManager;
	private String snowPrbU_CiClassification;
	private String snowPrbU_CiSubclassification;
	private String snowPrbU_Classification;
	private String snowPrbU_ClosedPeriod;
	private String snowPrbU_ClosureCategory;
	private String snowPrbU_CommentType;
	private String snowPrbU_CommentTypeHandling;
	private String snowPrbU_CommentsAndWorkNotes;
	private String snowPrbU_CopyComments;
	private String snowPrbU_CopySubject;
	private String snowPrbU_CountTasks;
	private String snowPrbU_CreateKnownError;
	private String snowPrbU_CsrJiraRef;
	private String snowPrbU_DateAgreedOnPriority;
	private String snowPrbU_DateAgreedOnProposedFix;
	private String snowPrbU_DateAgreedOnWorkaround;
	private String snowPrbU_DatePutIntoDevelopment;
	private String snowPrbU_Deadline;
	private String snowPrbU_DeployEndDate;
	private String snowPrbU_DeployStartDate;
	private String snowPrbU_DeploymentPlan;
	private String snowPrbU_DesktopAssetNumber;
	private String snowPrbU_DesktopMake;
	private String snowPrbU_DesktopModel;
	private String snowPrbU_DesktopSN;
	private String snowPrbU_DevEndDate;
	private String snowPrbU_DevStartDate;
	private String snowPrbU_Dormant;
	private String snowPrbU_ErrorCodeMessage;
	private String snowPrbU_Escalated;
	private String snowPrbU_Exception;
	private String snowPrbU_ExpertHelp;
	private String snowPrbU_ExternalRef;
	private String snowPrbU_FeedbackCode;
	private String snowPrbU_FeedbackCodeHandling;
	private String snowPrbU_FirstDeadline;
	private String snowPrbU_FixOptions;
	private String snowPrbU_FixedOnTime;
	private String snowPrbU_Folder;
	private String snowPrbU_Frequency;
	private String snowPrbU_HpException;
	private String snowPrbU_IcsImpact;
	private String snowPrbU_ImpBreakdown;
	private String snowPrbU_ImplementationEta;
	private String snowPrbU_InfosysException;
	private String snowPrbU_InitialAssignment;
	private String snowPrbU_Instructions;
	private String snowPrbU_InternalRef;
	private String snowPrbU_ItilWatchList;
	private String snowPrbU_KnowledgeArticle;
	private String snowPrbU_KnowledgeAvailable;
	private String snowPrbU_KnowledgeCode;
	private String snowPrbU_KnowledgeComments;
	private String snowPrbU_KnowledgeFound;
	private String snowPrbU_KnowledgeUser;
	private String snowPrbU_KnownError;
	private String snowPrbU_KnownErrorDatabaseUrl;
	private String snowPrbU_KnownErrorLocation;
	private String snowPrbU_KnownErrorUrl;
	private String snowPrbU_LastOccurrence;
	private String snowPrbU_LateImpReason;
	private String snowPrbU_LocalResp;
	private String snowPrbU_ManagementAuditComments;
	private String snowPrbU_ManagementComments;
	private String snowPrbU_MissingCi;
	private String snowPrbU_MissingCiFlag;
	private String snowPrbU_ModifiedPeriod;
	private String snowPrbU_MonitorReviewDate;
	private String snowPrbU_Name;
	private String snowPrbU_Occurrence;
	private String snowPrbU_OpenedPeriod;
	private String snowPrbU_OutageDuration;
	private String snowPrbU_OutsourceAssignedOut;
	private String snowPrbU_OutsourceAssignee;
	private String snowPrbU_OutsourceId;
	private String snowPrbU_OutsourceIntegration;
	private String snowPrbU_OutsourceModule;
	private String snowPrbU_OutsourceResponse;
	private String snowPrbU_OutsourceResult;
	private String snowPrbU_OutsourceStatus;
	private String snowPrbU_OutsourceTeam;
	private String snowPrbU_Override1;
	private String snowPrbU_Person;
	private String snowPrbU_PersonAudited;
	private String snowPrbU_PersonAuditing;
	private String snowPrbU_Phone;
	private String snowPrbU_PickupDuration;
	private String snowPrbU_PlannedEffort;
	private String snowPrbU_PlannedImplementationWeek;
	private String snowPrbU_PmVerify;
	private String snowPrbU_PmWorkgroup;
	private String snowPrbU_PmWritable;
	private String snowPrbU_PreviousGroup;
	private String snowPrbU_PreviousStatus;
	private String snowPrbU_PriorityAmendmentExplanati;
	private String snowPrbU_ProblemBoardRecommendation;
	private String snowPrbU_ProblemClosed;
	private String snowPrbU_ProblemImpact;
	private String snowPrbU_ProblemLite;
	private String snowPrbU_ProblemManager;
	private String snowPrbU_ProblemOwnerComments;
	private String snowPrbU_ProgReviewDate;
	private String snowPrbU_ProposedSolution;
	private String snowPrbU_QueryCount;
	private String snowPrbU_RcaInProgressTime;
	private String snowPrbU_RcaState;
	private String snowPrbU_ReasonForException;
	private String snowPrbU_RegionImpacted;
	private String snowPrbU_RelatedIncidents;
	private String snowPrbU_ReopenCount;
	private String snowPrbU_ReopenedDate;
	private String snowPrbU_Resolution;
	private String snowPrbU_ResolutionOverride;
	private String snowPrbU_ResolvedAt;
	private String snowPrbU_ResolvedBy;
	private String snowPrbU_ResolvedByWorkgroup;
	private String snowPrbU_Resolver;
	private String snowPrbU_ResponseFlag;
	private String snowPrbU_ResponseOverride;
	private String snowPrbU_RootCause;
	private String snowPrbU_SaveAsDraft;
	private String snowPrbU_SavedCount;
	private String snowPrbU_Scope;
	private String snowPrbU_SecondDeadline;
	private String snowPrbU_SelectApplication;
	private String snowPrbU_SelectEuc;
	private String snowPrbU_SelectInfrastructure;
	private String snowPrbU_SelectNetwork;
	private String snowPrbU_ServerName;
	private String snowPrbU_SlaFailureWorkgroup;
	private String snowPrbU_SlaState;
	private String snowPrbU_SlfApprover;
	private String snowPrbU_SlfComponent;
	private String snowPrbU_SlfReason;
	private String snowPrbU_SlfReviewDate;
	private String snowPrbU_SolutionApprovedBy;
	private String snowPrbU_SrtState;
	private String snowPrbU_SspForm;
	private String snowPrbU_Subcategory;
	private String snowPrbU_Subclassification;
	private String snowPrbU_Subject;
	private String snowPrbU_SupportStructure;
	private String snowPrbU_Symptoms;
	private String snowPrbU_TargetFixDate;
	private String snowPrbU_TaskType;
	private String snowPrbU_Template;
	private String snowPrbU_ThirdLineComments;
	private String snowPrbU_ThirdLineDate;
	private String snowPrbU_ThirdPartyReference;
	private String snowPrbU_TimeToAuth;
	private String snowPrbU_TimeToClose;
	private String snowPrbU_UsersAffected;
	private String snowPrbU_VerizonException;
	private String snowPrbU_WebUpdate;
	private String snowPrbU_Workaround;
	private String snowPrbU_WorkaroundSummary;
	private String snowPrbUponApproval;
	private String snowPrbUponReject;
	private String snowPrbUrgency;
	private String snowPrbUserInput;
	private String snowPrbWatchList;
	private String snowPrbWfActivity;
	private String snowPrbWorkAround;
	private String snowPrbWorkEffort;
	private String snowPrbWorkEnd;
	private String snowPrbWorkNotes;
	private String snowPrbWorkStart;
	
	public SnowProblemMetrics() {
	}
	
	public SnowProblemMetrics(HashMap<String, Object> jsonValues) {
		snowMdActive = SnowUtilities.getStringValueFromObject(jsonValues.get("md_active"));
		snowMdDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("md_description"));
		snowMdField = SnowUtilities.getStringValueFromObject(jsonValues.get("md_field"));
		snowMdName = SnowUtilities.getStringValueFromObject(jsonValues.get("md_name"));
		snowMdNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("md_number"));
		snowMdOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("md_order"));
		snowMdSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_class_name"));
		snowMdSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_created_by"));
		snowMdSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_created_on"));
		snowMdSysCustomerUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_customer_update"));
		snowMdSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_id"));
		snowMdSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_mod_count"));
		snowMdSysName = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_name"));
		snowMdSysPackage = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_package"));
		snowMdSysPolicy = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_policy"));
		snowMdSysReplaceOnUpgrade = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_replace_on_upgrade"));
		snowMdSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_tags"));
		snowMdSysUpdateName = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_update_name"));
		snowMdSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_updated_by"));
		snowMdSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("md_sys_updated_on"));
		snowMdTable = SnowUtilities.getStringValueFromObject(jsonValues.get("md_table"));
		snowMdTimeline = SnowUtilities.getStringValueFromObject(jsonValues.get("md_timeline"));
		snowMdType = SnowUtilities.getStringValueFromObject(jsonValues.get("md_type"));
		snowMiBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_business_duration"));
		snowMiCalculationComplete = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_calculation_complete"));
		snowMiDefinition = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_definition"));
		snowMiDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_duration"));
		snowMiEnd = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_end"));
		snowMiField = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_field"));
		snowMiFieldValue = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_field_value"));
		snowMiId = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_id"));
		snowMiStart = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_start"));
		snowMiSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_created_by"));
		snowMiSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_created_on"));
		snowMiSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_id"));
		snowMiSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_mod_count"));
		snowMiSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_updated_by"));
		snowMiSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_sys_updated_on"));
		snowMiTable = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_table"));
		snowMiValue = SnowUtilities.getStringValueFromObject(jsonValues.get("mi_value"));
		snowPrbActive = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_active"));
		snowPrbActivityDue = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_activity_due"));
		snowPrbAdditionalAssigneeList = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_additional_assignee_list"));
		snowPrbApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_approval"));
		snowPrbApprovalHistory = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_approval_history"));
		snowPrbApprovalSet = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_approval_set"));
		snowPrbAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_assigned_to"));
		snowPrbAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_assignment_group"));
		snowPrbBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_business_duration"));
		snowPrbBusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_business_service"));
		snowPrbCalendarDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_calendar_duration"));
		snowPrbCallerId = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_caller_id"));
		snowPrbCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_category"));
		snowPrbCloseCode = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_close_code"));
		snowPrbCloseNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_close_notes"));
		snowPrbClosedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_closed_at"));
		snowPrbClosedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_closed_by"));
		snowPrbCmdbCi = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_cmdb_ci"));
		snowPrbComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_comments"));
		snowPrbCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_company"));
		snowPrbContactType = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_contact_type"));
		snowPrbContract = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_contract"));
		snowPrbCorrelationDisplay = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_correlation_display"));
		snowPrbCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_correlation_id"));
		snowPrbDeliveryPlan = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_delivery_plan"));
		snowPrbDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_description"));
		snowPrbDueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_due_date"));
		snowPrbEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_effort"));
		snowPrbEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_end_date"));
		snowPrbEscalation = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_escalation"));
		snowPrbExpectedStart = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_expected_start"));
		snowPrbFollowUp = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_follow_up"));
		snowPrbGroupList = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_group_list"));
		snowPrbImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_impact"));
		snowPrbKnowledge = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_knowledge"));
		snowPrbLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_location"));
		snowPrbMadeSla = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_made_sla"));
		snowPrbNotify = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_notify"));
		snowPrbNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_number"));
		snowPrbOpenedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_opened_at"));
		snowPrbOpenedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_opened_by"));
		snowPrbOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_order"));
		snowPrbParent = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_parent"));
		snowPrbPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_priority"));
		snowPrbReassignmentCount = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_reassignment_count"));
		snowPrbRfc = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_rfc"));
		snowPrbShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_short_description"));
		snowPrbSkills = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_skills"));
		snowPrbSlaDue = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sla_due"));
		snowPrbStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_start_date"));
		snowPrbState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_state"));
		snowPrbStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_status"));
		snowPrbSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_subcategory"));
		snowPrbSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_class_name"));
		snowPrbSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_created_by"));
		snowPrbSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_created_on"));
		snowPrbSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_domain"));
		snowPrbSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_id"));
		snowPrbSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_mod_count"));
		snowPrbSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_tags"));
		snowPrbSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_updated_by"));
		snowPrbSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_sys_updated_on"));
		snowPrbTimeWorked = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_time_worked"));
		snowPrbU_1StLine = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_1st_line"));
		snowPrbU_2NdLine = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_2nd_line"));
		snowPrbU_3RdLineSrt = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_3rd_line_srt"));
		snowPrbU_AcceptTime = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_accept_time"));
		snowPrbU_AcknowldgeFeedback = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_acknowldge_feedback"));
		snowPrbU_Acknowledged = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_acknowledged"));
		snowPrbU_ActiveProbInc = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_active_prob_inc"));
		snowPrbU_ActualEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_effort"));
		snowPrbU_ActualFinish = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_finish"));
		snowPrbU_ActualFixDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_fix_date"));
		snowPrbU_ActualImpDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_imp_date"));
		snowPrbU_ActualImpFinish = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_imp_finish"));
		snowPrbU_ActualStart = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_actual_start"));
		snowPrbU_AffectedAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_affected_asset"));
		snowPrbU_AffectedUser = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_affected_user"));
		snowPrbU_AgreedFixImplementationDa = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_agreed_fix_implementation_da"));
		snowPrbU_AgreementOnPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_agreement_on_priority"));
		snowPrbU_AgreementOnProposedFixAn = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_agreement_on_proposed_fix_an"));
		snowPrbU_AgreementOnWorkaround = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_agreement_on_workaround"));
		snowPrbU_AofDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aof_date__time"));
		snowPrbU_AofState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aof_state"));
		snowPrbU_AofWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aof_workgroup"));
		snowPrbU_AosDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aos_date__time"));
		snowPrbU_AosState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aos_state"));
		snowPrbU_AosWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_aos_workgroup"));
		snowPrbU_AssetCode = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_asset_code"));
		snowPrbU_AssetString = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_asset_string"));
		snowPrbU_AssignedToBladelogic = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_assigned_to_bladelogic"));
		snowPrbU_AssignmentStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_assignment_status"));
		snowPrbU_AttachmentsAdded = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_attachments_added"));
		snowPrbU_AuditCode = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_audit__code"));
		snowPrbU_AutoClose = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_close"));
		snowPrbU_AutoCloseTicket = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_close_ticket"));
		snowPrbU_AutoParm1 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_parm1"));
		snowPrbU_AutoParm2 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_parm2"));
		snowPrbU_AutoParm3 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_parm3"));
		snowPrbU_AutoParm4 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_parm4"));
		snowPrbU_AutoParm5 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_parm5"));
		snowPrbU_AutoTarget = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_target"));
		snowPrbU_AutoType = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_auto_type"));
		snowPrbU_AvailAddComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_avail_add_comments"));
		snowPrbU_AvailTechSvc = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_avail_tech_svc"));
		snowPrbU_AvailabilityReport = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_availability_report"));
		snowPrbU_BriefSummary = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_brief_summary"));
		snowPrbU_BsdResolutionBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_bsd_resolution_by"));
		snowPrbU_BusinessImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_business_impact"));
		snowPrbU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_business_service"));
		snowPrbU_CallCaptureComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_call_capture_comments"));
		snowPrbU_CallHandlingComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_call_handling_comments"));
		snowPrbU_Category = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_category"));
		snowPrbU_CauseItem = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_cause_item"));
		snowPrbU_CausedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_caused_by"));
		snowPrbU_ChangeManager = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_change_manager"));
		snowPrbU_CiClassification = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_ci_classification"));
		snowPrbU_CiSubclassification = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_ci_subclassification"));
		snowPrbU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_classification"));
		snowPrbU_ClosedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_closed_period"));
		snowPrbU_ClosureCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_closure_category"));
		snowPrbU_CommentType = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_comment_type"));
		snowPrbU_CommentTypeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_comment_type_handling"));
		snowPrbU_CommentsAndWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_comments_and_work_notes"));
		snowPrbU_CopyComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_copy_comments"));
		snowPrbU_CopySubject = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_copy_subject"));
		snowPrbU_CountTasks = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_count_tasks"));
		snowPrbU_CreateKnownError = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_create_known_error"));
		snowPrbU_CsrJiraRef = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_csr__jira_ref_"));
		snowPrbU_DateAgreedOnPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_date_agreed_on_priority"));
		snowPrbU_DateAgreedOnProposedFix = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_date_agreed_on_proposed_fix"));
		snowPrbU_DateAgreedOnWorkaround = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_date_agreed_on_workaround"));
		snowPrbU_DatePutIntoDevelopment = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_date_put_into_development"));
		snowPrbU_Deadline = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_deadline"));
		snowPrbU_DeployEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_deploy_end_date"));
		snowPrbU_DeployStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_deploy_start_date"));
		snowPrbU_DeploymentPlan = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_deployment_plan"));
		snowPrbU_DesktopAssetNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_desktop_asset_number"));
		snowPrbU_DesktopMake = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_desktop_make"));
		snowPrbU_DesktopModel = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_desktop_model"));
		snowPrbU_DesktopSN = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_desktop_s_n"));
		snowPrbU_DevEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_dev_end_date"));
		snowPrbU_DevStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_dev_start_date"));
		snowPrbU_Dormant = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_dormant"));
		snowPrbU_ErrorCodeMessage = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_error_code_message"));
		snowPrbU_Escalated = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_escalated"));
		snowPrbU_Exception = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_exception"));
		snowPrbU_ExpertHelp = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_expert_help"));
		snowPrbU_ExternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_external_ref"));
		snowPrbU_FeedbackCode = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_feedback_code"));
		snowPrbU_FeedbackCodeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_feedback_code_handling"));
		snowPrbU_FirstDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_first_deadline"));
		snowPrbU_FixOptions = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_fix_options"));
		snowPrbU_FixedOnTime = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_fixed_on_time"));
		snowPrbU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_folder"));
		snowPrbU_Frequency = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_frequency"));
		snowPrbU_HpException = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_hp_exception"));
		snowPrbU_IcsImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_ics_impact"));
		snowPrbU_ImpBreakdown = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_imp_breakdown"));
		snowPrbU_ImplementationEta = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_implementation_eta"));
		snowPrbU_InfosysException = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_infosys_exception"));
		snowPrbU_InitialAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_initial_assignment"));
		snowPrbU_Instructions = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_instructions"));
		snowPrbU_InternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_internal_ref"));
		snowPrbU_ItilWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_itil_watch_list"));
		snowPrbU_KnowledgeArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_article"));
		snowPrbU_KnowledgeAvailable = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_available"));
		snowPrbU_KnowledgeCode = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_code"));
		snowPrbU_KnowledgeComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_comments"));
		snowPrbU_KnowledgeFound = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_found"));
		snowPrbU_KnowledgeUser = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_knowledge_user"));
		snowPrbU_KnownError = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_known_error"));
		snowPrbU_KnownErrorDatabaseUrl = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_known_error_database_url"));
		snowPrbU_KnownErrorLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_known_error_location"));
		snowPrbU_KnownErrorUrl = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_known_error_url"));
		snowPrbU_LastOccurrence = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_last_occurrence"));
		snowPrbU_LateImpReason = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_late_imp_reason"));
		snowPrbU_LocalResp = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_local_resp"));
		snowPrbU_ManagementAuditComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_management_audit_comments"));
		snowPrbU_ManagementComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_management_comments"));
		snowPrbU_MissingCi = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_missing_ci"));
		snowPrbU_MissingCiFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_missing_ci_flag"));
		snowPrbU_ModifiedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_modified_period"));
		snowPrbU_MonitorReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_monitor_review_date"));
		snowPrbU_Name = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_name"));
		snowPrbU_Occurrence = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_occurrence"));
		snowPrbU_OpenedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_opened_period"));
		snowPrbU_OutageDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outage_duration"));
		snowPrbU_OutsourceAssignedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_assigned_out"));
		snowPrbU_OutsourceAssignee = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_assignee"));
		snowPrbU_OutsourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_id"));
		snowPrbU_OutsourceIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_integration"));
		snowPrbU_OutsourceModule = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_module"));
		snowPrbU_OutsourceResponse = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_response"));
		snowPrbU_OutsourceResult = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_result"));
		snowPrbU_OutsourceStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_status"));
		snowPrbU_OutsourceTeam = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_outsource_team"));
		snowPrbU_Override1 = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_override1"));
		snowPrbU_Person = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_person"));
		snowPrbU_PersonAudited = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_person_audited"));
		snowPrbU_PersonAuditing = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_person_auditing"));
		snowPrbU_Phone = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_phone"));
		snowPrbU_PickupDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_pickup_duration"));
		snowPrbU_PlannedEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_planned_effort"));
		snowPrbU_PlannedImplementationWeek = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_planned_implementation_week"));
		snowPrbU_PmVerify = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_pm_verify"));
		snowPrbU_PmWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_pm_workgroup"));
		snowPrbU_PmWritable = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_pm_writable"));
		snowPrbU_PreviousGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_previous_group"));
		snowPrbU_PreviousStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_previous_status"));
		snowPrbU_PriorityAmendmentExplanati = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_priority_amendment_explanati"));
		snowPrbU_ProblemBoardRecommendation = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_board_recommendation"));
		snowPrbU_ProblemClosed = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_closed"));
		snowPrbU_ProblemImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_impact"));
		snowPrbU_ProblemLite = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_lite"));
		snowPrbU_ProblemManager = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_manager"));
		snowPrbU_ProblemOwnerComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_problem_owner_comments"));
		snowPrbU_ProgReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_prog_review_date"));
		snowPrbU_ProposedSolution = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_proposed_solution"));
		snowPrbU_QueryCount = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_query_count"));
		snowPrbU_RcaInProgressTime = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_rca_in_progress_time"));
		snowPrbU_RcaState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_rca_state"));
		snowPrbU_ReasonForException = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_reason_for_exception"));
		snowPrbU_RegionImpacted = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_region_impacted"));
		snowPrbU_RelatedIncidents = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_related_incidents"));
		snowPrbU_ReopenCount = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_reopen_count"));
		snowPrbU_ReopenedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_reopened_date"));
		snowPrbU_Resolution = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolution"));
		snowPrbU_ResolutionOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolution_override"));
		snowPrbU_ResolvedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolved_at"));
		snowPrbU_ResolvedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolved_by"));
		snowPrbU_ResolvedByWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolved_by_workgroup"));
		snowPrbU_Resolver = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_resolver"));
		snowPrbU_ResponseFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_response_flag"));
		snowPrbU_ResponseOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_response_override"));
		snowPrbU_RootCause = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_root_cause"));
		snowPrbU_SaveAsDraft = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_save_as_draft"));
		snowPrbU_SavedCount = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_saved_count"));
		snowPrbU_Scope = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_scope"));
		snowPrbU_SecondDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_second_deadline"));
		snowPrbU_SelectApplication = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_select_application"));
		snowPrbU_SelectEuc = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_select_euc"));
		snowPrbU_SelectInfrastructure = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_select_infrastructure"));
		snowPrbU_SelectNetwork = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_select_network"));
		snowPrbU_ServerName = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_server_name"));
		snowPrbU_SlaFailureWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_sla_failure_workgroup"));
		snowPrbU_SlaState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_sla_state"));
		snowPrbU_SlfApprover = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_slf_approver"));
		snowPrbU_SlfComponent = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_slf_component"));
		snowPrbU_SlfReason = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_slf_reason"));
		snowPrbU_SlfReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_slf_review_date"));
		snowPrbU_SolutionApprovedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_solution_approved_by"));
		snowPrbU_SrtState = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_srt_state"));
		snowPrbU_SspForm = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_ssp_form"));
		snowPrbU_Subcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_subcategory"));
		snowPrbU_Subclassification = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_subclassification"));
		snowPrbU_Subject = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_subject"));
		snowPrbU_SupportStructure = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_support_structure"));
		snowPrbU_Symptoms = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_symptoms"));
		snowPrbU_TargetFixDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_target_fix_date"));
		snowPrbU_TaskType = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_task_type"));
		snowPrbU_Template = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_template"));
		snowPrbU_ThirdLineComments = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_third_line_comments"));
		snowPrbU_ThirdLineDate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_third_line_date"));
		snowPrbU_ThirdPartyReference = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_third_party_reference"));
		snowPrbU_TimeToAuth = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_time_to_auth"));
		snowPrbU_TimeToClose = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_time_to_close"));
		snowPrbU_UsersAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_users_affected"));
		snowPrbU_VerizonException = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_verizon_exception"));
		snowPrbU_WebUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_web_update"));
		snowPrbU_Workaround = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_workaround"));
		snowPrbU_WorkaroundSummary = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_u_workaround_summary"));
		snowPrbUponApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_upon_approval"));
		snowPrbUponReject = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_upon_reject"));
		snowPrbUrgency = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_urgency"));
		snowPrbUserInput = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_user_input"));
		snowPrbWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_watch_list"));
		snowPrbWfActivity = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_wf_activity"));
		snowPrbWorkAround = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_work_around"));
		snowPrbWorkEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_work_effort"));
		snowPrbWorkEnd = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_work_end"));
		snowPrbWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_work_notes"));
		snowPrbWorkStart = SnowUtilities.getStringValueFromObject(jsonValues.get("prb_work_start"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowMdActive != null && !snowMdActive.toString().isEmpty()) jsonObject.put("md_active", snowMdActive);
		if (snowMdDescription != null && !snowMdDescription.toString().isEmpty()) jsonObject.put("md_description", snowMdDescription);
		if (snowMdField != null && !snowMdField.toString().isEmpty()) jsonObject.put("md_field", snowMdField);
		if (snowMdName != null && !snowMdName.toString().isEmpty()) jsonObject.put("md_name", snowMdName);
		if (snowMdNumber != null && !snowMdNumber.toString().isEmpty()) jsonObject.put("md_number", snowMdNumber);
		if (snowMdOrder != null && !snowMdOrder.toString().isEmpty()) jsonObject.put("md_order", snowMdOrder);
		if (snowMdSysClassName != null && !snowMdSysClassName.toString().isEmpty()) jsonObject.put("md_sys_class_name", snowMdSysClassName);
		if (snowMdSysCreatedBy != null && !snowMdSysCreatedBy.toString().isEmpty()) jsonObject.put("md_sys_created_by", snowMdSysCreatedBy);
		if (snowMdSysCreatedOn != null && !snowMdSysCreatedOn.toString().isEmpty()) jsonObject.put("md_sys_created_on", snowMdSysCreatedOn);
		if (snowMdSysCustomerUpdate != null && !snowMdSysCustomerUpdate.toString().isEmpty()) jsonObject.put("md_sys_customer_update", snowMdSysCustomerUpdate);
		if (snowMdSysId != null && !snowMdSysId.toString().isEmpty()) jsonObject.put("md_sys_id", snowMdSysId);
		if (snowMdSysModCount != null && !snowMdSysModCount.toString().isEmpty()) jsonObject.put("md_sys_mod_count", snowMdSysModCount);
		if (snowMdSysName != null && !snowMdSysName.toString().isEmpty()) jsonObject.put("md_sys_name", snowMdSysName);
		if (snowMdSysPackage != null && !snowMdSysPackage.toString().isEmpty()) jsonObject.put("md_sys_package", snowMdSysPackage);
		if (snowMdSysPolicy != null && !snowMdSysPolicy.toString().isEmpty()) jsonObject.put("md_sys_policy", snowMdSysPolicy);
		if (snowMdSysReplaceOnUpgrade != null && !snowMdSysReplaceOnUpgrade.toString().isEmpty()) jsonObject.put("md_sys_replace_on_upgrade", snowMdSysReplaceOnUpgrade);
		if (snowMdSysTags != null && !snowMdSysTags.toString().isEmpty()) jsonObject.put("md_sys_tags", snowMdSysTags);
		if (snowMdSysUpdateName != null && !snowMdSysUpdateName.toString().isEmpty()) jsonObject.put("md_sys_update_name", snowMdSysUpdateName);
		if (snowMdSysUpdatedBy != null && !snowMdSysUpdatedBy.toString().isEmpty()) jsonObject.put("md_sys_updated_by", snowMdSysUpdatedBy);
		if (snowMdSysUpdatedOn != null && !snowMdSysUpdatedOn.toString().isEmpty()) jsonObject.put("md_sys_updated_on", snowMdSysUpdatedOn);
		if (snowMdTable != null && !snowMdTable.toString().isEmpty()) jsonObject.put("md_table", snowMdTable);
		if (snowMdTimeline != null && !snowMdTimeline.toString().isEmpty()) jsonObject.put("md_timeline", snowMdTimeline);
		if (snowMdType != null && !snowMdType.toString().isEmpty()) jsonObject.put("md_type", snowMdType);
		if (snowMiBusinessDuration != null && !snowMiBusinessDuration.toString().isEmpty()) jsonObject.put("mi_business_duration", snowMiBusinessDuration);
		if (snowMiCalculationComplete != null && !snowMiCalculationComplete.toString().isEmpty()) jsonObject.put("mi_calculation_complete", snowMiCalculationComplete);
		if (snowMiDefinition != null && !snowMiDefinition.toString().isEmpty()) jsonObject.put("mi_definition", snowMiDefinition);
		if (snowMiDuration != null && !snowMiDuration.toString().isEmpty()) jsonObject.put("mi_duration", snowMiDuration);
		if (snowMiEnd != null && !snowMiEnd.toString().isEmpty()) jsonObject.put("mi_end", snowMiEnd);
		if (snowMiField != null && !snowMiField.toString().isEmpty()) jsonObject.put("mi_field", snowMiField);
		if (snowMiFieldValue != null && !snowMiFieldValue.toString().isEmpty()) jsonObject.put("mi_field_value", snowMiFieldValue);
		if (snowMiId != null && !snowMiId.toString().isEmpty()) jsonObject.put("mi_id", snowMiId);
		if (snowMiStart != null && !snowMiStart.toString().isEmpty()) jsonObject.put("mi_start", snowMiStart);
		if (snowMiSysCreatedBy != null && !snowMiSysCreatedBy.toString().isEmpty()) jsonObject.put("mi_sys_created_by", snowMiSysCreatedBy);
		if (snowMiSysCreatedOn != null && !snowMiSysCreatedOn.toString().isEmpty()) jsonObject.put("mi_sys_created_on", snowMiSysCreatedOn);
		if (snowMiSysId != null && !snowMiSysId.toString().isEmpty()) jsonObject.put("mi_sys_id", snowMiSysId);
		if (snowMiSysModCount != null && !snowMiSysModCount.toString().isEmpty()) jsonObject.put("mi_sys_mod_count", snowMiSysModCount);
		if (snowMiSysUpdatedBy != null && !snowMiSysUpdatedBy.toString().isEmpty()) jsonObject.put("mi_sys_updated_by", snowMiSysUpdatedBy);
		if (snowMiSysUpdatedOn != null && !snowMiSysUpdatedOn.toString().isEmpty()) jsonObject.put("mi_sys_updated_on", snowMiSysUpdatedOn);
		if (snowMiTable != null && !snowMiTable.toString().isEmpty()) jsonObject.put("mi_table", snowMiTable);
		if (snowMiValue != null && !snowMiValue.toString().isEmpty()) jsonObject.put("mi_value", snowMiValue);
		if (snowPrbActive != null && !snowPrbActive.toString().isEmpty()) jsonObject.put("prb_active", snowPrbActive);
		if (snowPrbActivityDue != null && !snowPrbActivityDue.toString().isEmpty()) jsonObject.put("prb_activity_due", snowPrbActivityDue);
		if (snowPrbAdditionalAssigneeList != null && !snowPrbAdditionalAssigneeList.toString().isEmpty()) jsonObject.put("prb_additional_assignee_list", snowPrbAdditionalAssigneeList);
		if (snowPrbApproval != null && !snowPrbApproval.toString().isEmpty()) jsonObject.put("prb_approval", snowPrbApproval);
		if (snowPrbApprovalHistory != null && !snowPrbApprovalHistory.toString().isEmpty()) jsonObject.put("prb_approval_history", snowPrbApprovalHistory);
		if (snowPrbApprovalSet != null && !snowPrbApprovalSet.toString().isEmpty()) jsonObject.put("prb_approval_set", snowPrbApprovalSet);
		if (snowPrbAssignedTo != null && !snowPrbAssignedTo.toString().isEmpty()) jsonObject.put("prb_assigned_to", snowPrbAssignedTo);
		if (snowPrbAssignmentGroup != null && !snowPrbAssignmentGroup.toString().isEmpty()) jsonObject.put("prb_assignment_group", snowPrbAssignmentGroup);
		if (snowPrbBusinessDuration != null && !snowPrbBusinessDuration.toString().isEmpty()) jsonObject.put("prb_business_duration", snowPrbBusinessDuration);
		if (snowPrbBusinessService != null && !snowPrbBusinessService.toString().isEmpty()) jsonObject.put("prb_business_service", snowPrbBusinessService);
		if (snowPrbCalendarDuration != null && !snowPrbCalendarDuration.toString().isEmpty()) jsonObject.put("prb_calendar_duration", snowPrbCalendarDuration);
		if (snowPrbCallerId != null && !snowPrbCallerId.toString().isEmpty()) jsonObject.put("prb_caller_id", snowPrbCallerId);
		if (snowPrbCategory != null && !snowPrbCategory.toString().isEmpty()) jsonObject.put("prb_category", snowPrbCategory);
		if (snowPrbCloseCode != null && !snowPrbCloseCode.toString().isEmpty()) jsonObject.put("prb_close_code", snowPrbCloseCode);
		if (snowPrbCloseNotes != null && !snowPrbCloseNotes.toString().isEmpty()) jsonObject.put("prb_close_notes", snowPrbCloseNotes);
		if (snowPrbClosedAt != null && !snowPrbClosedAt.toString().isEmpty()) jsonObject.put("prb_closed_at", snowPrbClosedAt);
		if (snowPrbClosedBy != null && !snowPrbClosedBy.toString().isEmpty()) jsonObject.put("prb_closed_by", snowPrbClosedBy);
		if (snowPrbCmdbCi != null && !snowPrbCmdbCi.toString().isEmpty()) jsonObject.put("prb_cmdb_ci", snowPrbCmdbCi);
		if (snowPrbComments != null && !snowPrbComments.toString().isEmpty()) jsonObject.put("prb_comments", snowPrbComments);
		if (snowPrbCompany != null && !snowPrbCompany.toString().isEmpty()) jsonObject.put("prb_company", snowPrbCompany);
		if (snowPrbContactType != null && !snowPrbContactType.toString().isEmpty()) jsonObject.put("prb_contact_type", snowPrbContactType);
		if (snowPrbContract != null && !snowPrbContract.toString().isEmpty()) jsonObject.put("prb_contract", snowPrbContract);
		if (snowPrbCorrelationDisplay != null && !snowPrbCorrelationDisplay.toString().isEmpty()) jsonObject.put("prb_correlation_display", snowPrbCorrelationDisplay);
		if (snowPrbCorrelationId != null && !snowPrbCorrelationId.toString().isEmpty()) jsonObject.put("prb_correlation_id", snowPrbCorrelationId);
		if (snowPrbDeliveryPlan != null && !snowPrbDeliveryPlan.toString().isEmpty()) jsonObject.put("prb_delivery_plan", snowPrbDeliveryPlan);
		if (snowPrbDescription != null && !snowPrbDescription.toString().isEmpty()) jsonObject.put("prb_description", snowPrbDescription);
		if (snowPrbDueDate != null && !snowPrbDueDate.toString().isEmpty()) jsonObject.put("prb_due_date", snowPrbDueDate);
		if (snowPrbEffort != null && !snowPrbEffort.toString().isEmpty()) jsonObject.put("prb_effort", snowPrbEffort);
		if (snowPrbEndDate != null && !snowPrbEndDate.toString().isEmpty()) jsonObject.put("prb_end_date", snowPrbEndDate);
		if (snowPrbEscalation != null && !snowPrbEscalation.toString().isEmpty()) jsonObject.put("prb_escalation", snowPrbEscalation);
		if (snowPrbExpectedStart != null && !snowPrbExpectedStart.toString().isEmpty()) jsonObject.put("prb_expected_start", snowPrbExpectedStart);
		if (snowPrbFollowUp != null && !snowPrbFollowUp.toString().isEmpty()) jsonObject.put("prb_follow_up", snowPrbFollowUp);
		if (snowPrbGroupList != null && !snowPrbGroupList.toString().isEmpty()) jsonObject.put("prb_group_list", snowPrbGroupList);
		if (snowPrbImpact != null && !snowPrbImpact.toString().isEmpty()) jsonObject.put("prb_impact", snowPrbImpact);
		if (snowPrbKnowledge != null && !snowPrbKnowledge.toString().isEmpty()) jsonObject.put("prb_knowledge", snowPrbKnowledge);
		if (snowPrbLocation != null && !snowPrbLocation.toString().isEmpty()) jsonObject.put("prb_location", snowPrbLocation);
		if (snowPrbMadeSla != null && !snowPrbMadeSla.toString().isEmpty()) jsonObject.put("prb_made_sla", snowPrbMadeSla);
		if (snowPrbNotify != null && !snowPrbNotify.toString().isEmpty()) jsonObject.put("prb_notify", snowPrbNotify);
		if (snowPrbNumber != null && !snowPrbNumber.toString().isEmpty()) jsonObject.put("prb_number", snowPrbNumber);
		if (snowPrbOpenedAt != null && !snowPrbOpenedAt.toString().isEmpty()) jsonObject.put("prb_opened_at", snowPrbOpenedAt);
		if (snowPrbOpenedBy != null && !snowPrbOpenedBy.toString().isEmpty()) jsonObject.put("prb_opened_by", snowPrbOpenedBy);
		if (snowPrbOrder != null && !snowPrbOrder.toString().isEmpty()) jsonObject.put("prb_order", snowPrbOrder);
		if (snowPrbParent != null && !snowPrbParent.toString().isEmpty()) jsonObject.put("prb_parent", snowPrbParent);
		if (snowPrbPriority != null && !snowPrbPriority.toString().isEmpty()) jsonObject.put("prb_priority", snowPrbPriority);
		if (snowPrbReassignmentCount != null && !snowPrbReassignmentCount.toString().isEmpty()) jsonObject.put("prb_reassignment_count", snowPrbReassignmentCount);
		if (snowPrbRfc != null && !snowPrbRfc.toString().isEmpty()) jsonObject.put("prb_rfc", snowPrbRfc);
		if (snowPrbShortDescription != null && !snowPrbShortDescription.toString().isEmpty()) jsonObject.put("prb_short_description", snowPrbShortDescription);
		if (snowPrbSkills != null && !snowPrbSkills.toString().isEmpty()) jsonObject.put("prb_skills", snowPrbSkills);
		if (snowPrbSlaDue != null && !snowPrbSlaDue.toString().isEmpty()) jsonObject.put("prb_sla_due", snowPrbSlaDue);
		if (snowPrbStartDate != null && !snowPrbStartDate.toString().isEmpty()) jsonObject.put("prb_start_date", snowPrbStartDate);
		if (snowPrbState != null && !snowPrbState.toString().isEmpty()) jsonObject.put("prb_state", snowPrbState);
		if (snowPrbStatus != null && !snowPrbStatus.toString().isEmpty()) jsonObject.put("prb_status", snowPrbStatus);
		if (snowPrbSubcategory != null && !snowPrbSubcategory.toString().isEmpty()) jsonObject.put("prb_subcategory", snowPrbSubcategory);
		if (snowPrbSysClassName != null && !snowPrbSysClassName.toString().isEmpty()) jsonObject.put("prb_sys_class_name", snowPrbSysClassName);
		if (snowPrbSysCreatedBy != null && !snowPrbSysCreatedBy.toString().isEmpty()) jsonObject.put("prb_sys_created_by", snowPrbSysCreatedBy);
		if (snowPrbSysCreatedOn != null && !snowPrbSysCreatedOn.toString().isEmpty()) jsonObject.put("prb_sys_created_on", snowPrbSysCreatedOn);
		if (snowPrbSysDomain != null && !snowPrbSysDomain.toString().isEmpty()) jsonObject.put("prb_sys_domain", snowPrbSysDomain);
		if (snowPrbSysId != null && !snowPrbSysId.toString().isEmpty()) jsonObject.put("prb_sys_id", snowPrbSysId);
		if (snowPrbSysModCount != null && !snowPrbSysModCount.toString().isEmpty()) jsonObject.put("prb_sys_mod_count", snowPrbSysModCount);
		if (snowPrbSysTags != null && !snowPrbSysTags.toString().isEmpty()) jsonObject.put("prb_sys_tags", snowPrbSysTags);
		if (snowPrbSysUpdatedBy != null && !snowPrbSysUpdatedBy.toString().isEmpty()) jsonObject.put("prb_sys_updated_by", snowPrbSysUpdatedBy);
		if (snowPrbSysUpdatedOn != null && !snowPrbSysUpdatedOn.toString().isEmpty()) jsonObject.put("prb_sys_updated_on", snowPrbSysUpdatedOn);
		if (snowPrbTimeWorked != null && !snowPrbTimeWorked.toString().isEmpty()) jsonObject.put("prb_time_worked", snowPrbTimeWorked);
		if (snowPrbU_1StLine != null && !snowPrbU_1StLine.toString().isEmpty()) jsonObject.put("prb_u_1st_line", snowPrbU_1StLine);
		if (snowPrbU_2NdLine != null && !snowPrbU_2NdLine.toString().isEmpty()) jsonObject.put("prb_u_2nd_line", snowPrbU_2NdLine);
		if (snowPrbU_3RdLineSrt != null && !snowPrbU_3RdLineSrt.toString().isEmpty()) jsonObject.put("prb_u_3rd_line_srt", snowPrbU_3RdLineSrt);
		if (snowPrbU_AcceptTime != null && !snowPrbU_AcceptTime.toString().isEmpty()) jsonObject.put("prb_u_accept_time", snowPrbU_AcceptTime);
		if (snowPrbU_AcknowldgeFeedback != null && !snowPrbU_AcknowldgeFeedback.toString().isEmpty()) jsonObject.put("prb_u_acknowldge_feedback", snowPrbU_AcknowldgeFeedback);
		if (snowPrbU_Acknowledged != null && !snowPrbU_Acknowledged.toString().isEmpty()) jsonObject.put("prb_u_acknowledged", snowPrbU_Acknowledged);
		if (snowPrbU_ActiveProbInc != null && !snowPrbU_ActiveProbInc.toString().isEmpty()) jsonObject.put("prb_u_active_prob_inc", snowPrbU_ActiveProbInc);
		if (snowPrbU_ActualEffort != null && !snowPrbU_ActualEffort.toString().isEmpty()) jsonObject.put("prb_u_actual_effort", snowPrbU_ActualEffort);
		if (snowPrbU_ActualFinish != null && !snowPrbU_ActualFinish.toString().isEmpty()) jsonObject.put("prb_u_actual_finish", snowPrbU_ActualFinish);
		if (snowPrbU_ActualFixDate != null && !snowPrbU_ActualFixDate.toString().isEmpty()) jsonObject.put("prb_u_actual_fix_date", snowPrbU_ActualFixDate);
		if (snowPrbU_ActualImpDate != null && !snowPrbU_ActualImpDate.toString().isEmpty()) jsonObject.put("prb_u_actual_imp_date", snowPrbU_ActualImpDate);
		if (snowPrbU_ActualImpFinish != null && !snowPrbU_ActualImpFinish.toString().isEmpty()) jsonObject.put("prb_u_actual_imp_finish", snowPrbU_ActualImpFinish);
		if (snowPrbU_ActualStart != null && !snowPrbU_ActualStart.toString().isEmpty()) jsonObject.put("prb_u_actual_start", snowPrbU_ActualStart);
		if (snowPrbU_AffectedAsset != null && !snowPrbU_AffectedAsset.toString().isEmpty()) jsonObject.put("prb_u_affected_asset", snowPrbU_AffectedAsset);
		if (snowPrbU_AffectedUser != null && !snowPrbU_AffectedUser.toString().isEmpty()) jsonObject.put("prb_u_affected_user", snowPrbU_AffectedUser);
		if (snowPrbU_AgreedFixImplementationDa != null && !snowPrbU_AgreedFixImplementationDa.toString().isEmpty()) jsonObject.put("prb_u_agreed_fix_implementation_da", snowPrbU_AgreedFixImplementationDa);
		if (snowPrbU_AgreementOnPriority != null && !snowPrbU_AgreementOnPriority.toString().isEmpty()) jsonObject.put("prb_u_agreement_on_priority", snowPrbU_AgreementOnPriority);
		if (snowPrbU_AgreementOnProposedFixAn != null && !snowPrbU_AgreementOnProposedFixAn.toString().isEmpty()) jsonObject.put("prb_u_agreement_on_proposed_fix_an", snowPrbU_AgreementOnProposedFixAn);
		if (snowPrbU_AgreementOnWorkaround != null && !snowPrbU_AgreementOnWorkaround.toString().isEmpty()) jsonObject.put("prb_u_agreement_on_workaround", snowPrbU_AgreementOnWorkaround);
		if (snowPrbU_AofDateTime != null && !snowPrbU_AofDateTime.toString().isEmpty()) jsonObject.put("prb_u_aof_date__time", snowPrbU_AofDateTime);
		if (snowPrbU_AofState != null && !snowPrbU_AofState.toString().isEmpty()) jsonObject.put("prb_u_aof_state", snowPrbU_AofState);
		if (snowPrbU_AofWorkgroup != null && !snowPrbU_AofWorkgroup.toString().isEmpty()) jsonObject.put("prb_u_aof_workgroup", snowPrbU_AofWorkgroup);
		if (snowPrbU_AosDateTime != null && !snowPrbU_AosDateTime.toString().isEmpty()) jsonObject.put("prb_u_aos_date__time", snowPrbU_AosDateTime);
		if (snowPrbU_AosState != null && !snowPrbU_AosState.toString().isEmpty()) jsonObject.put("prb_u_aos_state", snowPrbU_AosState);
		if (snowPrbU_AosWorkgroup != null && !snowPrbU_AosWorkgroup.toString().isEmpty()) jsonObject.put("prb_u_aos_workgroup", snowPrbU_AosWorkgroup);
		if (snowPrbU_AssetCode != null && !snowPrbU_AssetCode.toString().isEmpty()) jsonObject.put("prb_u_asset_code", snowPrbU_AssetCode);
		if (snowPrbU_AssetString != null && !snowPrbU_AssetString.toString().isEmpty()) jsonObject.put("prb_u_asset_string", snowPrbU_AssetString);
		if (snowPrbU_AssignedToBladelogic != null && !snowPrbU_AssignedToBladelogic.toString().isEmpty()) jsonObject.put("prb_u_assigned_to_bladelogic", snowPrbU_AssignedToBladelogic);
		if (snowPrbU_AssignmentStatus != null && !snowPrbU_AssignmentStatus.toString().isEmpty()) jsonObject.put("prb_u_assignment_status", snowPrbU_AssignmentStatus);
		if (snowPrbU_AttachmentsAdded != null && !snowPrbU_AttachmentsAdded.toString().isEmpty()) jsonObject.put("prb_u_attachments_added", snowPrbU_AttachmentsAdded);
		if (snowPrbU_AuditCode != null && !snowPrbU_AuditCode.toString().isEmpty()) jsonObject.put("prb_u_audit__code", snowPrbU_AuditCode);
		if (snowPrbU_AutoClose != null && !snowPrbU_AutoClose.toString().isEmpty()) jsonObject.put("prb_u_auto_close", snowPrbU_AutoClose);
		if (snowPrbU_AutoCloseTicket != null && !snowPrbU_AutoCloseTicket.toString().isEmpty()) jsonObject.put("prb_u_auto_close_ticket", snowPrbU_AutoCloseTicket);
		if (snowPrbU_AutoParm1 != null && !snowPrbU_AutoParm1.toString().isEmpty()) jsonObject.put("prb_u_auto_parm1", snowPrbU_AutoParm1);
		if (snowPrbU_AutoParm2 != null && !snowPrbU_AutoParm2.toString().isEmpty()) jsonObject.put("prb_u_auto_parm2", snowPrbU_AutoParm2);
		if (snowPrbU_AutoParm3 != null && !snowPrbU_AutoParm3.toString().isEmpty()) jsonObject.put("prb_u_auto_parm3", snowPrbU_AutoParm3);
		if (snowPrbU_AutoParm4 != null && !snowPrbU_AutoParm4.toString().isEmpty()) jsonObject.put("prb_u_auto_parm4", snowPrbU_AutoParm4);
		if (snowPrbU_AutoParm5 != null && !snowPrbU_AutoParm5.toString().isEmpty()) jsonObject.put("prb_u_auto_parm5", snowPrbU_AutoParm5);
		if (snowPrbU_AutoTarget != null && !snowPrbU_AutoTarget.toString().isEmpty()) jsonObject.put("prb_u_auto_target", snowPrbU_AutoTarget);
		if (snowPrbU_AutoType != null && !snowPrbU_AutoType.toString().isEmpty()) jsonObject.put("prb_u_auto_type", snowPrbU_AutoType);
		if (snowPrbU_AvailAddComments != null && !snowPrbU_AvailAddComments.toString().isEmpty()) jsonObject.put("prb_u_avail_add_comments", snowPrbU_AvailAddComments);
		if (snowPrbU_AvailTechSvc != null && !snowPrbU_AvailTechSvc.toString().isEmpty()) jsonObject.put("prb_u_avail_tech_svc", snowPrbU_AvailTechSvc);
		if (snowPrbU_AvailabilityReport != null && !snowPrbU_AvailabilityReport.toString().isEmpty()) jsonObject.put("prb_u_availability_report", snowPrbU_AvailabilityReport);
		if (snowPrbU_BriefSummary != null && !snowPrbU_BriefSummary.toString().isEmpty()) jsonObject.put("prb_u_brief_summary", snowPrbU_BriefSummary);
		if (snowPrbU_BsdResolutionBy != null && !snowPrbU_BsdResolutionBy.toString().isEmpty()) jsonObject.put("prb_u_bsd_resolution_by", snowPrbU_BsdResolutionBy);
		if (snowPrbU_BusinessImpact != null && !snowPrbU_BusinessImpact.toString().isEmpty()) jsonObject.put("prb_u_business_impact", snowPrbU_BusinessImpact);
		if (snowPrbU_BusinessService != null && !snowPrbU_BusinessService.toString().isEmpty()) jsonObject.put("prb_u_business_service", snowPrbU_BusinessService);
		if (snowPrbU_CallCaptureComments != null && !snowPrbU_CallCaptureComments.toString().isEmpty()) jsonObject.put("prb_u_call_capture_comments", snowPrbU_CallCaptureComments);
		if (snowPrbU_CallHandlingComments != null && !snowPrbU_CallHandlingComments.toString().isEmpty()) jsonObject.put("prb_u_call_handling_comments", snowPrbU_CallHandlingComments);
		if (snowPrbU_Category != null && !snowPrbU_Category.toString().isEmpty()) jsonObject.put("prb_u_category", snowPrbU_Category);
		if (snowPrbU_CauseItem != null && !snowPrbU_CauseItem.toString().isEmpty()) jsonObject.put("prb_u_cause_item", snowPrbU_CauseItem);
		if (snowPrbU_CausedBy != null && !snowPrbU_CausedBy.toString().isEmpty()) jsonObject.put("prb_u_caused_by", snowPrbU_CausedBy);
		if (snowPrbU_ChangeManager != null && !snowPrbU_ChangeManager.toString().isEmpty()) jsonObject.put("prb_u_change_manager", snowPrbU_ChangeManager);
		if (snowPrbU_CiClassification != null && !snowPrbU_CiClassification.toString().isEmpty()) jsonObject.put("prb_u_ci_classification", snowPrbU_CiClassification);
		if (snowPrbU_CiSubclassification != null && !snowPrbU_CiSubclassification.toString().isEmpty()) jsonObject.put("prb_u_ci_subclassification", snowPrbU_CiSubclassification);
		if (snowPrbU_Classification != null && !snowPrbU_Classification.toString().isEmpty()) jsonObject.put("prb_u_classification", snowPrbU_Classification);
		if (snowPrbU_ClosedPeriod != null && !snowPrbU_ClosedPeriod.toString().isEmpty()) jsonObject.put("prb_u_closed_period", snowPrbU_ClosedPeriod);
		if (snowPrbU_ClosureCategory != null && !snowPrbU_ClosureCategory.toString().isEmpty()) jsonObject.put("prb_u_closure_category", snowPrbU_ClosureCategory);
		if (snowPrbU_CommentType != null && !snowPrbU_CommentType.toString().isEmpty()) jsonObject.put("prb_u_comment_type", snowPrbU_CommentType);
		if (snowPrbU_CommentTypeHandling != null && !snowPrbU_CommentTypeHandling.toString().isEmpty()) jsonObject.put("prb_u_comment_type_handling", snowPrbU_CommentTypeHandling);
		if (snowPrbU_CommentsAndWorkNotes != null && !snowPrbU_CommentsAndWorkNotes.toString().isEmpty()) jsonObject.put("prb_u_comments_and_work_notes", snowPrbU_CommentsAndWorkNotes);
		if (snowPrbU_CopyComments != null && !snowPrbU_CopyComments.toString().isEmpty()) jsonObject.put("prb_u_copy_comments", snowPrbU_CopyComments);
		if (snowPrbU_CopySubject != null && !snowPrbU_CopySubject.toString().isEmpty()) jsonObject.put("prb_u_copy_subject", snowPrbU_CopySubject);
		if (snowPrbU_CountTasks != null && !snowPrbU_CountTasks.toString().isEmpty()) jsonObject.put("prb_u_count_tasks", snowPrbU_CountTasks);
		if (snowPrbU_CreateKnownError != null && !snowPrbU_CreateKnownError.toString().isEmpty()) jsonObject.put("prb_u_create_known_error", snowPrbU_CreateKnownError);
		if (snowPrbU_CsrJiraRef != null && !snowPrbU_CsrJiraRef.toString().isEmpty()) jsonObject.put("prb_u_csr__jira_ref_", snowPrbU_CsrJiraRef);
		if (snowPrbU_DateAgreedOnPriority != null && !snowPrbU_DateAgreedOnPriority.toString().isEmpty()) jsonObject.put("prb_u_date_agreed_on_priority", snowPrbU_DateAgreedOnPriority);
		if (snowPrbU_DateAgreedOnProposedFix != null && !snowPrbU_DateAgreedOnProposedFix.toString().isEmpty()) jsonObject.put("prb_u_date_agreed_on_proposed_fix", snowPrbU_DateAgreedOnProposedFix);
		if (snowPrbU_DateAgreedOnWorkaround != null && !snowPrbU_DateAgreedOnWorkaround.toString().isEmpty()) jsonObject.put("prb_u_date_agreed_on_workaround", snowPrbU_DateAgreedOnWorkaround);
		if (snowPrbU_DatePutIntoDevelopment != null && !snowPrbU_DatePutIntoDevelopment.toString().isEmpty()) jsonObject.put("prb_u_date_put_into_development", snowPrbU_DatePutIntoDevelopment);
		if (snowPrbU_Deadline != null && !snowPrbU_Deadline.toString().isEmpty()) jsonObject.put("prb_u_deadline", snowPrbU_Deadline);
		if (snowPrbU_DeployEndDate != null && !snowPrbU_DeployEndDate.toString().isEmpty()) jsonObject.put("prb_u_deploy_end_date", snowPrbU_DeployEndDate);
		if (snowPrbU_DeployStartDate != null && !snowPrbU_DeployStartDate.toString().isEmpty()) jsonObject.put("prb_u_deploy_start_date", snowPrbU_DeployStartDate);
		if (snowPrbU_DeploymentPlan != null && !snowPrbU_DeploymentPlan.toString().isEmpty()) jsonObject.put("prb_u_deployment_plan", snowPrbU_DeploymentPlan);
		if (snowPrbU_DesktopAssetNumber != null && !snowPrbU_DesktopAssetNumber.toString().isEmpty()) jsonObject.put("prb_u_desktop_asset_number", snowPrbU_DesktopAssetNumber);
		if (snowPrbU_DesktopMake != null && !snowPrbU_DesktopMake.toString().isEmpty()) jsonObject.put("prb_u_desktop_make", snowPrbU_DesktopMake);
		if (snowPrbU_DesktopModel != null && !snowPrbU_DesktopModel.toString().isEmpty()) jsonObject.put("prb_u_desktop_model", snowPrbU_DesktopModel);
		if (snowPrbU_DesktopSN != null && !snowPrbU_DesktopSN.toString().isEmpty()) jsonObject.put("prb_u_desktop_s_n", snowPrbU_DesktopSN);
		if (snowPrbU_DevEndDate != null && !snowPrbU_DevEndDate.toString().isEmpty()) jsonObject.put("prb_u_dev_end_date", snowPrbU_DevEndDate);
		if (snowPrbU_DevStartDate != null && !snowPrbU_DevStartDate.toString().isEmpty()) jsonObject.put("prb_u_dev_start_date", snowPrbU_DevStartDate);
		if (snowPrbU_Dormant != null && !snowPrbU_Dormant.toString().isEmpty()) jsonObject.put("prb_u_dormant", snowPrbU_Dormant);
		if (snowPrbU_ErrorCodeMessage != null && !snowPrbU_ErrorCodeMessage.toString().isEmpty()) jsonObject.put("prb_u_error_code_message", snowPrbU_ErrorCodeMessage);
		if (snowPrbU_Escalated != null && !snowPrbU_Escalated.toString().isEmpty()) jsonObject.put("prb_u_escalated", snowPrbU_Escalated);
		if (snowPrbU_Exception != null && !snowPrbU_Exception.toString().isEmpty()) jsonObject.put("prb_u_exception", snowPrbU_Exception);
		if (snowPrbU_ExpertHelp != null && !snowPrbU_ExpertHelp.toString().isEmpty()) jsonObject.put("prb_u_expert_help", snowPrbU_ExpertHelp);
		if (snowPrbU_ExternalRef != null && !snowPrbU_ExternalRef.toString().isEmpty()) jsonObject.put("prb_u_external_ref", snowPrbU_ExternalRef);
		if (snowPrbU_FeedbackCode != null && !snowPrbU_FeedbackCode.toString().isEmpty()) jsonObject.put("prb_u_feedback_code", snowPrbU_FeedbackCode);
		if (snowPrbU_FeedbackCodeHandling != null && !snowPrbU_FeedbackCodeHandling.toString().isEmpty()) jsonObject.put("prb_u_feedback_code_handling", snowPrbU_FeedbackCodeHandling);
		if (snowPrbU_FirstDeadline != null && !snowPrbU_FirstDeadline.toString().isEmpty()) jsonObject.put("prb_u_first_deadline", snowPrbU_FirstDeadline);
		if (snowPrbU_FixOptions != null && !snowPrbU_FixOptions.toString().isEmpty()) jsonObject.put("prb_u_fix_options", snowPrbU_FixOptions);
		if (snowPrbU_FixedOnTime != null && !snowPrbU_FixedOnTime.toString().isEmpty()) jsonObject.put("prb_u_fixed_on_time", snowPrbU_FixedOnTime);
		if (snowPrbU_Folder != null && !snowPrbU_Folder.toString().isEmpty()) jsonObject.put("prb_u_folder", snowPrbU_Folder);
		if (snowPrbU_Frequency != null && !snowPrbU_Frequency.toString().isEmpty()) jsonObject.put("prb_u_frequency", snowPrbU_Frequency);
		if (snowPrbU_HpException != null && !snowPrbU_HpException.toString().isEmpty()) jsonObject.put("prb_u_hp_exception", snowPrbU_HpException);
		if (snowPrbU_IcsImpact != null && !snowPrbU_IcsImpact.toString().isEmpty()) jsonObject.put("prb_u_ics_impact", snowPrbU_IcsImpact);
		if (snowPrbU_ImpBreakdown != null && !snowPrbU_ImpBreakdown.toString().isEmpty()) jsonObject.put("prb_u_imp_breakdown", snowPrbU_ImpBreakdown);
		if (snowPrbU_ImplementationEta != null && !snowPrbU_ImplementationEta.toString().isEmpty()) jsonObject.put("prb_u_implementation_eta", snowPrbU_ImplementationEta);
		if (snowPrbU_InfosysException != null && !snowPrbU_InfosysException.toString().isEmpty()) jsonObject.put("prb_u_infosys_exception", snowPrbU_InfosysException);
		if (snowPrbU_InitialAssignment != null && !snowPrbU_InitialAssignment.toString().isEmpty()) jsonObject.put("prb_u_initial_assignment", snowPrbU_InitialAssignment);
		if (snowPrbU_Instructions != null && !snowPrbU_Instructions.toString().isEmpty()) jsonObject.put("prb_u_instructions", snowPrbU_Instructions);
		if (snowPrbU_InternalRef != null && !snowPrbU_InternalRef.toString().isEmpty()) jsonObject.put("prb_u_internal_ref", snowPrbU_InternalRef);
		if (snowPrbU_ItilWatchList != null && !snowPrbU_ItilWatchList.toString().isEmpty()) jsonObject.put("prb_u_itil_watch_list", snowPrbU_ItilWatchList);
		if (snowPrbU_KnowledgeArticle != null && !snowPrbU_KnowledgeArticle.toString().isEmpty()) jsonObject.put("prb_u_knowledge_article", snowPrbU_KnowledgeArticle);
		if (snowPrbU_KnowledgeAvailable != null && !snowPrbU_KnowledgeAvailable.toString().isEmpty()) jsonObject.put("prb_u_knowledge_available", snowPrbU_KnowledgeAvailable);
		if (snowPrbU_KnowledgeCode != null && !snowPrbU_KnowledgeCode.toString().isEmpty()) jsonObject.put("prb_u_knowledge_code", snowPrbU_KnowledgeCode);
		if (snowPrbU_KnowledgeComments != null && !snowPrbU_KnowledgeComments.toString().isEmpty()) jsonObject.put("prb_u_knowledge_comments", snowPrbU_KnowledgeComments);
		if (snowPrbU_KnowledgeFound != null && !snowPrbU_KnowledgeFound.toString().isEmpty()) jsonObject.put("prb_u_knowledge_found", snowPrbU_KnowledgeFound);
		if (snowPrbU_KnowledgeUser != null && !snowPrbU_KnowledgeUser.toString().isEmpty()) jsonObject.put("prb_u_knowledge_user", snowPrbU_KnowledgeUser);
		if (snowPrbU_KnownError != null && !snowPrbU_KnownError.toString().isEmpty()) jsonObject.put("prb_u_known_error", snowPrbU_KnownError);
		if (snowPrbU_KnownErrorDatabaseUrl != null && !snowPrbU_KnownErrorDatabaseUrl.toString().isEmpty()) jsonObject.put("prb_u_known_error_database_url", snowPrbU_KnownErrorDatabaseUrl);
		if (snowPrbU_KnownErrorLocation != null && !snowPrbU_KnownErrorLocation.toString().isEmpty()) jsonObject.put("prb_u_known_error_location", snowPrbU_KnownErrorLocation);
		if (snowPrbU_KnownErrorUrl != null && !snowPrbU_KnownErrorUrl.toString().isEmpty()) jsonObject.put("prb_u_known_error_url", snowPrbU_KnownErrorUrl);
		if (snowPrbU_LastOccurrence != null && !snowPrbU_LastOccurrence.toString().isEmpty()) jsonObject.put("prb_u_last_occurrence", snowPrbU_LastOccurrence);
		if (snowPrbU_LateImpReason != null && !snowPrbU_LateImpReason.toString().isEmpty()) jsonObject.put("prb_u_late_imp_reason", snowPrbU_LateImpReason);
		if (snowPrbU_LocalResp != null && !snowPrbU_LocalResp.toString().isEmpty()) jsonObject.put("prb_u_local_resp", snowPrbU_LocalResp);
		if (snowPrbU_ManagementAuditComments != null && !snowPrbU_ManagementAuditComments.toString().isEmpty()) jsonObject.put("prb_u_management_audit_comments", snowPrbU_ManagementAuditComments);
		if (snowPrbU_ManagementComments != null && !snowPrbU_ManagementComments.toString().isEmpty()) jsonObject.put("prb_u_management_comments", snowPrbU_ManagementComments);
		if (snowPrbU_MissingCi != null && !snowPrbU_MissingCi.toString().isEmpty()) jsonObject.put("prb_u_missing_ci", snowPrbU_MissingCi);
		if (snowPrbU_MissingCiFlag != null && !snowPrbU_MissingCiFlag.toString().isEmpty()) jsonObject.put("prb_u_missing_ci_flag", snowPrbU_MissingCiFlag);
		if (snowPrbU_ModifiedPeriod != null && !snowPrbU_ModifiedPeriod.toString().isEmpty()) jsonObject.put("prb_u_modified_period", snowPrbU_ModifiedPeriod);
		if (snowPrbU_MonitorReviewDate != null && !snowPrbU_MonitorReviewDate.toString().isEmpty()) jsonObject.put("prb_u_monitor_review_date", snowPrbU_MonitorReviewDate);
		if (snowPrbU_Name != null && !snowPrbU_Name.toString().isEmpty()) jsonObject.put("prb_u_name", snowPrbU_Name);
		if (snowPrbU_Occurrence != null && !snowPrbU_Occurrence.toString().isEmpty()) jsonObject.put("prb_u_occurrence", snowPrbU_Occurrence);
		if (snowPrbU_OpenedPeriod != null && !snowPrbU_OpenedPeriod.toString().isEmpty()) jsonObject.put("prb_u_opened_period", snowPrbU_OpenedPeriod);
		if (snowPrbU_OutageDuration != null && !snowPrbU_OutageDuration.toString().isEmpty()) jsonObject.put("prb_u_outage_duration", snowPrbU_OutageDuration);
		if (snowPrbU_OutsourceAssignedOut != null && !snowPrbU_OutsourceAssignedOut.toString().isEmpty()) jsonObject.put("prb_u_outsource_assigned_out", snowPrbU_OutsourceAssignedOut);
		if (snowPrbU_OutsourceAssignee != null && !snowPrbU_OutsourceAssignee.toString().isEmpty()) jsonObject.put("prb_u_outsource_assignee", snowPrbU_OutsourceAssignee);
		if (snowPrbU_OutsourceId != null && !snowPrbU_OutsourceId.toString().isEmpty()) jsonObject.put("prb_u_outsource_id", snowPrbU_OutsourceId);
		if (snowPrbU_OutsourceIntegration != null && !snowPrbU_OutsourceIntegration.toString().isEmpty()) jsonObject.put("prb_u_outsource_integration", snowPrbU_OutsourceIntegration);
		if (snowPrbU_OutsourceModule != null && !snowPrbU_OutsourceModule.toString().isEmpty()) jsonObject.put("prb_u_outsource_module", snowPrbU_OutsourceModule);
		if (snowPrbU_OutsourceResponse != null && !snowPrbU_OutsourceResponse.toString().isEmpty()) jsonObject.put("prb_u_outsource_response", snowPrbU_OutsourceResponse);
		if (snowPrbU_OutsourceResult != null && !snowPrbU_OutsourceResult.toString().isEmpty()) jsonObject.put("prb_u_outsource_result", snowPrbU_OutsourceResult);
		if (snowPrbU_OutsourceStatus != null && !snowPrbU_OutsourceStatus.toString().isEmpty()) jsonObject.put("prb_u_outsource_status", snowPrbU_OutsourceStatus);
		if (snowPrbU_OutsourceTeam != null && !snowPrbU_OutsourceTeam.toString().isEmpty()) jsonObject.put("prb_u_outsource_team", snowPrbU_OutsourceTeam);
		if (snowPrbU_Override1 != null && !snowPrbU_Override1.toString().isEmpty()) jsonObject.put("prb_u_override1", snowPrbU_Override1);
		if (snowPrbU_Person != null && !snowPrbU_Person.toString().isEmpty()) jsonObject.put("prb_u_person", snowPrbU_Person);
		if (snowPrbU_PersonAudited != null && !snowPrbU_PersonAudited.toString().isEmpty()) jsonObject.put("prb_u_person_audited", snowPrbU_PersonAudited);
		if (snowPrbU_PersonAuditing != null && !snowPrbU_PersonAuditing.toString().isEmpty()) jsonObject.put("prb_u_person_auditing", snowPrbU_PersonAuditing);
		if (snowPrbU_Phone != null && !snowPrbU_Phone.toString().isEmpty()) jsonObject.put("prb_u_phone", snowPrbU_Phone);
		if (snowPrbU_PickupDuration != null && !snowPrbU_PickupDuration.toString().isEmpty()) jsonObject.put("prb_u_pickup_duration", snowPrbU_PickupDuration);
		if (snowPrbU_PlannedEffort != null && !snowPrbU_PlannedEffort.toString().isEmpty()) jsonObject.put("prb_u_planned_effort", snowPrbU_PlannedEffort);
		if (snowPrbU_PlannedImplementationWeek != null && !snowPrbU_PlannedImplementationWeek.toString().isEmpty()) jsonObject.put("prb_u_planned_implementation_week", snowPrbU_PlannedImplementationWeek);
		if (snowPrbU_PmVerify != null && !snowPrbU_PmVerify.toString().isEmpty()) jsonObject.put("prb_u_pm_verify", snowPrbU_PmVerify);
		if (snowPrbU_PmWorkgroup != null && !snowPrbU_PmWorkgroup.toString().isEmpty()) jsonObject.put("prb_u_pm_workgroup", snowPrbU_PmWorkgroup);
		if (snowPrbU_PmWritable != null && !snowPrbU_PmWritable.toString().isEmpty()) jsonObject.put("prb_u_pm_writable", snowPrbU_PmWritable);
		if (snowPrbU_PreviousGroup != null && !snowPrbU_PreviousGroup.toString().isEmpty()) jsonObject.put("prb_u_previous_group", snowPrbU_PreviousGroup);
		if (snowPrbU_PreviousStatus != null && !snowPrbU_PreviousStatus.toString().isEmpty()) jsonObject.put("prb_u_previous_status", snowPrbU_PreviousStatus);
		if (snowPrbU_PriorityAmendmentExplanati != null && !snowPrbU_PriorityAmendmentExplanati.toString().isEmpty()) jsonObject.put("prb_u_priority_amendment_explanati", snowPrbU_PriorityAmendmentExplanati);
		if (snowPrbU_ProblemBoardRecommendation != null && !snowPrbU_ProblemBoardRecommendation.toString().isEmpty()) jsonObject.put("prb_u_problem_board_recommendation", snowPrbU_ProblemBoardRecommendation);
		if (snowPrbU_ProblemClosed != null && !snowPrbU_ProblemClosed.toString().isEmpty()) jsonObject.put("prb_u_problem_closed", snowPrbU_ProblemClosed);
		if (snowPrbU_ProblemImpact != null && !snowPrbU_ProblemImpact.toString().isEmpty()) jsonObject.put("prb_u_problem_impact", snowPrbU_ProblemImpact);
		if (snowPrbU_ProblemLite != null && !snowPrbU_ProblemLite.toString().isEmpty()) jsonObject.put("prb_u_problem_lite", snowPrbU_ProblemLite);
		if (snowPrbU_ProblemManager != null && !snowPrbU_ProblemManager.toString().isEmpty()) jsonObject.put("prb_u_problem_manager", snowPrbU_ProblemManager);
		if (snowPrbU_ProblemOwnerComments != null && !snowPrbU_ProblemOwnerComments.toString().isEmpty()) jsonObject.put("prb_u_problem_owner_comments", snowPrbU_ProblemOwnerComments);
		if (snowPrbU_ProgReviewDate != null && !snowPrbU_ProgReviewDate.toString().isEmpty()) jsonObject.put("prb_u_prog_review_date", snowPrbU_ProgReviewDate);
		if (snowPrbU_ProposedSolution != null && !snowPrbU_ProposedSolution.toString().isEmpty()) jsonObject.put("prb_u_proposed_solution", snowPrbU_ProposedSolution);
		if (snowPrbU_QueryCount != null && !snowPrbU_QueryCount.toString().isEmpty()) jsonObject.put("prb_u_query_count", snowPrbU_QueryCount);
		if (snowPrbU_RcaInProgressTime != null && !snowPrbU_RcaInProgressTime.toString().isEmpty()) jsonObject.put("prb_u_rca_in_progress_time", snowPrbU_RcaInProgressTime);
		if (snowPrbU_RcaState != null && !snowPrbU_RcaState.toString().isEmpty()) jsonObject.put("prb_u_rca_state", snowPrbU_RcaState);
		if (snowPrbU_ReasonForException != null && !snowPrbU_ReasonForException.toString().isEmpty()) jsonObject.put("prb_u_reason_for_exception", snowPrbU_ReasonForException);
		if (snowPrbU_RegionImpacted != null && !snowPrbU_RegionImpacted.toString().isEmpty()) jsonObject.put("prb_u_region_impacted", snowPrbU_RegionImpacted);
		if (snowPrbU_RelatedIncidents != null && !snowPrbU_RelatedIncidents.toString().isEmpty()) jsonObject.put("prb_u_related_incidents", snowPrbU_RelatedIncidents);
		if (snowPrbU_ReopenCount != null && !snowPrbU_ReopenCount.toString().isEmpty()) jsonObject.put("prb_u_reopen_count", snowPrbU_ReopenCount);
		if (snowPrbU_ReopenedDate != null && !snowPrbU_ReopenedDate.toString().isEmpty()) jsonObject.put("prb_u_reopened_date", snowPrbU_ReopenedDate);
		if (snowPrbU_Resolution != null && !snowPrbU_Resolution.toString().isEmpty()) jsonObject.put("prb_u_resolution", snowPrbU_Resolution);
		if (snowPrbU_ResolutionOverride != null && !snowPrbU_ResolutionOverride.toString().isEmpty()) jsonObject.put("prb_u_resolution_override", snowPrbU_ResolutionOverride);
		if (snowPrbU_ResolvedAt != null && !snowPrbU_ResolvedAt.toString().isEmpty()) jsonObject.put("prb_u_resolved_at", snowPrbU_ResolvedAt);
		if (snowPrbU_ResolvedBy != null && !snowPrbU_ResolvedBy.toString().isEmpty()) jsonObject.put("prb_u_resolved_by", snowPrbU_ResolvedBy);
		if (snowPrbU_ResolvedByWorkgroup != null && !snowPrbU_ResolvedByWorkgroup.toString().isEmpty()) jsonObject.put("prb_u_resolved_by_workgroup", snowPrbU_ResolvedByWorkgroup);
		if (snowPrbU_Resolver != null && !snowPrbU_Resolver.toString().isEmpty()) jsonObject.put("prb_u_resolver", snowPrbU_Resolver);
		if (snowPrbU_ResponseFlag != null && !snowPrbU_ResponseFlag.toString().isEmpty()) jsonObject.put("prb_u_response_flag", snowPrbU_ResponseFlag);
		if (snowPrbU_ResponseOverride != null && !snowPrbU_ResponseOverride.toString().isEmpty()) jsonObject.put("prb_u_response_override", snowPrbU_ResponseOverride);
		if (snowPrbU_RootCause != null && !snowPrbU_RootCause.toString().isEmpty()) jsonObject.put("prb_u_root_cause", snowPrbU_RootCause);
		if (snowPrbU_SaveAsDraft != null && !snowPrbU_SaveAsDraft.toString().isEmpty()) jsonObject.put("prb_u_save_as_draft", snowPrbU_SaveAsDraft);
		if (snowPrbU_SavedCount != null && !snowPrbU_SavedCount.toString().isEmpty()) jsonObject.put("prb_u_saved_count", snowPrbU_SavedCount);
		if (snowPrbU_Scope != null && !snowPrbU_Scope.toString().isEmpty()) jsonObject.put("prb_u_scope", snowPrbU_Scope);
		if (snowPrbU_SecondDeadline != null && !snowPrbU_SecondDeadline.toString().isEmpty()) jsonObject.put("prb_u_second_deadline", snowPrbU_SecondDeadline);
		if (snowPrbU_SelectApplication != null && !snowPrbU_SelectApplication.toString().isEmpty()) jsonObject.put("prb_u_select_application", snowPrbU_SelectApplication);
		if (snowPrbU_SelectEuc != null && !snowPrbU_SelectEuc.toString().isEmpty()) jsonObject.put("prb_u_select_euc", snowPrbU_SelectEuc);
		if (snowPrbU_SelectInfrastructure != null && !snowPrbU_SelectInfrastructure.toString().isEmpty()) jsonObject.put("prb_u_select_infrastructure", snowPrbU_SelectInfrastructure);
		if (snowPrbU_SelectNetwork != null && !snowPrbU_SelectNetwork.toString().isEmpty()) jsonObject.put("prb_u_select_network", snowPrbU_SelectNetwork);
		if (snowPrbU_ServerName != null && !snowPrbU_ServerName.toString().isEmpty()) jsonObject.put("prb_u_server_name", snowPrbU_ServerName);
		if (snowPrbU_SlaFailureWorkgroup != null && !snowPrbU_SlaFailureWorkgroup.toString().isEmpty()) jsonObject.put("prb_u_sla_failure_workgroup", snowPrbU_SlaFailureWorkgroup);
		if (snowPrbU_SlaState != null && !snowPrbU_SlaState.toString().isEmpty()) jsonObject.put("prb_u_sla_state", snowPrbU_SlaState);
		if (snowPrbU_SlfApprover != null && !snowPrbU_SlfApprover.toString().isEmpty()) jsonObject.put("prb_u_slf_approver", snowPrbU_SlfApprover);
		if (snowPrbU_SlfComponent != null && !snowPrbU_SlfComponent.toString().isEmpty()) jsonObject.put("prb_u_slf_component", snowPrbU_SlfComponent);
		if (snowPrbU_SlfReason != null && !snowPrbU_SlfReason.toString().isEmpty()) jsonObject.put("prb_u_slf_reason", snowPrbU_SlfReason);
		if (snowPrbU_SlfReviewDate != null && !snowPrbU_SlfReviewDate.toString().isEmpty()) jsonObject.put("prb_u_slf_review_date", snowPrbU_SlfReviewDate);
		if (snowPrbU_SolutionApprovedBy != null && !snowPrbU_SolutionApprovedBy.toString().isEmpty()) jsonObject.put("prb_u_solution_approved_by", snowPrbU_SolutionApprovedBy);
		if (snowPrbU_SrtState != null && !snowPrbU_SrtState.toString().isEmpty()) jsonObject.put("prb_u_srt_state", snowPrbU_SrtState);
		if (snowPrbU_SspForm != null && !snowPrbU_SspForm.toString().isEmpty()) jsonObject.put("prb_u_ssp_form", snowPrbU_SspForm);
		if (snowPrbU_Subcategory != null && !snowPrbU_Subcategory.toString().isEmpty()) jsonObject.put("prb_u_subcategory", snowPrbU_Subcategory);
		if (snowPrbU_Subclassification != null && !snowPrbU_Subclassification.toString().isEmpty()) jsonObject.put("prb_u_subclassification", snowPrbU_Subclassification);
		if (snowPrbU_Subject != null && !snowPrbU_Subject.toString().isEmpty()) jsonObject.put("prb_u_subject", snowPrbU_Subject);
		if (snowPrbU_SupportStructure != null && !snowPrbU_SupportStructure.toString().isEmpty()) jsonObject.put("prb_u_support_structure", snowPrbU_SupportStructure);
		if (snowPrbU_Symptoms != null && !snowPrbU_Symptoms.toString().isEmpty()) jsonObject.put("prb_u_symptoms", snowPrbU_Symptoms);
		if (snowPrbU_TargetFixDate != null && !snowPrbU_TargetFixDate.toString().isEmpty()) jsonObject.put("prb_u_target_fix_date", snowPrbU_TargetFixDate);
		if (snowPrbU_TaskType != null && !snowPrbU_TaskType.toString().isEmpty()) jsonObject.put("prb_u_task_type", snowPrbU_TaskType);
		if (snowPrbU_Template != null && !snowPrbU_Template.toString().isEmpty()) jsonObject.put("prb_u_template", snowPrbU_Template);
		if (snowPrbU_ThirdLineComments != null && !snowPrbU_ThirdLineComments.toString().isEmpty()) jsonObject.put("prb_u_third_line_comments", snowPrbU_ThirdLineComments);
		if (snowPrbU_ThirdLineDate != null && !snowPrbU_ThirdLineDate.toString().isEmpty()) jsonObject.put("prb_u_third_line_date", snowPrbU_ThirdLineDate);
		if (snowPrbU_ThirdPartyReference != null && !snowPrbU_ThirdPartyReference.toString().isEmpty()) jsonObject.put("prb_u_third_party_reference", snowPrbU_ThirdPartyReference);
		if (snowPrbU_TimeToAuth != null && !snowPrbU_TimeToAuth.toString().isEmpty()) jsonObject.put("prb_u_time_to_auth", snowPrbU_TimeToAuth);
		if (snowPrbU_TimeToClose != null && !snowPrbU_TimeToClose.toString().isEmpty()) jsonObject.put("prb_u_time_to_close", snowPrbU_TimeToClose);
		if (snowPrbU_UsersAffected != null && !snowPrbU_UsersAffected.toString().isEmpty()) jsonObject.put("prb_u_users_affected", snowPrbU_UsersAffected);
		if (snowPrbU_VerizonException != null && !snowPrbU_VerizonException.toString().isEmpty()) jsonObject.put("prb_u_verizon_exception", snowPrbU_VerizonException);
		if (snowPrbU_WebUpdate != null && !snowPrbU_WebUpdate.toString().isEmpty()) jsonObject.put("prb_u_web_update", snowPrbU_WebUpdate);
		if (snowPrbU_Workaround != null && !snowPrbU_Workaround.toString().isEmpty()) jsonObject.put("prb_u_workaround", snowPrbU_Workaround);
		if (snowPrbU_WorkaroundSummary != null && !snowPrbU_WorkaroundSummary.toString().isEmpty()) jsonObject.put("prb_u_workaround_summary", snowPrbU_WorkaroundSummary);
		if (snowPrbUponApproval != null && !snowPrbUponApproval.toString().isEmpty()) jsonObject.put("prb_upon_approval", snowPrbUponApproval);
		if (snowPrbUponReject != null && !snowPrbUponReject.toString().isEmpty()) jsonObject.put("prb_upon_reject", snowPrbUponReject);
		if (snowPrbUrgency != null && !snowPrbUrgency.toString().isEmpty()) jsonObject.put("prb_urgency", snowPrbUrgency);
		if (snowPrbUserInput != null && !snowPrbUserInput.toString().isEmpty()) jsonObject.put("prb_user_input", snowPrbUserInput);
		if (snowPrbWatchList != null && !snowPrbWatchList.toString().isEmpty()) jsonObject.put("prb_watch_list", snowPrbWatchList);
		if (snowPrbWfActivity != null && !snowPrbWfActivity.toString().isEmpty()) jsonObject.put("prb_wf_activity", snowPrbWfActivity);
		if (snowPrbWorkAround != null && !snowPrbWorkAround.toString().isEmpty()) jsonObject.put("prb_work_around", snowPrbWorkAround);
		if (snowPrbWorkEffort != null && !snowPrbWorkEffort.toString().isEmpty()) jsonObject.put("prb_work_effort", snowPrbWorkEffort);
		if (snowPrbWorkEnd != null && !snowPrbWorkEnd.toString().isEmpty()) jsonObject.put("prb_work_end", snowPrbWorkEnd);
		if (snowPrbWorkNotes != null && !snowPrbWorkNotes.toString().isEmpty()) jsonObject.put("prb_work_notes", snowPrbWorkNotes);
		if (snowPrbWorkStart != null && !snowPrbWorkStart.toString().isEmpty()) jsonObject.put("prb_work_start", snowPrbWorkStart);
		
		return jsonObject;
	}

	public String getSnowMdActive() {
		return snowMdActive;
	}

	public void setSnowMdActive(String snowMdActive) {
		this.snowMdActive = snowMdActive;
	}

	public String getSnowMdDescription() {
		return snowMdDescription;
	}

	public void setSnowMdDescription(String snowMdDescription) {
		this.snowMdDescription = snowMdDescription;
	}

	public String getSnowMdField() {
		return snowMdField;
	}

	public void setSnowMdField(String snowMdField) {
		this.snowMdField = snowMdField;
	}

	public String getSnowMdName() {
		return snowMdName;
	}

	public void setSnowMdName(String snowMdName) {
		this.snowMdName = snowMdName;
	}

	public String getSnowMdNumber() {
		return snowMdNumber;
	}

	public void setSnowMdNumber(String snowMdNumber) {
		this.snowMdNumber = snowMdNumber;
	}

	public String getSnowMdOrder() {
		return snowMdOrder;
	}

	public void setSnowMdOrder(String snowMdOrder) {
		this.snowMdOrder = snowMdOrder;
	}

	public String getSnowMdSysClassName() {
		return snowMdSysClassName;
	}

	public void setSnowMdSysClassName(String snowMdSysClassName) {
		this.snowMdSysClassName = snowMdSysClassName;
	}

	public String getSnowMdSysCreatedBy() {
		return snowMdSysCreatedBy;
	}

	public void setSnowMdSysCreatedBy(String snowMdSysCreatedBy) {
		this.snowMdSysCreatedBy = snowMdSysCreatedBy;
	}

	public String getSnowMdSysCreatedOn() {
		return snowMdSysCreatedOn;
	}

	public void setSnowMdSysCreatedOn(String snowMdSysCreatedOn) {
		this.snowMdSysCreatedOn = snowMdSysCreatedOn;
	}

	public String getSnowMdSysCustomerUpdate() {
		return snowMdSysCustomerUpdate;
	}

	public void setSnowMdSysCustomerUpdate(String snowMdSysCustomerUpdate) {
		this.snowMdSysCustomerUpdate = snowMdSysCustomerUpdate;
	}

	public String getSnowMdSysId() {
		return snowMdSysId;
	}

	public void setSnowMdSysId(String snowMdSysId) {
		this.snowMdSysId = snowMdSysId;
	}

	public String getSnowMdSysModCount() {
		return snowMdSysModCount;
	}

	public void setSnowMdSysModCount(String snowMdSysModCount) {
		this.snowMdSysModCount = snowMdSysModCount;
	}

	public String getSnowMdSysName() {
		return snowMdSysName;
	}

	public void setSnowMdSysName(String snowMdSysName) {
		this.snowMdSysName = snowMdSysName;
	}

	public String getSnowMdSysPackage() {
		return snowMdSysPackage;
	}

	public void setSnowMdSysPackage(String snowMdSysPackage) {
		this.snowMdSysPackage = snowMdSysPackage;
	}

	public String getSnowMdSysPolicy() {
		return snowMdSysPolicy;
	}

	public void setSnowMdSysPolicy(String snowMdSysPolicy) {
		this.snowMdSysPolicy = snowMdSysPolicy;
	}

	public String getSnowMdSysReplaceOnUpgrade() {
		return snowMdSysReplaceOnUpgrade;
	}

	public void setSnowMdSysReplaceOnUpgrade(String snowMdSysReplaceOnUpgrade) {
		this.snowMdSysReplaceOnUpgrade = snowMdSysReplaceOnUpgrade;
	}

	public String getSnowMdSysTags() {
		return snowMdSysTags;
	}

	public void setSnowMdSysTags(String snowMdSysTags) {
		this.snowMdSysTags = snowMdSysTags;
	}

	public String getSnowMdSysUpdateName() {
		return snowMdSysUpdateName;
	}

	public void setSnowMdSysUpdateName(String snowMdSysUpdateName) {
		this.snowMdSysUpdateName = snowMdSysUpdateName;
	}

	public String getSnowMdSysUpdatedBy() {
		return snowMdSysUpdatedBy;
	}

	public void setSnowMdSysUpdatedBy(String snowMdSysUpdatedBy) {
		this.snowMdSysUpdatedBy = snowMdSysUpdatedBy;
	}

	public String getSnowMdSysUpdatedOn() {
		return snowMdSysUpdatedOn;
	}

	public void setSnowMdSysUpdatedOn(String snowMdSysUpdatedOn) {
		this.snowMdSysUpdatedOn = snowMdSysUpdatedOn;
	}

	public String getSnowMdTable() {
		return snowMdTable;
	}

	public void setSnowMdTable(String snowMdTable) {
		this.snowMdTable = snowMdTable;
	}

	public String getSnowMdTimeline() {
		return snowMdTimeline;
	}

	public void setSnowMdTimeline(String snowMdTimeline) {
		this.snowMdTimeline = snowMdTimeline;
	}

	public String getSnowMdType() {
		return snowMdType;
	}

	public void setSnowMdType(String snowMdType) {
		this.snowMdType = snowMdType;
	}

	public String getSnowMiBusinessDuration() {
		return snowMiBusinessDuration;
	}

	public void setSnowMiBusinessDuration(String snowMiBusinessDuration) {
		this.snowMiBusinessDuration = snowMiBusinessDuration;
	}

	public String getSnowMiCalculationComplete() {
		return snowMiCalculationComplete;
	}

	public void setSnowMiCalculationComplete(String snowMiCalculationComplete) {
		this.snowMiCalculationComplete = snowMiCalculationComplete;
	}

	public String getSnowMiDefinition() {
		return snowMiDefinition;
	}

	public void setSnowMiDefinition(String snowMiDefinition) {
		this.snowMiDefinition = snowMiDefinition;
	}

	public String getSnowMiDuration() {
		return snowMiDuration;
	}

	public void setSnowMiDuration(String snowMiDuration) {
		this.snowMiDuration = snowMiDuration;
	}

	public String getSnowMiEnd() {
		return snowMiEnd;
	}

	public void setSnowMiEnd(String snowMiEnd) {
		this.snowMiEnd = snowMiEnd;
	}

	public String getSnowMiField() {
		return snowMiField;
	}

	public void setSnowMiField(String snowMiField) {
		this.snowMiField = snowMiField;
	}

	public String getSnowMiFieldValue() {
		return snowMiFieldValue;
	}

	public void setSnowMiFieldValue(String snowMiFieldValue) {
		this.snowMiFieldValue = snowMiFieldValue;
	}

	public String getSnowMiId() {
		return snowMiId;
	}

	public void setSnowMiId(String snowMiId) {
		this.snowMiId = snowMiId;
	}

	public String getSnowMiStart() {
		return snowMiStart;
	}

	public void setSnowMiStart(String snowMiStart) {
		this.snowMiStart = snowMiStart;
	}

	public String getSnowMiSysCreatedBy() {
		return snowMiSysCreatedBy;
	}

	public void setSnowMiSysCreatedBy(String snowMiSysCreatedBy) {
		this.snowMiSysCreatedBy = snowMiSysCreatedBy;
	}

	public String getSnowMiSysCreatedOn() {
		return snowMiSysCreatedOn;
	}

	public void setSnowMiSysCreatedOn(String snowMiSysCreatedOn) {
		this.snowMiSysCreatedOn = snowMiSysCreatedOn;
	}

	public String getSnowMiSysId() {
		return snowMiSysId;
	}

	public void setSnowMiSysId(String snowMiSysId) {
		this.snowMiSysId = snowMiSysId;
	}

	public String getSnowMiSysModCount() {
		return snowMiSysModCount;
	}

	public void setSnowMiSysModCount(String snowMiSysModCount) {
		this.snowMiSysModCount = snowMiSysModCount;
	}

	public String getSnowMiSysUpdatedBy() {
		return snowMiSysUpdatedBy;
	}

	public void setSnowMiSysUpdatedBy(String snowMiSysUpdatedBy) {
		this.snowMiSysUpdatedBy = snowMiSysUpdatedBy;
	}

	public String getSnowMiSysUpdatedOn() {
		return snowMiSysUpdatedOn;
	}

	public void setSnowMiSysUpdatedOn(String snowMiSysUpdatedOn) {
		this.snowMiSysUpdatedOn = snowMiSysUpdatedOn;
	}

	public String getSnowMiTable() {
		return snowMiTable;
	}

	public void setSnowMiTable(String snowMiTable) {
		this.snowMiTable = snowMiTable;
	}

	public String getSnowMiValue() {
		return snowMiValue;
	}

	public void setSnowMiValue(String snowMiValue) {
		this.snowMiValue = snowMiValue;
	}

	public String getSnowPrbActive() {
		return snowPrbActive;
	}

	public void setSnowPrbActive(String snowPrbActive) {
		this.snowPrbActive = snowPrbActive;
	}

	public String getSnowPrbActivityDue() {
		return snowPrbActivityDue;
	}

	public void setSnowPrbActivityDue(String snowPrbActivityDue) {
		this.snowPrbActivityDue = snowPrbActivityDue;
	}

	public String getSnowPrbAdditionalAssigneeList() {
		return snowPrbAdditionalAssigneeList;
	}

	public void setSnowPrbAdditionalAssigneeList(String snowPrbAdditionalAssigneeList) {
		this.snowPrbAdditionalAssigneeList = snowPrbAdditionalAssigneeList;
	}

	public String getSnowPrbApproval() {
		return snowPrbApproval;
	}

	public void setSnowPrbApproval(String snowPrbApproval) {
		this.snowPrbApproval = snowPrbApproval;
	}

	public String getSnowPrbApprovalHistory() {
		return snowPrbApprovalHistory;
	}

	public void setSnowPrbApprovalHistory(String snowPrbApprovalHistory) {
		this.snowPrbApprovalHistory = snowPrbApprovalHistory;
	}

	public String getSnowPrbApprovalSet() {
		return snowPrbApprovalSet;
	}

	public void setSnowPrbApprovalSet(String snowPrbApprovalSet) {
		this.snowPrbApprovalSet = snowPrbApprovalSet;
	}

	public String getSnowPrbAssignedTo() {
		return snowPrbAssignedTo;
	}

	public void setSnowPrbAssignedTo(String snowPrbAssignedTo) {
		this.snowPrbAssignedTo = snowPrbAssignedTo;
	}

	public String getSnowPrbAssignmentGroup() {
		return snowPrbAssignmentGroup;
	}

	public void setSnowPrbAssignmentGroup(String snowPrbAssignmentGroup) {
		this.snowPrbAssignmentGroup = snowPrbAssignmentGroup;
	}

	public String getSnowPrbBusinessDuration() {
		return snowPrbBusinessDuration;
	}

	public void setSnowPrbBusinessDuration(String snowPrbBusinessDuration) {
		this.snowPrbBusinessDuration = snowPrbBusinessDuration;
	}

	public String getSnowPrbBusinessService() {
		return snowPrbBusinessService;
	}

	public void setSnowPrbBusinessService(String snowPrbBusinessService) {
		this.snowPrbBusinessService = snowPrbBusinessService;
	}

	public String getSnowPrbCalendarDuration() {
		return snowPrbCalendarDuration;
	}

	public void setSnowPrbCalendarDuration(String snowPrbCalendarDuration) {
		this.snowPrbCalendarDuration = snowPrbCalendarDuration;
	}

	public String getSnowPrbCallerId() {
		return snowPrbCallerId;
	}

	public void setSnowPrbCallerId(String snowPrbCallerId) {
		this.snowPrbCallerId = snowPrbCallerId;
	}

	public String getSnowPrbCategory() {
		return snowPrbCategory;
	}

	public void setSnowPrbCategory(String snowPrbCategory) {
		this.snowPrbCategory = snowPrbCategory;
	}

	public String getSnowPrbCloseCode() {
		return snowPrbCloseCode;
	}

	public void setSnowPrbCloseCode(String snowPrbCloseCode) {
		this.snowPrbCloseCode = snowPrbCloseCode;
	}

	public String getSnowPrbCloseNotes() {
		return snowPrbCloseNotes;
	}

	public void setSnowPrbCloseNotes(String snowPrbCloseNotes) {
		this.snowPrbCloseNotes = snowPrbCloseNotes;
	}

	public String getSnowPrbClosedAt() {
		return snowPrbClosedAt;
	}

	public void setSnowPrbClosedAt(String snowPrbClosedAt) {
		this.snowPrbClosedAt = snowPrbClosedAt;
	}

	public String getSnowPrbClosedBy() {
		return snowPrbClosedBy;
	}

	public void setSnowPrbClosedBy(String snowPrbClosedBy) {
		this.snowPrbClosedBy = snowPrbClosedBy;
	}

	public String getSnowPrbCmdbCi() {
		return snowPrbCmdbCi;
	}

	public void setSnowPrbCmdbCi(String snowPrbCmdbCi) {
		this.snowPrbCmdbCi = snowPrbCmdbCi;
	}

	public String getSnowPrbComments() {
		return snowPrbComments;
	}

	public void setSnowPrbComments(String snowPrbComments) {
		this.snowPrbComments = snowPrbComments;
	}

	public String getSnowPrbCompany() {
		return snowPrbCompany;
	}

	public void setSnowPrbCompany(String snowPrbCompany) {
		this.snowPrbCompany = snowPrbCompany;
	}

	public String getSnowPrbContactType() {
		return snowPrbContactType;
	}

	public void setSnowPrbContactType(String snowPrbContactType) {
		this.snowPrbContactType = snowPrbContactType;
	}

	public String getSnowPrbContract() {
		return snowPrbContract;
	}

	public void setSnowPrbContract(String snowPrbContract) {
		this.snowPrbContract = snowPrbContract;
	}

	public String getSnowPrbCorrelationDisplay() {
		return snowPrbCorrelationDisplay;
	}

	public void setSnowPrbCorrelationDisplay(String snowPrbCorrelationDisplay) {
		this.snowPrbCorrelationDisplay = snowPrbCorrelationDisplay;
	}

	public String getSnowPrbCorrelationId() {
		return snowPrbCorrelationId;
	}

	public void setSnowPrbCorrelationId(String snowPrbCorrelationId) {
		this.snowPrbCorrelationId = snowPrbCorrelationId;
	}

	public String getSnowPrbDeliveryPlan() {
		return snowPrbDeliveryPlan;
	}

	public void setSnowPrbDeliveryPlan(String snowPrbDeliveryPlan) {
		this.snowPrbDeliveryPlan = snowPrbDeliveryPlan;
	}

	public String getSnowPrbDescription() {
		return snowPrbDescription;
	}

	public void setSnowPrbDescription(String snowPrbDescription) {
		this.snowPrbDescription = snowPrbDescription;
	}

	public String getSnowPrbDueDate() {
		return snowPrbDueDate;
	}

	public void setSnowPrbDueDate(String snowPrbDueDate) {
		this.snowPrbDueDate = snowPrbDueDate;
	}

	public String getSnowPrbEffort() {
		return snowPrbEffort;
	}

	public void setSnowPrbEffort(String snowPrbEffort) {
		this.snowPrbEffort = snowPrbEffort;
	}

	public String getSnowPrbEndDate() {
		return snowPrbEndDate;
	}

	public void setSnowPrbEndDate(String snowPrbEndDate) {
		this.snowPrbEndDate = snowPrbEndDate;
	}

	public String getSnowPrbEscalation() {
		return snowPrbEscalation;
	}

	public void setSnowPrbEscalation(String snowPrbEscalation) {
		this.snowPrbEscalation = snowPrbEscalation;
	}

	public String getSnowPrbExpectedStart() {
		return snowPrbExpectedStart;
	}

	public void setSnowPrbExpectedStart(String snowPrbExpectedStart) {
		this.snowPrbExpectedStart = snowPrbExpectedStart;
	}

	public String getSnowPrbFollowUp() {
		return snowPrbFollowUp;
	}

	public void setSnowPrbFollowUp(String snowPrbFollowUp) {
		this.snowPrbFollowUp = snowPrbFollowUp;
	}

	public String getSnowPrbGroupList() {
		return snowPrbGroupList;
	}

	public void setSnowPrbGroupList(String snowPrbGroupList) {
		this.snowPrbGroupList = snowPrbGroupList;
	}

	public String getSnowPrbImpact() {
		return snowPrbImpact;
	}

	public void setSnowPrbImpact(String snowPrbImpact) {
		this.snowPrbImpact = snowPrbImpact;
	}

	public String getSnowPrbKnowledge() {
		return snowPrbKnowledge;
	}

	public void setSnowPrbKnowledge(String snowPrbKnowledge) {
		this.snowPrbKnowledge = snowPrbKnowledge;
	}

	public String getSnowPrbLocation() {
		return snowPrbLocation;
	}

	public void setSnowPrbLocation(String snowPrbLocation) {
		this.snowPrbLocation = snowPrbLocation;
	}

	public String getSnowPrbMadeSla() {
		return snowPrbMadeSla;
	}

	public void setSnowPrbMadeSla(String snowPrbMadeSla) {
		this.snowPrbMadeSla = snowPrbMadeSla;
	}

	public String getSnowPrbNotify() {
		return snowPrbNotify;
	}

	public void setSnowPrbNotify(String snowPrbNotify) {
		this.snowPrbNotify = snowPrbNotify;
	}

	public String getSnowPrbNumber() {
		return snowPrbNumber;
	}

	public void setSnowPrbNumber(String snowPrbNumber) {
		this.snowPrbNumber = snowPrbNumber;
	}

	public String getSnowPrbOpenedAt() {
		return snowPrbOpenedAt;
	}

	public void setSnowPrbOpenedAt(String snowPrbOpenedAt) {
		this.snowPrbOpenedAt = snowPrbOpenedAt;
	}

	public String getSnowPrbOpenedBy() {
		return snowPrbOpenedBy;
	}

	public void setSnowPrbOpenedBy(String snowPrbOpenedBy) {
		this.snowPrbOpenedBy = snowPrbOpenedBy;
	}

	public String getSnowPrbOrder() {
		return snowPrbOrder;
	}

	public void setSnowPrbOrder(String snowPrbOrder) {
		this.snowPrbOrder = snowPrbOrder;
	}

	public String getSnowPrbParent() {
		return snowPrbParent;
	}

	public void setSnowPrbParent(String snowPrbParent) {
		this.snowPrbParent = snowPrbParent;
	}

	public String getSnowPrbPriority() {
		return snowPrbPriority;
	}

	public void setSnowPrbPriority(String snowPrbPriority) {
		this.snowPrbPriority = snowPrbPriority;
	}

	public String getSnowPrbReassignmentCount() {
		return snowPrbReassignmentCount;
	}

	public void setSnowPrbReassignmentCount(String snowPrbReassignmentCount) {
		this.snowPrbReassignmentCount = snowPrbReassignmentCount;
	}

	public String getSnowPrbRfc() {
		return snowPrbRfc;
	}

	public void setSnowPrbRfc(String snowPrbRfc) {
		this.snowPrbRfc = snowPrbRfc;
	}

	public String getSnowPrbShortDescription() {
		return snowPrbShortDescription;
	}

	public void setSnowPrbShortDescription(String snowPrbShortDescription) {
		this.snowPrbShortDescription = snowPrbShortDescription;
	}

	public String getSnowPrbSkills() {
		return snowPrbSkills;
	}

	public void setSnowPrbSkills(String snowPrbSkills) {
		this.snowPrbSkills = snowPrbSkills;
	}

	public String getSnowPrbSlaDue() {
		return snowPrbSlaDue;
	}

	public void setSnowPrbSlaDue(String snowPrbSlaDue) {
		this.snowPrbSlaDue = snowPrbSlaDue;
	}

	public String getSnowPrbStartDate() {
		return snowPrbStartDate;
	}

	public void setSnowPrbStartDate(String snowPrbStartDate) {
		this.snowPrbStartDate = snowPrbStartDate;
	}

	public String getSnowPrbState() {
		return snowPrbState;
	}

	public void setSnowPrbState(String snowPrbState) {
		this.snowPrbState = snowPrbState;
	}

	public String getSnowPrbStatus() {
		return snowPrbStatus;
	}

	public void setSnowPrbStatus(String snowPrbStatus) {
		this.snowPrbStatus = snowPrbStatus;
	}

	public String getSnowPrbSubcategory() {
		return snowPrbSubcategory;
	}

	public void setSnowPrbSubcategory(String snowPrbSubcategory) {
		this.snowPrbSubcategory = snowPrbSubcategory;
	}

	public String getSnowPrbSysClassName() {
		return snowPrbSysClassName;
	}

	public void setSnowPrbSysClassName(String snowPrbSysClassName) {
		this.snowPrbSysClassName = snowPrbSysClassName;
	}

	public String getSnowPrbSysCreatedBy() {
		return snowPrbSysCreatedBy;
	}

	public void setSnowPrbSysCreatedBy(String snowPrbSysCreatedBy) {
		this.snowPrbSysCreatedBy = snowPrbSysCreatedBy;
	}

	public String getSnowPrbSysCreatedOn() {
		return snowPrbSysCreatedOn;
	}

	public void setSnowPrbSysCreatedOn(String snowPrbSysCreatedOn) {
		this.snowPrbSysCreatedOn = snowPrbSysCreatedOn;
	}

	public String getSnowPrbSysDomain() {
		return snowPrbSysDomain;
	}

	public void setSnowPrbSysDomain(String snowPrbSysDomain) {
		this.snowPrbSysDomain = snowPrbSysDomain;
	}

	public String getSnowPrbSysId() {
		return snowPrbSysId;
	}

	public void setSnowPrbSysId(String snowPrbSysId) {
		this.snowPrbSysId = snowPrbSysId;
	}

	public String getSnowPrbSysModCount() {
		return snowPrbSysModCount;
	}

	public void setSnowPrbSysModCount(String snowPrbSysModCount) {
		this.snowPrbSysModCount = snowPrbSysModCount;
	}

	public String getSnowPrbSysTags() {
		return snowPrbSysTags;
	}

	public void setSnowPrbSysTags(String snowPrbSysTags) {
		this.snowPrbSysTags = snowPrbSysTags;
	}

	public String getSnowPrbSysUpdatedBy() {
		return snowPrbSysUpdatedBy;
	}

	public void setSnowPrbSysUpdatedBy(String snowPrbSysUpdatedBy) {
		this.snowPrbSysUpdatedBy = snowPrbSysUpdatedBy;
	}

	public String getSnowPrbSysUpdatedOn() {
		return snowPrbSysUpdatedOn;
	}

	public void setSnowPrbSysUpdatedOn(String snowPrbSysUpdatedOn) {
		this.snowPrbSysUpdatedOn = snowPrbSysUpdatedOn;
	}

	public String getSnowPrbTimeWorked() {
		return snowPrbTimeWorked;
	}

	public void setSnowPrbTimeWorked(String snowPrbTimeWorked) {
		this.snowPrbTimeWorked = snowPrbTimeWorked;
	}

	public String getSnowPrbU_1StLine() {
		return snowPrbU_1StLine;
	}

	public void setSnowPrbU_1StLine(String snowPrbU_1StLine) {
		this.snowPrbU_1StLine = snowPrbU_1StLine;
	}

	public String getSnowPrbU_2NdLine() {
		return snowPrbU_2NdLine;
	}

	public void setSnowPrbU_2NdLine(String snowPrbU_2NdLine) {
		this.snowPrbU_2NdLine = snowPrbU_2NdLine;
	}

	public String getSnowPrbU_3RdLineSrt() {
		return snowPrbU_3RdLineSrt;
	}

	public void setSnowPrbU_3RdLineSrt(String snowPrbU_3RdLineSrt) {
		this.snowPrbU_3RdLineSrt = snowPrbU_3RdLineSrt;
	}

	public String getSnowPrbU_AcceptTime() {
		return snowPrbU_AcceptTime;
	}

	public void setSnowPrbU_AcceptTime(String snowPrbU_AcceptTime) {
		this.snowPrbU_AcceptTime = snowPrbU_AcceptTime;
	}

	public String getSnowPrbU_AcknowldgeFeedback() {
		return snowPrbU_AcknowldgeFeedback;
	}

	public void setSnowPrbU_AcknowldgeFeedback(String snowPrbU_AcknowldgeFeedback) {
		this.snowPrbU_AcknowldgeFeedback = snowPrbU_AcknowldgeFeedback;
	}

	public String getSnowPrbU_Acknowledged() {
		return snowPrbU_Acknowledged;
	}

	public void setSnowPrbU_Acknowledged(String snowPrbU_Acknowledged) {
		this.snowPrbU_Acknowledged = snowPrbU_Acknowledged;
	}

	public String getSnowPrbU_ActiveProbInc() {
		return snowPrbU_ActiveProbInc;
	}

	public void setSnowPrbU_ActiveProbInc(String snowPrbU_ActiveProbInc) {
		this.snowPrbU_ActiveProbInc = snowPrbU_ActiveProbInc;
	}

	public String getSnowPrbU_ActualEffort() {
		return snowPrbU_ActualEffort;
	}

	public void setSnowPrbU_ActualEffort(String snowPrbU_ActualEffort) {
		this.snowPrbU_ActualEffort = snowPrbU_ActualEffort;
	}

	public String getSnowPrbU_ActualFinish() {
		return snowPrbU_ActualFinish;
	}

	public void setSnowPrbU_ActualFinish(String snowPrbU_ActualFinish) {
		this.snowPrbU_ActualFinish = snowPrbU_ActualFinish;
	}

	public String getSnowPrbU_ActualFixDate() {
		return snowPrbU_ActualFixDate;
	}

	public void setSnowPrbU_ActualFixDate(String snowPrbU_ActualFixDate) {
		this.snowPrbU_ActualFixDate = snowPrbU_ActualFixDate;
	}

	public String getSnowPrbU_ActualImpDate() {
		return snowPrbU_ActualImpDate;
	}

	public void setSnowPrbU_ActualImpDate(String snowPrbU_ActualImpDate) {
		this.snowPrbU_ActualImpDate = snowPrbU_ActualImpDate;
	}

	public String getSnowPrbU_ActualImpFinish() {
		return snowPrbU_ActualImpFinish;
	}

	public void setSnowPrbU_ActualImpFinish(String snowPrbU_ActualImpFinish) {
		this.snowPrbU_ActualImpFinish = snowPrbU_ActualImpFinish;
	}

	public String getSnowPrbU_ActualStart() {
		return snowPrbU_ActualStart;
	}

	public void setSnowPrbU_ActualStart(String snowPrbU_ActualStart) {
		this.snowPrbU_ActualStart = snowPrbU_ActualStart;
	}

	public String getSnowPrbU_AffectedAsset() {
		return snowPrbU_AffectedAsset;
	}

	public void setSnowPrbU_AffectedAsset(String snowPrbU_AffectedAsset) {
		this.snowPrbU_AffectedAsset = snowPrbU_AffectedAsset;
	}

	public String getSnowPrbU_AffectedUser() {
		return snowPrbU_AffectedUser;
	}

	public void setSnowPrbU_AffectedUser(String snowPrbU_AffectedUser) {
		this.snowPrbU_AffectedUser = snowPrbU_AffectedUser;
	}

	public String getSnowPrbU_AgreedFixImplementationDa() {
		return snowPrbU_AgreedFixImplementationDa;
	}

	public void setSnowPrbU_AgreedFixImplementationDa(String snowPrbU_AgreedFixImplementationDa) {
		this.snowPrbU_AgreedFixImplementationDa = snowPrbU_AgreedFixImplementationDa;
	}

	public String getSnowPrbU_AgreementOnPriority() {
		return snowPrbU_AgreementOnPriority;
	}

	public void setSnowPrbU_AgreementOnPriority(String snowPrbU_AgreementOnPriority) {
		this.snowPrbU_AgreementOnPriority = snowPrbU_AgreementOnPriority;
	}

	public String getSnowPrbU_AgreementOnProposedFixAn() {
		return snowPrbU_AgreementOnProposedFixAn;
	}

	public void setSnowPrbU_AgreementOnProposedFixAn(String snowPrbU_AgreementOnProposedFixAn) {
		this.snowPrbU_AgreementOnProposedFixAn = snowPrbU_AgreementOnProposedFixAn;
	}

	public String getSnowPrbU_AgreementOnWorkaround() {
		return snowPrbU_AgreementOnWorkaround;
	}

	public void setSnowPrbU_AgreementOnWorkaround(String snowPrbU_AgreementOnWorkaround) {
		this.snowPrbU_AgreementOnWorkaround = snowPrbU_AgreementOnWorkaround;
	}

	public String getSnowPrbU_AofDateTime() {
		return snowPrbU_AofDateTime;
	}

	public void setSnowPrbU_AofDateTime(String snowPrbU_AofDateTime) {
		this.snowPrbU_AofDateTime = snowPrbU_AofDateTime;
	}

	public String getSnowPrbU_AofState() {
		return snowPrbU_AofState;
	}

	public void setSnowPrbU_AofState(String snowPrbU_AofState) {
		this.snowPrbU_AofState = snowPrbU_AofState;
	}

	public String getSnowPrbU_AofWorkgroup() {
		return snowPrbU_AofWorkgroup;
	}

	public void setSnowPrbU_AofWorkgroup(String snowPrbU_AofWorkgroup) {
		this.snowPrbU_AofWorkgroup = snowPrbU_AofWorkgroup;
	}

	public String getSnowPrbU_AosDateTime() {
		return snowPrbU_AosDateTime;
	}

	public void setSnowPrbU_AosDateTime(String snowPrbU_AosDateTime) {
		this.snowPrbU_AosDateTime = snowPrbU_AosDateTime;
	}

	public String getSnowPrbU_AosState() {
		return snowPrbU_AosState;
	}

	public void setSnowPrbU_AosState(String snowPrbU_AosState) {
		this.snowPrbU_AosState = snowPrbU_AosState;
	}

	public String getSnowPrbU_AosWorkgroup() {
		return snowPrbU_AosWorkgroup;
	}

	public void setSnowPrbU_AosWorkgroup(String snowPrbU_AosWorkgroup) {
		this.snowPrbU_AosWorkgroup = snowPrbU_AosWorkgroup;
	}

	public String getSnowPrbU_AssetCode() {
		return snowPrbU_AssetCode;
	}

	public void setSnowPrbU_AssetCode(String snowPrbU_AssetCode) {
		this.snowPrbU_AssetCode = snowPrbU_AssetCode;
	}

	public String getSnowPrbU_AssetString() {
		return snowPrbU_AssetString;
	}

	public void setSnowPrbU_AssetString(String snowPrbU_AssetString) {
		this.snowPrbU_AssetString = snowPrbU_AssetString;
	}

	public String getSnowPrbU_AssignedToBladelogic() {
		return snowPrbU_AssignedToBladelogic;
	}

	public void setSnowPrbU_AssignedToBladelogic(String snowPrbU_AssignedToBladelogic) {
		this.snowPrbU_AssignedToBladelogic = snowPrbU_AssignedToBladelogic;
	}

	public String getSnowPrbU_AssignmentStatus() {
		return snowPrbU_AssignmentStatus;
	}

	public void setSnowPrbU_AssignmentStatus(String snowPrbU_AssignmentStatus) {
		this.snowPrbU_AssignmentStatus = snowPrbU_AssignmentStatus;
	}

	public String getSnowPrbU_AttachmentsAdded() {
		return snowPrbU_AttachmentsAdded;
	}

	public void setSnowPrbU_AttachmentsAdded(String snowPrbU_AttachmentsAdded) {
		this.snowPrbU_AttachmentsAdded = snowPrbU_AttachmentsAdded;
	}

	public String getSnowPrbU_AuditCode() {
		return snowPrbU_AuditCode;
	}

	public void setSnowPrbU_AuditCode(String snowPrbU_AuditCode) {
		this.snowPrbU_AuditCode = snowPrbU_AuditCode;
	}

	public String getSnowPrbU_AutoClose() {
		return snowPrbU_AutoClose;
	}

	public void setSnowPrbU_AutoClose(String snowPrbU_AutoClose) {
		this.snowPrbU_AutoClose = snowPrbU_AutoClose;
	}

	public String getSnowPrbU_AutoCloseTicket() {
		return snowPrbU_AutoCloseTicket;
	}

	public void setSnowPrbU_AutoCloseTicket(String snowPrbU_AutoCloseTicket) {
		this.snowPrbU_AutoCloseTicket = snowPrbU_AutoCloseTicket;
	}

	public String getSnowPrbU_AutoParm1() {
		return snowPrbU_AutoParm1;
	}

	public void setSnowPrbU_AutoParm1(String snowPrbU_AutoParm1) {
		this.snowPrbU_AutoParm1 = snowPrbU_AutoParm1;
	}

	public String getSnowPrbU_AutoParm2() {
		return snowPrbU_AutoParm2;
	}

	public void setSnowPrbU_AutoParm2(String snowPrbU_AutoParm2) {
		this.snowPrbU_AutoParm2 = snowPrbU_AutoParm2;
	}

	public String getSnowPrbU_AutoParm3() {
		return snowPrbU_AutoParm3;
	}

	public void setSnowPrbU_AutoParm3(String snowPrbU_AutoParm3) {
		this.snowPrbU_AutoParm3 = snowPrbU_AutoParm3;
	}

	public String getSnowPrbU_AutoParm4() {
		return snowPrbU_AutoParm4;
	}

	public void setSnowPrbU_AutoParm4(String snowPrbU_AutoParm4) {
		this.snowPrbU_AutoParm4 = snowPrbU_AutoParm4;
	}

	public String getSnowPrbU_AutoParm5() {
		return snowPrbU_AutoParm5;
	}

	public void setSnowPrbU_AutoParm5(String snowPrbU_AutoParm5) {
		this.snowPrbU_AutoParm5 = snowPrbU_AutoParm5;
	}

	public String getSnowPrbU_AutoTarget() {
		return snowPrbU_AutoTarget;
	}

	public void setSnowPrbU_AutoTarget(String snowPrbU_AutoTarget) {
		this.snowPrbU_AutoTarget = snowPrbU_AutoTarget;
	}

	public String getSnowPrbU_AutoType() {
		return snowPrbU_AutoType;
	}

	public void setSnowPrbU_AutoType(String snowPrbU_AutoType) {
		this.snowPrbU_AutoType = snowPrbU_AutoType;
	}

	public String getSnowPrbU_AvailAddComments() {
		return snowPrbU_AvailAddComments;
	}

	public void setSnowPrbU_AvailAddComments(String snowPrbU_AvailAddComments) {
		this.snowPrbU_AvailAddComments = snowPrbU_AvailAddComments;
	}

	public String getSnowPrbU_AvailTechSvc() {
		return snowPrbU_AvailTechSvc;
	}

	public void setSnowPrbU_AvailTechSvc(String snowPrbU_AvailTechSvc) {
		this.snowPrbU_AvailTechSvc = snowPrbU_AvailTechSvc;
	}

	public String getSnowPrbU_AvailabilityReport() {
		return snowPrbU_AvailabilityReport;
	}

	public void setSnowPrbU_AvailabilityReport(String snowPrbU_AvailabilityReport) {
		this.snowPrbU_AvailabilityReport = snowPrbU_AvailabilityReport;
	}

	public String getSnowPrbU_BriefSummary() {
		return snowPrbU_BriefSummary;
	}

	public void setSnowPrbU_BriefSummary(String snowPrbU_BriefSummary) {
		this.snowPrbU_BriefSummary = snowPrbU_BriefSummary;
	}

	public String getSnowPrbU_BsdResolutionBy() {
		return snowPrbU_BsdResolutionBy;
	}

	public void setSnowPrbU_BsdResolutionBy(String snowPrbU_BsdResolutionBy) {
		this.snowPrbU_BsdResolutionBy = snowPrbU_BsdResolutionBy;
	}

	public String getSnowPrbU_BusinessImpact() {
		return snowPrbU_BusinessImpact;
	}

	public void setSnowPrbU_BusinessImpact(String snowPrbU_BusinessImpact) {
		this.snowPrbU_BusinessImpact = snowPrbU_BusinessImpact;
	}

	public String getSnowPrbU_BusinessService() {
		return snowPrbU_BusinessService;
	}

	public void setSnowPrbU_BusinessService(String snowPrbU_BusinessService) {
		this.snowPrbU_BusinessService = snowPrbU_BusinessService;
	}

	public String getSnowPrbU_CallCaptureComments() {
		return snowPrbU_CallCaptureComments;
	}

	public void setSnowPrbU_CallCaptureComments(String snowPrbU_CallCaptureComments) {
		this.snowPrbU_CallCaptureComments = snowPrbU_CallCaptureComments;
	}

	public String getSnowPrbU_CallHandlingComments() {
		return snowPrbU_CallHandlingComments;
	}

	public void setSnowPrbU_CallHandlingComments(String snowPrbU_CallHandlingComments) {
		this.snowPrbU_CallHandlingComments = snowPrbU_CallHandlingComments;
	}

	public String getSnowPrbU_Category() {
		return snowPrbU_Category;
	}

	public void setSnowPrbU_Category(String snowPrbU_Category) {
		this.snowPrbU_Category = snowPrbU_Category;
	}

	public String getSnowPrbU_CauseItem() {
		return snowPrbU_CauseItem;
	}

	public void setSnowPrbU_CauseItem(String snowPrbU_CauseItem) {
		this.snowPrbU_CauseItem = snowPrbU_CauseItem;
	}

	public String getSnowPrbU_CausedBy() {
		return snowPrbU_CausedBy;
	}

	public void setSnowPrbU_CausedBy(String snowPrbU_CausedBy) {
		this.snowPrbU_CausedBy = snowPrbU_CausedBy;
	}

	public String getSnowPrbU_ChangeManager() {
		return snowPrbU_ChangeManager;
	}

	public void setSnowPrbU_ChangeManager(String snowPrbU_ChangeManager) {
		this.snowPrbU_ChangeManager = snowPrbU_ChangeManager;
	}

	public String getSnowPrbU_CiClassification() {
		return snowPrbU_CiClassification;
	}

	public void setSnowPrbU_CiClassification(String snowPrbU_CiClassification) {
		this.snowPrbU_CiClassification = snowPrbU_CiClassification;
	}

	public String getSnowPrbU_CiSubclassification() {
		return snowPrbU_CiSubclassification;
	}

	public void setSnowPrbU_CiSubclassification(String snowPrbU_CiSubclassification) {
		this.snowPrbU_CiSubclassification = snowPrbU_CiSubclassification;
	}

	public String getSnowPrbU_Classification() {
		return snowPrbU_Classification;
	}

	public void setSnowPrbU_Classification(String snowPrbU_Classification) {
		this.snowPrbU_Classification = snowPrbU_Classification;
	}

	public String getSnowPrbU_ClosedPeriod() {
		return snowPrbU_ClosedPeriod;
	}

	public void setSnowPrbU_ClosedPeriod(String snowPrbU_ClosedPeriod) {
		this.snowPrbU_ClosedPeriod = snowPrbU_ClosedPeriod;
	}

	public String getSnowPrbU_ClosureCategory() {
		return snowPrbU_ClosureCategory;
	}

	public void setSnowPrbU_ClosureCategory(String snowPrbU_ClosureCategory) {
		this.snowPrbU_ClosureCategory = snowPrbU_ClosureCategory;
	}

	public String getSnowPrbU_CommentType() {
		return snowPrbU_CommentType;
	}

	public void setSnowPrbU_CommentType(String snowPrbU_CommentType) {
		this.snowPrbU_CommentType = snowPrbU_CommentType;
	}

	public String getSnowPrbU_CommentTypeHandling() {
		return snowPrbU_CommentTypeHandling;
	}

	public void setSnowPrbU_CommentTypeHandling(String snowPrbU_CommentTypeHandling) {
		this.snowPrbU_CommentTypeHandling = snowPrbU_CommentTypeHandling;
	}

	public String getSnowPrbU_CommentsAndWorkNotes() {
		return snowPrbU_CommentsAndWorkNotes;
	}

	public void setSnowPrbU_CommentsAndWorkNotes(String snowPrbU_CommentsAndWorkNotes) {
		this.snowPrbU_CommentsAndWorkNotes = snowPrbU_CommentsAndWorkNotes;
	}

	public String getSnowPrbU_CopyComments() {
		return snowPrbU_CopyComments;
	}

	public void setSnowPrbU_CopyComments(String snowPrbU_CopyComments) {
		this.snowPrbU_CopyComments = snowPrbU_CopyComments;
	}

	public String getSnowPrbU_CopySubject() {
		return snowPrbU_CopySubject;
	}

	public void setSnowPrbU_CopySubject(String snowPrbU_CopySubject) {
		this.snowPrbU_CopySubject = snowPrbU_CopySubject;
	}

	public String getSnowPrbU_CountTasks() {
		return snowPrbU_CountTasks;
	}

	public void setSnowPrbU_CountTasks(String snowPrbU_CountTasks) {
		this.snowPrbU_CountTasks = snowPrbU_CountTasks;
	}

	public String getSnowPrbU_CreateKnownError() {
		return snowPrbU_CreateKnownError;
	}

	public void setSnowPrbU_CreateKnownError(String snowPrbU_CreateKnownError) {
		this.snowPrbU_CreateKnownError = snowPrbU_CreateKnownError;
	}

	public String getSnowPrbU_CsrJiraRef() {
		return snowPrbU_CsrJiraRef;
	}

	public void setSnowPrbU_CsrJiraRef(String snowPrbU_CsrJiraRef) {
		this.snowPrbU_CsrJiraRef = snowPrbU_CsrJiraRef;
	}

	public String getSnowPrbU_DateAgreedOnPriority() {
		return snowPrbU_DateAgreedOnPriority;
	}

	public void setSnowPrbU_DateAgreedOnPriority(String snowPrbU_DateAgreedOnPriority) {
		this.snowPrbU_DateAgreedOnPriority = snowPrbU_DateAgreedOnPriority;
	}

	public String getSnowPrbU_DateAgreedOnProposedFix() {
		return snowPrbU_DateAgreedOnProposedFix;
	}

	public void setSnowPrbU_DateAgreedOnProposedFix(String snowPrbU_DateAgreedOnProposedFix) {
		this.snowPrbU_DateAgreedOnProposedFix = snowPrbU_DateAgreedOnProposedFix;
	}

	public String getSnowPrbU_DateAgreedOnWorkaround() {
		return snowPrbU_DateAgreedOnWorkaround;
	}

	public void setSnowPrbU_DateAgreedOnWorkaround(String snowPrbU_DateAgreedOnWorkaround) {
		this.snowPrbU_DateAgreedOnWorkaround = snowPrbU_DateAgreedOnWorkaround;
	}

	public String getSnowPrbU_DatePutIntoDevelopment() {
		return snowPrbU_DatePutIntoDevelopment;
	}

	public void setSnowPrbU_DatePutIntoDevelopment(String snowPrbU_DatePutIntoDevelopment) {
		this.snowPrbU_DatePutIntoDevelopment = snowPrbU_DatePutIntoDevelopment;
	}

	public String getSnowPrbU_Deadline() {
		return snowPrbU_Deadline;
	}

	public void setSnowPrbU_Deadline(String snowPrbU_Deadline) {
		this.snowPrbU_Deadline = snowPrbU_Deadline;
	}

	public String getSnowPrbU_DeployEndDate() {
		return snowPrbU_DeployEndDate;
	}

	public void setSnowPrbU_DeployEndDate(String snowPrbU_DeployEndDate) {
		this.snowPrbU_DeployEndDate = snowPrbU_DeployEndDate;
	}

	public String getSnowPrbU_DeployStartDate() {
		return snowPrbU_DeployStartDate;
	}

	public void setSnowPrbU_DeployStartDate(String snowPrbU_DeployStartDate) {
		this.snowPrbU_DeployStartDate = snowPrbU_DeployStartDate;
	}

	public String getSnowPrbU_DeploymentPlan() {
		return snowPrbU_DeploymentPlan;
	}

	public void setSnowPrbU_DeploymentPlan(String snowPrbU_DeploymentPlan) {
		this.snowPrbU_DeploymentPlan = snowPrbU_DeploymentPlan;
	}

	public String getSnowPrbU_DesktopAssetNumber() {
		return snowPrbU_DesktopAssetNumber;
	}

	public void setSnowPrbU_DesktopAssetNumber(String snowPrbU_DesktopAssetNumber) {
		this.snowPrbU_DesktopAssetNumber = snowPrbU_DesktopAssetNumber;
	}

	public String getSnowPrbU_DesktopMake() {
		return snowPrbU_DesktopMake;
	}

	public void setSnowPrbU_DesktopMake(String snowPrbU_DesktopMake) {
		this.snowPrbU_DesktopMake = snowPrbU_DesktopMake;
	}

	public String getSnowPrbU_DesktopModel() {
		return snowPrbU_DesktopModel;
	}

	public void setSnowPrbU_DesktopModel(String snowPrbU_DesktopModel) {
		this.snowPrbU_DesktopModel = snowPrbU_DesktopModel;
	}

	public String getSnowPrbU_DesktopSN() {
		return snowPrbU_DesktopSN;
	}

	public void setSnowPrbU_DesktopSN(String snowPrbU_DesktopSN) {
		this.snowPrbU_DesktopSN = snowPrbU_DesktopSN;
	}

	public String getSnowPrbU_DevEndDate() {
		return snowPrbU_DevEndDate;
	}

	public void setSnowPrbU_DevEndDate(String snowPrbU_DevEndDate) {
		this.snowPrbU_DevEndDate = snowPrbU_DevEndDate;
	}

	public String getSnowPrbU_DevStartDate() {
		return snowPrbU_DevStartDate;
	}

	public void setSnowPrbU_DevStartDate(String snowPrbU_DevStartDate) {
		this.snowPrbU_DevStartDate = snowPrbU_DevStartDate;
	}

	public String getSnowPrbU_Dormant() {
		return snowPrbU_Dormant;
	}

	public void setSnowPrbU_Dormant(String snowPrbU_Dormant) {
		this.snowPrbU_Dormant = snowPrbU_Dormant;
	}

	public String getSnowPrbU_ErrorCodeMessage() {
		return snowPrbU_ErrorCodeMessage;
	}

	public void setSnowPrbU_ErrorCodeMessage(String snowPrbU_ErrorCodeMessage) {
		this.snowPrbU_ErrorCodeMessage = snowPrbU_ErrorCodeMessage;
	}

	public String getSnowPrbU_Escalated() {
		return snowPrbU_Escalated;
	}

	public void setSnowPrbU_Escalated(String snowPrbU_Escalated) {
		this.snowPrbU_Escalated = snowPrbU_Escalated;
	}

	public String getSnowPrbU_Exception() {
		return snowPrbU_Exception;
	}

	public void setSnowPrbU_Exception(String snowPrbU_Exception) {
		this.snowPrbU_Exception = snowPrbU_Exception;
	}

	public String getSnowPrbU_ExpertHelp() {
		return snowPrbU_ExpertHelp;
	}

	public void setSnowPrbU_ExpertHelp(String snowPrbU_ExpertHelp) {
		this.snowPrbU_ExpertHelp = snowPrbU_ExpertHelp;
	}

	public String getSnowPrbU_ExternalRef() {
		return snowPrbU_ExternalRef;
	}

	public void setSnowPrbU_ExternalRef(String snowPrbU_ExternalRef) {
		this.snowPrbU_ExternalRef = snowPrbU_ExternalRef;
	}

	public String getSnowPrbU_FeedbackCode() {
		return snowPrbU_FeedbackCode;
	}

	public void setSnowPrbU_FeedbackCode(String snowPrbU_FeedbackCode) {
		this.snowPrbU_FeedbackCode = snowPrbU_FeedbackCode;
	}

	public String getSnowPrbU_FeedbackCodeHandling() {
		return snowPrbU_FeedbackCodeHandling;
	}

	public void setSnowPrbU_FeedbackCodeHandling(String snowPrbU_FeedbackCodeHandling) {
		this.snowPrbU_FeedbackCodeHandling = snowPrbU_FeedbackCodeHandling;
	}

	public String getSnowPrbU_FirstDeadline() {
		return snowPrbU_FirstDeadline;
	}

	public void setSnowPrbU_FirstDeadline(String snowPrbU_FirstDeadline) {
		this.snowPrbU_FirstDeadline = snowPrbU_FirstDeadline;
	}

	public String getSnowPrbU_FixOptions() {
		return snowPrbU_FixOptions;
	}

	public void setSnowPrbU_FixOptions(String snowPrbU_FixOptions) {
		this.snowPrbU_FixOptions = snowPrbU_FixOptions;
	}

	public String getSnowPrbU_FixedOnTime() {
		return snowPrbU_FixedOnTime;
	}

	public void setSnowPrbU_FixedOnTime(String snowPrbU_FixedOnTime) {
		this.snowPrbU_FixedOnTime = snowPrbU_FixedOnTime;
	}

	public String getSnowPrbU_Folder() {
		return snowPrbU_Folder;
	}

	public void setSnowPrbU_Folder(String snowPrbU_Folder) {
		this.snowPrbU_Folder = snowPrbU_Folder;
	}

	public String getSnowPrbU_Frequency() {
		return snowPrbU_Frequency;
	}

	public void setSnowPrbU_Frequency(String snowPrbU_Frequency) {
		this.snowPrbU_Frequency = snowPrbU_Frequency;
	}

	public String getSnowPrbU_HpException() {
		return snowPrbU_HpException;
	}

	public void setSnowPrbU_HpException(String snowPrbU_HpException) {
		this.snowPrbU_HpException = snowPrbU_HpException;
	}

	public String getSnowPrbU_IcsImpact() {
		return snowPrbU_IcsImpact;
	}

	public void setSnowPrbU_IcsImpact(String snowPrbU_IcsImpact) {
		this.snowPrbU_IcsImpact = snowPrbU_IcsImpact;
	}

	public String getSnowPrbU_ImpBreakdown() {
		return snowPrbU_ImpBreakdown;
	}

	public void setSnowPrbU_ImpBreakdown(String snowPrbU_ImpBreakdown) {
		this.snowPrbU_ImpBreakdown = snowPrbU_ImpBreakdown;
	}

	public String getSnowPrbU_ImplementationEta() {
		return snowPrbU_ImplementationEta;
	}

	public void setSnowPrbU_ImplementationEta(String snowPrbU_ImplementationEta) {
		this.snowPrbU_ImplementationEta = snowPrbU_ImplementationEta;
	}

	public String getSnowPrbU_InfosysException() {
		return snowPrbU_InfosysException;
	}

	public void setSnowPrbU_InfosysException(String snowPrbU_InfosysException) {
		this.snowPrbU_InfosysException = snowPrbU_InfosysException;
	}

	public String getSnowPrbU_InitialAssignment() {
		return snowPrbU_InitialAssignment;
	}

	public void setSnowPrbU_InitialAssignment(String snowPrbU_InitialAssignment) {
		this.snowPrbU_InitialAssignment = snowPrbU_InitialAssignment;
	}

	public String getSnowPrbU_Instructions() {
		return snowPrbU_Instructions;
	}

	public void setSnowPrbU_Instructions(String snowPrbU_Instructions) {
		this.snowPrbU_Instructions = snowPrbU_Instructions;
	}

	public String getSnowPrbU_InternalRef() {
		return snowPrbU_InternalRef;
	}

	public void setSnowPrbU_InternalRef(String snowPrbU_InternalRef) {
		this.snowPrbU_InternalRef = snowPrbU_InternalRef;
	}

	public String getSnowPrbU_ItilWatchList() {
		return snowPrbU_ItilWatchList;
	}

	public void setSnowPrbU_ItilWatchList(String snowPrbU_ItilWatchList) {
		this.snowPrbU_ItilWatchList = snowPrbU_ItilWatchList;
	}

	public String getSnowPrbU_KnowledgeArticle() {
		return snowPrbU_KnowledgeArticle;
	}

	public void setSnowPrbU_KnowledgeArticle(String snowPrbU_KnowledgeArticle) {
		this.snowPrbU_KnowledgeArticle = snowPrbU_KnowledgeArticle;
	}

	public String getSnowPrbU_KnowledgeAvailable() {
		return snowPrbU_KnowledgeAvailable;
	}

	public void setSnowPrbU_KnowledgeAvailable(String snowPrbU_KnowledgeAvailable) {
		this.snowPrbU_KnowledgeAvailable = snowPrbU_KnowledgeAvailable;
	}

	public String getSnowPrbU_KnowledgeCode() {
		return snowPrbU_KnowledgeCode;
	}

	public void setSnowPrbU_KnowledgeCode(String snowPrbU_KnowledgeCode) {
		this.snowPrbU_KnowledgeCode = snowPrbU_KnowledgeCode;
	}

	public String getSnowPrbU_KnowledgeComments() {
		return snowPrbU_KnowledgeComments;
	}

	public void setSnowPrbU_KnowledgeComments(String snowPrbU_KnowledgeComments) {
		this.snowPrbU_KnowledgeComments = snowPrbU_KnowledgeComments;
	}

	public String getSnowPrbU_KnowledgeFound() {
		return snowPrbU_KnowledgeFound;
	}

	public void setSnowPrbU_KnowledgeFound(String snowPrbU_KnowledgeFound) {
		this.snowPrbU_KnowledgeFound = snowPrbU_KnowledgeFound;
	}

	public String getSnowPrbU_KnowledgeUser() {
		return snowPrbU_KnowledgeUser;
	}

	public void setSnowPrbU_KnowledgeUser(String snowPrbU_KnowledgeUser) {
		this.snowPrbU_KnowledgeUser = snowPrbU_KnowledgeUser;
	}

	public String getSnowPrbU_KnownError() {
		return snowPrbU_KnownError;
	}

	public void setSnowPrbU_KnownError(String snowPrbU_KnownError) {
		this.snowPrbU_KnownError = snowPrbU_KnownError;
	}

	public String getSnowPrbU_KnownErrorDatabaseUrl() {
		return snowPrbU_KnownErrorDatabaseUrl;
	}

	public void setSnowPrbU_KnownErrorDatabaseUrl(String snowPrbU_KnownErrorDatabaseUrl) {
		this.snowPrbU_KnownErrorDatabaseUrl = snowPrbU_KnownErrorDatabaseUrl;
	}

	public String getSnowPrbU_KnownErrorLocation() {
		return snowPrbU_KnownErrorLocation;
	}

	public void setSnowPrbU_KnownErrorLocation(String snowPrbU_KnownErrorLocation) {
		this.snowPrbU_KnownErrorLocation = snowPrbU_KnownErrorLocation;
	}

	public String getSnowPrbU_KnownErrorUrl() {
		return snowPrbU_KnownErrorUrl;
	}

	public void setSnowPrbU_KnownErrorUrl(String snowPrbU_KnownErrorUrl) {
		this.snowPrbU_KnownErrorUrl = snowPrbU_KnownErrorUrl;
	}

	public String getSnowPrbU_LastOccurrence() {
		return snowPrbU_LastOccurrence;
	}

	public void setSnowPrbU_LastOccurrence(String snowPrbU_LastOccurrence) {
		this.snowPrbU_LastOccurrence = snowPrbU_LastOccurrence;
	}

	public String getSnowPrbU_LateImpReason() {
		return snowPrbU_LateImpReason;
	}

	public void setSnowPrbU_LateImpReason(String snowPrbU_LateImpReason) {
		this.snowPrbU_LateImpReason = snowPrbU_LateImpReason;
	}

	public String getSnowPrbU_LocalResp() {
		return snowPrbU_LocalResp;
	}

	public void setSnowPrbU_LocalResp(String snowPrbU_LocalResp) {
		this.snowPrbU_LocalResp = snowPrbU_LocalResp;
	}

	public String getSnowPrbU_ManagementAuditComments() {
		return snowPrbU_ManagementAuditComments;
	}

	public void setSnowPrbU_ManagementAuditComments(String snowPrbU_ManagementAuditComments) {
		this.snowPrbU_ManagementAuditComments = snowPrbU_ManagementAuditComments;
	}

	public String getSnowPrbU_ManagementComments() {
		return snowPrbU_ManagementComments;
	}

	public void setSnowPrbU_ManagementComments(String snowPrbU_ManagementComments) {
		this.snowPrbU_ManagementComments = snowPrbU_ManagementComments;
	}

	public String getSnowPrbU_MissingCi() {
		return snowPrbU_MissingCi;
	}

	public void setSnowPrbU_MissingCi(String snowPrbU_MissingCi) {
		this.snowPrbU_MissingCi = snowPrbU_MissingCi;
	}

	public String getSnowPrbU_MissingCiFlag() {
		return snowPrbU_MissingCiFlag;
	}

	public void setSnowPrbU_MissingCiFlag(String snowPrbU_MissingCiFlag) {
		this.snowPrbU_MissingCiFlag = snowPrbU_MissingCiFlag;
	}

	public String getSnowPrbU_ModifiedPeriod() {
		return snowPrbU_ModifiedPeriod;
	}

	public void setSnowPrbU_ModifiedPeriod(String snowPrbU_ModifiedPeriod) {
		this.snowPrbU_ModifiedPeriod = snowPrbU_ModifiedPeriod;
	}

	public String getSnowPrbU_MonitorReviewDate() {
		return snowPrbU_MonitorReviewDate;
	}

	public void setSnowPrbU_MonitorReviewDate(String snowPrbU_MonitorReviewDate) {
		this.snowPrbU_MonitorReviewDate = snowPrbU_MonitorReviewDate;
	}

	public String getSnowPrbU_Name() {
		return snowPrbU_Name;
	}

	public void setSnowPrbU_Name(String snowPrbU_Name) {
		this.snowPrbU_Name = snowPrbU_Name;
	}

	public String getSnowPrbU_Occurrence() {
		return snowPrbU_Occurrence;
	}

	public void setSnowPrbU_Occurrence(String snowPrbU_Occurrence) {
		this.snowPrbU_Occurrence = snowPrbU_Occurrence;
	}

	public String getSnowPrbU_OpenedPeriod() {
		return snowPrbU_OpenedPeriod;
	}

	public void setSnowPrbU_OpenedPeriod(String snowPrbU_OpenedPeriod) {
		this.snowPrbU_OpenedPeriod = snowPrbU_OpenedPeriod;
	}

	public String getSnowPrbU_OutageDuration() {
		return snowPrbU_OutageDuration;
	}

	public void setSnowPrbU_OutageDuration(String snowPrbU_OutageDuration) {
		this.snowPrbU_OutageDuration = snowPrbU_OutageDuration;
	}

	public String getSnowPrbU_OutsourceAssignedOut() {
		return snowPrbU_OutsourceAssignedOut;
	}

	public void setSnowPrbU_OutsourceAssignedOut(String snowPrbU_OutsourceAssignedOut) {
		this.snowPrbU_OutsourceAssignedOut = snowPrbU_OutsourceAssignedOut;
	}

	public String getSnowPrbU_OutsourceAssignee() {
		return snowPrbU_OutsourceAssignee;
	}

	public void setSnowPrbU_OutsourceAssignee(String snowPrbU_OutsourceAssignee) {
		this.snowPrbU_OutsourceAssignee = snowPrbU_OutsourceAssignee;
	}

	public String getSnowPrbU_OutsourceId() {
		return snowPrbU_OutsourceId;
	}

	public void setSnowPrbU_OutsourceId(String snowPrbU_OutsourceId) {
		this.snowPrbU_OutsourceId = snowPrbU_OutsourceId;
	}

	public String getSnowPrbU_OutsourceIntegration() {
		return snowPrbU_OutsourceIntegration;
	}

	public void setSnowPrbU_OutsourceIntegration(String snowPrbU_OutsourceIntegration) {
		this.snowPrbU_OutsourceIntegration = snowPrbU_OutsourceIntegration;
	}

	public String getSnowPrbU_OutsourceModule() {
		return snowPrbU_OutsourceModule;
	}

	public void setSnowPrbU_OutsourceModule(String snowPrbU_OutsourceModule) {
		this.snowPrbU_OutsourceModule = snowPrbU_OutsourceModule;
	}

	public String getSnowPrbU_OutsourceResponse() {
		return snowPrbU_OutsourceResponse;
	}

	public void setSnowPrbU_OutsourceResponse(String snowPrbU_OutsourceResponse) {
		this.snowPrbU_OutsourceResponse = snowPrbU_OutsourceResponse;
	}

	public String getSnowPrbU_OutsourceResult() {
		return snowPrbU_OutsourceResult;
	}

	public void setSnowPrbU_OutsourceResult(String snowPrbU_OutsourceResult) {
		this.snowPrbU_OutsourceResult = snowPrbU_OutsourceResult;
	}

	public String getSnowPrbU_OutsourceStatus() {
		return snowPrbU_OutsourceStatus;
	}

	public void setSnowPrbU_OutsourceStatus(String snowPrbU_OutsourceStatus) {
		this.snowPrbU_OutsourceStatus = snowPrbU_OutsourceStatus;
	}

	public String getSnowPrbU_OutsourceTeam() {
		return snowPrbU_OutsourceTeam;
	}

	public void setSnowPrbU_OutsourceTeam(String snowPrbU_OutsourceTeam) {
		this.snowPrbU_OutsourceTeam = snowPrbU_OutsourceTeam;
	}

	public String getSnowPrbU_Override1() {
		return snowPrbU_Override1;
	}

	public void setSnowPrbU_Override1(String snowPrbU_Override1) {
		this.snowPrbU_Override1 = snowPrbU_Override1;
	}

	public String getSnowPrbU_Person() {
		return snowPrbU_Person;
	}

	public void setSnowPrbU_Person(String snowPrbU_Person) {
		this.snowPrbU_Person = snowPrbU_Person;
	}

	public String getSnowPrbU_PersonAudited() {
		return snowPrbU_PersonAudited;
	}

	public void setSnowPrbU_PersonAudited(String snowPrbU_PersonAudited) {
		this.snowPrbU_PersonAudited = snowPrbU_PersonAudited;
	}

	public String getSnowPrbU_PersonAuditing() {
		return snowPrbU_PersonAuditing;
	}

	public void setSnowPrbU_PersonAuditing(String snowPrbU_PersonAuditing) {
		this.snowPrbU_PersonAuditing = snowPrbU_PersonAuditing;
	}

	public String getSnowPrbU_Phone() {
		return snowPrbU_Phone;
	}

	public void setSnowPrbU_Phone(String snowPrbU_Phone) {
		this.snowPrbU_Phone = snowPrbU_Phone;
	}

	public String getSnowPrbU_PickupDuration() {
		return snowPrbU_PickupDuration;
	}

	public void setSnowPrbU_PickupDuration(String snowPrbU_PickupDuration) {
		this.snowPrbU_PickupDuration = snowPrbU_PickupDuration;
	}

	public String getSnowPrbU_PlannedEffort() {
		return snowPrbU_PlannedEffort;
	}

	public void setSnowPrbU_PlannedEffort(String snowPrbU_PlannedEffort) {
		this.snowPrbU_PlannedEffort = snowPrbU_PlannedEffort;
	}

	public String getSnowPrbU_PlannedImplementationWeek() {
		return snowPrbU_PlannedImplementationWeek;
	}

	public void setSnowPrbU_PlannedImplementationWeek(String snowPrbU_PlannedImplementationWeek) {
		this.snowPrbU_PlannedImplementationWeek = snowPrbU_PlannedImplementationWeek;
	}

	public String getSnowPrbU_PmVerify() {
		return snowPrbU_PmVerify;
	}

	public void setSnowPrbU_PmVerify(String snowPrbU_PmVerify) {
		this.snowPrbU_PmVerify = snowPrbU_PmVerify;
	}

	public String getSnowPrbU_PmWorkgroup() {
		return snowPrbU_PmWorkgroup;
	}

	public void setSnowPrbU_PmWorkgroup(String snowPrbU_PmWorkgroup) {
		this.snowPrbU_PmWorkgroup = snowPrbU_PmWorkgroup;
	}

	public String getSnowPrbU_PmWritable() {
		return snowPrbU_PmWritable;
	}

	public void setSnowPrbU_PmWritable(String snowPrbU_PmWritable) {
		this.snowPrbU_PmWritable = snowPrbU_PmWritable;
	}

	public String getSnowPrbU_PreviousGroup() {
		return snowPrbU_PreviousGroup;
	}

	public void setSnowPrbU_PreviousGroup(String snowPrbU_PreviousGroup) {
		this.snowPrbU_PreviousGroup = snowPrbU_PreviousGroup;
	}

	public String getSnowPrbU_PreviousStatus() {
		return snowPrbU_PreviousStatus;
	}

	public void setSnowPrbU_PreviousStatus(String snowPrbU_PreviousStatus) {
		this.snowPrbU_PreviousStatus = snowPrbU_PreviousStatus;
	}

	public String getSnowPrbU_PriorityAmendmentExplanati() {
		return snowPrbU_PriorityAmendmentExplanati;
	}

	public void setSnowPrbU_PriorityAmendmentExplanati(String snowPrbU_PriorityAmendmentExplanati) {
		this.snowPrbU_PriorityAmendmentExplanati = snowPrbU_PriorityAmendmentExplanati;
	}

	public String getSnowPrbU_ProblemBoardRecommendation() {
		return snowPrbU_ProblemBoardRecommendation;
	}

	public void setSnowPrbU_ProblemBoardRecommendation(String snowPrbU_ProblemBoardRecommendation) {
		this.snowPrbU_ProblemBoardRecommendation = snowPrbU_ProblemBoardRecommendation;
	}

	public String getSnowPrbU_ProblemClosed() {
		return snowPrbU_ProblemClosed;
	}

	public void setSnowPrbU_ProblemClosed(String snowPrbU_ProblemClosed) {
		this.snowPrbU_ProblemClosed = snowPrbU_ProblemClosed;
	}

	public String getSnowPrbU_ProblemImpact() {
		return snowPrbU_ProblemImpact;
	}

	public void setSnowPrbU_ProblemImpact(String snowPrbU_ProblemImpact) {
		this.snowPrbU_ProblemImpact = snowPrbU_ProblemImpact;
	}

	public String getSnowPrbU_ProblemLite() {
		return snowPrbU_ProblemLite;
	}

	public void setSnowPrbU_ProblemLite(String snowPrbU_ProblemLite) {
		this.snowPrbU_ProblemLite = snowPrbU_ProblemLite;
	}

	public String getSnowPrbU_ProblemManager() {
		return snowPrbU_ProblemManager;
	}

	public void setSnowPrbU_ProblemManager(String snowPrbU_ProblemManager) {
		this.snowPrbU_ProblemManager = snowPrbU_ProblemManager;
	}

	public String getSnowPrbU_ProblemOwnerComments() {
		return snowPrbU_ProblemOwnerComments;
	}

	public void setSnowPrbU_ProblemOwnerComments(String snowPrbU_ProblemOwnerComments) {
		this.snowPrbU_ProblemOwnerComments = snowPrbU_ProblemOwnerComments;
	}

	public String getSnowPrbU_ProgReviewDate() {
		return snowPrbU_ProgReviewDate;
	}

	public void setSnowPrbU_ProgReviewDate(String snowPrbU_ProgReviewDate) {
		this.snowPrbU_ProgReviewDate = snowPrbU_ProgReviewDate;
	}

	public String getSnowPrbU_ProposedSolution() {
		return snowPrbU_ProposedSolution;
	}

	public void setSnowPrbU_ProposedSolution(String snowPrbU_ProposedSolution) {
		this.snowPrbU_ProposedSolution = snowPrbU_ProposedSolution;
	}

	public String getSnowPrbU_QueryCount() {
		return snowPrbU_QueryCount;
	}

	public void setSnowPrbU_QueryCount(String snowPrbU_QueryCount) {
		this.snowPrbU_QueryCount = snowPrbU_QueryCount;
	}

	public String getSnowPrbU_RcaInProgressTime() {
		return snowPrbU_RcaInProgressTime;
	}

	public void setSnowPrbU_RcaInProgressTime(String snowPrbU_RcaInProgressTime) {
		this.snowPrbU_RcaInProgressTime = snowPrbU_RcaInProgressTime;
	}

	public String getSnowPrbU_RcaState() {
		return snowPrbU_RcaState;
	}

	public void setSnowPrbU_RcaState(String snowPrbU_RcaState) {
		this.snowPrbU_RcaState = snowPrbU_RcaState;
	}

	public String getSnowPrbU_ReasonForException() {
		return snowPrbU_ReasonForException;
	}

	public void setSnowPrbU_ReasonForException(String snowPrbU_ReasonForException) {
		this.snowPrbU_ReasonForException = snowPrbU_ReasonForException;
	}

	public String getSnowPrbU_RegionImpacted() {
		return snowPrbU_RegionImpacted;
	}

	public void setSnowPrbU_RegionImpacted(String snowPrbU_RegionImpacted) {
		this.snowPrbU_RegionImpacted = snowPrbU_RegionImpacted;
	}

	public String getSnowPrbU_RelatedIncidents() {
		return snowPrbU_RelatedIncidents;
	}

	public void setSnowPrbU_RelatedIncidents(String snowPrbU_RelatedIncidents) {
		this.snowPrbU_RelatedIncidents = snowPrbU_RelatedIncidents;
	}

	public String getSnowPrbU_ReopenCount() {
		return snowPrbU_ReopenCount;
	}

	public void setSnowPrbU_ReopenCount(String snowPrbU_ReopenCount) {
		this.snowPrbU_ReopenCount = snowPrbU_ReopenCount;
	}

	public String getSnowPrbU_ReopenedDate() {
		return snowPrbU_ReopenedDate;
	}

	public void setSnowPrbU_ReopenedDate(String snowPrbU_ReopenedDate) {
		this.snowPrbU_ReopenedDate = snowPrbU_ReopenedDate;
	}

	public String getSnowPrbU_Resolution() {
		return snowPrbU_Resolution;
	}

	public void setSnowPrbU_Resolution(String snowPrbU_Resolution) {
		this.snowPrbU_Resolution = snowPrbU_Resolution;
	}

	public String getSnowPrbU_ResolutionOverride() {
		return snowPrbU_ResolutionOverride;
	}

	public void setSnowPrbU_ResolutionOverride(String snowPrbU_ResolutionOverride) {
		this.snowPrbU_ResolutionOverride = snowPrbU_ResolutionOverride;
	}

	public String getSnowPrbU_ResolvedAt() {
		return snowPrbU_ResolvedAt;
	}

	public void setSnowPrbU_ResolvedAt(String snowPrbU_ResolvedAt) {
		this.snowPrbU_ResolvedAt = snowPrbU_ResolvedAt;
	}

	public String getSnowPrbU_ResolvedBy() {
		return snowPrbU_ResolvedBy;
	}

	public void setSnowPrbU_ResolvedBy(String snowPrbU_ResolvedBy) {
		this.snowPrbU_ResolvedBy = snowPrbU_ResolvedBy;
	}

	public String getSnowPrbU_ResolvedByWorkgroup() {
		return snowPrbU_ResolvedByWorkgroup;
	}

	public void setSnowPrbU_ResolvedByWorkgroup(String snowPrbU_ResolvedByWorkgroup) {
		this.snowPrbU_ResolvedByWorkgroup = snowPrbU_ResolvedByWorkgroup;
	}

	public String getSnowPrbU_Resolver() {
		return snowPrbU_Resolver;
	}

	public void setSnowPrbU_Resolver(String snowPrbU_Resolver) {
		this.snowPrbU_Resolver = snowPrbU_Resolver;
	}

	public String getSnowPrbU_ResponseFlag() {
		return snowPrbU_ResponseFlag;
	}

	public void setSnowPrbU_ResponseFlag(String snowPrbU_ResponseFlag) {
		this.snowPrbU_ResponseFlag = snowPrbU_ResponseFlag;
	}

	public String getSnowPrbU_ResponseOverride() {
		return snowPrbU_ResponseOverride;
	}

	public void setSnowPrbU_ResponseOverride(String snowPrbU_ResponseOverride) {
		this.snowPrbU_ResponseOverride = snowPrbU_ResponseOverride;
	}

	public String getSnowPrbU_RootCause() {
		return snowPrbU_RootCause;
	}

	public void setSnowPrbU_RootCause(String snowPrbU_RootCause) {
		this.snowPrbU_RootCause = snowPrbU_RootCause;
	}

	public String getSnowPrbU_SaveAsDraft() {
		return snowPrbU_SaveAsDraft;
	}

	public void setSnowPrbU_SaveAsDraft(String snowPrbU_SaveAsDraft) {
		this.snowPrbU_SaveAsDraft = snowPrbU_SaveAsDraft;
	}

	public String getSnowPrbU_SavedCount() {
		return snowPrbU_SavedCount;
	}

	public void setSnowPrbU_SavedCount(String snowPrbU_SavedCount) {
		this.snowPrbU_SavedCount = snowPrbU_SavedCount;
	}

	public String getSnowPrbU_Scope() {
		return snowPrbU_Scope;
	}

	public void setSnowPrbU_Scope(String snowPrbU_Scope) {
		this.snowPrbU_Scope = snowPrbU_Scope;
	}

	public String getSnowPrbU_SecondDeadline() {
		return snowPrbU_SecondDeadline;
	}

	public void setSnowPrbU_SecondDeadline(String snowPrbU_SecondDeadline) {
		this.snowPrbU_SecondDeadline = snowPrbU_SecondDeadline;
	}

	public String getSnowPrbU_SelectApplication() {
		return snowPrbU_SelectApplication;
	}

	public void setSnowPrbU_SelectApplication(String snowPrbU_SelectApplication) {
		this.snowPrbU_SelectApplication = snowPrbU_SelectApplication;
	}

	public String getSnowPrbU_SelectEuc() {
		return snowPrbU_SelectEuc;
	}

	public void setSnowPrbU_SelectEuc(String snowPrbU_SelectEuc) {
		this.snowPrbU_SelectEuc = snowPrbU_SelectEuc;
	}

	public String getSnowPrbU_SelectInfrastructure() {
		return snowPrbU_SelectInfrastructure;
	}

	public void setSnowPrbU_SelectInfrastructure(String snowPrbU_SelectInfrastructure) {
		this.snowPrbU_SelectInfrastructure = snowPrbU_SelectInfrastructure;
	}

	public String getSnowPrbU_SelectNetwork() {
		return snowPrbU_SelectNetwork;
	}

	public void setSnowPrbU_SelectNetwork(String snowPrbU_SelectNetwork) {
		this.snowPrbU_SelectNetwork = snowPrbU_SelectNetwork;
	}

	public String getSnowPrbU_ServerName() {
		return snowPrbU_ServerName;
	}

	public void setSnowPrbU_ServerName(String snowPrbU_ServerName) {
		this.snowPrbU_ServerName = snowPrbU_ServerName;
	}

	public String getSnowPrbU_SlaFailureWorkgroup() {
		return snowPrbU_SlaFailureWorkgroup;
	}

	public void setSnowPrbU_SlaFailureWorkgroup(String snowPrbU_SlaFailureWorkgroup) {
		this.snowPrbU_SlaFailureWorkgroup = snowPrbU_SlaFailureWorkgroup;
	}

	public String getSnowPrbU_SlaState() {
		return snowPrbU_SlaState;
	}

	public void setSnowPrbU_SlaState(String snowPrbU_SlaState) {
		this.snowPrbU_SlaState = snowPrbU_SlaState;
	}

	public String getSnowPrbU_SlfApprover() {
		return snowPrbU_SlfApprover;
	}

	public void setSnowPrbU_SlfApprover(String snowPrbU_SlfApprover) {
		this.snowPrbU_SlfApprover = snowPrbU_SlfApprover;
	}

	public String getSnowPrbU_SlfComponent() {
		return snowPrbU_SlfComponent;
	}

	public void setSnowPrbU_SlfComponent(String snowPrbU_SlfComponent) {
		this.snowPrbU_SlfComponent = snowPrbU_SlfComponent;
	}

	public String getSnowPrbU_SlfReason() {
		return snowPrbU_SlfReason;
	}

	public void setSnowPrbU_SlfReason(String snowPrbU_SlfReason) {
		this.snowPrbU_SlfReason = snowPrbU_SlfReason;
	}

	public String getSnowPrbU_SlfReviewDate() {
		return snowPrbU_SlfReviewDate;
	}

	public void setSnowPrbU_SlfReviewDate(String snowPrbU_SlfReviewDate) {
		this.snowPrbU_SlfReviewDate = snowPrbU_SlfReviewDate;
	}

	public String getSnowPrbU_SolutionApprovedBy() {
		return snowPrbU_SolutionApprovedBy;
	}

	public void setSnowPrbU_SolutionApprovedBy(String snowPrbU_SolutionApprovedBy) {
		this.snowPrbU_SolutionApprovedBy = snowPrbU_SolutionApprovedBy;
	}

	public String getSnowPrbU_SrtState() {
		return snowPrbU_SrtState;
	}

	public void setSnowPrbU_SrtState(String snowPrbU_SrtState) {
		this.snowPrbU_SrtState = snowPrbU_SrtState;
	}

	public String getSnowPrbU_SspForm() {
		return snowPrbU_SspForm;
	}

	public void setSnowPrbU_SspForm(String snowPrbU_SspForm) {
		this.snowPrbU_SspForm = snowPrbU_SspForm;
	}

	public String getSnowPrbU_Subcategory() {
		return snowPrbU_Subcategory;
	}

	public void setSnowPrbU_Subcategory(String snowPrbU_Subcategory) {
		this.snowPrbU_Subcategory = snowPrbU_Subcategory;
	}

	public String getSnowPrbU_Subclassification() {
		return snowPrbU_Subclassification;
	}

	public void setSnowPrbU_Subclassification(String snowPrbU_Subclassification) {
		this.snowPrbU_Subclassification = snowPrbU_Subclassification;
	}

	public String getSnowPrbU_Subject() {
		return snowPrbU_Subject;
	}

	public void setSnowPrbU_Subject(String snowPrbU_Subject) {
		this.snowPrbU_Subject = snowPrbU_Subject;
	}

	public String getSnowPrbU_SupportStructure() {
		return snowPrbU_SupportStructure;
	}

	public void setSnowPrbU_SupportStructure(String snowPrbU_SupportStructure) {
		this.snowPrbU_SupportStructure = snowPrbU_SupportStructure;
	}

	public String getSnowPrbU_Symptoms() {
		return snowPrbU_Symptoms;
	}

	public void setSnowPrbU_Symptoms(String snowPrbU_Symptoms) {
		this.snowPrbU_Symptoms = snowPrbU_Symptoms;
	}

	public String getSnowPrbU_TargetFixDate() {
		return snowPrbU_TargetFixDate;
	}

	public void setSnowPrbU_TargetFixDate(String snowPrbU_TargetFixDate) {
		this.snowPrbU_TargetFixDate = snowPrbU_TargetFixDate;
	}

	public String getSnowPrbU_TaskType() {
		return snowPrbU_TaskType;
	}

	public void setSnowPrbU_TaskType(String snowPrbU_TaskType) {
		this.snowPrbU_TaskType = snowPrbU_TaskType;
	}

	public String getSnowPrbU_Template() {
		return snowPrbU_Template;
	}

	public void setSnowPrbU_Template(String snowPrbU_Template) {
		this.snowPrbU_Template = snowPrbU_Template;
	}

	public String getSnowPrbU_ThirdLineComments() {
		return snowPrbU_ThirdLineComments;
	}

	public void setSnowPrbU_ThirdLineComments(String snowPrbU_ThirdLineComments) {
		this.snowPrbU_ThirdLineComments = snowPrbU_ThirdLineComments;
	}

	public String getSnowPrbU_ThirdLineDate() {
		return snowPrbU_ThirdLineDate;
	}

	public void setSnowPrbU_ThirdLineDate(String snowPrbU_ThirdLineDate) {
		this.snowPrbU_ThirdLineDate = snowPrbU_ThirdLineDate;
	}

	public String getSnowPrbU_ThirdPartyReference() {
		return snowPrbU_ThirdPartyReference;
	}

	public void setSnowPrbU_ThirdPartyReference(String snowPrbU_ThirdPartyReference) {
		this.snowPrbU_ThirdPartyReference = snowPrbU_ThirdPartyReference;
	}

	public String getSnowPrbU_TimeToAuth() {
		return snowPrbU_TimeToAuth;
	}

	public void setSnowPrbU_TimeToAuth(String snowPrbU_TimeToAuth) {
		this.snowPrbU_TimeToAuth = snowPrbU_TimeToAuth;
	}

	public String getSnowPrbU_TimeToClose() {
		return snowPrbU_TimeToClose;
	}

	public void setSnowPrbU_TimeToClose(String snowPrbU_TimeToClose) {
		this.snowPrbU_TimeToClose = snowPrbU_TimeToClose;
	}

	public String getSnowPrbU_UsersAffected() {
		return snowPrbU_UsersAffected;
	}

	public void setSnowPrbU_UsersAffected(String snowPrbU_UsersAffected) {
		this.snowPrbU_UsersAffected = snowPrbU_UsersAffected;
	}

	public String getSnowPrbU_VerizonException() {
		return snowPrbU_VerizonException;
	}

	public void setSnowPrbU_VerizonException(String snowPrbU_VerizonException) {
		this.snowPrbU_VerizonException = snowPrbU_VerizonException;
	}

	public String getSnowPrbU_WebUpdate() {
		return snowPrbU_WebUpdate;
	}

	public void setSnowPrbU_WebUpdate(String snowPrbU_WebUpdate) {
		this.snowPrbU_WebUpdate = snowPrbU_WebUpdate;
	}

	public String getSnowPrbU_Workaround() {
		return snowPrbU_Workaround;
	}

	public void setSnowPrbU_Workaround(String snowPrbU_Workaround) {
		this.snowPrbU_Workaround = snowPrbU_Workaround;
	}

	public String getSnowPrbU_WorkaroundSummary() {
		return snowPrbU_WorkaroundSummary;
	}

	public void setSnowPrbU_WorkaroundSummary(String snowPrbU_WorkaroundSummary) {
		this.snowPrbU_WorkaroundSummary = snowPrbU_WorkaroundSummary;
	}

	public String getSnowPrbUponApproval() {
		return snowPrbUponApproval;
	}

	public void setSnowPrbUponApproval(String snowPrbUponApproval) {
		this.snowPrbUponApproval = snowPrbUponApproval;
	}

	public String getSnowPrbUponReject() {
		return snowPrbUponReject;
	}

	public void setSnowPrbUponReject(String snowPrbUponReject) {
		this.snowPrbUponReject = snowPrbUponReject;
	}

	public String getSnowPrbUrgency() {
		return snowPrbUrgency;
	}

	public void setSnowPrbUrgency(String snowPrbUrgency) {
		this.snowPrbUrgency = snowPrbUrgency;
	}

	public String getSnowPrbUserInput() {
		return snowPrbUserInput;
	}

	public void setSnowPrbUserInput(String snowPrbUserInput) {
		this.snowPrbUserInput = snowPrbUserInput;
	}

	public String getSnowPrbWatchList() {
		return snowPrbWatchList;
	}

	public void setSnowPrbWatchList(String snowPrbWatchList) {
		this.snowPrbWatchList = snowPrbWatchList;
	}

	public String getSnowPrbWfActivity() {
		return snowPrbWfActivity;
	}

	public void setSnowPrbWfActivity(String snowPrbWfActivity) {
		this.snowPrbWfActivity = snowPrbWfActivity;
	}

	public String getSnowPrbWorkAround() {
		return snowPrbWorkAround;
	}

	public void setSnowPrbWorkAround(String snowPrbWorkAround) {
		this.snowPrbWorkAround = snowPrbWorkAround;
	}

	public String getSnowPrbWorkEffort() {
		return snowPrbWorkEffort;
	}

	public void setSnowPrbWorkEffort(String snowPrbWorkEffort) {
		this.snowPrbWorkEffort = snowPrbWorkEffort;
	}

	public String getSnowPrbWorkEnd() {
		return snowPrbWorkEnd;
	}

	public void setSnowPrbWorkEnd(String snowPrbWorkEnd) {
		this.snowPrbWorkEnd = snowPrbWorkEnd;
	}

	public String getSnowPrbWorkNotes() {
		return snowPrbWorkNotes;
	}

	public void setSnowPrbWorkNotes(String snowPrbWorkNotes) {
		this.snowPrbWorkNotes = snowPrbWorkNotes;
	}

	public String getSnowPrbWorkStart() {
		return snowPrbWorkStart;
	}

	public void setSnowPrbWorkStart(String snowPrbWorkStart) {
		this.snowPrbWorkStart = snowPrbWorkStart;
	}

}
