package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.fedex.emea.sd.da.objects.ServerAvailabilities;

public class ServerAvailabilitiesRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		ServerAvailabilities serverAvailability = new ServerAvailabilities();
		
		serverAvailability.setServerName(rs.getString("SERVERNAME"));
		serverAvailability.setServerDc(rs.getString("SERVERDC"));
		serverAvailability.setServerAlive(rs.getBoolean("ALIVE"));
		serverAvailability.setLastCheckTime(rs.getTimestamp("LASTCHECKTIME"));
		serverAvailability.setOldStatusTime(rs.getTimestamp("OLDSTATUSTIME"));
		serverAvailability.setStatusChangeTime(rs.getTimestamp("STATUSCHANGETIME"));
		serverAvailability.setServerSoftwareVersion(rs.getString("SERVERSOFTWAREVERSION"));
		serverAvailability.setServerStatus(rs.getString("SERVERSTATUS"));
		serverAvailability.setServerId(rs.getString("SERVERID"));
		
		return serverAvailability;
	}

}
