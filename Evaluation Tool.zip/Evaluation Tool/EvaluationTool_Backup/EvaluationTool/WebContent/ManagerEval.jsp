<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="java.io.*"%>
    <%@page import="java.util.*"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<script type="text/javascript" language="javascript">
	
	function managerEval() {
		return true;
	}

	var reg = new RegExp('^\\d+$');

  	function validate()
  	{
  	  	var m1 = document.getElementById("textMarks").value;
  	  	alert("Entered :"+m1);
  		return reg.test(m1);
  	}
	</script>
	<style>
	textarea{
  width: 40px;
  height: 40px;
  /* padding: 12px 20px;  */
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-family:Calibri; 
}
input[type=submit]{

background-color:#4B0082;
color:white;
padding:14px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:20%;
}
input[type=submit]:hover{
background-color:#7030a0;
}
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;
		
}
.dropdown {
  position: relative;
  display: inline-block;
  background-color: #4CAF50;
  color: black;
  padding: 1px;
  font-size: 20px;
  border: none;
  cursor: pointer;
  position: absolute;
  background-color: #f9f9f9;
  width : 300px;
  margin : 5px;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}
</style>
<title>Manager Evaluation Page</title>
</head>
<body>
	<div class="main"> 
     	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">TEST RESULTS</p></center>
   		</div>
     <form name="ResForm"  action="Results.jsp" method="post" onsubmit="return managerEval()"><br>
<%
		try {
			String dirName = "C:/Users/rajarama.kaniyoor/Documents/Evaluation Tool/Resources/";
			String fileName = dirName;
			boolean fileFound = false;
			File directoryPath = new File(dirName);
			String contents[] = directoryPath.list();
			String uId = request.getParameter("id");
			%>
				<input type="hidden" name="uId" value="<%=uId%>">
			<%
			for(int i=0; i<contents.length; i++) {
		         System.out.println(contents[i]);
		         System.out.println("uId"+uId);
		         
		         if(uId != null && contents[i].contains(uId))
		         {
		        	 fileName+= contents[i];
		        	 fileFound = true;
		        	 break;
		         }
		      }
			System.out.println("fileName :"+fileName);
			
			if(fileFound)
			{
				File file = new File(fileName);
				BufferedReader br = new BufferedReader(new FileReader(file));
				String st;
				int count = 0;
				String field = "";
				List<String> teamList = new ArrayList<String>();
				List<String> teamList1 = Arrays.asList("0","1");
				List<String> teamList2 = Arrays.asList("0","1","2");
				List<String> teamList3 = Arrays.asList("0","1","2","3");
				List<String> teamList4 = Arrays.asList("0","1","2","3","4");
				List<String> teamList5 = Arrays.asList("0","1","2","3","4","5");;
				
				while ((st = br.readLine()) != null)
				{
					if(!st.startsWith("MCQ Total"))
					{
						if (st.startsWith("User Answer"))
						{
							++count;
						%>
						<br>
						<label style="color:red;font-size:20px;font-family:Calibri;"><%=st %></label><br>
						<label style="color:red;font-size:15px;font-family:Calibri;">Marks obtained:</label>
						teamList = teamList4;
						<select id="textMarks" name="textMarks<%=count%>" class="dropdown"> <%
				        for(int i=0;i<teamList.size();i++) {
				        	field=teamList.get(i).toString();
				        	%> <option value="<%=field%>"> <%=field%> </option> <%			        
				        }%>
				    	</select>
						<%-- <textarea id="textMarks" name="textMarks<%=count%>" maxlength="1" onchange="validate()"></textarea> --%>
						
						<br>
						<input type="hidden" name="textMarks<%=count%>" value="<%=st%>">
						<% 
						}
						else if(st.endsWith("Questions"))
						{%>
						<label style="color:blue;font-size:20px;font-family:Calibri;"><%=st %></label><br>
						<%}
						else if(st.startsWith("Correct"))
						{%>
						<label style="color:green;font-size:20px;font-family:Calibri;"><%=st %></label><br>
						<%}
						else if(st.startsWith("Wrong"))
						{%>
						<label style="color:red;font-size:20px;font-family:Calibri;"><%=st %></label><br>
						<%}
						else
						{%>
							<label style="color:Black;font-size:15px;font-family:Calibri;"><%=st %></label><br>
						<% }
					}
					if(st.startsWith("MCQ Total"))
					{
						char mcqTot = st.charAt(st.length()-1);
						System.out.println("MCQQ Total:"+mcqTot);
					%>
						<input type="hidden" name="mcqTotal" value="<%=mcqTot%>">
					<%}
					
				}
				br.close();
		 	}
			
			else{
				%>
					<label>No data found for the user : <%=uId %></label>
				<%
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	%>
	<br><br>
<!-- <button id="submit" onclick="managerEval()" >Submit</button> -->
<input type="submit" name="page" value="submit">
<input type="hidden" name="page" value="submit"/>
</form>
<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>