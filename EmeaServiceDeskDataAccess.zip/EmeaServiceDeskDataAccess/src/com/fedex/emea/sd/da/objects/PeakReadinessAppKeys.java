package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class PeakReadinessAppKeys implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String cy;
	private String ni2AppId;
	private String symEaiId;
		
	public PeakReadinessAppKeys() {
	}
	
	public PeakReadinessAppKeys(String cy, String ni2AppId, String symEaiId) {
		this.cy       = cy;
		this.ni2AppId = ni2AppId;
		this.symEaiId = symEaiId;
	}
	
	public String getNi2AppId() {
		return ni2AppId;
	}

	public void setNi2AppId(String ni2AppId) {
		this.ni2AppId = ni2AppId;
	}

	public String getSymEaiId() {
		return symEaiId;
	}

	public void setSymEaiId(String symEaiId) {
		this.symEaiId = symEaiId;
	}

	public String getCy() {
		return cy;
	}

	public void setCy(String cy) {
		this.cy = cy;
	}	
}
