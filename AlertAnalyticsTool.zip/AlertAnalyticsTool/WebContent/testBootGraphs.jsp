<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@ page import="java.util.*,java.sql.*" %>
<!DOCTYPE html>

<%
Map<String, Integer> alltypeAlertData = new HashMap<>();
alltypeAlertData.put("Disconnect", 22);
alltypeAlertData.put("rfscPFrfMetNumber", 18);
alltypeAlertData.put("AL_msg_diff", 5);
/* alltypeAlertData.put("cannot_initiate_close_all", 1);
alltypeAlertData.put("No_Chute_Asgnmt_found", 1);
alltypeAlertData.put("JMS Queue", 7);
alltypeAlertData.put("PJ_Timeout", 2);
alltypeAlertData.put("Machine_not_active", 2);
alltypeAlertData.put("SystCbackupReceive Read Error", 7);
alltypeAlertData.put("0006LS_Error", 6);
alltypeAlertData.put("Connection_Terminated", 7);
alltypeAlertData.put("pending_synch", 2);
alltypeAlertData.put("Run_Timeout", 5);
alltypeAlertData.put("SystCdockLoad1 No Response", 5); */


List<String> labelArr = new ArrayList<>();
List<Integer> dataArr = new ArrayList<>();

for (String label : alltypeAlertData.keySet())
{
	labelArr.add(label);
	System.out.println("label :"+label);
}

for (Integer data : alltypeAlertData.values())
{
	dataArr.add(data);
	System.out.println("label :"+data);
}

System.out.println("labelArr :"+labelArr);
System.out.println("dataArr :"+dataArr);
%>
<html>

<head>
<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style>
 body {
     background-color: #f9f9fa
 }

 .flex {
     -webkit-box-flex: 1;
     -ms-flex: 1 1 auto;
     flex: 1 1 auto
 }

 @media (max-width:991.98px) {
     .padding {
         padding: 1.5rem
     }
 }

 @media (max-width:767.98px) {
     .padding {
         padding: 1rem
     }
 }

 .padding {
     padding: 5rem
 }

 .card {
     background: #fff;
     border-width: 0;
     border-radius: .25rem;
     box-shadow: 0 1px 3px rgba(0, 0, 0, .05);
     margin-bottom: 1.5rem
 }

 .card {
     position: relative;
     display: flex;
     flex-direction: column;
     min-width: 0;
     word-wrap: break-word;
     background-color: #fff;
     background-clip: border-box;
     border: 1px solid rgba(19, 24, 44, .125);
     border-radius: .25rem
 }

 .card-header {
     padding: .75rem 1.25rem;
     margin-bottom: 0;
     background-color: rgba(19, 24, 44, .03);
     border-bottom: 1px solid rgba(19, 24, 44, .125)
 }

 .card-header:first-child {
     border-radius: calc(.25rem - 1px) calc(.25rem - 1px) 0 0
 }

 card-footer,
 .card-header {
     background-color: transparent;
     border-color: rgba(160, 175, 185, .15);
     background-clip: padding-box
 }
</style>
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>



<script>

function getLabels()
{
	var labelList = [];
	<%
	for (String label : alltypeAlertData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

    $(document).ready(function() {
        var ctx = $("#chart-line");
        var myLineChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: getLabels(),
                datasets: [{
                    data: <%=dataArr%>,
                    
                    borderColor: "#458af7",
                    backgroundColor: '#458af7',
                    fill: false
                }]
            },
            options: {
                title: {
                    display: true,
                    text: 'World population per region (in millions)'
                }
            }
        });
        $("#chart-line").click( 
                function(evt){
                    var activePoints = myLineChart.getElementsAtEvent(evt);
                    if (activePoints[0]) {
                        var chartData = activePoints[0]['_chart'].config.data;
                        var idx = activePoints[0]['_index'];
                        var label = chartData.labels[idx];
                        var value = chartData.datasets[0].data[idx];
                        var url = "http://example.com/?label=" + label + "&value=" + value;
                        alert(url);
                      }
                }
            );  
    });
</script>
<div class="page-content page-container" id="page-content">
    <div class="padding">
        <div class="row">
            <div class="container-fluid d-flex justify-content-center">
                <div class="col-sm-8 col-md-6">
                    <div class="card">
                        <div class="card-header">Bar chart</div>
                        <div class="card-body" style="height: 420px">
                            <div class="chartjs-size-monitor" style="position: absolute; left: 0px; top: 0px; right: 0px; bottom: 0px; overflow: hidden; pointer-events: none; visibility: hidden; z-index: -1;">
                                <div class="chartjs-size-monitor-expand" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:1000000px;height:1000000px;left:0;top:0"></div>
                                </div>
                                <div class="chartjs-size-monitor-shrink" style="position:absolute;left:0;top:0;right:0;bottom:0;overflow:hidden;pointer-events:none;visibility:hidden;z-index:-1;">
                                    <div style="position:absolute;width:200%;height:200%;left:0; top:0"></div>
                                </div>
                            </div> <canvas id="chart-line" width="299" height="200" class="chartjs-render-monitor" style="display: block; width: 299px; height: 200px;"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<body></body>
</html>