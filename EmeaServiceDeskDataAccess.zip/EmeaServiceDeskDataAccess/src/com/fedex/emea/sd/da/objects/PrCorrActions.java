package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;

public class PrCorrActions implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6329243883468261554L;

	protected String cy;
	protected String eaiId;
	protected String symAppName;
	protected String ni2AppId;
	protected String ni2AppName;
	protected String respMdPin;
	protected String respMgrPin;
	protected String item;
	protected String action;
	protected String actionImportance;
	protected Date actionBy;
	protected String actionFeedback;
	protected String actionStatus;
	protected Date lastUpdateDttm;
	protected int auditId;
	protected boolean auditIdNull = true;
	protected String org;

	/**
	 * Method 'PrCorrActions'
	 * 
	 */
	public PrCorrActions()
	{
	}

	/**
	 * Method 'getCy'
	 * 
	 * @return String
	 */
	public String getCy()
	{
		return cy;
	}

	/**
	 * Method 'setCy'
	 * 
	 * @param cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/**
	 * Method 'getEaiId'
	 * 
	 * @return String
	 */
	public String getEaiId()
	{
		return eaiId;
	}

	/**
	 * Method 'setEaiId'
	 * 
	 * @param eaiId
	 */
	public void setEaiId(String eaiId)
	{
		this.eaiId = eaiId;
	}

	/**
	 * Method 'getSymAppName'
	 * 
	 * @return String
	 */
	public String getSymAppName()
	{
		return symAppName;
	}

	/**
	 * Method 'setSymAppName'
	 * 
	 * @param symAppName
	 */
	public void setSymAppName(String symAppName)
	{
		this.symAppName = symAppName;
	}

	/**
	 * Method 'getNi2AppId'
	 * 
	 * @return String
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'setNi2AppId'
	 * 
	 * @param ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'getNi2AppName'
	 * 
	 * @return String
	 */
	public String getNi2AppName()
	{
		return ni2AppName;
	}

	/**
	 * Method 'setNi2AppName'
	 * 
	 * @param ni2AppName
	 */
	public void setNi2AppName(String ni2AppName)
	{
		this.ni2AppName = ni2AppName;
	}

	/**
	 * Method 'getRespMdPin'
	 * 
	 * @return String
	 */
	public String getRespMdPin()
	{
		return respMdPin;
	}

	/**
	 * Method 'setRespMdPin'
	 * 
	 * @param respMdPin
	 */
	public void setRespMdPin(String respMdPin)
	{
		this.respMdPin = respMdPin;
	}

	/**
	 * Method 'getRespMgrPin'
	 * 
	 * @return String
	 */
	public String getRespMgrPin()
	{
		return respMgrPin;
	}

	/**
	 * Method 'setRespMgrPin'
	 * 
	 * @param respMgrPin
	 */
	public void setRespMgrPin(String respMgrPin)
	{
		this.respMgrPin = respMgrPin;
	}

	/**
	 * Method 'getItem'
	 * 
	 * @return String
	 */
	public String getItem()
	{
		return item;
	}

	/**
	 * Method 'setItem'
	 * 
	 * @param item
	 */
	public void setItem(String item)
	{
		this.item = item;
	}

	/**
	 * Method 'getAction'
	 * 
	 * @return String
	 */
	public String getAction()
	{
		return action;
	}

	/**
	 * Method 'setAction'
	 * 
	 * @param action
	 */
	public void setAction(String action)
	{
		this.action = action;
	}

	/**
	 * Method 'getActionImportance'
	 * 
	 * @return String
	 */
	public String getActionImportance()
	{
		return actionImportance;
	}

	/**
	 * Method 'setActionImportance'
	 * 
	 * @param actionImportance
	 */
	public void setActionImportance(String actionImportance)
	{
		this.actionImportance = actionImportance;
	}

	/**
	 * Method 'getActionBy'
	 * 
	 * @return Date
	 */
	public Date getActionBy()
	{
		return actionBy;
	}

	/**
	 * Method 'setActionBy'
	 * 
	 * @param actionBy
	 */
	public void setActionBy(Date actionBy)
	{
		this.actionBy = actionBy;
	}

	/**
	 * Method 'getActionFeedback'
	 * 
	 * @return String
	 */
	public String getActionFeedback()
	{
		return actionFeedback;
	}

	/**
	 * Method 'setActionFeedback'
	 * 
	 * @param actionFeedback
	 */
	public void setActionFeedback(String actionFeedback)
	{
		this.actionFeedback = actionFeedback;
	}

	/**
	 * Method 'getActionStatus'
	 * 
	 * @return String
	 */
	public String getActionStatus()
	{
		return actionStatus;
	}

	/**
	 * Method 'setActionStatus'
	 * 
	 * @param actionStatus
	 */
	public void setActionStatus(String actionStatus)
	{
		this.actionStatus = actionStatus;
	}

	/**
	 * Method 'getLastUpdateDttm'
	 * 
	 * @return Date
	 */
	public Date getLastUpdateDttm()
	{
		return lastUpdateDttm;
	}

	/**
	 * Method 'setLastUpdateDttm'
	 * 
	 * @param lastUpdateDttm
	 */
	public void setLastUpdateDttm(Date lastUpdateDttm)
	{
		this.lastUpdateDttm = lastUpdateDttm;
	}

	/**
	 * Method 'getAuditId'
	 * 
	 * @return int
	 */
	public int getAuditId()
	{
		return auditId;
	}

	/**
	 * Method 'setAuditId'
	 * 
	 * @param auditId
	 */
	public void setAuditId(int auditId)
	{
		this.auditId = auditId;
		this.auditIdNull = false;
	}

	/**
	 * Method 'setAuditIdNull'
	 * 
	 * @param value
	 */
	public void setAuditIdNull(boolean value)
	{
		this.auditIdNull = value;
	}

	/**
	 * Method 'isAuditIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isAuditIdNull()
	{
		return auditIdNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrCorrActions)) {
			return false;
		}
		
		final PrCorrActions _cast = (PrCorrActions) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (eaiId == null ? _cast.eaiId != eaiId : !eaiId.equals( _cast.eaiId )) {
			return false;
		}
		
		if (symAppName == null ? _cast.symAppName != symAppName : !symAppName.equals( _cast.symAppName )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		if (ni2AppName == null ? _cast.ni2AppName != ni2AppName : !ni2AppName.equals( _cast.ni2AppName )) {
			return false;
		}
		
		if (respMdPin == null ? _cast.respMdPin != respMdPin : !respMdPin.equals( _cast.respMdPin )) {
			return false;
		}
		
		if (respMgrPin == null ? _cast.respMgrPin != respMgrPin : !respMgrPin.equals( _cast.respMgrPin )) {
			return false;
		}
		
		if (item == null ? _cast.item != item : !item.equals( _cast.item )) {
			return false;
		}
		
		if (action == null ? _cast.action != action : !action.equals( _cast.action )) {
			return false;
		}
		
		if (actionImportance == null ? _cast.actionImportance != actionImportance : !actionImportance.equals( _cast.actionImportance )) {
			return false;
		}
		
		if (actionBy == null ? _cast.actionBy != actionBy : !actionBy.equals( _cast.actionBy )) {
			return false;
		}
		
		if (actionFeedback == null ? _cast.actionFeedback != actionFeedback : !actionFeedback.equals( _cast.actionFeedback )) {
			return false;
		}
		
		if (actionStatus == null ? _cast.actionStatus != actionStatus : !actionStatus.equals( _cast.actionStatus )) {
			return false;
		}
		
		if (lastUpdateDttm == null ? _cast.lastUpdateDttm != lastUpdateDttm : !lastUpdateDttm.equals( _cast.lastUpdateDttm )) {
			return false;
		}
		
		if (auditId != _cast.auditId) {
			return false;
		}
		
		if (auditIdNull != _cast.auditIdNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (eaiId != null) {
			_hashCode = 29 * _hashCode + eaiId.hashCode();
		}
		
		if (symAppName != null) {
			_hashCode = 29 * _hashCode + symAppName.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		if (ni2AppName != null) {
			_hashCode = 29 * _hashCode + ni2AppName.hashCode();
		}
		
		if (respMdPin != null) {
			_hashCode = 29 * _hashCode + respMdPin.hashCode();
		}
		
		if (respMgrPin != null) {
			_hashCode = 29 * _hashCode + respMgrPin.hashCode();
		}
		
		if (item != null) {
			_hashCode = 29 * _hashCode + item.hashCode();
		}
		
		if (action != null) {
			_hashCode = 29 * _hashCode + action.hashCode();
		}
		
		if (actionImportance != null) {
			_hashCode = 29 * _hashCode + actionImportance.hashCode();
		}
		
		if (actionBy != null) {
			_hashCode = 29 * _hashCode + actionBy.hashCode();
		}
		
		if (actionFeedback != null) {
			_hashCode = 29 * _hashCode + actionFeedback.hashCode();
		}
		
		if (actionStatus != null) {
			_hashCode = 29 * _hashCode + actionStatus.hashCode();
		}
		
		if (lastUpdateDttm != null) {
			_hashCode = 29 * _hashCode + lastUpdateDttm.hashCode();
		}
		
		_hashCode = 29 * _hashCode + auditId;
		_hashCode = 29 * _hashCode + (auditIdNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrCorrActionsPk
	 */
	public PrCorrActionsPk createPk()
	{
		return new PrCorrActionsPk(cy, eaiId, ni2AppId, item);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrCorrActions: " );
		ret.append( "cy=" + cy );
		ret.append( ", eaiId=" + eaiId );
		ret.append( ", symAppName=" + symAppName );
		ret.append( ", ni2AppId=" + ni2AppId );
		ret.append( ", ni2AppName=" + ni2AppName );
		ret.append( ", respMdPin=" + respMdPin );
		ret.append( ", respMgrPin=" + respMgrPin );
		ret.append( ", item=" + item );
		ret.append( ", action=" + action );
		ret.append( ", actionImportance=" + actionImportance );
		ret.append( ", actionBy=" + actionBy );
		ret.append( ", actionFeedback=" + actionFeedback );
		ret.append( ", actionStatus=" + actionStatus );
		ret.append( ", lastUpdateDttm=" + lastUpdateDttm );
		ret.append( ", auditId=" + auditId );
		return ret.toString();
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

}
