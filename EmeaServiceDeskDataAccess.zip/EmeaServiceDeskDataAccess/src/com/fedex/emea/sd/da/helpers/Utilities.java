package com.fedex.emea.sd.da.helpers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.fedex.emea.sd.da.objects.NexusCases;

public class Utilities {
	
	public static Date getExactDayAtMidnight(Date theDate) {
		Calendar tmpCal = Calendar.getInstance();
		tmpCal.clear();
		tmpCal.setTime(theDate);
		tmpCal.set(Calendar.HOUR_OF_DAY, 0);
		tmpCal.set(Calendar.MINUTE, 0);
		tmpCal.set(Calendar.SECOND, 0);
		tmpCal.set(Calendar.MILLISECOND, 0);
		return tmpCal.getTime();
	}
	
	public static long getIntervalTimeUntilNow(Timestamp creationTime) {
		Calendar cal = Calendar.getInstance();
		long msNow = cal.getTimeInMillis();
		
		long msAlert = 0;
		long timeDifference = 0;
		
		msAlert = creationTime.getTime();
		timeDifference = (msNow - msAlert) / 1000;
		
		return timeDifference;
	}
	
	public static String getTimeOnly(Date d) {
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss.S a");
		return sdf.format(d);
	}
	
	public static boolean isNotNullOrEmpty(String s) {
		if ((s == null) || (s.equals(""))) {
			return false;
		} else {
			return true;
		}
	}
	
	public static String nullToEmptyString(String s) {
		if ((s == null) || (s.equals(""))) {
			return "";
		} else {
			return s;
		}
	}
	
	public static String formatToDbDate(Date d) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a");
		return sdf.format(d);
	}
	
	public static String getDateOnly(Date d) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		return sdf.format(d);
	}
	
	public static String getSubstring(String s, int start, int stop) {
		if (s.length() < start) {
			return "";
		} else {
			if (s.length() < stop) {
				return s.substring(start);
			} else {
				return s.substring(start, stop);
			}
		}
	}
	
	public static byte[] getBytesFromNexusCases(NexusCases obj) throws IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(obj);
		oos.flush();
		oos.close();
		bos.close();
		byte [] data = bos.toByteArray();
		return data;
	}
	
	public static NexusCases getNexusCasesFromBytes(byte[] bytes) throws IOException, ClassNotFoundException {
		if (bytes == null) return null;
		
		NexusCases object = null; 
		try {
			object = (NexusCases) new java.io.ObjectInputStream(new java.io.ByteArrayInputStream(bytes)).readObject();
		} catch (IOException e) {
			throw e;
		} catch (ClassNotFoundException e) {
			throw e;
		}
		return object;
	}
	
	public static String cleanServerName(String serverName) {
		String cleanedServerName = serverName.trim();
		int posToCheck = 0;
		
		posToCheck = cleanedServerName.indexOf(" ");
		if (posToCheck >= 0) {
			cleanedServerName = cleanedServerName.substring(0, posToCheck);
		}
		posToCheck = cleanedServerName.indexOf("/");
		if (posToCheck >= 0) {
			cleanedServerName = cleanedServerName.substring(0, posToCheck);
		}
		return cleanedServerName.toUpperCase();
	}
}
