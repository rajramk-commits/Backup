package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class SupportTicketClassification implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String caseArea;
	private String caseService;
	private String caseComponent;
	private String caseFunction;
	private String caseDescription;
	private String casePriority;
	private String caseStatus;
	private String caseType;
	private String caseProviderGroup;
	private String caseBusinessUnit;
	private String caseSource;
	private String caseSummary;
	private String caseId;
	private String caseSysId;
	private String caseNumber;
	private long   intervalForSimilar;
	
	public String getCaseArea() {
		return caseArea;
	}
	public void setCaseArea(String caseArea) {
		this.caseArea = caseArea;
	}
	public String getCaseService() {
		return caseService;
	}
	public void setCaseService(String caseService) {
		this.caseService = caseService;
	}
	public String getCaseComponent() {
		return caseComponent;
	}
	public void setCaseComponent(String caseComponent) {
		this.caseComponent = caseComponent;
	}
	public String getCaseFunction() {
		return caseFunction;
	}
	public void setCaseFunction(String caseFunction) {
		this.caseFunction = caseFunction;
	}
	public String getCaseDescription() {
		return caseDescription;
	}
	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}
	public String getCasePriority() {
		return casePriority;
	}
	public void setCasePriority(String casePriority) {
		this.casePriority = casePriority;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCaseProviderGroup() {
		return caseProviderGroup;
	}
	public void setCaseProviderGroup(String caseProviderGroup) {
		this.caseProviderGroup = caseProviderGroup;
	}
	public String getCaseBusinessUnit() {
		return caseBusinessUnit;
	}
	public void setCaseBusinessUnit(String caseBusinessUnit) {
		this.caseBusinessUnit = caseBusinessUnit;
	}
	public String getCaseSource() {
		return caseSource;
	}
	public void setCaseSource(String caseSource) {
		this.caseSource = caseSource;
	}
	public String getCaseSummary() {
		return caseSummary;
	}
	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public long getIntervalForSimilar() {
		return intervalForSimilar;
	}
	public void setIntervalForSimilar(long intervalForSimilar) {
		this.intervalForSimilar = intervalForSimilar;
	}
	
	public void setCaseASCF(String area, String service, String component, String function) {
		this.caseArea = area;
		this.caseService = service;
		this.caseComponent = component;
		this.caseFunction = function;
	}
	public String getCaseSysId() {
		return caseSysId;
	}
	public void setCaseSysId(String caseSysId) {
		this.caseSysId = caseSysId;
	}
	public String getCaseNumber() {
		return caseNumber;
	}
	public void setCaseNumber(String caseNumber) {
		this.caseNumber = caseNumber;
	}
	
}
