package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class PrSymNi2Links implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 235524497087142665L;

	/** 
	 * This attribute maps to the column SYM_EAI_ID in the PR_SYM_NI2_LINKS table.
	 */
	protected String symEaiId;

	/** 
	 * This attribute maps to the column NI2_APP_NAME in the PR_SYM_NI2_LINKS table.
	 */
	protected String ni2AppName;

	/** 
	 * This attribute maps to the column NI2_APP_ID in the PR_SYM_NI2_LINKS table.
	 */
	protected String ni2AppId;

	/**
	 * Method 'PrSymNi2Links'
	 * 
	 */
	public PrSymNi2Links()
	{
	}

	/**
	 * Method 'getSymEaiId'
	 * 
	 * @return String
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/**
	 * Method 'setSymEaiId'
	 * 
	 * @param symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/**
	 * Method 'getNi2AppName'
	 * 
	 * @return String
	 */
	public String getNi2AppName()
	{
		return ni2AppName;
	}

	/**
	 * Method 'setNi2AppName'
	 * 
	 * @param ni2AppName
	 */
	public void setNi2AppName(String ni2AppName)
	{
		this.ni2AppName = ni2AppName;
	}

	/**
	 * Method 'getNi2AppId'
	 * 
	 * @return String
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'setNi2AppId'
	 * 
	 * @param ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSymNi2Links)) {
			return false;
		}
		
		final PrSymNi2Links _cast = (PrSymNi2Links) _other;
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		if (ni2AppName == null ? _cast.ni2AppName != ni2AppName : !ni2AppName.equals( _cast.ni2AppName )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		if (ni2AppName != null) {
			_hashCode = 29 * _hashCode + ni2AppName.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrSymNi2LinksPk
	 */
	public PrSymNi2LinksPk createPk()
	{
		return new PrSymNi2LinksPk(symEaiId, ni2AppId);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSymNi2Links: " );
		ret.append( "symEaiId=" + symEaiId );
		ret.append( ", ni2AppName=" + ni2AppName );
		ret.append( ", ni2AppId=" + ni2AppId );
		return ret.toString();
	}

}
