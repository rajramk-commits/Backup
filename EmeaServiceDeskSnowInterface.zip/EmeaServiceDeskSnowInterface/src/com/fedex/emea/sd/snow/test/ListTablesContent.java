package com.fedex.emea.sd.snow.test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.utilities.SnowConstants;
import com.fedex.emea.sd.snow.utilities.SnowUtilities;

@SuppressWarnings("unused")
public class ListTablesContent {
	
	private static final String EXPORT_FOLDER = "C:\\Temp\\";
	private static Calendar     cal           = Calendar.getInstance();
	
	public static void main(String[] args) {
		
		SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.EPDSM_PROD_DIRECT);
//		SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.SNOW_PROD);
		
		SnowSearchFilter fedexFolderLabelFilter = new SnowSearchFilter("u_folder", SnowConstants.OPER_EQUAL, "fedex");
		SnowSearchFilter fedexFolderFilter      = new SnowSearchFilter("u_folder", SnowConstants.OPER_EQUAL, "1a0e8689dbe5fac0c9a7b14ffe9619a5");
				
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		
//		filters.add(new SnowSearchFilter("value",      SnowConstants.OPER_EQUAL, "2"));
//		filters.add(new SnowSearchFilter("element",    SnowConstants.OPER_EQUAL, "sequence"));
//		filters.add(new SnowSearchFilter("language",   SnowConstants.OPER_EQUAL, "en"));
//		filters.add(new SnowSearchFilter("label",      SnowConstants.OPER_EQUAL, "In Progress"));
//		filters.add(new SnowSearchFilter("name",       SnowConstants.OPER_IN,    "incident,task,sc_request"));
//		filters.add(new SnowSearchFilter("u_folder",   SnowConstants.OPER_EQUAL, "1a0e8689dbe5fac0c9a7b14ffe9619a5"));
		
		System.out.println("Started...");
		
		// ========================================================================
		// USERS
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("user_name", SnowConstants.OPER_IN, "261157"));
//		String[] sysUserFields = {"sys_id", "user_name", "first_name", "last_name", "name", "u_fedex_ldap_id", "u_folder", "u_search_code", "active"};
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_SYS_USER, filters, sysUserFields, EXPORT_FOLDER);

		// ========================================================================
		// USER GROUPS
		// ========================================================================
		filters.clear();
//		filters.add(new SnowSearchFilter("u_folder",            SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX_ID));
//		filters.add(new SnowSearchFilter("name",   SnowConstants.OPER_LIKE, "FXE"));
//		filters.add(new SnowSearchFilter("sys_id",   SnowConstants.OPER_EQUAL, "c47fcbf80a0aa02100f961b9fa5352c5"));
		String[] sysUserGroupFields = {"sys_id", "name", "active", "u_folder"};
		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_SYS_USER_GROUP, null, sysUserGroupFields, EXPORT_FOLDER);

		// ========================================================================
		// SYS_CHOICE table List
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("label", SnowConstants.OPER_EQUAL, "Resolved"));
//		String[] fields = {"name", "element", "sequence", "value", "language", "label"};
//		SnowUtilities.listTable(snowRequestor, "sys_choice", null, null, EXPORT_FOLDER);

		// ========================================================================
		// METRIC Table List
		// ========================================================================
//		cal.clear();
//		cal.set(2018, Calendar.MAY, 1, 0, 0, 0);
//		Date startRange = new Date(cal.getTimeInMillis());
//		cal.clear();
//		cal.set(2018, Calendar.MAY, 2, 0, 0, 0);
//		Date endRange = new Date(cal.getTimeInMillis());
		
//		filters.clear();
//		filters.add(new SnowSearchFilter("inc_u_folder", SnowConstants.OPER_EQUAL, "fedex"));
//		filters.add(new SnowSearchFilter("inc_sys_class_name", SnowConstants.OPER_EQUAL, "incident"));
//		filters.add(new SnowSearchFilter("inc_u_support_structure", SnowConstants.OPER_IN, "Group 1,Group 2,Group 3"));
//		filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startRange), SnowUtilities.formatDateForSNOW(endRange)));
//		String[] fieldsIM = {"inc_number", "inc_sys_created_on"};
//		SnowUtilities.listTable(snowRequestor, "incident_metric", filters, fieldsIM, EXPORT_FOLDER);

//		filters.clear();
//		filters.add(new SnowSearchFilter("inc_number", SnowConstants.OPER_IN, "INC4263262"));
//		String[] fieldsISLA = {"inc_number", "inc_state", "taskslatable_start_time","taskslatable_end_time","taskslatable_planned_end_time","taskslatable_time_left","taskslatable_duration","taskslatable_original_breach_time","taskslatable_percentage","taskslatable_timezone","taskslatable_has_breached","taskslatable_pause_time","taskslatable_active","taskslatable_pause_duration","taskslatable_stage","taskslatable_u_in_scope"};		
//		SnowUtilities.listTable(snowRequestor, "incident_sla", filters, fieldsISLA, EXPORT_FOLDER);
		
//		filters.clear();
//		filters.add(new SnowSearchFilter("scr_number", SnowConstants.OPER_IN, "REQ3468464"));
//		filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startRange), SnowUtilities.formatDateForSNOW(endRange)));
//		String[] fieldsRM = {"scr_number", "scr_category", "scr_state", "scr_sys_created_on", "scr_opened_at", "scr_closed_at", "scr_sla_due", "md_number","md_name","md_field","mi_start","mi_end","mi_duration","mi_field","mi_field_value","mi_value","mi_calculation_complete"};
//		SnowUtilities.listTable(snowRequestor, "sc_request_metric", filters, fieldsRM, EXPORT_FOLDER);
			
//		String[] fieldsRSLA = {"scr_number", "scr_state", "taskslatable_start_time","taskslatable_end_time","taskslatable_planned_end_time","taskslatable_time_left","taskslatable_duration","taskslatable_original_breach_time","taskslatable_percentage","taskslatable_timezone","taskslatable_has_breached","taskslatable_pause_time","taskslatable_active","taskslatable_pause_duration","taskslatable_stage","taskslatable_u_in_scope"};
//		filters.clear();
//		filters.add(new SnowSearchFilter("scr_number", SnowConstants.OPER_IN, "REQ3454836"));
//		SnowUtilities.listTable(snowRequestor, "sc_request_sla", filters, fieldsRSLA, EXPORT_FOLDER);

//		String[] fieldsPM = {"prb_number", "prb_state", "md_number","md_name","md_field","mi_start","mi_end","mi_duration","mi_field","mi_field_value","mi_value","mi_calculation_complete"};
//		filters.clear();
//		filters.add(new SnowSearchFilter("prb_number", SnowConstants.OPER_EQUAL, "PRB0009004"));
//		SnowUtilities.listTable(snowRequestor, "problem_metric", filters, fieldsPM, EXPORT_FOLDER);

		// ========================================================================
		// SYS_HISTORY_SET
		// ========================================================================
//		String[] sysHistorySetFields = {""};
//		filters.clear();
//		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, "70007513dbca8f808b3df3d31d9619f2"));
//		SnowUtilities.listTable(snowRequestor, "sys_history_set", filters, null, EXPORT_FOLDER);
		
		// ========================================================================
		// CMDB_CI_SERVICE - Business Service => Applications
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("u_top50_application",    SnowConstants.OPER_EQUAL, "Yes"));
//		filters.add(new SnowSearchFilter("service_classification", SnowConstants.OPER_EQUAL, "Business Service"));
//		filters.add(new SnowSearchFilter("used_for",               SnowConstants.OPER_EQUAL, "Production"));
//		filters.add(new SnowSearchFilter("u_pac",                  SnowConstants.OPER_LIKE, "PAC_00252^ORu_pacLIKEPAC_02213^ORu_pacLIKEPAC_01514^ORu_pacLIKEPAC_00379^ORu_pacLIKEPAC_00431^ORu_pacLIKEPAC_02294^ORu_pacLIKEPAC_00377^ORu_pacLIKEPAC_00281^ORu_pacLIKEPAC_00517^ORu_pacLIKEPAC_02422^ORu_pacLIKEPAC_00423^ORu_pacLIKEPAC_00265^ORu_pacLIKEPAC_00463^ORu_pacLIKEPAC_00426^ORu_pacLIKEPAC_00427^ORu_pacLIKEPAC_00635^ORu_pacLIKEPAC_00456^ORu_pacLIKEPAC_00446^ORu_pacLIKEPAC_00259^ORu_pacLIKEPAC_02284^ORu_pacLIKEPAC_00538^ORu_pacLIKEPAC_00474^ORu_pacLIKEPAC_00489^ORu_pacLIKEPAC_00490^ORu_pacLIKEPAC_00491^ORu_pacLIKEPAC_00492^ORu_pacLIKEPAC_00250^ORu_pacLIKEPAC_00398^ORu_pacLIKEPAC_00249^ORu_pacLIKEPAC_00478^ORu_pacLIKEPAC_00477^ORu_pacLIKEPAC_00410^ORu_pacLIKEPAC_00369^ORu_pacLIKEPAC_00503^ORu_pacLIKEPAC_00504^ORu_pacLIKEPAC_00505^ORu_pacLIKEPAC_00506^ORu_pacLIKEPAC_00507^ORu_pacLIKEPAC_01692^ORu_pacLIKEPAC_00278^ORu_pacLIKEPAC_00905^ORu_pacLIKEPAC_00906^ORu_pacLIKEPAC_00484^ORu_pacLIKEPAC_00526^ORu_pacLIKEPAC_00248^ORu_pacLIKEPAC_02629"));
//		filters.add(new SnowSearchFilter("u_folder",               SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX_ID));
//		filters.add(new SnowSearchFilter("u_pac",                  SnowConstants.OPER_IN, "PAC_00252,PAC_02213,PAC_01514,PAC_00379,PAC_00431,PAC_02294,PAC_00377,PAC_00281,PAC_00517,PAC_02422,PAC_00423,PAC_00265,PAC_00463,PAC_00426,PAC_00427,PAC_00635,PAC_00456,PAC_00446,PAC_00259,PAC_02284,PAC_00538,PAC_00474,PAC_00489,PAC_00490,PAC_00491,PAC_00492,PAC_00250,PAC_00398,PAC_00249,PAC_00478,PAC_00477,PAC_00410,PAC_00369,PAC_00503,PAC_00504,PAC_00505,PAC_00506,PAC_00507,PAC_01692,PAC_00278,PAC_00905,PAC_00906,PAC_00484,PAC_00526,PAC_00248,PAC_02629"));
//		filters.add(new SnowSearchFilter("name",                   SnowConstants.OPER_EQUAL, "EMEA-SD-AUTOMATION-TOOLS"));
//		filters.add(new SnowSearchFilter("sys_id",                 SnowConstants.OPER_EQUAL, "b195665425645400d216b5853d1bd3a2"));
//		String[] cmdbCiServiceFields = {"sys_id", "name", "u_pac", "u_business_service_owner", "u_application_service_owner", "busines_criticality","u_business_critical","u_business_criticality_fdx", "u_top50_application", "service_classification", "u_folder"};
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_CMDB_CI_SERVICE, filters, cmdbCiServiceFields, EXPORT_FOLDER);
		
		// ========================================================================
		// INCIDENT
		// ========================================================================
//		filters.clear();
//		cal.clear();
//		cal.set(2018, Calendar.MARCH, 14, 0, 0, 0);
//		Date startRange = new Date(cal.getTimeInMillis());
//		cal.clear();
//		cal.set(2018, Calendar.MARCH, 28, 0, 0, 0);
//		Date endRange = new Date(cal.getTimeInMillis());
//
//		filters.add(new SnowSearchFilter("sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startRange), SnowUtilities.formatDateForSNOW(endRange)));
//		filters.add(new SnowSearchFilter("u_folder",       SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
//		filters.add(new SnowSearchFilter("category",       SnowConstants.OPER_EQUAL, SnowConstants.CATEGORY_INCIDENT));
//		String[] incidentsFields = {"sys_id", "short_description", "number", "severity","impact","urgency","priority", "sys_created_on","opened_at","sla_due","resolved_at","closed_at","business_duration","calendar_duration","state","sys_created_by", "business_service"};
//		String[] astcIncidentFields = {"sys_id","u_short_description","u_number","u_severity", "u_impact","u_urgency","u_priority","u_instructions","u_classification","u_business_service","u_work_notes","u_subcategory","u_state","u_assignment_group","u_contact_type","sys_import_state","u_category","u_description","u_caller","sys_created_on"};
//		filters.add(new SnowSearchFilter("short_description", SnowConstants.OPER_LIKE, "ASTC END-TO-END TEST"));
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_U_ASTC_INCIDENT, filters, null, EXPORT_FOLDER);
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_INCIDENT, filters, null, EXPORT_FOLDER);
		
		// ========================================================================
		// CMBD_CI
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("name",   SnowConstants.OPER_EQUAL, "COMNEX"));
//		String[] cmdbCiFields = {"sys_id","name"};
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_CMDB_CI, filters, null, EXPORT_FOLDER);
		
		// ========================================================================
		// CMDB_CI_BUSINESS_APP (EPDSM)
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("name",   SnowConstants.OPER_LIKE, "Seagha"));
//		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "TRUE"));
//		String[] cmdbCiBusinessAppFields = {"sys_id","name", "u_eai_id", "u_application_code", "it_application_owner", "business_criticality", "u_business_function", "u_environment","u_it_lead", "emergency_tier", "u_integration_source", "operational_status", "u_app_use", "active"};
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_CMDB_CI_BUSINESS_APP, null, cmdbCiBusinessAppFields, EXPORT_FOLDER);		

		// ========================================================================
		// U_FOLDER
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("name",   SnowConstants.OPER_EQUAL, "COMNEX"));
//		String[] cuFolderFields = {"sys_id","name"};
//		SnowUtilities.listTable(snowRequestor, "u_folder", null, null, EXPORT_FOLDER);		

		// ========================================================================
		// TASK - Incident's Parent
		// ========================================================================
//		cal = Calendar.getInstance();
//		int todayYYYY = cal.get(Calendar.YEAR);
//		int todayMM   = cal.get(Calendar.MONTH);
//		int todayDD   = cal.get(Calendar.DAY_OF_MONTH); 
//		
//		cal.clear();
//		cal.set(todayYYYY, todayMM, todayDD, 0, 0, 0);
//		Date startIncidentRange = new Date(cal.getTimeInMillis());
//		
//		cal.clear();
//		cal.set(todayYYYY, todayMM, todayDD + 1, 0, 0, 0);
//		Date endIncidentRange = new Date(cal.getTimeInMillis());
//		
//		cal.clear();
//		cal.set(2018, Calendar.MAY, 1, 0, 0, 0);
//		Date startSelfRange = new Date(cal.getTimeInMillis());
//		
//		cal.clear();
//		cal.set(todayYYYY, todayMM, todayDD + 1, 0, 0, 0);
//		Date endSelfRange = new Date(cal.getTimeInMillis());
//		
//		filters.clear();
//		filters.add(new SnowSearchFilter("sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startSelfRange), SnowUtilities.formatDateForSNOW(endSelfRange)));
//		filters.add(new SnowSearchFilter("u_folder",       SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
//		filters.add(new SnowSearchFilter("contact_type",   SnowConstants.OPER_EQUAL, SnowConstants.CONTACT_MEDIUM_WEB));
//		
//		try {
//			List<HashMap<String,Object>> fieldsMapList = snowRequestor.getTableContent(SnowConstants.TBL_TASK, "number", filters);
//			System.out.println("Let's make a pause...");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		
		// ========================================================================
		// COMPANY
		// ========================================================================
//		filters.clear();
//		filters.add(new SnowSearchFilter("u_folder", SnowConstants.OPER_EQUAL, "1a0e8689dbe5fac0c9a7b14ffe9619a5"));
//		String[] coreCompanyFields = {"sys_id", "name", "u_organisation_searchcode", "u_top_layer"};
//		SnowUtilities.listTable(snowRequestor, SnowConstants.TBL_CORE_COMPANY, filters, coreCompanyFields, EXPORT_FOLDER);
		
		// ========================================================================
		
		System.out.println("Done!");
		System.exit(0);
		
	}
	
}
