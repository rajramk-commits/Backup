<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>


   <script type="text/javascript">
	onload=function(){
	var e=document.getElementById("refreshed");
	if(e.value=="no")e.value="yes";
	else{e.value="no";location.reload();}
	}
</script>

<style>

.login{
	
	display:flex;
	justify-content:center;
}


form{	
	width:270px;
	padding : 20px;
	border:3px solid #f1f1f1;
	border-radius:8px;	
		
}

input[type=text],input[type=password]{
font-family:Calibri;
font-size:15px;
width:100%;
padding:12px 20px;
margin:8px 0;
display:inline-block;
border:1px solid #ccc;
box-sizing:border-box;
}

input[type=submit]{

background-color:#4B0082;
color:white;
padding:14px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:100%;
}

.container{
padding:16px;
}


</style>

</head>

<body onunload="func()">

<div>
		<div class="login">
			<img alt="FedExSD" src="image/HEADER.png">
		</div>
		<br><br>
		<div class='login'>
		<form action="Login" method="post">
			<center><div >
				<img alt="FedEx" src="image/logo.png">
			</div></center>
			<br><br>
			<div class="container">
			<label style="font-size:15px;color:#929aa1;" for="userPin">FedEx Pin</label>
			<input type="text" size="15px" name="userPin">
			
			<label style="font-size:15px;color:#929aa1" for="userPassword">Password</label>
			<input type="password" size="15px" name="userPassword">		
			
			<br>			
			<input type="hidden" id="thisField" name="inputName" value="LoginMenu.jsp"/>
			<input type="submit" value="Login" id="#" >
			
			</div>						
			<div style="text-align:center">${userMessage}</div>
			<div style="color:red;text-align:center">${errorMessage}</div>
		</form>
		</div>
		<br><br>
		<div class="login">
			<img alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 131px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
		
</div>

</body>
</html>