package com.fedex.dashboard.constants;

public class DashboardConstants {
	
	public static final String SELECT_HUBSTACKCCTICKETS = 	"select CASEID, CREATIONTIME,RECORDSOURCE,CASEDESCRIPTION1,CASETYPE,CASEPRIORITY,CASESTATUS " + 
															" from SDTOOL_SCHEMA.DIMMINTERFACE " + 
															" where RECORDSOURCE = 'DIMM:HUBSTACK_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' " + 
															" order by CREATIONTIME DESC";
	
	public static final String SELECT_CLEARANCECCTICKETS = 	"select CASEID, CREATIONTIME,RECORDSOURCE,CASEDESCRIPTION1,CASETYPE,CASEPRIORITY,CASESTATUS " + 
															" from SDTOOL_SCHEMA.EXTERNAL_INTERFACE " + 
															" where RECORDSOURCE = 'DIMM:GENIUS_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' " + 
															" order by CREATIONTIME DESC";
	
	public static final String COUNT_HUBSTACKCCTICKETS  = 	"select count(*) from SDTOOL_SCHEMA.DIMMINTERFACE " + 
															" where RECORDSOURCE = 'DIMM:HUBSTACK_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' order by CREATIONTIME DESC";
	
	
	public static final String COUNT_CLEARANCECCTICKETS = 	"select count(*) from SDTOOL_SCHEMA.EXTERNAL_INTERFACE " + 
															" where RECORDSOURCE = 'DIMM:GENIUS_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' order by CREATIONTIME DESC";
	public static final String VALIDATED				=	"validated";
	public static final String INVALIDATED				=	"invalidated";
	public static final String STOPPED					=	"stopped";
	public static final String RUNNING					=	"running";
}
