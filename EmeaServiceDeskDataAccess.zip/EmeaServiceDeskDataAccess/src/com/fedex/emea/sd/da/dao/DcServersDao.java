package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import com.fedex.emea.sd.da.objects.DcServers;

public interface DcServersDao {
	public DcServers createValueObject();
	public List<DcServers> loadAllServersByDataCenter(String dataCenter) throws SQLException;
}
