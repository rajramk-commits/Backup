
//*****************************************************************
//* 
//* FdxCaseJavaCi.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import java.math.*;
import psft.pt8.joa.*;

public class FdxCaseJavaCi implements IFdxCaseJavaCi 
  {
  public FdxCaseJavaCi(IObject oThis) { m_oThis = oThis; }

  public String getBusinessUnit0() throws JOAException {
    return (String)m_oThis.getProperty("BUSINESS_UNIT_0");
 }

  public void setBusinessUnit0(String inBusinessUnit0) throws JOAException {
    m_oThis.setProperty("BUSINESS_UNIT_0", inBusinessUnit0);
 }

  public BigDecimal getCaseId() throws JOAException {
    return (new BigDecimal((String)m_oThis.getProperty("CASE_ID")));
 }

  public void setCaseId(BigDecimal inCaseId) throws JOAException {
    m_oThis.setProperty("CASE_ID", inCaseId.toPlainString());
 }

  public String getDispTmplFamCd() throws JOAException {
    return (String)m_oThis.getProperty("DISP_TMPL_FAM_CD");
 }

  public void setDispTmplFamCd(String inDispTmplFamCd) throws JOAException {
    m_oThis.setProperty("DISP_TMPL_FAM_CD", inDispTmplFamCd);
 }

  public String getCaseType() throws JOAException {
    return (String)m_oThis.getProperty("CASE_TYPE");
 }

  public void setCaseType(String inCaseType) throws JOAException {
    m_oThis.setProperty("CASE_TYPE", inCaseType);
 }

  public String getCaseContact() throws JOAException {
    return (String)m_oThis.getProperty("CASE_CONTACT");
 }

  public void setCaseContact(String inCaseContact) throws JOAException {
    m_oThis.setProperty("CASE_CONTACT", inCaseContact);
 }

  public BigDecimal getBoIdCust() throws JOAException {
    return (new BigDecimal((String)m_oThis.getProperty("BO_ID_CUST")));
 }

  public void setBoIdCust(BigDecimal inBoIdCust) throws JOAException {
    m_oThis.setProperty("BO_ID_CUST", inBoIdCust.toPlainString());
 }

  public BigDecimal getRoleTypeIdCust() throws JOAException {
    return (new BigDecimal((String)m_oThis.getProperty("ROLE_TYPE_ID_CUST")));
 }

  public void setRoleTypeIdCust(BigDecimal inRoleTypeIdCust) throws JOAException {
    m_oThis.setProperty("ROLE_TYPE_ID_CUST", inRoleTypeIdCust.toPlainString());
 }

  public BigDecimal getBoIdReportedBy() throws JOAException {
    return (new BigDecimal((String)m_oThis.getProperty("BO_ID_REPORTED_BY")));
 }

  public void setBoIdReportedBy(BigDecimal inBoIdReportedBy) throws JOAException {
    m_oThis.setProperty("BO_ID_REPORTED_BY", inBoIdReportedBy.toPlainString());
 }

  public String getRcSource() throws JOAException {
    return (String)m_oThis.getProperty("RC_SOURCE");
 }

  public void setRcSource(String inRcSource) throws JOAException {
    m_oThis.setProperty("RC_SOURCE", inRcSource);
 }

  public String getProviderGrpId() throws JOAException {
    return (String)m_oThis.getProperty("PROVIDER_GRP_ID");
 }

  public void setProviderGrpId(String inProviderGrpId) throws JOAException {
    m_oThis.setProperty("PROVIDER_GRP_ID", inProviderGrpId);
 }

  public String getAssignedTo() throws JOAException {
    return (String)m_oThis.getProperty("ASSIGNED_TO");
 }

  public void setAssignedTo(String inAssignedTo) throws JOAException {
    m_oThis.setProperty("ASSIGNED_TO", inAssignedTo);
 }

  public String getRcStatus() throws JOAException {
    return (String)m_oThis.getProperty("RC_STATUS");
 }

  public void setRcStatus(String inRcStatus) throws JOAException {
    m_oThis.setProperty("RC_STATUS", inRcStatus);
 }

  public String getRcPriority() throws JOAException {
    return (String)m_oThis.getProperty("RC_PRIORITY");
 }

  public void setRcPriority(String inRcPriority) throws JOAException {
    m_oThis.setProperty("RC_PRIORITY", inRcPriority);
 }

  public String getRcSeverity() throws JOAException {
    return (String)m_oThis.getProperty("RC_SEVERITY");
 }

  public void setRcSeverity(String inRcSeverity) throws JOAException {
    m_oThis.setProperty("RC_SEVERITY", inRcSeverity);
 }

  public String getRcCategory() throws JOAException {
    return (String)m_oThis.getProperty("RC_CATEGORY");
 }

  public void setRcCategory(String inRcCategory) throws JOAException {
    m_oThis.setProperty("RC_CATEGORY", inRcCategory);
 }

  public String getRcType() throws JOAException {
    return (String)m_oThis.getProperty("RC_TYPE");
 }

  public void setRcType(String inRcType) throws JOAException {
    m_oThis.setProperty("RC_TYPE", inRcType);
 }

  public String getRcDetail() throws JOAException {
    return (String)m_oThis.getProperty("RC_DETAIL");
 }

  public void setRcDetail(String inRcDetail) throws JOAException {
    m_oThis.setProperty("RC_DETAIL", inRcDetail);
 }

  public String getRcSummary() throws JOAException {
    return (String)m_oThis.getProperty("RC_SUMMARY");
 }

  public void setRcSummary(String inRcSummary) throws JOAException {
    m_oThis.setProperty("RC_SUMMARY", inRcSummary);
 }

  public String getRcCloseReasonCd() throws JOAException {
    return (String)m_oThis.getProperty("RC_CLOSE_REASON_CD");
 }

  public void setRcCloseReasonCd(String inRcCloseReasonCd) throws JOAException {
    m_oThis.setProperty("RC_CLOSE_REASON_CD", inRcCloseReasonCd);
 }

  public String getFdxActionTaken() throws JOAException {
    return (String)m_oThis.getProperty("FDX_ACTION_TAKEN");
 }

  public void setFdxActionTaken(String inFdxActionTaken) throws JOAException {
    m_oThis.setProperty("FDX_ACTION_TAKEN", inFdxActionTaken);
 }

  public String getFdxApplication() throws JOAException {
    return (String)m_oThis.getProperty("FDX_APPLICATION");
 }

  public void setFdxApplication(String inFdxApplication) throws JOAException {
    m_oThis.setProperty("FDX_APPLICATION", inFdxApplication);
 }

  public String getFdxBusImpact() throws JOAException {
    return (String)m_oThis.getProperty("FDX_BUS_IMPACT");
 }

  public void setFdxBusImpact(String inFdxBusImpact) throws JOAException {
    m_oThis.setProperty("FDX_BUS_IMPACT", inFdxBusImpact);
 }

  public String getFdxCause() throws JOAException {
    return (String)m_oThis.getProperty("FDX_CAUSE");
 }

  public void setFdxCause(String inFdxCause) throws JOAException {
    m_oThis.setProperty("FDX_CAUSE", inFdxCause);
 }

  public String getFdxDocAvailable() throws JOAException {
    return (String)m_oThis.getProperty("FDX_DOC_AVAILABLE");
 }

  public void setFdxDocAvailable(String inFdxDocAvailable) throws JOAException {
    m_oThis.setProperty("FDX_DOC_AVAILABLE", inFdxDocAvailable);
 }

  public String getFdxDocUseful() throws JOAException {
    return (String)m_oThis.getProperty("FDX_DOC_USEFUL");
 }

  public void setFdxDocUseful(String inFdxDocUseful) throws JOAException {
    m_oThis.setProperty("FDX_DOC_USEFUL", inFdxDocUseful);
 }

  public String getFdxEffEndDt() throws JOAException {
    return (String)m_oThis.getProperty("FDX_EFF_END_DT");
 }

  public void setFdxEffEndDt(String inFdxEffEndDt) throws JOAException {
    m_oThis.setProperty("FDX_EFF_END_DT", inFdxEffEndDt);
 }

  public String getFdxEffEndTime() throws JOAException {
    return (String)m_oThis.getProperty("FDX_EFF_END_TIME");
 }

  public void setFdxEffEndTime(String inFdxEffEndTime) throws JOAException {
    m_oThis.setProperty("FDX_EFF_END_TIME", inFdxEffEndTime);
 }

  public String getFdxEffStartDt() throws JOAException {
    return (String)m_oThis.getProperty("FDX_EFF_START_DT");
 }

  public void setFdxEffStartDt(String inFdxEffStartDt) throws JOAException {
    m_oThis.setProperty("FDX_EFF_START_DT", inFdxEffStartDt);
 }

  public String getFdxEffStartTime() throws JOAException {
    return (String)m_oThis.getProperty("FDX_EFF_START_TIME");
 }

  public void setFdxEffStartTime(String inFdxEffStartTime) throws JOAException {
    m_oThis.setProperty("FDX_EFF_START_TIME", inFdxEffStartTime);
 }

  public String getFdxFollowAction() throws JOAException {
    return (String)m_oThis.getProperty("FDX_FOLLOW_ACTION");
 }

  public void setFdxFollowAction(String inFdxFollowAction) throws JOAException {
    m_oThis.setProperty("FDX_FOLLOW_ACTION", inFdxFollowAction);
 }

  public String getFdxImpact() throws JOAException {
    return (String)m_oThis.getProperty("FDX_IMPACT");
 }

  public void setFdxImpact(String inFdxImpact) throws JOAException {
    m_oThis.setProperty("FDX_IMPACT", inFdxImpact);
 }

  public String getFdxKiReference() throws JOAException {
    return (String)m_oThis.getProperty("FDX_KI_REFERENCE");
 }

  public void setFdxKiReference(String inFdxKiReference) throws JOAException {
    m_oThis.setProperty("FDX_KI_REFERENCE", inFdxKiReference);
 }

  public String getFdxNode() throws JOAException {
    return (String)m_oThis.getProperty("FDX_NODE");
 }

  public void setFdxNode(String inFdxNode) throws JOAException {
    m_oThis.setProperty("FDX_NODE", inFdxNode);
 }

  public String getFdxGrouping() throws JOAException {
    return (String)m_oThis.getProperty("FDX_GROUPING");
 }

  public void setFdxGrouping(String inFdxGrouping) throws JOAException {
    m_oThis.setProperty("FDX_GROUPING", inFdxGrouping);
 }

  public String getFdxProblemDetail() throws JOAException {
    return (String)m_oThis.getProperty("FDX_PROBLEM_DETAIL");
 }

  public void setFdxProblemDetail(String inFdxProblemDetail) throws JOAException {
    m_oThis.setProperty("FDX_PROBLEM_DETAIL", inFdxProblemDetail);
 }

  public String getFdxSystem() throws JOAException {
    return (String)m_oThis.getProperty("FDX_SYSTEM");
 }

  public void setFdxSystem(String inFdxSystem) throws JOAException {
    m_oThis.setProperty("FDX_SYSTEM", inFdxSystem);
 }

  public String getFdxVendor() throws JOAException {
    return (String)m_oThis.getProperty("FDX_VENDOR");
 }

  public void setFdxVendor(String inFdxVendor) throws JOAException {
    m_oThis.setProperty("FDX_VENDOR", inFdxVendor);
 }

  public String getFdxVendId() throws JOAException {
    return (String)m_oThis.getProperty("FDX_VEND_ID");
 }

  public void setFdxVendId(String inFdxVendId) throws JOAException {
    m_oThis.setProperty("FDX_VEND_ID", inFdxVendId);
 }

  public String getRcDescrlong() throws JOAException {
    return (String)m_oThis.getProperty("RC_DESCRLONG");
 }

  public void setRcDescrlong(String inRcDescrlong) throws JOAException {
    m_oThis.setProperty("RC_DESCRLONG", inRcDescrlong);
 }

  public IFdxCaseJavaCiRcCaseNoteCollection getRcCaseNote() throws JOAException {
    return (IFdxCaseJavaCiRcCaseNoteCollection)m_oThis.getProperty("RC_CASE_NOTE");
 }

  public String getBusinessUnit() throws JOAException {
    return (String)m_oThis.getProperty("BUSINESS_UNIT");
 }

  public void setBusinessUnit(String inBusinessUnit) throws JOAException {
    m_oThis.setProperty("BUSINESS_UNIT", inBusinessUnit);
 }

  public boolean getInteractiveMode() throws JOAException {
    return ((Boolean)m_oThis.getProperty("InteractiveMode")).booleanValue();
 }

  public void setInteractiveMode(boolean inInteractiveMode) throws JOAException {
    m_oThis.setProperty("InteractiveMode", new Boolean(inInteractiveMode));
 }

  public boolean getGetHistoryItems() throws JOAException {
    return ((Boolean)m_oThis.getProperty("GetHistoryItems")).booleanValue();
 }

  public void setGetHistoryItems(boolean inGetHistoryItems) throws JOAException {
    m_oThis.setProperty("GetHistoryItems", new Boolean(inGetHistoryItems));
 }

  public boolean getEditHistoryItems() throws JOAException {
    return ((Boolean)m_oThis.getProperty("EditHistoryItems")).booleanValue();
 }

  public void setEditHistoryItems(boolean inEditHistoryItems) throws JOAException {
    m_oThis.setProperty("EditHistoryItems", new Boolean(inEditHistoryItems));
 }

  public String getComponentName() throws JOAException {
    return (String)m_oThis.getProperty("ComponentName");
 }

  public String getCompIntfcName() throws JOAException {
    return (String)m_oThis.getProperty("CompIntfcName");
 }

  public String getMarket() throws JOAException {
    return (String)m_oThis.getProperty("Market");
 }

  public String getDescription() throws JOAException {
    return (String)m_oThis.getProperty("Description");
 }

  public boolean getGetDummyRows() throws JOAException {
    return ((Boolean)m_oThis.getProperty("GetDummyRows")).booleanValue();
 }

  public void setGetDummyRows(boolean inGetDummyRows) throws JOAException {
    m_oThis.setProperty("GetDummyRows", new Boolean(inGetDummyRows));
 }

  public boolean getStopOnFirstError() throws JOAException {
    return ((Boolean)m_oThis.getProperty("StopOnFirstError")).booleanValue();
 }

  public void setStopOnFirstError(boolean inStopOnFirstError) throws JOAException {
    m_oThis.setProperty("StopOnFirstError", new Boolean(inStopOnFirstError));
 }

  public ICompIntfcPropertyInfoCollection getPropertyInfoCollection() throws JOAException {
    return (ICompIntfcPropertyInfoCollection)m_oThis.getProperty("PropertyInfoCollection");
 }

  public ICompIntfcPropertyInfoCollection getCreateKeyInfoCollection() throws JOAException {
    return (ICompIntfcPropertyInfoCollection)m_oThis.getProperty("CreateKeyInfoCollection");
 }

  public ICompIntfcPropertyInfoCollection getGetKeyInfoCollection() throws JOAException {
    return (ICompIntfcPropertyInfoCollection)m_oThis.getProperty("GetKeyInfoCollection");
 }

  public ICompIntfcPropertyInfoCollection getFindKeyInfoCollection() throws JOAException {
    return (ICompIntfcPropertyInfoCollection)m_oThis.getProperty("FindKeyInfoCollection");
 }

  public boolean get() throws JOAException {
    Object[] args = new Object[0];
    return ((Boolean)(m_oThis.invokeMethod("Get", args))).booleanValue();
    }

  public boolean create() throws JOAException {
    Object[] args = new Object[0];
    return ((Boolean)(m_oThis.invokeMethod("Create", args))).booleanValue();
    }

  public boolean save() throws JOAException {
    Object[] args = new Object[0];
    return ((Boolean)(m_oThis.invokeMethod("Save", args))).booleanValue();
    }

  public boolean cancel() throws JOAException {
    Object[] args = new Object[0];
    return ((Boolean)(m_oThis.invokeMethod("Cancel", args))).booleanValue();
    }

  public IFdxCaseJavaCiCollection find() throws JOAException {
    Object[] args = new Object[0];
    return (IFdxCaseJavaCiCollection)m_oThis.invokeMethod("Find", args);
    }

  public Object getPropertyByName(String Name) throws JOAException {
    Object[] args = new Object[1];
    args[0] = Name;
    return (Object)m_oThis.invokeMethod("GetPropertyByName", args);
    }

  public long setPropertyByName(String Name, Object Value) throws JOAException {
    Object[] args = new Object[2];
    args[0] = Name;
    args[1] = Value;
    return ((Long)(m_oThis.invokeMethod("SetPropertyByName", args))).longValue();
    }

  public ICompIntfcPropertyInfo getPropertyInfoByName(String Name) throws JOAException {
    Object[] args = new Object[1];
    args[0] = Name;
    return (ICompIntfcPropertyInfo)m_oThis.invokeMethod("GetPropertyInfoByName", args);
    }

  public long loadNotes() throws JOAException {
    Object[] args = new Object[0];
    return ((Long)(m_oThis.invokeMethod("LoadNotes", args))).longValue();
    }

  IObject m_oThis;
  }
