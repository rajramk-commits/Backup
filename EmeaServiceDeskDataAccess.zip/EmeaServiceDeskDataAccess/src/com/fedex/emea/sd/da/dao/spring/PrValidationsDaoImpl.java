package com.fedex.emea.sd.da.dao.spring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrValidationsDao;
import com.fedex.emea.sd.da.exceptions.PrValidationsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrValidations;
import com.fedex.emea.sd.da.objects.PrValidationsPk;

public class PrValidationsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrValidations>, PrValidationsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrValidationsPk
	 */
	@Transactional
	public PrValidationsPk insert(PrValidations dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getDrDocRecvd(),dto.getValType(),dto.getValComponent(),dto.getValScenario(),dto.getValJustif(),dto.getValEstmatedTestDttm(),dto.getValConfirmedTestDttm(),dto.getValStatus(),dto.getValRemarks(),dto.getValResult(),dto.getValGaps(),dto.getValPropActions(),dto.getLastUpdateDttm(),dto.getSymProfName(),dto.getNi2BusCrit(),dto.isAuditIdNull()?null:dto.getAuditId(),dto.isValRtaNull()?null:dto.getValRta(),dto.getOrg());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_VALIDATIONS table.
	 */
	@Transactional
	public void update(PrValidationsPk pk, PrValidations dto) throws PrValidationsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET CY = ?, EAI_ID = ?, SYM_APP_NAME = ?, NI2_APP_ID = ?, NI2_APP_NAME = ?, RESP_MD_PIN = ?, RESP_MGR_PIN = ?, DR_DOC_RECVD = ?, VAL_TYPE = ?, VAL_COMPONENT = ?, VAL_SCENARIO = ?, VAL_JUSTIF = ?, VAL_ESTMATED_TEST_DTTM = ?, VAL_CONFIRMED_TEST_DTTM = ?, VAL_STATUS = ?, VAL_REMARKS = ?, VAL_RESULT = ?, VAL_GAPS = ?, VAL_PROP_ACTIONS = ?, LAST_UPDATE_DTTM = ?, SYM_PROF_NAME = ?, NI2_BUS_CRIT = ?, AUDIT_ID = ?, VAL_RTA = ? WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getDrDocRecvd(),dto.getValType(),dto.getValComponent(),dto.getValScenario(),dto.getValJustif(),dto.getValEstmatedTestDttm(),dto.getValConfirmedTestDttm(),dto.getValStatus(),dto.getValRemarks(),dto.getValResult(),dto.getValGaps(),dto.getValPropActions(),dto.getLastUpdateDttm(),dto.getSymProfName(),dto.getNi2BusCrit(),dto.getAuditId(),dto.getValRta(),pk.getCy(),pk.getEaiId(),pk.getNi2AppId());
	}

	/** 
	 * Deletes a single row in the PR_VALIDATIONS table.
	 */
	@Transactional
	public void delete(PrValidationsPk pk) throws PrValidationsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?",pk.getCy(),pk.getEaiId(),pk.getNi2AppId());
	}
	
	/** 
	 * Deletes rows per Application Key + CY.
	 */
	@Transactional
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrValidationsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?",appKey.getCy(),appKey.getSymEaiId(),appKey.getNi2AppId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrValidations
	 */
	public PrValidations mapRow(ResultSet rs, int row) throws SQLException
	{
		PrValidations dto = new PrValidations();
		dto.setCy( rs.getString( 1 ) );
		dto.setEaiId( rs.getString( 2 ) );
		dto.setSymAppName( rs.getString( 3 ) );
		dto.setNi2AppId( rs.getString( 4 ) );
		dto.setNi2AppName( rs.getString( 5 ) );
		dto.setRespMdPin( rs.getString( 6 ) );
		dto.setRespMgrPin( rs.getString( 7 ) );
		dto.setDrDocRecvd( rs.getString( 8 ) );
		dto.setValType( rs.getString( 9 ) );
		dto.setValComponent( rs.getString( 10 ) );
		dto.setValScenario( rs.getString( 11 ) );
		dto.setValJustif( rs.getString( 12 ) );
		dto.setValEstmatedTestDttm( rs.getTimestamp(13 ) );
		dto.setValConfirmedTestDttm( rs.getTimestamp(14 ) );
		dto.setValStatus( rs.getString( 15 ) );
		dto.setValRemarks( rs.getString( 16 ) );
		dto.setValResult( rs.getString( 17 ) );
		dto.setValGaps( rs.getString( 18 ) );
		dto.setValPropActions( rs.getString( 19 ) );
		dto.setLastUpdateDttm( rs.getTimestamp(20 ) );
		dto.setSymProfName( rs.getString( 21 ) );
		dto.setNi2BusCrit( rs.getString( 22 ) );
		dto.setAuditId( rs.getInt( 23 ) );
		if (rs.wasNull()) {
			dto.setAuditIdNull( true );
		}
		
		dto.setValRta( rs.getInt( 24 ) );
		if (rs.wasNull()) {
			dto.setValRtaNull( true );
		}
		dto.setOrg( rs.getString( 25 ) );
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_VALIDATIONS";
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public PrValidations findByPrimaryKey(String cy, String eaiId, String ni2AppId) throws PrValidationsDaoException
	{
		try {
			List<PrValidations> list = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?", this,cy,eaiId,ni2AppId);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria ''.
	 */
	@Transactional
	public List<PrValidations> findAll() throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " ORDER BY CY, EAI_ID, NI2_APP_ID", this);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'CY = :cy'.
	 */
	@Transactional
	public List<PrValidations> findWhereCyEquals(String cy) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all keys (CMDB ID, EID ID) from the PR_VALIDATIONS table per CY.
	 */
	@Transactional
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrValidationsDaoException {
		List<PeakReadinessAppKeys> returnedList = new ArrayList<PeakReadinessAppKeys>();
		
		try {
			List<PrValidations> eltList = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
			for (PrValidations elt: eltList) {
				returnedList.add(new PeakReadinessAppKeys(cy, elt.getNi2AppId(), elt.getEaiId()));
			}
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
		return returnedList;
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	@Transactional
	public List<PrValidations> findWhereEaiIdEquals(String eaiId) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE EAI_ID = ? ORDER BY EAI_ID", this,eaiId);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	@Transactional
	public List<PrValidations> findWhereSymAppNameEquals(String symAppName) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE SYM_APP_NAME = ? ORDER BY SYM_APP_NAME", this,symAppName);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public List<PrValidations> findWhereNi2AppIdEquals(String ni2AppId) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE NI2_APP_ID = ? ORDER BY NI2_APP_ID", this,ni2AppId);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	@Transactional
	public List<PrValidations> findWhereNi2AppNameEquals(String ni2AppName) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE NI2_APP_NAME = ? ORDER BY NI2_APP_NAME", this,ni2AppName);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	@Transactional
	public List<PrValidations> findWhereRespMdPinEquals(String respMdPin) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE RESP_MD_PIN = ? ORDER BY RESP_MD_PIN", this,respMdPin);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	@Transactional
	public List<PrValidations> findWhereRespMgrPinEquals(String respMgrPin) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE RESP_MGR_PIN = ? ORDER BY RESP_MGR_PIN", this,respMgrPin);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'DR_DOC_RECVD = :drDocRecvd'.
	 */
	@Transactional
	public List<PrValidations> findWhereDrDocRecvdEquals(String drDocRecvd) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE DR_DOC_RECVD = ? ORDER BY DR_DOC_RECVD", this,drDocRecvd);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_TYPE = :valType'.
	 */
	@Transactional
	public List<PrValidations> findWhereValTypeEquals(String valType) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_TYPE = ? ORDER BY VAL_TYPE", this,valType);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_COMPONENT = :valComponent'.
	 */
	@Transactional
	public List<PrValidations> findWhereValComponentEquals(String valComponent) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_COMPONENT = ? ORDER BY VAL_COMPONENT", this,valComponent);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_SCENARIO = :valScenario'.
	 */
	@Transactional
	public List<PrValidations> findWhereValScenarioEquals(String valScenario) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_SCENARIO = ? ORDER BY VAL_SCENARIO", this,valScenario);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_JUSTIF = :valJustif'.
	 */
	@Transactional
	public List<PrValidations> findWhereValJustifEquals(String valJustif) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_JUSTIF = ? ORDER BY VAL_JUSTIF", this,valJustif);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_ESTMATED_TEST_DTTM = :valEstmatedTestDttm'.
	 */
	@Transactional
	public List<PrValidations> findWhereValEstmatedTestDttmEquals(Date valEstmatedTestDttm) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_ESTMATED_TEST_DTTM = ? ORDER BY VAL_ESTMATED_TEST_DTTM", this,valEstmatedTestDttm);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_CONFIRMED_TEST_DTTM = :valConfirmedTestDttm'.
	 */
	@Transactional
	public List<PrValidations> findWhereValConfirmedTestDttmEquals(Date valConfirmedTestDttm) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_CONFIRMED_TEST_DTTM = ? ORDER BY VAL_CONFIRMED_TEST_DTTM", this,valConfirmedTestDttm);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_STATUS = :valStatus'.
	 */
	@Transactional
	public List<PrValidations> findWhereValStatusEquals(String valStatus) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_STATUS = ? ORDER BY VAL_STATUS", this,valStatus);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_REMARKS = :valRemarks'.
	 */
	@Transactional
	public List<PrValidations> findWhereValRemarksEquals(String valRemarks) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_REMARKS = ? ORDER BY VAL_REMARKS", this,valRemarks);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_RESULT = :valResult'.
	 */
	@Transactional
	public List<PrValidations> findWhereValResultEquals(String valResult) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_RESULT = ? ORDER BY VAL_RESULT", this,valResult);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_GAPS = :valGaps'.
	 */
	@Transactional
	public List<PrValidations> findWhereValGapsEquals(String valGaps) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_GAPS = ? ORDER BY VAL_GAPS", this,valGaps);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_PROP_ACTIONS = :valPropActions'.
	 */
	@Transactional
	public List<PrValidations> findWhereValPropActionsEquals(String valPropActions) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_PROP_ACTIONS = ? ORDER BY VAL_PROP_ACTIONS", this,valPropActions);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	@Transactional
	public List<PrValidations> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE LAST_UPDATE_DTTM = ? ORDER BY LAST_UPDATE_DTTM", this,lastUpdateDttm);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'SYM_PROF_NAME = :symProfName'.
	 */
	@Transactional
	public List<PrValidations> findWhereSymProfNameEquals(String symProfName) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE SYM_PROF_NAME = ? ORDER BY SYM_PROF_NAME", this,symProfName);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_BUS_CRIT = :ni2BusCrit'.
	 */
	@Transactional
	public List<PrValidations> findWhereNi2BusCritEquals(String ni2BusCrit) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE NI2_BUS_CRIT = ? ORDER BY NI2_BUS_CRIT", this,ni2BusCrit);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	@Transactional
	public List<PrValidations> findWhereAuditIdEquals(int auditId) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE AUDIT_ID = ? ORDER BY AUDIT_ID", this,auditId);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_RTA = :valRta'.
	 */
	@Transactional
	public List<PrValidations> findWhereValRtaEquals(int valRta) throws PrValidationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, DR_DOC_RECVD, VAL_TYPE, VAL_COMPONENT, VAL_SCENARIO, VAL_JUSTIF, VAL_ESTMATED_TEST_DTTM, VAL_CONFIRMED_TEST_DTTM, VAL_STATUS, VAL_REMARKS, VAL_RESULT, VAL_GAPS, VAL_PROP_ACTIONS, LAST_UPDATE_DTTM, SYM_PROF_NAME, NI2_BUS_CRIT, AUDIT_ID, VAL_RTA, ORG FROM " + getTableName() + " WHERE VAL_RTA = ? ORDER BY VAL_RTA", this,valRta);
		}
		catch (Exception e) {
			throw new PrValidationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_VALIDATIONS table that matches the specified primary-key value.
	 */
	public PrValidations findByPrimaryKey(PrValidationsPk pk) throws PrValidationsDaoException
	{
		return findByPrimaryKey( pk.getCy(), pk.getEaiId(), pk.getNi2AppId() );
	}

}
