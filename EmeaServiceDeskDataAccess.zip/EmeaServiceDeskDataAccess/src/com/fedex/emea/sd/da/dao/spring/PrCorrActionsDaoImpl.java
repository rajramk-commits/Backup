package com.fedex.emea.sd.da.dao.spring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrCorrActionsDao;
import com.fedex.emea.sd.da.exceptions.PrCorrActionsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrCorrActions;
import com.fedex.emea.sd.da.objects.PrCorrActionsPk;

public class PrCorrActionsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrCorrActions>, PrCorrActionsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrCorrActionsPk
	 */
	@Transactional
	public PrCorrActionsPk insert(PrCorrActions dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getItem(),dto.getAction(),dto.getActionImportance(),dto.getActionBy(),dto.getActionFeedback(),dto.getActionStatus(),dto.getLastUpdateDttm(),dto.isAuditIdNull()?null:dto.getAuditId(), dto.getOrg());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_CORR_ACTIONS table.
	 */
	@Transactional
	public void update(PrCorrActionsPk pk, PrCorrActions dto) throws PrCorrActionsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET CY = ?, EAI_ID = ?, SYM_APP_NAME = ?, NI2_APP_ID = ?, NI2_APP_NAME = ?, RESP_MD_PIN = ?, RESP_MGR_PIN = ?, ITEM = ?, ACTION = ?, ACTION_IMPORTANCE = ?, ACTION_BY = ?, ACTION_FEEDBACK = ?, ACTION_STATUS = ?, LAST_UPDATE_DTTM = ?, AUDIT_ID = ?, ORG = ? WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getItem(),dto.getAction(),dto.getActionImportance(),dto.getActionBy(),dto.getActionFeedback(),dto.getActionStatus(),dto.getLastUpdateDttm(),dto.getAuditId(),dto.getOrg(),pk.getCy(),pk.getEaiId(),pk.getNi2AppId(),pk.getItem());
	}

	/** 
	 * Deletes a single row in the PR_CORR_ACTIONS table.
	 */
	@Transactional
	public void delete(PrCorrActionsPk pk) throws PrCorrActionsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?",pk.getCy(),pk.getEaiId(),pk.getNi2AppId(),pk.getItem());
	}
	
	/** 
	 * Deletes rows per Application Key + CY.
	 */
	@Transactional
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrCorrActionsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?",appKey.getCy(),appKey.getSymEaiId(),appKey.getNi2AppId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrCorrActions
	 */
	public PrCorrActions mapRow(ResultSet rs, int row) throws SQLException
	{
		PrCorrActions dto = new PrCorrActions();
		dto.setCy( rs.getString( 1 ) );
		dto.setEaiId( rs.getString( 2 ) );
		dto.setSymAppName( rs.getString( 3 ) );
		dto.setNi2AppId( rs.getString( 4 ) );
		dto.setNi2AppName( rs.getString( 5 ) );
		dto.setRespMdPin( rs.getString( 6 ) );
		dto.setRespMgrPin( rs.getString( 7 ) );
		dto.setItem( rs.getString( 8 ) );
		dto.setAction( rs.getString( 9 ) );
		dto.setActionImportance( rs.getString( 10 ) );
		dto.setActionBy( rs.getTimestamp(11 ) );
		dto.setActionFeedback( rs.getString( 12 ) );
		dto.setActionStatus( rs.getString( 13 ) );
		dto.setLastUpdateDttm( rs.getTimestamp(14 ) );
		dto.setAuditId( rs.getInt( 15 ) );
		if (rs.wasNull()) {
			dto.setAuditIdNull( true );
		}
		dto.setOrg( rs.getString( 16 ) );
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_CORR_ACTIONS";
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId AND ITEM = :item'.
	 */
	@Transactional
	public PrCorrActions findByPrimaryKey(String cy, String eaiId, String ni2AppId, String item) throws PrCorrActionsDaoException
	{
		try {
			List<PrCorrActions> list = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?", this,cy,eaiId,ni2AppId,item);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria ''.
	 */
	@Transactional
	public List<PrCorrActions> findAll() throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " ORDER BY CY, EAI_ID, NI2_APP_ID, ITEM", this);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'CY = :cy'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereCyEquals(String cy) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all keys (CMDB ID, EID ID) from the PR_CORR_ACTIONS table per CY.
	 */
	@Transactional
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrCorrActionsDaoException {
		List<PeakReadinessAppKeys> returnedList = new ArrayList<PeakReadinessAppKeys>();
		
		try {
			List<PrCorrActions> eltList = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
			for (PrCorrActions elt: eltList) {
				returnedList.add(new PeakReadinessAppKeys(cy, elt.getNi2AppId(), elt.getEaiId()));
			}
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
		return returnedList;
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereEaiIdEquals(String eaiId) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE EAI_ID = ? ORDER BY EAI_ID", this,eaiId);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereSymAppNameEquals(String symAppName) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SYM_APP_NAME = ? ORDER BY SYM_APP_NAME", this,symAppName);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereNi2AppIdEquals(String ni2AppId) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_ID = ? ORDER BY NI2_APP_ID", this,ni2AppId);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereNi2AppNameEquals(String ni2AppName) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_NAME = ? ORDER BY NI2_APP_NAME", this,ni2AppName);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereRespMdPinEquals(String respMdPin) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MD_PIN = ? ORDER BY RESP_MD_PIN", this,respMdPin);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereRespMgrPinEquals(String respMgrPin) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MGR_PIN = ? ORDER BY RESP_MGR_PIN", this,respMgrPin);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ITEM = :item'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereItemEquals(String item) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ITEM = ? ORDER BY ITEM", this,item);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION = :action'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereActionEquals(String action) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ACTION = ? ORDER BY ACTION", this,action);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_IMPORTANCE = :actionImportance'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereActionImportanceEquals(String actionImportance) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ACTION_IMPORTANCE = ? ORDER BY ACTION_IMPORTANCE", this,actionImportance);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_BY = :actionBy'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereActionByEquals(Date actionBy) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ACTION_BY = ? ORDER BY ACTION_BY", this,actionBy);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_FEEDBACK = :actionFeedback'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereActionFeedbackEquals(String actionFeedback) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ACTION_FEEDBACK = ? ORDER BY ACTION_FEEDBACK", this,actionFeedback);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_STATUS = :actionStatus'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereActionStatusEquals(String actionStatus) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ACTION_STATUS = ? ORDER BY ACTION_STATUS", this,actionStatus);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE LAST_UPDATE_DTTM = ? ORDER BY LAST_UPDATE_DTTM", this,lastUpdateDttm);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	@Transactional
	public List<PrCorrActions> findWhereAuditIdEquals(int auditId) throws PrCorrActionsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, ACTION, ACTION_IMPORTANCE, ACTION_BY, ACTION_FEEDBACK, ACTION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE AUDIT_ID = ? ORDER BY AUDIT_ID", this,auditId);
		}
		catch (Exception e) {
			throw new PrCorrActionsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_CORR_ACTIONS table that matches the specified primary-key value.
	 */
	public PrCorrActions findByPrimaryKey(PrCorrActionsPk pk) throws PrCorrActionsDaoException
	{
		return findByPrimaryKey( pk.getCy(), pk.getEaiId(), pk.getNi2AppId(), pk.getItem() );
	}

}
