package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.AllocatedtoassociationDaoException;
import com.fedex.emea.sd.da.objects.Allocatedtoassociation;
import com.fedex.emea.sd.da.objects.AllocatedtoassociationPk;

public interface AllocatedtoassociationDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return AllocatedtoassociationPk
	 */
	public AllocatedtoassociationPk insert(Allocatedtoassociation dto);

	/** 
	 * Updates a single row in the ALLOCATEDTOASSOCIATION table.
	 */
	public void update(AllocatedtoassociationPk pk, Allocatedtoassociation dto) throws AllocatedtoassociationDaoException;

	/** 
	 * Deletes a single row in the ALLOCATEDTOASSOCIATION table.
	 */
	public void delete(AllocatedtoassociationPk pk) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ID = :id'.
	 */
	public Allocatedtoassociation findByPrimaryKey(String id) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria ''.
	 */
	public List<Allocatedtoassociation> findAll() throws AllocatedtoassociationDaoException;
	
	public Allocatedtoassociation findRelatedToInPrScope(String appId) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ID = :id'.
	 */
	public List<Allocatedtoassociation> findWhereIdEquals(String id) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATEE_KEY_PK = :allocateeKeyPk'.
	 */
	public List<Allocatedtoassociation> findWhereAllocateeKeyPkEquals(String allocateeKeyPk) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATEE_KEY_TYPE = :allocateeKeyType'.
	 */
	public List<Allocatedtoassociation> findWhereAllocateeKeyTypeEquals(String allocateeKeyType) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATED_KEY_PK = :allocatedKeyPk'.
	 */
	public List<Allocatedtoassociation> findWhereAllocatedKeyPkEquals(String allocatedKeyPk) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATED_KEY_TYPE = :allocatedKeyType'.
	 */
	public List<Allocatedtoassociation> findWhereAllocatedKeyTypeEquals(String allocatedKeyType) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	public List<Allocatedtoassociation> findWhereDescriptionEquals(String description) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	public List<Allocatedtoassociation> findWhereLongDescriptionEquals(String longDescription) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	public List<Allocatedtoassociation> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	public List<Allocatedtoassociation> findWhereLastModificationDateEquals(Date lastModificationDate) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	public List<Allocatedtoassociation> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	public List<Allocatedtoassociation> findWhereCustom1Equals(String custom1) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	public List<Allocatedtoassociation> findWhereCustom2Equals(String custom2) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	public List<Allocatedtoassociation> findWhereCustom3Equals(String custom3) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	public List<Allocatedtoassociation> findWhereCustom4Equals(String custom4) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	public List<Allocatedtoassociation> findWhereCustom5Equals(String custom5) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	public List<Allocatedtoassociation> findWhereCustom6Equals(String custom6) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	public List<Allocatedtoassociation> findWhereCustom7Equals(String custom7) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	public List<Allocatedtoassociation> findWhereCustom8Equals(String custom8) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	public List<Allocatedtoassociation> findWhereCustom9Equals(String custom9) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	public List<Allocatedtoassociation> findWhereCustom10Equals(String custom10) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	public List<Allocatedtoassociation> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws AllocatedtoassociationDaoException;

	/** 
	 * Returns the rows from the ALLOCATEDTOASSOCIATION table that matches the specified primary-key value.
	 */
	public Allocatedtoassociation findByPrimaryKey(AllocatedtoassociationPk pk) throws AllocatedtoassociationDaoException;

}
