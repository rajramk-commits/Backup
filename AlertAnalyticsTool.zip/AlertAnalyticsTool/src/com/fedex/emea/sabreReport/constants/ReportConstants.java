package com.fedex.emea.sabreReport.constants;

public class ReportConstants {
	public static final String DIRECTORY_PATH ="C:/Users/rajarama.kaniyoor/Documents/SabreConnect/Results/"; 
			//"E:\\AlertReports\\";
			//"/var/fedex/ServiceDeskAutomation/AlertAnalyticsTool/output/";
			//"C:\\Users\\5126675\\Documents\\Results\\";
	public static final String REPORT_FILE_NAME = "SABRE Report.xlsx";
	
}
