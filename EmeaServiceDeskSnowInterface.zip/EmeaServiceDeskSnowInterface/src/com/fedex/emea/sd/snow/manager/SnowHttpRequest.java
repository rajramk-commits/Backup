package com.fedex.emea.sd.snow.manager;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.json.JSONObject;

import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class SnowHttpRequest {
	
	private String        queryTableURL;
	private String        queryIncidentURL;
	private String        queryAstcIncidentUpdateURL;
	private String        querySysJournalFieldURL;
	private String        queryStatsURL;
	private RequestConfig config;
	
	public SnowHttpRequest() {
		this.queryTableURL              = SnowConstants.SNOW_PROD.getSnowQueryTableURL();
	    this.queryIncidentURL           = SnowConstants.SNOW_PROD.getSnowQueryIncidentURL();
		this.queryAstcIncidentUpdateURL = SnowConstants.SNOW_PROD.getSnowQueryAstcIncidentUpdateURL();
		this.querySysJournalFieldURL    = SnowConstants.SNOW_PROD.getSnowQuerySysJournalFieldURL();
		this.queryStatsURL              = SnowConstants.SNOW_PROD.getSnowQueryStatsURL();
		
		/*this.queryTableURL              = SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryTableURL();
		this.queryIncidentURL           = SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryIncidentURL();
		this.queryAstcIncidentUpdateURL = SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryAstcIncidentUpdateURL();
		this.querySysJournalFieldURL    = SnowConstants.EPDSM_UAT_DIRECT.getSnowQuerySysJournalFieldURL();
		this.queryStatsURL              = SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryStatsURL();*/
		
//		this.queryTableURL              = SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryTableURL();
//		this.queryIncidentURL           = SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryIncidentURL();
//		this.queryAstcIncidentUpdateURL = SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryAstcIncidentUpdateURL();
//		this.querySysJournalFieldURL    = SnowConstants.EPDSM_PROD_DIRECT.getSnowQuerySysJournalFieldURL();
//		this.queryStatsURL              = SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryStatsURL();
	}
	
	
	public SnowHttpRequest(String pQueryTableURL, String pQueryIncidentURL, String pQueryAstcIncidentUpdateURL, String pQuerySysJournalFieldURL, String pQueryStatsURL, RequestConfig config) {
		this.queryTableURL              = pQueryTableURL;
		this.queryIncidentURL           = pQueryIncidentURL;
		this.queryAstcIncidentUpdateURL = pQueryAstcIncidentUpdateURL;
		this.querySysJournalFieldURL    = pQuerySysJournalFieldURL;
		this.queryStatsURL              = pQueryStatsURL;
		this.config                     = config;
	}

	// ******************************************************************************************
	//                                         POST
	// ******************************************************************************************

	public HttpPost postIncidentRequest(JSONObject newIncidentData) {
		HttpPost postRequest = new HttpPost(queryIncidentURL);
		postRequest.addHeader("Content-Type", "application/json");
		postRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) postRequest.setConfig(config);
		postRequest.setEntity(new StringEntity(newIncidentData.toString(), ContentType.APPLICATION_JSON));
		
		return postRequest;
	}
	
	public HttpPost postAstcIncidentUpdateRequest(JSONObject incidentData) {
		HttpPost postRequest = new HttpPost(queryAstcIncidentUpdateURL);
		postRequest.addHeader("Content-Type", "application/json");
		postRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) postRequest.setConfig(config);
		postRequest.setEntity(new StringEntity(incidentData.toString(), ContentType.APPLICATION_JSON));
		
		return postRequest;
	}
	
	public HttpPost postWorkNoteRequest(JSONObject newWorkNoteData) {
		HttpPost postRequest = new HttpPost(querySysJournalFieldURL);
		postRequest.addHeader("Content-Type", "application/json");
		postRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) postRequest.setConfig(config);
		postRequest.setEntity(new StringEntity(newWorkNoteData.toString(), ContentType.APPLICATION_JSON));
		
		return postRequest;
	}
	
	// ******************************************************************************************
	//                                         PUT
	// ******************************************************************************************

	
	public HttpPut putIncidentRequest(String sysId, JSONObject updatedIncidentData) {
		String updateURL = queryIncidentURL + "/" + sysId;
		
		HttpPut putRequest = new HttpPut(updateURL);
		putRequest.addHeader("Content-Type", "application/json");
		putRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) putRequest.setConfig(config);
		putRequest.setEntity(new StringEntity(updatedIncidentData.toString(), ContentType.APPLICATION_JSON));
		
		return putRequest;
	}
	
	// ******************************************************************************************
	//                                         GET
	// ******************************************************************************************
	
	public HttpGet getTableRequest(String tableName, String fields) {
		StringBuilder fieldsParam = new StringBuilder();
		
		String getURL = queryTableURL + tableName;
		
		if (fields != null) {
			fieldsParam.append("?sysparm_fields=");
			fieldsParam.append(fields);
			getURL = getURL + fieldsParam.toString();
		}
		
		HttpGet getRequest = new HttpGet(getURL);
		getRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) getRequest.setConfig(config);

		return getRequest;
	}
	
	public HttpGet getTableRequestBySingleFilter(String tableName, String fields, SnowSearchFilter filter) {
		StringBuilder searchParam = new StringBuilder();
		
		if (fields != null) {
			searchParam.append("?sysparm_fields=");
			searchParam.append(fields);
			searchParam.append("&sysparm_query=");
		} else {
			searchParam.append("?sysparm_query=");
		}
		
		searchParam.append(filter.toString());
		
		String getURL = queryTableURL + tableName  + searchParam.toString();
		
		HttpGet getRequest = new HttpGet(getURL);
		getRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) getRequest.setConfig(config);

		return getRequest;
	}
	
	public HttpGet getTableRequestByMultiFilters(String tableName, String fields, List<SnowSearchFilter> filters) throws UnsupportedEncodingException {
		StringBuilder queryString = new StringBuilder();
		
		if (fields != null) {
			queryString.append("?sysparm_fields=");
			queryString.append(fields);
			queryString.append("&sysparm_query=");
		} else {
			queryString.append("?sysparm_query=");
		}
				
		StringBuilder searchParam = new StringBuilder();
		
		for (SnowSearchFilter filter: filters) {
			if (searchParam.toString().isEmpty()) {
				searchParam.append(filter.toString());
			} else {
				searchParam.append("^");
				searchParam.append(filter.toString());
			}
		}
		
		queryString.append(URLEncoder.encode(searchParam.toString(), StandardCharsets.UTF_8.toString()));
		
		String getURL = queryTableURL + tableName + queryString.toString();
		
		HttpGet getRequest = new HttpGet(getURL);
		getRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) getRequest.setConfig(config);
		
		return getRequest;		
	}
	
	public HttpGet getStatsOnTableRequestByMultiFilters(String tableName, List<SnowSearchFilter> filters) throws UnsupportedEncodingException {
		StringBuilder queryString = new StringBuilder();
		
		queryString.append("?sysparm_count=true&sysparm_query=");
		
		StringBuilder searchParam = new StringBuilder();
		
		for (SnowSearchFilter filter: filters) {
			if (searchParam.toString().isEmpty()) {
				searchParam.append(filter.toString());
			} else {
				searchParam.append("^");
				searchParam.append(filter.toString());
			}
		}
		
		queryString.append(URLEncoder.encode(searchParam.toString(), StandardCharsets.UTF_8.toString()));
		
		String getURL = queryStatsURL + tableName + queryString.toString();
		
		HttpGet getRequest = new HttpGet(getURL);
		getRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) getRequest.setConfig(config);
		
		return getRequest;		
	}
	
	// ******************************************************************************************
	//                                         DELETE
	// ******************************************************************************************
	
	public HttpDelete deleteIncidentRequest(String sysId) {
		String deleteURL = queryIncidentURL + "/" + sysId;
		
		HttpDelete deleteRequest = new HttpDelete(deleteURL);
		deleteRequest.addHeader("Accept", "application/json");
		// *** To be used if PROXY needed ***
		if (config != null) deleteRequest.setConfig(config);
		return deleteRequest;		
	}
	
	// ******************************************************************************************
	//                                         Getters / Setters
	// ******************************************************************************************	

	public String getQueryTableURL() {
		return queryTableURL;
	}

	public void setQueryTableURL(String queryTableURL) {
		this.queryTableURL = queryTableURL;
	}

	public String getQueryIncidentURL() {
		return queryIncidentURL;
	}

	public void setQueryIncidentURL(String queryIncidentURL) {
		this.queryIncidentURL = queryIncidentURL;
	}

	public String getQuerySysJournalFieldURL() {
		return querySysJournalFieldURL;
	}

	public void setQuerySysJournalFieldURL(String querySysJournalFieldURL) {
		this.querySysJournalFieldURL = querySysJournalFieldURL;
	}
	
	public RequestConfig getConfig() {
		return config;
	}

	public void setConfig(RequestConfig config) {
		this.config = config;
	}

	public String getQueryStatsURL() {
		return queryStatsURL;
	}

	public void setQueryStatsURL(String queryStatsURL) {
		this.queryStatsURL = queryStatsURL;
	}

	public String getQueryAstcIncidentUpdateURL() {
		return queryAstcIncidentUpdateURL;
	}

	public void setQueryAstcIncidentUpdateURL(String queryAstcIncidentUpdateURL) {
		this.queryAstcIncidentUpdateURL = queryAstcIncidentUpdateURL;
	}

}
