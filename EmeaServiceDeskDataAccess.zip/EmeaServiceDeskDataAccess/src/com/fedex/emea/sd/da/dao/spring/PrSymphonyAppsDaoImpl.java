package com.fedex.emea.sd.da.dao.spring;

import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrSymphonyAppsDao;
import com.fedex.emea.sd.da.exceptions.PrSymphonyAppsDaoException;
import com.fedex.emea.sd.da.objects.PrSymphonyApps;
import com.fedex.emea.sd.da.objects.PrSymphonyAppsPk;

public class PrSymphonyAppsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrSymphonyApps>, PrSymphonyAppsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSymphonyAppsPk
	 */
	@Transactional
	public PrSymphonyAppsPk insert(PrSymphonyApps dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getSymEaiId(),dto.getSymAppName(),dto.getSymProfName(),dto.getSymItLead(),dto.getSymProjDispo(),dto.getSymDomain(),dto.getSymTier(),dto.getSymAppState(),dto.getSymFrmwrk(),dto.getSymDwnImp(),dto.getSymAvgTxDay(),dto.getSymRpo(),dto.getSymRto(),dto.getSymAccessTyp(),dto.getSymPlatform(),dto.getSymArchDsgn(),dto.getSymBacklogMeth(),dto.getSymBusFunc(),dto.getSymExtUsr(),dto.getSymIntUsr(),dto.getSymReglLegalFlg(),dto.getSymLastUpdDttm());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_SYMPHONY_APPS table.
	 */
	@Transactional
	public void update(PrSymphonyAppsPk pk, PrSymphonyApps dto) throws PrSymphonyAppsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET SYM_EAI_ID = ?, SYM_APP_NAME = ?, SYM_PROF_NAME = ?, SYM_IT_LEAD = ?, SYM_PROJ_DISPO = ?, SYM_DOMAIN = ?, SYM_TIER = ?, SYM_APP_STATE = ?, SYM_FRMWRK = ?, SYM_DWN_IMP = ?, SYM_AVG_TX_DAY = ?, SYM_RPO = ?, SYM_RTO = ?, SYM_ACCESS_TYP = ?, SYM_PLATFORM = ?, SYM_ARCH_DSGN = ?, SYM_BACKLOG_METH = ?, SYM_BUS_FUNC = ?, SYM_EXT_USR = ?, SYM_INT_USR = ?, SYM_REGL_LEGAL_FLG = ?, SYM_LAST_UPD_DTTM = ? WHERE SYM_EAI_ID = ?",dto.getSymEaiId(),dto.getSymAppName(),dto.getSymProfName(),dto.getSymItLead(),dto.getSymProjDispo(),dto.getSymDomain(),dto.getSymTier(),dto.getSymAppState(),dto.getSymFrmwrk(),dto.getSymDwnImp(),dto.getSymAvgTxDay(),dto.getSymRpo(),dto.getSymRto(),dto.getSymAccessTyp(),dto.getSymPlatform(),dto.getSymArchDsgn(),dto.getSymBacklogMeth(),dto.getSymBusFunc(),dto.getSymExtUsr(),dto.getSymIntUsr(),dto.getSymReglLegalFlg(),dto.getSymLastUpdDttm(),pk.getSymEaiId());
	}

	/** 
	 * Deletes a single row in the PR_SYMPHONY_APPS table.
	 */
	@Transactional
	public void delete(PrSymphonyAppsPk pk) throws PrSymphonyAppsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE SYM_EAI_ID = ?",pk.getSymEaiId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrSymphonyApps
	 */
	public PrSymphonyApps mapRow(ResultSet rs, int row) throws SQLException
	{
		PrSymphonyApps dto = new PrSymphonyApps();
		dto.setSymEaiId( rs.getString( 1 ) );
		dto.setSymAppName( rs.getString( 2 ) );
		dto.setSymProfName( rs.getString( 3 ) );
		dto.setSymItLead( rs.getString( 4 ) );
		dto.setSymProjDispo( rs.getString( 5 ) );
		dto.setSymDomain( rs.getString( 6 ) );
		dto.setSymTier( rs.getString( 7 ) );
		dto.setSymAppState( rs.getString( 8 ) );
		dto.setSymFrmwrk( rs.getString( 9 ) );
		dto.setSymDwnImp( rs.getString( 10 ) );
		dto.setSymAvgTxDay( rs.getString( 11 ) );
		dto.setSymRpo( rs.getString( 12 ) );
		dto.setSymRto( rs.getString( 13 ) );
		dto.setSymAccessTyp( rs.getString( 14 ) );
		dto.setSymPlatform( rs.getString( 15 ) );
		dto.setSymArchDsgn( rs.getString( 16 ) );
		dto.setSymBacklogMeth( rs.getString( 17 ) );
		dto.setSymBusFunc( rs.getString( 18 ) );
		dto.setSymExtUsr( rs.getString( 19 ) );
		dto.setSymIntUsr( rs.getString( 20 ) );
		dto.setSymReglLegalFlg( rs.getString( 21 ) );
		dto.setSymLastUpdDttm( rs.getTimestamp(22 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_SYMPHONY_APPS";
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	@Transactional
	public PrSymphonyApps findByPrimaryKey(String symEaiId) throws PrSymphonyAppsDaoException
	{
		try {
			List<PrSymphonyApps> list = jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_EAI_ID = ?", this,symEaiId);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria ''.
	 */
	@Transactional
	public List<PrSymphonyApps> findAll() throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " ORDER BY SYM_EAI_ID", this);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymEaiIdEquals(String symEaiId) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_EAI_ID = ? ORDER BY SYM_EAI_ID", this,symEaiId);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymAppNameEquals(String symAppName) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_APP_NAME = ? ORDER BY SYM_APP_NAME", this,symAppName);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PROF_NAME = :symProfName'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymProfNameEquals(String symProfName) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_PROF_NAME = ? ORDER BY SYM_PROF_NAME", this,symProfName);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_IT_LEAD = :symItLead'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymItLeadEquals(String symItLead) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_IT_LEAD = ? ORDER BY SYM_IT_LEAD", this,symItLead);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PROJ_DISPO = :symProjDispo'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymProjDispoEquals(String symProjDispo) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_PROJ_DISPO = ? ORDER BY SYM_PROJ_DISPO", this,symProjDispo);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_DOMAIN = :symDomain'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymDomainEquals(String symDomain) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_DOMAIN = ? ORDER BY SYM_DOMAIN", this,symDomain);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_TIER = :symTier'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymTierEquals(String symTier) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_TIER = ? ORDER BY SYM_TIER", this,symTier);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_APP_STATE = :symAppState'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymAppStateEquals(String symAppState) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_APP_STATE = ? ORDER BY SYM_APP_STATE", this,symAppState);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_FRMWRK = :symFrmwrk'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymFrmwrkEquals(String symFrmwrk) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_FRMWRK = ? ORDER BY SYM_FRMWRK", this,symFrmwrk);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_DWN_IMP = :symDwnImp'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymDwnImpEquals(String symDwnImp) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_DWN_IMP = ? ORDER BY SYM_DWN_IMP", this,symDwnImp);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_AVG_TX_DAY = :symAvgTxDay'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymAvgTxDayEquals(String symAvgTxDay) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_AVG_TX_DAY = ? ORDER BY SYM_AVG_TX_DAY", this,symAvgTxDay);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_RPO = :symRpo'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymRpoEquals(String symRpo) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_RPO = ? ORDER BY SYM_RPO", this,symRpo);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_RTO = :symRto'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymRtoEquals(String symRto) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_RTO = ? ORDER BY SYM_RTO", this,symRto);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_ACCESS_TYP = :symAccessTyp'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymAccessTypEquals(String symAccessTyp) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_ACCESS_TYP = ? ORDER BY SYM_ACCESS_TYP", this,symAccessTyp);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_PLATFORM = :symPlatform'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymPlatformEquals(String symPlatform) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_PLATFORM = ? ORDER BY SYM_PLATFORM", this,symPlatform);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_ARCH_DSGN = :symArchDsgn'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymArchDsgnEquals(String symArchDsgn) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_ARCH_DSGN = ? ORDER BY SYM_ARCH_DSGN", this,symArchDsgn);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_BACKLOG_METH = :symBacklogMeth'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymBacklogMethEquals(String symBacklogMeth) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_BACKLOG_METH = ? ORDER BY SYM_BACKLOG_METH", this,symBacklogMeth);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_BUS_FUNC = :symBusFunc'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymBusFuncEquals(String symBusFunc) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_BUS_FUNC = ? ORDER BY SYM_BUS_FUNC", this,symBusFunc);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_EXT_USR = :symExtUsr'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymExtUsrEquals(String symExtUsr) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_EXT_USR = ? ORDER BY SYM_EXT_USR", this,symExtUsr);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_INT_USR = :symIntUsr'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymIntUsrEquals(String symIntUsr) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_INT_USR = ? ORDER BY SYM_INT_USR", this,symIntUsr);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_REGL_LEGAL_FLG = :symReglLegalFlg'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymReglLegalFlgEquals(String symReglLegalFlg) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_REGL_LEGAL_FLG = ? ORDER BY SYM_REGL_LEGAL_FLG", this,symReglLegalFlg);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYMPHONY_APPS table that match the criteria 'SYM_LAST_UPD_DTTM = :symLastUpdDttm'.
	 */
	@Transactional
	public List<PrSymphonyApps> findWhereSymLastUpdDttmEquals(Date symLastUpdDttm) throws PrSymphonyAppsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, SYM_APP_NAME, SYM_PROF_NAME, SYM_IT_LEAD, SYM_PROJ_DISPO, SYM_DOMAIN, SYM_TIER, SYM_APP_STATE, SYM_FRMWRK, SYM_DWN_IMP, SYM_AVG_TX_DAY, SYM_RPO, SYM_RTO, SYM_ACCESS_TYP, SYM_PLATFORM, SYM_ARCH_DSGN, SYM_BACKLOG_METH, SYM_BUS_FUNC, SYM_EXT_USR, SYM_INT_USR, SYM_REGL_LEGAL_FLG, SYM_LAST_UPD_DTTM FROM " + getTableName() + " WHERE SYM_LAST_UPD_DTTM = ? ORDER BY SYM_LAST_UPD_DTTM", this,symLastUpdDttm);
		}
		catch (Exception e) {
			throw new PrSymphonyAppsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_SYMPHONY_APPS table that matches the specified primary-key value.
	 */
	public PrSymphonyApps findByPrimaryKey(PrSymphonyAppsPk pk) throws PrSymphonyAppsDaoException
	{
		return findByPrimaryKey( pk.getSymEaiId() );
	}

}
