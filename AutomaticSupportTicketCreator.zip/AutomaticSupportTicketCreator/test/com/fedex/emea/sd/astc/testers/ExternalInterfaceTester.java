package com.fedex.emea.sd.astc.testers;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.dao.ExternalInterfaceDao;
import com.fedex.emea.sd.da.objects.ExternalInterface;

@SuppressWarnings("unused")
public class ExternalInterfaceTester {
	
	static ExternalInterfaceDao externalInterfaceDao;
	
	public static void main(String[] args) {
		
		ExternalInterfaceTester myTester = new ExternalInterfaceTester();
		
		ClassPathResource classPathResource = new ClassPathResource("spring-config.xml");
		XmlBeanFactory beanFactory = new XmlBeanFactory(classPathResource);
		externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceTestDao");
		
		try {
			myTester.testInsertExternalInterface();
//			myTester.testGetExternalInterface();
		} catch (Exception ex) {
			System.out.println("Error occured...:");
			ex.printStackTrace();
		}
		System.out.println("Done!");
	}
	
	private void testInsertExternalInterface() throws SQLException, DataAccessException, IOException {
		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordForOVO());
//		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordToAddNoteForOVO("INC3899854", "cd853745db22b600a548f7871d9619a0"));
		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordForDashboard());
		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordForOVO());
		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordForOVO());
		externalInterfaceDao.create(TestObjects.getExternalInterfaceRecordForDashboard());
	}
	
	private void testGetExternalInterface() throws SQLException {
		
		System.out.println("List Not Processed Alerts:");
		
		List<ExternalInterface> externalInterfaceList = externalInterfaceDao.loadNotProcessed();
		
		for (Iterator<?> iter = externalInterfaceList.iterator(); iter.hasNext();) {
			ExternalInterface element = (ExternalInterface) iter.next();
			System.out.println(element.getAlertId() + " - " + element.getCaseSummary());
		}		
		System.out.println("---------------------------------------------------------");
	}
	
}
