package com.fedex.emea.dimm.adaptor.jms.itih;

import java.util.Map;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;
import com.fedex.emea.dimm.utils.DIMMConstants;

public class ITIHJMSAlertDomainAdaptorConfig extends AbstractAlertDomainAdaptorConfig{

	private String dashboardName;
	
	public ITIHJMSAlertDomainAdaptorConfig() throws Exception {
		super();
	}

	@Override
	protected void loadAdatorSpecificConfigFromProperties(Map<String, String> propertyMap) {
		
		this.dashboardName = propertyMap.get(DIMMConstants.ITIH_RECORDSOURCE);
	}

	@Override
	protected String getPropertyFileName() {
		return "ITIHJMSAlertDomainAdaptorConfig.properties";
	}

	public String getDashboardName() {
		return dashboardName;
	}

	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}
		
}