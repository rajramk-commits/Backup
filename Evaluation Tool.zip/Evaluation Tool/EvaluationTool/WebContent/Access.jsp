<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
	pageEncoding="ISO-8859-1"%>

<%@page import="com.fedex.emea.onlinequiz.objects.Role"%>
<%@page import="java.util.ArrayList"%>
<jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao"
	scope="page" />

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%
	String useridddd = (String) session.getAttribute("Userid");

	if (session.getAttribute("sessionName") == null) {
		response.sendRedirect("Login.jsp");
	}
	if (session.getAttribute("Sessionid").equals("User")) {
		response.sendRedirect("LoginMenu.jsp");
	} else {
		String userID = (String) session.getAttribute("sessionName");
%>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
<script>
	function openLoginMenu() {
		window.close("Access.jsp");
		window.open("Admin.jsp");
	}
	function accessvalidation() {
		if (document.getElementById("useridd").value == null
				|| document.getElementById("useridd").value == "") {
			document.getElementById("idblank").innerHTML = "Please Enter userid";
			return false;
		}
	}
</script>
<style>
.main {
	margin-left: 10%;
	margin-right: 12%;
}

.head {
	height: 50px;
	background-color: #7030a0;
	margin: 0;
}

.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

.logout {
	float: right;
	margin-right: 5%;
	background-color: #FF8C00;
	color: white;
	padding: 14px 20px;
	border: none;
	cursor: pointer;
}

.logout:hover {
	background-color: #4B0060;
}

input[type=text] {
	width: 250px;
	height: 50px;
	padding: 12px 20px;
	box-sizing: border-box;
	border: 2px solid #ccc;
	border-radius: 4px;
	background-color: #f8f8f8;
}

.heading {
	font-family: Calibri;
	font-size: 18px;
}

td, tr, th {
	font-family: Calibri;
	font-size: 16px;
}

select {
	width: 250px;
	height: 50px;
	padding: 12px 20px;
	box-sizing: border-box;
	border: 2px solid #ccc;
	border-radius: 4px;
	background-color: #f8f8f8;
	color: black;
}

option {
	font-family: Calibri;
	font-size: 16px;
	color: black
}

.addsubmit {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 100;
}

.addsubmit:hover {
	background-color: #7030a0;
}

.removee {
	background-color: #666666;
	color: white;
	padding: 4px 6px;
	margin: 5px 0;
	border: none;
	cursor: pointer;
	width: 50;
}

.removee:hover {
	background-color: #d4d6d6;
	color: black;
}

.utable {
	border: 1px solid #dddddd;
	border-collapse: collapse;
	width: 450px
}

.utable tr {
	border: 1px solid #dddddd;
	text-align: center;
}

.utable td {
	border: 1px solid #dddddd;
	text-align: center;
}

.utable th {
	border: 1px solid #dddddd;
	background-color: #dddddd;
	text-align: center;
	padding: 15px;
}
</style>
</head>
<body>



	<%
		ArrayList<Role> AccessList;

			AccessList = DAO.getAllAccess();

			Role user_role;
	%>
	<div class="main">
		<div class="head">
			<center>
				<p
					style="font-family: Calibri; font-weight: 700; color: white; font-size: 20px; padding: 12px 0 0 0">FedEx
					Support - Evaluation</p>
			</center>
		</div>

		<form action=" ${pageContext.request.contextPath}/Logout"
			method="post">
			<button value="Logout" type="submit" class="logout"
				style="margin-top: 6px; font-family: Calibri; font-size: 16px">Logout</button>
		</form>
		<div
			style="margin: 15px 0 0px 40px; font-family: Calibri; font-size: 16px">
			<b>Welcome :</b>
			<%=userID%>
		</div>
		<button class="home" onclick="openLoginMenu()">HOME</button>
		<br>
		<br> <label class="heading">ADD NEW USER</label><BR>
		<BR>

		<form action="Controller.jsp" method="post"
			onsubmit="return accessvalidation()">
			<table>
				<tr>
					<td>USER ID<br> <input type="text" id="useridd"
						name="userid"> <input type="hidden" id="givenby"
						name="givenby" value=<%=useridddd%>>
					</td>
					<td><div id="idblank"
							style="color: red; font-family: Calibri;"></div></td>
				</tr>

				<tr>
					<td><BR>USER ROLE<br> <select name="role">
							<option value="user">Test</option>
							<option value="admin">Admin</option>
					</select></td>
				</tr>
			</table>
			<BR> <input class="addsubmit" type="submit" value="SUBMIT">
			<input type="hidden" name="page" value="addAccess">
		</form>
		<div style="color: red; font-family: Calibri;">${accessMessage}</div>
		<BR>
		<BR> <label class="heading">ACCESS INFO</label><BR>
		<BR>

		<div style="color: red; font-family: Calibri;">${removeMessage}</div>
		<form action="Controller.jsp" method="post">
			<table class="utable">
				<tr>
					<th>USER ID</th>
					<th>USER ROLE</th>
					<th>GIVEN BY</th>
					<th>ACTION</th>
				</tr>

				<%
					for (int i = 0; i < AccessList.size(); i++) {
							user_role = AccessList.get(i);
				%>

				<tr>
					<td><label><%=user_role.getUserid()%><br>
						<br></label></td>
					<td><label><%=user_role.getUserrole()%><br>
						<br></label></td>
					<td><label><%=user_role.getGivenby()%><br>
						<br></label></td>
					<%
						if (!useridddd.equals(user_role.getUserid())) {
					%>
					<td><button class="removee" type="submit" name="userid"
							value=<%=user_role.getUserid()%>>Remove</button></td>
					<%
						} else {
					%>
					<td></td>
					<%
						}
					%>
				</tr>

				<%
					}
				%>
			</table>
			<input type="hidden" name="userid" value="${user_role.getUserid()}">

			<input type="hidden" name="page" value="removeAccess">
		</form>
		<br> <img style="width: 100%; border: 0" alt="FedExSD"
			src="image/menu1.PNG">
	</div>
	<div
		style="margin: 1% 0% 0% 129px; font-size: 13px; color: #9daca1; font-family: Calibri">
		This application is protected by copyright and trade mark laws under
		U.S. and International law. All rights reserved.&nbsp;� 2019 FedEx
		Express EMEA</div>

</body>
</html>
<%}%>
