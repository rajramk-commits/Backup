package com.fedex.emea.onlinequiz.objects;


public class Question {
    
    private int questionId;
	private String question,opt1,opt2,opt3,opt4,correct,TestName,userans,teamName,questiontype;
	private String question1;

   

    public Question(int questionId, String question, String opt1, String opt2, String opt3, String opt4, String correct) {
        
    	
        this.question = question;
        this.opt1 = opt1;
        this.opt2 = opt2;
        this.opt3 = opt3;
        this.opt4 = opt4;
        this.correct = correct;
        this.questionId = questionId;
    }



	public Question(String question, String opt1, String opt2, String opt3, String opt4,String correct) {
		// TODO Auto-generated constructor stub
		this.question = question;
        this.opt1 = opt1;
        this.opt2 = opt2;
        this.opt3 = opt3;
        this.opt4 = opt4;
        this.correct = correct;       
	}


   public Question(String question, String userans) {
	   this.question = question;
	   this.userans = userans;
   }
   
   
   
	public Question(String teamname, int questionId, String question, String questiontype, String opt1, String opt2, String opt3,
		String opt4, String correct) {
	// TODO Auto-generated constructor stub
		 this.question = teamname;
		 this.question = question;
	        this.opt1 = opt1;
	        this.opt2 = opt2;
	        this.opt3 = opt3;
	        this.opt4 = opt4;
	        this.correct = correct;
	        this.questionId = questionId;
}

	public String getUserans() {
	return userans;
}



//public void setUserans(String userans) {
//	this.userans = userans;
//}



	public int getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Integer questionId) {
        this.questionId = questionId;
    }

    public String getQuestion() {
        return question;
    }

    public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	
	public String getQuestiontype() {
		return questiontype;
	}



	public void setQuestiontype(String questiontype) {
		this.questiontype = questiontype;
	}



	public void setQuestion(String question) {
        this.question = question;
    }

    public String getOpt1() {
        return opt1;
    }

    public void setOpt1(String opt1) {
        this.opt1 = opt1;
    }

    public String getOpt2() {
        return opt2;
    }

    public void setOpt2(String opt2) {
        this.opt2 = opt2;
    }

    public String getOpt3() {
        return opt3;
    }

    public void setOpt3(String opt3) {
        this.opt3 = opt3;
    }

    public String getOpt4() {
        return opt4;
    }

    public void setOpt4(String opt4) {
        this.opt4 = opt4;
    }

    public String getCorrect() {
        return correct;
    }

    public void setCorrect(String correct) {
        this.correct = correct;
    }

    public String getCourseName() {
        return TestName;
    }

    public void setCourseName(String TestName) {
        this.TestName = TestName;
    }

	public String getQuestion1() {
		return question1;
	}

	public void setQuestion1(String question1) {
		this.question1 = question1;
	}
    
    
}
