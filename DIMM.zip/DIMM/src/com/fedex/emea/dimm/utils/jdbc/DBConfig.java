package com.fedex.emea.dimm.utils.jdbc;

public class DBConfig {
	
	private String jdbcURL;//the jdbc URL of the database
	private String userName;//the username for login
	private String password;//the password for login
	
	
	public String getJdbcURL() {
		return jdbcURL;
	}
	public String getPassword() {
		return password;
	}
	public String getUserName() {
		return userName;
	}
	
	public DBConfig(String jdbcURL, String userName, String password) {
		super();
		this.jdbcURL = jdbcURL;
		this.userName = userName;
		this.password = password;
	}

}
