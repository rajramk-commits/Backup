package com.fedex.emea.dimm.log;

public class LogFactory {
	private static LoggingInterface logger;
	
	public static void initialize(LoggingInterface myLogger){
		if(myLogger != null){
			logger = myLogger;
		}else{
			logger = new DefaultLogger();
		}
	}
	
	public static LoggingInterface getLogger() {
		if(logger == null){
			System.out.println("Logger not initialized. Using default logger.");
			logger = new DefaultLogger();
		}
		return logger;
	}

}
