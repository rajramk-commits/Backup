package com.fedex.emea.sd.da.dao;

import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrSpocsDaoException;
import com.fedex.emea.sd.da.objects.PrSpocs;
import com.fedex.emea.sd.da.objects.PrSpocsPk;

public interface PrSpocsDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSpocsPk
	 */
	public PrSpocsPk insert(PrSpocs dto);

	/** 
	 * Updates a single row in the PR_SPOCS table.
	 */
	public void update(PrSpocsPk pk, PrSpocs dto) throws PrSpocsDaoException;

	/** 
	 * Deletes a single row in the PR_SPOCS table.
	 */
	public void delete(PrSpocsPk pk) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_PIN = :mdPin AND MGR_PIN = :mgrPin'.
	 */
	public PrSpocs findByPrimaryKey(String mdPin, String mgrPin) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria ''.
	 */
	public List<PrSpocs> findAll() throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_PIN = :mdPin'.
	 */
	public List<PrSpocs> findWhereMdPinEquals(String mdPin) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_NAME = :mdName'.
	 */
	public List<PrSpocs> findWhereMdNameEquals(String mdName) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MGR_PIN = :mgrPin'.
	 */
	public List<PrSpocs> findWhereMgrPinEquals(String mgrPin) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MGR_NAME = :mgrName'.
	 */
	public List<PrSpocs> findWhereMgrNameEquals(String mgrName) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'SPOC_PIN = :spocPin'.
	 */
	public List<PrSpocs> findWhereSpocPinEquals(String spocPin) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'SPOC_NAME = :spocName'.
	 */
	public List<PrSpocs> findWhereSpocNameEquals(String spocName) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'AUDIT_STATUS = :auditStatus'.
	 */
	public List<PrSpocs> findWhereAuditStatusEquals(String auditStatus) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MITIG_READY = :mitigReady'.
	 */
	public List<PrSpocs> findWhereMitigReadyEquals(String mitigReady) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MITIG_STATUS = :mitigStatus'.
	 */
	public List<PrSpocs> findWhereMitigStatusEquals(String mitigStatus) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'CORRACT_READY = :corractReady'.
	 */
	public List<PrSpocs> findWhereCorractReadyEquals(String corractReady) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'CORRACT_STATUS = :corractStatus'.
	 */
	public List<PrSpocs> findWhereCorractStatusEquals(String corractStatus) throws PrSpocsDaoException;

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'VALTEST_STATUS = :valtestStatus'.
	 */
	public List<PrSpocs> findWhereValtestStatusEquals(String valtestStatus) throws PrSpocsDaoException;

	/** 
	 * Returns the rows from the PR_SPOCS table that matches the specified primary-key value.
	 */
	public PrSpocs findByPrimaryKey(PrSpocsPk pk) throws PrSpocsDaoException;
	
	public List<PrSpocs> findWhereOrgEquals(String org) throws PrSpocsDaoException;

}
