package com.fedex.emea.onlinequiz.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.fedex.emea.onlinequiz.objects.Question;
import com.fedex.emea.onlinequiz.objects.QuestionCCC;

import com.fedex.emea.onlinequiz.objects.Role;


public class QuizDao {

	private Connection conn;
	
	private String getAbbreviatedName(String shortName)
	{
		switch(shortName.toLowerCase())
		{
		case "ccc" 		:	return "ClearanceCC";
		case "hscc" 	:	return "HubstackCC";
		case "appsupp" 	:	return "Application Support";
		case "offsupp" 	:	return "Office Support";
		case "vosupp" 	:	return "Voice Support";
		default			:	return shortName;
		}
	}
	
	private String getShortName(String abbrvtName)
	{
		switch(abbrvtName.toLowerCase())
		{
		case "clearancecc" 			:	return "ccc";
		case "hubstackcc" 			:	return "hscc";
		case "application support" 	:	return "AppSupp";
		case "office support" 		:	return "OffSupp";
		case "voice support" 		:	return "VoSupp";
		default						:	return abbrvtName;
		}
	}
	
	
		public QuizDao() throws ClassNotFoundException, SQLException {
	        establishConnection();
	    }
	    
	    private void establishConnection()  {
	       
	    	
	    	try {
				Class.forName("oracle.jdbc.driver.OracleDriver");	
				//Test
				conn= DriverManager.getConnection(
						"jdbc:oracle:thin:@(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = tcbe007-scan.emea.fedex.com)(PORT = 1526)))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = TC007_COMB_ASTC_LX_SVC1.emea.fedex.com)(FAILOVER_MODE =(TYPE = select)(METHOD = basic)(RETRIES = 1)(DELAY = 5))))",
						"SDTOOL_APP", "YA5jmElhIQE5oyNWJ03BSIKsP");
				//production
				//conn= DriverManager.getConnection("jdbc:oracle:thin:@pcbe002-scan.emea.fedex.com:1526/D002A_ASTC_PRD_SVC1.emea.fedex.com","SDTOOL_APP","Too1sd");
			}catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		    catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    
	    }
	    
	    
	    
	    
	    
	    //fetching questions for Prog1
	    public ArrayList<Question> getQuestions(){
	        ArrayList<Question> list=new ArrayList<Question>();
	        try {	            
	          
	            String sql="SELECT * FROM (SELECT * FROM EVAL_QUESTIONS ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum < 51";
	           
	            PreparedStatement pstm=conn.prepareStatement(sql);
	            
	            ResultSet rs=pstm.executeQuery();
	            
	            Question question;
	            while(rs.next()){
	               question = new Question(rs.getInt(1),rs.getString(2),rs.getString(4),
	                       rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
	                  
	               list.add(question);
	            }
	            pstm.close();
	        } catch (SQLException ex) {
	           System.out.println(ex);
	        }
	        System.out.println(list.size());
	        
	        return list;
	    }
	    
	    //fetching question for Prog2CCC
	    public ArrayList<QuestionCCC> getQuestionsCCC(String teamName){
	        ArrayList<QuestionCCC> list=new ArrayList<QuestionCCC>();
	        try {	            
	          
	            String sqlmcq="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 5 and QUESTION_TYP = 'mcq'";
	            String sql1="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 4 and QUESTION_TYP = '1m' ";
	            String sql2="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 4 and QUESTION_TYP = '2m' ";
	            String sql3="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 3 and QUESTION_TYP = '3m' ";
	            String sql4="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 3 and QUESTION_TYP = '4m' ";
	            String sql5="SELECT * FROM (SELECT * FROM EVAL_TEAM_QUESTIONS WHERE TEAM_NM = '"+teamName+"' ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum <= 4 and QUESTION_TYP = '5m' ";
	           
	            list.addAll(executeRes(sqlmcq));
	            System.out.println("sqlmcq :"+list.size());
	            list.addAll(executeRes(sql1));
	            System.out.println("sql1 :"+list.size());
	            list.addAll(executeRes(sql2));
	            System.out.println("sql2 :"+list.size());
	            list.addAll(executeRes(sql3));
	            System.out.println("sql3 :"+list.size());
	            list.addAll(executeRes(sql4));
	            System.out.println("sql4 :"+list.size());
	            list.addAll(executeRes(sql5));
	            System.out.println("sql5 :"+list.size());
	            
	        } catch (SQLException ex) {
	           System.out.println(ex);
	           ex.printStackTrace();
	        }	        
	        return list;
	    }
	    
	    public ArrayList<QuestionCCC> executeRes(String sql) throws SQLException
	    {
	    	 ArrayList<QuestionCCC> list=new ArrayList<QuestionCCC>();
	    	PreparedStatement pstm=conn.prepareStatement(sql);
            
            ResultSet rs=pstm.executeQuery();
            
            QuestionCCC questionCCC;
            while(rs.next()){
            	questionCCC = new QuestionCCC(rs.getString(1),rs.getInt(2),rs.getString(3),rs.getString(4),
                       rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
                  
               list.add(questionCCC);
            }
            pstm.close();
            return list;
	    }
//	    
//	    //fetching question for Prog2HSCC
//	    public ArrayList<QuestionHSCC> getQuestionsHSCC(){
//	        ArrayList<QuestionHSCC> list=new ArrayList<QuestionHSCC>();
//	        try {	            
//	          
//	            String sql="SELECT * FROM (SELECT * FROM EVAL_QUESTIONS ORDER BY DBMS_RANDOM.VALUE) WHERE  rownum < 51";
//	           
//	            PreparedStatement pstm=conn.prepareStatement(sql);
//	            
//	            ResultSet rs=pstm.executeQuery();
//	            
//	            Question questionCCC;
//	            while(rs.next()){
//	               question = new QuestionHSCC(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),
//	                       rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
//	                  
//	               list.add(questionHSCC);
//	            }
//	            pstm.close();
//	        } catch (SQLException ex) {
//	           System.out.println(ex);
//	        }
//	        System.out.println(list.size());
//	        
//	        return list;
//	    }
//	    
	    //getting answer
	    public String getAnswerbyqid(int qid){
	    	String Answer = null;
	    	try{
    		String sql ="Select Answer from EVAL_QUESTIONS where Question_ID = ?";
    		PreparedStatement pstm=conn.prepareStatement(sql);
    		pstm.setInt(1,qid);
    		ResultSet rs=pstm.executeQuery();
    		while(rs.next())
    		{
    			Answer = rs.getString(1);
    			
    		}
    		pstm.close();
	    		
	    	}catch (SQLException ex) {
		           System.out.println(ex);
		           
		        }
			return Answer;
	    	
	    }
	    
	    //getting answer for CCC
	    public String getAnswerbycccqid(int qid){
	    	String Answer = null;
	    	try{
    		String sql ="Select ANSWER_TXT from EVAL_TEAM_QUESTIONS where Question_ID = ?";
    		PreparedStatement pstm=conn.prepareStatement(sql);
    		pstm.setInt(1,qid);
    		ResultSet rs=pstm.executeQuery();
    		while(rs.next())
    		{
    			Answer = rs.getString(1);
    			
    		}
    		pstm.close();
	    		
	    	}catch (SQLException ex) {
		           System.out.println(ex);
		           
		        }
			return Answer;
	    	
	    }
	    
	    
	    
	    // inserting question for p1
	    public void insertQues(String Question,String OptionA,String OptionB, String OptionC,String OptionD,String CorrectAns){
	    	
	    	try{
	    		String sql ="Insert into EVAL_QUESTIONS(QUESTION_ID,QUESTION,OPTION_A,OPTION_B,OPTION_C,OPTION_D,ANSWER) Values (QUESTION_ID_SQ.nextval,?,?,?,?,?,?)";
	    		PreparedStatement pstm=conn.prepareStatement(sql);
	    		pstm.setString(1,Question);
	    		pstm.setString(2,OptionA);
	    		pstm.setString(3,OptionB);
	    		pstm.setString(4,OptionC);
	    		pstm.setString(5,OptionD);
	    		pstm.setString(6,CorrectAns);
	    		pstm.executeUpdate();
	    		pstm.close();
	    	}
	    	
	    	catch(SQLException ex){
	    		System.out.println(ex);
	    	}
	    	
	    }
	    
	    
	    //inserting question for p2
	    public void insertQuesP2(String teamName,String Question,String questionType,String OptionA,String OptionB, String OptionC,String OptionD,String CorrectAns){
	    	
	    	try{
	    		String sql ="Insert into EVAL_TEAM_QUESTIONS(TEAM_NM,QUESTION_ID,QUESTION_TXT,QUESTION_TYP,OPTION_A,OPTION_B,OPTION_C,OPTION_D,ANSWER_TXT) Values (?,QUESTION_ID_SQ.nextval,?,?,?,?,?,?,?)";
	    		PreparedStatement pstm=conn.prepareStatement(sql);
	    		pstm.setString(1,teamName);
	    		pstm.setString(2,Question);
	    		pstm.setString(3,questionType);
	    		pstm.setString(4,OptionA);
	    		pstm.setString(5,OptionB);
	    		pstm.setString(6,OptionC);
	    		pstm.setString(7,OptionD);
	    		pstm.setString(8,CorrectAns);
	    		int status = pstm.executeUpdate();
	    		System.out.println("status"+status);
	    		pstm.close();
	    	}
	    	
	    	catch(SQLException ex){
	    		System.out.println(ex);
	    	}
	    	
	    }

	
	    
	    //user, access related coding
		public String getUserRole(String string) {
			// TODO Auto-generated method stub
			String user_role= null;
			try{
	    		String sql ="select USER_ROLE from EVAL_ROLES where USER_ID= ?";
	    		PreparedStatement pstm=conn.prepareStatement(sql);
	    		pstm.setString(1,string);
	    		System.out.println(string);
	    		
	    		ResultSet rs=pstm.executeQuery();
	    		
	    		while(rs.next())
	    		{
	    			user_role = rs.getString(1);
	    			System.out.println(user_role);
	    		}
	    		pstm.close();
	    	}
	    	
	    	catch(SQLException ex){
	    		System.out.println(ex);
	    	}
			return user_role;
		}
	    
		public ArrayList<Role> getAllAccess(){
			ArrayList<Role> rolelist = new ArrayList<Role>();
			try{
				String sql = "select * from EVAL_ROLES";
				PreparedStatement pstm=conn.prepareStatement(sql);
				ResultSet rs=pstm.executeQuery();
				Role r;
				while(rs.next()){
					r = new Role(rs.getString(1),rs.getString(2),rs.getString(3));
					rolelist.add(r);
				}
				pstm.close();
			}catch(SQLException ex){
				System.out.println(ex);
			}
			return rolelist;
			
		}

		
	public void addUserRole(String userid,String role,String givenby){
		
		String t = getUserRole(userid);
		if(t!=null){
			try{
			String sql = "update EVAL_ROLES Set User_Role = ? ,Given_by=? where USER_ID = ?";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,role);
			pstm.setString(2,givenby);
			pstm.setString(3,userid);
			pstm.executeQuery();
			pstm.close();
			}    	
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		}
		else{
		try{
			String sql = "insert into EVAL_ROLES values(?,?,?)";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,userid);
			pstm.setString(2,role);
			pstm.setString(3,givenby);
			pstm.executeQuery();
			pstm.close();
    	}
    	
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		}
	}
	
	public void deleteUser(String userid){
		try{
			String sql = "Delete EVAL_ROLES where User_ID = ? ";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,userid);
			pstm.executeQuery();
			pstm.close();
    	}
    	
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
	}
	
	 //fetching questions for Prog1 for View and Delete
    public ArrayList<Question> viewQuestions(){
        ArrayList<Question> list=new ArrayList<Question>();
        try {	            
          
            String sql="SELECT * FROM EVAL_QUESTIONS ORDER BY Question_id";
           
            PreparedStatement pstm=conn.prepareStatement(sql);
            
            ResultSet rs=pstm.executeQuery();
            
            Question question;
            while(rs.next()){
               question = new Question(rs.getInt(1),rs.getString(2),rs.getString(4),
                       rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
                  
               list.add(question);
            }
            pstm.close();
        } catch (SQLException ex) {
           System.out.println(ex);
        }
        System.out.println(list.size());
        return list;
    }
    
    public String deleteQnID(String qnID){
    	int res = 0;
		try{
			String sql = "Delete EVAL_QUESTIONS where QUESTION_ID = ? ";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,qnID);
			res = pstm.executeUpdate();
			pstm.close();
    	}
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		if(res > 0)
			return "Selected record deleted Successfully";
		else
			return "Failed to Delete selected record";
	}
    
    public String deleteQnIDP2(String qnID){
    	int res = 0;
		try{
			String sql = "Delete EVAL_TEAM_QUESTIONS where QUESTION_ID = ? ";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,qnID);
			res = pstm.executeUpdate();
			pstm.close();
    	}
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		if(res > 0)
			return "Selected record deleted Successfully";
		else
			return "Failed to Delete selected record";
	}
    
    public String updateQnID(String qn, String optA, String optB, String optC, String optD, String ans, String qnID){
    	int res = 0;
		try{
			String sql = "update EVAL_QUESTIONS "
						+ "set QUESTION= ? , "
						+ "OPTION_A=? , "
						+ "OPTION_B=? , "
						+ "OPTION_C=? , "
						+ "OPTION_D=? , "
						+ "ANSWER=?  "
						+ "where QUESTION_ID=? ";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1,qn);
			pstm.setString(2,optA);
			pstm.setString(3,optB);
			pstm.setString(4,optC);
			pstm.setString(5,optD);
			pstm.setString(6,ans);
			pstm.setString(7,qnID);
			res = pstm.executeUpdate();
			pstm.close();
    	}
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		if(res > 0)
			return "Selected record Updated Successfully";
		else
			return "Failed to Update selected record";
	}

    public String updateQnIDP2(String team, String qnType, String qn, String optA, String optB, String optC, String optD, String ans, String qnID){
    	int res = 0;
		try{
			String sql = "update EVAL_TEAM_QUESTIONS "
						+ "set TEAM_NM= ? , "
						+ "QUESTION_TYP=? , "
						+ "QUESTION_TXT= ? , "
						+ "OPTION_A=? , "
						+ "OPTION_B=? , "
						+ "OPTION_C=? , "
						+ "OPTION_D=? , "
						+ "ANSWER_TXT=?  "
						+ "where QUESTION_ID=? ";
			PreparedStatement pstm=conn.prepareStatement(sql);
			pstm.setString(1, getShortName(team)); // -Change-
			pstm.setString(2,qnType);
			pstm.setString(3,qn);
			pstm.setString(4,optA);
			pstm.setString(5,optB);
			pstm.setString(6,optC);
			pstm.setString(7,optD);
			pstm.setString(8,ans);
			pstm.setString(9,qnID);
			res = pstm.executeUpdate();
			pstm.close();
    	}
    	catch(SQLException ex){
    		System.out.println(ex);
    	}
		if(res > 0)
			return "Selected record Updated Successfully";
		else
			return "Failed to Update selected record";
	}
    
	 //fetching questions for Prog2 for View and Delete
   public ArrayList<QuestionCCC> viewQuestionsP2(){
       ArrayList<QuestionCCC> list=new ArrayList<QuestionCCC>();
       try {
           String sql="SELECT * FROM EVAL_TEAM_QUESTIONS ORDER BY Question_id";
           PreparedStatement pstm=conn.prepareStatement(sql);
           ResultSet rs=pstm.executeQuery();
           QuestionCCC question;
           while(rs.next()){ // -Change-
              question = new QuestionCCC( getAbbreviatedName(rs.getString(1)),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),
                      rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
              list.add(question);
           }
           pstm.close();
       } catch (SQLException ex) {
          System.out.println(ex);
       }
       System.out.println(list.size());
       return list;
   }
}