<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
    <%@page import="java.util.*"%> 
    <%@page import="com.fedex.emea.sabreReport.model.*"%>
  <jsp:useBean id="ReportDataService" class="com.fedex.emea.sabreReport.service.ReportDataService" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
String startDate = request.getParameter("startDate");
String endDate = request.getParameter("endDate");
System.out.println("startDate1 :"+startDate);
System.out.println("endDate 1:"+endDate);
List<SabreBean> sabreList  = ReportDataService.generateReport(startDate, endDate);
System.out.println("Result Data1:"+sabreList);
request.getSession().setAttribute("sabreList", sabreList);
response.sendRedirect("SabreHomePage.jsp");
%>
</body>
</html>