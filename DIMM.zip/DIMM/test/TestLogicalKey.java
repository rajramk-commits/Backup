
public class TestLogicalKey {

	public static void main(String[] args)
	{
		System.out.println("Logical KEy :"+"" + ("mipemb65.prod.fedex.com:55210"+":"+"ABOVE_CRITICAL_LEVEL"+":"+"JMS_QUEUE"+":"+"FXSHIP.FX.ESE.ITIH-AUTOPUX").hashCode());
	}
}
