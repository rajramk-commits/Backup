package com.fedex.emea.dimm.alert;

public class SnowBean {

	private String caseid;
	private String casesysid;
	public String getCaseid() {
		return caseid;
	}
	public void setCaseid(String caseid) {
		this.caseid = caseid;
	}
	public String getCasesysid() {
		return casesysid;
	}
	public void setCasesysid(String casesysid) {
		this.casesysid = casesysid;
	}
	
	
}
