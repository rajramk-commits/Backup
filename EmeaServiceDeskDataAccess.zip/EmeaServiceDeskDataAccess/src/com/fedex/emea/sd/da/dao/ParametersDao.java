package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.Parameters;

public interface ParametersDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract void create(Parameters valueObject) throws SQLException, DataAccessException, IOException;
	public abstract Parameters createValueObject();
	public abstract void delete(Parameters valueObject);
	public abstract void deleteAll() throws SQLException;
	public abstract Parameters getObject(String parameterEntity, String parameterName) throws SQLException;
	public abstract List<Parameters> loadAll() throws SQLException;
	public abstract List<Parameters> loadByEntity(String parameterEntity) throws SQLException;
	public abstract void save(Parameters valueObject) throws DataAccessException;
}