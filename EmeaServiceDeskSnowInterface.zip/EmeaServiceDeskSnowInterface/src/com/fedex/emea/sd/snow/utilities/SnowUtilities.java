package com.fedex.emea.sd.snow.utilities;

import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowCmdbCiServices;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowIncidentMetrics;
import com.fedex.emea.sd.snow.objects.SnowIncidentSLA;
import com.fedex.emea.sd.snow.objects.SnowIncidentWorkNote;
import com.fedex.emea.sd.snow.objects.SnowProblemMetrics;
import com.fedex.emea.sd.snow.objects.SnowRequestMetrics;
import com.fedex.emea.sd.snow.objects.SnowRequestSLA;
import com.fedex.emea.sd.snow.objects.SnowRequests;
import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.objects.SnowTasks;
import com.fedex.emea.sd.snow.objects.SnowUserGroups;

 public class SnowUtilities {
	/**
	 * Output list of records contained in a specific Table of a given ServiceNow instance (DEV, UAT, SANDBOX, PROD)
	 * 
	 * @param snowRequestor	ServiceNow Requester instance
	 * @param tableName		ServiceNow Table name
	 * @param elementFilter	Search Filter applied on Table   
	 * @param fieldsList	String Array of Field Names to extract. If NULL => All fields
	 * @param exportFolder	Folder to create Export file. If NULL => Output to STDOUT
	 */
	public static void listTable(SnowRequestor snowRequestor, String tableName, List<SnowSearchFilter> filters, String[] fieldsList, String exportFolder) {
		List<HashMap<String, Object>> listFieldsMap = new ArrayList<HashMap<String, Object>>();
		PrintWriter writer = null;
		
		try {
			listFieldsMap = snowRequestor.getTableContent(tableName, getCsvFromArray(fieldsList), filters);
			int resultsCount = listFieldsMap.size();
			
			if (resultsCount > 0) {
				Set<String> headerRowKeys = listFieldsMap.get(0).keySet();
				
				if (fieldsList == null) fieldsList =  headerRowKeys.toArray(new String[headerRowKeys.size()]);
				
				if (exportFolder != null && !exportFolder.trim().isEmpty()) {
					writer = new PrintWriter(exportFolder + "ServiceNow_DataExport_" + tableName.toUpperCase() + ".txt", "UTF-8");
					writer.println(getTableHeader(fieldsList));
				} else {
					System.out.println("***************************************************************");
					System.out.println(tableName.toUpperCase());
					System.out.println("***************************************************************");
					System.out.println(getTableHeader(fieldsList));
				}
				
				for (int i = 0; i < resultsCount; i++) {				
					if (exportFolder != null && !exportFolder.trim().isEmpty()) {
						writer.println(getFieldsFromFieldsMap(listFieldsMap.get(i), fieldsList));
					} else {
						System.out.println(getFieldsFromFieldsMap(listFieldsMap.get(i), fieldsList));
					}
				}
			} else {
				System.out.println("Resultset is EMPTY.");
			}
		} catch (Exception e) {
			System.out.println("ERROR: " + e.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	public static Date toGMT(Date date){
	    TimeZone tz = TimeZone.getDefault();
	    Date ret = new Date(date.getTime() - tz.getRawOffset());

	    // Seems that ServiceNow is not using DayLight saving stuff
	    //
//	    if (tz.inDaylightTime(ret)) {
//	        Date dstDate = new Date(ret.getTime() - tz.getDSTSavings());
//	        if (tz.inDaylightTime(dstDate)) ret = dstDate;
//        }
	    
	    return ret;
	}

	public static Date toLocalTime(Date date){
	    TimeZone tz = TimeZone.getDefault();
	    Date ret = new Date(date.getTime() + tz.getRawOffset());

	    if (tz.inDaylightTime(ret)){
	        Date dstDate = new Date(ret.getTime() + tz.getDSTSavings());
	        if (tz.inDaylightTime(dstDate)) ret = dstDate;
	     }
	     return ret;
	}

	private static String getFieldsFromFieldsMap(HashMap<String, Object> fieldsMap, String[] fieldsList) {
		StringBuilder fieldsLine = new StringBuilder();
		int col = 0;
		for (String fieldName: fieldsList) {
			if (col == 0) {
				fieldsLine.append(fieldsMap.get(fieldName));
			} else {
				fieldsLine.append("|" + fieldsMap.get(fieldName));
			}
			col++;
		}
		return fieldsLine.toString();
	}
	
	private static String getTableHeader(String[] fieldsList) {
		StringBuilder fieldsLine = new StringBuilder();
		
		for (String fieldName: fieldsList) {
			if (fieldsLine.toString().isEmpty()) {
				fieldsLine.append(fieldName);
			} else {
				fieldsLine.append("|" + fieldName);
			}
		}
		return fieldsLine.toString();
	}
	
	private static String getCsvFromArray(String[] fieldsList) {
		StringBuilder fieldsLine = new StringBuilder();
		
		if (fieldsList == null) return null;
		
		for (String fieldName: fieldsList) {
			if (fieldsLine.toString().isEmpty()) {
				fieldsLine.append(fieldName);
			} else {
				fieldsLine.append("," + fieldName);
			}
		}
		return fieldsLine.toString();
	}
	
	/**
	 * Transform an Object into a String.
	 * If Object is JSONObject, returned String is content of "value" field
	 * 
	 * @param obj	Object to return as String
	 * @return		String object. Empty String if Object is NULL.
	 */
	public static String getStringValueFromObject(Object obj) {
		String retVal = "";
		JSONObject tmpJSON = null;
		
		if (obj == null) return "";
		
		if (obj.getClass() == JSONObject.class) {
			tmpJSON = (JSONObject) obj;
			retVal = tmpJSON.getString("value");
		} else {
			retVal = (String) obj;
		}
		
		return retVal;
	}
	
	public static Object nullifyEmptyStringForJSON(Object param) {
		return (param.toString().trim().isEmpty()?null:param);
	}
	
	public static List<SnowIncident> getIncidentsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowIncident> incidents = new ArrayList<SnowIncident>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			incidents.add(new SnowIncident(listFieldsMap.get(i)));
		}
		
		return incidents;
	}
	
	public static List<SnowCmdbCiServices> getCmdbCiServicesFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowCmdbCiServices> objList = new ArrayList<SnowCmdbCiServices>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			objList.add(new SnowCmdbCiServices(listFieldsMap.get(i)));
		}
		
		return objList;
	}
	
	public static List<SnowUserGroups> getUserGroupsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowUserGroups> objList = new ArrayList<SnowUserGroups>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			objList.add(new SnowUserGroups(listFieldsMap.get(i)));
		}
		
		return objList;
	}
	
	public static List<SnowTasks> getTasksFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowTasks> tasks = new ArrayList<SnowTasks>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			tasks.add(new SnowTasks(listFieldsMap.get(i)));
		}
		
		return tasks;
	}
	
	public static List<SnowRequests> getRequestsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowRequests> requests = new ArrayList<SnowRequests>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			requests.add(new SnowRequests(listFieldsMap.get(i)));
		}
		
		return requests;
	}
	
	public static List<SnowIncidentWorkNote> getWorkNotesFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowIncidentWorkNote> workNotes = new ArrayList<SnowIncidentWorkNote>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			workNotes.add(new SnowIncidentWorkNote(listFieldsMap.get(i)));
		}
		
		return workNotes;
	}
	
	public static List<SnowIncidentMetrics> getIncidentMetricsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowIncidentMetrics> incidentMetrics = new ArrayList<SnowIncidentMetrics>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			incidentMetrics.add(new SnowIncidentMetrics(listFieldsMap.get(i)));
		}
		
		return incidentMetrics;
	}
	
	public static List<SnowIncidentSLA> getIncidentSLAFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowIncidentSLA> incidentSLAs = new ArrayList<SnowIncidentSLA>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			incidentSLAs.add(new SnowIncidentSLA(listFieldsMap.get(i)));
		}
		
		return incidentSLAs;
	}
	
	public static List<SnowRequestMetrics> getRequestMetricsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowRequestMetrics> requestMetrics = new ArrayList<SnowRequestMetrics>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			requestMetrics.add(new SnowRequestMetrics(listFieldsMap.get(i)));
		}
		
		return requestMetrics;
	}
	
	public static List<SnowRequestSLA> getRequestSLAFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowRequestSLA> requestSLAs = new ArrayList<SnowRequestSLA>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			requestSLAs.add(new SnowRequestSLA(listFieldsMap.get(i)));
		}
		
		return requestSLAs;
	}
	
	public static List<SnowProblemMetrics> getProblemMetricsFromHashMap(List<HashMap<String, Object>> listFieldsMap) {
		List<SnowProblemMetrics> problemMetrics = new ArrayList<SnowProblemMetrics>();
		int resultsCount = listFieldsMap.size();
		
		for (int i = 0; i < resultsCount; i++) {
			problemMetrics.add(new SnowProblemMetrics(listFieldsMap.get(i)));
		}
		
		return problemMetrics;
	}
	
	public static List<HashMap<String, Object>> parseJSONresponse(JSONObject jsonResponse) throws Exception {
		
		List<HashMap<String, Object>> listFieldsMap = new ArrayList<HashMap<String, Object>>();
		
		if (jsonResponse != null) {
			if (jsonResponse.has("error")) {
				String exceptionMessage = "";
				JSONObject response = jsonResponse.getJSONObject("error");
				if (response.has("code")) exceptionMessage = response.getString("code");
				if (response.has("message")) {
					if (exceptionMessage.isEmpty()) {
						exceptionMessage = response.getString("message");
					} else {
						exceptionMessage = exceptionMessage + " - " + response.getString("message");
					}
				}
				if (response.has("detail")) {
					if (exceptionMessage.isEmpty()) {
						exceptionMessage = response.getString("detail");
					} else {
						exceptionMessage = exceptionMessage + " - " + response.getString("detail");
					}
				}
				throw new Exception(exceptionMessage);
			} else {
				if (jsonResponse.has("result")) {
					if (jsonResponse.get("result").getClass() == JSONObject.class) {
						JSONObject incident = jsonResponse.getJSONObject("result");
						if (incident.has("stats")) {
							JSONObject stats = incident.getJSONObject("stats");
							listFieldsMap.add(getFieldsMapFromJSON(stats));
						} else {
							listFieldsMap.add(getFieldsMapFromJSON(incident));
						}
					} else {
						if (jsonResponse.get("result").getClass() == JSONArray.class) {
							JSONArray incdients = jsonResponse.getJSONArray("result");
							for (int i = 0; i < incdients.length(); i++) {
								JSONObject incident = incdients.getJSONObject(i);
								listFieldsMap.add(getFieldsMapFromJSON(incident));
							}
						}
					}
				}			
			}
		}
		
		return listFieldsMap;
	}
	
	public static JSONObject getJSONfromFieldsMap(HashMap<String, Object> fieldsMap) {
		JSONObject jsonObject = new JSONObject();
		
		for (String str: fieldsMap.keySet()) {
			jsonObject.put(str, fieldsMap.get(str));
		}
		
		return jsonObject;
	}
	
	public static HashMap<String, Object> getFieldsMapFromJSON(JSONObject jsonObject) {
		HashMap<String, Object> fieldsMap = new HashMap<String, Object>();
		Iterator<String> jsonKeys = jsonObject.keys();
		while (jsonKeys.hasNext()) {
			String key = jsonKeys.next();
			fieldsMap.put(key, jsonObject.get(key));
		}
		return fieldsMap;
	}
	
	public static String formatDateForSNOW(Date d1) {
		String dateSNOW = null;
		SimpleDateFormat fmtDateOnly = new SimpleDateFormat("yyyy-MM-dd");
		SimpleDateFormat fmtTimeOnly = new SimpleDateFormat("HH:mm:ss");
		Date dateGMT    = SnowUtilities.toGMT(d1);
		
		dateSNOW = "javascript:gs.dateGenerate('" + fmtDateOnly.format(dateGMT) + "','" + fmtTimeOnly.format(dateGMT) + "')";
		
		return dateSNOW;
	}
	
	public static Date formatToDateFromSNOW(String stringToFormat) {
		Date snowDate;
		Date returnedDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
			snowDate = sdf.parse(stringToFormat);
			if (snowDate != null) returnedDate = SnowUtilities.toLocalTime(snowDate);
		} catch (ParseException e) {
			returnedDate = null;
		}
		return returnedDate;
	}
	
	public static String formatDuration(Date d) {
		SimpleDateFormat fmtTimeOnly = new SimpleDateFormat("HH:mm:ss");
		if (d != null) return fmtTimeOnly.format(d);
		return null;
	}
	
}
