package com.fedex.emea.sabreReport.model;

public final class AuthenticateResult{
    private boolean isAuthenticated;
    private String errorDesc;//if the authentication failed give the reason
    private UserInfo userInfo;//holds user data



    public AuthenticateResult(boolean success){
        this.isAuthenticated = success;
    }
    public AuthenticateResult(boolean fail,String reason){
        this.isAuthenticated = fail;
        this.errorDesc = reason;
    }
    public String getErrorDesc() {
        return errorDesc;
    }
    public boolean isAuthenticated() {
        return isAuthenticated;
    }
    
    public void setUserInfo(UserInfo userInfo){
        this.userInfo = userInfo;
    }
    
    public UserInfo getUserInfo(){
        return this.userInfo;
    }
}