package com.fedex.emea.sd.da.dao.spring;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.ApplicationDao;
import com.fedex.emea.sd.da.exceptions.ApplicationDaoException;
import com.fedex.emea.sd.da.objects.Application;
import com.fedex.emea.sd.da.objects.ApplicationPk;

public class ApplicationDaoImpl extends AbstractDAO implements ParameterizedRowMapper<Application>, ApplicationDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return ApplicationPk
	 */
	@Transactional
	public ApplicationPk insert(Application dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getId(),dto.getName(),dto.getLocationName(),dto.getApplicationRevision(),dto.getApplicationVersion(),dto.getStatus(),dto.getStatusDate(),dto.getManufacturerIssueNumber(),dto.getVendor(),dto.getInstalledIn(),dto.getOwnedByLeasedFrom(),dto.getOwnedOrLeased(),dto.getOwnershipLeaseDate(),dto.isLeasingPaymentNull()?null:dto.getLeasingPayment(),dto.getComments(),dto.getResourceStatus(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getDefiningTypeKeyType(),dto.getDefiningTypeKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getBusinessCriticality(),dto.getSource(),dto.getSourceKey(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.isIsOverlayComponentNull()?null:dto.getIsOverlayComponent());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the APPLICATION table.
	 */
	@Transactional
	public void update(ApplicationPk pk, Application dto) throws ApplicationDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET ID = ?, NAME = ?, LOCATION_NAME = ?, APPLICATION_REVISION = ?, APPLICATION_VERSION = ?, STATUS = ?, STATUS_DATE = ?, MANUFACTURER_ISSUE_NUMBER = ?, VENDOR = ?, INSTALLED_IN = ?, OWNED_BY_LEASED_FROM = ?, OWNED_OR_LEASED = ?, OWNERSHIP_LEASE_DATE = ?, LEASING_PAYMENT = ?, COMMENTS = ?, RESOURCE_STATUS = ?, CUSTOM_1 = ?, CUSTOM_2 = ?, CUSTOM_3 = ?, CUSTOM_4 = ?, CUSTOM_5 = ?, DEFINING_TYPE_KEY_TYPE = ?, DEFINING_TYPE_KEY_PK = ?, DESCRIPTION = ?, LONG_DESCRIPTION = ?, LAST_MODIFICATION_USER_ID = ?, LAST_MODIFICATION_DATE = ?, LASTUPDATEVERSIONNUMBER = ?, CUSTOM_6 = ?, CUSTOM_7 = ?, CUSTOM_8 = ?, CUSTOM_9 = ?, CUSTOM_10 = ?, BUSINESS_CRITICALITY = ?, SOURCE = ?, SOURCE_KEY = ?, OBJECT_DEFAULT_KEY_TYPE = ?, OBJECT_DEFAULT_KEY_PK = ?, ENVIRONMENT = ?, INVENTORY_KEY_TYPE = ?, INVENTORY_KEY_PK = ?, IS_OVERLAY_COMPONENT = ? WHERE ID = ?",dto.getId(),dto.getName(),dto.getLocationName(),dto.getApplicationRevision(),dto.getApplicationVersion(),dto.getStatus(),dto.getStatusDate(),dto.getManufacturerIssueNumber(),dto.getVendor(),dto.getInstalledIn(),dto.getOwnedByLeasedFrom(),dto.getOwnedOrLeased(),dto.getOwnershipLeaseDate(),dto.getLeasingPayment(),dto.getComments(),dto.getResourceStatus(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getDefiningTypeKeyType(),dto.getDefiningTypeKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getBusinessCriticality(),dto.getSource(),dto.getSourceKey(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.getIsOverlayComponent(),pk.getId());
	}

	/** 
	 * Deletes a single row in the APPLICATION table.
	 */
	@Transactional
	public void delete(ApplicationPk pk) throws ApplicationDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE ID = ?",pk.getId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return Application
	 */
	public Application mapRow(ResultSet rs, int row) throws SQLException
	{
		Application dto = new Application();
		dto.setId( rs.getString( 1 ) );
		dto.setName( rs.getString( 2 ) );
		dto.setLocationName( rs.getString( 3 ) );
		dto.setApplicationRevision( rs.getString( 4 ) );
		dto.setApplicationVersion( rs.getString( 5 ) );
		dto.setStatus( rs.getString( 6 ) );
		dto.setStatusDate( rs.getTimestamp(7 ) );
		dto.setManufacturerIssueNumber( rs.getString( 8 ) );
		dto.setVendor( rs.getString( 9 ) );
		dto.setInstalledIn( rs.getString( 10 ) );
		dto.setOwnedByLeasedFrom( rs.getString( 11 ) );
		dto.setOwnedOrLeased( rs.getString( 12 ) );
		dto.setOwnershipLeaseDate( rs.getTimestamp(13 ) );
		dto.setLeasingPayment( rs.getFloat( 14 ) );
		if (rs.wasNull()) {
			dto.setLeasingPaymentNull( true );
		}
		
		dto.setComments( rs.getString( 15 ) );
		dto.setResourceStatus( rs.getString( 16 ) );
		dto.setCustom1( rs.getString( 17 ) );
		dto.setCustom2( rs.getString( 18 ) );
		dto.setCustom3( rs.getString( 19 ) );
		dto.setCustom4( rs.getString( 20 ) );
		dto.setCustom5( rs.getString( 21 ) );
		dto.setDefiningTypeKeyType( rs.getString( 22 ) );
		dto.setDefiningTypeKeyPk( rs.getString( 23 ) );
		dto.setDescription( rs.getString( 24 ) );
		dto.setLongDescription( rs.getString( 25 ) );
		dto.setLastModificationUserId( rs.getString( 26 ) );
		dto.setLastModificationDate( rs.getTimestamp(27 ) );
		dto.setLastupdateversionnumber( rs.getBigDecimal(28));
		dto.setCustom6( rs.getString( 29 ) );
		dto.setCustom7( rs.getString( 30 ) );
		dto.setCustom8( rs.getString( 31 ) );
		dto.setCustom9( rs.getString( 32 ) );
		dto.setCustom10( rs.getString( 33 ) );
		dto.setBusinessCriticality( rs.getString( 34 ) );
		dto.setSource( rs.getString( 35 ) );
		dto.setSourceKey( rs.getString( 36 ) );
		dto.setObjectDefaultKeyType( rs.getString( 37 ) );
		dto.setObjectDefaultKeyPk( rs.getString( 38 ) );
		dto.setEnvironment( rs.getString( 39 ) );
		dto.setInventoryKeyType( rs.getString( 40 ) );
		dto.setInventoryKeyPk( rs.getString( 41 ) );
		dto.setIsOverlayComponent( rs.getInt( 42 ) );
		if (rs.wasNull()) {
			dto.setIsOverlayComponentNull( true );
		}
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "FIT_SCHEMA.APPLICATION";
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public Application findByPrimaryKey(String id) throws ApplicationDaoException
	{
		try {
			List<Application> list = jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ?", this,id);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria ''.
	 */
	@Transactional
	public List<Application> findAll() throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " ORDER BY ID", this);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}
	
	@Transactional
	public List<Application> findInPrScope() throws ApplicationDaoException {
		String selectFields = "ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT";
		String whereClause  = "BUSINESS_CRITICALITY not in ('Undefined', 'Not relevant') " +
			                  "and STATUS = 'In production' " +
	                          "and VENDOR <> 'IT US' and VENDOR <> 'Not Managed by IT' and upper(VENDOR) <> 'N/A' and upper(VENDOR) <> 'OTHER' " +
			                  "and BUSINESS_CRITICALITY not like '4%'";
		String orderFields  = "upper(NAME)";
		
		String sql = "SELECT " + selectFields 
				  + " FROM " + getTableName()
				  + " WHERE " + whereClause 
				  + " ORDER BY " + orderFields;
		
		try {
			return jdbcTemplate.query(sql, this);
		} catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public List<Application> findWhereIdEquals(String id) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ? ORDER BY ID", this,id);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'NAME = :name'.
	 */
	@Transactional
	public List<Application> findWhereNameEquals(String name) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE NAME = ? ORDER BY NAME", this,name);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LOCATION_NAME = :locationName'.
	 */
	@Transactional
	public List<Application> findWhereLocationNameEquals(String locationName) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LOCATION_NAME = ? ORDER BY LOCATION_NAME", this,locationName);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'APPLICATION_REVISION = :applicationRevision'.
	 */
	@Transactional
	public List<Application> findWhereApplicationRevisionEquals(String applicationRevision) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE APPLICATION_REVISION = ? ORDER BY APPLICATION_REVISION", this,applicationRevision);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'APPLICATION_VERSION = :applicationVersion'.
	 */
	@Transactional
	public List<Application> findWhereApplicationVersionEquals(String applicationVersion) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE APPLICATION_VERSION = ? ORDER BY APPLICATION_VERSION", this,applicationVersion);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'STATUS = :status'.
	 */
	@Transactional
	public List<Application> findWhereStatusEquals(String status) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE STATUS = ? ORDER BY STATUS", this,status);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'STATUS_DATE = :statusDate'.
	 */
	@Transactional
	public List<Application> findWhereStatusDateEquals(Date statusDate) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE STATUS_DATE = ? ORDER BY STATUS_DATE", this,statusDate);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'MANUFACTURER_ISSUE_NUMBER = :manufacturerIssueNumber'.
	 */
	@Transactional
	public List<Application> findWhereManufacturerIssueNumberEquals(String manufacturerIssueNumber) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_ISSUE_NUMBER = ? ORDER BY MANUFACTURER_ISSUE_NUMBER", this,manufacturerIssueNumber);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'VENDOR = :vendor'.
	 */
	@Transactional
	public List<Application> findWhereVendorEquals(String vendor) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE VENDOR = ? ORDER BY VENDOR", this,vendor);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INSTALLED_IN = :installedIn'.
	 */
	@Transactional
	public List<Application> findWhereInstalledInEquals(String installedIn) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INSTALLED_IN = ? ORDER BY INSTALLED_IN", this,installedIn);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNED_BY_LEASED_FROM = :ownedByLeasedFrom'.
	 */
	@Transactional
	public List<Application> findWhereOwnedByLeasedFromEquals(String ownedByLeasedFrom) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OWNED_BY_LEASED_FROM = ? ORDER BY OWNED_BY_LEASED_FROM", this,ownedByLeasedFrom);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNED_OR_LEASED = :ownedOrLeased'.
	 */
	@Transactional
	public List<Application> findWhereOwnedOrLeasedEquals(String ownedOrLeased) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OWNED_OR_LEASED = ? ORDER BY OWNED_OR_LEASED", this,ownedOrLeased);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNERSHIP_LEASE_DATE = :ownershipLeaseDate'.
	 */
	@Transactional
	public List<Application> findWhereOwnershipLeaseDateEquals(Date ownershipLeaseDate) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OWNERSHIP_LEASE_DATE = ? ORDER BY OWNERSHIP_LEASE_DATE", this,ownershipLeaseDate);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LEASING_PAYMENT = :leasingPayment'.
	 */
	@Transactional
	public List<Application> findWhereLeasingPaymentEquals(float leasingPayment) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LEASING_PAYMENT = ? ORDER BY LEASING_PAYMENT", this,leasingPayment);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'COMMENTS = :comments'.
	 */
	@Transactional
	public List<Application> findWhereCommentsEquals(String comments) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE COMMENTS = ? ORDER BY COMMENTS", this,comments);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'RESOURCE_STATUS = :resourceStatus'.
	 */
	@Transactional
	public List<Application> findWhereResourceStatusEquals(String resourceStatus) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE RESOURCE_STATUS = ? ORDER BY RESOURCE_STATUS", this,resourceStatus);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	@Transactional
	public List<Application> findWhereCustom1Equals(String custom1) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_1 = ? ORDER BY CUSTOM_1", this,custom1);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	@Transactional
	public List<Application> findWhereCustom2Equals(String custom2) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_2 = ? ORDER BY CUSTOM_2", this,custom2);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	@Transactional
	public List<Application> findWhereCustom3Equals(String custom3) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_3 = ? ORDER BY CUSTOM_3", this,custom3);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	@Transactional
	public List<Application> findWhereCustom4Equals(String custom4) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_4 = ? ORDER BY CUSTOM_4", this,custom4);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	@Transactional
	public List<Application> findWhereCustom5Equals(String custom5) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_5 = ? ORDER BY CUSTOM_5", this,custom5);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DEFINING_TYPE_KEY_TYPE = :definingTypeKeyType'.
	 */
	@Transactional
	public List<Application> findWhereDefiningTypeKeyTypeEquals(String definingTypeKeyType) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DEFINING_TYPE_KEY_TYPE = ? ORDER BY DEFINING_TYPE_KEY_TYPE", this,definingTypeKeyType);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DEFINING_TYPE_KEY_PK = :definingTypeKeyPk'.
	 */
	@Transactional
	public List<Application> findWhereDefiningTypeKeyPkEquals(String definingTypeKeyPk) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DEFINING_TYPE_KEY_PK = ? ORDER BY DEFINING_TYPE_KEY_PK", this,definingTypeKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	@Transactional
	public List<Application> findWhereDescriptionEquals(String description) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DESCRIPTION = ? ORDER BY DESCRIPTION", this,description);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	@Transactional
	public List<Application> findWhereLongDescriptionEquals(String longDescription) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LONG_DESCRIPTION = ? ORDER BY LONG_DESCRIPTION", this,longDescription);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	@Transactional
	public List<Application> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_USER_ID = ? ORDER BY LAST_MODIFICATION_USER_ID", this,lastModificationUserId);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	@Transactional
	public List<Application> findWhereLastModificationDateEquals(Date lastModificationDate) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_DATE = ? ORDER BY LAST_MODIFICATION_DATE", this,lastModificationDate);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	@Transactional
	public List<Application> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LASTUPDATEVERSIONNUMBER = ? ORDER BY LASTUPDATEVERSIONNUMBER", this,lastupdateversionnumber);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	@Transactional
	public List<Application> findWhereCustom6Equals(String custom6) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_6 = ? ORDER BY CUSTOM_6", this,custom6);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	@Transactional
	public List<Application> findWhereCustom7Equals(String custom7) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_7 = ? ORDER BY CUSTOM_7", this,custom7);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	@Transactional
	public List<Application> findWhereCustom8Equals(String custom8) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_8 = ? ORDER BY CUSTOM_8", this,custom8);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	@Transactional
	public List<Application> findWhereCustom9Equals(String custom9) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_9 = ? ORDER BY CUSTOM_9", this,custom9);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	@Transactional
	public List<Application> findWhereCustom10Equals(String custom10) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_10 = ? ORDER BY CUSTOM_10", this,custom10);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'BUSINESS_CRITICALITY = :businessCriticality'.
	 */
	@Transactional
	public List<Application> findWhereBusinessCriticalityEquals(String businessCriticality) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE BUSINESS_CRITICALITY = ? ORDER BY BUSINESS_CRITICALITY", this,businessCriticality);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'SOURCE = :source'.
	 */
	@Transactional
	public List<Application> findWhereSourceEquals(String source) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SOURCE = ? ORDER BY SOURCE", this,source);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'SOURCE_KEY = :sourceKey'.
	 */
	@Transactional
	public List<Application> findWhereSourceKeyEquals(String sourceKey) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SOURCE_KEY = ? ORDER BY SOURCE_KEY", this,sourceKey);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	@Transactional
	public List<Application> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_TYPE = ? ORDER BY OBJECT_DEFAULT_KEY_TYPE", this,objectDefaultKeyType);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	@Transactional
	public List<Application> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_PK = ? ORDER BY OBJECT_DEFAULT_KEY_PK", this,objectDefaultKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	@Transactional
	public List<Application> findWhereEnvironmentEquals(String environment) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ENVIRONMENT = ? ORDER BY ENVIRONMENT", this,environment);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	@Transactional
	public List<Application> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_TYPE = ? ORDER BY INVENTORY_KEY_TYPE", this,inventoryKeyType);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	@Transactional
	public List<Application> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_PK = ? ORDER BY INVENTORY_KEY_PK", this,inventoryKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	@Transactional
	public List<Application> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws ApplicationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, APPLICATION_REVISION, APPLICATION_VERSION, STATUS, STATUS_DATE, MANUFACTURER_ISSUE_NUMBER, VENDOR, INSTALLED_IN, OWNED_BY_LEASED_FROM, OWNED_OR_LEASED, OWNERSHIP_LEASE_DATE, LEASING_PAYMENT, COMMENTS, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, BUSINESS_CRITICALITY, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE IS_OVERLAY_COMPONENT = ? ORDER BY IS_OVERLAY_COMPONENT", this,isOverlayComponent);
		}
		catch (Exception e) {
			throw new ApplicationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the APPLICATION table that matches the specified primary-key value.
	 */
	public Application findByPrimaryKey(ApplicationPk pk) throws ApplicationDaoException
	{
		return findByPrimaryKey( pk.getId() );
	}

}
