package com.fedex.emea.dimm.adaptor.datacenter;

import java.util.Map;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;

public class DataCenterOutageAlertDomainAdaptorConfig extends AbstractAlertDomainAdaptorConfig{

	public DataCenterOutageAlertDomainAdaptorConfig() throws Exception {
		super();
	}

	@Override
	protected void loadAdatorSpecificConfigFromProperties(
			Map<String, String> propertyMap) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String getPropertyFileName() {
		return "DataCenterOutageAlertDomainAdaptorConfig.properties";
	}

}
