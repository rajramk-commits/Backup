package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.sql.Timestamp;

public class ServerAvailabilities implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String    serverName;
	private String    serverDc;
	private boolean   serverAlive;
	private Timestamp lastCheckTime;
	private Timestamp oldStatusTime;
	private Timestamp statusChangeTime;
	private String    serverSoftwareVersion;
	private String    serverStatus;
	private String    serverId;
	
	public ServerAvailabilities() {
	}
	
	public ServerAvailabilities(String serverId, String serverName, String serverDc, boolean serverAlive, Timestamp lastCheckTime, Timestamp oldStatusTime, Timestamp statusChangeTime) {
		this.setServerName(serverName);
		this.setServerDc(serverDc);
		this.setServerAlive(serverAlive);
		this.setLastCheckTime(lastCheckTime);
		this.setOldStatusTime(oldStatusTime);
		this.setStatusChangeTime(statusChangeTime);
		this.setServerId(serverId);
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getServerDc() {
		return serverDc;
	}

	public void setServerDc(String serverDc) {
		this.serverDc = serverDc;
	}

	public boolean isServerAlive() {
		return serverAlive;
	}

	public void setServerAlive(boolean serverAlive) {
		this.serverAlive = serverAlive;
	}

	public Timestamp getLastCheckTime() {
		return lastCheckTime;
	}

	public void setLastCheckTime(Timestamp lastCheckTime) {
		this.lastCheckTime = lastCheckTime;
	}

	public Timestamp getStatusChangeTime() {
		return statusChangeTime;
	}

	public void setStatusChangeTime(Timestamp statusChangeTime) {
		this.statusChangeTime = statusChangeTime;
	}

	public Timestamp getOldStatusTime() {
		return oldStatusTime;
	}

	public void setOldStatusTime(Timestamp oldStatusTime) {
		this.oldStatusTime = oldStatusTime;
	}

	public String getServerSoftwareVersion() {
		return serverSoftwareVersion;
	}

	public void setServerSoftwareVersion(String serverSoftwareVersion) {
		this.serverSoftwareVersion = serverSoftwareVersion;
	}

	public String getServerStatus() {
		return serverStatus;
	}

	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}

	public String getServerId() {
		return serverId;
	}

	public void setServerId(String serverId) {
		this.serverId = serverId;
	}
	
}
