<%@page import="javax.mail.MessagingException"%>
<%@page import="javax.mail.internet.AddressException"%>
<%@page import="javax.mail.Transport"%>
<%@page import="javax.mail.Message"%>
<%@page import="javax.mail.internet.InternetAddress"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.time.LocalTime"%>
<%@page import="java.util.*"%>
<jsp:useBean id="dao" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>


<%@page contentType="text/html" pageEncoding="UTF-8"%>

 <% 
 
 String userID = (String) session.getAttribute("sessionName");
	//out.println("Welcome : "+userID);
 
 if(request.getParameter("page").toString().equals("exams")){
    
        String TestName=request.getParameter("TestName");
        session.setAttribute("Test",TestName);
        session.setAttribute("examStarted","1");
        response.sendRedirect("Program1Exam.jsp");
    
 } if(request.getParameter("page").toString().equals("exam2")){
	 System.out.println("TeamName Param :"+request.getParameter("TeamName"));
	 System.out.println("examStarted :"+session.getAttribute("examStarted"));
	 
     String TestName=request.getParameter("TestName");
     session.setAttribute("Test",TestName);
     session.setAttribute("examStarted","1");
     
     if(request.getParameter("TeamName").equalsIgnoreCase("ClearanceCC"))
     	response.sendRedirect("Program2CCC.jsp");
     else if(request.getParameter("TeamName").equalsIgnoreCase("HubstackCC"))
      	response.sendRedirect("Program2HSCC.jsp");
     else if(request.getParameter("TeamName").equalsIgnoreCase("Application_Support"))
      	response.sendRedirect("Program2AppSupp.jsp");
 
} if(request.getParameter("page").toString().equals("examsHSCC")){
    
    String TestName=request.getParameter("TestName");
    session.setAttribute("Test",TestName);
    session.setAttribute("examStarted","1");
    response.sendRedirect("Program2HSCC.jsp");

}if(request.getParameter("page").toString().equals("examsAppSupp")){
    
    String TestName=request.getParameter("TestName");
    session.setAttribute("Test",TestName);
    session.setAttribute("examStarted","1");
    response.sendRedirect("Program2AppSupp.jsp");

}if(request.getParameter("page").toString().equals("addAccess")){
	 
	 String UserID=request.getParameter("userid");
	 String role=request.getParameter("role");
	 String givenby=request.getParameter("givenby");	
	 
	 dao.addUserRole(UserID, role,givenby);
	 session.removeAttribute("removeMessage");
	 session.setAttribute("accessMessage","User Added Successfully");
	 response.sendRedirect("Access.jsp");
	 
 } if(request.getParameter("page").toString().equals("removeAccess")){
	 String UserID=request.getParameter("userid");
	  	 
	 dao.deleteUser(UserID);
	 session.removeAttribute("accessMessage");
	 session.setAttribute("removeMessage","User Deleted Successfully");
	 response.sendRedirect("Access.jsp");
 }
%>

