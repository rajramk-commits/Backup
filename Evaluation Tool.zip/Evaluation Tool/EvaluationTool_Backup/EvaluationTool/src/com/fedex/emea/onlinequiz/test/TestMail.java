package com.fedex.emea.onlinequiz.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class TestMail {

	public static void main(String[] args) {
		
		//Test Server 
		String filename = "/automationtools/AutomationTools/deployments/test.txt";
		 
		 	String mailTo = "rajarama.kaniyoor.osv@fedex.com";//(String) session.getAttribute("UserMail");	
			String mailcc = "deepak.kumar.osv@fedex.com";//"ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";

		 	Properties props = System.getProperties();
			props.put("mail.smtp.host", "mapper.gslb.fedex.com");
			props.put("mail.smtp.port", "25");
			props.put("mail.smtp.connectiontimeout", 10000);
			props.put("mail.smtp.timeout", 10000);
			props.put("mail.smtp.writetimeout", 10000);
			
			Session session1 = Session.getDefaultInstance(props, null);
			MimeMessage message = new MimeMessage(session1);
			
			try {
				message.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
			  	message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo));
			  	message.addRecipient(Message.RecipientType.CC, new InternetAddress(mailcc));

				message.setSubject("Program 1 Evaluation Test Result");
				//message.setText(htmlText);
				StringBuilder email = new StringBuilder();
				email.append("<html><head>");		
				email.append("<br><br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\"> 5126675</label>");
				email.append("<br><br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">Thank you for taking the evaluation test</label>");
				email.append("<br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">You Scored : 60</label>");
				email.append("<br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">Your Result is : pass </label><br>");
				email.append("<br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
				email.append("</html></head>");						
				message.setContent(email.toString(),"text/html" ); 

				// Send message
				Transport.send(message);
				System.out.println("Mail sent successfully to user!!!");
			}  catch (Exception e) {
				e.printStackTrace();
			}
		
			//
		 	String reportMailTo = "rajarama.kaniyoor.osv@fedex.com";//"ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";

		 	Properties props1 = System.getProperties();
			props1.put("mail.smtp.host", "mapper.gslb.fedex.com");
			props1.put("mail.smtp.port", "25");
			props1.put("mail.smtp.connectiontimeout", 10000);
			props1.put("mail.smtp.timeout", 10000);
			props1.put("mail.smtp.writetimeout", 10000);
			
			Session session11 = Session.getDefaultInstance(props, null);
			MimeMessage message1 = new MimeMessage(session11);
			
			try {
				message1.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
			  	message1.addRecipient(Message.RecipientType.TO, new InternetAddress(reportMailTo));
				
			  	BodyPart messageBodyPart1 = new MimeBodyPart(); 
				
				message1.setSubject("Evaluation Test Details");
				
				StringBuilder email = new StringBuilder();
				email.append("<html><head>");					
				email.append("<br><br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">Please find attached the details of the test taken by:</label>");
				email.append("<br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\"> 5126675 </label>");
				email.append("<br><br>");
				email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
				email.append("</html></head>");		
				messageBodyPart1.setContent(email.toString(),"text/html" ); 			
				
				MimeBodyPart messageBodyPart2 = new MimeBodyPart();  	        
		        
		        DataSource source = new FileDataSource(filename);  
		        messageBodyPart2.setDataHandler(new DataHandler(source));  
		        messageBodyPart2.setFileName("test.txt");  
		         
		        // create Multi part object and add MimeBodyPart objects to this object      
		        Multipart multipart = new MimeMultipart();  
		        multipart.addBodyPart(messageBodyPart1);  
		        multipart.addBodyPart(messageBodyPart2);  
		        message1.setContent(multipart);  
		        Transport.send(message1);
		        System.out.println("Mail sent successfully to Manager!!!");
			}  catch (Exception e) {
				e.printStackTrace();
			}		
	}

}
