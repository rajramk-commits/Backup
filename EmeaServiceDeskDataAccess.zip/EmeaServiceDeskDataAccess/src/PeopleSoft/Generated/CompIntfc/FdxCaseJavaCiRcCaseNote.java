
//*****************************************************************
//* 
//* FdxCaseJavaCiRcCaseNote.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public class FdxCaseJavaCiRcCaseNote implements IFdxCaseJavaCiRcCaseNote 
  {
  public FdxCaseJavaCiRcCaseNote(IObject oThis) { m_oThis = oThis; }

  public long getItemNum() throws JOAException {
    return ((Long)m_oThis.getProperty("ItemNum")).longValue();
 }

  public String getNoteSummary() throws JOAException {
    return (String)m_oThis.getProperty("NOTE_SUMMARY");
 }

  public void setNoteSummary(String inNoteSummary) throws JOAException {
    m_oThis.setProperty("NOTE_SUMMARY", inNoteSummary);
 }

  public String getNoteType() throws JOAException {
    return (String)m_oThis.getProperty("NOTE_TYPE");
 }

  public void setNoteType(String inNoteType) throws JOAException {
    m_oThis.setProperty("NOTE_TYPE", inNoteType);
 }

  public String getNoteOrigin() throws JOAException {
    return (String)m_oThis.getProperty("NOTE_ORIGIN");
 }

  public void setNoteOrigin(String inNoteOrigin) throws JOAException {
    m_oThis.setProperty("NOTE_ORIGIN", inNoteOrigin);
 }

  public String getNoteContactType() throws JOAException {
    return (String)m_oThis.getProperty("NOTE_CONTACT_TYPE");
 }

  public void setNoteContactType(String inNoteContactType) throws JOAException {
    m_oThis.setProperty("NOTE_CONTACT_TYPE", inNoteContactType);
 }

  public String getNoteDescrlong() throws JOAException {
    return (String)m_oThis.getProperty("NOTE_DESCRLONG");
 }

  public void setNoteDescrlong(String inNoteDescrlong) throws JOAException {
    m_oThis.setProperty("NOTE_DESCRLONG", inNoteDescrlong);
 }

  public Object getPropertyByName(String Name) throws JOAException {
    Object[] args = new Object[1];
    args[0] = Name;
    return (Object)m_oThis.invokeMethod("GetPropertyByName", args);
    }

  public long setPropertyByName(String Name, Object Value) throws JOAException {
    Object[] args = new Object[2];
    args[0] = Name;
    args[1] = Value;
    return ((Long)(m_oThis.invokeMethod("SetPropertyByName", args))).longValue();
    }

  public ICompIntfcPropertyInfo getPropertyInfoByName(String Name) throws JOAException {
    Object[] args = new Object[1];
    args[0] = Name;
    return (ICompIntfcPropertyInfo)m_oThis.invokeMethod("GetPropertyInfoByName", args);
    }

  IObject m_oThis;
  }
