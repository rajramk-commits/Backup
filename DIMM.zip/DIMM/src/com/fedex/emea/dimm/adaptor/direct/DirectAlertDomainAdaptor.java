package com.fedex.emea.dimm.adaptor.direct;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;
import com.fedex.emea.dimm.alert.AbstractAlert;
import com.fedex.emea.dimm.alert.PhysicalAlert;
import com.fedex.emea.dimm.utils.DIMMConstants;
import com.fedex.emea.dimm.utils.Utilities;

public class DirectAlertDomainAdaptor extends AbstractAlertDomainAdaptor{

	private DirectAlertDomainAdaptorConfig config;
	
	public DirectAlertDomainAdaptor() throws Exception {
		super();
		config = new DirectAlertDomainAdaptorConfig();
	}

	@Override
	public AbstractAlertDomainAdaptorConfig getConfig() {
		return config;
	}

	@Override
	public boolean isApplicable(AbstractAlert physicalAlert) {
		return true;//applicable for any alert
	}

	@Override
	protected String adaptServerValue(PhysicalAlert physicalAlert) {
		
		String serverValue = null;
		//For Component_3
		if(Utilities.getOvoServerComponents().contains(physicalAlert.getComponent())) {
			serverValue = physicalAlert.getServer();
		} else {
			serverValue = DIMMConstants.GENERIC_SERVER;
		}
		return serverValue;
	}
}
