package com.fedex.emea.sd.da.exceptions;

public class PrSpocsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4437062179071667454L;

	/**
	 * Method 'PrSpocsDaoException'
	 * 
	 * @param message
	 */
	public PrSpocsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrSpocsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrSpocsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
