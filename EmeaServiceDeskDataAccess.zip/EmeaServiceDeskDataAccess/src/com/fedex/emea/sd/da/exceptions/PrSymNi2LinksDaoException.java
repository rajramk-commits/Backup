package com.fedex.emea.sd.da.exceptions;

public class PrSymNi2LinksDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3993484528447351243L;

	/**
	 * Method 'PrSymNi2LinksDaoException'
	 * 
	 * @param message
	 */
	public PrSymNi2LinksDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrSymNi2LinksDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrSymNi2LinksDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
