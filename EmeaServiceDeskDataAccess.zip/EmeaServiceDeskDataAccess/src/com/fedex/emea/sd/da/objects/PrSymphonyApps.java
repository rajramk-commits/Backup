package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;

public class PrSymphonyApps implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3394998967085427165L;

	/** 
	 * This attribute maps to the column SYM_EAI_ID in the PR_SYMPHONY_APPS table.
	 */
	protected String symEaiId;

	/** 
	 * This attribute maps to the column SYM_APP_NAME in the PR_SYMPHONY_APPS table.
	 */
	protected String symAppName;

	/** 
	 * This attribute maps to the column SYM_PROF_NAME in the PR_SYMPHONY_APPS table.
	 */
	protected String symProfName;

	/** 
	 * This attribute maps to the column SYM_IT_LEAD in the PR_SYMPHONY_APPS table.
	 */
	protected String symItLead;

	/** 
	 * This attribute maps to the column SYM_PROJ_DISPO in the PR_SYMPHONY_APPS table.
	 */
	protected String symProjDispo;

	/** 
	 * This attribute maps to the column SYM_DOMAIN in the PR_SYMPHONY_APPS table.
	 */
	protected String symDomain;

	/** 
	 * This attribute maps to the column SYM_TIER in the PR_SYMPHONY_APPS table.
	 */
	protected String symTier;

	/** 
	 * This attribute maps to the column SYM_APP_STATE in the PR_SYMPHONY_APPS table.
	 */
	protected String symAppState;

	/** 
	 * This attribute maps to the column SYM_FRMWRK in the PR_SYMPHONY_APPS table.
	 */
	protected String symFrmwrk;

	/** 
	 * This attribute maps to the column SYM_DWN_IMP in the PR_SYMPHONY_APPS table.
	 */
	protected String symDwnImp;

	/** 
	 * This attribute maps to the column SYM_AVG_TX_DAY in the PR_SYMPHONY_APPS table.
	 */
	protected String symAvgTxDay;

	/** 
	 * This attribute maps to the column SYM_RPO in the PR_SYMPHONY_APPS table.
	 */
	protected String symRpo;

	/** 
	 * This attribute maps to the column SYM_RTO in the PR_SYMPHONY_APPS table.
	 */
	protected String symRto;

	/** 
	 * This attribute maps to the column SYM_ACCESS_TYP in the PR_SYMPHONY_APPS table.
	 */
	protected String symAccessTyp;

	/** 
	 * This attribute maps to the column SYM_PLATFORM in the PR_SYMPHONY_APPS table.
	 */
	protected String symPlatform;

	/** 
	 * This attribute maps to the column SYM_ARCH_DSGN in the PR_SYMPHONY_APPS table.
	 */
	protected String symArchDsgn;

	/** 
	 * This attribute maps to the column SYM_BACKLOG_METH in the PR_SYMPHONY_APPS table.
	 */
	protected String symBacklogMeth;

	/** 
	 * This attribute maps to the column SYM_BUS_FUNC in the PR_SYMPHONY_APPS table.
	 */
	protected String symBusFunc;

	/** 
	 * This attribute maps to the column SYM_EXT_USR in the PR_SYMPHONY_APPS table.
	 */
	protected String symExtUsr;

	/** 
	 * This attribute maps to the column SYM_INT_USR in the PR_SYMPHONY_APPS table.
	 */
	protected String symIntUsr;

	/** 
	 * This attribute maps to the column SYM_REGL_LEGAL_FLG in the PR_SYMPHONY_APPS table.
	 */
	protected String symReglLegalFlg;

	/** 
	 * This attribute maps to the column SYM_LAST_UPD_DTTM in the PR_SYMPHONY_APPS table.
	 */
	protected Date symLastUpdDttm;

	/**
	 * Method 'PrSymphonyApps'
	 * 
	 */
	public PrSymphonyApps()
	{
	}

	/**
	 * Method 'getSymEaiId'
	 * 
	 * @return String
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/**
	 * Method 'setSymEaiId'
	 * 
	 * @param symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/**
	 * Method 'getSymAppName'
	 * 
	 * @return String
	 */
	public String getSymAppName()
	{
		return symAppName;
	}

	/**
	 * Method 'setSymAppName'
	 * 
	 * @param symAppName
	 */
	public void setSymAppName(String symAppName)
	{
		this.symAppName = symAppName;
	}

	/**
	 * Method 'getSymProfName'
	 * 
	 * @return String
	 */
	public String getSymProfName()
	{
		return symProfName;
	}

	/**
	 * Method 'setSymProfName'
	 * 
	 * @param symProfName
	 */
	public void setSymProfName(String symProfName)
	{
		this.symProfName = symProfName;
	}

	/**
	 * Method 'getSymItLead'
	 * 
	 * @return String
	 */
	public String getSymItLead()
	{
		return symItLead;
	}

	/**
	 * Method 'setSymItLead'
	 * 
	 * @param symItLead
	 */
	public void setSymItLead(String symItLead)
	{
		this.symItLead = symItLead;
	}

	/**
	 * Method 'getSymProjDispo'
	 * 
	 * @return String
	 */
	public String getSymProjDispo()
	{
		return symProjDispo;
	}

	/**
	 * Method 'setSymProjDispo'
	 * 
	 * @param symProjDispo
	 */
	public void setSymProjDispo(String symProjDispo)
	{
		this.symProjDispo = symProjDispo;
	}

	/**
	 * Method 'getSymDomain'
	 * 
	 * @return String
	 */
	public String getSymDomain()
	{
		return symDomain;
	}

	/**
	 * Method 'setSymDomain'
	 * 
	 * @param symDomain
	 */
	public void setSymDomain(String symDomain)
	{
		this.symDomain = symDomain;
	}

	/**
	 * Method 'getSymTier'
	 * 
	 * @return String
	 */
	public String getSymTier()
	{
		return symTier;
	}

	/**
	 * Method 'setSymTier'
	 * 
	 * @param symTier
	 */
	public void setSymTier(String symTier)
	{
		this.symTier = symTier;
	}

	/**
	 * Method 'getSymAppState'
	 * 
	 * @return String
	 */
	public String getSymAppState()
	{
		return symAppState;
	}

	/**
	 * Method 'setSymAppState'
	 * 
	 * @param symAppState
	 */
	public void setSymAppState(String symAppState)
	{
		this.symAppState = symAppState;
	}

	/**
	 * Method 'getSymFrmwrk'
	 * 
	 * @return String
	 */
	public String getSymFrmwrk()
	{
		return symFrmwrk;
	}

	/**
	 * Method 'setSymFrmwrk'
	 * 
	 * @param symFrmwrk
	 */
	public void setSymFrmwrk(String symFrmwrk)
	{
		this.symFrmwrk = symFrmwrk;
	}

	/**
	 * Method 'getSymDwnImp'
	 * 
	 * @return String
	 */
	public String getSymDwnImp()
	{
		return symDwnImp;
	}

	/**
	 * Method 'setSymDwnImp'
	 * 
	 * @param symDwnImp
	 */
	public void setSymDwnImp(String symDwnImp)
	{
		this.symDwnImp = symDwnImp;
	}

	/**
	 * Method 'getSymAvgTxDay'
	 * 
	 * @return String
	 */
	public String getSymAvgTxDay()
	{
		return symAvgTxDay;
	}

	/**
	 * Method 'setSymAvgTxDay'
	 * 
	 * @param symAvgTxDay
	 */
	public void setSymAvgTxDay(String symAvgTxDay)
	{
		this.symAvgTxDay = symAvgTxDay;
	}

	/**
	 * Method 'getSymRpo'
	 * 
	 * @return String
	 */
	public String getSymRpo()
	{
		return symRpo;
	}

	/**
	 * Method 'setSymRpo'
	 * 
	 * @param symRpo
	 */
	public void setSymRpo(String symRpo)
	{
		this.symRpo = symRpo;
	}

	/**
	 * Method 'getSymRto'
	 * 
	 * @return String
	 */
	public String getSymRto()
	{
		return symRto;
	}

	/**
	 * Method 'setSymRto'
	 * 
	 * @param symRto
	 */
	public void setSymRto(String symRto)
	{
		this.symRto = symRto;
	}

	/**
	 * Method 'getSymAccessTyp'
	 * 
	 * @return String
	 */
	public String getSymAccessTyp()
	{
		return symAccessTyp;
	}

	/**
	 * Method 'setSymAccessTyp'
	 * 
	 * @param symAccessTyp
	 */
	public void setSymAccessTyp(String symAccessTyp)
	{
		this.symAccessTyp = symAccessTyp;
	}

	/**
	 * Method 'getSymPlatform'
	 * 
	 * @return String
	 */
	public String getSymPlatform()
	{
		return symPlatform;
	}

	/**
	 * Method 'setSymPlatform'
	 * 
	 * @param symPlatform
	 */
	public void setSymPlatform(String symPlatform)
	{
		this.symPlatform = symPlatform;
	}

	/**
	 * Method 'getSymArchDsgn'
	 * 
	 * @return String
	 */
	public String getSymArchDsgn()
	{
		return symArchDsgn;
	}

	/**
	 * Method 'setSymArchDsgn'
	 * 
	 * @param symArchDsgn
	 */
	public void setSymArchDsgn(String symArchDsgn)
	{
		this.symArchDsgn = symArchDsgn;
	}

	/**
	 * Method 'getSymBacklogMeth'
	 * 
	 * @return String
	 */
	public String getSymBacklogMeth()
	{
		return symBacklogMeth;
	}

	/**
	 * Method 'setSymBacklogMeth'
	 * 
	 * @param symBacklogMeth
	 */
	public void setSymBacklogMeth(String symBacklogMeth)
	{
		this.symBacklogMeth = symBacklogMeth;
	}

	/**
	 * Method 'getSymBusFunc'
	 * 
	 * @return String
	 */
	public String getSymBusFunc()
	{
		return symBusFunc;
	}

	/**
	 * Method 'setSymBusFunc'
	 * 
	 * @param symBusFunc
	 */
	public void setSymBusFunc(String symBusFunc)
	{
		this.symBusFunc = symBusFunc;
	}

	/**
	 * Method 'getSymExtUsr'
	 * 
	 * @return String
	 */
	public String getSymExtUsr()
	{
		return symExtUsr;
	}

	/**
	 * Method 'setSymExtUsr'
	 * 
	 * @param symExtUsr
	 */
	public void setSymExtUsr(String symExtUsr)
	{
		this.symExtUsr = symExtUsr;
	}

	/**
	 * Method 'getSymIntUsr'
	 * 
	 * @return String
	 */
	public String getSymIntUsr()
	{
		return symIntUsr;
	}

	/**
	 * Method 'setSymIntUsr'
	 * 
	 * @param symIntUsr
	 */
	public void setSymIntUsr(String symIntUsr)
	{
		this.symIntUsr = symIntUsr;
	}

	/**
	 * Method 'getSymReglLegalFlg'
	 * 
	 * @return String
	 */
	public String getSymReglLegalFlg()
	{
		return symReglLegalFlg;
	}

	/**
	 * Method 'setSymReglLegalFlg'
	 * 
	 * @param symReglLegalFlg
	 */
	public void setSymReglLegalFlg(String symReglLegalFlg)
	{
		this.symReglLegalFlg = symReglLegalFlg;
	}

	/**
	 * Method 'getSymLastUpdDttm'
	 * 
	 * @return Date
	 */
	public Date getSymLastUpdDttm()
	{
		return symLastUpdDttm;
	}

	/**
	 * Method 'setSymLastUpdDttm'
	 * 
	 * @param symLastUpdDttm
	 */
	public void setSymLastUpdDttm(Date symLastUpdDttm)
	{
		this.symLastUpdDttm = symLastUpdDttm;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSymphonyApps)) {
			return false;
		}
		
		final PrSymphonyApps _cast = (PrSymphonyApps) _other;
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		if (symAppName == null ? _cast.symAppName != symAppName : !symAppName.equals( _cast.symAppName )) {
			return false;
		}
		
		if (symProfName == null ? _cast.symProfName != symProfName : !symProfName.equals( _cast.symProfName )) {
			return false;
		}
		
		if (symItLead == null ? _cast.symItLead != symItLead : !symItLead.equals( _cast.symItLead )) {
			return false;
		}
		
		if (symProjDispo == null ? _cast.symProjDispo != symProjDispo : !symProjDispo.equals( _cast.symProjDispo )) {
			return false;
		}
		
		if (symDomain == null ? _cast.symDomain != symDomain : !symDomain.equals( _cast.symDomain )) {
			return false;
		}
		
		if (symTier == null ? _cast.symTier != symTier : !symTier.equals( _cast.symTier )) {
			return false;
		}
		
		if (symAppState == null ? _cast.symAppState != symAppState : !symAppState.equals( _cast.symAppState )) {
			return false;
		}
		
		if (symFrmwrk == null ? _cast.symFrmwrk != symFrmwrk : !symFrmwrk.equals( _cast.symFrmwrk )) {
			return false;
		}
		
		if (symDwnImp == null ? _cast.symDwnImp != symDwnImp : !symDwnImp.equals( _cast.symDwnImp )) {
			return false;
		}
		
		if (symAvgTxDay == null ? _cast.symAvgTxDay != symAvgTxDay : !symAvgTxDay.equals( _cast.symAvgTxDay )) {
			return false;
		}
		
		if (symRpo == null ? _cast.symRpo != symRpo : !symRpo.equals( _cast.symRpo )) {
			return false;
		}
		
		if (symRto == null ? _cast.symRto != symRto : !symRto.equals( _cast.symRto )) {
			return false;
		}
		
		if (symAccessTyp == null ? _cast.symAccessTyp != symAccessTyp : !symAccessTyp.equals( _cast.symAccessTyp )) {
			return false;
		}
		
		if (symPlatform == null ? _cast.symPlatform != symPlatform : !symPlatform.equals( _cast.symPlatform )) {
			return false;
		}
		
		if (symArchDsgn == null ? _cast.symArchDsgn != symArchDsgn : !symArchDsgn.equals( _cast.symArchDsgn )) {
			return false;
		}
		
		if (symBacklogMeth == null ? _cast.symBacklogMeth != symBacklogMeth : !symBacklogMeth.equals( _cast.symBacklogMeth )) {
			return false;
		}
		
		if (symBusFunc == null ? _cast.symBusFunc != symBusFunc : !symBusFunc.equals( _cast.symBusFunc )) {
			return false;
		}
		
		if (symExtUsr == null ? _cast.symExtUsr != symExtUsr : !symExtUsr.equals( _cast.symExtUsr )) {
			return false;
		}
		
		if (symIntUsr == null ? _cast.symIntUsr != symIntUsr : !symIntUsr.equals( _cast.symIntUsr )) {
			return false;
		}
		
		if (symReglLegalFlg == null ? _cast.symReglLegalFlg != symReglLegalFlg : !symReglLegalFlg.equals( _cast.symReglLegalFlg )) {
			return false;
		}
		
		if (symLastUpdDttm == null ? _cast.symLastUpdDttm != symLastUpdDttm : !symLastUpdDttm.equals( _cast.symLastUpdDttm )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		if (symAppName != null) {
			_hashCode = 29 * _hashCode + symAppName.hashCode();
		}
		
		if (symProfName != null) {
			_hashCode = 29 * _hashCode + symProfName.hashCode();
		}
		
		if (symItLead != null) {
			_hashCode = 29 * _hashCode + symItLead.hashCode();
		}
		
		if (symProjDispo != null) {
			_hashCode = 29 * _hashCode + symProjDispo.hashCode();
		}
		
		if (symDomain != null) {
			_hashCode = 29 * _hashCode + symDomain.hashCode();
		}
		
		if (symTier != null) {
			_hashCode = 29 * _hashCode + symTier.hashCode();
		}
		
		if (symAppState != null) {
			_hashCode = 29 * _hashCode + symAppState.hashCode();
		}
		
		if (symFrmwrk != null) {
			_hashCode = 29 * _hashCode + symFrmwrk.hashCode();
		}
		
		if (symDwnImp != null) {
			_hashCode = 29 * _hashCode + symDwnImp.hashCode();
		}
		
		if (symAvgTxDay != null) {
			_hashCode = 29 * _hashCode + symAvgTxDay.hashCode();
		}
		
		if (symRpo != null) {
			_hashCode = 29 * _hashCode + symRpo.hashCode();
		}
		
		if (symRto != null) {
			_hashCode = 29 * _hashCode + symRto.hashCode();
		}
		
		if (symAccessTyp != null) {
			_hashCode = 29 * _hashCode + symAccessTyp.hashCode();
		}
		
		if (symPlatform != null) {
			_hashCode = 29 * _hashCode + symPlatform.hashCode();
		}
		
		if (symArchDsgn != null) {
			_hashCode = 29 * _hashCode + symArchDsgn.hashCode();
		}
		
		if (symBacklogMeth != null) {
			_hashCode = 29 * _hashCode + symBacklogMeth.hashCode();
		}
		
		if (symBusFunc != null) {
			_hashCode = 29 * _hashCode + symBusFunc.hashCode();
		}
		
		if (symExtUsr != null) {
			_hashCode = 29 * _hashCode + symExtUsr.hashCode();
		}
		
		if (symIntUsr != null) {
			_hashCode = 29 * _hashCode + symIntUsr.hashCode();
		}
		
		if (symReglLegalFlg != null) {
			_hashCode = 29 * _hashCode + symReglLegalFlg.hashCode();
		}
		
		if (symLastUpdDttm != null) {
			_hashCode = 29 * _hashCode + symLastUpdDttm.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrSymphonyAppsPk
	 */
	public PrSymphonyAppsPk createPk()
	{
		return new PrSymphonyAppsPk(symEaiId);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSymphonyApps: " );
		ret.append( "symEaiId=" + symEaiId );
		ret.append( ", symAppName=" + symAppName );
		ret.append( ", symProfName=" + symProfName );
		ret.append( ", symItLead=" + symItLead );
		ret.append( ", symProjDispo=" + symProjDispo );
		ret.append( ", symDomain=" + symDomain );
		ret.append( ", symTier=" + symTier );
		ret.append( ", symAppState=" + symAppState );
		ret.append( ", symFrmwrk=" + symFrmwrk );
		ret.append( ", symDwnImp=" + symDwnImp );
		ret.append( ", symAvgTxDay=" + symAvgTxDay );
		ret.append( ", symRpo=" + symRpo );
		ret.append( ", symRto=" + symRto );
		ret.append( ", symAccessTyp=" + symAccessTyp );
		ret.append( ", symPlatform=" + symPlatform );
		ret.append( ", symArchDsgn=" + symArchDsgn );
		ret.append( ", symBacklogMeth=" + symBacklogMeth );
		ret.append( ", symBusFunc=" + symBusFunc );
		ret.append( ", symExtUsr=" + symExtUsr );
		ret.append( ", symIntUsr=" + symIntUsr );
		ret.append( ", symReglLegalFlg=" + symReglLegalFlg );
		ret.append( ", symLastUpdDttm=" + symLastUpdDttm );
		return ret.toString();
	}

}
