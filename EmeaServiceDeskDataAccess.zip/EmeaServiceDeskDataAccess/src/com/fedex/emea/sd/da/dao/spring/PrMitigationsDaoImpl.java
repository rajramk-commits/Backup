package com.fedex.emea.sd.da.dao.spring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrMitigationsDao;
import com.fedex.emea.sd.da.exceptions.PrMitigationsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrMitigations;
import com.fedex.emea.sd.da.objects.PrMitigationsPk;

public class PrMitigationsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrMitigations>, PrMitigationsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrMitigationsPk
	 */
	@Transactional
	public PrMitigationsPk insert(PrMitigations dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getItem(),dto.getQuestion(),dto.getAnswer(),dto.getMitigationStatus(),dto.getLastUpdateDttm(),dto.isAuditIdNull()?null:dto.getAuditId(),dto.getOrg());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_MITIGATIONS table.
	 */
	@Transactional
	public void update(PrMitigationsPk pk, PrMitigations dto) throws PrMitigationsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET CY = ?, EAI_ID = ?, SYM_APP_NAME = ?, NI2_APP_ID = ?, NI2_APP_NAME = ?, RESP_MD_PIN = ?, RESP_MGR_PIN = ?, ITEM = ?, QUESTION = ?, ANSWER = ?, MITIGATION_STATUS = ?, LAST_UPDATE_DTTM = ?, AUDIT_ID = ?, ORG = ? WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?",dto.getCy(),dto.getEaiId(),dto.getSymAppName(),dto.getNi2AppId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getItem(),dto.getQuestion(),dto.getAnswer(),dto.getMitigationStatus(),dto.getLastUpdateDttm(),dto.getAuditId(),dto.getOrg(),pk.getCy(),pk.getEaiId(),pk.getNi2AppId(),pk.getItem());
	}

	/** 
	 * Deletes a single row in the PR_MITIGATIONS table.
	 */
	@Transactional
	public void delete(PrMitigationsPk pk) throws PrMitigationsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?",pk.getCy(),pk.getEaiId(),pk.getNi2AppId(),pk.getItem());
	}
	
	/** 
	 * Deletes rows per Application Key + CY.
	 */
	@Transactional
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrMitigationsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ?",appKey.getCy(),appKey.getSymEaiId(),appKey.getNi2AppId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrMitigations
	 */
	public PrMitigations mapRow(ResultSet rs, int row) throws SQLException
	{
		PrMitigations dto = new PrMitigations();
		dto.setCy( rs.getString( 1 ) );
		dto.setEaiId( rs.getString( 2 ) );
		dto.setSymAppName( rs.getString( 3 ) );
		dto.setNi2AppId( rs.getString( 4 ) );
		dto.setNi2AppName( rs.getString( 5 ) );
		dto.setRespMdPin( rs.getString( 6 ) );
		dto.setRespMgrPin( rs.getString( 7 ) );
		dto.setItem( rs.getString( 8 ) );
		dto.setQuestion( rs.getString( 9 ) );
		dto.setAnswer( rs.getString( 10 ) );
		dto.setMitigationStatus( rs.getString( 11 ) );
		dto.setLastUpdateDttm( rs.getTimestamp(12 ) );
		dto.setAuditId( rs.getInt( 13 ) );
		if (rs.wasNull()) {
			dto.setAuditIdNull( true );
		}
		dto.setOrg( rs.getString( 14 ) );
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_MITIGATIONS";
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId AND ITEM = :item'.
	 */
	@Transactional
	public PrMitigations findByPrimaryKey(String cy, String eaiId, String ni2AppId, String item) throws PrMitigationsDaoException
	{
		try {
			List<PrMitigations> list = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? AND EAI_ID = ? AND NI2_APP_ID = ? AND ITEM = ?", this,cy,eaiId,ni2AppId,item);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria ''.
	 */
	@Transactional
	public List<PrMitigations> findAll() throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " ORDER BY CY, EAI_ID, NI2_APP_ID, ITEM", this);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'CY = :cy'.
	 */
	@Transactional
	public List<PrMitigations> findWhereCyEquals(String cy) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all keys (CMDB ID, EID ID) from the PR_MITIGATIONS table per CY.
	 */
	@Transactional
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrMitigationsDaoException {
		List<PeakReadinessAppKeys> returnedList = new ArrayList<PeakReadinessAppKeys>();
		
		try {
			List<PrMitigations> eltList = jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
			for (PrMitigations elt: eltList) {
				returnedList.add(new PeakReadinessAppKeys(cy, elt.getNi2AppId(), elt.getEaiId()));
			}
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
		return returnedList;
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	@Transactional
	public List<PrMitigations> findWhereEaiIdEquals(String eaiId) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE EAI_ID = ? ORDER BY EAI_ID", this,eaiId);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	@Transactional
	public List<PrMitigations> findWhereSymAppNameEquals(String symAppName) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SYM_APP_NAME = ? ORDER BY SYM_APP_NAME", this,symAppName);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public List<PrMitigations> findWhereNi2AppIdEquals(String ni2AppId) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_ID = ? ORDER BY NI2_APP_ID", this,ni2AppId);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	@Transactional
	public List<PrMitigations> findWhereNi2AppNameEquals(String ni2AppName) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_NAME = ? ORDER BY NI2_APP_NAME", this,ni2AppName);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	@Transactional
	public List<PrMitigations> findWhereRespMdPinEquals(String respMdPin) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MD_PIN = ? ORDER BY RESP_MD_PIN", this,respMdPin);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	@Transactional
	public List<PrMitigations> findWhereRespMgrPinEquals(String respMgrPin) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MGR_PIN = ? ORDER BY RESP_MGR_PIN", this,respMgrPin);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'ITEM = :item'.
	 */
	@Transactional
	public List<PrMitigations> findWhereItemEquals(String item) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ITEM = ? ORDER BY ITEM", this,item);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'QUESTION = :question'.
	 */
	@Transactional
	public List<PrMitigations> findWhereQuestionEquals(String question) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE QUESTION = ? ORDER BY QUESTION", this,question);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'ANSWER = :answer'.
	 */
	@Transactional
	public List<PrMitigations> findWhereAnswerEquals(String answer) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE ANSWER = ? ORDER BY ANSWER", this,answer);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'MITIGATION_STATUS = :mitigationStatus'.
	 */
	@Transactional
	public List<PrMitigations> findWhereMitigationStatusEquals(String mitigationStatus) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE MITIGATION_STATUS = ? ORDER BY MITIGATION_STATUS", this,mitigationStatus);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	@Transactional
	public List<PrMitigations> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE LAST_UPDATE_DTTM = ? ORDER BY LAST_UPDATE_DTTM", this,lastUpdateDttm);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	@Transactional
	public List<PrMitigations> findWhereAuditIdEquals(int auditId) throws PrMitigationsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, EAI_ID, SYM_APP_NAME, NI2_APP_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, ITEM, QUESTION, ANSWER, MITIGATION_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE AUDIT_ID = ? ORDER BY AUDIT_ID", this,auditId);
		}
		catch (Exception e) {
			throw new PrMitigationsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_MITIGATIONS table that matches the specified primary-key value.
	 */
	public PrMitigations findByPrimaryKey(PrMitigationsPk pk) throws PrMitigationsDaoException
	{
		return findByPrimaryKey( pk.getCy(), pk.getEaiId(), pk.getNi2AppId(), pk.getItem() );
	}

}
