package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowUserGroups implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowActive;
	private String snowCostCenter;
	private String snowDefaultAssignee;
	private String snowDescription;
	private String snowEmail;
	private String snowExcludeManager;
	private String snowHourlyRate;
	private String snowIncludeMembers;
	private String snowManager;
	private String snowName;
	private String snowParent;
	private String snowPoints;
	private String snowSource;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowType;
	private String snowU_ChangeRequest;
	private String snowU_Country;
	private String snowU_CountryDeptLevel;
	private String snowU_DeliverTower;
	private String snowU_Demand;
	private String snowU_Director;
	private String snowU_FedexAndTntShared;
	private String snowU_Folder;
	private String snowU_FunctionalSubcategory;
	private String snowU_HistName;
	private String snowU_HistQm;
	private String snowU_HistQmRepLevel2;
	private String snowU_HistQmRepLevel3;
	private String snowU_HistQmRepLevel4;
	private String snowU_HistQmRepLevel5;
	private String snowU_HistRepLevel2;
	private String snowU_HistRepLevel3;
	private String snowU_HistRepLevel4;
	private String snowU_HistRepLevel5;
	private String snowU_HistSearchode;
	private String snowU_Incident;
	private String snowU_LocalHelpdesk;
	private String snowU_MailAutoclosure;
	private String snowU_NoAssignment;
	private String snowU_NotMeasured;
	private String snowU_OrganisationCategory;
	private String snowU_OutsourceIntegration;
	private String snowU_Problem;
	private String snowU_RegionalLevel;
	private String snowU_ReportingLevel1;
	private String snowU_ReportingLevel2;
	private String snowU_ReportingLevel3;
	private String snowU_ReportingLevel4;
	private String snowU_ReportingLevel5;
	private String snowU_Request;
	private String snowU_SearchCode;
	private String snowU_WorkgroupLevel;
	private String snowU_WorkgroupRole;
	
	public SnowUserGroups() {
	}
	
	public SnowUserGroups(HashMap<String, Object> jsonValues) {
		snowActive = SnowUtilities.getStringValueFromObject(jsonValues.get("active"));
		snowCostCenter = SnowUtilities.getStringValueFromObject(jsonValues.get("cost_center"));
		snowDefaultAssignee = SnowUtilities.getStringValueFromObject(jsonValues.get("default_assignee"));
		snowDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("description"));
		snowEmail = SnowUtilities.getStringValueFromObject(jsonValues.get("email"));
		snowExcludeManager = SnowUtilities.getStringValueFromObject(jsonValues.get("exclude_manager"));
		snowHourlyRate = SnowUtilities.getStringValueFromObject(jsonValues.get("hourly_rate"));
		snowIncludeMembers = SnowUtilities.getStringValueFromObject(jsonValues.get("include_members"));
		snowManager = SnowUtilities.getStringValueFromObject(jsonValues.get("manager"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowParent = SnowUtilities.getStringValueFromObject(jsonValues.get("parent"));
		snowPoints = SnowUtilities.getStringValueFromObject(jsonValues.get("points"));
		snowSource = SnowUtilities.getStringValueFromObject(jsonValues.get("source"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowType = SnowUtilities.getStringValueFromObject(jsonValues.get("type"));
		snowU_ChangeRequest = SnowUtilities.getStringValueFromObject(jsonValues.get("u_change_request"));
		snowU_Country = SnowUtilities.getStringValueFromObject(jsonValues.get("u_country"));
		snowU_CountryDeptLevel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_country___dept_level"));
		snowU_DeliverTower = SnowUtilities.getStringValueFromObject(jsonValues.get("u_deliver_tower"));
		snowU_Demand = SnowUtilities.getStringValueFromObject(jsonValues.get("u_demand"));
		snowU_Director = SnowUtilities.getStringValueFromObject(jsonValues.get("u_director"));
		snowU_FedexAndTntShared = SnowUtilities.getStringValueFromObject(jsonValues.get("u_fedex_and_tnt_shared"));
		snowU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("u_folder"));
		snowU_FunctionalSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_functional_subcategory"));
		snowU_HistName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_name"));
		snowU_HistQm = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_qm"));
		snowU_HistQmRepLevel2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_qm_rep_level_2"));
		snowU_HistQmRepLevel3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_qm_rep_level_3"));
		snowU_HistQmRepLevel4 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_qm_rep_level_4"));
		snowU_HistQmRepLevel5 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_qm_rep_level_5"));
		snowU_HistRepLevel2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_rep_level_2"));
		snowU_HistRepLevel3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_rep_level_3"));
		snowU_HistRepLevel4 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_rep_level_4"));
		snowU_HistRepLevel5 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_rep_level_5"));
		snowU_HistSearchode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hist_searchode"));
		snowU_Incident = SnowUtilities.getStringValueFromObject(jsonValues.get("u_incident"));
		snowU_LocalHelpdesk = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_helpdesk"));
		snowU_MailAutoclosure = SnowUtilities.getStringValueFromObject(jsonValues.get("u_mail_autoclosure"));
		snowU_NoAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("u_no_assignment"));
		snowU_NotMeasured = SnowUtilities.getStringValueFromObject(jsonValues.get("u_not_measured"));
		snowU_OrganisationCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_category"));
		snowU_OutsourceIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_integration"));
		snowU_Problem = SnowUtilities.getStringValueFromObject(jsonValues.get("u_problem"));
		snowU_RegionalLevel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_regional_level"));
		snowU_ReportingLevel1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_1"));
		snowU_ReportingLevel2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_2"));
		snowU_ReportingLevel3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_3"));
		snowU_ReportingLevel4 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_4"));
		snowU_ReportingLevel5 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_5"));
		snowU_Request = SnowUtilities.getStringValueFromObject(jsonValues.get("u_request"));
		snowU_SearchCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_search_code"));
		snowU_WorkgroupLevel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_workgroup_level"));
		snowU_WorkgroupRole = SnowUtilities.getStringValueFromObject(jsonValues.get("u_workgroup_role"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (snowActive != null && !snowActive.toString().isEmpty()) jsonObject.put("active", snowActive);
		if (snowCostCenter != null && !snowCostCenter.toString().isEmpty()) jsonObject.put("cost_center", snowCostCenter);
		if (snowDefaultAssignee != null && !snowDefaultAssignee.toString().isEmpty()) jsonObject.put("default_assignee", snowDefaultAssignee);
		if (snowDescription != null && !snowDescription.toString().isEmpty()) jsonObject.put("description", snowDescription);
		if (snowEmail != null && !snowEmail.toString().isEmpty()) jsonObject.put("email", snowEmail);
		if (snowExcludeManager != null && !snowExcludeManager.toString().isEmpty()) jsonObject.put("exclude_manager", snowExcludeManager);
		if (snowHourlyRate != null && !snowHourlyRate.toString().isEmpty()) jsonObject.put("hourly_rate", snowHourlyRate);
		if (snowIncludeMembers != null && !snowIncludeMembers.toString().isEmpty()) jsonObject.put("include_members", snowIncludeMembers);
		if (snowManager != null && !snowManager.toString().isEmpty()) jsonObject.put("manager", snowManager);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowParent != null && !snowParent.toString().isEmpty()) jsonObject.put("parent", snowParent);
		if (snowPoints != null && !snowPoints.toString().isEmpty()) jsonObject.put("points", snowPoints);
		if (snowSource != null && !snowSource.toString().isEmpty()) jsonObject.put("source", snowSource);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowType != null && !snowType.toString().isEmpty()) jsonObject.put("type", snowType);
		if (snowU_ChangeRequest != null && !snowU_ChangeRequest.toString().isEmpty()) jsonObject.put("u_change_request", snowU_ChangeRequest);
		if (snowU_Country != null && !snowU_Country.toString().isEmpty()) jsonObject.put("u_country", snowU_Country);
		if (snowU_CountryDeptLevel != null && !snowU_CountryDeptLevel.toString().isEmpty()) jsonObject.put("u_country___dept_level", snowU_CountryDeptLevel);
		if (snowU_DeliverTower != null && !snowU_DeliverTower.toString().isEmpty()) jsonObject.put("u_deliver_tower", snowU_DeliverTower);
		if (snowU_Demand != null && !snowU_Demand.toString().isEmpty()) jsonObject.put("u_demand", snowU_Demand);
		if (snowU_Director != null && !snowU_Director.toString().isEmpty()) jsonObject.put("u_director", snowU_Director);
		if (snowU_FedexAndTntShared != null && !snowU_FedexAndTntShared.toString().isEmpty()) jsonObject.put("u_fedex_and_tnt_shared", snowU_FedexAndTntShared);
		if (snowU_Folder != null && !snowU_Folder.toString().isEmpty()) jsonObject.put("u_folder", snowU_Folder);
		if (snowU_FunctionalSubcategory != null && !snowU_FunctionalSubcategory.toString().isEmpty()) jsonObject.put("u_functional_subcategory", snowU_FunctionalSubcategory);
		if (snowU_HistName != null && !snowU_HistName.toString().isEmpty()) jsonObject.put("u_hist_name", snowU_HistName);
		if (snowU_HistQm != null && !snowU_HistQm.toString().isEmpty()) jsonObject.put("u_hist_qm", snowU_HistQm);
		if (snowU_HistQmRepLevel2 != null && !snowU_HistQmRepLevel2.toString().isEmpty()) jsonObject.put("u_hist_qm_rep_level_2", snowU_HistQmRepLevel2);
		if (snowU_HistQmRepLevel3 != null && !snowU_HistQmRepLevel3.toString().isEmpty()) jsonObject.put("u_hist_qm_rep_level_3", snowU_HistQmRepLevel3);
		if (snowU_HistQmRepLevel4 != null && !snowU_HistQmRepLevel4.toString().isEmpty()) jsonObject.put("u_hist_qm_rep_level_4", snowU_HistQmRepLevel4);
		if (snowU_HistQmRepLevel5 != null && !snowU_HistQmRepLevel5.toString().isEmpty()) jsonObject.put("u_hist_qm_rep_level_5", snowU_HistQmRepLevel5);
		if (snowU_HistRepLevel2 != null && !snowU_HistRepLevel2.toString().isEmpty()) jsonObject.put("u_hist_rep_level_2", snowU_HistRepLevel2);
		if (snowU_HistRepLevel3 != null && !snowU_HistRepLevel3.toString().isEmpty()) jsonObject.put("u_hist_rep_level_3", snowU_HistRepLevel3);
		if (snowU_HistRepLevel4 != null && !snowU_HistRepLevel4.toString().isEmpty()) jsonObject.put("u_hist_rep_level_4", snowU_HistRepLevel4);
		if (snowU_HistRepLevel5 != null && !snowU_HistRepLevel5.toString().isEmpty()) jsonObject.put("u_hist_rep_level_5", snowU_HistRepLevel5);
		if (snowU_HistSearchode != null && !snowU_HistSearchode.toString().isEmpty()) jsonObject.put("u_hist_searchode", snowU_HistSearchode);
		if (snowU_Incident != null && !snowU_Incident.toString().isEmpty()) jsonObject.put("u_incident", snowU_Incident);
		if (snowU_LocalHelpdesk != null && !snowU_LocalHelpdesk.toString().isEmpty()) jsonObject.put("u_local_helpdesk", snowU_LocalHelpdesk);
		if (snowU_MailAutoclosure != null && !snowU_MailAutoclosure.toString().isEmpty()) jsonObject.put("u_mail_autoclosure", snowU_MailAutoclosure);
		if (snowU_NoAssignment != null && !snowU_NoAssignment.toString().isEmpty()) jsonObject.put("u_no_assignment", snowU_NoAssignment);
		if (snowU_NotMeasured != null && !snowU_NotMeasured.toString().isEmpty()) jsonObject.put("u_not_measured", snowU_NotMeasured);
		if (snowU_OrganisationCategory != null && !snowU_OrganisationCategory.toString().isEmpty()) jsonObject.put("u_organisation_category", snowU_OrganisationCategory);
		if (snowU_OutsourceIntegration != null && !snowU_OutsourceIntegration.toString().isEmpty()) jsonObject.put("u_outsource_integration", snowU_OutsourceIntegration);
		if (snowU_Problem != null && !snowU_Problem.toString().isEmpty()) jsonObject.put("u_problem", snowU_Problem);
		if (snowU_RegionalLevel != null && !snowU_RegionalLevel.toString().isEmpty()) jsonObject.put("u_regional_level", snowU_RegionalLevel);
		if (snowU_ReportingLevel1 != null && !snowU_ReportingLevel1.toString().isEmpty()) jsonObject.put("u_reporting_level_1", snowU_ReportingLevel1);
		if (snowU_ReportingLevel2 != null && !snowU_ReportingLevel2.toString().isEmpty()) jsonObject.put("u_reporting_level_2", snowU_ReportingLevel2);
		if (snowU_ReportingLevel3 != null && !snowU_ReportingLevel3.toString().isEmpty()) jsonObject.put("u_reporting_level_3", snowU_ReportingLevel3);
		if (snowU_ReportingLevel4 != null && !snowU_ReportingLevel4.toString().isEmpty()) jsonObject.put("u_reporting_level_4", snowU_ReportingLevel4);
		if (snowU_ReportingLevel5 != null && !snowU_ReportingLevel5.toString().isEmpty()) jsonObject.put("u_reporting_level_5", snowU_ReportingLevel5);
		if (snowU_Request != null && !snowU_Request.toString().isEmpty()) jsonObject.put("u_request", snowU_Request);
		if (snowU_SearchCode != null && !snowU_SearchCode.toString().isEmpty()) jsonObject.put("u_search_code", snowU_SearchCode);
		if (snowU_WorkgroupLevel != null && !snowU_WorkgroupLevel.toString().isEmpty()) jsonObject.put("u_workgroup_level", snowU_WorkgroupLevel);
		if (snowU_WorkgroupRole != null && !snowU_WorkgroupRole.toString().isEmpty()) jsonObject.put("u_workgroup_role", snowU_WorkgroupRole);
		
		return jsonObject;
	}

	public String getSnowActive() {
		return snowActive;
	}

	public void setSnowActive(String snowActive) {
		this.snowActive = snowActive;
	}

	public String getSnowCostCenter() {
		return snowCostCenter;
	}

	public void setSnowCostCenter(String snowCostCenter) {
		this.snowCostCenter = snowCostCenter;
	}

	public String getSnowDefaultAssignee() {
		return snowDefaultAssignee;
	}

	public void setSnowDefaultAssignee(String snowDefaultAssignee) {
		this.snowDefaultAssignee = snowDefaultAssignee;
	}

	public String getSnowDescription() {
		return snowDescription;
	}

	public void setSnowDescription(String snowDescription) {
		this.snowDescription = snowDescription;
	}

	public String getSnowEmail() {
		return snowEmail;
	}

	public void setSnowEmail(String snowEmail) {
		this.snowEmail = snowEmail;
	}

	public String getSnowExcludeManager() {
		return snowExcludeManager;
	}

	public void setSnowExcludeManager(String snowExcludeManager) {
		this.snowExcludeManager = snowExcludeManager;
	}

	public String getSnowHourlyRate() {
		return snowHourlyRate;
	}

	public void setSnowHourlyRate(String snowHourlyRate) {
		this.snowHourlyRate = snowHourlyRate;
	}

	public String getSnowIncludeMembers() {
		return snowIncludeMembers;
	}

	public void setSnowIncludeMembers(String snowIncludeMembers) {
		this.snowIncludeMembers = snowIncludeMembers;
	}

	public String getSnowManager() {
		return snowManager;
	}

	public void setSnowManager(String snowManager) {
		this.snowManager = snowManager;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowParent() {
		return snowParent;
	}

	public void setSnowParent(String snowParent) {
		this.snowParent = snowParent;
	}

	public String getSnowPoints() {
		return snowPoints;
	}

	public void setSnowPoints(String snowPoints) {
		this.snowPoints = snowPoints;
	}

	public String getSnowSource() {
		return snowSource;
	}

	public void setSnowSource(String snowSource) {
		this.snowSource = snowSource;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowType() {
		return snowType;
	}

	public void setSnowType(String snowType) {
		this.snowType = snowType;
	}

	public String getSnowU_ChangeRequest() {
		return snowU_ChangeRequest;
	}

	public void setSnowU_ChangeRequest(String snowU_ChangeRequest) {
		this.snowU_ChangeRequest = snowU_ChangeRequest;
	}

	public String getSnowU_Country() {
		return snowU_Country;
	}

	public void setSnowU_Country(String snowU_Country) {
		this.snowU_Country = snowU_Country;
	}

	public String getSnowU_CountryDeptLevel() {
		return snowU_CountryDeptLevel;
	}

	public void setSnowU_CountryDeptLevel(String snowU_CountryDeptLevel) {
		this.snowU_CountryDeptLevel = snowU_CountryDeptLevel;
	}

	public String getSnowU_DeliverTower() {
		return snowU_DeliverTower;
	}

	public void setSnowU_DeliverTower(String snowU_DeliverTower) {
		this.snowU_DeliverTower = snowU_DeliverTower;
	}

	public String getSnowU_Demand() {
		return snowU_Demand;
	}

	public void setSnowU_Demand(String snowU_Demand) {
		this.snowU_Demand = snowU_Demand;
	}

	public String getSnowU_Director() {
		return snowU_Director;
	}

	public void setSnowU_Director(String snowU_Director) {
		this.snowU_Director = snowU_Director;
	}

	public String getSnowU_FedexAndTntShared() {
		return snowU_FedexAndTntShared;
	}

	public void setSnowU_FedexAndTntShared(String snowU_FedexAndTntShared) {
		this.snowU_FedexAndTntShared = snowU_FedexAndTntShared;
	}

	public String getSnowU_Folder() {
		return snowU_Folder;
	}

	public void setSnowU_Folder(String snowU_Folder) {
		this.snowU_Folder = snowU_Folder;
	}

	public String getSnowU_FunctionalSubcategory() {
		return snowU_FunctionalSubcategory;
	}

	public void setSnowU_FunctionalSubcategory(String snowU_FunctionalSubcategory) {
		this.snowU_FunctionalSubcategory = snowU_FunctionalSubcategory;
	}

	public String getSnowU_HistName() {
		return snowU_HistName;
	}

	public void setSnowU_HistName(String snowU_HistName) {
		this.snowU_HistName = snowU_HistName;
	}

	public String getSnowU_HistQm() {
		return snowU_HistQm;
	}

	public void setSnowU_HistQm(String snowU_HistQm) {
		this.snowU_HistQm = snowU_HistQm;
	}

	public String getSnowU_HistQmRepLevel2() {
		return snowU_HistQmRepLevel2;
	}

	public void setSnowU_HistQmRepLevel2(String snowU_HistQmRepLevel2) {
		this.snowU_HistQmRepLevel2 = snowU_HistQmRepLevel2;
	}

	public String getSnowU_HistQmRepLevel3() {
		return snowU_HistQmRepLevel3;
	}

	public void setSnowU_HistQmRepLevel3(String snowU_HistQmRepLevel3) {
		this.snowU_HistQmRepLevel3 = snowU_HistQmRepLevel3;
	}

	public String getSnowU_HistQmRepLevel4() {
		return snowU_HistQmRepLevel4;
	}

	public void setSnowU_HistQmRepLevel4(String snowU_HistQmRepLevel4) {
		this.snowU_HistQmRepLevel4 = snowU_HistQmRepLevel4;
	}

	public String getSnowU_HistQmRepLevel5() {
		return snowU_HistQmRepLevel5;
	}

	public void setSnowU_HistQmRepLevel5(String snowU_HistQmRepLevel5) {
		this.snowU_HistQmRepLevel5 = snowU_HistQmRepLevel5;
	}

	public String getSnowU_HistRepLevel2() {
		return snowU_HistRepLevel2;
	}

	public void setSnowU_HistRepLevel2(String snowU_HistRepLevel2) {
		this.snowU_HistRepLevel2 = snowU_HistRepLevel2;
	}

	public String getSnowU_HistRepLevel3() {
		return snowU_HistRepLevel3;
	}

	public void setSnowU_HistRepLevel3(String snowU_HistRepLevel3) {
		this.snowU_HistRepLevel3 = snowU_HistRepLevel3;
	}

	public String getSnowU_HistRepLevel4() {
		return snowU_HistRepLevel4;
	}

	public void setSnowU_HistRepLevel4(String snowU_HistRepLevel4) {
		this.snowU_HistRepLevel4 = snowU_HistRepLevel4;
	}

	public String getSnowU_HistRepLevel5() {
		return snowU_HistRepLevel5;
	}

	public void setSnowU_HistRepLevel5(String snowU_HistRepLevel5) {
		this.snowU_HistRepLevel5 = snowU_HistRepLevel5;
	}

	public String getSnowU_HistSearchode() {
		return snowU_HistSearchode;
	}

	public void setSnowU_HistSearchode(String snowU_HistSearchode) {
		this.snowU_HistSearchode = snowU_HistSearchode;
	}

	public String getSnowU_Incident() {
		return snowU_Incident;
	}

	public void setSnowU_Incident(String snowU_Incident) {
		this.snowU_Incident = snowU_Incident;
	}

	public String getSnowU_LocalHelpdesk() {
		return snowU_LocalHelpdesk;
	}

	public void setSnowU_LocalHelpdesk(String snowU_LocalHelpdesk) {
		this.snowU_LocalHelpdesk = snowU_LocalHelpdesk;
	}

	public String getSnowU_MailAutoclosure() {
		return snowU_MailAutoclosure;
	}

	public void setSnowU_MailAutoclosure(String snowU_MailAutoclosure) {
		this.snowU_MailAutoclosure = snowU_MailAutoclosure;
	}

	public String getSnowU_NoAssignment() {
		return snowU_NoAssignment;
	}

	public void setSnowU_NoAssignment(String snowU_NoAssignment) {
		this.snowU_NoAssignment = snowU_NoAssignment;
	}

	public String getSnowU_NotMeasured() {
		return snowU_NotMeasured;
	}

	public void setSnowU_NotMeasured(String snowU_NotMeasured) {
		this.snowU_NotMeasured = snowU_NotMeasured;
	}

	public String getSnowU_OrganisationCategory() {
		return snowU_OrganisationCategory;
	}

	public void setSnowU_OrganisationCategory(String snowU_OrganisationCategory) {
		this.snowU_OrganisationCategory = snowU_OrganisationCategory;
	}

	public String getSnowU_OutsourceIntegration() {
		return snowU_OutsourceIntegration;
	}

	public void setSnowU_OutsourceIntegration(String snowU_OutsourceIntegration) {
		this.snowU_OutsourceIntegration = snowU_OutsourceIntegration;
	}

	public String getSnowU_Problem() {
		return snowU_Problem;
	}

	public void setSnowU_Problem(String snowU_Problem) {
		this.snowU_Problem = snowU_Problem;
	}

	public String getSnowU_RegionalLevel() {
		return snowU_RegionalLevel;
	}

	public void setSnowU_RegionalLevel(String snowU_RegionalLevel) {
		this.snowU_RegionalLevel = snowU_RegionalLevel;
	}

	public String getSnowU_ReportingLevel1() {
		return snowU_ReportingLevel1;
	}

	public void setSnowU_ReportingLevel1(String snowU_ReportingLevel1) {
		this.snowU_ReportingLevel1 = snowU_ReportingLevel1;
	}

	public String getSnowU_ReportingLevel2() {
		return snowU_ReportingLevel2;
	}

	public void setSnowU_ReportingLevel2(String snowU_ReportingLevel2) {
		this.snowU_ReportingLevel2 = snowU_ReportingLevel2;
	}

	public String getSnowU_ReportingLevel3() {
		return snowU_ReportingLevel3;
	}

	public void setSnowU_ReportingLevel3(String snowU_ReportingLevel3) {
		this.snowU_ReportingLevel3 = snowU_ReportingLevel3;
	}

	public String getSnowU_ReportingLevel4() {
		return snowU_ReportingLevel4;
	}

	public void setSnowU_ReportingLevel4(String snowU_ReportingLevel4) {
		this.snowU_ReportingLevel4 = snowU_ReportingLevel4;
	}

	public String getSnowU_ReportingLevel5() {
		return snowU_ReportingLevel5;
	}

	public void setSnowU_ReportingLevel5(String snowU_ReportingLevel5) {
		this.snowU_ReportingLevel5 = snowU_ReportingLevel5;
	}

	public String getSnowU_Request() {
		return snowU_Request;
	}

	public void setSnowU_Request(String snowU_Request) {
		this.snowU_Request = snowU_Request;
	}

	public String getSnowU_SearchCode() {
		return snowU_SearchCode;
	}

	public void setSnowU_SearchCode(String snowU_SearchCode) {
		this.snowU_SearchCode = snowU_SearchCode;
	}

	public String getSnowU_WorkgroupLevel() {
		return snowU_WorkgroupLevel;
	}

	public void setSnowU_WorkgroupLevel(String snowU_WorkgroupLevel) {
		this.snowU_WorkgroupLevel = snowU_WorkgroupLevel;
	}

	public String getSnowU_WorkgroupRole() {
		return snowU_WorkgroupRole;
	}

	public void setSnowU_WorkgroupRole(String snowU_WorkgroupRole) {
		this.snowU_WorkgroupRole = snowU_WorkgroupRole;
	}
	
}
