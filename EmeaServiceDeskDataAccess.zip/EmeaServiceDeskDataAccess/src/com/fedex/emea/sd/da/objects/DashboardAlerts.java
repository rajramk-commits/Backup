package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.sql.Timestamp;

import com.fedex.emea.sd.da.helpers.Constants;

public class DashboardAlerts implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String alertType;
	private String impactedServer;
	private String impactedComponent;
	private String impactedApplication;
	private String impactedModule;
	private String alertMessage;
	private String alertAction;
	private String alertId;
	private Timestamp creationTime;
	private String nexusCaseId;
	private String niAlertId;
	private String nexusCaseDescription;
	
	public DashboardAlerts() {
	}
	
	public DashboardAlerts(String alertId, String impactedServer, String impactedComponent, String impactedApplication, String impactedModule, Timestamp creationTime, String nexusCaseId, String niAlertId) {
		this.setAlertId(alertId);
		this.setImpactedServer(impactedServer);
		this.setImpactedComponent(impactedComponent);
		this.setImpactedApplication(impactedApplication);
		this.setImpactedModule(impactedModule);
		this.setCreationTime(creationTime);
		this.setNexusCaseId(nexusCaseId);
		this.setNiAlertId(niAlertId);
	}
	
	public DashboardAlerts(String alertType, String impactedServer, String impactedComponent, String impactedApplication, String impactedModule, String alertMessage, String alertAction) {
		this.setAlertType(alertType);
		this.setImpactedServer(impactedServer);
		this.setImpactedComponent(impactedComponent);
		this.setImpactedApplication(impactedApplication);
		this.setImpactedModule(impactedModule);
		this.setAlertMessage(alertMessage);
		this.setAlertAction(alertAction);
	}
	
	public DashboardAlerts(String caseDescription) {
		this.setAlertType(getContentInBrackets(caseDescription, Constants.ALERT_TYPE));
		this.setImpactedServer(getContentInBrackets(caseDescription, Constants.IMPACTED_SERVER));
		this.setImpactedComponent(getContentInBrackets(caseDescription, Constants.IMPACTED_COMPONENT));
		this.setImpactedApplication(getContentInBrackets(caseDescription, Constants.IMPACTED_APPLICATION));
		this.setImpactedModule(getContentInBrackets(caseDescription, Constants.IMPACTED_MODULE));
		this.setAlertMessage(getContentInBrackets(caseDescription, Constants.ALERT_MESSAGE));
		this.setAlertAction(getContentInBrackets(caseDescription, Constants.ALERT_ACTION));
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public String getImpactedServer() {
		return impactedServer;
	}

	public void setImpactedServer(String impactedServer) {
		this.impactedServer = impactedServer;
	}

	public String getImpactedComponent() {
		return impactedComponent;
	}

	public void setImpactedComponent(String impactedComponent) {
		this.impactedComponent = impactedComponent;
	}

	public String getImpactedApplication() {
		return impactedApplication;
	}

	public void setImpactedApplication(String impactedApplication) {
		this.impactedApplication = impactedApplication;
	}

	public String getImpactedModule() {
		return impactedModule;
	}

	public void setImpactedModule(String impactedModule) {
		this.impactedModule = impactedModule;
	}

	public String getAlertMessage() {
		return alertMessage;
	}

	public void setAlertMessage(String alertMessage) {
		this.alertMessage = alertMessage;
	}

	public String getAlertAction() {
		return alertAction;
	}

	public void setAlertAction(String alertAction) {
		this.alertAction = alertAction;
	}
	
	private String getContentInBrackets(String message, String parameter) {
		String content = "";
		String toSearch = parameter + "[";
		int toSearchLength = toSearch.length();
		int posToSearch = message.indexOf(toSearch);
		int startPos = posToSearch + toSearchLength;
		
		int bracketCount = 1;
		char charAtPos;
		while (bracketCount > 0) {
			charAtPos = message.charAt(startPos);
			if (charAtPos == '[') bracketCount++;
			if (charAtPos == ']') bracketCount--;
			if (bracketCount > 0) {
				content = content + charAtPos;
			}
			startPos++;
		}
		
		return content;
	}

	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getNexusCaseId() {
		return nexusCaseId;
	}

	public void setNexusCaseId(String nexusCaseId) {
		this.nexusCaseId = nexusCaseId;
	}

	public String getNiAlertId() {
		return niAlertId;
	}

	public void setNiAlertId(String niAlertId) {
		this.niAlertId = niAlertId;
	}

	public String getNexusCaseDescription() {
		StringBuffer fullDescription = new StringBuffer();
		fullDescription.append("Server: " + this.getImpactedServer() + System.getProperty("line.separator"));
		fullDescription.append("Component: " + this.getImpactedComponent() + System.getProperty("line.separator"));
		fullDescription.append("Application: " + this.getImpactedApplication() + System.getProperty("line.separator"));
		fullDescription.append("Module: " + this.getImpactedModule() + System.getProperty("line.separator"));
		fullDescription.append("Message: " + this.getAlertMessage() + System.getProperty("line.separator"));
		fullDescription.append("Action: " + this.getAlertAction() + System.getProperty("line.separator"));
		nexusCaseDescription = fullDescription.toString();
		
		return nexusCaseDescription;
	}

	public void setNexusCaseDescription(String nexusCaseDescription) {
		this.nexusCaseDescription = nexusCaseDescription;
	}
	
}
