package com.fedex.emea.dimm.log;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ApplicationLogger implements LoggingInterface {
	
	private Logger LogDebug = LogManager.getLogger("DIMM_DebugLogger");
	private Logger LogInfo = LogManager.getLogger("DIMM_InfoLogger");
	private Logger LogError = LogManager.getLogger("DIMM_ErrorLogger");
	private Logger LogFatal = LogManager.getLogger("DIMM_FatalLogger");
	

	@Override
	public void logInfo(String message) {
		LogInfo.info(message);
	}

	@Override
	public void logDebug(String message) {
		LogDebug.debug(message);
	}

	@Override
	public void logError(String message) {
		LogError.error(message);
	}

	@Override
	public void logException(String message, Exception e) {
		LogError.error(message, e);
	}
	
	@Override
	public void logFatal(String message) {
		LogFatal.fatal(message);
	}

}
