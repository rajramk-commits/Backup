package com.fedex.emea.dimm.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class CipherUtils {

	public static byte[] getCiphyerKey() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMdd-HHmmss");
	    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
	    return sdf.format(new Date(0)).getBytes();
	}
	
	public static synchronized String decrypt(String strToDecrypt) throws Exception {
		Cipher cipher = Cipher.getInstance("AES");
		SecretKey aesKey = new SecretKeySpec(getCiphyerKey(), "AES");
		cipher.init(Cipher.DECRYPT_MODE, aesKey);
		BASE64Decoder base64decoder = new BASE64Decoder();
		String decryptedString = new String(cipher.doFinal(base64decoder.decodeBuffer(strToDecrypt)));
		return decryptedString;
	}
	
	public static synchronized String encrypt(String strToEncrypt) throws Exception {
		Cipher cipher = Cipher.getInstance("AES");
		SecretKey aesKey = new SecretKeySpec(CipherUtils.getCiphyerKey(), "AES");
		cipher.init(Cipher.ENCRYPT_MODE, aesKey);
		BASE64Encoder base64encoder = new BASE64Encoder();
		String encryptedString = base64encoder.encodeBuffer(cipher.doFinal(strToEncrypt.getBytes()));
		return encryptedString;
	}

}
