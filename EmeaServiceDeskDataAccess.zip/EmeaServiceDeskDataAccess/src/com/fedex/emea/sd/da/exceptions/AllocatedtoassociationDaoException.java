package com.fedex.emea.sd.da.exceptions;

public class AllocatedtoassociationDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6402512047493258446L;

	/**
	 * Method 'AllocatedtoassociationDaoException'
	 * 
	 * @param message
	 */
	public AllocatedtoassociationDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'AllocatedtoassociationDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public AllocatedtoassociationDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
