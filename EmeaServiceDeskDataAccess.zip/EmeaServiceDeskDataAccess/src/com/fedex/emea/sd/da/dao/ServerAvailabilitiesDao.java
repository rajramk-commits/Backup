package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import com.fedex.emea.sd.da.objects.ServerAvailabilities;

public interface ServerAvailabilitiesDao {
	public ServerAvailabilities createValueObject();
	public ServerAvailabilities getServerAvailability(String serverName) throws SQLException;
	public ServerAvailabilities getServerLastAvailability(String serverName) throws SQLException;
	public void updateServerAvailability(ServerAvailabilities valueObject, Timestamp oldCheckTime)	throws SQLException;
	public List<ServerAvailabilities> loadServerAvailabilitiesByDataCenter(String dataCenter) throws SQLException;
	public List<ServerAvailabilities> loadAvailableServers() throws SQLException;
	public List<ServerAvailabilities> loadUnavailableServers() throws SQLException;
	public void create(ServerAvailabilities valueObject) throws SQLException;
}
