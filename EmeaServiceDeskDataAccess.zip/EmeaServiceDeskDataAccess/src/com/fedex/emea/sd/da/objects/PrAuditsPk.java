package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_AUDITS table.
 */
public class PrAuditsPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4895621966527470965L;

	protected String cy;

	protected String symEaiId;

	protected String ni2AppId;

	/** 
	 * Sets the value of cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/** 
	 * Gets the value of cy
	 */
	public String getCy()
	{
		return cy;
	}

	/** 
	 * Sets the value of symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/** 
	 * Gets the value of symEaiId
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/** 
	 * Sets the value of ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/** 
	 * Gets the value of ni2AppId
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'PrAuditsPk'
	 * 
	 */
	public PrAuditsPk()
	{
	}

	/**
	 * Method 'PrAuditsPk'
	 * 
	 * @param cy
	 * @param symEaiId
	 * @param ni2AppId
	 */
	public PrAuditsPk(final String cy, final String symEaiId, final String ni2AppId)
	{
		this.cy = cy;
		this.symEaiId = symEaiId;
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrAuditsPk)) {
			return false;
		}
		
		final PrAuditsPk _cast = (PrAuditsPk) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrAuditsPk: " );
		ret.append( "cy=" + cy );
		ret.append( ", symEaiId=" + symEaiId );
		ret.append( ", ni2AppId=" + ni2AppId );
		return ret.toString();
	}

}
