<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="java.io.*"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<script type="text/javascript" language="javascript">
function openLoginMenu() {
	window.close("Results.jsp");
	window.open("Admin.jsp");
}
</script>
<style>
.main{
	margin-left:10%;
	margin-right:12%;
	
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
	}
.logout{
float:right;
margin-right:5%;
background-color:#FF8C00;
color:white;
padding:14px 20px;
border:none;
cursor:pointer;
}
.logout:hover{
background-color:#4B0060;
}
.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

</style>
<title>SD Evaluation</title>
</head>
<body style="background-color:#BEBEBE;">
<form name="ViewForm">
<div class="main">
<%     	
		
        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		String userID = (String) session.getAttribute("sessionName");
		//out.println("Welcome : "+userID);
        %>
        <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Results View Page</p></center>
   		</div>
        
      <%--   <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form> --%>
        <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div> 
        <button class="home" onclick="openLoginMenu()">HOME</button><br><br><br>
	<%
		try {
			 String dirName = "C:/Users/rahul.raj/Documents/finaaal/Resources/";

		     //String dirName = "/opt/automationtools/Deployments/resources/";
			String fileName = dirName;
			boolean fileFound = false;
			File directoryPath = new File(dirName);
			String contents[] = directoryPath.list();
			String uId = request.getParameter("id");
			String team = request.getParameter("team");
			String attempt = request.getParameter("attempt");
			%>
				<input type="hidden" name="uId" value="<%=uId%>">
				<input type="hidden" name="team" value="<%=team%>">
				<input type="hidden" name="attempt" value="<%=attempt%>">
			<%
			for(int i=0; i<contents.length; i++) {
		         System.out.println(contents[i]);
		         System.out.println("uId"+uId);
		         
		         if(uId != null && contents[i].contains(uId) && contents[i].contains(team) && contents[i].contains("_"+attempt))
		         {
		        	 fileName+= contents[i];
		        	 fileFound = true;
		        	 break;
		         }
		      }
			
			System.out.println("fileName :"+fileName);
			
			if(fileFound)
			{
				File file = new File(fileName);
				BufferedReader br = new BufferedReader(new FileReader(file));
				String st;
				int count = 0;
				while ((st = br.readLine()) != null)
				{
					if(count < 4)
					{
						++count;
						%>
						<label style="font-size: x-large;font-family: sans-serif; color:purple;"><b><%=st %></b></label><br>
						<% 
						continue;
					}
					if(st.startsWith("User Answer"))
					{%>
					<br><label style="font-size:medium; font-family: sans-serif; color: red;"><%=st %></label><br>
					<% 
					}
					else if(st.endsWith("Questions"))
					{%>
					<label style="font-size: x-large;font-family: sans-serif; color: black;"><b><%=st %></b></label><br>
					<% 
					}
					else if(st.contains("Marks Obtained"))
					{%>
					<label style="font-size: medium;font-family: sans-serif; color: blue;"><b><%=st %></b></label><br>
					<% 
					}
					else if(st.contains("Result"))
					{
						if(st.contains("PASS"))
						{
							%>
							<label style="font-size: large;font-family: sans-serif; color: green;"><b><%=st %></b></label><br>
							<%
						}
						if(st.contains("FAIL"))
						{
							%>
							<label style="font-size: large;font-family: sans-serif; color: red;"><b><%=st %></b></label><br>
							<%
						}
					}
					else if(st.contains("Correct"))
					{
						%>
						<label style="font-size: medium;font-family: sans-serif; color: green;"><b><%=st %></b></label><br>
						<%
					}
					else if(st.contains("Wrong"))
					{
						%>
						<label style="font-size: medium;font-family: sans-serif; color: red;"><b><%=st %></b></label><br>
						<%
					}
					
					else if(st.contains("Weightage"))
					{%>
					<label style="font-size: large;font-family: sans-serif; color: brown;"><b><%=st %></b></label><br>
					<% 
					}
					else if (st.contains("Total"))
					{
					%>
					<br>
					<label style="font-size: large;font-family: sans-serif; color: black;"><b><%=st %></b></label><br>
					<%}
					else
					{
						%>
						<label style="font-size:medium; font-family: sans-serif; color: black;"><%=st %></label><br>
						<% 
					}
				}
				br.close();
		 	}
			else{
				%>
					<label>No data found for the user : <%=uId %></label>
				<%
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	%>
	<br><br>
	</div>
		<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</form>
</body>
</html>
