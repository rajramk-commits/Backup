package com.fedex.emea.dimm.app;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.AlertDomainAdaptorFactory;
import com.fedex.emea.dimm.adaptor.LogicalKeySeedEntry;
import com.fedex.emea.dimm.alert.AbstractAlert;
import com.fedex.emea.dimm.alert.LogicalAlert;
import com.fedex.emea.dimm.alert.PhysicalAlert;
import com.fedex.emea.dimm.utils.MailService;
import com.fedex.emea.dimm.utils.Utilities;

public class DIMMApplication {
	
	private static final Logger log = LogManager.getLogger(DIMMApplication.class);
	
	private DIMMAppConfig config;
	
	private DIMMDao dao;
	
	private MailService mailService;
	
	private AlertDomainAdaptorFactory adaptorFactory;
	
	private AbstractAlertDomainAdaptor adaptor;
	
	public void init() throws Exception{
		//LogFactory.initialize(new DefaultLogger());
		//LogFactory.getLogger().logInfo("Initializing the application...");
		log.info("Begining of init()--Initializing the application...");
		
		config = new DIMMAppConfig();
		
		dao = new DIMMDao(config.getMonitorAlertStagingDbConfig(), config.getAntcDbConfig(), config.getNexusDbConfig());
		
		mailService = new MailService(config.getMailConfig());
		
		adaptorFactory = AlertDomainAdaptorFactory.getInstance();
		
		Thread workThread = new Thread(){
			@Override
			public void run() {
				adaptAlerts();
			}
		};
		
		//finally add the shut-down hook
		Runtime.getRuntime().addShutdownHook(new Thread(){
			@Override
			public void run() {
				onShutdown();
			}
		});
		
		workThread.start();
		
		while(true){
			try{
				Thread.sleep(60*60*1000);
			}catch(Exception e){}
		}
	}
	
	private void onShutdown(){
		mailService.sendMailNotification(null, null, "DIMM Module stopped","DIMM module has been stopped. Please make a check");
	}
	
	private AbstractAlertDomainAdaptor getFirstHighestPriorityApplicableActiveAdaptor(PhysicalAlert pa){
		TreeMap<Integer, Set<AbstractAlertDomainAdaptor>>  adaptors = adaptorFactory.getAdaptors();
		Iterator<Integer> pI = adaptors.keySet().iterator();//tree map guarantees the order is ascending, the lower the number is, the higher the priority is
		while(pI.hasNext()){
			int priority = pI.next();
			Set<AbstractAlertDomainAdaptor> onePriorityAdaptors = adaptors.get(priority);
			for(AbstractAlertDomainAdaptor adaptor:onePriorityAdaptors){
				if(adaptor.getConfig().isAdaptorActive() && adaptor.isApplicable(pa)){
					return adaptor;
				}
			}
		}
		return null;
	}
	
	private PhysicalAlert populatePhysicalAlertValues(PhysicalAlert pa) {
		
		StringBuilder caseDesc = new StringBuilder();
		caseDesc.append(pa.getCaseDescription1());
		caseDesc.append(pa.getCaseDescription2());
		caseDesc.append(pa.getCaseDescription3());
		caseDesc.append(pa.getCaseDescription4());
		caseDesc.append(pa.getCaseDescription5());
		caseDesc.append(pa.getCaseDescription6());
		caseDesc.append(pa.getCaseDescription7());
		caseDesc.append(pa.getCaseDescription8());
		caseDesc.append(pa.getCaseDescription9());
		
		String[] caseDescArray = caseDesc.toString().split("] ");
		
		for (String token :caseDescArray) {
			
			if(token.contains("Server[")) {
				pa.setServer(token.substring(7, token.length()));
			} else if(token.contains("Component[")) {
				pa.setComponent(token.substring(10, token.length()));
			} else if(token.contains("Application[")) {
				pa.setApplication(token.substring(12, token.length()));
			} else if(token.contains("Module[")) {
				pa.setModule(token.substring(7, token.length()));
			}
		}
			
		return pa;
	}
	



	
	private void adaptAlerts(){
		log.info("Begining of adaptAlerts()");
		do{
			List<PhysicalAlert> updateLogicalKeyForPhysicalAlertList = new ArrayList<PhysicalAlert>();
			List<LogicalAlert> insertLogicalAlertIntoANTCIfAbsentList = new ArrayList<LogicalAlert>();
			Map<String, String> logicalKeyCaseIdMap = new HashMap<String, String>();
			Map<String, String> logicalKeyCaseIdMapForAddNote = new HashMap<String, String>();
			Set<String> logicalKeysForCaseNumbers = new HashSet<String>();
			Set<String> logicalKeysForCaseNumbersForAddNote = new HashSet<String>();
			Set<String>logicalKeysForCasenumupdate = new HashSet<String>();
			List<PhysicalAlert> updateNexusCaseNumberForPhysicalAlertList = new ArrayList<PhysicalAlert>();
			List<AbstractAlert> logicalAlertListForAddNote = new ArrayList<AbstractAlert>();
			Map<String, List<PhysicalAlert>> tempAddNoteMap = new HashMap<String, List<PhysicalAlert>>();
			List<PhysicalAlert> physicalAlertsForAddNote = null;
			//For Component_3
			List<PhysicalAlert> physicalAlertListForComponent3 = null;
			List<LogicalAlert> logicalAlertListForComponent3 = null;
			Map<String, List<LogicalAlert>> logicalAlertMapForComponent3 = new HashMap<String, List<LogicalAlert>>();
			Map<String, List<PhysicalAlert>> physicalAlertMapForComponent3 = new HashMap<String, List<PhysicalAlert>>();
			//For ANTC is down
			Set<String> logicalKeysIfANTCDown = new HashSet<String>();
			/* Logical key can be duplicate for NO_MSG_CONSUME or ABOVE_CRITICAL_LEVEL. 
			   That is the reason case status is required to get only one case number from ANTC. */
			
			List<String> logicalkeyforstatuscheck = new ArrayList<String>();
			
			
			Collection<PhysicalAlert> physicalAlerts = dao.getAllPhysicalAlertsWithoutNexusCaseNumber();
			if(physicalAlerts!=null && !physicalAlerts.isEmpty()){
				//to calculate logicalkey for new alerts
				log.info("Calculating logicalkey for new alerts:" +physicalAlerts.size());
				for(PhysicalAlert pa:physicalAlerts){
					pa = populatePhysicalAlertValues(pa);
					String logicalKey = pa.getLogicalKey();
					adaptor = getFirstHighestPriorityApplicableActiveAdaptor(pa);
					if(logicalKey==null || logicalKey.trim().length()==0){//the logical key has not been assigned to the physical alert yet
						//adaptor = getFirstHighestPriorityApplicableActiveAdaptor(pa);
						if(adaptor!=null){
							LogicalKeySeedEntry logicalKeySeedEntry = adaptor.getLogicalSeedKeyEntry();
							boolean recreateLogicalKeyEntry;
							if(logicalKeySeedEntry==null)
								recreateLogicalKeyEntry=true;
							else{//logical key entry already exist
								int logicalKeyTtlMinute = adaptor.getConfig().getAdaptorLogicalKeyTtlMinute();
								if(logicalKeyTtlMinute<0){
									recreateLogicalKeyEntry = false;
								}else{
									Date lastCreateTime = logicalKeySeedEntry.getLastCreateTime();
									Date currentTime = Calendar.getInstance().getTime();
									if(currentTime.getTime()-lastCreateTime.getTime()>logicalKeyTtlMinute*60*1000){
										recreateLogicalKeyEntry = true;
									}else
										recreateLogicalKeyEntry = false;
								}
							}
							
							if(recreateLogicalKeyEntry){
								String newLogicalKey = dao.getNextAvailableLogicalKey();
								adaptor.setLogicalSeedKeyEntry(new LogicalKeySeedEntry(newLogicalKey,Calendar.getInstance().getTime()));
							}
							
							LogicalAlert la = adaptor.adaptPhysicalAlertToLogicalAlert(pa);
						
							logicalkeyforstatuscheck.add(la.getLogicalKey());
							pa.setLogicalKey(la.getLogicalKey());
							
							
							
						//For Component 1 and 2
							if(!Utilities.getOvoServerComponents().contains(pa.getComponent())) {
								updateLogicalKeyForPhysicalAlertList.add(pa);
								insertLogicalAlertIntoANTCIfAbsentList.add(la);
							//}
							}
						}
					}else{//the logical key has been assigned to the physical alert during previous adaptation round
						
						if(!Utilities.getOvoServerComponents().contains(pa.getComponent())) {
							
							logicalKeysForCaseNumbers.add(logicalKey);
						
							
							updateNexusCaseNumberForPhysicalAlertList.add(pa);
							
							if(tempAddNoteMap.containsKey(logicalKey)) {
								physicalAlertsForAddNote = tempAddNoteMap.get(logicalKey);
								physicalAlertsForAddNote.add(pa);
							} else {
								physicalAlertsForAddNote = new ArrayList<PhysicalAlert>();
								physicalAlertsForAddNote.add(pa);
							}
							
							tempAddNoteMap.put(logicalKey, physicalAlertsForAddNote);
						}
					}
										
					if(Utilities.getOvoServerComponents().contains(pa.getComponent())) {
						LogicalAlert la = adaptor.adaptPhysicalAlertToLogicalAlert(pa);
						if(physicalAlertMapForComponent3.containsKey(pa.getServer())) {
							physicalAlertListForComponent3 = physicalAlertMapForComponent3.get(pa.getServer());
							physicalAlertListForComponent3.add(pa);
							logicalAlertListForComponent3 = logicalAlertMapForComponent3.get(la.getServer());
							logicalAlertListForComponent3.add(la);
						} else {
							physicalAlertListForComponent3 = new ArrayList<PhysicalAlert>();
							physicalAlertListForComponent3.add(pa);
							logicalAlertListForComponent3 = new ArrayList<LogicalAlert>();
							logicalAlertListForComponent3.add(la);
						}
						physicalAlertMapForComponent3.put(pa.getServer(), physicalAlertListForComponent3);
						logicalAlertMapForComponent3.put(la.getServer(), logicalAlertListForComponent3);
					}
				}
			
		// update casestatus to RESOL if case is closed in SNOW
		if(logicalkeyforstatuscheck.size()>0)
		{
			//System.out.println("logicalkey for status check"+logicalkeyforstatuscheck);
				List<String> openCases = dao.getOpenCasesFromDIMM(logicalkeyforstatuscheck);
				//System.out.println("opencase in DIMM:"+openCases);
				if(openCases.size()>0)
				{ List<String> caseIdClosedList= new ArrayList<>();
					try{
					caseIdClosedList = dao.getClosedCasesFromSnow(openCases);
					}
					catch(Exception exception) {
						//LogFactory.getLogger().logException("Error: ",exception);k
						log.error("Unexpected error:: ", exception);
						try{
							log.info("Sleep for 30 seconds");
							Thread.sleep(30000);//if no data, wait for 30 seconds
							adaptAlerts();
						}catch(Exception e){
							//LogFactory.getLogger().logException("Error: ",exception);
							log.error("Unexpected error:: ", e);
						}
					} finally {
						log.info("closed cases in snow found  : "+caseIdClosedList.size());
					
					}
					if(caseIdClosedList.size()>0)
					{//System.out.println("closed cases"+ caseIdClosedList);
						dao.updateCaseStatusIfClosedToDIMM(caseIdClosedList);
					}
					
				}
				
		}
			
		// update casestatus to RESOL if alertprocessed in EXTERNAL_INTERFACE is 9
		if(logicalkeyforstatuscheck.size()>0)
		{
			//System.out.println("logicalkey for status check"+logicalkeyforstatuscheck);
				List<String> openCases = dao.getOpenAlertsRecordSourceIdFromDIMM(logicalkeyforstatuscheck);
				//System.out.println("opencase in DIMM:"+openCases);
				if(openCases.size()>0)
				{ 
				 dao.upadteCaseStatusifLogicalkeyForUnprocessedAlert(openCases);
				
					}
				}
				
		
		
				
				
				
				//Batch update
				//For Component_3
				if(physicalAlertMapForComponent3.size() > 0) {
					List<PhysicalAlert> tempPhysicalAlertListForComponent3 = new ArrayList<PhysicalAlert>();
					for(String serverName :physicalAlertMapForComponent3.keySet()) {
			
						physicalAlertListForComponent3 = physicalAlertMapForComponent3.get(serverName);
						logicalAlertListForComponent3 = logicalAlertMapForComponent3.get(serverName);
												
						for(PhysicalAlert pAlert :physicalAlertListForComponent3) {
							
							pAlert.setLogicalKey("ReferenceAlert");
						
							tempPhysicalAlertListForComponent3.add(pAlert);
						}
						//add logcalkey for alert in DIMM
						dao.updateLogicalKeyForPhysicalAlert(tempPhysicalAlertListForComponent3);
						
						
					}
					
					physicalAlertListForComponent3.clear();
					logicalAlertListForComponent3.clear();
					logicalAlertMapForComponent3.clear();
					physicalAlertMapForComponent3.clear();
					tempPhysicalAlertListForComponent3.clear();
				}
				
				if(updateLogicalKeyForPhysicalAlertList.size() > 0) {
					dao.updateLogicalKeyForPhysicalAlert(updateLogicalKeyForPhysicalAlertList);
					//updateLogicalKeyForPhysicalAlertList.clear();
				}
		}
			

			
			
				
				List<AbstractAlert> physicalAlerts1 = dao.getAllPhysicalAlertsWithoutNexusCaseNumberandwithlogicalkey();
				if(physicalAlerts1!=null && !physicalAlerts1.isEmpty()){
					dao.updateAlertPreoessedforaddnote();
					List<AbstractAlert> physicalAlerttonewcase =dao.getAllPhysicalAlertsforNewCaseCreation();
				//System.out.println("new"+physicalAlerttonewcase.size());
				
				if(physicalAlerttonewcase.size() > 0) {
					dao.insertLogicalAlertIntoANTCIfAbsent(physicalAlerttonewcase);	
					}
				
				List<AbstractAlert> physicalAlertforcasenumupdate = dao.getAllPhysicalAlertsforCaseNumberNeedsUpdate();
				
				//System.out.println(physicalAlertforcasenumupdate.size());
				for(AbstractAlert logicalAlert: physicalAlertforcasenumupdate) {
					logicalKeysForCasenumupdate.add(logicalAlert.getRecordSourceId());
				}
				
				
				if(logicalKeysForCasenumupdate.size() > 0) {
					logicalKeyCaseIdMapForAddNote = dao.getNexusCaseNumberFromANTC(logicalKeysForCasenumupdate);
					logicalKeysForCasenumupdate.clear();
					dao.updateSNOWCaseNumberForPhysicalAlert(physicalAlertforcasenumupdate, logicalKeyCaseIdMapForAddNote);
					physicalAlertforcasenumupdate.clear();
				}
				
				
				List<AbstractAlert> physicalAlertforAddNote =dao.getAllPhysicalAlertsforAddnote();
				//System.out.println(physicalAlertforAddNote.size());
				for(AbstractAlert logicalAlert: physicalAlertforAddNote) {
					logicalKeysForCaseNumbersForAddNote.add(logicalAlert.getLogicalkey1());
				}
				
				
				
				//For ADD-NOTE
				if(logicalKeysForCaseNumbersForAddNote.size() > 0) {
					logicalKeyCaseIdMapForAddNote = dao.getNexusCaseNumberFromANTCForAddNote(logicalKeysForCaseNumbersForAddNote);
					logicalKeysForCaseNumbersForAddNote.clear();
					dao.updateSNOWCaseNumberForPhysicalAlert(physicalAlertforAddNote, logicalKeyCaseIdMapForAddNote);
					//physicalAlertforAddNote.clear();
				}
				
				for(AbstractAlert logicalAlert :physicalAlertforAddNote) {
					
					String logicalKey = logicalAlert.getLogicalkey1();
					String caseid = logicalKeyCaseIdMapForAddNote.get(logicalKey);
					if(caseid != null) {
						//logocalAlert.setDashboardName("ADD-NOTE");
						logicalAlert.setNexusCaseNumber(caseid);
						logicalAlertListForAddNote.add(logicalAlert);
					}
				}
				
				if(logicalAlertListForAddNote.size() > 0) {
					dao.insertLogicalAlertForAddNote(logicalAlertListForAddNote);
					logicalAlertListForAddNote.clear();
				}
				
				if(logicalKeysForCaseNumbers.size() > 0) {
					logicalKeyCaseIdMap = dao.getNexusCaseNumberFromANTC(logicalKeysForCaseNumbers);
					for(String logicalKey :logicalKeyCaseIdMap.keySet()) {
						if(logicalKeyCaseIdMap.get(logicalKey) == null) {
							logicalKeysIfANTCDown.add(logicalKey);
						}
						
					}
					logicalKeysForCaseNumbers.clear();
				}
				
				if(updateNexusCaseNumberForPhysicalAlertList.size() > 0) {
					dao.updateSNOWCaseNumberForPhysicalAlert(physicalAlertforAddNote, logicalKeyCaseIdMap);
					updateNexusCaseNumberForPhysicalAlertList.clear();
				}
				
				//ADD-NOTE: if DIMM receive multiple alerts at a time in first time (Ex: ITIH 22 alerts)
				for(String logicalKey :tempAddNoteMap.keySet()) {
					List<PhysicalAlert> physicalAlertList = tempAddNoteMap.get(logicalKey);
					String caseid = logicalKeyCaseIdMap.get(logicalKey);
					if(physicalAlertList.size() > 1 && caseid != null) {
						for(int i = 1; i < physicalAlertList.size(); i++) {
							LogicalAlert la = adaptor.adaptPhysicalAlertToLogicalAlert(physicalAlertList.get(i));
							la.setNexusCaseNumber(caseid);
							logicalAlertListForAddNote.add(la);
						}
					}
				}
				
				if(logicalAlertListForAddNote.size() > 0) {
					dao.insertLogicalAlertForAddNote(logicalAlertListForAddNote);
					logicalAlertListForAddNote.clear();
				}
			
		
				
				
				
				
				physicalAlerts1.clear();
				insertLogicalAlertIntoANTCIfAbsentList.clear();
				logicalKeyCaseIdMap.clear();
				logicalKeyCaseIdMapForAddNote.clear();
				tempAddNoteMap.clear();
				}	
				try{
					log.info("Sleep for 30 seconds");
					Thread.sleep(30000);//if no data, wait for 30 seconds
				}catch(Exception exception){
					//LogFactory.getLogger().logException("Error: ",exception);
					log.error("Unexpected error:: ", exception);
				}
			
		}while(true);
	}
	public static void main(String[] args){
		DIMMApplication app = new DIMMApplication();
		try{
			app.init();
		}catch(Exception exception){
			//LogFactory.getLogger().logException("Fail to initialize the application: ",exception);
			log.error("Fail to initialize the application:: ", exception);
		}
	}
	
}