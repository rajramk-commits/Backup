package com.fedex.dashboard.model;

public class DepandantAppBean {
	private String appName;
	private String depAppName;
	private String description;
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getDepAppName() {
		return depAppName;
	}
	public void setDepAppName(String depAppName) {
		this.depAppName = depAppName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "DepandantAppBean [appName=" + appName + ", depAppName=" + depAppName + ", description=" + description+ "]\n";
	}
}
