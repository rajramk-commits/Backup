package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_MITIGATIONS table.
 */
public class PrMitigationsPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -170542950323402816L;

	protected String cy;

	protected String eaiId;

	protected String ni2AppId;

	protected String item;

	/** 
	 * Sets the value of cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/** 
	 * Gets the value of cy
	 */
	public String getCy()
	{
		return cy;
	}

	/** 
	 * Sets the value of eaiId
	 */
	public void setEaiId(String eaiId)
	{
		this.eaiId = eaiId;
	}

	/** 
	 * Gets the value of eaiId
	 */
	public String getEaiId()
	{
		return eaiId;
	}

	/** 
	 * Sets the value of ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/** 
	 * Gets the value of ni2AppId
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/** 
	 * Sets the value of item
	 */
	public void setItem(String item)
	{
		this.item = item;
	}

	/** 
	 * Gets the value of item
	 */
	public String getItem()
	{
		return item;
	}

	/**
	 * Method 'PrMitigationsPk'
	 * 
	 */
	public PrMitigationsPk()
	{
	}

	/**
	 * Method 'PrMitigationsPk'
	 * 
	 * @param cy
	 * @param eaiId
	 * @param ni2AppId
	 * @param item
	 */
	public PrMitigationsPk(final String cy, final String eaiId, final String ni2AppId, final String item)
	{
		this.cy = cy;
		this.eaiId = eaiId;
		this.ni2AppId = ni2AppId;
		this.item = item;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrMitigationsPk)) {
			return false;
		}
		
		final PrMitigationsPk _cast = (PrMitigationsPk) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (eaiId == null ? _cast.eaiId != eaiId : !eaiId.equals( _cast.eaiId )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		if (item == null ? _cast.item != item : !item.equals( _cast.item )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (eaiId != null) {
			_hashCode = 29 * _hashCode + eaiId.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		if (item != null) {
			_hashCode = 29 * _hashCode + item.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrMitigationsPk: " );
		ret.append( "cy=" + cy );
		ret.append( ", eaiId=" + eaiId );
		ret.append( ", ni2AppId=" + ni2AppId );
		ret.append( ", item=" + item );
		return ret.toString();
	}

}
