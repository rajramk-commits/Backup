package com.fedex.emea.dimm.adaptor.datacenter;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;
import com.fedex.emea.dimm.alert.AbstractAlert;

public class DataCenterOutageAlertDomainAdaptor extends AbstractAlertDomainAdaptor{

	private DataCenterOutageAlertDomainAdaptorConfig config;
	
	public DataCenterOutageAlertDomainAdaptor() throws Exception {
		super();
		config = new DataCenterOutageAlertDomainAdaptorConfig();
	}

	@Override
	public AbstractAlertDomainAdaptorConfig getConfig() {
		return config;
	}

	@Override
	public boolean isApplicable(AbstractAlert physicalAlert) {
		// TODO based on the business logic to determine if this adaptor is applicable for the given physical alert
		return false;
	}

}
