package com.fedex.dashboard.model;

import java.util.List;

public class RequestBean {
	private String hubLocation;
	private List<String> appNames;
	private String serverStatus;
	
	public String getHubLocation() {
		return hubLocation;
	}
	public void setHubLocation(String hubLocation) {
		this.hubLocation = hubLocation;
	}
	public List<String> getAppNames() {
		return appNames;
	}
	public void setAppNames(List<String> appNames) {
		this.appNames = appNames;
	}
	public String getServerStatus() {
		return serverStatus;
	}
	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}
	@Override
	public String toString() {
		return "RequestBean [hubLocation=" + hubLocation + ", appNames=" + appNames + ", serverStatus=" + serverStatus +"]";
	}
	
}
