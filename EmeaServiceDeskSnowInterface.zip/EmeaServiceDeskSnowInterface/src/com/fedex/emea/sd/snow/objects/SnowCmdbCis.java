package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowCmdbCis implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowAsset;
	private String snowAssetTag;
	private String snowAssigned;
	private String snowAssignedTo;
	private String snowAssignmentGroup;
	private String snowAttributes;
	private String snowBusinesCriticality;
	private String snowCanPrint;
	private String snowCategory;
	private String snowChangeControl;
	private String snowCheckedIn;
	private String snowCheckedOut;
	private String snowComments;
	private String snowCompany;
	private String snowCorrelationId;
	private String snowCost;
	private String snowCostCc;
	private String snowCostCenter;
	private String snowDeliveryDate;
	private String snowDepartment;
	private String snowDiscoverySource;
	private String snowDnsDomain;
	private String snowDue;
	private String snowDueIn;
	private String snowFaultCount;
	private String snowFirstDiscovered;
	private String snowFqdn;
	private String snowGlAccount;
	private String snowInstallDate;
	private String snowInstallStatus;
	private String snowInvoiceNumber;
	private String snowIpAddress;
	private String snowJustification;
	private String snowLastDiscovered;
	private String snowLeaseId;
	private String snowLocation;
	private String snowMacAddress;
	private String snowMaintenanceSchedule;
	private String snowManagedBy;
	private String snowManufacturer;
	private String snowModelId;
	private String snowModelNumber;
	private String snowMonitor;
	private String snowName;
	private String snowOperationalStatus;
	private String snowOrderDate;
	private String snowOwnedBy;
	private String snowPoNumber;
	private String snowPurchaseDate;
	private String snowRepairContractId;
	private String snowReturnedFromRepair;
	private String snowSchedule;
	private String snowSentForRepair;
	private String snowSerialNumber;
	private String snowShortDescription;
	private String snowSkipSync;
	private String snowStartDate;
	private String snowSubcategory;
	private String snowSupportGroup;
	private String snowSupportedBy;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysDomain;
	private String snowSysDomainPath;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowU_AcquiredDate;
	private String snowU_ApplicationCode;
	private String snowU_ApplicationServiceOwner;
	private String snowU_Apps;
	private String snowU_AssetLifeMonths;
	private String snowU_Blocked;
	private String snowU_Brand;
	private String snowU_BusinessServiceOwner;
	private String snowU_C3Component;
	private String snowU_Cell;
	private String snowU_Charge;
	private String snowU_CirEir;
	private String snowU_CircuitAccessSpeed;
	private String snowU_CisuAdditionalInformation;
	private String snowU_CisuApplicationServiceOwn;
	private String snowU_CisuAudit;
	private String snowU_CisuAuditDate;
	private String snowU_CisuAuditor;
	private String snowU_CisuBusinessServiceOwner;
	private String snowU_CisuComment;
	private String snowU_CisuImportSource;
	private String snowU_CisuMainUnderpinningServi;
	private String snowU_CisuMatchingHostnames;
	private String snowU_CisuRack;
	private String snowU_CisuRecoveryPriority;
	private String snowU_CisuRoom;
	private String snowU_CisuServer;
	private String snowU_CisuServiceAffected;
	private String snowU_CisuTechnicalServiceOwner;
	private String snowU_CisuTsoPointOfContact;
	private String snowU_CisuUpdated;
	private String snowU_CisuUpdatesBy;
	private String snowU_CisuVm;
	private String snowU_Classification;
	private String snowU_Cluster;
	private String snowU_DecommissionDate;
	private String snowU_DetailedName;
	private String snowU_DiscontinuedDate;
	private String snowU_Emphasise;
	private String snowU_Envprops;
	private String snowU_FinancialAsset;
	private String snowU_Folder;
	private String snowU_Host;
	private String snowU_HostnameCircuitRef;
	private String snowU_HpsdAcquiredDate;
	private String snowU_HpsdCreatedDate_Time;
	private String snowU_HpsdCreatedDateTime;
	private String snowU_HpsdDecomminssionDate;
	private String snowU_HpsdDiscontinuedDate;
	private String snowU_HpsdItemType;
	private String snowU_HpsdLastReviewAuditDate;
	private String snowU_HpsdOrderDate;
	private String snowU_HpsdPurchaseDate;
	private String snowU_HpsdSnStatus;
	private String snowU_HpsdWarrantyDate;
	private String snowU_IncidentPriority;
	private String snowU_InvalidSearchCode;
	private String snowU_KeyA;
	private String snowU_KeyB;
	private String snowU_KeyC;
	private String snowU_LastImport;
	private String snowU_LastReviewAuditDate;
	private String snowU_MaintenanceContract;
	private String snowU_Manager;
	private String snowU_MatchingHostnames;
	private String snowU_MaxInstallations;
	private String snowU_Node;
	private String snowU_NodeType;
	private String snowU_OrderDate;
	private String snowU_OutsourcedTo;
	private String snowU_Owner;
	private String snowU_OwnerOrganisation;
	private String snowU_OwnerPerson;
	private String snowU_Pac;
	private String snowU_PortalVersion;
	private String snowU_Price;
	private String snowU_Profile;
	private String snowU_PurchaseDate;
	private String snowU_Remark;
	private String snowU_SapNumber;
	private String snowU_SearchCode;
	private String snowU_Server;
	private String snowU_ServerType;
	private String snowU_ServiceLevel;
	private String snowU_ServiceLevelClass;
	private String snowU_ServiceTower;
	private String snowU_ServiceType;
	private String snowU_SourceId;
	private String snowU_Subclassification;
	private String snowU_SupplierOrganisation;
	private String snowU_SupportOrganization;
	private String snowU_SupportPerson;
	private String snowU_SupportRota;
	private String snowU_SupportWorkgroup;
	private String snowU_Template;
	private String snowU_TntServiceType;
	private String snowU_Unique;
	private String snowU_ValidHostnameFormat;
	private String snowU_Version;
	private String snowU_Vista3RdPartyDetails;
	private String snowU_VistaAcquiredDate;
	private String snowU_VistaApproxNoOfUsers;
	private String snowU_VistaAssetLinkedToSap;
	private String snowU_VistaAssetTag;
	private String snowU_VistaAssetValue;
	private String snowU_VistaAssetValueUnknown;
	private String snowU_VistaBusinessCriticality;
	private String snowU_VistaLocationTntSiteCode;
	private String snowU_VistaManufacturer;
	private String snowU_VistaModelNumber;
	private String snowU_VistaName;
	private String snowU_VistaOperatingSystem;
	private String snowU_VistaOperatingSystemVersi;
	private String snowU_VistaOperationalStatus;
	private String snowU_VistaPhysicalOrVirtual;
	private String snowU_VistaSerialNumber;
	private String snowU_VistaServerRole;
	private String snowU_VistaSupport;
	private String snowU_VsAlarmActions;
	private String snowU_VsEnv;
	private String snowU_VsGuestMem;
	private String snowU_VsGuestMemPercentage;
	private String snowU_VsHost;
	private String snowU_VsHostCpuMhz;
	private String snowU_VsHostMemMb;
	private String snowU_VsName;
	private String snowU_VsNotes;
	private String snowU_VsOwner;
	private String snowU_VsProvisionedSpace;
	private String snowU_VsRole;
	private String snowU_VsState;
	private String snowU_VsStatus;
	private String snowU_VsUsedSpace;
	private String snowU_VsWasType;
	private String snowU_WarrantyDate;
	private String snowU_WsEnvHostServerHostName;
	private String snowU_WsEnvServerAppFileDate;
	private String snowU_WsEnvServerAppFileDate2;
	private String snowU_WsEnvironmentHostServerA;
	private String snowU_WsEnvironmentHostServerI;
	private String snowU_WsEnvironmentId;
	private String snowU_WsEnvironmentName;
	private String snowU_WsExtractDate;
	private String snowU_WsExtractDate2;
	private String snowUnverified;
	private String snowVendor;
	private String snowWarrantyExpiration;
	
	public SnowCmdbCis() {
	}
	
	public SnowCmdbCis(HashMap<String, Object> jsonValues) {
		snowAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("asset"));
		snowAssetTag = SnowUtilities.getStringValueFromObject(jsonValues.get("asset_tag"));
		snowAssigned = SnowUtilities.getStringValueFromObject(jsonValues.get("assigned"));
		snowAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("assigned_to"));
		snowAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("assignment_group"));
		snowAttributes = SnowUtilities.getStringValueFromObject(jsonValues.get("attributes"));
		snowBusinesCriticality = SnowUtilities.getStringValueFromObject(jsonValues.get("busines_criticality"));
		snowCanPrint = SnowUtilities.getStringValueFromObject(jsonValues.get("can_print"));
		snowCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("category"));
		snowChangeControl = SnowUtilities.getStringValueFromObject(jsonValues.get("change_control"));
		snowCheckedIn = SnowUtilities.getStringValueFromObject(jsonValues.get("checked_in"));
		snowCheckedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("checked_out"));
		snowComments = SnowUtilities.getStringValueFromObject(jsonValues.get("comments"));
		snowCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("company"));
		snowCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("correlation_id"));
		snowCost = SnowUtilities.getStringValueFromObject(jsonValues.get("cost"));
		snowCostCc = SnowUtilities.getStringValueFromObject(jsonValues.get("cost_cc"));
		snowCostCenter = SnowUtilities.getStringValueFromObject(jsonValues.get("cost_center"));
		snowDeliveryDate = SnowUtilities.getStringValueFromObject(jsonValues.get("delivery_date"));
		snowDepartment = SnowUtilities.getStringValueFromObject(jsonValues.get("department"));
		snowDiscoverySource = SnowUtilities.getStringValueFromObject(jsonValues.get("discovery_source"));
		snowDnsDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("dns_domain"));
		snowDue = SnowUtilities.getStringValueFromObject(jsonValues.get("due"));
		snowDueIn = SnowUtilities.getStringValueFromObject(jsonValues.get("due_in"));
		snowFaultCount = SnowUtilities.getStringValueFromObject(jsonValues.get("fault_count"));
		snowFirstDiscovered = SnowUtilities.getStringValueFromObject(jsonValues.get("first_discovered"));
		snowFqdn = SnowUtilities.getStringValueFromObject(jsonValues.get("fqdn"));
		snowGlAccount = SnowUtilities.getStringValueFromObject(jsonValues.get("gl_account"));
		snowInstallDate = SnowUtilities.getStringValueFromObject(jsonValues.get("install_date"));
		snowInstallStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("install_status"));
		snowInvoiceNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("invoice_number"));
		snowIpAddress = SnowUtilities.getStringValueFromObject(jsonValues.get("ip_address"));
		snowJustification = SnowUtilities.getStringValueFromObject(jsonValues.get("justification"));
		snowLastDiscovered = SnowUtilities.getStringValueFromObject(jsonValues.get("last_discovered"));
		snowLeaseId = SnowUtilities.getStringValueFromObject(jsonValues.get("lease_id"));
		snowLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("location"));
		snowMacAddress = SnowUtilities.getStringValueFromObject(jsonValues.get("mac_address"));
		snowMaintenanceSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("maintenance_schedule"));
		snowManagedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("managed_by"));
		snowManufacturer = SnowUtilities.getStringValueFromObject(jsonValues.get("manufacturer"));
		snowModelId = SnowUtilities.getStringValueFromObject(jsonValues.get("model_id"));
		snowModelNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("model_number"));
		snowMonitor = SnowUtilities.getStringValueFromObject(jsonValues.get("monitor"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowOperationalStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("operational_status"));
		snowOrderDate = SnowUtilities.getStringValueFromObject(jsonValues.get("order_date"));
		snowOwnedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("owned_by"));
		snowPoNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("po_number"));
		snowPurchaseDate = SnowUtilities.getStringValueFromObject(jsonValues.get("purchase_date"));
		snowRepairContractId = SnowUtilities.getStringValueFromObject(jsonValues.get("repair_contract_id"));
		snowReturnedFromRepair = SnowUtilities.getStringValueFromObject(jsonValues.get("returned_from_repair"));
		snowSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("schedule"));
		snowSentForRepair = SnowUtilities.getStringValueFromObject(jsonValues.get("sent_for_repair"));
		snowSerialNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("serial_number"));
		snowShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("short_description"));
		snowSkipSync = SnowUtilities.getStringValueFromObject(jsonValues.get("skip_sync"));
		snowStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("start_date"));
		snowSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("subcategory"));
		snowSupportGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("support_group"));
		snowSupportedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("supported_by"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain"));
		snowSysDomainPath = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain_path"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowU_AcquiredDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_acquired_date"));
		snowU_ApplicationCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_application_code"));
		snowU_ApplicationServiceOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_application_service_owner"));
		snowU_Apps = SnowUtilities.getStringValueFromObject(jsonValues.get("u_apps"));
		snowU_AssetLifeMonths = SnowUtilities.getStringValueFromObject(jsonValues.get("u_asset_life__months_"));
		snowU_Blocked = SnowUtilities.getStringValueFromObject(jsonValues.get("u_blocked"));
		snowU_Brand = SnowUtilities.getStringValueFromObject(jsonValues.get("u_brand"));
		snowU_BusinessServiceOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_service_owner"));
		snowU_C3Component = SnowUtilities.getStringValueFromObject(jsonValues.get("u_c3_component"));
		snowU_Cell = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cell"));
		snowU_Charge = SnowUtilities.getStringValueFromObject(jsonValues.get("u_charge"));
		snowU_CirEir = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cir___eir"));
		snowU_CircuitAccessSpeed = SnowUtilities.getStringValueFromObject(jsonValues.get("u_circuit_access_speed"));
		snowU_CisuAdditionalInformation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_additional_information"));
		snowU_CisuApplicationServiceOwn = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_application_service_own"));
		snowU_CisuAudit = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_audit"));
		snowU_CisuAuditDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_audit_date"));
		snowU_CisuAuditor = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_auditor"));
		snowU_CisuBusinessServiceOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_business_service_owner"));
		snowU_CisuComment = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_comment"));
		snowU_CisuImportSource = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_import_source"));
		snowU_CisuMainUnderpinningServi = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_main_underpinning_servi"));
		snowU_CisuMatchingHostnames = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_matching_hostnames"));
		snowU_CisuRack = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_rack"));
		snowU_CisuRecoveryPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_recovery_priority"));
		snowU_CisuRoom = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_room"));
		snowU_CisuServer = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_server"));
		snowU_CisuServiceAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_service_affected"));
		snowU_CisuTechnicalServiceOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_technical_service_owner"));
		snowU_CisuTsoPointOfContact = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_tso_point_of_contact"));
		snowU_CisuUpdated = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_updated"));
		snowU_CisuUpdatesBy = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_updates_by"));
		snowU_CisuVm = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cisu_vm"));
		snowU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("u_classification"));
		snowU_Cluster = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cluster"));
		snowU_DecommissionDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_decommission_date"));
		snowU_DetailedName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_detailed_name"));
		snowU_DiscontinuedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_discontinued_date"));
		snowU_Emphasise = SnowUtilities.getStringValueFromObject(jsonValues.get("u_emphasise"));
		snowU_Envprops = SnowUtilities.getStringValueFromObject(jsonValues.get("u_envprops"));
		snowU_FinancialAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("u_financial_asset"));
		snowU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("u_folder"));
		snowU_Host = SnowUtilities.getStringValueFromObject(jsonValues.get("u_host"));
		snowU_HostnameCircuitRef = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hostname___circuit_ref"));
		snowU_HpsdAcquiredDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_acquired_date"));
		snowU_HpsdCreatedDate_Time = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_created_date___time"));
		snowU_HpsdCreatedDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_created_date__time"));
		snowU_HpsdDecomminssionDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_decomminssion_date"));
		snowU_HpsdDiscontinuedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_discontinued_date"));
		snowU_HpsdItemType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_item_type"));
		snowU_HpsdLastReviewAuditDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_last_review_audit_date"));
		snowU_HpsdOrderDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_order_date"));
		snowU_HpsdPurchaseDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_purchase_date"));
		snowU_HpsdSnStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_sn_status"));
		snowU_HpsdWarrantyDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hpsd_warranty_date"));
		snowU_IncidentPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("u_incident_priority"));
		snowU_InvalidSearchCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_invalid_search_code"));
		snowU_KeyA = SnowUtilities.getStringValueFromObject(jsonValues.get("u_key_a"));
		snowU_KeyB = SnowUtilities.getStringValueFromObject(jsonValues.get("u_key_b"));
		snowU_KeyC = SnowUtilities.getStringValueFromObject(jsonValues.get("u_key_c"));
		snowU_LastImport = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_import"));
		snowU_LastReviewAuditDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_review_audit_date"));
		snowU_MaintenanceContract = SnowUtilities.getStringValueFromObject(jsonValues.get("u_maintenance_contract"));
		snowU_Manager = SnowUtilities.getStringValueFromObject(jsonValues.get("u_manager"));
		snowU_MatchingHostnames = SnowUtilities.getStringValueFromObject(jsonValues.get("u_matching_hostnames"));
		snowU_MaxInstallations = SnowUtilities.getStringValueFromObject(jsonValues.get("u_max_installations"));
		snowU_Node = SnowUtilities.getStringValueFromObject(jsonValues.get("u_node"));
		snowU_NodeType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_node_type"));
		snowU_OrderDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_order_date"));
		snowU_OutsourcedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsourced_to"));
		snowU_Owner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_owner"));
		snowU_OwnerOrganisation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_owner_organisation"));
		snowU_OwnerPerson = SnowUtilities.getStringValueFromObject(jsonValues.get("u_owner_person"));
		snowU_Pac = SnowUtilities.getStringValueFromObject(jsonValues.get("u_pac"));
		snowU_PortalVersion = SnowUtilities.getStringValueFromObject(jsonValues.get("u_portal_version"));
		snowU_Price = SnowUtilities.getStringValueFromObject(jsonValues.get("u_price"));
		snowU_Profile = SnowUtilities.getStringValueFromObject(jsonValues.get("u_profile"));
		snowU_PurchaseDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_purchase_date"));
		snowU_Remark = SnowUtilities.getStringValueFromObject(jsonValues.get("u_remark"));
		snowU_SapNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sap_number"));
		snowU_SearchCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_search_code"));
		snowU_Server = SnowUtilities.getStringValueFromObject(jsonValues.get("u_server"));
		snowU_ServerType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_server_type"));
		snowU_ServiceLevel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service_level"));
		snowU_ServiceLevelClass = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service_level_class"));
		snowU_ServiceTower = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service_tower"));
		snowU_ServiceType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service_type"));
		snowU_SourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_source_id"));
		snowU_Subclassification = SnowUtilities.getStringValueFromObject(jsonValues.get("u_subclassification"));
		snowU_SupplierOrganisation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_supplier_organisation"));
		snowU_SupportOrganization = SnowUtilities.getStringValueFromObject(jsonValues.get("u_support_organization"));
		snowU_SupportPerson = SnowUtilities.getStringValueFromObject(jsonValues.get("u_support_person"));
		snowU_SupportRota = SnowUtilities.getStringValueFromObject(jsonValues.get("u_support_rota"));
		snowU_SupportWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_support_workgroup"));
		snowU_Template = SnowUtilities.getStringValueFromObject(jsonValues.get("u_template"));
		snowU_TntServiceType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_tnt_service_type"));
		snowU_Unique = SnowUtilities.getStringValueFromObject(jsonValues.get("u_unique"));
		snowU_ValidHostnameFormat = SnowUtilities.getStringValueFromObject(jsonValues.get("u_valid_hostname_format"));
		snowU_Version = SnowUtilities.getStringValueFromObject(jsonValues.get("u_version"));
		snowU_Vista3RdPartyDetails = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_3rd_party_details"));
		snowU_VistaAcquiredDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_acquired_date"));
		snowU_VistaApproxNoOfUsers = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_approx_no_of_users"));
		snowU_VistaAssetLinkedToSap = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_asset_linked_to_sap"));
		snowU_VistaAssetTag = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_asset_tag"));
		snowU_VistaAssetValue = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_asset_value"));
		snowU_VistaAssetValueUnknown = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_asset_value_unknown"));
		snowU_VistaBusinessCriticality = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_business_criticality"));
		snowU_VistaLocationTntSiteCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_location_tnt_site_code"));
		snowU_VistaManufacturer = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_manufacturer"));
		snowU_VistaModelNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_model_number"));
		snowU_VistaName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_name"));
		snowU_VistaOperatingSystem = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_operating_system"));
		snowU_VistaOperatingSystemVersi = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_operating_system_versi"));
		snowU_VistaOperationalStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_operational_status"));
		snowU_VistaPhysicalOrVirtual = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_physical_or_virtual"));
		snowU_VistaSerialNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_serial_number"));
		snowU_VistaServerRole = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_server_role"));
		snowU_VistaSupport = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vista_support"));
		snowU_VsAlarmActions = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_alarm_actions"));
		snowU_VsEnv = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_env"));
		snowU_VsGuestMem = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_guest_mem__"));
		snowU_VsGuestMemPercentage = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_guest_mem_percentage"));
		snowU_VsHost = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_host"));
		snowU_VsHostCpuMhz = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_host_cpu_mhz"));
		snowU_VsHostMemMb = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_host_mem_mb"));
		snowU_VsName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_name"));
		snowU_VsNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_notes"));
		snowU_VsOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_owner"));
		snowU_VsProvisionedSpace = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_provisioned_space"));
		snowU_VsRole = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_role"));
		snowU_VsState = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_state"));
		snowU_VsStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_status"));
		snowU_VsUsedSpace = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_used_space"));
		snowU_VsWasType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_vs_was_type"));
		snowU_WarrantyDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_warranty_date"));
		snowU_WsEnvHostServerHostName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_env_host_server_host_name"));
		snowU_WsEnvServerAppFileDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_env_server_app_file_date"));
		snowU_WsEnvServerAppFileDate2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_env_server_app_file_date2"));
		snowU_WsEnvironmentHostServerA = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_environment_host_server_a"));
		snowU_WsEnvironmentHostServerI = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_environment_host_server_i"));
		snowU_WsEnvironmentId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_environment_id"));
		snowU_WsEnvironmentName = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_environment_name"));
		snowU_WsExtractDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_extract_date"));
		snowU_WsExtractDate2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ws_extract_date2"));
		snowUnverified = SnowUtilities.getStringValueFromObject(jsonValues.get("unverified"));
		snowVendor = SnowUtilities.getStringValueFromObject(jsonValues.get("vendor"));
		snowWarrantyExpiration = SnowUtilities.getStringValueFromObject(jsonValues.get("warranty_expiration"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (snowAsset != null && !snowAsset.toString().isEmpty()) jsonObject.put("asset", snowAsset);
		if (snowAssetTag != null && !snowAssetTag.toString().isEmpty()) jsonObject.put("asset_tag", snowAssetTag);
		if (snowAssigned != null && !snowAssigned.toString().isEmpty()) jsonObject.put("assigned", snowAssigned);
		if (snowAssignedTo != null && !snowAssignedTo.toString().isEmpty()) jsonObject.put("assigned_to", snowAssignedTo);
		if (snowAssignmentGroup != null && !snowAssignmentGroup.toString().isEmpty()) jsonObject.put("assignment_group", snowAssignmentGroup);
		if (snowAttributes != null && !snowAttributes.toString().isEmpty()) jsonObject.put("attributes", snowAttributes);
		if (snowBusinesCriticality != null && !snowBusinesCriticality.toString().isEmpty()) jsonObject.put("busines_criticality", snowBusinesCriticality);
		if (snowCanPrint != null && !snowCanPrint.toString().isEmpty()) jsonObject.put("can_print", snowCanPrint);
		if (snowCategory != null && !snowCategory.toString().isEmpty()) jsonObject.put("category", snowCategory);
		if (snowChangeControl != null && !snowChangeControl.toString().isEmpty()) jsonObject.put("change_control", snowChangeControl);
		if (snowCheckedIn != null && !snowCheckedIn.toString().isEmpty()) jsonObject.put("checked_in", snowCheckedIn);
		if (snowCheckedOut != null && !snowCheckedOut.toString().isEmpty()) jsonObject.put("checked_out", snowCheckedOut);
		if (snowComments != null && !snowComments.toString().isEmpty()) jsonObject.put("comments", snowComments);
		if (snowCompany != null && !snowCompany.toString().isEmpty()) jsonObject.put("company", snowCompany);
		if (snowCorrelationId != null && !snowCorrelationId.toString().isEmpty()) jsonObject.put("correlation_id", snowCorrelationId);
		if (snowCost != null && !snowCost.toString().isEmpty()) jsonObject.put("cost", snowCost);
		if (snowCostCc != null && !snowCostCc.toString().isEmpty()) jsonObject.put("cost_cc", snowCostCc);
		if (snowCostCenter != null && !snowCostCenter.toString().isEmpty()) jsonObject.put("cost_center", snowCostCenter);
		if (snowDeliveryDate != null && !snowDeliveryDate.toString().isEmpty()) jsonObject.put("delivery_date", snowDeliveryDate);
		if (snowDepartment != null && !snowDepartment.toString().isEmpty()) jsonObject.put("department", snowDepartment);
		if (snowDiscoverySource != null && !snowDiscoverySource.toString().isEmpty()) jsonObject.put("discovery_source", snowDiscoverySource);
		if (snowDnsDomain != null && !snowDnsDomain.toString().isEmpty()) jsonObject.put("dns_domain", snowDnsDomain);
		if (snowDue != null && !snowDue.toString().isEmpty()) jsonObject.put("due", snowDue);
		if (snowDueIn != null && !snowDueIn.toString().isEmpty()) jsonObject.put("due_in", snowDueIn);
		if (snowFaultCount != null && !snowFaultCount.toString().isEmpty()) jsonObject.put("fault_count", snowFaultCount);
		if (snowFirstDiscovered != null && !snowFirstDiscovered.toString().isEmpty()) jsonObject.put("first_discovered", snowFirstDiscovered);
		if (snowFqdn != null && !snowFqdn.toString().isEmpty()) jsonObject.put("fqdn", snowFqdn);
		if (snowGlAccount != null && !snowGlAccount.toString().isEmpty()) jsonObject.put("gl_account", snowGlAccount);
		if (snowInstallDate != null && !snowInstallDate.toString().isEmpty()) jsonObject.put("install_date", snowInstallDate);
		if (snowInstallStatus != null && !snowInstallStatus.toString().isEmpty()) jsonObject.put("install_status", snowInstallStatus);
		if (snowInvoiceNumber != null && !snowInvoiceNumber.toString().isEmpty()) jsonObject.put("invoice_number", snowInvoiceNumber);
		if (snowIpAddress != null && !snowIpAddress.toString().isEmpty()) jsonObject.put("ip_address", snowIpAddress);
		if (snowJustification != null && !snowJustification.toString().isEmpty()) jsonObject.put("justification", snowJustification);
		if (snowLastDiscovered != null && !snowLastDiscovered.toString().isEmpty()) jsonObject.put("last_discovered", snowLastDiscovered);
		if (snowLeaseId != null && !snowLeaseId.toString().isEmpty()) jsonObject.put("lease_id", snowLeaseId);
		if (snowLocation != null && !snowLocation.toString().isEmpty()) jsonObject.put("location", snowLocation);
		if (snowMacAddress != null && !snowMacAddress.toString().isEmpty()) jsonObject.put("mac_address", snowMacAddress);
		if (snowMaintenanceSchedule != null && !snowMaintenanceSchedule.toString().isEmpty()) jsonObject.put("maintenance_schedule", snowMaintenanceSchedule);
		if (snowManagedBy != null && !snowManagedBy.toString().isEmpty()) jsonObject.put("managed_by", snowManagedBy);
		if (snowManufacturer != null && !snowManufacturer.toString().isEmpty()) jsonObject.put("manufacturer", snowManufacturer);
		if (snowModelId != null && !snowModelId.toString().isEmpty()) jsonObject.put("model_id", snowModelId);
		if (snowModelNumber != null && !snowModelNumber.toString().isEmpty()) jsonObject.put("model_number", snowModelNumber);
		if (snowMonitor != null && !snowMonitor.toString().isEmpty()) jsonObject.put("monitor", snowMonitor);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowOperationalStatus != null && !snowOperationalStatus.toString().isEmpty()) jsonObject.put("operational_status", snowOperationalStatus);
		if (snowOrderDate != null && !snowOrderDate.toString().isEmpty()) jsonObject.put("order_date", snowOrderDate);
		if (snowOwnedBy != null && !snowOwnedBy.toString().isEmpty()) jsonObject.put("owned_by", snowOwnedBy);
		if (snowPoNumber != null && !snowPoNumber.toString().isEmpty()) jsonObject.put("po_number", snowPoNumber);
		if (snowPurchaseDate != null && !snowPurchaseDate.toString().isEmpty()) jsonObject.put("purchase_date", snowPurchaseDate);
		if (snowRepairContractId != null && !snowRepairContractId.toString().isEmpty()) jsonObject.put("repair_contract_id", snowRepairContractId);
		if (snowReturnedFromRepair != null && !snowReturnedFromRepair.toString().isEmpty()) jsonObject.put("returned_from_repair", snowReturnedFromRepair);
		if (snowSchedule != null && !snowSchedule.toString().isEmpty()) jsonObject.put("schedule", snowSchedule);
		if (snowSentForRepair != null && !snowSentForRepair.toString().isEmpty()) jsonObject.put("sent_for_repair", snowSentForRepair);
		if (snowSerialNumber != null && !snowSerialNumber.toString().isEmpty()) jsonObject.put("serial_number", snowSerialNumber);
		if (snowShortDescription != null && !snowShortDescription.toString().isEmpty()) jsonObject.put("short_description", snowShortDescription);
		if (snowSkipSync != null && !snowSkipSync.toString().isEmpty()) jsonObject.put("skip_sync", snowSkipSync);
		if (snowStartDate != null && !snowStartDate.toString().isEmpty()) jsonObject.put("start_date", snowStartDate);
		if (snowSubcategory != null && !snowSubcategory.toString().isEmpty()) jsonObject.put("subcategory", snowSubcategory);
		if (snowSupportGroup != null && !snowSupportGroup.toString().isEmpty()) jsonObject.put("support_group", snowSupportGroup);
		if (snowSupportedBy != null && !snowSupportedBy.toString().isEmpty()) jsonObject.put("supported_by", snowSupportedBy);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysDomain != null && !snowSysDomain.toString().isEmpty()) jsonObject.put("sys_domain", snowSysDomain);
		if (snowSysDomainPath != null && !snowSysDomainPath.toString().isEmpty()) jsonObject.put("sys_domain_path", snowSysDomainPath);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowU_AcquiredDate != null && !snowU_AcquiredDate.toString().isEmpty()) jsonObject.put("u_acquired_date", snowU_AcquiredDate);
		if (snowU_ApplicationCode != null && !snowU_ApplicationCode.toString().isEmpty()) jsonObject.put("u_application_code", snowU_ApplicationCode);
		if (snowU_ApplicationServiceOwner != null && !snowU_ApplicationServiceOwner.toString().isEmpty()) jsonObject.put("u_application_service_owner", snowU_ApplicationServiceOwner);
		if (snowU_Apps != null && !snowU_Apps.toString().isEmpty()) jsonObject.put("u_apps", snowU_Apps);
		if (snowU_AssetLifeMonths != null && !snowU_AssetLifeMonths.toString().isEmpty()) jsonObject.put("u_asset_life__months_", snowU_AssetLifeMonths);
		if (snowU_Blocked != null && !snowU_Blocked.toString().isEmpty()) jsonObject.put("u_blocked", snowU_Blocked);
		if (snowU_Brand != null && !snowU_Brand.toString().isEmpty()) jsonObject.put("u_brand", snowU_Brand);
		if (snowU_BusinessServiceOwner != null && !snowU_BusinessServiceOwner.toString().isEmpty()) jsonObject.put("u_business_service_owner", snowU_BusinessServiceOwner);
		if (snowU_C3Component != null && !snowU_C3Component.toString().isEmpty()) jsonObject.put("u_c3_component", snowU_C3Component);
		if (snowU_Cell != null && !snowU_Cell.toString().isEmpty()) jsonObject.put("u_cell", snowU_Cell);
		if (snowU_Charge != null && !snowU_Charge.toString().isEmpty()) jsonObject.put("u_charge", snowU_Charge);
		if (snowU_CirEir != null && !snowU_CirEir.toString().isEmpty()) jsonObject.put("u_cir___eir", snowU_CirEir);
		if (snowU_CircuitAccessSpeed != null && !snowU_CircuitAccessSpeed.toString().isEmpty()) jsonObject.put("u_circuit_access_speed", snowU_CircuitAccessSpeed);
		if (snowU_CisuAdditionalInformation != null && !snowU_CisuAdditionalInformation.toString().isEmpty()) jsonObject.put("u_cisu_additional_information", snowU_CisuAdditionalInformation);
		if (snowU_CisuApplicationServiceOwn != null && !snowU_CisuApplicationServiceOwn.toString().isEmpty()) jsonObject.put("u_cisu_application_service_own", snowU_CisuApplicationServiceOwn);
		if (snowU_CisuAudit != null && !snowU_CisuAudit.toString().isEmpty()) jsonObject.put("u_cisu_audit", snowU_CisuAudit);
		if (snowU_CisuAuditDate != null && !snowU_CisuAuditDate.toString().isEmpty()) jsonObject.put("u_cisu_audit_date", snowU_CisuAuditDate);
		if (snowU_CisuAuditor != null && !snowU_CisuAuditor.toString().isEmpty()) jsonObject.put("u_cisu_auditor", snowU_CisuAuditor);
		if (snowU_CisuBusinessServiceOwner != null && !snowU_CisuBusinessServiceOwner.toString().isEmpty()) jsonObject.put("u_cisu_business_service_owner", snowU_CisuBusinessServiceOwner);
		if (snowU_CisuComment != null && !snowU_CisuComment.toString().isEmpty()) jsonObject.put("u_cisu_comment", snowU_CisuComment);
		if (snowU_CisuImportSource != null && !snowU_CisuImportSource.toString().isEmpty()) jsonObject.put("u_cisu_import_source", snowU_CisuImportSource);
		if (snowU_CisuMainUnderpinningServi != null && !snowU_CisuMainUnderpinningServi.toString().isEmpty()) jsonObject.put("u_cisu_main_underpinning_servi", snowU_CisuMainUnderpinningServi);
		if (snowU_CisuMatchingHostnames != null && !snowU_CisuMatchingHostnames.toString().isEmpty()) jsonObject.put("u_cisu_matching_hostnames", snowU_CisuMatchingHostnames);
		if (snowU_CisuRack != null && !snowU_CisuRack.toString().isEmpty()) jsonObject.put("u_cisu_rack", snowU_CisuRack);
		if (snowU_CisuRecoveryPriority != null && !snowU_CisuRecoveryPriority.toString().isEmpty()) jsonObject.put("u_cisu_recovery_priority", snowU_CisuRecoveryPriority);
		if (snowU_CisuRoom != null && !snowU_CisuRoom.toString().isEmpty()) jsonObject.put("u_cisu_room", snowU_CisuRoom);
		if (snowU_CisuServer != null && !snowU_CisuServer.toString().isEmpty()) jsonObject.put("u_cisu_server", snowU_CisuServer);
		if (snowU_CisuServiceAffected != null && !snowU_CisuServiceAffected.toString().isEmpty()) jsonObject.put("u_cisu_service_affected", snowU_CisuServiceAffected);
		if (snowU_CisuTechnicalServiceOwner != null && !snowU_CisuTechnicalServiceOwner.toString().isEmpty()) jsonObject.put("u_cisu_technical_service_owner", snowU_CisuTechnicalServiceOwner);
		if (snowU_CisuTsoPointOfContact != null && !snowU_CisuTsoPointOfContact.toString().isEmpty()) jsonObject.put("u_cisu_tso_point_of_contact", snowU_CisuTsoPointOfContact);
		if (snowU_CisuUpdated != null && !snowU_CisuUpdated.toString().isEmpty()) jsonObject.put("u_cisu_updated", snowU_CisuUpdated);
		if (snowU_CisuUpdatesBy != null && !snowU_CisuUpdatesBy.toString().isEmpty()) jsonObject.put("u_cisu_updates_by", snowU_CisuUpdatesBy);
		if (snowU_CisuVm != null && !snowU_CisuVm.toString().isEmpty()) jsonObject.put("u_cisu_vm", snowU_CisuVm);
		if (snowU_Classification != null && !snowU_Classification.toString().isEmpty()) jsonObject.put("u_classification", snowU_Classification);
		if (snowU_Cluster != null && !snowU_Cluster.toString().isEmpty()) jsonObject.put("u_cluster", snowU_Cluster);
		if (snowU_DecommissionDate != null && !snowU_DecommissionDate.toString().isEmpty()) jsonObject.put("u_decommission_date", snowU_DecommissionDate);
		if (snowU_DetailedName != null && !snowU_DetailedName.toString().isEmpty()) jsonObject.put("u_detailed_name", snowU_DetailedName);
		if (snowU_DiscontinuedDate != null && !snowU_DiscontinuedDate.toString().isEmpty()) jsonObject.put("u_discontinued_date", snowU_DiscontinuedDate);
		if (snowU_Emphasise != null && !snowU_Emphasise.toString().isEmpty()) jsonObject.put("u_emphasise", snowU_Emphasise);
		if (snowU_Envprops != null && !snowU_Envprops.toString().isEmpty()) jsonObject.put("u_envprops", snowU_Envprops);
		if (snowU_FinancialAsset != null && !snowU_FinancialAsset.toString().isEmpty()) jsonObject.put("u_financial_asset", snowU_FinancialAsset);
		if (snowU_Folder != null && !snowU_Folder.toString().isEmpty()) jsonObject.put("u_folder", snowU_Folder);
		if (snowU_Host != null && !snowU_Host.toString().isEmpty()) jsonObject.put("u_host", snowU_Host);
		if (snowU_HostnameCircuitRef != null && !snowU_HostnameCircuitRef.toString().isEmpty()) jsonObject.put("u_hostname___circuit_ref", snowU_HostnameCircuitRef);
		if (snowU_HpsdAcquiredDate != null && !snowU_HpsdAcquiredDate.toString().isEmpty()) jsonObject.put("u_hpsd_acquired_date", snowU_HpsdAcquiredDate);
		if (snowU_HpsdCreatedDate_Time != null && !snowU_HpsdCreatedDate_Time.toString().isEmpty()) jsonObject.put("u_hpsd_created_date___time", snowU_HpsdCreatedDate_Time);
		if (snowU_HpsdCreatedDateTime != null && !snowU_HpsdCreatedDateTime.toString().isEmpty()) jsonObject.put("u_hpsd_created_date__time", snowU_HpsdCreatedDateTime);
		if (snowU_HpsdDecomminssionDate != null && !snowU_HpsdDecomminssionDate.toString().isEmpty()) jsonObject.put("u_hpsd_decomminssion_date", snowU_HpsdDecomminssionDate);
		if (snowU_HpsdDiscontinuedDate != null && !snowU_HpsdDiscontinuedDate.toString().isEmpty()) jsonObject.put("u_hpsd_discontinued_date", snowU_HpsdDiscontinuedDate);
		if (snowU_HpsdItemType != null && !snowU_HpsdItemType.toString().isEmpty()) jsonObject.put("u_hpsd_item_type", snowU_HpsdItemType);
		if (snowU_HpsdLastReviewAuditDate != null && !snowU_HpsdLastReviewAuditDate.toString().isEmpty()) jsonObject.put("u_hpsd_last_review_audit_date", snowU_HpsdLastReviewAuditDate);
		if (snowU_HpsdOrderDate != null && !snowU_HpsdOrderDate.toString().isEmpty()) jsonObject.put("u_hpsd_order_date", snowU_HpsdOrderDate);
		if (snowU_HpsdPurchaseDate != null && !snowU_HpsdPurchaseDate.toString().isEmpty()) jsonObject.put("u_hpsd_purchase_date", snowU_HpsdPurchaseDate);
		if (snowU_HpsdSnStatus != null && !snowU_HpsdSnStatus.toString().isEmpty()) jsonObject.put("u_hpsd_sn_status", snowU_HpsdSnStatus);
		if (snowU_HpsdWarrantyDate != null && !snowU_HpsdWarrantyDate.toString().isEmpty()) jsonObject.put("u_hpsd_warranty_date", snowU_HpsdWarrantyDate);
		if (snowU_IncidentPriority != null && !snowU_IncidentPriority.toString().isEmpty()) jsonObject.put("u_incident_priority", snowU_IncidentPriority);
		if (snowU_InvalidSearchCode != null && !snowU_InvalidSearchCode.toString().isEmpty()) jsonObject.put("u_invalid_search_code", snowU_InvalidSearchCode);
		if (snowU_KeyA != null && !snowU_KeyA.toString().isEmpty()) jsonObject.put("u_key_a", snowU_KeyA);
		if (snowU_KeyB != null && !snowU_KeyB.toString().isEmpty()) jsonObject.put("u_key_b", snowU_KeyB);
		if (snowU_KeyC != null && !snowU_KeyC.toString().isEmpty()) jsonObject.put("u_key_c", snowU_KeyC);
		if (snowU_LastImport != null && !snowU_LastImport.toString().isEmpty()) jsonObject.put("u_last_import", snowU_LastImport);
		if (snowU_LastReviewAuditDate != null && !snowU_LastReviewAuditDate.toString().isEmpty()) jsonObject.put("u_last_review_audit_date", snowU_LastReviewAuditDate);
		if (snowU_MaintenanceContract != null && !snowU_MaintenanceContract.toString().isEmpty()) jsonObject.put("u_maintenance_contract", snowU_MaintenanceContract);
		if (snowU_Manager != null && !snowU_Manager.toString().isEmpty()) jsonObject.put("u_manager", snowU_Manager);
		if (snowU_MatchingHostnames != null && !snowU_MatchingHostnames.toString().isEmpty()) jsonObject.put("u_matching_hostnames", snowU_MatchingHostnames);
		if (snowU_MaxInstallations != null && !snowU_MaxInstallations.toString().isEmpty()) jsonObject.put("u_max_installations", snowU_MaxInstallations);
		if (snowU_Node != null && !snowU_Node.toString().isEmpty()) jsonObject.put("u_node", snowU_Node);
		if (snowU_NodeType != null && !snowU_NodeType.toString().isEmpty()) jsonObject.put("u_node_type", snowU_NodeType);
		if (snowU_OrderDate != null && !snowU_OrderDate.toString().isEmpty()) jsonObject.put("u_order_date", snowU_OrderDate);
		if (snowU_OutsourcedTo != null && !snowU_OutsourcedTo.toString().isEmpty()) jsonObject.put("u_outsourced_to", snowU_OutsourcedTo);
		if (snowU_Owner != null && !snowU_Owner.toString().isEmpty()) jsonObject.put("u_owner", snowU_Owner);
		if (snowU_OwnerOrganisation != null && !snowU_OwnerOrganisation.toString().isEmpty()) jsonObject.put("u_owner_organisation", snowU_OwnerOrganisation);
		if (snowU_OwnerPerson != null && !snowU_OwnerPerson.toString().isEmpty()) jsonObject.put("u_owner_person", snowU_OwnerPerson);
		if (snowU_Pac != null && !snowU_Pac.toString().isEmpty()) jsonObject.put("u_pac", snowU_Pac);
		if (snowU_PortalVersion != null && !snowU_PortalVersion.toString().isEmpty()) jsonObject.put("u_portal_version", snowU_PortalVersion);
		if (snowU_Price != null && !snowU_Price.toString().isEmpty()) jsonObject.put("u_price", snowU_Price);
		if (snowU_Profile != null && !snowU_Profile.toString().isEmpty()) jsonObject.put("u_profile", snowU_Profile);
		if (snowU_PurchaseDate != null && !snowU_PurchaseDate.toString().isEmpty()) jsonObject.put("u_purchase_date", snowU_PurchaseDate);
		if (snowU_Remark != null && !snowU_Remark.toString().isEmpty()) jsonObject.put("u_remark", snowU_Remark);
		if (snowU_SapNumber != null && !snowU_SapNumber.toString().isEmpty()) jsonObject.put("u_sap_number", snowU_SapNumber);
		if (snowU_SearchCode != null && !snowU_SearchCode.toString().isEmpty()) jsonObject.put("u_search_code", snowU_SearchCode);
		if (snowU_Server != null && !snowU_Server.toString().isEmpty()) jsonObject.put("u_server", snowU_Server);
		if (snowU_ServerType != null && !snowU_ServerType.toString().isEmpty()) jsonObject.put("u_server_type", snowU_ServerType);
		if (snowU_ServiceLevel != null && !snowU_ServiceLevel.toString().isEmpty()) jsonObject.put("u_service_level", snowU_ServiceLevel);
		if (snowU_ServiceLevelClass != null && !snowU_ServiceLevelClass.toString().isEmpty()) jsonObject.put("u_service_level_class", snowU_ServiceLevelClass);
		if (snowU_ServiceTower != null && !snowU_ServiceTower.toString().isEmpty()) jsonObject.put("u_service_tower", snowU_ServiceTower);
		if (snowU_ServiceType != null && !snowU_ServiceType.toString().isEmpty()) jsonObject.put("u_service_type", snowU_ServiceType);
		if (snowU_SourceId != null && !snowU_SourceId.toString().isEmpty()) jsonObject.put("u_source_id", snowU_SourceId);
		if (snowU_Subclassification != null && !snowU_Subclassification.toString().isEmpty()) jsonObject.put("u_subclassification", snowU_Subclassification);
		if (snowU_SupplierOrganisation != null && !snowU_SupplierOrganisation.toString().isEmpty()) jsonObject.put("u_supplier_organisation", snowU_SupplierOrganisation);
		if (snowU_SupportOrganization != null && !snowU_SupportOrganization.toString().isEmpty()) jsonObject.put("u_support_organization", snowU_SupportOrganization);
		if (snowU_SupportPerson != null && !snowU_SupportPerson.toString().isEmpty()) jsonObject.put("u_support_person", snowU_SupportPerson);
		if (snowU_SupportRota != null && !snowU_SupportRota.toString().isEmpty()) jsonObject.put("u_support_rota", snowU_SupportRota);
		if (snowU_SupportWorkgroup != null && !snowU_SupportWorkgroup.toString().isEmpty()) jsonObject.put("u_support_workgroup", snowU_SupportWorkgroup);
		if (snowU_Template != null && !snowU_Template.toString().isEmpty()) jsonObject.put("u_template", snowU_Template);
		if (snowU_TntServiceType != null && !snowU_TntServiceType.toString().isEmpty()) jsonObject.put("u_tnt_service_type", snowU_TntServiceType);
		if (snowU_Unique != null && !snowU_Unique.toString().isEmpty()) jsonObject.put("u_unique", snowU_Unique);
		if (snowU_ValidHostnameFormat != null && !snowU_ValidHostnameFormat.toString().isEmpty()) jsonObject.put("u_valid_hostname_format", snowU_ValidHostnameFormat);
		if (snowU_Version != null && !snowU_Version.toString().isEmpty()) jsonObject.put("u_version", snowU_Version);
		if (snowU_Vista3RdPartyDetails != null && !snowU_Vista3RdPartyDetails.toString().isEmpty()) jsonObject.put("u_vista_3rd_party_details", snowU_Vista3RdPartyDetails);
		if (snowU_VistaAcquiredDate != null && !snowU_VistaAcquiredDate.toString().isEmpty()) jsonObject.put("u_vista_acquired_date", snowU_VistaAcquiredDate);
		if (snowU_VistaApproxNoOfUsers != null && !snowU_VistaApproxNoOfUsers.toString().isEmpty()) jsonObject.put("u_vista_approx_no_of_users", snowU_VistaApproxNoOfUsers);
		if (snowU_VistaAssetLinkedToSap != null && !snowU_VistaAssetLinkedToSap.toString().isEmpty()) jsonObject.put("u_vista_asset_linked_to_sap", snowU_VistaAssetLinkedToSap);
		if (snowU_VistaAssetTag != null && !snowU_VistaAssetTag.toString().isEmpty()) jsonObject.put("u_vista_asset_tag", snowU_VistaAssetTag);
		if (snowU_VistaAssetValue != null && !snowU_VistaAssetValue.toString().isEmpty()) jsonObject.put("u_vista_asset_value", snowU_VistaAssetValue);
		if (snowU_VistaAssetValueUnknown != null && !snowU_VistaAssetValueUnknown.toString().isEmpty()) jsonObject.put("u_vista_asset_value_unknown", snowU_VistaAssetValueUnknown);
		if (snowU_VistaBusinessCriticality != null && !snowU_VistaBusinessCriticality.toString().isEmpty()) jsonObject.put("u_vista_business_criticality", snowU_VistaBusinessCriticality);
		if (snowU_VistaLocationTntSiteCode != null && !snowU_VistaLocationTntSiteCode.toString().isEmpty()) jsonObject.put("u_vista_location_tnt_site_code", snowU_VistaLocationTntSiteCode);
		if (snowU_VistaManufacturer != null && !snowU_VistaManufacturer.toString().isEmpty()) jsonObject.put("u_vista_manufacturer", snowU_VistaManufacturer);
		if (snowU_VistaModelNumber != null && !snowU_VistaModelNumber.toString().isEmpty()) jsonObject.put("u_vista_model_number", snowU_VistaModelNumber);
		if (snowU_VistaName != null && !snowU_VistaName.toString().isEmpty()) jsonObject.put("u_vista_name", snowU_VistaName);
		if (snowU_VistaOperatingSystem != null && !snowU_VistaOperatingSystem.toString().isEmpty()) jsonObject.put("u_vista_operating_system", snowU_VistaOperatingSystem);
		if (snowU_VistaOperatingSystemVersi != null && !snowU_VistaOperatingSystemVersi.toString().isEmpty()) jsonObject.put("u_vista_operating_system_versi", snowU_VistaOperatingSystemVersi);
		if (snowU_VistaOperationalStatus != null && !snowU_VistaOperationalStatus.toString().isEmpty()) jsonObject.put("u_vista_operational_status", snowU_VistaOperationalStatus);
		if (snowU_VistaPhysicalOrVirtual != null && !snowU_VistaPhysicalOrVirtual.toString().isEmpty()) jsonObject.put("u_vista_physical_or_virtual", snowU_VistaPhysicalOrVirtual);
		if (snowU_VistaSerialNumber != null && !snowU_VistaSerialNumber.toString().isEmpty()) jsonObject.put("u_vista_serial_number", snowU_VistaSerialNumber);
		if (snowU_VistaServerRole != null && !snowU_VistaServerRole.toString().isEmpty()) jsonObject.put("u_vista_server_role", snowU_VistaServerRole);
		if (snowU_VistaSupport != null && !snowU_VistaSupport.toString().isEmpty()) jsonObject.put("u_vista_support", snowU_VistaSupport);
		if (snowU_VsAlarmActions != null && !snowU_VsAlarmActions.toString().isEmpty()) jsonObject.put("u_vs_alarm_actions", snowU_VsAlarmActions);
		if (snowU_VsEnv != null && !snowU_VsEnv.toString().isEmpty()) jsonObject.put("u_vs_env", snowU_VsEnv);
		if (snowU_VsGuestMem != null && !snowU_VsGuestMem.toString().isEmpty()) jsonObject.put("u_vs_guest_mem__", snowU_VsGuestMem);
		if (snowU_VsGuestMemPercentage != null && !snowU_VsGuestMemPercentage.toString().isEmpty()) jsonObject.put("u_vs_guest_mem_percentage", snowU_VsGuestMemPercentage);
		if (snowU_VsHost != null && !snowU_VsHost.toString().isEmpty()) jsonObject.put("u_vs_host", snowU_VsHost);
		if (snowU_VsHostCpuMhz != null && !snowU_VsHostCpuMhz.toString().isEmpty()) jsonObject.put("u_vs_host_cpu_mhz", snowU_VsHostCpuMhz);
		if (snowU_VsHostMemMb != null && !snowU_VsHostMemMb.toString().isEmpty()) jsonObject.put("u_vs_host_mem_mb", snowU_VsHostMemMb);
		if (snowU_VsName != null && !snowU_VsName.toString().isEmpty()) jsonObject.put("u_vs_name", snowU_VsName);
		if (snowU_VsNotes != null && !snowU_VsNotes.toString().isEmpty()) jsonObject.put("u_vs_notes", snowU_VsNotes);
		if (snowU_VsOwner != null && !snowU_VsOwner.toString().isEmpty()) jsonObject.put("u_vs_owner", snowU_VsOwner);
		if (snowU_VsProvisionedSpace != null && !snowU_VsProvisionedSpace.toString().isEmpty()) jsonObject.put("u_vs_provisioned_space", snowU_VsProvisionedSpace);
		if (snowU_VsRole != null && !snowU_VsRole.toString().isEmpty()) jsonObject.put("u_vs_role", snowU_VsRole);
		if (snowU_VsState != null && !snowU_VsState.toString().isEmpty()) jsonObject.put("u_vs_state", snowU_VsState);
		if (snowU_VsStatus != null && !snowU_VsStatus.toString().isEmpty()) jsonObject.put("u_vs_status", snowU_VsStatus);
		if (snowU_VsUsedSpace != null && !snowU_VsUsedSpace.toString().isEmpty()) jsonObject.put("u_vs_used_space", snowU_VsUsedSpace);
		if (snowU_VsWasType != null && !snowU_VsWasType.toString().isEmpty()) jsonObject.put("u_vs_was_type", snowU_VsWasType);
		if (snowU_WarrantyDate != null && !snowU_WarrantyDate.toString().isEmpty()) jsonObject.put("u_warranty_date", snowU_WarrantyDate);
		if (snowU_WsEnvHostServerHostName != null && !snowU_WsEnvHostServerHostName.toString().isEmpty()) jsonObject.put("u_ws_env_host_server_host_name", snowU_WsEnvHostServerHostName);
		if (snowU_WsEnvServerAppFileDate != null && !snowU_WsEnvServerAppFileDate.toString().isEmpty()) jsonObject.put("u_ws_env_server_app_file_date", snowU_WsEnvServerAppFileDate);
		if (snowU_WsEnvServerAppFileDate2 != null && !snowU_WsEnvServerAppFileDate2.toString().isEmpty()) jsonObject.put("u_ws_env_server_app_file_date2", snowU_WsEnvServerAppFileDate2);
		if (snowU_WsEnvironmentHostServerA != null && !snowU_WsEnvironmentHostServerA.toString().isEmpty()) jsonObject.put("u_ws_environment_host_server_a", snowU_WsEnvironmentHostServerA);
		if (snowU_WsEnvironmentHostServerI != null && !snowU_WsEnvironmentHostServerI.toString().isEmpty()) jsonObject.put("u_ws_environment_host_server_i", snowU_WsEnvironmentHostServerI);
		if (snowU_WsEnvironmentId != null && !snowU_WsEnvironmentId.toString().isEmpty()) jsonObject.put("u_ws_environment_id", snowU_WsEnvironmentId);
		if (snowU_WsEnvironmentName != null && !snowU_WsEnvironmentName.toString().isEmpty()) jsonObject.put("u_ws_environment_name", snowU_WsEnvironmentName);
		if (snowU_WsExtractDate != null && !snowU_WsExtractDate.toString().isEmpty()) jsonObject.put("u_ws_extract_date", snowU_WsExtractDate);
		if (snowU_WsExtractDate2 != null && !snowU_WsExtractDate2.toString().isEmpty()) jsonObject.put("u_ws_extract_date2", snowU_WsExtractDate2);
		if (snowUnverified != null && !snowUnverified.toString().isEmpty()) jsonObject.put("unverified", snowUnverified);
		if (snowVendor != null && !snowVendor.toString().isEmpty()) jsonObject.put("vendor", snowVendor);
		if (snowWarrantyExpiration != null && !snowWarrantyExpiration.toString().isEmpty()) jsonObject.put("warranty_expiration", snowWarrantyExpiration);
		
		return jsonObject;
	}

	public String getSnowAsset() {
		return snowAsset;
	}

	public void setSnowAsset(String snowAsset) {
		this.snowAsset = snowAsset;
	}

	public String getSnowAssetTag() {
		return snowAssetTag;
	}

	public void setSnowAssetTag(String snowAssetTag) {
		this.snowAssetTag = snowAssetTag;
	}

	public String getSnowAssigned() {
		return snowAssigned;
	}

	public void setSnowAssigned(String snowAssigned) {
		this.snowAssigned = snowAssigned;
	}

	public String getSnowAssignedTo() {
		return snowAssignedTo;
	}

	public void setSnowAssignedTo(String snowAssignedTo) {
		this.snowAssignedTo = snowAssignedTo;
	}

	public String getSnowAssignmentGroup() {
		return snowAssignmentGroup;
	}

	public void setSnowAssignmentGroup(String snowAssignmentGroup) {
		this.snowAssignmentGroup = snowAssignmentGroup;
	}

	public String getSnowAttributes() {
		return snowAttributes;
	}

	public void setSnowAttributes(String snowAttributes) {
		this.snowAttributes = snowAttributes;
	}

	public String getSnowBusinesCriticality() {
		return snowBusinesCriticality;
	}

	public void setSnowBusinesCriticality(String snowBusinesCriticality) {
		this.snowBusinesCriticality = snowBusinesCriticality;
	}

	public String getSnowCanPrint() {
		return snowCanPrint;
	}

	public void setSnowCanPrint(String snowCanPrint) {
		this.snowCanPrint = snowCanPrint;
	}

	public String getSnowCategory() {
		return snowCategory;
	}

	public void setSnowCategory(String snowCategory) {
		this.snowCategory = snowCategory;
	}

	public String getSnowChangeControl() {
		return snowChangeControl;
	}

	public void setSnowChangeControl(String snowChangeControl) {
		this.snowChangeControl = snowChangeControl;
	}

	public String getSnowCheckedIn() {
		return snowCheckedIn;
	}

	public void setSnowCheckedIn(String snowCheckedIn) {
		this.snowCheckedIn = snowCheckedIn;
	}

	public String getSnowCheckedOut() {
		return snowCheckedOut;
	}

	public void setSnowCheckedOut(String snowCheckedOut) {
		this.snowCheckedOut = snowCheckedOut;
	}

	public String getSnowComments() {
		return snowComments;
	}

	public void setSnowComments(String snowComments) {
		this.snowComments = snowComments;
	}

	public String getSnowCompany() {
		return snowCompany;
	}

	public void setSnowCompany(String snowCompany) {
		this.snowCompany = snowCompany;
	}

	public String getSnowCorrelationId() {
		return snowCorrelationId;
	}

	public void setSnowCorrelationId(String snowCorrelationId) {
		this.snowCorrelationId = snowCorrelationId;
	}

	public String getSnowCost() {
		return snowCost;
	}

	public void setSnowCost(String snowCost) {
		this.snowCost = snowCost;
	}

	public String getSnowCostCc() {
		return snowCostCc;
	}

	public void setSnowCostCc(String snowCostCc) {
		this.snowCostCc = snowCostCc;
	}

	public String getSnowCostCenter() {
		return snowCostCenter;
	}

	public void setSnowCostCenter(String snowCostCenter) {
		this.snowCostCenter = snowCostCenter;
	}

	public String getSnowDeliveryDate() {
		return snowDeliveryDate;
	}

	public void setSnowDeliveryDate(String snowDeliveryDate) {
		this.snowDeliveryDate = snowDeliveryDate;
	}

	public String getSnowDepartment() {
		return snowDepartment;
	}

	public void setSnowDepartment(String snowDepartment) {
		this.snowDepartment = snowDepartment;
	}

	public String getSnowDiscoverySource() {
		return snowDiscoverySource;
	}

	public void setSnowDiscoverySource(String snowDiscoverySource) {
		this.snowDiscoverySource = snowDiscoverySource;
	}

	public String getSnowDnsDomain() {
		return snowDnsDomain;
	}

	public void setSnowDnsDomain(String snowDnsDomain) {
		this.snowDnsDomain = snowDnsDomain;
	}

	public String getSnowDue() {
		return snowDue;
	}

	public void setSnowDue(String snowDue) {
		this.snowDue = snowDue;
	}

	public String getSnowDueIn() {
		return snowDueIn;
	}

	public void setSnowDueIn(String snowDueIn) {
		this.snowDueIn = snowDueIn;
	}

	public String getSnowFaultCount() {
		return snowFaultCount;
	}

	public void setSnowFaultCount(String snowFaultCount) {
		this.snowFaultCount = snowFaultCount;
	}

	public String getSnowFirstDiscovered() {
		return snowFirstDiscovered;
	}

	public void setSnowFirstDiscovered(String snowFirstDiscovered) {
		this.snowFirstDiscovered = snowFirstDiscovered;
	}

	public String getSnowFqdn() {
		return snowFqdn;
	}

	public void setSnowFqdn(String snowFqdn) {
		this.snowFqdn = snowFqdn;
	}

	public String getSnowGlAccount() {
		return snowGlAccount;
	}

	public void setSnowGlAccount(String snowGlAccount) {
		this.snowGlAccount = snowGlAccount;
	}

	public String getSnowInstallDate() {
		return snowInstallDate;
	}

	public void setSnowInstallDate(String snowInstallDate) {
		this.snowInstallDate = snowInstallDate;
	}

	public String getSnowInstallStatus() {
		return snowInstallStatus;
	}

	public void setSnowInstallStatus(String snowInstallStatus) {
		this.snowInstallStatus = snowInstallStatus;
	}

	public String getSnowInvoiceNumber() {
		return snowInvoiceNumber;
	}

	public void setSnowInvoiceNumber(String snowInvoiceNumber) {
		this.snowInvoiceNumber = snowInvoiceNumber;
	}

	public String getSnowIpAddress() {
		return snowIpAddress;
	}

	public void setSnowIpAddress(String snowIpAddress) {
		this.snowIpAddress = snowIpAddress;
	}

	public String getSnowJustification() {
		return snowJustification;
	}

	public void setSnowJustification(String snowJustification) {
		this.snowJustification = snowJustification;
	}

	public String getSnowLastDiscovered() {
		return snowLastDiscovered;
	}

	public void setSnowLastDiscovered(String snowLastDiscovered) {
		this.snowLastDiscovered = snowLastDiscovered;
	}

	public String getSnowLeaseId() {
		return snowLeaseId;
	}

	public void setSnowLeaseId(String snowLeaseId) {
		this.snowLeaseId = snowLeaseId;
	}

	public String getSnowLocation() {
		return snowLocation;
	}

	public void setSnowLocation(String snowLocation) {
		this.snowLocation = snowLocation;
	}

	public String getSnowMacAddress() {
		return snowMacAddress;
	}

	public void setSnowMacAddress(String snowMacAddress) {
		this.snowMacAddress = snowMacAddress;
	}

	public String getSnowMaintenanceSchedule() {
		return snowMaintenanceSchedule;
	}

	public void setSnowMaintenanceSchedule(String snowMaintenanceSchedule) {
		this.snowMaintenanceSchedule = snowMaintenanceSchedule;
	}

	public String getSnowManagedBy() {
		return snowManagedBy;
	}

	public void setSnowManagedBy(String snowManagedBy) {
		this.snowManagedBy = snowManagedBy;
	}

	public String getSnowManufacturer() {
		return snowManufacturer;
	}

	public void setSnowManufacturer(String snowManufacturer) {
		this.snowManufacturer = snowManufacturer;
	}

	public String getSnowModelId() {
		return snowModelId;
	}

	public void setSnowModelId(String snowModelId) {
		this.snowModelId = snowModelId;
	}

	public String getSnowModelNumber() {
		return snowModelNumber;
	}

	public void setSnowModelNumber(String snowModelNumber) {
		this.snowModelNumber = snowModelNumber;
	}

	public String getSnowMonitor() {
		return snowMonitor;
	}

	public void setSnowMonitor(String snowMonitor) {
		this.snowMonitor = snowMonitor;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowOperationalStatus() {
		return snowOperationalStatus;
	}

	public void setSnowOperationalStatus(String snowOperationalStatus) {
		this.snowOperationalStatus = snowOperationalStatus;
	}

	public String getSnowOrderDate() {
		return snowOrderDate;
	}

	public void setSnowOrderDate(String snowOrderDate) {
		this.snowOrderDate = snowOrderDate;
	}

	public String getSnowOwnedBy() {
		return snowOwnedBy;
	}

	public void setSnowOwnedBy(String snowOwnedBy) {
		this.snowOwnedBy = snowOwnedBy;
	}

	public String getSnowPoNumber() {
		return snowPoNumber;
	}

	public void setSnowPoNumber(String snowPoNumber) {
		this.snowPoNumber = snowPoNumber;
	}

	public String getSnowPurchaseDate() {
		return snowPurchaseDate;
	}

	public void setSnowPurchaseDate(String snowPurchaseDate) {
		this.snowPurchaseDate = snowPurchaseDate;
	}

	public String getSnowRepairContractId() {
		return snowRepairContractId;
	}

	public void setSnowRepairContractId(String snowRepairContractId) {
		this.snowRepairContractId = snowRepairContractId;
	}

	public String getSnowReturnedFromRepair() {
		return snowReturnedFromRepair;
	}

	public void setSnowReturnedFromRepair(String snowReturnedFromRepair) {
		this.snowReturnedFromRepair = snowReturnedFromRepair;
	}

	public String getSnowSchedule() {
		return snowSchedule;
	}

	public void setSnowSchedule(String snowSchedule) {
		this.snowSchedule = snowSchedule;
	}

	public String getSnowSentForRepair() {
		return snowSentForRepair;
	}

	public void setSnowSentForRepair(String snowSentForRepair) {
		this.snowSentForRepair = snowSentForRepair;
	}

	public String getSnowSerialNumber() {
		return snowSerialNumber;
	}

	public void setSnowSerialNumber(String snowSerialNumber) {
		this.snowSerialNumber = snowSerialNumber;
	}

	public String getSnowShortDescription() {
		return snowShortDescription;
	}

	public void setSnowShortDescription(String snowShortDescription) {
		this.snowShortDescription = snowShortDescription;
	}

	public String getSnowSkipSync() {
		return snowSkipSync;
	}

	public void setSnowSkipSync(String snowSkipSync) {
		this.snowSkipSync = snowSkipSync;
	}

	public String getSnowStartDate() {
		return snowStartDate;
	}

	public void setSnowStartDate(String snowStartDate) {
		this.snowStartDate = snowStartDate;
	}

	public String getSnowSubcategory() {
		return snowSubcategory;
	}

	public void setSnowSubcategory(String snowSubcategory) {
		this.snowSubcategory = snowSubcategory;
	}

	public String getSnowSupportGroup() {
		return snowSupportGroup;
	}

	public void setSnowSupportGroup(String snowSupportGroup) {
		this.snowSupportGroup = snowSupportGroup;
	}

	public String getSnowSupportedBy() {
		return snowSupportedBy;
	}

	public void setSnowSupportedBy(String snowSupportedBy) {
		this.snowSupportedBy = snowSupportedBy;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysDomain() {
		return snowSysDomain;
	}

	public void setSnowSysDomain(String snowSysDomain) {
		this.snowSysDomain = snowSysDomain;
	}

	public String getSnowSysDomainPath() {
		return snowSysDomainPath;
	}

	public void setSnowSysDomainPath(String snowSysDomainPath) {
		this.snowSysDomainPath = snowSysDomainPath;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowU_AcquiredDate() {
		return snowU_AcquiredDate;
	}

	public void setSnowU_AcquiredDate(String snowU_AcquiredDate) {
		this.snowU_AcquiredDate = snowU_AcquiredDate;
	}

	public String getSnowU_ApplicationCode() {
		return snowU_ApplicationCode;
	}

	public void setSnowU_ApplicationCode(String snowU_ApplicationCode) {
		this.snowU_ApplicationCode = snowU_ApplicationCode;
	}

	public String getSnowU_ApplicationServiceOwner() {
		return snowU_ApplicationServiceOwner;
	}

	public void setSnowU_ApplicationServiceOwner(String snowU_ApplicationServiceOwner) {
		this.snowU_ApplicationServiceOwner = snowU_ApplicationServiceOwner;
	}

	public String getSnowU_Apps() {
		return snowU_Apps;
	}

	public void setSnowU_Apps(String snowU_Apps) {
		this.snowU_Apps = snowU_Apps;
	}

	public String getSnowU_AssetLifeMonths() {
		return snowU_AssetLifeMonths;
	}

	public void setSnowU_AssetLifeMonths(String snowU_AssetLifeMonths) {
		this.snowU_AssetLifeMonths = snowU_AssetLifeMonths;
	}

	public String getSnowU_Blocked() {
		return snowU_Blocked;
	}

	public void setSnowU_Blocked(String snowU_Blocked) {
		this.snowU_Blocked = snowU_Blocked;
	}

	public String getSnowU_Brand() {
		return snowU_Brand;
	}

	public void setSnowU_Brand(String snowU_Brand) {
		this.snowU_Brand = snowU_Brand;
	}

	public String getSnowU_BusinessServiceOwner() {
		return snowU_BusinessServiceOwner;
	}

	public void setSnowU_BusinessServiceOwner(String snowU_BusinessServiceOwner) {
		this.snowU_BusinessServiceOwner = snowU_BusinessServiceOwner;
	}

	public String getSnowU_C3Component() {
		return snowU_C3Component;
	}

	public void setSnowU_C3Component(String snowU_C3Component) {
		this.snowU_C3Component = snowU_C3Component;
	}

	public String getSnowU_Cell() {
		return snowU_Cell;
	}

	public void setSnowU_Cell(String snowU_Cell) {
		this.snowU_Cell = snowU_Cell;
	}

	public String getSnowU_Charge() {
		return snowU_Charge;
	}

	public void setSnowU_Charge(String snowU_Charge) {
		this.snowU_Charge = snowU_Charge;
	}

	public String getSnowU_CirEir() {
		return snowU_CirEir;
	}

	public void setSnowU_CirEir(String snowU_CirEir) {
		this.snowU_CirEir = snowU_CirEir;
	}

	public String getSnowU_CircuitAccessSpeed() {
		return snowU_CircuitAccessSpeed;
	}

	public void setSnowU_CircuitAccessSpeed(String snowU_CircuitAccessSpeed) {
		this.snowU_CircuitAccessSpeed = snowU_CircuitAccessSpeed;
	}

	public String getSnowU_CisuAdditionalInformation() {
		return snowU_CisuAdditionalInformation;
	}

	public void setSnowU_CisuAdditionalInformation(String snowU_CisuAdditionalInformation) {
		this.snowU_CisuAdditionalInformation = snowU_CisuAdditionalInformation;
	}

	public String getSnowU_CisuApplicationServiceOwn() {
		return snowU_CisuApplicationServiceOwn;
	}

	public void setSnowU_CisuApplicationServiceOwn(String snowU_CisuApplicationServiceOwn) {
		this.snowU_CisuApplicationServiceOwn = snowU_CisuApplicationServiceOwn;
	}

	public String getSnowU_CisuAudit() {
		return snowU_CisuAudit;
	}

	public void setSnowU_CisuAudit(String snowU_CisuAudit) {
		this.snowU_CisuAudit = snowU_CisuAudit;
	}

	public String getSnowU_CisuAuditDate() {
		return snowU_CisuAuditDate;
	}

	public void setSnowU_CisuAuditDate(String snowU_CisuAuditDate) {
		this.snowU_CisuAuditDate = snowU_CisuAuditDate;
	}

	public String getSnowU_CisuAuditor() {
		return snowU_CisuAuditor;
	}

	public void setSnowU_CisuAuditor(String snowU_CisuAuditor) {
		this.snowU_CisuAuditor = snowU_CisuAuditor;
	}

	public String getSnowU_CisuBusinessServiceOwner() {
		return snowU_CisuBusinessServiceOwner;
	}

	public void setSnowU_CisuBusinessServiceOwner(String snowU_CisuBusinessServiceOwner) {
		this.snowU_CisuBusinessServiceOwner = snowU_CisuBusinessServiceOwner;
	}

	public String getSnowU_CisuComment() {
		return snowU_CisuComment;
	}

	public void setSnowU_CisuComment(String snowU_CisuComment) {
		this.snowU_CisuComment = snowU_CisuComment;
	}

	public String getSnowU_CisuImportSource() {
		return snowU_CisuImportSource;
	}

	public void setSnowU_CisuImportSource(String snowU_CisuImportSource) {
		this.snowU_CisuImportSource = snowU_CisuImportSource;
	}

	public String getSnowU_CisuMainUnderpinningServi() {
		return snowU_CisuMainUnderpinningServi;
	}

	public void setSnowU_CisuMainUnderpinningServi(String snowU_CisuMainUnderpinningServi) {
		this.snowU_CisuMainUnderpinningServi = snowU_CisuMainUnderpinningServi;
	}

	public String getSnowU_CisuMatchingHostnames() {
		return snowU_CisuMatchingHostnames;
	}

	public void setSnowU_CisuMatchingHostnames(String snowU_CisuMatchingHostnames) {
		this.snowU_CisuMatchingHostnames = snowU_CisuMatchingHostnames;
	}

	public String getSnowU_CisuRack() {
		return snowU_CisuRack;
	}

	public void setSnowU_CisuRack(String snowU_CisuRack) {
		this.snowU_CisuRack = snowU_CisuRack;
	}

	public String getSnowU_CisuRecoveryPriority() {
		return snowU_CisuRecoveryPriority;
	}

	public void setSnowU_CisuRecoveryPriority(String snowU_CisuRecoveryPriority) {
		this.snowU_CisuRecoveryPriority = snowU_CisuRecoveryPriority;
	}

	public String getSnowU_CisuRoom() {
		return snowU_CisuRoom;
	}

	public void setSnowU_CisuRoom(String snowU_CisuRoom) {
		this.snowU_CisuRoom = snowU_CisuRoom;
	}

	public String getSnowU_CisuServer() {
		return snowU_CisuServer;
	}

	public void setSnowU_CisuServer(String snowU_CisuServer) {
		this.snowU_CisuServer = snowU_CisuServer;
	}

	public String getSnowU_CisuServiceAffected() {
		return snowU_CisuServiceAffected;
	}

	public void setSnowU_CisuServiceAffected(String snowU_CisuServiceAffected) {
		this.snowU_CisuServiceAffected = snowU_CisuServiceAffected;
	}

	public String getSnowU_CisuTechnicalServiceOwner() {
		return snowU_CisuTechnicalServiceOwner;
	}

	public void setSnowU_CisuTechnicalServiceOwner(String snowU_CisuTechnicalServiceOwner) {
		this.snowU_CisuTechnicalServiceOwner = snowU_CisuTechnicalServiceOwner;
	}

	public String getSnowU_CisuTsoPointOfContact() {
		return snowU_CisuTsoPointOfContact;
	}

	public void setSnowU_CisuTsoPointOfContact(String snowU_CisuTsoPointOfContact) {
		this.snowU_CisuTsoPointOfContact = snowU_CisuTsoPointOfContact;
	}

	public String getSnowU_CisuUpdated() {
		return snowU_CisuUpdated;
	}

	public void setSnowU_CisuUpdated(String snowU_CisuUpdated) {
		this.snowU_CisuUpdated = snowU_CisuUpdated;
	}

	public String getSnowU_CisuUpdatesBy() {
		return snowU_CisuUpdatesBy;
	}

	public void setSnowU_CisuUpdatesBy(String snowU_CisuUpdatesBy) {
		this.snowU_CisuUpdatesBy = snowU_CisuUpdatesBy;
	}

	public String getSnowU_CisuVm() {
		return snowU_CisuVm;
	}

	public void setSnowU_CisuVm(String snowU_CisuVm) {
		this.snowU_CisuVm = snowU_CisuVm;
	}

	public String getSnowU_Classification() {
		return snowU_Classification;
	}

	public void setSnowU_Classification(String snowU_Classification) {
		this.snowU_Classification = snowU_Classification;
	}

	public String getSnowU_Cluster() {
		return snowU_Cluster;
	}

	public void setSnowU_Cluster(String snowU_Cluster) {
		this.snowU_Cluster = snowU_Cluster;
	}

	public String getSnowU_DecommissionDate() {
		return snowU_DecommissionDate;
	}

	public void setSnowU_DecommissionDate(String snowU_DecommissionDate) {
		this.snowU_DecommissionDate = snowU_DecommissionDate;
	}

	public String getSnowU_DetailedName() {
		return snowU_DetailedName;
	}

	public void setSnowU_DetailedName(String snowU_DetailedName) {
		this.snowU_DetailedName = snowU_DetailedName;
	}

	public String getSnowU_DiscontinuedDate() {
		return snowU_DiscontinuedDate;
	}

	public void setSnowU_DiscontinuedDate(String snowU_DiscontinuedDate) {
		this.snowU_DiscontinuedDate = snowU_DiscontinuedDate;
	}

	public String getSnowU_Emphasise() {
		return snowU_Emphasise;
	}

	public void setSnowU_Emphasise(String snowU_Emphasise) {
		this.snowU_Emphasise = snowU_Emphasise;
	}

	public String getSnowU_Envprops() {
		return snowU_Envprops;
	}

	public void setSnowU_Envprops(String snowU_Envprops) {
		this.snowU_Envprops = snowU_Envprops;
	}

	public String getSnowU_FinancialAsset() {
		return snowU_FinancialAsset;
	}

	public void setSnowU_FinancialAsset(String snowU_FinancialAsset) {
		this.snowU_FinancialAsset = snowU_FinancialAsset;
	}

	public String getSnowU_Folder() {
		return snowU_Folder;
	}

	public void setSnowU_Folder(String snowU_Folder) {
		this.snowU_Folder = snowU_Folder;
	}

	public String getSnowU_Host() {
		return snowU_Host;
	}

	public void setSnowU_Host(String snowU_Host) {
		this.snowU_Host = snowU_Host;
	}

	public String getSnowU_HostnameCircuitRef() {
		return snowU_HostnameCircuitRef;
	}

	public void setSnowU_HostnameCircuitRef(String snowU_HostnameCircuitRef) {
		this.snowU_HostnameCircuitRef = snowU_HostnameCircuitRef;
	}

	public String getSnowU_HpsdAcquiredDate() {
		return snowU_HpsdAcquiredDate;
	}

	public void setSnowU_HpsdAcquiredDate(String snowU_HpsdAcquiredDate) {
		this.snowU_HpsdAcquiredDate = snowU_HpsdAcquiredDate;
	}

	public String getSnowU_HpsdCreatedDate_Time() {
		return snowU_HpsdCreatedDate_Time;
	}

	public void setSnowU_HpsdCreatedDate_Time(String snowU_HpsdCreatedDate_Time) {
		this.snowU_HpsdCreatedDate_Time = snowU_HpsdCreatedDate_Time;
	}

	public String getSnowU_HpsdCreatedDateTime() {
		return snowU_HpsdCreatedDateTime;
	}

	public void setSnowU_HpsdCreatedDateTime(String snowU_HpsdCreatedDateTime) {
		this.snowU_HpsdCreatedDateTime = snowU_HpsdCreatedDateTime;
	}

	public String getSnowU_HpsdDecomminssionDate() {
		return snowU_HpsdDecomminssionDate;
	}

	public void setSnowU_HpsdDecomminssionDate(String snowU_HpsdDecomminssionDate) {
		this.snowU_HpsdDecomminssionDate = snowU_HpsdDecomminssionDate;
	}

	public String getSnowU_HpsdDiscontinuedDate() {
		return snowU_HpsdDiscontinuedDate;
	}

	public void setSnowU_HpsdDiscontinuedDate(String snowU_HpsdDiscontinuedDate) {
		this.snowU_HpsdDiscontinuedDate = snowU_HpsdDiscontinuedDate;
	}

	public String getSnowU_HpsdItemType() {
		return snowU_HpsdItemType;
	}

	public void setSnowU_HpsdItemType(String snowU_HpsdItemType) {
		this.snowU_HpsdItemType = snowU_HpsdItemType;
	}

	public String getSnowU_HpsdLastReviewAuditDate() {
		return snowU_HpsdLastReviewAuditDate;
	}

	public void setSnowU_HpsdLastReviewAuditDate(String snowU_HpsdLastReviewAuditDate) {
		this.snowU_HpsdLastReviewAuditDate = snowU_HpsdLastReviewAuditDate;
	}

	public String getSnowU_HpsdOrderDate() {
		return snowU_HpsdOrderDate;
	}

	public void setSnowU_HpsdOrderDate(String snowU_HpsdOrderDate) {
		this.snowU_HpsdOrderDate = snowU_HpsdOrderDate;
	}

	public String getSnowU_HpsdPurchaseDate() {
		return snowU_HpsdPurchaseDate;
	}

	public void setSnowU_HpsdPurchaseDate(String snowU_HpsdPurchaseDate) {
		this.snowU_HpsdPurchaseDate = snowU_HpsdPurchaseDate;
	}

	public String getSnowU_HpsdSnStatus() {
		return snowU_HpsdSnStatus;
	}

	public void setSnowU_HpsdSnStatus(String snowU_HpsdSnStatus) {
		this.snowU_HpsdSnStatus = snowU_HpsdSnStatus;
	}

	public String getSnowU_HpsdWarrantyDate() {
		return snowU_HpsdWarrantyDate;
	}

	public void setSnowU_HpsdWarrantyDate(String snowU_HpsdWarrantyDate) {
		this.snowU_HpsdWarrantyDate = snowU_HpsdWarrantyDate;
	}

	public String getSnowU_IncidentPriority() {
		return snowU_IncidentPriority;
	}

	public void setSnowU_IncidentPriority(String snowU_IncidentPriority) {
		this.snowU_IncidentPriority = snowU_IncidentPriority;
	}

	public String getSnowU_InvalidSearchCode() {
		return snowU_InvalidSearchCode;
	}

	public void setSnowU_InvalidSearchCode(String snowU_InvalidSearchCode) {
		this.snowU_InvalidSearchCode = snowU_InvalidSearchCode;
	}

	public String getSnowU_KeyA() {
		return snowU_KeyA;
	}

	public void setSnowU_KeyA(String snowU_KeyA) {
		this.snowU_KeyA = snowU_KeyA;
	}

	public String getSnowU_KeyB() {
		return snowU_KeyB;
	}

	public void setSnowU_KeyB(String snowU_KeyB) {
		this.snowU_KeyB = snowU_KeyB;
	}

	public String getSnowU_KeyC() {
		return snowU_KeyC;
	}

	public void setSnowU_KeyC(String snowU_KeyC) {
		this.snowU_KeyC = snowU_KeyC;
	}

	public String getSnowU_LastImport() {
		return snowU_LastImport;
	}

	public void setSnowU_LastImport(String snowU_LastImport) {
		this.snowU_LastImport = snowU_LastImport;
	}

	public String getSnowU_LastReviewAuditDate() {
		return snowU_LastReviewAuditDate;
	}

	public void setSnowU_LastReviewAuditDate(String snowU_LastReviewAuditDate) {
		this.snowU_LastReviewAuditDate = snowU_LastReviewAuditDate;
	}

	public String getSnowU_MaintenanceContract() {
		return snowU_MaintenanceContract;
	}

	public void setSnowU_MaintenanceContract(String snowU_MaintenanceContract) {
		this.snowU_MaintenanceContract = snowU_MaintenanceContract;
	}

	public String getSnowU_Manager() {
		return snowU_Manager;
	}

	public void setSnowU_Manager(String snowU_Manager) {
		this.snowU_Manager = snowU_Manager;
	}

	public String getSnowU_MatchingHostnames() {
		return snowU_MatchingHostnames;
	}

	public void setSnowU_MatchingHostnames(String snowU_MatchingHostnames) {
		this.snowU_MatchingHostnames = snowU_MatchingHostnames;
	}

	public String getSnowU_MaxInstallations() {
		return snowU_MaxInstallations;
	}

	public void setSnowU_MaxInstallations(String snowU_MaxInstallations) {
		this.snowU_MaxInstallations = snowU_MaxInstallations;
	}

	public String getSnowU_Node() {
		return snowU_Node;
	}

	public void setSnowU_Node(String snowU_Node) {
		this.snowU_Node = snowU_Node;
	}

	public String getSnowU_NodeType() {
		return snowU_NodeType;
	}

	public void setSnowU_NodeType(String snowU_NodeType) {
		this.snowU_NodeType = snowU_NodeType;
	}

	public String getSnowU_OrderDate() {
		return snowU_OrderDate;
	}

	public void setSnowU_OrderDate(String snowU_OrderDate) {
		this.snowU_OrderDate = snowU_OrderDate;
	}

	public String getSnowU_OutsourcedTo() {
		return snowU_OutsourcedTo;
	}

	public void setSnowU_OutsourcedTo(String snowU_OutsourcedTo) {
		this.snowU_OutsourcedTo = snowU_OutsourcedTo;
	}

	public String getSnowU_Owner() {
		return snowU_Owner;
	}

	public void setSnowU_Owner(String snowU_Owner) {
		this.snowU_Owner = snowU_Owner;
	}

	public String getSnowU_OwnerOrganisation() {
		return snowU_OwnerOrganisation;
	}

	public void setSnowU_OwnerOrganisation(String snowU_OwnerOrganisation) {
		this.snowU_OwnerOrganisation = snowU_OwnerOrganisation;
	}

	public String getSnowU_OwnerPerson() {
		return snowU_OwnerPerson;
	}

	public void setSnowU_OwnerPerson(String snowU_OwnerPerson) {
		this.snowU_OwnerPerson = snowU_OwnerPerson;
	}

	public String getSnowU_Pac() {
		return snowU_Pac;
	}

	public void setSnowU_Pac(String snowU_Pac) {
		this.snowU_Pac = snowU_Pac;
	}

	public String getSnowU_PortalVersion() {
		return snowU_PortalVersion;
	}

	public void setSnowU_PortalVersion(String snowU_PortalVersion) {
		this.snowU_PortalVersion = snowU_PortalVersion;
	}

	public String getSnowU_Price() {
		return snowU_Price;
	}

	public void setSnowU_Price(String snowU_Price) {
		this.snowU_Price = snowU_Price;
	}

	public String getSnowU_Profile() {
		return snowU_Profile;
	}

	public void setSnowU_Profile(String snowU_Profile) {
		this.snowU_Profile = snowU_Profile;
	}

	public String getSnowU_PurchaseDate() {
		return snowU_PurchaseDate;
	}

	public void setSnowU_PurchaseDate(String snowU_PurchaseDate) {
		this.snowU_PurchaseDate = snowU_PurchaseDate;
	}

	public String getSnowU_Remark() {
		return snowU_Remark;
	}

	public void setSnowU_Remark(String snowU_Remark) {
		this.snowU_Remark = snowU_Remark;
	}

	public String getSnowU_SapNumber() {
		return snowU_SapNumber;
	}

	public void setSnowU_SapNumber(String snowU_SapNumber) {
		this.snowU_SapNumber = snowU_SapNumber;
	}

	public String getSnowU_SearchCode() {
		return snowU_SearchCode;
	}

	public void setSnowU_SearchCode(String snowU_SearchCode) {
		this.snowU_SearchCode = snowU_SearchCode;
	}

	public String getSnowU_Server() {
		return snowU_Server;
	}

	public void setSnowU_Server(String snowU_Server) {
		this.snowU_Server = snowU_Server;
	}

	public String getSnowU_ServerType() {
		return snowU_ServerType;
	}

	public void setSnowU_ServerType(String snowU_ServerType) {
		this.snowU_ServerType = snowU_ServerType;
	}

	public String getSnowU_ServiceLevel() {
		return snowU_ServiceLevel;
	}

	public void setSnowU_ServiceLevel(String snowU_ServiceLevel) {
		this.snowU_ServiceLevel = snowU_ServiceLevel;
	}

	public String getSnowU_ServiceLevelClass() {
		return snowU_ServiceLevelClass;
	}

	public void setSnowU_ServiceLevelClass(String snowU_ServiceLevelClass) {
		this.snowU_ServiceLevelClass = snowU_ServiceLevelClass;
	}

	public String getSnowU_ServiceTower() {
		return snowU_ServiceTower;
	}

	public void setSnowU_ServiceTower(String snowU_ServiceTower) {
		this.snowU_ServiceTower = snowU_ServiceTower;
	}

	public String getSnowU_ServiceType() {
		return snowU_ServiceType;
	}

	public void setSnowU_ServiceType(String snowU_ServiceType) {
		this.snowU_ServiceType = snowU_ServiceType;
	}

	public String getSnowU_SourceId() {
		return snowU_SourceId;
	}

	public void setSnowU_SourceId(String snowU_SourceId) {
		this.snowU_SourceId = snowU_SourceId;
	}

	public String getSnowU_Subclassification() {
		return snowU_Subclassification;
	}

	public void setSnowU_Subclassification(String snowU_Subclassification) {
		this.snowU_Subclassification = snowU_Subclassification;
	}

	public String getSnowU_SupplierOrganisation() {
		return snowU_SupplierOrganisation;
	}

	public void setSnowU_SupplierOrganisation(String snowU_SupplierOrganisation) {
		this.snowU_SupplierOrganisation = snowU_SupplierOrganisation;
	}

	public String getSnowU_SupportOrganization() {
		return snowU_SupportOrganization;
	}

	public void setSnowU_SupportOrganization(String snowU_SupportOrganization) {
		this.snowU_SupportOrganization = snowU_SupportOrganization;
	}

	public String getSnowU_SupportPerson() {
		return snowU_SupportPerson;
	}

	public void setSnowU_SupportPerson(String snowU_SupportPerson) {
		this.snowU_SupportPerson = snowU_SupportPerson;
	}

	public String getSnowU_SupportRota() {
		return snowU_SupportRota;
	}

	public void setSnowU_SupportRota(String snowU_SupportRota) {
		this.snowU_SupportRota = snowU_SupportRota;
	}

	public String getSnowU_SupportWorkgroup() {
		return snowU_SupportWorkgroup;
	}

	public void setSnowU_SupportWorkgroup(String snowU_SupportWorkgroup) {
		this.snowU_SupportWorkgroup = snowU_SupportWorkgroup;
	}

	public String getSnowU_Template() {
		return snowU_Template;
	}

	public void setSnowU_Template(String snowU_Template) {
		this.snowU_Template = snowU_Template;
	}

	public String getSnowU_TntServiceType() {
		return snowU_TntServiceType;
	}

	public void setSnowU_TntServiceType(String snowU_TntServiceType) {
		this.snowU_TntServiceType = snowU_TntServiceType;
	}

	public String getSnowU_Unique() {
		return snowU_Unique;
	}

	public void setSnowU_Unique(String snowU_Unique) {
		this.snowU_Unique = snowU_Unique;
	}

	public String getSnowU_ValidHostnameFormat() {
		return snowU_ValidHostnameFormat;
	}

	public void setSnowU_ValidHostnameFormat(String snowU_ValidHostnameFormat) {
		this.snowU_ValidHostnameFormat = snowU_ValidHostnameFormat;
	}

	public String getSnowU_Version() {
		return snowU_Version;
	}

	public void setSnowU_Version(String snowU_Version) {
		this.snowU_Version = snowU_Version;
	}

	public String getSnowU_Vista3RdPartyDetails() {
		return snowU_Vista3RdPartyDetails;
	}

	public void setSnowU_Vista3RdPartyDetails(String snowU_Vista3RdPartyDetails) {
		this.snowU_Vista3RdPartyDetails = snowU_Vista3RdPartyDetails;
	}

	public String getSnowU_VistaAcquiredDate() {
		return snowU_VistaAcquiredDate;
	}

	public void setSnowU_VistaAcquiredDate(String snowU_VistaAcquiredDate) {
		this.snowU_VistaAcquiredDate = snowU_VistaAcquiredDate;
	}

	public String getSnowU_VistaApproxNoOfUsers() {
		return snowU_VistaApproxNoOfUsers;
	}

	public void setSnowU_VistaApproxNoOfUsers(String snowU_VistaApproxNoOfUsers) {
		this.snowU_VistaApproxNoOfUsers = snowU_VistaApproxNoOfUsers;
	}

	public String getSnowU_VistaAssetLinkedToSap() {
		return snowU_VistaAssetLinkedToSap;
	}

	public void setSnowU_VistaAssetLinkedToSap(String snowU_VistaAssetLinkedToSap) {
		this.snowU_VistaAssetLinkedToSap = snowU_VistaAssetLinkedToSap;
	}

	public String getSnowU_VistaAssetTag() {
		return snowU_VistaAssetTag;
	}

	public void setSnowU_VistaAssetTag(String snowU_VistaAssetTag) {
		this.snowU_VistaAssetTag = snowU_VistaAssetTag;
	}

	public String getSnowU_VistaAssetValue() {
		return snowU_VistaAssetValue;
	}

	public void setSnowU_VistaAssetValue(String snowU_VistaAssetValue) {
		this.snowU_VistaAssetValue = snowU_VistaAssetValue;
	}

	public String getSnowU_VistaAssetValueUnknown() {
		return snowU_VistaAssetValueUnknown;
	}

	public void setSnowU_VistaAssetValueUnknown(String snowU_VistaAssetValueUnknown) {
		this.snowU_VistaAssetValueUnknown = snowU_VistaAssetValueUnknown;
	}

	public String getSnowU_VistaBusinessCriticality() {
		return snowU_VistaBusinessCriticality;
	}

	public void setSnowU_VistaBusinessCriticality(String snowU_VistaBusinessCriticality) {
		this.snowU_VistaBusinessCriticality = snowU_VistaBusinessCriticality;
	}

	public String getSnowU_VistaLocationTntSiteCode() {
		return snowU_VistaLocationTntSiteCode;
	}

	public void setSnowU_VistaLocationTntSiteCode(String snowU_VistaLocationTntSiteCode) {
		this.snowU_VistaLocationTntSiteCode = snowU_VistaLocationTntSiteCode;
	}

	public String getSnowU_VistaManufacturer() {
		return snowU_VistaManufacturer;
	}

	public void setSnowU_VistaManufacturer(String snowU_VistaManufacturer) {
		this.snowU_VistaManufacturer = snowU_VistaManufacturer;
	}

	public String getSnowU_VistaModelNumber() {
		return snowU_VistaModelNumber;
	}

	public void setSnowU_VistaModelNumber(String snowU_VistaModelNumber) {
		this.snowU_VistaModelNumber = snowU_VistaModelNumber;
	}

	public String getSnowU_VistaName() {
		return snowU_VistaName;
	}

	public void setSnowU_VistaName(String snowU_VistaName) {
		this.snowU_VistaName = snowU_VistaName;
	}

	public String getSnowU_VistaOperatingSystem() {
		return snowU_VistaOperatingSystem;
	}

	public void setSnowU_VistaOperatingSystem(String snowU_VistaOperatingSystem) {
		this.snowU_VistaOperatingSystem = snowU_VistaOperatingSystem;
	}

	public String getSnowU_VistaOperatingSystemVersi() {
		return snowU_VistaOperatingSystemVersi;
	}

	public void setSnowU_VistaOperatingSystemVersi(String snowU_VistaOperatingSystemVersi) {
		this.snowU_VistaOperatingSystemVersi = snowU_VistaOperatingSystemVersi;
	}

	public String getSnowU_VistaOperationalStatus() {
		return snowU_VistaOperationalStatus;
	}

	public void setSnowU_VistaOperationalStatus(String snowU_VistaOperationalStatus) {
		this.snowU_VistaOperationalStatus = snowU_VistaOperationalStatus;
	}

	public String getSnowU_VistaPhysicalOrVirtual() {
		return snowU_VistaPhysicalOrVirtual;
	}

	public void setSnowU_VistaPhysicalOrVirtual(String snowU_VistaPhysicalOrVirtual) {
		this.snowU_VistaPhysicalOrVirtual = snowU_VistaPhysicalOrVirtual;
	}

	public String getSnowU_VistaSerialNumber() {
		return snowU_VistaSerialNumber;
	}

	public void setSnowU_VistaSerialNumber(String snowU_VistaSerialNumber) {
		this.snowU_VistaSerialNumber = snowU_VistaSerialNumber;
	}

	public String getSnowU_VistaServerRole() {
		return snowU_VistaServerRole;
	}

	public void setSnowU_VistaServerRole(String snowU_VistaServerRole) {
		this.snowU_VistaServerRole = snowU_VistaServerRole;
	}

	public String getSnowU_VistaSupport() {
		return snowU_VistaSupport;
	}

	public void setSnowU_VistaSupport(String snowU_VistaSupport) {
		this.snowU_VistaSupport = snowU_VistaSupport;
	}

	public String getSnowU_VsAlarmActions() {
		return snowU_VsAlarmActions;
	}

	public void setSnowU_VsAlarmActions(String snowU_VsAlarmActions) {
		this.snowU_VsAlarmActions = snowU_VsAlarmActions;
	}

	public String getSnowU_VsEnv() {
		return snowU_VsEnv;
	}

	public void setSnowU_VsEnv(String snowU_VsEnv) {
		this.snowU_VsEnv = snowU_VsEnv;
	}

	public String getSnowU_VsGuestMem() {
		return snowU_VsGuestMem;
	}

	public void setSnowU_VsGuestMem(String snowU_VsGuestMem) {
		this.snowU_VsGuestMem = snowU_VsGuestMem;
	}

	public String getSnowU_VsGuestMemPercentage() {
		return snowU_VsGuestMemPercentage;
	}

	public void setSnowU_VsGuestMemPercentage(String snowU_VsGuestMemPercentage) {
		this.snowU_VsGuestMemPercentage = snowU_VsGuestMemPercentage;
	}

	public String getSnowU_VsHost() {
		return snowU_VsHost;
	}

	public void setSnowU_VsHost(String snowU_VsHost) {
		this.snowU_VsHost = snowU_VsHost;
	}

	public String getSnowU_VsHostCpuMhz() {
		return snowU_VsHostCpuMhz;
	}

	public void setSnowU_VsHostCpuMhz(String snowU_VsHostCpuMhz) {
		this.snowU_VsHostCpuMhz = snowU_VsHostCpuMhz;
	}

	public String getSnowU_VsHostMemMb() {
		return snowU_VsHostMemMb;
	}

	public void setSnowU_VsHostMemMb(String snowU_VsHostMemMb) {
		this.snowU_VsHostMemMb = snowU_VsHostMemMb;
	}

	public String getSnowU_VsName() {
		return snowU_VsName;
	}

	public void setSnowU_VsName(String snowU_VsName) {
		this.snowU_VsName = snowU_VsName;
	}

	public String getSnowU_VsNotes() {
		return snowU_VsNotes;
	}

	public void setSnowU_VsNotes(String snowU_VsNotes) {
		this.snowU_VsNotes = snowU_VsNotes;
	}

	public String getSnowU_VsOwner() {
		return snowU_VsOwner;
	}

	public void setSnowU_VsOwner(String snowU_VsOwner) {
		this.snowU_VsOwner = snowU_VsOwner;
	}

	public String getSnowU_VsProvisionedSpace() {
		return snowU_VsProvisionedSpace;
	}

	public void setSnowU_VsProvisionedSpace(String snowU_VsProvisionedSpace) {
		this.snowU_VsProvisionedSpace = snowU_VsProvisionedSpace;
	}

	public String getSnowU_VsRole() {
		return snowU_VsRole;
	}

	public void setSnowU_VsRole(String snowU_VsRole) {
		this.snowU_VsRole = snowU_VsRole;
	}

	public String getSnowU_VsState() {
		return snowU_VsState;
	}

	public void setSnowU_VsState(String snowU_VsState) {
		this.snowU_VsState = snowU_VsState;
	}

	public String getSnowU_VsStatus() {
		return snowU_VsStatus;
	}

	public void setSnowU_VsStatus(String snowU_VsStatus) {
		this.snowU_VsStatus = snowU_VsStatus;
	}

	public String getSnowU_VsUsedSpace() {
		return snowU_VsUsedSpace;
	}

	public void setSnowU_VsUsedSpace(String snowU_VsUsedSpace) {
		this.snowU_VsUsedSpace = snowU_VsUsedSpace;
	}

	public String getSnowU_VsWasType() {
		return snowU_VsWasType;
	}

	public void setSnowU_VsWasType(String snowU_VsWasType) {
		this.snowU_VsWasType = snowU_VsWasType;
	}

	public String getSnowU_WarrantyDate() {
		return snowU_WarrantyDate;
	}

	public void setSnowU_WarrantyDate(String snowU_WarrantyDate) {
		this.snowU_WarrantyDate = snowU_WarrantyDate;
	}

	public String getSnowU_WsEnvHostServerHostName() {
		return snowU_WsEnvHostServerHostName;
	}

	public void setSnowU_WsEnvHostServerHostName(String snowU_WsEnvHostServerHostName) {
		this.snowU_WsEnvHostServerHostName = snowU_WsEnvHostServerHostName;
	}

	public String getSnowU_WsEnvServerAppFileDate() {
		return snowU_WsEnvServerAppFileDate;
	}

	public void setSnowU_WsEnvServerAppFileDate(String snowU_WsEnvServerAppFileDate) {
		this.snowU_WsEnvServerAppFileDate = snowU_WsEnvServerAppFileDate;
	}

	public String getSnowU_WsEnvServerAppFileDate2() {
		return snowU_WsEnvServerAppFileDate2;
	}

	public void setSnowU_WsEnvServerAppFileDate2(String snowU_WsEnvServerAppFileDate2) {
		this.snowU_WsEnvServerAppFileDate2 = snowU_WsEnvServerAppFileDate2;
	}

	public String getSnowU_WsEnvironmentHostServerA() {
		return snowU_WsEnvironmentHostServerA;
	}

	public void setSnowU_WsEnvironmentHostServerA(String snowU_WsEnvironmentHostServerA) {
		this.snowU_WsEnvironmentHostServerA = snowU_WsEnvironmentHostServerA;
	}

	public String getSnowU_WsEnvironmentHostServerI() {
		return snowU_WsEnvironmentHostServerI;
	}

	public void setSnowU_WsEnvironmentHostServerI(String snowU_WsEnvironmentHostServerI) {
		this.snowU_WsEnvironmentHostServerI = snowU_WsEnvironmentHostServerI;
	}

	public String getSnowU_WsEnvironmentId() {
		return snowU_WsEnvironmentId;
	}

	public void setSnowU_WsEnvironmentId(String snowU_WsEnvironmentId) {
		this.snowU_WsEnvironmentId = snowU_WsEnvironmentId;
	}

	public String getSnowU_WsEnvironmentName() {
		return snowU_WsEnvironmentName;
	}

	public void setSnowU_WsEnvironmentName(String snowU_WsEnvironmentName) {
		this.snowU_WsEnvironmentName = snowU_WsEnvironmentName;
	}

	public String getSnowU_WsExtractDate() {
		return snowU_WsExtractDate;
	}

	public void setSnowU_WsExtractDate(String snowU_WsExtractDate) {
		this.snowU_WsExtractDate = snowU_WsExtractDate;
	}

	public String getSnowU_WsExtractDate2() {
		return snowU_WsExtractDate2;
	}

	public void setSnowU_WsExtractDate2(String snowU_WsExtractDate2) {
		this.snowU_WsExtractDate2 = snowU_WsExtractDate2;
	}

	public String getSnowUnverified() {
		return snowUnverified;
	}

	public void setSnowUnverified(String snowUnverified) {
		this.snowUnverified = snowUnverified;
	}

	public String getSnowVendor() {
		return snowVendor;
	}

	public void setSnowVendor(String snowVendor) {
		this.snowVendor = snowVendor;
	}

	public String getSnowWarrantyExpiration() {
		return snowWarrantyExpiration;
	}

	public void setSnowWarrantyExpiration(String snowWarrantyExpiration) {
		this.snowWarrantyExpiration = snowWarrantyExpiration;
	}

}
