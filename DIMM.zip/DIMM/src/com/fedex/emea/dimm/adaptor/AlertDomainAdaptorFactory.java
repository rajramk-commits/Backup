package com.fedex.emea.dimm.adaptor;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeMap;

import com.fedex.emea.dimm.adaptor.datacenter.DataCenterOutageAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.direct.DirectAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.jms.itih.ITIHJMSAlertDomainAdaptor;

public class AlertDomainAdaptorFactory {

	private static AlertDomainAdaptorFactory instance = new AlertDomainAdaptorFactory();
	
	public static AlertDomainAdaptorFactory getInstance(){
		return instance;
	}
	
	private Set<AbstractAlertDomainAdaptor> allAdaptors = new LinkedHashSet<AbstractAlertDomainAdaptor>();
	
	private AlertDomainAdaptorFactory() {
		super();
		
			try{
				registerAdaptor(new ITIHJMSAlertDomainAdaptor());
			}catch(Exception exception){
				throw new RuntimeException("Fail to register the ITIH JMS Alert Domain Adaptor");
			}
			
			try{
				registerAdaptor(new DataCenterOutageAlertDomainAdaptor());
			}catch(Exception exception){
				throw new RuntimeException("Fail to register the data center outage Alert Domain Adaptor");
			}

			//finally always register the default direct adaptor
			try{
				registerAdaptor(new DirectAlertDomainAdaptor());
			}catch(Exception exception){
				throw new RuntimeException("Fail to register the default direct  Alert Domain Adaptor");
			}
	}

	private void registerAdaptor(AbstractAlertDomainAdaptor adaptor){
		if(adaptor!=null){
			allAdaptors.add(adaptor);
		}
	}

	public TreeMap<Integer, Set<AbstractAlertDomainAdaptor>> getAdaptors() {
		//dynamically construct the prioritized adaptor map, so if the priority of some adaptor is changed due to property configuration file is changed, it will be taken into account automatically
		TreeMap<Integer,Set<AbstractAlertDomainAdaptor>> prioritizedAdaptors = new TreeMap<Integer,Set<AbstractAlertDomainAdaptor>>();//the lower the priority number is, the higher the priority is
		Iterator<AbstractAlertDomainAdaptor> aI = allAdaptors.iterator();
		while(aI.hasNext()){
			AbstractAlertDomainAdaptor adaptor = aI.next();
			int priority = adaptor.getConfig().getAdaptorPriority();
			Set<AbstractAlertDomainAdaptor> onePriorityAdaptors = prioritizedAdaptors.get(priority);
			if(onePriorityAdaptors==null){
				onePriorityAdaptors = new HashSet<AbstractAlertDomainAdaptor>();
				prioritizedAdaptors.put(priority, onePriorityAdaptors);
			}
			onePriorityAdaptors.add(adaptor);
		}
		return prioritizedAdaptors;
	}
	
	
}
