package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

public class Application implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 6332670836471227549L;

	/** 
	 * This attribute maps to the column ID in the APPLICATION table.
	 */
	protected String id;

	/** 
	 * This attribute maps to the column NAME in the APPLICATION table.
	 */
	protected String name;

	/** 
	 * This attribute maps to the column LOCATION_NAME in the APPLICATION table.
	 */
	protected String locationName;

	/** 
	 * This attribute maps to the column APPLICATION_REVISION in the APPLICATION table.
	 */
	protected String applicationRevision;

	/** 
	 * This attribute maps to the column APPLICATION_VERSION in the APPLICATION table.
	 */
	protected String applicationVersion;

	/** 
	 * This attribute maps to the column STATUS in the APPLICATION table.
	 */
	protected String status;

	/** 
	 * This attribute maps to the column STATUS_DATE in the APPLICATION table.
	 */
	protected Date statusDate;

	/** 
	 * This attribute maps to the column MANUFACTURER_ISSUE_NUMBER in the APPLICATION table.
	 */
	protected String manufacturerIssueNumber;

	/** 
	 * This attribute maps to the column VENDOR in the APPLICATION table.
	 */
	protected String vendor;

	/** 
	 * This attribute maps to the column INSTALLED_IN in the APPLICATION table.
	 */
	protected String installedIn;

	/** 
	 * This attribute maps to the column OWNED_BY_LEASED_FROM in the APPLICATION table.
	 */
	protected String ownedByLeasedFrom;

	/** 
	 * This attribute maps to the column OWNED_OR_LEASED in the APPLICATION table.
	 */
	protected String ownedOrLeased;

	/** 
	 * This attribute maps to the column OWNERSHIP_LEASE_DATE in the APPLICATION table.
	 */
	protected Date ownershipLeaseDate;

	/** 
	 * This attribute maps to the column LEASING_PAYMENT in the APPLICATION table.
	 */
	protected float leasingPayment;

	/** 
	 * This attribute represents whether the primitive attribute leasingPayment is null.
	 */
	protected boolean leasingPaymentNull = true;

	/** 
	 * This attribute maps to the column COMMENTS in the APPLICATION table.
	 */
	protected String comments;

	/** 
	 * This attribute maps to the column RESOURCE_STATUS in the APPLICATION table.
	 */
	protected String resourceStatus;

	/** 
	 * This attribute maps to the column CUSTOM_1 in the APPLICATION table.
	 */
	protected String custom1;

	/** 
	 * This attribute maps to the column CUSTOM_2 in the APPLICATION table.
	 */
	protected String custom2;

	/** 
	 * This attribute maps to the column CUSTOM_3 in the APPLICATION table.
	 */
	protected String custom3;

	/** 
	 * This attribute maps to the column CUSTOM_4 in the APPLICATION table.
	 */
	protected String custom4;

	/** 
	 * This attribute maps to the column CUSTOM_5 in the APPLICATION table.
	 */
	protected String custom5;

	/** 
	 * This attribute maps to the column DEFINING_TYPE_KEY_TYPE in the APPLICATION table.
	 */
	protected String definingTypeKeyType;

	/** 
	 * This attribute maps to the column DEFINING_TYPE_KEY_PK in the APPLICATION table.
	 */
	protected String definingTypeKeyPk;

	/** 
	 * This attribute maps to the column DESCRIPTION in the APPLICATION table.
	 */
	protected String description;

	/** 
	 * This attribute maps to the column LONG_DESCRIPTION in the APPLICATION table.
	 */
	protected String longDescription;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_USER_ID in the APPLICATION table.
	 */
	protected String lastModificationUserId;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_DATE in the APPLICATION table.
	 */
	protected Date lastModificationDate;

	/** 
	 * This attribute maps to the column LASTUPDATEVERSIONNUMBER in the APPLICATION table.
	 */
	protected BigDecimal lastupdateversionnumber;

	/** 
	 * This attribute maps to the column CUSTOM_6 in the APPLICATION table.
	 */
	protected String custom6;

	/** 
	 * This attribute maps to the column CUSTOM_7 in the APPLICATION table.
	 */
	protected String custom7;

	/** 
	 * This attribute maps to the column CUSTOM_8 in the APPLICATION table.
	 */
	protected String custom8;

	/** 
	 * This attribute maps to the column CUSTOM_9 in the APPLICATION table.
	 */
	protected String custom9;

	/** 
	 * This attribute maps to the column CUSTOM_10 in the APPLICATION table.
	 */
	protected String custom10;

	/** 
	 * This attribute maps to the column BUSINESS_CRITICALITY in the APPLICATION table.
	 */
	protected String businessCriticality;

	/** 
	 * This attribute maps to the column SOURCE in the APPLICATION table.
	 */
	protected String source;

	/** 
	 * This attribute maps to the column SOURCE_KEY in the APPLICATION table.
	 */
	protected String sourceKey;

	/** 
	 * This attribute maps to the column OBJECT_DEFAULT_KEY_TYPE in the APPLICATION table.
	 */
	protected String objectDefaultKeyType;

	/** 
	 * This attribute maps to the column OBJECT_DEFAULT_KEY_PK in the APPLICATION table.
	 */
	protected String objectDefaultKeyPk;

	/** 
	 * This attribute maps to the column ENVIRONMENT in the APPLICATION table.
	 */
	protected String environment;

	/** 
	 * This attribute maps to the column INVENTORY_KEY_TYPE in the APPLICATION table.
	 */
	protected String inventoryKeyType;

	/** 
	 * This attribute maps to the column INVENTORY_KEY_PK in the APPLICATION table.
	 */
	protected String inventoryKeyPk;

	/** 
	 * This attribute maps to the column IS_OVERLAY_COMPONENT in the APPLICATION table.
	 */
	protected int isOverlayComponent;

	/** 
	 * This attribute represents whether the primitive attribute isOverlayComponent is null.
	 */
	protected boolean isOverlayComponentNull = true;

	/**
	 * Method 'Application'
	 * 
	 */
	public Application()
	{
	}

	/**
	 * Method 'getId'
	 * 
	 * @return String
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * Method 'setId'
	 * 
	 * @param id
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * Method 'getName'
	 * 
	 * @return String
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * Method 'setName'
	 * 
	 * @param name
	 */
	public void setName(String name)
	{
		this.name = name;
	}

	/**
	 * Method 'getLocationName'
	 * 
	 * @return String
	 */
	public String getLocationName()
	{
		return locationName;
	}

	/**
	 * Method 'setLocationName'
	 * 
	 * @param locationName
	 */
	public void setLocationName(String locationName)
	{
		this.locationName = locationName;
	}

	/**
	 * Method 'getApplicationRevision'
	 * 
	 * @return String
	 */
	public String getApplicationRevision()
	{
		return applicationRevision;
	}

	/**
	 * Method 'setApplicationRevision'
	 * 
	 * @param applicationRevision
	 */
	public void setApplicationRevision(String applicationRevision)
	{
		this.applicationRevision = applicationRevision;
	}

	/**
	 * Method 'getApplicationVersion'
	 * 
	 * @return String
	 */
	public String getApplicationVersion()
	{
		return applicationVersion;
	}

	/**
	 * Method 'setApplicationVersion'
	 * 
	 * @param applicationVersion
	 */
	public void setApplicationVersion(String applicationVersion)
	{
		this.applicationVersion = applicationVersion;
	}

	/**
	 * Method 'getStatus'
	 * 
	 * @return String
	 */
	public String getStatus()
	{
		return status;
	}

	/**
	 * Method 'setStatus'
	 * 
	 * @param status
	 */
	public void setStatus(String status)
	{
		this.status = status;
	}

	/**
	 * Method 'getStatusDate'
	 * 
	 * @return Date
	 */
	public Date getStatusDate()
	{
		return statusDate;
	}

	/**
	 * Method 'setStatusDate'
	 * 
	 * @param statusDate
	 */
	public void setStatusDate(Date statusDate)
	{
		this.statusDate = statusDate;
	}

	/**
	 * Method 'getManufacturerIssueNumber'
	 * 
	 * @return String
	 */
	public String getManufacturerIssueNumber()
	{
		return manufacturerIssueNumber;
	}

	/**
	 * Method 'setManufacturerIssueNumber'
	 * 
	 * @param manufacturerIssueNumber
	 */
	public void setManufacturerIssueNumber(String manufacturerIssueNumber)
	{
		this.manufacturerIssueNumber = manufacturerIssueNumber;
	}

	/**
	 * Method 'getVendor'
	 * 
	 * @return String
	 */
	public String getVendor()
	{
		return vendor;
	}

	/**
	 * Method 'setVendor'
	 * 
	 * @param vendor
	 */
	public void setVendor(String vendor)
	{
		this.vendor = vendor;
	}

	/**
	 * Method 'getInstalledIn'
	 * 
	 * @return String
	 */
	public String getInstalledIn()
	{
		return installedIn;
	}

	/**
	 * Method 'setInstalledIn'
	 * 
	 * @param installedIn
	 */
	public void setInstalledIn(String installedIn)
	{
		this.installedIn = installedIn;
	}

	/**
	 * Method 'getOwnedByLeasedFrom'
	 * 
	 * @return String
	 */
	public String getOwnedByLeasedFrom()
	{
		return ownedByLeasedFrom;
	}

	/**
	 * Method 'setOwnedByLeasedFrom'
	 * 
	 * @param ownedByLeasedFrom
	 */
	public void setOwnedByLeasedFrom(String ownedByLeasedFrom)
	{
		this.ownedByLeasedFrom = ownedByLeasedFrom;
	}

	/**
	 * Method 'getOwnedOrLeased'
	 * 
	 * @return String
	 */
	public String getOwnedOrLeased()
	{
		return ownedOrLeased;
	}

	/**
	 * Method 'setOwnedOrLeased'
	 * 
	 * @param ownedOrLeased
	 */
	public void setOwnedOrLeased(String ownedOrLeased)
	{
		this.ownedOrLeased = ownedOrLeased;
	}

	/**
	 * Method 'getOwnershipLeaseDate'
	 * 
	 * @return Date
	 */
	public Date getOwnershipLeaseDate()
	{
		return ownershipLeaseDate;
	}

	/**
	 * Method 'setOwnershipLeaseDate'
	 * 
	 * @param ownershipLeaseDate
	 */
	public void setOwnershipLeaseDate(Date ownershipLeaseDate)
	{
		this.ownershipLeaseDate = ownershipLeaseDate;
	}

	/**
	 * Method 'getLeasingPayment'
	 * 
	 * @return float
	 */
	public float getLeasingPayment()
	{
		return leasingPayment;
	}

	/**
	 * Method 'setLeasingPayment'
	 * 
	 * @param leasingPayment
	 */
	public void setLeasingPayment(float leasingPayment)
	{
		this.leasingPayment = leasingPayment;
		this.leasingPaymentNull = false;
	}

	/**
	 * Method 'setLeasingPaymentNull'
	 * 
	 * @param value
	 */
	public void setLeasingPaymentNull(boolean value)
	{
		this.leasingPaymentNull = value;
	}

	/**
	 * Method 'isLeasingPaymentNull'
	 * 
	 * @return boolean
	 */
	public boolean isLeasingPaymentNull()
	{
		return leasingPaymentNull;
	}

	/**
	 * Method 'getComments'
	 * 
	 * @return String
	 */
	public String getComments()
	{
		return comments;
	}

	/**
	 * Method 'setComments'
	 * 
	 * @param comments
	 */
	public void setComments(String comments)
	{
		this.comments = comments;
	}

	/**
	 * Method 'getResourceStatus'
	 * 
	 * @return String
	 */
	public String getResourceStatus()
	{
		return resourceStatus;
	}

	/**
	 * Method 'setResourceStatus'
	 * 
	 * @param resourceStatus
	 */
	public void setResourceStatus(String resourceStatus)
	{
		this.resourceStatus = resourceStatus;
	}

	/**
	 * Method 'getCustom1'
	 * 
	 * @return String
	 */
	public String getCustom1()
	{
		return custom1;
	}

	/**
	 * Method 'setCustom1'
	 * 
	 * @param custom1
	 */
	public void setCustom1(String custom1)
	{
		this.custom1 = custom1;
	}

	/**
	 * Method 'getCustom2'
	 * 
	 * @return String
	 */
	public String getCustom2()
	{
		return custom2;
	}

	/**
	 * Method 'setCustom2'
	 * 
	 * @param custom2
	 */
	public void setCustom2(String custom2)
	{
		this.custom2 = custom2;
	}

	/**
	 * Method 'getCustom3'
	 * 
	 * @return String
	 */
	public String getCustom3()
	{
		return custom3;
	}

	/**
	 * Method 'setCustom3'
	 * 
	 * @param custom3
	 */
	public void setCustom3(String custom3)
	{
		this.custom3 = custom3;
	}

	/**
	 * Method 'getCustom4'
	 * 
	 * @return String
	 */
	public String getCustom4()
	{
		return custom4;
	}

	/**
	 * Method 'setCustom4'
	 * 
	 * @param custom4
	 */
	public void setCustom4(String custom4)
	{
		this.custom4 = custom4;
	}

	/**
	 * Method 'getCustom5'
	 * 
	 * @return String
	 */
	public String getCustom5()
	{
		return custom5;
	}

	/**
	 * Method 'setCustom5'
	 * 
	 * @param custom5
	 */
	public void setCustom5(String custom5)
	{
		this.custom5 = custom5;
	}

	/**
	 * Method 'getDefiningTypeKeyType'
	 * 
	 * @return String
	 */
	public String getDefiningTypeKeyType()
	{
		return definingTypeKeyType;
	}

	/**
	 * Method 'setDefiningTypeKeyType'
	 * 
	 * @param definingTypeKeyType
	 */
	public void setDefiningTypeKeyType(String definingTypeKeyType)
	{
		this.definingTypeKeyType = definingTypeKeyType;
	}

	/**
	 * Method 'getDefiningTypeKeyPk'
	 * 
	 * @return String
	 */
	public String getDefiningTypeKeyPk()
	{
		return definingTypeKeyPk;
	}

	/**
	 * Method 'setDefiningTypeKeyPk'
	 * 
	 * @param definingTypeKeyPk
	 */
	public void setDefiningTypeKeyPk(String definingTypeKeyPk)
	{
		this.definingTypeKeyPk = definingTypeKeyPk;
	}

	/**
	 * Method 'getDescription'
	 * 
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Method 'setDescription'
	 * 
	 * @param description
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * Method 'getLongDescription'
	 * 
	 * @return String
	 */
	public String getLongDescription()
	{
		return longDescription;
	}

	/**
	 * Method 'setLongDescription'
	 * 
	 * @param longDescription
	 */
	public void setLongDescription(String longDescription)
	{
		this.longDescription = longDescription;
	}

	/**
	 * Method 'getLastModificationUserId'
	 * 
	 * @return String
	 */
	public String getLastModificationUserId()
	{
		return lastModificationUserId;
	}

	/**
	 * Method 'setLastModificationUserId'
	 * 
	 * @param lastModificationUserId
	 */
	public void setLastModificationUserId(String lastModificationUserId)
	{
		this.lastModificationUserId = lastModificationUserId;
	}

	/**
	 * Method 'getLastModificationDate'
	 * 
	 * @return Date
	 */
	public Date getLastModificationDate()
	{
		return lastModificationDate;
	}

	/**
	 * Method 'setLastModificationDate'
	 * 
	 * @param lastModificationDate
	 */
	public void setLastModificationDate(Date lastModificationDate)
	{
		this.lastModificationDate = lastModificationDate;
	}

	/**
	 * Method 'getLastupdateversionnumber'
	 * 
	 * @return BigDecimal
	 */
	public BigDecimal getLastupdateversionnumber()
	{
		return lastupdateversionnumber;
	}

	/**
	 * Method 'setLastupdateversionnumber'
	 * 
	 * @param lastupdateversionnumber
	 */
	public void setLastupdateversionnumber(BigDecimal lastupdateversionnumber)
	{
		this.lastupdateversionnumber = lastupdateversionnumber;
	}

	/**
	 * Method 'getCustom6'
	 * 
	 * @return String
	 */
	public String getCustom6()
	{
		return custom6;
	}

	/**
	 * Method 'setCustom6'
	 * 
	 * @param custom6
	 */
	public void setCustom6(String custom6)
	{
		this.custom6 = custom6;
	}

	/**
	 * Method 'getCustom7'
	 * 
	 * @return String
	 */
	public String getCustom7()
	{
		return custom7;
	}

	/**
	 * Method 'setCustom7'
	 * 
	 * @param custom7
	 */
	public void setCustom7(String custom7)
	{
		this.custom7 = custom7;
	}

	/**
	 * Method 'getCustom8'
	 * 
	 * @return String
	 */
	public String getCustom8()
	{
		return custom8;
	}

	/**
	 * Method 'setCustom8'
	 * 
	 * @param custom8
	 */
	public void setCustom8(String custom8)
	{
		this.custom8 = custom8;
	}

	/**
	 * Method 'getCustom9'
	 * 
	 * @return String
	 */
	public String getCustom9()
	{
		return custom9;
	}

	/**
	 * Method 'setCustom9'
	 * 
	 * @param custom9
	 */
	public void setCustom9(String custom9)
	{
		this.custom9 = custom9;
	}

	/**
	 * Method 'getCustom10'
	 * 
	 * @return String
	 */
	public String getCustom10()
	{
		return custom10;
	}

	/**
	 * Method 'setCustom10'
	 * 
	 * @param custom10
	 */
	public void setCustom10(String custom10)
	{
		this.custom10 = custom10;
	}

	/**
	 * Method 'getBusinessCriticality'
	 * 
	 * @return String
	 */
	public String getBusinessCriticality()
	{
		return businessCriticality;
	}

	/**
	 * Method 'setBusinessCriticality'
	 * 
	 * @param businessCriticality
	 */
	public void setBusinessCriticality(String businessCriticality)
	{
		this.businessCriticality = businessCriticality;
	}

	/**
	 * Method 'getSource'
	 * 
	 * @return String
	 */
	public String getSource()
	{
		return source;
	}

	/**
	 * Method 'setSource'
	 * 
	 * @param source
	 */
	public void setSource(String source)
	{
		this.source = source;
	}

	/**
	 * Method 'getSourceKey'
	 * 
	 * @return String
	 */
	public String getSourceKey()
	{
		return sourceKey;
	}

	/**
	 * Method 'setSourceKey'
	 * 
	 * @param sourceKey
	 */
	public void setSourceKey(String sourceKey)
	{
		this.sourceKey = sourceKey;
	}

	/**
	 * Method 'getObjectDefaultKeyType'
	 * 
	 * @return String
	 */
	public String getObjectDefaultKeyType()
	{
		return objectDefaultKeyType;
	}

	/**
	 * Method 'setObjectDefaultKeyType'
	 * 
	 * @param objectDefaultKeyType
	 */
	public void setObjectDefaultKeyType(String objectDefaultKeyType)
	{
		this.objectDefaultKeyType = objectDefaultKeyType;
	}

	/**
	 * Method 'getObjectDefaultKeyPk'
	 * 
	 * @return String
	 */
	public String getObjectDefaultKeyPk()
	{
		return objectDefaultKeyPk;
	}

	/**
	 * Method 'setObjectDefaultKeyPk'
	 * 
	 * @param objectDefaultKeyPk
	 */
	public void setObjectDefaultKeyPk(String objectDefaultKeyPk)
	{
		this.objectDefaultKeyPk = objectDefaultKeyPk;
	}

	/**
	 * Method 'getEnvironment'
	 * 
	 * @return String
	 */
	public String getEnvironment()
	{
		return environment;
	}

	/**
	 * Method 'setEnvironment'
	 * 
	 * @param environment
	 */
	public void setEnvironment(String environment)
	{
		this.environment = environment;
	}

	/**
	 * Method 'getInventoryKeyType'
	 * 
	 * @return String
	 */
	public String getInventoryKeyType()
	{
		return inventoryKeyType;
	}

	/**
	 * Method 'setInventoryKeyType'
	 * 
	 * @param inventoryKeyType
	 */
	public void setInventoryKeyType(String inventoryKeyType)
	{
		this.inventoryKeyType = inventoryKeyType;
	}

	/**
	 * Method 'getInventoryKeyPk'
	 * 
	 * @return String
	 */
	public String getInventoryKeyPk()
	{
		return inventoryKeyPk;
	}

	/**
	 * Method 'setInventoryKeyPk'
	 * 
	 * @param inventoryKeyPk
	 */
	public void setInventoryKeyPk(String inventoryKeyPk)
	{
		this.inventoryKeyPk = inventoryKeyPk;
	}

	/**
	 * Method 'getIsOverlayComponent'
	 * 
	 * @return int
	 */
	public int getIsOverlayComponent()
	{
		return isOverlayComponent;
	}

	/**
	 * Method 'setIsOverlayComponent'
	 * 
	 * @param isOverlayComponent
	 */
	public void setIsOverlayComponent(int isOverlayComponent)
	{
		this.isOverlayComponent = isOverlayComponent;
		this.isOverlayComponentNull = false;
	}

	/**
	 * Method 'setIsOverlayComponentNull'
	 * 
	 * @param value
	 */
	public void setIsOverlayComponentNull(boolean value)
	{
		this.isOverlayComponentNull = value;
	}

	/**
	 * Method 'isIsOverlayComponentNull'
	 * 
	 * @return boolean
	 */
	public boolean isIsOverlayComponentNull()
	{
		return isOverlayComponentNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof Application)) {
			return false;
		}
		
		final Application _cast = (Application) _other;
		if (id == null ? _cast.id != id : !id.equals( _cast.id )) {
			return false;
		}
		
		if (name == null ? _cast.name != name : !name.equals( _cast.name )) {
			return false;
		}
		
		if (locationName == null ? _cast.locationName != locationName : !locationName.equals( _cast.locationName )) {
			return false;
		}
		
		if (applicationRevision == null ? _cast.applicationRevision != applicationRevision : !applicationRevision.equals( _cast.applicationRevision )) {
			return false;
		}
		
		if (applicationVersion == null ? _cast.applicationVersion != applicationVersion : !applicationVersion.equals( _cast.applicationVersion )) {
			return false;
		}
		
		if (status == null ? _cast.status != status : !status.equals( _cast.status )) {
			return false;
		}
		
		if (statusDate == null ? _cast.statusDate != statusDate : !statusDate.equals( _cast.statusDate )) {
			return false;
		}
		
		if (manufacturerIssueNumber == null ? _cast.manufacturerIssueNumber != manufacturerIssueNumber : !manufacturerIssueNumber.equals( _cast.manufacturerIssueNumber )) {
			return false;
		}
		
		if (vendor == null ? _cast.vendor != vendor : !vendor.equals( _cast.vendor )) {
			return false;
		}
		
		if (installedIn == null ? _cast.installedIn != installedIn : !installedIn.equals( _cast.installedIn )) {
			return false;
		}
		
		if (ownedByLeasedFrom == null ? _cast.ownedByLeasedFrom != ownedByLeasedFrom : !ownedByLeasedFrom.equals( _cast.ownedByLeasedFrom )) {
			return false;
		}
		
		if (ownedOrLeased == null ? _cast.ownedOrLeased != ownedOrLeased : !ownedOrLeased.equals( _cast.ownedOrLeased )) {
			return false;
		}
		
		if (ownershipLeaseDate == null ? _cast.ownershipLeaseDate != ownershipLeaseDate : !ownershipLeaseDate.equals( _cast.ownershipLeaseDate )) {
			return false;
		}
		
		if (leasingPayment != _cast.leasingPayment) {
			return false;
		}
		
		if (leasingPaymentNull != _cast.leasingPaymentNull) {
			return false;
		}
		
		if (comments == null ? _cast.comments != comments : !comments.equals( _cast.comments )) {
			return false;
		}
		
		if (resourceStatus == null ? _cast.resourceStatus != resourceStatus : !resourceStatus.equals( _cast.resourceStatus )) {
			return false;
		}
		
		if (custom1 == null ? _cast.custom1 != custom1 : !custom1.equals( _cast.custom1 )) {
			return false;
		}
		
		if (custom2 == null ? _cast.custom2 != custom2 : !custom2.equals( _cast.custom2 )) {
			return false;
		}
		
		if (custom3 == null ? _cast.custom3 != custom3 : !custom3.equals( _cast.custom3 )) {
			return false;
		}
		
		if (custom4 == null ? _cast.custom4 != custom4 : !custom4.equals( _cast.custom4 )) {
			return false;
		}
		
		if (custom5 == null ? _cast.custom5 != custom5 : !custom5.equals( _cast.custom5 )) {
			return false;
		}
		
		if (definingTypeKeyType == null ? _cast.definingTypeKeyType != definingTypeKeyType : !definingTypeKeyType.equals( _cast.definingTypeKeyType )) {
			return false;
		}
		
		if (definingTypeKeyPk == null ? _cast.definingTypeKeyPk != definingTypeKeyPk : !definingTypeKeyPk.equals( _cast.definingTypeKeyPk )) {
			return false;
		}
		
		if (description == null ? _cast.description != description : !description.equals( _cast.description )) {
			return false;
		}
		
		if (longDescription == null ? _cast.longDescription != longDescription : !longDescription.equals( _cast.longDescription )) {
			return false;
		}
		
		if (lastModificationUserId == null ? _cast.lastModificationUserId != lastModificationUserId : !lastModificationUserId.equals( _cast.lastModificationUserId )) {
			return false;
		}
		
		if (lastModificationDate == null ? _cast.lastModificationDate != lastModificationDate : !lastModificationDate.equals( _cast.lastModificationDate )) {
			return false;
		}
		
		if (lastupdateversionnumber == null ? _cast.lastupdateversionnumber != lastupdateversionnumber : !lastupdateversionnumber.equals( _cast.lastupdateversionnumber )) {
			return false;
		}
		
		if (custom6 == null ? _cast.custom6 != custom6 : !custom6.equals( _cast.custom6 )) {
			return false;
		}
		
		if (custom7 == null ? _cast.custom7 != custom7 : !custom7.equals( _cast.custom7 )) {
			return false;
		}
		
		if (custom8 == null ? _cast.custom8 != custom8 : !custom8.equals( _cast.custom8 )) {
			return false;
		}
		
		if (custom9 == null ? _cast.custom9 != custom9 : !custom9.equals( _cast.custom9 )) {
			return false;
		}
		
		if (custom10 == null ? _cast.custom10 != custom10 : !custom10.equals( _cast.custom10 )) {
			return false;
		}
		
		if (businessCriticality == null ? _cast.businessCriticality != businessCriticality : !businessCriticality.equals( _cast.businessCriticality )) {
			return false;
		}
		
		if (source == null ? _cast.source != source : !source.equals( _cast.source )) {
			return false;
		}
		
		if (sourceKey == null ? _cast.sourceKey != sourceKey : !sourceKey.equals( _cast.sourceKey )) {
			return false;
		}
		
		if (objectDefaultKeyType == null ? _cast.objectDefaultKeyType != objectDefaultKeyType : !objectDefaultKeyType.equals( _cast.objectDefaultKeyType )) {
			return false;
		}
		
		if (objectDefaultKeyPk == null ? _cast.objectDefaultKeyPk != objectDefaultKeyPk : !objectDefaultKeyPk.equals( _cast.objectDefaultKeyPk )) {
			return false;
		}
		
		if (environment == null ? _cast.environment != environment : !environment.equals( _cast.environment )) {
			return false;
		}
		
		if (inventoryKeyType == null ? _cast.inventoryKeyType != inventoryKeyType : !inventoryKeyType.equals( _cast.inventoryKeyType )) {
			return false;
		}
		
		if (inventoryKeyPk == null ? _cast.inventoryKeyPk != inventoryKeyPk : !inventoryKeyPk.equals( _cast.inventoryKeyPk )) {
			return false;
		}
		
		if (isOverlayComponent != _cast.isOverlayComponent) {
			return false;
		}
		
		if (isOverlayComponentNull != _cast.isOverlayComponentNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (id != null) {
			_hashCode = 29 * _hashCode + id.hashCode();
		}
		
		if (name != null) {
			_hashCode = 29 * _hashCode + name.hashCode();
		}
		
		if (locationName != null) {
			_hashCode = 29 * _hashCode + locationName.hashCode();
		}
		
		if (applicationRevision != null) {
			_hashCode = 29 * _hashCode + applicationRevision.hashCode();
		}
		
		if (applicationVersion != null) {
			_hashCode = 29 * _hashCode + applicationVersion.hashCode();
		}
		
		if (status != null) {
			_hashCode = 29 * _hashCode + status.hashCode();
		}
		
		if (statusDate != null) {
			_hashCode = 29 * _hashCode + statusDate.hashCode();
		}
		
		if (manufacturerIssueNumber != null) {
			_hashCode = 29 * _hashCode + manufacturerIssueNumber.hashCode();
		}
		
		if (vendor != null) {
			_hashCode = 29 * _hashCode + vendor.hashCode();
		}
		
		if (installedIn != null) {
			_hashCode = 29 * _hashCode + installedIn.hashCode();
		}
		
		if (ownedByLeasedFrom != null) {
			_hashCode = 29 * _hashCode + ownedByLeasedFrom.hashCode();
		}
		
		if (ownedOrLeased != null) {
			_hashCode = 29 * _hashCode + ownedOrLeased.hashCode();
		}
		
		if (ownershipLeaseDate != null) {
			_hashCode = 29 * _hashCode + ownershipLeaseDate.hashCode();
		}
		
		_hashCode = 29 * _hashCode + Float.floatToIntBits(leasingPayment);
		_hashCode = 29 * _hashCode + (leasingPaymentNull ? 1 : 0);
		if (comments != null) {
			_hashCode = 29 * _hashCode + comments.hashCode();
		}
		
		if (resourceStatus != null) {
			_hashCode = 29 * _hashCode + resourceStatus.hashCode();
		}
		
		if (custom1 != null) {
			_hashCode = 29 * _hashCode + custom1.hashCode();
		}
		
		if (custom2 != null) {
			_hashCode = 29 * _hashCode + custom2.hashCode();
		}
		
		if (custom3 != null) {
			_hashCode = 29 * _hashCode + custom3.hashCode();
		}
		
		if (custom4 != null) {
			_hashCode = 29 * _hashCode + custom4.hashCode();
		}
		
		if (custom5 != null) {
			_hashCode = 29 * _hashCode + custom5.hashCode();
		}
		
		if (definingTypeKeyType != null) {
			_hashCode = 29 * _hashCode + definingTypeKeyType.hashCode();
		}
		
		if (definingTypeKeyPk != null) {
			_hashCode = 29 * _hashCode + definingTypeKeyPk.hashCode();
		}
		
		if (description != null) {
			_hashCode = 29 * _hashCode + description.hashCode();
		}
		
		if (longDescription != null) {
			_hashCode = 29 * _hashCode + longDescription.hashCode();
		}
		
		if (lastModificationUserId != null) {
			_hashCode = 29 * _hashCode + lastModificationUserId.hashCode();
		}
		
		if (lastModificationDate != null) {
			_hashCode = 29 * _hashCode + lastModificationDate.hashCode();
		}
		
		if (lastupdateversionnumber != null) {
			_hashCode = 29 * _hashCode + lastupdateversionnumber.hashCode();
		}
		
		if (custom6 != null) {
			_hashCode = 29 * _hashCode + custom6.hashCode();
		}
		
		if (custom7 != null) {
			_hashCode = 29 * _hashCode + custom7.hashCode();
		}
		
		if (custom8 != null) {
			_hashCode = 29 * _hashCode + custom8.hashCode();
		}
		
		if (custom9 != null) {
			_hashCode = 29 * _hashCode + custom9.hashCode();
		}
		
		if (custom10 != null) {
			_hashCode = 29 * _hashCode + custom10.hashCode();
		}
		
		if (businessCriticality != null) {
			_hashCode = 29 * _hashCode + businessCriticality.hashCode();
		}
		
		if (source != null) {
			_hashCode = 29 * _hashCode + source.hashCode();
		}
		
		if (sourceKey != null) {
			_hashCode = 29 * _hashCode + sourceKey.hashCode();
		}
		
		if (objectDefaultKeyType != null) {
			_hashCode = 29 * _hashCode + objectDefaultKeyType.hashCode();
		}
		
		if (objectDefaultKeyPk != null) {
			_hashCode = 29 * _hashCode + objectDefaultKeyPk.hashCode();
		}
		
		if (environment != null) {
			_hashCode = 29 * _hashCode + environment.hashCode();
		}
		
		if (inventoryKeyType != null) {
			_hashCode = 29 * _hashCode + inventoryKeyType.hashCode();
		}
		
		if (inventoryKeyPk != null) {
			_hashCode = 29 * _hashCode + inventoryKeyPk.hashCode();
		}
		
		_hashCode = 29 * _hashCode + isOverlayComponent;
		_hashCode = 29 * _hashCode + (isOverlayComponentNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return ApplicationPk
	 */
	public ApplicationPk createPk()
	{
		return new ApplicationPk(id);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.fedex.emea.sd.dto.Application: " );
		ret.append( "id=" + id );
		ret.append( ", name=" + name );
		ret.append( ", locationName=" + locationName );
		ret.append( ", applicationRevision=" + applicationRevision );
		ret.append( ", applicationVersion=" + applicationVersion );
		ret.append( ", status=" + status );
		ret.append( ", statusDate=" + statusDate );
		ret.append( ", manufacturerIssueNumber=" + manufacturerIssueNumber );
		ret.append( ", vendor=" + vendor );
		ret.append( ", installedIn=" + installedIn );
		ret.append( ", ownedByLeasedFrom=" + ownedByLeasedFrom );
		ret.append( ", ownedOrLeased=" + ownedOrLeased );
		ret.append( ", ownershipLeaseDate=" + ownershipLeaseDate );
		ret.append( ", leasingPayment=" + leasingPayment );
		ret.append( ", comments=" + comments );
		ret.append( ", resourceStatus=" + resourceStatus );
		ret.append( ", custom1=" + custom1 );
		ret.append( ", custom2=" + custom2 );
		ret.append( ", custom3=" + custom3 );
		ret.append( ", custom4=" + custom4 );
		ret.append( ", custom5=" + custom5 );
		ret.append( ", definingTypeKeyType=" + definingTypeKeyType );
		ret.append( ", definingTypeKeyPk=" + definingTypeKeyPk );
		ret.append( ", description=" + description );
		ret.append( ", longDescription=" + longDescription );
		ret.append( ", lastModificationUserId=" + lastModificationUserId );
		ret.append( ", lastModificationDate=" + lastModificationDate );
		ret.append( ", lastupdateversionnumber=" + lastupdateversionnumber );
		ret.append( ", custom6=" + custom6 );
		ret.append( ", custom7=" + custom7 );
		ret.append( ", custom8=" + custom8 );
		ret.append( ", custom9=" + custom9 );
		ret.append( ", custom10=" + custom10 );
		ret.append( ", businessCriticality=" + businessCriticality );
		ret.append( ", source=" + source );
		ret.append( ", sourceKey=" + sourceKey );
		ret.append( ", objectDefaultKeyType=" + objectDefaultKeyType );
		ret.append( ", objectDefaultKeyPk=" + objectDefaultKeyPk );
		ret.append( ", environment=" + environment );
		ret.append( ", inventoryKeyType=" + inventoryKeyType );
		ret.append( ", inventoryKeyPk=" + inventoryKeyPk );
		ret.append( ", isOverlayComponent=" + isOverlayComponent );
		return ret.toString();
	}

}
