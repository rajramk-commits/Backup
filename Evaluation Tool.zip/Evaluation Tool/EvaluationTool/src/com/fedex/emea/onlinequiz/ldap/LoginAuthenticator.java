package com.fedex.emea.onlinequiz.ldap;

import com.fedex.emea.onlinequiz.ldap.LDAPAbstractAuthenticator.AuthenticateResult;

public class LoginAuthenticator {
	LDAPAuthenticator ldp = new LDAPAuthenticator();
	
	public AuthenticateResult isUserAuthenticated(String userId, String userPwd) throws Exception {
		AuthenticateResult arr = null;
		try {
			arr = ldp.isUserAuthenticated(userId, userPwd);
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}
		return arr;
	}
	
	public LDAPUserInfo extractUserProfile(String userName) throws Exception {
		LDAPUserInfo userInfo = null;
		
		try {
			userInfo = ldp.extractUserProfile(userName, true, null, false);
			//System.out.println(userInfo.getUserName()+""+userInfo.getUid()+""+userInfo.getUserRoid());
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception(ex.getMessage());
		}
		return userInfo;
	}
}
