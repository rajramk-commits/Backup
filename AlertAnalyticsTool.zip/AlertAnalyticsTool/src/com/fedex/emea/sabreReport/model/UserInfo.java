package com.fedex.emea.sabreReport.model;

import java.io.Serializable;

public class UserInfo implements Serializable {
    // these parameters are exact match of the LDAP properties
    private String Uid;
    private String Xuid;
    private String Country;
    private String GivenName;
    private String Xdomain;
    private String PostalAddress;
    private String TelephoneNumber;
    private String Manager;
    private String Sn;
    private String Departmentname;
    private String Mail;
    
    private int sessionTimeout = 30;
    
    private UserProfile userProfile;
    
    public String getCountry() {
        return Country;
    }
    public void setCountry(String country) {
        Country = country;
    }
    public String getGivenName() {
        return GivenName;
    }
    public void setGivenName(String givenName) {
        GivenName = givenName;
    }
    public String getPostalAddress() {
        return PostalAddress;
    }
    public void setPostalAddress(String postalAddress) {
        PostalAddress = postalAddress;
    }
    public String getTelephoneNumber() {
        return TelephoneNumber;
    }
    public void setTelephoneNumber(String telephoneNumber) {
        TelephoneNumber = telephoneNumber;
    }
    public String getUid() {
        return Uid;
    }
    public void setUid(String uid) {
        Uid = uid;
    }
    public String getXdomain() {
        return Xdomain;
    }
    public void setXdomain(String xdomain) {
        Xdomain = xdomain;
    }
    public String getXuid() {
        return Xuid;
    }
    public void setXuid(String xuid) {
        Xuid = xuid;
    }
    public int getSessionTimeout() {
        return sessionTimeout;
    }
    public void setSessionTimeout(int sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
    }
    public String getMail() {
        return Mail;
    }
    public void setMail(String mail) {
        Mail = mail;
    }
    public String getManager() {
        return Manager;
    }
    public void setManager(String manager) {
        Manager = manager;
    }
    public String getSn() {
        return Sn;
    }
    public void setSn(String sn) {
        Sn = sn;
    }
    public String getDepartmentname() {
        return Departmentname;
    }
    public void setDepartmentname(String departmentname) {
        Departmentname = departmentname;
    }
    public UserProfile getUserProfile() {
        return userProfile;
    }
    public void setUserProfile(UserProfile userProfile) {
        this.userProfile = userProfile;
    }    
    
    public String toString(){
        StringBuffer strUser = new StringBuffer();
        strUser.append("User ID = "+Uid)
        .append("\nXuid = "+Xuid)
        .append("\nCountry = "+Country)
        .append("\nGiven Name  = "+GivenName)
        .append("\nXdomain = "+Xdomain)
        .append("\nPostalAddress = "+PostalAddress)
        .append("\nTelephoneNumber = "+TelephoneNumber)
        .append("\nManager = "+Manager)
        .append("\nSn = "+Sn)
        .append("\nDepartmentname = "+Departmentname)
        .append("\nMail = "+Mail);
        return strUser.toString();
    }
}