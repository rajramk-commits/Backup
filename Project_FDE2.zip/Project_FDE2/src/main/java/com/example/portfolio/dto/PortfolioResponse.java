package com.example.portfolio.dto;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.validation.constraints.NotNull;

public class PortfolioResponse {
    private String requestId;
    private String portfolioId;
    private String valuationDate;
    private boolean totalContributionPct;
    private status status;

    public enum status {
        VALID,
        REVIEW_REQUIRED,
        DEGRADED,
        INVALID_INPUT
    }
    private boolean degradedProcessing;
    private String fallBackWarnings;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date processedAt;

    public PortfolioResponse() {
    }
    public PortfolioResponse( String requestId, String portfolioId, String valuationDate, status status) {
        this.requestId = requestId;
        this.portfolioId = portfolioId;
        this.valuationDate = valuationDate;
        this.status = status;
    }
    private List<GroupContribution> groupContribution;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getPortfolioId() {
        return portfolioId;
    }

    public void setPortfolioId(String portfolioId) {
        this.portfolioId = portfolioId;
    }

    public String getValuationDate() {
        return valuationDate;
    }

    public void setValuationDate(String valuationDate) {
        this.valuationDate = valuationDate;
    }

    public void setProcessedAt(Date processedAt) {
        this.processedAt = processedAt;
    }
    public Date getProcessedAt() {
        return processedAt;
    }

    public boolean isTotalContributionPct() {
        return totalContributionPct;
    }

    public void setTotalContributionPct(boolean totalContributionPct) {
        this.totalContributionPct = totalContributionPct;
    }

    public List<GroupContribution> getGroupContribution() {
        return groupContribution;
    }

    public void setGroupContribution(List<GroupContribution> groupContribution) {
        this.groupContribution = groupContribution;
    }

    public boolean isDegradedProcessing() {
        return degradedProcessing;
    }

    public void setDegradedProcessing(boolean degradedProcessing) {
        this.degradedProcessing = degradedProcessing;
    }

    public String getFallBackWarnings() {
        return fallBackWarnings;
    }

    public void setFallBackWarnings(String fallBackWarnings) {
        this.fallBackWarnings = fallBackWarnings;
    }
    
    public status getStatus() {
        return status;
    }

    public void setStatus(status status) {
        this.status = status;
    }

}