package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

public class Applicationtype implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7278785334358742532L;

	/** 
	 * This attribute maps to the column ID in the APPLICATIONTYPE table.
	 */
	protected String id;

	/** 
	 * This attribute maps to the column TYPE in the APPLICATIONTYPE table.
	 */
	protected String type;

	/** 
	 * This attribute maps to the column APPLICATION_REVISION in the APPLICATIONTYPE table.
	 */
	protected String applicationRevision;

	/** 
	 * This attribute maps to the column APPLICATION_VERSION in the APPLICATIONTYPE table.
	 */
	protected String applicationVersion;

	/** 
	 * This attribute maps to the column MANAGEMENT_STATUS in the APPLICATIONTYPE table.
	 */
	protected String managementStatus;

	/** 
	 * This attribute maps to the column MANUFACTURER_PK in the APPLICATIONTYPE table.
	 */
	protected String manufacturerPk;

	/** 
	 * This attribute maps to the column MANUFACTURER_TYPE in the APPLICATIONTYPE table.
	 */
	protected String manufacturerType;

	/** 
	 * This attribute maps to the column MANUFACTURER_PART_NUMBER in the APPLICATIONTYPE table.
	 */
	protected String manufacturerPartNumber;

	/** 
	 * This attribute maps to the column MANUFACTURER_PART_CODE in the APPLICATIONTYPE table.
	 */
	protected String manufacturerPartCode;

	/** 
	 * This attribute maps to the column MANUFACTURER_BRAND_NAME in the APPLICATIONTYPE table.
	 */
	protected String manufacturerBrandName;

	/** 
	 * This attribute maps to the column MANUFACTURER_UNIT_COST in the APPLICATIONTYPE table.
	 */
	protected float manufacturerUnitCost;

	/** 
	 * This attribute represents whether the primitive attribute manufacturerUnitCost is null.
	 */
	protected boolean manufacturerUnitCostNull = true;

	/** 
	 * This attribute maps to the column CUSTOM_1 in the APPLICATIONTYPE table.
	 */
	protected String custom1;

	/** 
	 * This attribute maps to the column CUSTOM_2 in the APPLICATIONTYPE table.
	 */
	protected String custom2;

	/** 
	 * This attribute maps to the column CUSTOM_3 in the APPLICATIONTYPE table.
	 */
	protected String custom3;

	/** 
	 * This attribute maps to the column CUSTOM_4 in the APPLICATIONTYPE table.
	 */
	protected String custom4;

	/** 
	 * This attribute maps to the column CUSTOM_5 in the APPLICATIONTYPE table.
	 */
	protected String custom5;

	/** 
	 * This attribute maps to the column OBJECT_DEFAULT_KEY_TYPE in the APPLICATIONTYPE table.
	 */
	protected String objectDefaultKeyType;

	/** 
	 * This attribute maps to the column OBJECT_DEFAULT_KEY_PK in the APPLICATIONTYPE table.
	 */
	protected String objectDefaultKeyPk;

	/** 
	 * This attribute maps to the column SUB_CATEGORY_KEY_TYPE in the APPLICATIONTYPE table.
	 */
	protected String subCategoryKeyType;

	/** 
	 * This attribute maps to the column SUB_CATEGORY_KEY_PK in the APPLICATIONTYPE table.
	 */
	protected String subCategoryKeyPk;

	/** 
	 * This attribute maps to the column DESCRIPTION in the APPLICATIONTYPE table.
	 */
	protected String description;

	/** 
	 * This attribute maps to the column LONG_DESCRIPTION in the APPLICATIONTYPE table.
	 */
	protected String longDescription;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_USER_ID in the APPLICATIONTYPE table.
	 */
	protected String lastModificationUserId;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_DATE in the APPLICATIONTYPE table.
	 */
	protected Date lastModificationDate;

	/** 
	 * This attribute maps to the column LASTUPDATEVERSIONNUMBER in the APPLICATIONTYPE table.
	 */
	protected BigDecimal lastupdateversionnumber;

	/** 
	 * This attribute maps to the column CUSTOM_6 in the APPLICATIONTYPE table.
	 */
	protected String custom6;

	/** 
	 * This attribute maps to the column CUSTOM_7 in the APPLICATIONTYPE table.
	 */
	protected String custom7;

	/** 
	 * This attribute maps to the column CUSTOM_8 in the APPLICATIONTYPE table.
	 */
	protected String custom8;

	/** 
	 * This attribute maps to the column CUSTOM_9 in the APPLICATIONTYPE table.
	 */
	protected String custom9;

	/** 
	 * This attribute maps to the column CUSTOM_10 in the APPLICATIONTYPE table.
	 */
	protected String custom10;

	/** 
	 * This attribute maps to the column ENVIRONMENT in the APPLICATIONTYPE table.
	 */
	protected String environment;

	/** 
	 * This attribute maps to the column INVENTORY_KEY_TYPE in the APPLICATIONTYPE table.
	 */
	protected String inventoryKeyType;

	/** 
	 * This attribute maps to the column INVENTORY_KEY_PK in the APPLICATIONTYPE table.
	 */
	protected String inventoryKeyPk;

	/** 
	 * This attribute maps to the column IS_OVERLAY_COMPONENT in the APPLICATIONTYPE table.
	 */
	protected int isOverlayComponent;

	/** 
	 * This attribute represents whether the primitive attribute isOverlayComponent is null.
	 */
	protected boolean isOverlayComponentNull = true;

	/**
	 * Method 'Applicationtype'
	 * 
	 */
	public Applicationtype()
	{
	}

	/**
	 * Method 'getId'
	 * 
	 * @return String
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * Method 'setId'
	 * 
	 * @param id
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * Method 'getType'
	 * 
	 * @return String
	 */
	public String getType()
	{
		return type;
	}

	/**
	 * Method 'setType'
	 * 
	 * @param type
	 */
	public void setType(String type)
	{
		this.type = type;
	}

	/**
	 * Method 'getApplicationRevision'
	 * 
	 * @return String
	 */
	public String getApplicationRevision()
	{
		return applicationRevision;
	}

	/**
	 * Method 'setApplicationRevision'
	 * 
	 * @param applicationRevision
	 */
	public void setApplicationRevision(String applicationRevision)
	{
		this.applicationRevision = applicationRevision;
	}

	/**
	 * Method 'getApplicationVersion'
	 * 
	 * @return String
	 */
	public String getApplicationVersion()
	{
		return applicationVersion;
	}

	/**
	 * Method 'setApplicationVersion'
	 * 
	 * @param applicationVersion
	 */
	public void setApplicationVersion(String applicationVersion)
	{
		this.applicationVersion = applicationVersion;
	}

	/**
	 * Method 'getManagementStatus'
	 * 
	 * @return String
	 */
	public String getManagementStatus()
	{
		return managementStatus;
	}

	/**
	 * Method 'setManagementStatus'
	 * 
	 * @param managementStatus
	 */
	public void setManagementStatus(String managementStatus)
	{
		this.managementStatus = managementStatus;
	}

	/**
	 * Method 'getManufacturerPk'
	 * 
	 * @return String
	 */
	public String getManufacturerPk()
	{
		return manufacturerPk;
	}

	/**
	 * Method 'setManufacturerPk'
	 * 
	 * @param manufacturerPk
	 */
	public void setManufacturerPk(String manufacturerPk)
	{
		this.manufacturerPk = manufacturerPk;
	}

	/**
	 * Method 'getManufacturerType'
	 * 
	 * @return String
	 */
	public String getManufacturerType()
	{
		return manufacturerType;
	}

	/**
	 * Method 'setManufacturerType'
	 * 
	 * @param manufacturerType
	 */
	public void setManufacturerType(String manufacturerType)
	{
		this.manufacturerType = manufacturerType;
	}

	/**
	 * Method 'getManufacturerPartNumber'
	 * 
	 * @return String
	 */
	public String getManufacturerPartNumber()
	{
		return manufacturerPartNumber;
	}

	/**
	 * Method 'setManufacturerPartNumber'
	 * 
	 * @param manufacturerPartNumber
	 */
	public void setManufacturerPartNumber(String manufacturerPartNumber)
	{
		this.manufacturerPartNumber = manufacturerPartNumber;
	}

	/**
	 * Method 'getManufacturerPartCode'
	 * 
	 * @return String
	 */
	public String getManufacturerPartCode()
	{
		return manufacturerPartCode;
	}

	/**
	 * Method 'setManufacturerPartCode'
	 * 
	 * @param manufacturerPartCode
	 */
	public void setManufacturerPartCode(String manufacturerPartCode)
	{
		this.manufacturerPartCode = manufacturerPartCode;
	}

	/**
	 * Method 'getManufacturerBrandName'
	 * 
	 * @return String
	 */
	public String getManufacturerBrandName()
	{
		return manufacturerBrandName;
	}

	/**
	 * Method 'setManufacturerBrandName'
	 * 
	 * @param manufacturerBrandName
	 */
	public void setManufacturerBrandName(String manufacturerBrandName)
	{
		this.manufacturerBrandName = manufacturerBrandName;
	}

	/**
	 * Method 'getManufacturerUnitCost'
	 * 
	 * @return float
	 */
	public float getManufacturerUnitCost()
	{
		return manufacturerUnitCost;
	}

	/**
	 * Method 'setManufacturerUnitCost'
	 * 
	 * @param manufacturerUnitCost
	 */
	public void setManufacturerUnitCost(float manufacturerUnitCost)
	{
		this.manufacturerUnitCost = manufacturerUnitCost;
		this.manufacturerUnitCostNull = false;
	}

	/**
	 * Method 'setManufacturerUnitCostNull'
	 * 
	 * @param value
	 */
	public void setManufacturerUnitCostNull(boolean value)
	{
		this.manufacturerUnitCostNull = value;
	}

	/**
	 * Method 'isManufacturerUnitCostNull'
	 * 
	 * @return boolean
	 */
	public boolean isManufacturerUnitCostNull()
	{
		return manufacturerUnitCostNull;
	}

	/**
	 * Method 'getCustom1'
	 * 
	 * @return String
	 */
	public String getCustom1()
	{
		return custom1;
	}

	/**
	 * Method 'setCustom1'
	 * 
	 * @param custom1
	 */
	public void setCustom1(String custom1)
	{
		this.custom1 = custom1;
	}

	/**
	 * Method 'getCustom2'
	 * 
	 * @return String
	 */
	public String getCustom2()
	{
		return custom2;
	}

	/**
	 * Method 'setCustom2'
	 * 
	 * @param custom2
	 */
	public void setCustom2(String custom2)
	{
		this.custom2 = custom2;
	}

	/**
	 * Method 'getCustom3'
	 * 
	 * @return String
	 */
	public String getCustom3()
	{
		return custom3;
	}

	/**
	 * Method 'setCustom3'
	 * 
	 * @param custom3
	 */
	public void setCustom3(String custom3)
	{
		this.custom3 = custom3;
	}

	/**
	 * Method 'getCustom4'
	 * 
	 * @return String
	 */
	public String getCustom4()
	{
		return custom4;
	}

	/**
	 * Method 'setCustom4'
	 * 
	 * @param custom4
	 */
	public void setCustom4(String custom4)
	{
		this.custom4 = custom4;
	}

	/**
	 * Method 'getCustom5'
	 * 
	 * @return String
	 */
	public String getCustom5()
	{
		return custom5;
	}

	/**
	 * Method 'setCustom5'
	 * 
	 * @param custom5
	 */
	public void setCustom5(String custom5)
	{
		this.custom5 = custom5;
	}

	/**
	 * Method 'getObjectDefaultKeyType'
	 * 
	 * @return String
	 */
	public String getObjectDefaultKeyType()
	{
		return objectDefaultKeyType;
	}

	/**
	 * Method 'setObjectDefaultKeyType'
	 * 
	 * @param objectDefaultKeyType
	 */
	public void setObjectDefaultKeyType(String objectDefaultKeyType)
	{
		this.objectDefaultKeyType = objectDefaultKeyType;
	}

	/**
	 * Method 'getObjectDefaultKeyPk'
	 * 
	 * @return String
	 */
	public String getObjectDefaultKeyPk()
	{
		return objectDefaultKeyPk;
	}

	/**
	 * Method 'setObjectDefaultKeyPk'
	 * 
	 * @param objectDefaultKeyPk
	 */
	public void setObjectDefaultKeyPk(String objectDefaultKeyPk)
	{
		this.objectDefaultKeyPk = objectDefaultKeyPk;
	}

	/**
	 * Method 'getSubCategoryKeyType'
	 * 
	 * @return String
	 */
	public String getSubCategoryKeyType()
	{
		return subCategoryKeyType;
	}

	/**
	 * Method 'setSubCategoryKeyType'
	 * 
	 * @param subCategoryKeyType
	 */
	public void setSubCategoryKeyType(String subCategoryKeyType)
	{
		this.subCategoryKeyType = subCategoryKeyType;
	}

	/**
	 * Method 'getSubCategoryKeyPk'
	 * 
	 * @return String
	 */
	public String getSubCategoryKeyPk()
	{
		return subCategoryKeyPk;
	}

	/**
	 * Method 'setSubCategoryKeyPk'
	 * 
	 * @param subCategoryKeyPk
	 */
	public void setSubCategoryKeyPk(String subCategoryKeyPk)
	{
		this.subCategoryKeyPk = subCategoryKeyPk;
	}

	/**
	 * Method 'getDescription'
	 * 
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Method 'setDescription'
	 * 
	 * @param description
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * Method 'getLongDescription'
	 * 
	 * @return String
	 */
	public String getLongDescription()
	{
		return longDescription;
	}

	/**
	 * Method 'setLongDescription'
	 * 
	 * @param longDescription
	 */
	public void setLongDescription(String longDescription)
	{
		this.longDescription = longDescription;
	}

	/**
	 * Method 'getLastModificationUserId'
	 * 
	 * @return String
	 */
	public String getLastModificationUserId()
	{
		return lastModificationUserId;
	}

	/**
	 * Method 'setLastModificationUserId'
	 * 
	 * @param lastModificationUserId
	 */
	public void setLastModificationUserId(String lastModificationUserId)
	{
		this.lastModificationUserId = lastModificationUserId;
	}

	/**
	 * Method 'getLastModificationDate'
	 * 
	 * @return Date
	 */
	public Date getLastModificationDate()
	{
		return lastModificationDate;
	}

	/**
	 * Method 'setLastModificationDate'
	 * 
	 * @param lastModificationDate
	 */
	public void setLastModificationDate(Date lastModificationDate)
	{
		this.lastModificationDate = lastModificationDate;
	}

	/**
	 * Method 'getLastupdateversionnumber'
	 * 
	 * @return BigDecimal
	 */
	public BigDecimal getLastupdateversionnumber()
	{
		return lastupdateversionnumber;
	}

	/**
	 * Method 'setLastupdateversionnumber'
	 * 
	 * @param lastupdateversionnumber
	 */
	public void setLastupdateversionnumber(BigDecimal lastupdateversionnumber)
	{
		this.lastupdateversionnumber = lastupdateversionnumber;
	}

	/**
	 * Method 'getCustom6'
	 * 
	 * @return String
	 */
	public String getCustom6()
	{
		return custom6;
	}

	/**
	 * Method 'setCustom6'
	 * 
	 * @param custom6
	 */
	public void setCustom6(String custom6)
	{
		this.custom6 = custom6;
	}

	/**
	 * Method 'getCustom7'
	 * 
	 * @return String
	 */
	public String getCustom7()
	{
		return custom7;
	}

	/**
	 * Method 'setCustom7'
	 * 
	 * @param custom7
	 */
	public void setCustom7(String custom7)
	{
		this.custom7 = custom7;
	}

	/**
	 * Method 'getCustom8'
	 * 
	 * @return String
	 */
	public String getCustom8()
	{
		return custom8;
	}

	/**
	 * Method 'setCustom8'
	 * 
	 * @param custom8
	 */
	public void setCustom8(String custom8)
	{
		this.custom8 = custom8;
	}

	/**
	 * Method 'getCustom9'
	 * 
	 * @return String
	 */
	public String getCustom9()
	{
		return custom9;
	}

	/**
	 * Method 'setCustom9'
	 * 
	 * @param custom9
	 */
	public void setCustom9(String custom9)
	{
		this.custom9 = custom9;
	}

	/**
	 * Method 'getCustom10'
	 * 
	 * @return String
	 */
	public String getCustom10()
	{
		return custom10;
	}

	/**
	 * Method 'setCustom10'
	 * 
	 * @param custom10
	 */
	public void setCustom10(String custom10)
	{
		this.custom10 = custom10;
	}

	/**
	 * Method 'getEnvironment'
	 * 
	 * @return String
	 */
	public String getEnvironment()
	{
		return environment;
	}

	/**
	 * Method 'setEnvironment'
	 * 
	 * @param environment
	 */
	public void setEnvironment(String environment)
	{
		this.environment = environment;
	}

	/**
	 * Method 'getInventoryKeyType'
	 * 
	 * @return String
	 */
	public String getInventoryKeyType()
	{
		return inventoryKeyType;
	}

	/**
	 * Method 'setInventoryKeyType'
	 * 
	 * @param inventoryKeyType
	 */
	public void setInventoryKeyType(String inventoryKeyType)
	{
		this.inventoryKeyType = inventoryKeyType;
	}

	/**
	 * Method 'getInventoryKeyPk'
	 * 
	 * @return String
	 */
	public String getInventoryKeyPk()
	{
		return inventoryKeyPk;
	}

	/**
	 * Method 'setInventoryKeyPk'
	 * 
	 * @param inventoryKeyPk
	 */
	public void setInventoryKeyPk(String inventoryKeyPk)
	{
		this.inventoryKeyPk = inventoryKeyPk;
	}

	/**
	 * Method 'getIsOverlayComponent'
	 * 
	 * @return int
	 */
	public int getIsOverlayComponent()
	{
		return isOverlayComponent;
	}

	/**
	 * Method 'setIsOverlayComponent'
	 * 
	 * @param isOverlayComponent
	 */
	public void setIsOverlayComponent(int isOverlayComponent)
	{
		this.isOverlayComponent = isOverlayComponent;
		this.isOverlayComponentNull = false;
	}

	/**
	 * Method 'setIsOverlayComponentNull'
	 * 
	 * @param value
	 */
	public void setIsOverlayComponentNull(boolean value)
	{
		this.isOverlayComponentNull = value;
	}

	/**
	 * Method 'isIsOverlayComponentNull'
	 * 
	 * @return boolean
	 */
	public boolean isIsOverlayComponentNull()
	{
		return isOverlayComponentNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof Applicationtype)) {
			return false;
		}
		
		final Applicationtype _cast = (Applicationtype) _other;
		if (id == null ? _cast.id != id : !id.equals( _cast.id )) {
			return false;
		}
		
		if (type == null ? _cast.type != type : !type.equals( _cast.type )) {
			return false;
		}
		
		if (applicationRevision == null ? _cast.applicationRevision != applicationRevision : !applicationRevision.equals( _cast.applicationRevision )) {
			return false;
		}
		
		if (applicationVersion == null ? _cast.applicationVersion != applicationVersion : !applicationVersion.equals( _cast.applicationVersion )) {
			return false;
		}
		
		if (managementStatus == null ? _cast.managementStatus != managementStatus : !managementStatus.equals( _cast.managementStatus )) {
			return false;
		}
		
		if (manufacturerPk == null ? _cast.manufacturerPk != manufacturerPk : !manufacturerPk.equals( _cast.manufacturerPk )) {
			return false;
		}
		
		if (manufacturerType == null ? _cast.manufacturerType != manufacturerType : !manufacturerType.equals( _cast.manufacturerType )) {
			return false;
		}
		
		if (manufacturerPartNumber == null ? _cast.manufacturerPartNumber != manufacturerPartNumber : !manufacturerPartNumber.equals( _cast.manufacturerPartNumber )) {
			return false;
		}
		
		if (manufacturerPartCode == null ? _cast.manufacturerPartCode != manufacturerPartCode : !manufacturerPartCode.equals( _cast.manufacturerPartCode )) {
			return false;
		}
		
		if (manufacturerBrandName == null ? _cast.manufacturerBrandName != manufacturerBrandName : !manufacturerBrandName.equals( _cast.manufacturerBrandName )) {
			return false;
		}
		
		if (manufacturerUnitCost != _cast.manufacturerUnitCost) {
			return false;
		}
		
		if (manufacturerUnitCostNull != _cast.manufacturerUnitCostNull) {
			return false;
		}
		
		if (custom1 == null ? _cast.custom1 != custom1 : !custom1.equals( _cast.custom1 )) {
			return false;
		}
		
		if (custom2 == null ? _cast.custom2 != custom2 : !custom2.equals( _cast.custom2 )) {
			return false;
		}
		
		if (custom3 == null ? _cast.custom3 != custom3 : !custom3.equals( _cast.custom3 )) {
			return false;
		}
		
		if (custom4 == null ? _cast.custom4 != custom4 : !custom4.equals( _cast.custom4 )) {
			return false;
		}
		
		if (custom5 == null ? _cast.custom5 != custom5 : !custom5.equals( _cast.custom5 )) {
			return false;
		}
		
		if (objectDefaultKeyType == null ? _cast.objectDefaultKeyType != objectDefaultKeyType : !objectDefaultKeyType.equals( _cast.objectDefaultKeyType )) {
			return false;
		}
		
		if (objectDefaultKeyPk == null ? _cast.objectDefaultKeyPk != objectDefaultKeyPk : !objectDefaultKeyPk.equals( _cast.objectDefaultKeyPk )) {
			return false;
		}
		
		if (subCategoryKeyType == null ? _cast.subCategoryKeyType != subCategoryKeyType : !subCategoryKeyType.equals( _cast.subCategoryKeyType )) {
			return false;
		}
		
		if (subCategoryKeyPk == null ? _cast.subCategoryKeyPk != subCategoryKeyPk : !subCategoryKeyPk.equals( _cast.subCategoryKeyPk )) {
			return false;
		}
		
		if (description == null ? _cast.description != description : !description.equals( _cast.description )) {
			return false;
		}
		
		if (longDescription == null ? _cast.longDescription != longDescription : !longDescription.equals( _cast.longDescription )) {
			return false;
		}
		
		if (lastModificationUserId == null ? _cast.lastModificationUserId != lastModificationUserId : !lastModificationUserId.equals( _cast.lastModificationUserId )) {
			return false;
		}
		
		if (lastModificationDate == null ? _cast.lastModificationDate != lastModificationDate : !lastModificationDate.equals( _cast.lastModificationDate )) {
			return false;
		}
		
		if (lastupdateversionnumber == null ? _cast.lastupdateversionnumber != lastupdateversionnumber : !lastupdateversionnumber.equals( _cast.lastupdateversionnumber )) {
			return false;
		}
		
		if (custom6 == null ? _cast.custom6 != custom6 : !custom6.equals( _cast.custom6 )) {
			return false;
		}
		
		if (custom7 == null ? _cast.custom7 != custom7 : !custom7.equals( _cast.custom7 )) {
			return false;
		}
		
		if (custom8 == null ? _cast.custom8 != custom8 : !custom8.equals( _cast.custom8 )) {
			return false;
		}
		
		if (custom9 == null ? _cast.custom9 != custom9 : !custom9.equals( _cast.custom9 )) {
			return false;
		}
		
		if (custom10 == null ? _cast.custom10 != custom10 : !custom10.equals( _cast.custom10 )) {
			return false;
		}
		
		if (environment == null ? _cast.environment != environment : !environment.equals( _cast.environment )) {
			return false;
		}
		
		if (inventoryKeyType == null ? _cast.inventoryKeyType != inventoryKeyType : !inventoryKeyType.equals( _cast.inventoryKeyType )) {
			return false;
		}
		
		if (inventoryKeyPk == null ? _cast.inventoryKeyPk != inventoryKeyPk : !inventoryKeyPk.equals( _cast.inventoryKeyPk )) {
			return false;
		}
		
		if (isOverlayComponent != _cast.isOverlayComponent) {
			return false;
		}
		
		if (isOverlayComponentNull != _cast.isOverlayComponentNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (id != null) {
			_hashCode = 29 * _hashCode + id.hashCode();
		}
		
		if (type != null) {
			_hashCode = 29 * _hashCode + type.hashCode();
		}
		
		if (applicationRevision != null) {
			_hashCode = 29 * _hashCode + applicationRevision.hashCode();
		}
		
		if (applicationVersion != null) {
			_hashCode = 29 * _hashCode + applicationVersion.hashCode();
		}
		
		if (managementStatus != null) {
			_hashCode = 29 * _hashCode + managementStatus.hashCode();
		}
		
		if (manufacturerPk != null) {
			_hashCode = 29 * _hashCode + manufacturerPk.hashCode();
		}
		
		if (manufacturerType != null) {
			_hashCode = 29 * _hashCode + manufacturerType.hashCode();
		}
		
		if (manufacturerPartNumber != null) {
			_hashCode = 29 * _hashCode + manufacturerPartNumber.hashCode();
		}
		
		if (manufacturerPartCode != null) {
			_hashCode = 29 * _hashCode + manufacturerPartCode.hashCode();
		}
		
		if (manufacturerBrandName != null) {
			_hashCode = 29 * _hashCode + manufacturerBrandName.hashCode();
		}
		
		_hashCode = 29 * _hashCode + Float.floatToIntBits(manufacturerUnitCost);
		_hashCode = 29 * _hashCode + (manufacturerUnitCostNull ? 1 : 0);
		if (custom1 != null) {
			_hashCode = 29 * _hashCode + custom1.hashCode();
		}
		
		if (custom2 != null) {
			_hashCode = 29 * _hashCode + custom2.hashCode();
		}
		
		if (custom3 != null) {
			_hashCode = 29 * _hashCode + custom3.hashCode();
		}
		
		if (custom4 != null) {
			_hashCode = 29 * _hashCode + custom4.hashCode();
		}
		
		if (custom5 != null) {
			_hashCode = 29 * _hashCode + custom5.hashCode();
		}
		
		if (objectDefaultKeyType != null) {
			_hashCode = 29 * _hashCode + objectDefaultKeyType.hashCode();
		}
		
		if (objectDefaultKeyPk != null) {
			_hashCode = 29 * _hashCode + objectDefaultKeyPk.hashCode();
		}
		
		if (subCategoryKeyType != null) {
			_hashCode = 29 * _hashCode + subCategoryKeyType.hashCode();
		}
		
		if (subCategoryKeyPk != null) {
			_hashCode = 29 * _hashCode + subCategoryKeyPk.hashCode();
		}
		
		if (description != null) {
			_hashCode = 29 * _hashCode + description.hashCode();
		}
		
		if (longDescription != null) {
			_hashCode = 29 * _hashCode + longDescription.hashCode();
		}
		
		if (lastModificationUserId != null) {
			_hashCode = 29 * _hashCode + lastModificationUserId.hashCode();
		}
		
		if (lastModificationDate != null) {
			_hashCode = 29 * _hashCode + lastModificationDate.hashCode();
		}
		
		if (lastupdateversionnumber != null) {
			_hashCode = 29 * _hashCode + lastupdateversionnumber.hashCode();
		}
		
		if (custom6 != null) {
			_hashCode = 29 * _hashCode + custom6.hashCode();
		}
		
		if (custom7 != null) {
			_hashCode = 29 * _hashCode + custom7.hashCode();
		}
		
		if (custom8 != null) {
			_hashCode = 29 * _hashCode + custom8.hashCode();
		}
		
		if (custom9 != null) {
			_hashCode = 29 * _hashCode + custom9.hashCode();
		}
		
		if (custom10 != null) {
			_hashCode = 29 * _hashCode + custom10.hashCode();
		}
		
		if (environment != null) {
			_hashCode = 29 * _hashCode + environment.hashCode();
		}
		
		if (inventoryKeyType != null) {
			_hashCode = 29 * _hashCode + inventoryKeyType.hashCode();
		}
		
		if (inventoryKeyPk != null) {
			_hashCode = 29 * _hashCode + inventoryKeyPk.hashCode();
		}
		
		_hashCode = 29 * _hashCode + isOverlayComponent;
		_hashCode = 29 * _hashCode + (isOverlayComponentNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return ApplicationtypePk
	 */
	public ApplicationtypePk createPk()
	{
		return new ApplicationtypePk(id);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.fedex.emea.sd.dto.Applicationtype: " );
		ret.append( "id=" + id );
		ret.append( ", type=" + type );
		ret.append( ", applicationRevision=" + applicationRevision );
		ret.append( ", applicationVersion=" + applicationVersion );
		ret.append( ", managementStatus=" + managementStatus );
		ret.append( ", manufacturerPk=" + manufacturerPk );
		ret.append( ", manufacturerType=" + manufacturerType );
		ret.append( ", manufacturerPartNumber=" + manufacturerPartNumber );
		ret.append( ", manufacturerPartCode=" + manufacturerPartCode );
		ret.append( ", manufacturerBrandName=" + manufacturerBrandName );
		ret.append( ", manufacturerUnitCost=" + manufacturerUnitCost );
		ret.append( ", custom1=" + custom1 );
		ret.append( ", custom2=" + custom2 );
		ret.append( ", custom3=" + custom3 );
		ret.append( ", custom4=" + custom4 );
		ret.append( ", custom5=" + custom5 );
		ret.append( ", objectDefaultKeyType=" + objectDefaultKeyType );
		ret.append( ", objectDefaultKeyPk=" + objectDefaultKeyPk );
		ret.append( ", subCategoryKeyType=" + subCategoryKeyType );
		ret.append( ", subCategoryKeyPk=" + subCategoryKeyPk );
		ret.append( ", description=" + description );
		ret.append( ", longDescription=" + longDescription );
		ret.append( ", lastModificationUserId=" + lastModificationUserId );
		ret.append( ", lastModificationDate=" + lastModificationDate );
		ret.append( ", lastupdateversionnumber=" + lastupdateversionnumber );
		ret.append( ", custom6=" + custom6 );
		ret.append( ", custom7=" + custom7 );
		ret.append( ", custom8=" + custom8 );
		ret.append( ", custom9=" + custom9 );
		ret.append( ", custom10=" + custom10 );
		ret.append( ", environment=" + environment );
		ret.append( ", inventoryKeyType=" + inventoryKeyType );
		ret.append( ", inventoryKeyPk=" + inventoryKeyPk );
		ret.append( ", isOverlayComponent=" + isOverlayComponent );
		return ret.toString();
	}

}
