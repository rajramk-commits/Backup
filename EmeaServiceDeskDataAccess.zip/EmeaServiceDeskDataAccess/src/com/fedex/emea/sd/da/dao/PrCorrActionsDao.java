package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrCorrActionsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrCorrActions;
import com.fedex.emea.sd.da.objects.PrCorrActionsPk;

public interface PrCorrActionsDao
{
	
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrCorrActionsDaoException;
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrCorrActionsDaoException;
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrCorrActionsPk
	 */
	public PrCorrActionsPk insert(PrCorrActions dto);

	/** 
	 * Updates a single row in the PR_CORR_ACTIONS table.
	 */
	public void update(PrCorrActionsPk pk, PrCorrActions dto) throws PrCorrActionsDaoException;

	/** 
	 * Deletes a single row in the PR_CORR_ACTIONS table.
	 */
	public void delete(PrCorrActionsPk pk) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId AND ITEM = :item'.
	 */
	public PrCorrActions findByPrimaryKey(String cy, String eaiId, String ni2AppId, String item) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria ''.
	 */
	public List<PrCorrActions> findAll() throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'CY = :cy'.
	 */
	public List<PrCorrActions> findWhereCyEquals(String cy) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	public List<PrCorrActions> findWhereEaiIdEquals(String eaiId) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	public List<PrCorrActions> findWhereSymAppNameEquals(String symAppName) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	public List<PrCorrActions> findWhereNi2AppIdEquals(String ni2AppId) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	public List<PrCorrActions> findWhereNi2AppNameEquals(String ni2AppName) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	public List<PrCorrActions> findWhereRespMdPinEquals(String respMdPin) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	public List<PrCorrActions> findWhereRespMgrPinEquals(String respMgrPin) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ITEM = :item'.
	 */
	public List<PrCorrActions> findWhereItemEquals(String item) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION = :action'.
	 */
	public List<PrCorrActions> findWhereActionEquals(String action) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_IMPORTANCE = :actionImportance'.
	 */
	public List<PrCorrActions> findWhereActionImportanceEquals(String actionImportance) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_BY = :actionBy'.
	 */
	public List<PrCorrActions> findWhereActionByEquals(Date actionBy) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_FEEDBACK = :actionFeedback'.
	 */
	public List<PrCorrActions> findWhereActionFeedbackEquals(String actionFeedback) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'ACTION_STATUS = :actionStatus'.
	 */
	public List<PrCorrActions> findWhereActionStatusEquals(String actionStatus) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	public List<PrCorrActions> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrCorrActionsDaoException;

	/** 
	 * Returns all rows from the PR_CORR_ACTIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	public List<PrCorrActions> findWhereAuditIdEquals(int auditId) throws PrCorrActionsDaoException;

	/** 
	 * Returns the rows from the PR_CORR_ACTIONS table that matches the specified primary-key value.
	 */
	public PrCorrActions findByPrimaryKey(PrCorrActionsPk pk) throws PrCorrActionsDaoException;

}
