package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

public class OvoMessages implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String    ovoMessageId;
	private String    ovoNode;
	private String    ovoAppGroup;
	private String    ovoAppName;
	private String    ovoAppObject;
	private Timestamp creationTime;
	private String    nexusCaseId;
	
	public OvoMessages() {
	}
	
	public OvoMessages(String ovoMessageId, String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject) {
		this.ovoMessageId = ovoMessageId;
		this.ovoNode = ovoNode;
		this.ovoAppGroup = ovoAppGroup;
		this.ovoAppName = ovoAppName;
		this.ovoAppObject = ovoAppObject;
	}
	
	public OvoMessages(String ovoMessageId, String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject, String nexusCaseId) {
		this.ovoMessageId = ovoMessageId;
		this.ovoNode = ovoNode;
		this.ovoAppGroup = ovoAppGroup;
		this.ovoAppName = ovoAppName;
		this.ovoAppObject = ovoAppObject;
		this.nexusCaseId = nexusCaseId;
	}
	
	public OvoMessages(OvoObject ovoMessage, String nexusCaseId) {
		this.setOvoMessageId(ovoMessage.getMessageID().trim());
		this.setOvoNode(ovoMessage.getMessageNodeName());
		this.setOvoAppGroup(ovoMessage.getMessageGroup());
		this.setOvoAppName(ovoMessage.getApplicationName());
		this.setOvoAppObject(ovoMessage.getObjectName());
		this.setCreationTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		this.setNexusCaseId(nexusCaseId);
	}

	public String getOvoMessageId() {
		return ovoMessageId;
	}

	public void setOvoMessageId(String ovoMessageId) {
		this.ovoMessageId = ovoMessageId;
	}

	public String getOvoNode() {
		return ovoNode;
	}

	public void setOvoNode(String ovoNode) {
		this.ovoNode = ovoNode;
	}

	public String getOvoAppGroup() {
		return ovoAppGroup;
	}

	public void setOvoAppGroup(String ovoAppGroup) {
		this.ovoAppGroup = ovoAppGroup;
	}

	public String getOvoAppName() {
		return ovoAppName;
	}

	public void setOvoAppName(String ovoAppName) {
		this.ovoAppName = ovoAppName;
	}

	public String getOvoAppObject() {
		return ovoAppObject;
	}

	public void setOvoAppObject(String ovoAppObject) {
		this.ovoAppObject = ovoAppObject;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public String getNexusCaseId() {
		return nexusCaseId;
	}

	public void setNexusCaseId(String nexusCaseId) {
		this.nexusCaseId = nexusCaseId;
	}
	
	
}
