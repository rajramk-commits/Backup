package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;
import java.math.BigDecimal;

public class Allocatedtoassociation implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1950976193723721874L;

	/** 
	 * This attribute maps to the column ID in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String id;

	/** 
	 * This attribute maps to the column ALLOCATEE_KEY_PK in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String allocateeKeyPk;

	/** 
	 * This attribute maps to the column ALLOCATEE_KEY_TYPE in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String allocateeKeyType;

	/** 
	 * This attribute maps to the column ALLOCATED_KEY_PK in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String allocatedKeyPk;

	/** 
	 * This attribute maps to the column ALLOCATED_KEY_TYPE in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String allocatedKeyType;

	/** 
	 * This attribute maps to the column DESCRIPTION in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String description;

	/** 
	 * This attribute maps to the column LONG_DESCRIPTION in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String longDescription;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_USER_ID in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String lastModificationUserId;

	/** 
	 * This attribute maps to the column LAST_MODIFICATION_DATE in the ALLOCATEDTOASSOCIATION table.
	 */
	protected Date lastModificationDate;

	/** 
	 * This attribute maps to the column LASTUPDATEVERSIONNUMBER in the ALLOCATEDTOASSOCIATION table.
	 */
	protected BigDecimal lastupdateversionnumber;

	/** 
	 * This attribute maps to the column CUSTOM_1 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom1;

	/** 
	 * This attribute maps to the column CUSTOM_2 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom2;

	/** 
	 * This attribute maps to the column CUSTOM_3 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom3;

	/** 
	 * This attribute maps to the column CUSTOM_4 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom4;

	/** 
	 * This attribute maps to the column CUSTOM_5 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom5;

	/** 
	 * This attribute maps to the column CUSTOM_6 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom6;

	/** 
	 * This attribute maps to the column CUSTOM_7 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom7;

	/** 
	 * This attribute maps to the column CUSTOM_8 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom8;

	/** 
	 * This attribute maps to the column CUSTOM_9 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom9;

	/** 
	 * This attribute maps to the column CUSTOM_10 in the ALLOCATEDTOASSOCIATION table.
	 */
	protected String custom10;

	/** 
	 * This attribute maps to the column IS_OVERLAY_COMPONENT in the ALLOCATEDTOASSOCIATION table.
	 */
	protected int isOverlayComponent;

	/** 
	 * This attribute represents whether the primitive attribute isOverlayComponent is null.
	 */
	protected boolean isOverlayComponentNull = true;

	/**
	 * Method 'Allocatedtoassociation'
	 * 
	 */
	public Allocatedtoassociation()
	{
	}

	/**
	 * Method 'getId'
	 * 
	 * @return String
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * Method 'setId'
	 * 
	 * @param id
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/**
	 * Method 'getAllocateeKeyPk'
	 * 
	 * @return String
	 */
	public String getAllocateeKeyPk()
	{
		return allocateeKeyPk;
	}

	/**
	 * Method 'setAllocateeKeyPk'
	 * 
	 * @param allocateeKeyPk
	 */
	public void setAllocateeKeyPk(String allocateeKeyPk)
	{
		this.allocateeKeyPk = allocateeKeyPk;
	}

	/**
	 * Method 'getAllocateeKeyType'
	 * 
	 * @return String
	 */
	public String getAllocateeKeyType()
	{
		return allocateeKeyType;
	}

	/**
	 * Method 'setAllocateeKeyType'
	 * 
	 * @param allocateeKeyType
	 */
	public void setAllocateeKeyType(String allocateeKeyType)
	{
		this.allocateeKeyType = allocateeKeyType;
	}

	/**
	 * Method 'getAllocatedKeyPk'
	 * 
	 * @return String
	 */
	public String getAllocatedKeyPk()
	{
		return allocatedKeyPk;
	}

	/**
	 * Method 'setAllocatedKeyPk'
	 * 
	 * @param allocatedKeyPk
	 */
	public void setAllocatedKeyPk(String allocatedKeyPk)
	{
		this.allocatedKeyPk = allocatedKeyPk;
	}

	/**
	 * Method 'getAllocatedKeyType'
	 * 
	 * @return String
	 */
	public String getAllocatedKeyType()
	{
		return allocatedKeyType;
	}

	/**
	 * Method 'setAllocatedKeyType'
	 * 
	 * @param allocatedKeyType
	 */
	public void setAllocatedKeyType(String allocatedKeyType)
	{
		this.allocatedKeyType = allocatedKeyType;
	}

	/**
	 * Method 'getDescription'
	 * 
	 * @return String
	 */
	public String getDescription()
	{
		return description;
	}

	/**
	 * Method 'setDescription'
	 * 
	 * @param description
	 */
	public void setDescription(String description)
	{
		this.description = description;
	}

	/**
	 * Method 'getLongDescription'
	 * 
	 * @return String
	 */
	public String getLongDescription()
	{
		return longDescription;
	}

	/**
	 * Method 'setLongDescription'
	 * 
	 * @param longDescription
	 */
	public void setLongDescription(String longDescription)
	{
		this.longDescription = longDescription;
	}

	/**
	 * Method 'getLastModificationUserId'
	 * 
	 * @return String
	 */
	public String getLastModificationUserId()
	{
		return lastModificationUserId;
	}

	/**
	 * Method 'setLastModificationUserId'
	 * 
	 * @param lastModificationUserId
	 */
	public void setLastModificationUserId(String lastModificationUserId)
	{
		this.lastModificationUserId = lastModificationUserId;
	}

	/**
	 * Method 'getLastModificationDate'
	 * 
	 * @return Date
	 */
	public Date getLastModificationDate()
	{
		return lastModificationDate;
	}

	/**
	 * Method 'setLastModificationDate'
	 * 
	 * @param lastModificationDate
	 */
	public void setLastModificationDate(Date lastModificationDate)
	{
		this.lastModificationDate = lastModificationDate;
	}

	/**
	 * Method 'getLastupdateversionnumber'
	 * 
	 * @return BigDecimal
	 */
	public BigDecimal getLastupdateversionnumber()
	{
		return lastupdateversionnumber;
	}

	/**
	 * Method 'setLastupdateversionnumber'
	 * 
	 * @param lastupdateversionnumber
	 */
	public void setLastupdateversionnumber(BigDecimal lastupdateversionnumber)
	{
		this.lastupdateversionnumber = lastupdateversionnumber;
	}

	/**
	 * Method 'getCustom1'
	 * 
	 * @return String
	 */
	public String getCustom1()
	{
		return custom1;
	}

	/**
	 * Method 'setCustom1'
	 * 
	 * @param custom1
	 */
	public void setCustom1(String custom1)
	{
		this.custom1 = custom1;
	}

	/**
	 * Method 'getCustom2'
	 * 
	 * @return String
	 */
	public String getCustom2()
	{
		return custom2;
	}

	/**
	 * Method 'setCustom2'
	 * 
	 * @param custom2
	 */
	public void setCustom2(String custom2)
	{
		this.custom2 = custom2;
	}

	/**
	 * Method 'getCustom3'
	 * 
	 * @return String
	 */
	public String getCustom3()
	{
		return custom3;
	}

	/**
	 * Method 'setCustom3'
	 * 
	 * @param custom3
	 */
	public void setCustom3(String custom3)
	{
		this.custom3 = custom3;
	}

	/**
	 * Method 'getCustom4'
	 * 
	 * @return String
	 */
	public String getCustom4()
	{
		return custom4;
	}

	/**
	 * Method 'setCustom4'
	 * 
	 * @param custom4
	 */
	public void setCustom4(String custom4)
	{
		this.custom4 = custom4;
	}

	/**
	 * Method 'getCustom5'
	 * 
	 * @return String
	 */
	public String getCustom5()
	{
		return custom5;
	}

	/**
	 * Method 'setCustom5'
	 * 
	 * @param custom5
	 */
	public void setCustom5(String custom5)
	{
		this.custom5 = custom5;
	}

	/**
	 * Method 'getCustom6'
	 * 
	 * @return String
	 */
	public String getCustom6()
	{
		return custom6;
	}

	/**
	 * Method 'setCustom6'
	 * 
	 * @param custom6
	 */
	public void setCustom6(String custom6)
	{
		this.custom6 = custom6;
	}

	/**
	 * Method 'getCustom7'
	 * 
	 * @return String
	 */
	public String getCustom7()
	{
		return custom7;
	}

	/**
	 * Method 'setCustom7'
	 * 
	 * @param custom7
	 */
	public void setCustom7(String custom7)
	{
		this.custom7 = custom7;
	}

	/**
	 * Method 'getCustom8'
	 * 
	 * @return String
	 */
	public String getCustom8()
	{
		return custom8;
	}

	/**
	 * Method 'setCustom8'
	 * 
	 * @param custom8
	 */
	public void setCustom8(String custom8)
	{
		this.custom8 = custom8;
	}

	/**
	 * Method 'getCustom9'
	 * 
	 * @return String
	 */
	public String getCustom9()
	{
		return custom9;
	}

	/**
	 * Method 'setCustom9'
	 * 
	 * @param custom9
	 */
	public void setCustom9(String custom9)
	{
		this.custom9 = custom9;
	}

	/**
	 * Method 'getCustom10'
	 * 
	 * @return String
	 */
	public String getCustom10()
	{
		return custom10;
	}

	/**
	 * Method 'setCustom10'
	 * 
	 * @param custom10
	 */
	public void setCustom10(String custom10)
	{
		this.custom10 = custom10;
	}

	/**
	 * Method 'getIsOverlayComponent'
	 * 
	 * @return int
	 */
	public int getIsOverlayComponent()
	{
		return isOverlayComponent;
	}

	/**
	 * Method 'setIsOverlayComponent'
	 * 
	 * @param isOverlayComponent
	 */
	public void setIsOverlayComponent(int isOverlayComponent)
	{
		this.isOverlayComponent = isOverlayComponent;
		this.isOverlayComponentNull = false;
	}

	/**
	 * Method 'setIsOverlayComponentNull'
	 * 
	 * @param value
	 */
	public void setIsOverlayComponentNull(boolean value)
	{
		this.isOverlayComponentNull = value;
	}

	/**
	 * Method 'isIsOverlayComponentNull'
	 * 
	 * @return boolean
	 */
	public boolean isIsOverlayComponentNull()
	{
		return isOverlayComponentNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof Allocatedtoassociation)) {
			return false;
		}
		
		final Allocatedtoassociation _cast = (Allocatedtoassociation) _other;
		if (id == null ? _cast.id != id : !id.equals( _cast.id )) {
			return false;
		}
		
		if (allocateeKeyPk == null ? _cast.allocateeKeyPk != allocateeKeyPk : !allocateeKeyPk.equals( _cast.allocateeKeyPk )) {
			return false;
		}
		
		if (allocateeKeyType == null ? _cast.allocateeKeyType != allocateeKeyType : !allocateeKeyType.equals( _cast.allocateeKeyType )) {
			return false;
		}
		
		if (allocatedKeyPk == null ? _cast.allocatedKeyPk != allocatedKeyPk : !allocatedKeyPk.equals( _cast.allocatedKeyPk )) {
			return false;
		}
		
		if (allocatedKeyType == null ? _cast.allocatedKeyType != allocatedKeyType : !allocatedKeyType.equals( _cast.allocatedKeyType )) {
			return false;
		}
		
		if (description == null ? _cast.description != description : !description.equals( _cast.description )) {
			return false;
		}
		
		if (longDescription == null ? _cast.longDescription != longDescription : !longDescription.equals( _cast.longDescription )) {
			return false;
		}
		
		if (lastModificationUserId == null ? _cast.lastModificationUserId != lastModificationUserId : !lastModificationUserId.equals( _cast.lastModificationUserId )) {
			return false;
		}
		
		if (lastModificationDate == null ? _cast.lastModificationDate != lastModificationDate : !lastModificationDate.equals( _cast.lastModificationDate )) {
			return false;
		}
		
		if (lastupdateversionnumber == null ? _cast.lastupdateversionnumber != lastupdateversionnumber : !lastupdateversionnumber.equals( _cast.lastupdateversionnumber )) {
			return false;
		}
		
		if (custom1 == null ? _cast.custom1 != custom1 : !custom1.equals( _cast.custom1 )) {
			return false;
		}
		
		if (custom2 == null ? _cast.custom2 != custom2 : !custom2.equals( _cast.custom2 )) {
			return false;
		}
		
		if (custom3 == null ? _cast.custom3 != custom3 : !custom3.equals( _cast.custom3 )) {
			return false;
		}
		
		if (custom4 == null ? _cast.custom4 != custom4 : !custom4.equals( _cast.custom4 )) {
			return false;
		}
		
		if (custom5 == null ? _cast.custom5 != custom5 : !custom5.equals( _cast.custom5 )) {
			return false;
		}
		
		if (custom6 == null ? _cast.custom6 != custom6 : !custom6.equals( _cast.custom6 )) {
			return false;
		}
		
		if (custom7 == null ? _cast.custom7 != custom7 : !custom7.equals( _cast.custom7 )) {
			return false;
		}
		
		if (custom8 == null ? _cast.custom8 != custom8 : !custom8.equals( _cast.custom8 )) {
			return false;
		}
		
		if (custom9 == null ? _cast.custom9 != custom9 : !custom9.equals( _cast.custom9 )) {
			return false;
		}
		
		if (custom10 == null ? _cast.custom10 != custom10 : !custom10.equals( _cast.custom10 )) {
			return false;
		}
		
		if (isOverlayComponent != _cast.isOverlayComponent) {
			return false;
		}
		
		if (isOverlayComponentNull != _cast.isOverlayComponentNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (id != null) {
			_hashCode = 29 * _hashCode + id.hashCode();
		}
		
		if (allocateeKeyPk != null) {
			_hashCode = 29 * _hashCode + allocateeKeyPk.hashCode();
		}
		
		if (allocateeKeyType != null) {
			_hashCode = 29 * _hashCode + allocateeKeyType.hashCode();
		}
		
		if (allocatedKeyPk != null) {
			_hashCode = 29 * _hashCode + allocatedKeyPk.hashCode();
		}
		
		if (allocatedKeyType != null) {
			_hashCode = 29 * _hashCode + allocatedKeyType.hashCode();
		}
		
		if (description != null) {
			_hashCode = 29 * _hashCode + description.hashCode();
		}
		
		if (longDescription != null) {
			_hashCode = 29 * _hashCode + longDescription.hashCode();
		}
		
		if (lastModificationUserId != null) {
			_hashCode = 29 * _hashCode + lastModificationUserId.hashCode();
		}
		
		if (lastModificationDate != null) {
			_hashCode = 29 * _hashCode + lastModificationDate.hashCode();
		}
		
		if (lastupdateversionnumber != null) {
			_hashCode = 29 * _hashCode + lastupdateversionnumber.hashCode();
		}
		
		if (custom1 != null) {
			_hashCode = 29 * _hashCode + custom1.hashCode();
		}
		
		if (custom2 != null) {
			_hashCode = 29 * _hashCode + custom2.hashCode();
		}
		
		if (custom3 != null) {
			_hashCode = 29 * _hashCode + custom3.hashCode();
		}
		
		if (custom4 != null) {
			_hashCode = 29 * _hashCode + custom4.hashCode();
		}
		
		if (custom5 != null) {
			_hashCode = 29 * _hashCode + custom5.hashCode();
		}
		
		if (custom6 != null) {
			_hashCode = 29 * _hashCode + custom6.hashCode();
		}
		
		if (custom7 != null) {
			_hashCode = 29 * _hashCode + custom7.hashCode();
		}
		
		if (custom8 != null) {
			_hashCode = 29 * _hashCode + custom8.hashCode();
		}
		
		if (custom9 != null) {
			_hashCode = 29 * _hashCode + custom9.hashCode();
		}
		
		if (custom10 != null) {
			_hashCode = 29 * _hashCode + custom10.hashCode();
		}
		
		_hashCode = 29 * _hashCode + isOverlayComponent;
		_hashCode = 29 * _hashCode + (isOverlayComponentNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return AllocatedtoassociationPk
	 */
	public AllocatedtoassociationPk createPk()
	{
		return new AllocatedtoassociationPk(id);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.fedex.emea.sd.dto.Allocatedtoassociation: " );
		ret.append( "id=" + id );
		ret.append( ", allocateeKeyPk=" + allocateeKeyPk );
		ret.append( ", allocateeKeyType=" + allocateeKeyType );
		ret.append( ", allocatedKeyPk=" + allocatedKeyPk );
		ret.append( ", allocatedKeyType=" + allocatedKeyType );
		ret.append( ", description=" + description );
		ret.append( ", longDescription=" + longDescription );
		ret.append( ", lastModificationUserId=" + lastModificationUserId );
		ret.append( ", lastModificationDate=" + lastModificationDate );
		ret.append( ", lastupdateversionnumber=" + lastupdateversionnumber );
		ret.append( ", custom1=" + custom1 );
		ret.append( ", custom2=" + custom2 );
		ret.append( ", custom3=" + custom3 );
		ret.append( ", custom4=" + custom4 );
		ret.append( ", custom5=" + custom5 );
		ret.append( ", custom6=" + custom6 );
		ret.append( ", custom7=" + custom7 );
		ret.append( ", custom8=" + custom8 );
		ret.append( ", custom9=" + custom9 );
		ret.append( ", custom10=" + custom10 );
		ret.append( ", isOverlayComponent=" + isOverlayComponent );
		return ret.toString();
	}

}
