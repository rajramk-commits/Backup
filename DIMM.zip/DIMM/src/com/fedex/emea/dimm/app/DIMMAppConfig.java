package com.fedex.emea.dimm.app;

import java.util.Map;

import com.fedex.emea.dimm.config.AbstractPropertyFileBasedConfig;
import com.fedex.emea.dimm.config.MailConfig;
import com.fedex.emea.dimm.utils.CipherUtils;
import com.fedex.emea.dimm.utils.jdbc.DBConfig;

public class DIMMAppConfig extends AbstractPropertyFileBasedConfig{

	private static final String ALERT_STAGING_DB_JDBC_URL = "alert.staging.db.jdbc";
	
	private static final String ALERT_STAGING_DB_USER_NAME = "alert.staging.db.username";
	
	private static final String ALERT_STAGING_DB_PASS_WORD = "alert.staging.db.password";
	
	private static final String ANTC_DB_JDBC_URL = "antc.db.jdbc";
	
	private static final String ANTC_DB_USER_NAME = "antc.db.username";
	
	private static final String ANTC_DB_PASS_WORD = "antc.db.password";
	
	private static final String NEXUS_DB_JDBC_URL = "nexus.db.jdbc";
	
	private static final String NEXUS_DB_USER_NAME = "nexus.db.username";
	
	private static final String NEXUS_DB_PASS_WORD = "nexus.db.password";
	
	private static final String MAIL_ADMIN = "mail.fedex.address.admin";
	private static final String MAIL_FROM = "mail.fedex.address.from";
	private static final String MAIL_TO = "mail.fedex.address.to";
	private static final String MAIL_SERVER_HOST = "mail.fedex.host";
	
	private DBConfig monitorAlertStagingDbConfig;
	
	private DBConfig antcDbConfig;
	
	private DBConfig nexusDbConfig;
	
	private MailConfig mailConfig;
		
	
	public DIMMAppConfig() throws Exception {
		super();
	}
	
	@Override
	protected String getPropertyFileName() {
		return "DIMMAppConfig.properties";
	}

	@Override
	protected boolean isAutoReloadConfig() {
		return false;//for application level configuration, we don't support auto reload, whenever the configuration is changed, restart the application is required
	}

	@Override
	protected void loadConfigFromProperties(Map<String, String> propertyMap) throws Exception{
		String alertStagingDbJdbcUrl = propertyMap.get(ALERT_STAGING_DB_JDBC_URL);
		String alertStagingDbUserName = propertyMap.get(ALERT_STAGING_DB_USER_NAME);
		String alertStagingDbPassword = CipherUtils.decrypt(propertyMap.get(ALERT_STAGING_DB_PASS_WORD));
		
		monitorAlertStagingDbConfig = new DBConfig(alertStagingDbJdbcUrl,alertStagingDbUserName,alertStagingDbPassword);
		
		String antcDbJdbcUrl = propertyMap.get(ANTC_DB_JDBC_URL);
		String antcDbUserName = propertyMap.get(ANTC_DB_USER_NAME);
		String antcDbPassword = CipherUtils.decrypt(propertyMap.get(ANTC_DB_PASS_WORD));
		
		antcDbConfig = new DBConfig(antcDbJdbcUrl,antcDbUserName,antcDbPassword);
		
		String nexusDbJdbcUrl = propertyMap.get(NEXUS_DB_JDBC_URL);
		String nexusDbUserName = propertyMap.get(NEXUS_DB_USER_NAME);
		String nexusDbPassword = CipherUtils.decrypt(propertyMap.get(NEXUS_DB_PASS_WORD));
		
		nexusDbConfig = new DBConfig(nexusDbJdbcUrl,nexusDbUserName,nexusDbPassword);
		
		String adminMail = propertyMap.get(MAIL_ADMIN);
		String mailFrom = propertyMap.get(MAIL_FROM);
		String mailTo = propertyMap.get(MAIL_TO);
		String mailHost = propertyMap.get(MAIL_SERVER_HOST);
		
		mailConfig = new MailConfig(mailHost, mailFrom, mailTo, adminMail);
	}

	public DBConfig getMonitorAlertStagingDbConfig() {
		return monitorAlertStagingDbConfig;
	}

	public DBConfig getAntcDbConfig() {
		return antcDbConfig;
	}
	
	public DBConfig getNexusDbConfig() {
		return nexusDbConfig;
	}

	public MailConfig getMailConfig() {
		return mailConfig;
	}

	public void setMailConfig(MailConfig mailConfig) {
		this.mailConfig = mailConfig;
	}

	
}
