package com.fedex.emea.sd.da.exceptions;

public class PrValidationsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 719503894348940554L;

	/**
	 * Method 'PrValidationsDaoException'
	 * 
	 * @param message
	 */
	public PrValidationsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrValidationsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrValidationsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
