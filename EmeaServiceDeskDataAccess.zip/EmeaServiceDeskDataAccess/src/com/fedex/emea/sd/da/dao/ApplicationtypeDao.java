package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.ApplicationtypeDaoException;
import com.fedex.emea.sd.da.objects.Applicationtype;
import com.fedex.emea.sd.da.objects.ApplicationtypePk;

public interface ApplicationtypeDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return ApplicationtypePk
	 */
	public ApplicationtypePk insert(Applicationtype dto);

	/** 
	 * Updates a single row in the APPLICATIONTYPE table.
	 */
	public void update(ApplicationtypePk pk, Applicationtype dto) throws ApplicationtypeDaoException;

	/** 
	 * Deletes a single row in the APPLICATIONTYPE table.
	 */
	public void delete(ApplicationtypePk pk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ID = :id'.
	 */
	public Applicationtype findByPrimaryKey(String id) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria ''.
	 */
	public List<Applicationtype> findAll() throws ApplicationtypeDaoException;
	
	public Applicationtype findRelatedToInPrScope(String appDefiningTypeKeyPk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ID = :id'.
	 */
	public List<Applicationtype> findWhereIdEquals(String id) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'TYPE = :type'.
	 */
	public List<Applicationtype> findWhereTypeEquals(String type) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'APPLICATION_REVISION = :applicationRevision'.
	 */
	public List<Applicationtype> findWhereApplicationRevisionEquals(String applicationRevision) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'APPLICATION_VERSION = :applicationVersion'.
	 */
	public List<Applicationtype> findWhereApplicationVersionEquals(String applicationVersion) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANAGEMENT_STATUS = :managementStatus'.
	 */
	public List<Applicationtype> findWhereManagementStatusEquals(String managementStatus) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PK = :manufacturerPk'.
	 */
	public List<Applicationtype> findWhereManufacturerPkEquals(String manufacturerPk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_TYPE = :manufacturerType'.
	 */
	public List<Applicationtype> findWhereManufacturerTypeEquals(String manufacturerType) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PART_NUMBER = :manufacturerPartNumber'.
	 */
	public List<Applicationtype> findWhereManufacturerPartNumberEquals(String manufacturerPartNumber) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PART_CODE = :manufacturerPartCode'.
	 */
	public List<Applicationtype> findWhereManufacturerPartCodeEquals(String manufacturerPartCode) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_BRAND_NAME = :manufacturerBrandName'.
	 */
	public List<Applicationtype> findWhereManufacturerBrandNameEquals(String manufacturerBrandName) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_UNIT_COST = :manufacturerUnitCost'.
	 */
	public List<Applicationtype> findWhereManufacturerUnitCostEquals(float manufacturerUnitCost) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	public List<Applicationtype> findWhereCustom1Equals(String custom1) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	public List<Applicationtype> findWhereCustom2Equals(String custom2) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	public List<Applicationtype> findWhereCustom3Equals(String custom3) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	public List<Applicationtype> findWhereCustom4Equals(String custom4) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	public List<Applicationtype> findWhereCustom5Equals(String custom5) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	public List<Applicationtype> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	public List<Applicationtype> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'SUB_CATEGORY_KEY_TYPE = :subCategoryKeyType'.
	 */
	public List<Applicationtype> findWhereSubCategoryKeyTypeEquals(String subCategoryKeyType) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'SUB_CATEGORY_KEY_PK = :subCategoryKeyPk'.
	 */
	public List<Applicationtype> findWhereSubCategoryKeyPkEquals(String subCategoryKeyPk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'DESCRIPTION = :description'.
	 */
	public List<Applicationtype> findWhereDescriptionEquals(String description) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	public List<Applicationtype> findWhereLongDescriptionEquals(String longDescription) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	public List<Applicationtype> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	public List<Applicationtype> findWhereLastModificationDateEquals(Date lastModificationDate) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	public List<Applicationtype> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	public List<Applicationtype> findWhereCustom6Equals(String custom6) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	public List<Applicationtype> findWhereCustom7Equals(String custom7) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	public List<Applicationtype> findWhereCustom8Equals(String custom8) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	public List<Applicationtype> findWhereCustom9Equals(String custom9) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	public List<Applicationtype> findWhereCustom10Equals(String custom10) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	public List<Applicationtype> findWhereEnvironmentEquals(String environment) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	public List<Applicationtype> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	public List<Applicationtype> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws ApplicationtypeDaoException;

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	public List<Applicationtype> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws ApplicationtypeDaoException;

	/** 
	 * Returns the rows from the APPLICATIONTYPE table that matches the specified primary-key value.
	 */
	public Applicationtype findByPrimaryKey(ApplicationtypePk pk) throws ApplicationtypeDaoException;

}
