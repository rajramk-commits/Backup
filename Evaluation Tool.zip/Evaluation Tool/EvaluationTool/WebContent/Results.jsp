<%@page import="com.fedex.emea.onlinequiz.objects.Role"%>
<%@page import="java.util.*"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.io.*"%>
<%@page import="java.nio.file.*"%>
<%@page import="java.nio.charset.*"%>

<%@page import="javax.mail.internet.MimeMultipart"%>
<%@page import="javax.mail.BodyPart"%>
<%@page import="javax.mail.Multipart"%>
<%@page import="javax.activation.DataHandler"%>
<%@page import="javax.activation.FileDataSource"%>
<%@page import="javax.activation.DataSource"%>
<%@page import="javax.mail.internet.MimeBodyPart"%>
<%@page import="javax.mail.MessagingException"%>
<%@page import="javax.mail.internet.AddressException"%>
<%@page import="javax.mail.Transport"%>
<%@page import="javax.mail.Message"%>
<%@page import="javax.mail.internet.InternetAddress"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="javax.mail.Session"%>

<jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page" />
<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<%     	
String useridddd = (String) session.getAttribute("Userid");

        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
		
        %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
<script type="text/javascript">
		window.history.forward();
		function noBack() {
			window.history.forward();
		}
		function openLoginMenu() {
			window.close("Results.jsp");
			window.open("Admin.jsp");
		}
		function evaluateRes(id, team, attempt)
		{
			window.open("ManagerEval.jsp?id="+id+"&team="+team+"&attempt="+attempt);		
		}
		function ViewRes(id, team, attempt)
		{
			window.open("ViewResult.jsp?id="+id+"&team="+team+"&attempt="+attempt);		
		}
	</script>
<style>
.main {
	margin-left: 10%;
	margin-right: 12%;
}

.head {
	height: 50px;
	background-color: #7030a0;
	margin: 0;
}

.logout {
	float: right;
	margin-right: 5%;
	background-color: #FF8C00;
	color: white;
	padding: 14px 20px;
	border: none;
	cursor: pointer;
}

.logout:hover {
	background-color: #4B0060;
}

.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

table {
	font-family: arial, sans-serif;
	border-collapse: collapse;
	width: 100%;
}

td, th {
	border: 1px solid #dddddd;
	text-align: left;
	padding: 8px;
}

tr:nth-child(even) {
	background-color: #dddddd;
}
</style>
</head>
<body>

	<div class="main">
		<div class="head">
				<p
					style="font-family: Calibri; font-weight: 700; color: white; font-size: 20px; padding: 12px 0 0 0">FedEx
					Support - Results</p>
		</div>

		<form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class="logout"
				style="margin-top: 6px; font-family: Calibri; font-size: 16px">Logout</button>
		</form>
		<div
			style="margin: 15px 0 0px 40px; font-family: Calibri; font-size: 16px">
			<b>Welcome :</b>
			<%=userID %>
		</div>
		<button class="home" onclick="openLoginMenu()">HOME</button>
		<br> <br>
		<%
		 String dirName = "C:/Users/rahul.raj/Documents/finaaal/Resources/";

	     //String dirName = "/opt/automationtools/Deployments/resources/";
		String fileName = dirName+"ResultDB.txt";
		File file = new File(fileName);
		file.createNewFile();
		
		String uId = request.getParameter("uId");
		String team = request.getParameter("team");
		String attempt = request.getParameter("attempt");
		
		String result = "", score="", teamNM ="", userName ="";
		System.out.println("Res uId :"+uId);
		if(uId != null)
		{
			float  totMarks=0, max = 60;
			int mcqTot=0;
			System.out.println("mcqTotal :"+request.getParameter("mcqTotal"));
			
			if(request.getParameter("mcqTotal") != null)
			{
				try
				{
					mcqTot = Integer.parseInt(request.getParameter("mcqTotal"));
				}
				catch(NumberFormatException e){
					System.out.println(e);
				}
			}
			for (int i=1; i<23; i++)
			{
				int mark=0;
				String var = request.getParameter("textMarks"+i);
				if(var != null && !var.trim().isEmpty())
				{
					try
					{
						mark = Integer.parseInt(var);
						System.out.println("mark :"+mark);
					}
					catch(NumberFormatException e){
						System.out.println(e);
					}
					totMarks += mark;
					System.out.println("Test Area :"+mark);
				}
			}
			totMarks = totMarks + mcqTot;
			System.out.println("totMarks :"+totMarks);
			float avg = (totMarks/max)*100;
			System.out.println("avg :"+avg);
			if (avg >= 80)
			{
				result = "PASS";
		    }
			else if (avg >0 && avg < 80)
			{
				result = "FAIL";
			}
			score = "Marks Obtained : " + totMarks  +"_Weightage : " + avg;
			List<String> newLines = new ArrayList<>();
			for (String line : Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8))
			{
				System.out.println("line :"+line);
				System.out.println("team :"+team);
				System.out.println("attempt :"+attempt);
			    if (line.contains(uId) && line.contains(team)  && line.contains("_"+attempt+"_") ) {
			    	String updatedLine = line.replace("PENDING", result+"_") + score;
			       	newLines.add(updatedLine);
			       	System.out.println("updatedLine :"+updatedLine);
			    } else {
			       newLines.add(line);
			    }
			}
			Files.write(Paths.get(fileName), newLines, StandardCharsets.UTF_8);
			
			// Write scores and result to User files
			String userFileName = dirName;
			boolean fileFound = false;
			File directoryPath = new File(dirName);
			String contents[] = directoryPath.list();
			for(int i=0; i<contents.length; i++) {
		         if(uId != null && contents[i].contains(uId) && contents[i].contains(team) && contents[i].contains("_"+attempt))
		         {
		        	 userFileName+= contents[i];
		        	 fileFound = true;
		        	 break;
		         }
		      }
			
			System.out.println("userFileName :"+userFileName);
			
			if(fileFound)
			{
				List<String> scoreList = new ArrayList<String>();
				for (int i =1; i< 23; i++)
				{
					scoreList.add(request.getParameter("textMarks"+i));
				}
				System.out.println("scoreList :"+scoreList);
				
				File userFile = new File(userFileName);
				userFile.createNewFile();
			
				StringBuilder newFileSB = new StringBuilder();
				BufferedReader br = new BufferedReader(new FileReader(userFile));
				String st;
				int index = 0;
				
				while ((st = br.readLine()) != null)
				{
					System.out.println("User File st :"+st);
					if(st.contains("Team :"))
                    {
                        teamNM = st.substring(7);
                    }
					if(st.contains(uId))
                    {
                        userName = st.substring(10);
                    }
					if(st.contains("Result"))
						continue;
					if(st.contains("MCQ Total"))
					{
						newFileSB.append(" Total Marks : "+totMarks);
						newFileSB.append("\n Weightage : "+avg);
						newFileSB.append("\n Result : "+result);
						continue;
					}
					newFileSB.append(st);
					newFileSB.append("\n");
					if(st.contains("User Answer"))
					{
						System.out.println("st contians:"+st);
						newFileSB.append("\nMarks Obtained : "+scoreList.get(index)+"\n");
						++index;
					}
				}
				br.close();
				
				// Clear old file content
				if (userFile.exists()) {
				    RandomAccessFile raf = new RandomAccessFile(userFile, "rw");
				    raf.setLength(0);
				    raf.close();
				}
				System.out.println("newFileSB :"+newFileSB);
				
				//Write New content
				BufferedWriter bufferOut = new BufferedWriter(new FileWriter(userFile, false));
				bufferOut.write(newFileSB.toString());
				bufferOut.newLine();
				bufferOut.close();
			}
			
			//Trigger a mail after Evaluvate
			System.out.println("teamNM :"+teamNM);
            String mailTo = uId+"@fedex.com";
            //String mailTo1 = "ravi.lingegowda.osv@fedex.com";
            String mailcc = "ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";
            Properties props = System.getProperties();
            props.put("mail.smtp.host", "mapper.gslb.fedex.com");
            props.put("mail.smtp.port", "25");
            props.put("mail.smtp.connectiontimeout", 10000);
            props.put("mail.smtp.timeout", 10000);
            props.put("mail.smtp.writetimeout", 10000);
           
            Session session11 = Session.getDefaultInstance(props, null);
            MimeMessage message = new MimeMessage(session11);
           
            try {
                message.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
                message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo));
                //message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo1));
                message.addRecipient(Message.RecipientType.CC, new InternetAddress(mailcc));
                BodyPart messageBodyPart1 = new MimeBodyPart();           
                message.setSubject("Program 2 Manager Evaluation Test Result");
               
                StringBuilder email = new StringBuilder();
                email.append("<html><head>");       
                email.append("<br><br>");
                email.append("<label style=\"font-family:Calibri;font-size:16px\">Please find attached the details of the test taken by : </label>");
                email.append("<label style=\"font-family:Calibri;font-size:16px\"> <b>"+userName+"</b></label>");
                email.append("<br><br>");
                email.append("<label style=\"font-family:Calibri;font-size:16px\">Thank you for taking the evaluation test : Program2 - "+ teamNM+"</label>");
                email.append("<br>");
                email.append("<label style=\"font-family:Calibri;font-size:16px\">Your Result after manager evaluation is : "+result+" with Weightage of  "+avg+"%  </label><br>");
                email.append("<br>");
                email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
                email.append("</html></head>");       
                messageBodyPart1.setContent(email.toString(),"text/html" );            
               
                MimeBodyPart messageBodyPart2 = new MimeBodyPart();
                DataSource source = new FileDataSource(userFileName);
                messageBodyPart2.setDataHandler(new DataHandler(source));
                messageBodyPart2.setFileName("Result_"+uId+"_"+team+"_"+attempt+".txt");
                
                // create Multi part object and add MimeBodyPart objects to this object     
                Multipart multipart = new MimeMultipart();
                multipart.addBodyPart(messageBodyPart1);
                multipart.addBodyPart(messageBodyPart2);
                message.setContent(multipart);
                Transport.send(message);
   
            }  catch (MessagingException e) {
                e.printStackTrace();
            }			
		}
		%>
			
		<table>
		<tr>
				<th>Teams</th>
				<th>Name</th>
				<th>Fedex ID</th>
				<th>Info</th>
				<th>Results</th>
				<th>Scores</th>
				<th>Action</th>
		</tr>
		<%
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			while ((st = br.readLine()) != null)
			{
				String[] fields = st.split("_");
				for(int i=0;i<fields.length; i++)
					System.out.println("fileds :"+fields[i]);
				%>
				<tr>
					<td><%=fields[0] %></td>
					<td><%=fields[1] %></td>
					<td><%=fields[2] %></td>
					<td>Date : <%=fields[3] %>, Attempts : <%=fields[4] %></td>
					<td><%=fields[5] %></td>
					<%
					String scoreDetails = "";
					try
					{
						%>
						<td>Total Marks : 60(More than 80% Weightage is required to Pass)<br><%=fields[6] %><br><%=fields[7] %></td>
						<%
					}
					catch (Exception e)
					{
						System.out.println(e);
					}
					if(fields[5] != null && fields[5].equalsIgnoreCase("Pending"))
					{%>
						<td><button id="Evaluate" name="Evaluate" onclick="evaluateRes('<%=fields[2] %>','<%=fields[0] %>','<%=fields[4] %>' )">Evaluate</button></td>
					<%}
					else if(fields[5] != null && ( fields[5].equalsIgnoreCase("Pass") || fields[5].equalsIgnoreCase("Fail")))
					{%>
						<td><button id="View" name="View" onclick="ViewRes('<%=fields[2] %>','<%=fields[0] %>','<%=fields[4] %>')">View</button></td>
					<%}
					%>
				</tr>
			<%}
			br.close();
		%>
		</table>
	</div>
	<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>
<%}%>