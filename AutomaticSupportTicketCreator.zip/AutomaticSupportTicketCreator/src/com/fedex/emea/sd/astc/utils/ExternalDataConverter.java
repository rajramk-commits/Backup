package com.fedex.emea.sd.astc.utils;

import java.util.List;

import com.fedex.emea.sd.da.helpers.Constants;
import com.fedex.emea.sd.da.objects.ExternalInterface;
import com.fedex.emea.sd.snow.objects.SnowPassiveData;
import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class ExternalDataConverter {
	
	private boolean isEPDSM;
	
	private ExternalInterface eiRecord;
	private String eiPriority;
	private String eiProviderGroup;
	private String eiStatus;
	private String eiType;
	private String eiDescription;
	private String eiRecordSource;
	
	private List<SnowPassiveData> snowCiServiceList;
	private List<SnowPassiveData> snowCiBusinessAppList;
	private List<SnowPassiveData> snowUsersList;
	private List<SnowPassiveData> snowUserGroupsList;
	
	private String snowPriority;
	private String snowImpact;
	private String snowUrgency;
	private String snowSeverity;
	
	public ExternalDataConverter() {
	}
	
	public ExternalDataConverter(ExternalInterface eiRecord) {
		this.setEiRecord(eiRecord);
	}
	
	public String getSnowContactType() {
		
		if (isEPDSM) {
			if (eiRecordSource.equals(Constants.SELF_SERVICE_NPF))        return SnowConstants.CONTACT_EPDSM_SELF;
			return SnowConstants.CONTACT_EPDSM_EVENT;			
		} else {
			if (eiRecordSource.equals(Constants.SELF_SERVICE_NPF))        return SnowConstants.CONTACT_MEDIUM_WEB;
			return SnowConstants.CONTACT_MEDIUM_EVENT;			
		}
	}
		
	public String getSnowCategory() {
		
		if (isEPDSM) {
			if (eiType.equals(Constants.CASE_TYPE_INCIDENT))              return SnowConstants.CATEGORY_EPDSM_APP;
			if (eiType.equals(Constants.CASE_TYPE_PROBLEM))               return SnowConstants.CATEGORY_EPDSM_APP;
			if (eiType.equals(Constants.CASE_TYPE_SRV_REQ))               return SnowConstants.CATEGORY_EPDSM_INQ;
			return SnowConstants.CATEGORY_EPDSM_APP;			
		} else {
			if (eiType.equals(Constants.CASE_TYPE_INCIDENT))              return SnowConstants.CATEGORY_INCIDENT;
			if (eiType.equals(Constants.CASE_TYPE_PROBLEM))               return SnowConstants.CATEGORY_PROBLEM;
			if (eiType.equals(Constants.CASE_TYPE_SRV_REQ))               return SnowConstants.CATEGORY_REQUEST;
			return SnowConstants.CATEGORY_INCIDENT;
		}
	}
	
	public String getSnowState() {
		
		if (isEPDSM) {
			if (eiStatus.equals(Constants.CASE_STATUS_NEW_CASE))          return SnowConstants.STATE_EPDSM_NEW;
			if (eiStatus.equals(Constants.CASE_STATUS_SOLVED))            return SnowConstants.STATE_EPDSM_RESOLVED;
			if (eiStatus.equals(Constants.CASE_STATUS_CLOSE))             return SnowConstants.STATE_EPDSM_CLOSED;
			return SnowConstants.STATE_EPDSM_NEW;			
		} else {
			if (eiStatus.equals(Constants.CASE_STATUS_NEW_CASE))          return SnowConstants.STATE_REGISTERED;
			if (eiStatus.equals(Constants.CASE_STATUS_SOLVED))            return SnowConstants.STATE_RESOLVED;
			if (eiStatus.equals(Constants.CASE_STATUS_CLOSE))             return SnowConstants.STATE_CLOSED;
			return SnowConstants.STATE_REGISTERED;			
		}
	}
		
	// "SYS_USER_GROUP" ServiceNow Table 
	// Auto-Assign Group based on Provider Group field in EXTERNAL_INTERFACE Table
	//
	public String getSnowAssignmentGroup() {
		if (isEPDSM) {
			if (eiProviderGroup.equals(Constants.PROVIDER_HELPDESK))       return getSysIdByDescription(snowUserGroupsList, "FXE_SDESK_EU");
			if (eiProviderGroup.equals(Constants.PROVIDER_ATLAS))          return getSysIdByDescription(snowUserGroupsList, "FXE_SDESK_EU_FIRST");
			if (eiProviderGroup.equals(Constants.PROVIDER_SD_APP_SUPPORT)) return getSysIdByDescription(snowUserGroupsList, "FXE_SDESK_EU_SDAppSup");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_NT))         return getSysIdByDescription(snowUserGroupsList, "FXE_SA_EU_WINDOWS");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_UNIX))       return getSysIdByDescription(snowUserGroupsList, "FXE_SA_EU_UNIX");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_SAN))        return getSysIdByDescription(snowUserGroupsList, "FXE_SA_EU_STORAGE");
			if (eiProviderGroup.equals(Constants.PROVIDER_DBA))            return getSysIdByDescription(snowUserGroupsList, "FXE_DBA_EU");
			if (eiProviderGroup.equals(Constants.PROVIDER_NE_LAN))         return getSysIdByDescription(snowUserGroupsList, "FXE_SPT_EU_NELANWAN");
			if (eiProviderGroup.equals(Constants.PROVIDER_NE_VOICE))       return getSysIdByDescription(snowUserGroupsList, "FXE_SPT_EU_NEVOICE");
			if (eiProviderGroup.equals(Constants.PROVIDER_HUBSTACK))       return getSysIdByDescription(snowUserGroupsList, "FXE_SPT_EU_HubStackCC");
			if (eiProviderGroup.equals(Constants.PROVIDER_CLEARANCE))      return getSysIdByDescription(snowUserGroupsList, "FXE_SPT_EU_ClearanceCC");
			if (eiProviderGroup.equals(Constants.FXE_SA_EU_LINUX))		   return getSysIdByDescription(snowUserGroupsList, "FXE_SA_EU_LINUX");

			return getSysIdByDescription(snowUserGroupsList, "FXE_SDESK_EU_FIRST"); //"cca0f38713a513005b85be395144b05d"; // FXE_SDESK_EU - On DEV08 - UAT - PROD
		} else {
			if (eiProviderGroup.equals(Constants.PROVIDER_HELPDESK))       return getSysIdByDescription(snowUserGroupsList, "FDX-SD-Helpdesk");
			if (eiProviderGroup.equals(Constants.PROVIDER_SD_APP_SUPPORT)) return getSysIdByDescription(snowUserGroupsList, "FDX-SD-AppSup");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_NT))         return getSysIdByDescription(snowUserGroupsList, "FDX-SSA-NT");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_UNIX))       return getSysIdByDescription(snowUserGroupsList, "FDX-SSA-UNIX");
			if (eiProviderGroup.equals(Constants.PROVIDER_SSA_SAN))        return getSysIdByDescription(snowUserGroupsList, "FDX-SSA-SAN");
			if (eiProviderGroup.equals(Constants.PROVIDER_DBA))            return getSysIdByDescription(snowUserGroupsList, "FDX-DATABASE-Support");
			if (eiProviderGroup.equals(Constants.PROVIDER_NE_LAN))         return getSysIdByDescription(snowUserGroupsList, "FDX-NE-LAN/WAN");
			if (eiProviderGroup.equals(Constants.PROVIDER_NE_VOICE))       return getSysIdByDescription(snowUserGroupsList, "FDX-NE-VOICE");
			if (eiProviderGroup.equals(Constants.PROVIDER_HUBSTACK))       return getSysIdByDescription(snowUserGroupsList, "FDX-SD-HSCC");
			if (eiProviderGroup.equals(Constants.FXE_SA_EU_LINUX))         return getSysIdByDescription(snowUserGroupsList, "FXE_SA_EU_LINUX");
			return getSysIdByDescription(snowUserGroupsList, "FXE_SDESK_EU_FIRST"); //"621add04dbd6f600eab5f3541d961972"; // FDX-SD-Helpdesk - On PREPROD - PROD			
		}
	}
	
	public String getSnowU_Instructions() {
		String instructions = "Please act upon Description provided";
		
		try {
			if (eiRecord.getRecordSource().equals(Constants.OBM)) {
				String instructionsLabel = "Instructions   :";
				int labelOffset = instructionsLabel.length();
				int startPos = eiDescription.indexOf(instructionsLabel) + labelOffset + 1;
				String instructionString = eiDescription.substring(startPos);
				int endPos = instructionString.indexOf("_") - 1;
				instructions = instructionString.substring(0, endPos);
			}
		} catch (Exception ex) {
			// Format of Description has changed for OBM Alert in EXTERNAL_INTERFACE Table
		}
		
		return instructions;
	}
	
	public String getSnowU_Classification() {
		if (isEPDSM) {
			return ""; 		// Not used in EPDSM
		} else {
			return SnowConstants.CLASSIFICATION_APP_SOFT_OS;
		}
	}
		
	// "CMDB_CI_SERVICE" ServiceNow Table
	//
	public String getSnowU_BusinessService() {
		if (isEPDSM) {
			return ""; 	// No more "Unknown" in EPDSM => Empty
		} else {
			return getSysIdByDescription(snowCiServiceList, "Unknown Service"); 	// Unknown
		}
	}
	
	private String getSysIdByDescription(List<SnowPassiveData> passiveDataList, String description) {
		String sysId = null;
		for (SnowPassiveData data: passiveDataList) {
			if (data.getDescription().equals(description)) {
				sysId = data.getSysId();
				break;
			}
		}
		return sysId;
	}
	
	// *****************************************************************************************
	//                                  GETTERS / SETTERS
	// *****************************************************************************************

	public ExternalInterface getEiRecord() {
		return eiRecord;
	}

	public void setEiRecord(ExternalInterface eiRecord) {
		this.eiRecord = eiRecord;
		this.setEiPriority(eiRecord.getCasePriority());
		this.setEiProviderGroup(eiRecord.getCaseProviderGroup());
		this.setEiStatus(eiRecord.getCaseStatus());
		this.setEiType(eiRecord.getCaseType());
		this.setEiDescription(eiRecord.getCaseDescription().toString());
		this.setEiRecordSource(eiRecord.getRecordSource());
	}

	public String getEiPriority() {
		return eiPriority;
	}

	public void setEiPriority(String eiPriority) {
		this.eiPriority = eiPriority;
		this.snowPriority = null;		// Always set to NULL as it's assigned using Impact, Urgency
		this.snowSeverity = null;		// Always set to NULL as it's assigned using Impact, Urgency
		
		if (isEPDSM) {
			if (eiPriority.equals(Constants.CASE_PRIORITY_CRITICAL)) {
				this.snowImpact   = SnowConstants.IMPACT_EPDSM_1_GLOBAL;
				this.snowUrgency  = SnowConstants.URGENCY_EPDSM_1_CRIT_NOWA;
			} else {
				if (eiPriority.equals(Constants.CASE_PRIORITY_HIGH)) {
//					this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
//					this.snowUrgency  = SnowConstants.URGENCY_EPDSM_2_CRIT_WA; // for EPDSM to set the priority to P3
					
					//Below to Set the priority to P4 in case of SCOM
					this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
					this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;
					
					//below to set the priority to P2
					//this.snowUrgency  = SnowConstants.URGENCY_EPDSM_1_CRIT_NOWA;
					// this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
				}else {
					if (eiPriority.equals(Constants.CASE_PRIORITY_TOOHIGH)) {
						this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
						this.snowUrgency  = SnowConstants.URGENCY_EPDSM_2_CRIT_WA; // for EPDSM to set the priority to P3
						
						//Below to Set the priority to P4 in case of SCOM
//						this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
//						this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;
						
						//below to set the priority to P2
						//this.snowUrgency  = SnowConstants.URGENCY_EPDSM_1_CRIT_NOWA;
						// this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
					}else {
					if (eiPriority.equals(Constants.CASE_PRIORITY_MEDIUM)) {
						this.snowImpact   = SnowConstants.IMPACT_EPDSM_3_SINGLE; //for EPDSM to set the priority to P5
						this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT; //for EPDSM to set the priority to P5
						
						//Below to set the priority to P3
						//this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
						// this.snowUrgency  = SnowConstants.URGENCY_EPDSM_2_CRIT_WA;
						
						//Below to Set the priority to P4 in case of SCOM
//						this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
//						this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;
						
					  } else {
						if (eiPriority.equals(Constants.CASE_PRIORITY_LOW)) {
							this.snowImpact   = SnowConstants.IMPACT_EPDSM_3_SINGLE;  //for EPDSM to set the priority to P5
							this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;  //for EPDSM to set the priority to P5
							//Below to Set the priority to P4
							//this.snowImpact   = SnowConstants.IMPACT_EPDSM_2_MULTI;
						//	this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;
						} else {
							this.snowImpact   = SnowConstants.IMPACT_EPDSM_3_SINGLE;
							this.snowUrgency  = SnowConstants.URGENCY_EPDSM_3_NOCRIT;
						}
					}
				}
			}
		}
		}		else {
			if (eiPriority.equals(Constants.CASE_PRIORITY_CRITICAL)) {
				this.snowImpact   = SnowConstants.IMPACT_ONE;
				this.snowUrgency  = SnowConstants.URGENCY_ONE;
			} else {
				if (eiPriority.equals(Constants.CASE_PRIORITY_HIGH)) {
					this.snowImpact   = SnowConstants.IMPACT_TWO;
					this.snowUrgency  = SnowConstants.URGENCY_THREE;
				} else {
					if (eiPriority.equals(Constants.CASE_PRIORITY_TOOHIGH)) {
						this.snowImpact   = SnowConstants.IMPACT_TWO;
						this.snowUrgency  = SnowConstants.URGENCY_TWO;
					}else {
					 if (eiPriority.equals(Constants.CASE_PRIORITY_MEDIUM)) {
						this.snowImpact   = SnowConstants.IMPACT_THREE;
						this.snowUrgency  = SnowConstants.URGENCY_TWO;
					   } else {
						   if (eiPriority.equals(Constants.CASE_PRIORITY_LOW)) {
							    this.snowImpact   = SnowConstants.IMPACT_FOUR;
							this.snowUrgency  = SnowConstants.URGENCY_FOUR;
						} else {
							this.snowImpact   = SnowConstants.IMPACT_FOUR;
							this.snowUrgency  = SnowConstants.URGENCY_FOUR;
						}
					}
				}
			}
		}
	}}
		

	public String getEiProviderGroup() {
		return eiProviderGroup;
	}

	public void setEiProviderGroup(String eiProviderGroup) {
		this.eiProviderGroup = eiProviderGroup;
	}

	public String getEiStatus() {
		return eiStatus;
	}

	public void setEiStatus(String eiStatus) {
		this.eiStatus = eiStatus;
	}

	public String getEiType() {
		return eiType;
	}

	public void setEiType(String eiType) {
		this.eiType = eiType;
	}
	
	public String getEiDescription() {
		return eiDescription;
	}

	public void setEiDescription(String eiDescription) {
		this.eiDescription = eiDescription;
	}

	public List<SnowPassiveData> getSnowCiServiceList() {
		return snowCiServiceList;
	}

	public void setSnowCiServiceList(List<SnowPassiveData> snowCiServiceList) {
		this.snowCiServiceList = snowCiServiceList;
	}

	public List<SnowPassiveData> getSnowUsersList() {
		return snowUsersList;
	}

	public void setSnowUsersList(List<SnowPassiveData> snowUsersList) {
		this.snowUsersList = snowUsersList;
	}

	public List<SnowPassiveData> getSnowUserGroupsList() {
		return snowUserGroupsList;
	}

	public void setSnowUserGroupsList(List<SnowPassiveData> snowUserGroupsList) {
		this.snowUserGroupsList = snowUserGroupsList;
	}
	
	public String getEiRecordSource() {
		return eiRecordSource;
	}

	public void setEiRecordSource(String eiRecordSource) {
		this.eiRecordSource = eiRecordSource;
	}
	
	public String getSnowPriority() {
		return snowPriority;
	}

	public String getSnowImpact() {
		return snowImpact;
	}

	public String getSnowUrgency() {
		return snowUrgency;
	}

	public String getSnowSeverity() {
		return snowSeverity;
	}

	public List<SnowPassiveData> getSnowCiBusinessAppList() {
		return snowCiBusinessAppList;
	}

	public void setSnowCiBusinessAppList(List<SnowPassiveData> snowCiBusinessAppList) {
		this.snowCiBusinessAppList = snowCiBusinessAppList;
	}

	public boolean isEPDSM() {
		return isEPDSM;
	}

	public void setEPDSM(boolean isEPDSM) {
		this.isEPDSM = isEPDSM;
	}
}
