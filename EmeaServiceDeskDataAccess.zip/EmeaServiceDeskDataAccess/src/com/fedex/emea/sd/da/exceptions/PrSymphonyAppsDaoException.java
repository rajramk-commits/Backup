package com.fedex.emea.sd.da.exceptions;

public class PrSymphonyAppsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2003161528192250515L;

	/**
	 * Method 'PrSymphonyAppsDaoException'
	 * 
	 * @param message
	 */
	public PrSymphonyAppsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrSymphonyAppsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrSymphonyAppsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
