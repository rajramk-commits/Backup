package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.ExternalInterface;

/** * RowMapper is used by Spring to read a line from a database table
 *  * and to fill an instance of the class with the values */

public final class ExternalInterfaceRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		ExternalInterface externalInterface = new ExternalInterface();
		
		externalInterface.setAlertId(rs.getLong("ALERTID"));
		externalInterface.setRecordSource(rs.getString("RECORDSOURCE"));
		externalInterface.setRecordSourceId(rs.getString("RECORDSOURCEID"));
		externalInterface.setNexusCase(rs.getBytes("NEXUSCASEOBJECT"));
		externalInterface.setCaseBusinessUnit(rs.getString("CASEBUSINESSUNIT"));
		externalInterface.setCaseLocation(rs.getString("CASELOCATION"));
		externalInterface.setCaseOriginPin(rs.getString("CASEORIGINPIN"));
		externalInterface.setCaseSummary(rs.getString("CASESUMMARY"));
		externalInterface.setCaseDescription1(rs.getString("CASEDESCRIPTION1"));
		externalInterface.setCaseDescription2(rs.getString("CASEDESCRIPTION2"));
		externalInterface.setCaseDescription3(rs.getString("CASEDESCRIPTION3"));
		externalInterface.setCaseDescription4(rs.getString("CASEDESCRIPTION4"));
		externalInterface.setCaseDescription5(rs.getString("CASEDESCRIPTION5"));
		externalInterface.setCaseDescription6(rs.getString("CASEDESCRIPTION6"));
		externalInterface.setCaseDescription7(rs.getString("CASEDESCRIPTION7"));
		externalInterface.setCaseDescription8(rs.getString("CASEDESCRIPTION8"));
		externalInterface.setCaseDescription9(rs.getString("CASEDESCRIPTION9"));
		externalInterface.setCaseType(rs.getString("CASETYPE"));
		externalInterface.setCasePriority(rs.getString("CASEPRIORITY"));
		externalInterface.setCaseStatus(rs.getString("CASESTATUS"));
		externalInterface.setCaseSeverity(rs.getString("CASESEVERITY"));
		externalInterface.setCaseSource(rs.getString("CASESOURCE"));
		externalInterface.setCaseProviderGroup(rs.getString("CASEPROVIDERGROUP"));
		externalInterface.setCaseOwnership(rs.getString("CASEOWNERSHIP"));
		externalInterface.setCaseCategory(rs.getString("CASECATEGORY"));
		externalInterface.setCaseCallType(rs.getString("CASECALLTYPE"));
		externalInterface.setCaseProblemType(rs.getString("CASEPROBLEMTYPE"));
		externalInterface.setCaseProblemDetail(rs.getString("CASEPROBLEMDETAIL"));
		externalInterface.setCaseProblemDescription(rs.getString("CASEPROBLEMDESCRIPTION"));
		externalInterface.setCaseFdxNode(rs.getString("CASEFDXNODE"));
		externalInterface.setCaseFdxVendor(rs.getString("CASEFDXVENDOR"));
		externalInterface.setCaseFdxVendorId(rs.getString("CASEFDXVENDORID"));
		externalInterface.setCaseFdxSystem(rs.getString("CASEFDXSYSTEM"));
		externalInterface.setCaseFdxApplication(rs.getString("CASEFDXAPPLICATION"));
		externalInterface.setCaseAssignedTo(rs.getString("CASEASSIGNEDTO"));
		externalInterface.setCaseSolution(rs.getString("CASESOLUTION"));
		externalInterface.setAlertProcessed(rs.getInt("ALERTPROCESSED"));
		externalInterface.setProcessedTime(rs.getTimestamp("PROCESSEDTIME"));
		externalInterface.setCreationTime(rs.getTimestamp("CREATIONTIME"));
		externalInterface.setCaseId(rs.getString("CASEID"));
		externalInterface.setLogicalKey(rs.getString("LOGICALKEY"));
		externalInterface.setCaseSysId(rs.getString("CASESYSID"));
		
		return externalInterface;	
	}
}
