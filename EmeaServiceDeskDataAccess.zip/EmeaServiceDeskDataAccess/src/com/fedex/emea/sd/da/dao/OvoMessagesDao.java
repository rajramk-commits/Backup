package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.OvoMessages;

public interface OvoMessagesDao {
	public OvoMessages createValueObject();
	public OvoMessages getObject(String ovoMessageId) throws SQLException;
	public List<OvoMessages> loadSimilarObject(String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject) throws SQLException;
	public List<OvoMessages> loadSimilarObjectFromExternalInterface(String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject) throws SQLException;
	public List<OvoMessages> loadAll() throws SQLException;
	public void create(OvoMessages valueObject) throws SQLException, DataAccessException, IOException;
	public void delete(OvoMessages valueObject);
	public void deleteAll() throws SQLException;
	public void deleteOlderThan(Timestamp limitDate) throws SQLException;
	public int countAll() throws SQLException;
	public void updateNexusCaseId(OvoMessages valueObject) throws SQLException;
}

