package com.fedex.emea.sd.bl.mailer;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailSender {
	private String smtpHost;
	private String smtpPort;
	private String mailFrom;
	private List<String> mailTos;
	private String mailSubject;
	private String mailContent;
	
	public MailSender(String smtpHost, String smtpPort) {
		this.setSmtpHost(smtpHost);
		this.setSmtpPort(smtpPort);
	}
	
	public void sendMail(String mailFrom, ArrayList<String> mailTos, String mailSubject, String mailContent) throws Exception {
		this.setMailFrom(mailFrom);
		this.setMailTos(mailTos);
		this.setMailSubject(mailSubject);
		this.setMailContent(mailContent);
		sendMail();
	}
	
	public void sendMail() throws Exception {
		Properties props = System.getProperties();
		props.put("mail.smtp.host", smtpHost);
		props.put("mail.smtp.port", smtpPort);
		props.put("mail.smtp.connectiontimeout", 10000);
		props.put("mail.smtp.timeout", 10000);
		props.put("mail.smtp.writetimeout", 10000);
		
		Session session = Session.getDefaultInstance(props, null);
		MimeMessage message = new MimeMessage(session);
		
		try {
			message.setFrom(new InternetAddress(mailFrom));
			for (String mailTo: mailTos) {
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo));
			}
			message.setSubject(mailSubject);
			//message.setText(htmlText);
			message.setContent(mailContent, "text/html");
			
			// Send message
			Transport.send(message);
			
		} catch (AddressException e) {
			throw e;
		} catch (MessagingException e) {
			throw e;
		}
	}

	public String getSmtpHost() {
		return smtpHost;
	}

	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	public String getSmtpPort() {
		return smtpPort;
	}

	public void setSmtpPort(String smtpPort) {
		this.smtpPort = smtpPort;
	}

	public String getMailFrom() {
		return mailFrom;
	}

	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}

	public List<String> getMailTos() {
		return mailTos;
	}

	public void setMailTos(List<String> mailTos) {
		this.mailTos = mailTos;
	}

	public String getMailSubject() {
		return mailSubject;
	}

	public void setMailSubject(String mailSubject) {
		this.mailSubject = mailSubject;
	}

	public String getMailContent() {
		return mailContent;
	}

	public void setMailContent(String mailContent) {
		this.mailContent = mailContent;
	}
}
