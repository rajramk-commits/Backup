package com.fedex.emea.sd.da.dao;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.NexusInterface;

public interface NexusInterfaceDao {
	public NexusInterface createValueObject();
	public NexusInterface getObject(int alertId) throws SQLException;
	public NexusInterface getObjectByRecordSourceId(String recordSourceId) throws SQLException;
	public List<NexusInterface> loadAll() throws SQLException;
	public List<NexusInterface> loadNotProcessed() throws SQLException;
	public List<NexusInterface> loadOnlyDashboard() throws SQLException;
	public void create(NexusInterface valueObject) throws SQLException, DataAccessException, IOException;
	public void createFromDashboard(NexusInterface valueObject) throws SQLException, DataAccessException, IOException;
	public void saveCompleted(NexusInterface valueObject) throws SQLException;
	public void delete(NexusInterface valueObject) throws SQLException;
	public void deleteAll() throws SQLException;
	public void deleteOlderThan(Timestamp limitDate) throws SQLException;
	public int countAll() throws SQLException;
	public void updateCaseId(NexusInterface valueObject) throws SQLException;
	public void updatePriorityStatusGroup(NexusInterface valueObject) throws SQLException;
	public void updateRecordStatus(NexusInterface valueObject) throws SQLException;
}

