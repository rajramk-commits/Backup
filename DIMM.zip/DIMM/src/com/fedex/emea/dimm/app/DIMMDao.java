package com.fedex.emea.dimm.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fedex.emea.dimm.alert.AbstractAlert;
import com.fedex.emea.dimm.alert.PhysicalAlert;
import com.fedex.emea.dimm.utils.DIMMConstants;
import com.fedex.emea.dimm.utils.DIMMQueries;
import com.fedex.emea.dimm.utils.jdbc.DBConfig;
import com.fedex.emea.dimm.utils.jdbc.DBConnectionFactory;
import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class DIMMDao {

	private static final Logger log = LogManager.getLogger(DIMMDao.class);
	
	private DBConfig monitorAlertStagingDbConfig;
	
	private DBConfig antcDbConfig;
	
	private DBConfig nexusDbConfig;

	public DIMMDao(DBConfig monitorAlertStagingDbConfig, DBConfig antcDbConfig, DBConfig nexusDbConfig) {
		super();
		this.monitorAlertStagingDbConfig = monitorAlertStagingDbConfig;
		this.antcDbConfig = antcDbConfig;
		this.nexusDbConfig = nexusDbConfig;
	}
	
	SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.EPDSM_PROD_DIRECT);
	//SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.EPDSM_UAT_DIRECT);
	//SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.SNOW_PROD);// PDSM production
    //private static SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.SNOW_PREPROD);// (preprod in DAWN)test
	//SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.SNOW_SAND); // (Available Environment: SNOW_DEV, SNOW_UAT)
	SnowIncident  incident      = new SnowIncident();
	
	
	
	
	/**
	 * This method is used to get all open cases from ANTC.
	 * @param Nothing
	 * @return List<String> list of open case numbers
	 */
	public List<String> getOpenCasesFromDIMM( List<String> logicalkeyforstatuscheck) {
		
		log.info("Begining of  getOpenCasesFromDIMM()");
           StringBuilder s1=new StringBuilder();
           s1.append("'");
           for(int i=1;i<logicalkeyforstatuscheck.size();i++)
           {
        	   s1.append(logicalkeyforstatuscheck.get(i-1)); 
        	   s1.append("','"); 
           }
           s1.append(logicalkeyforstatuscheck.get(logicalkeyforstatuscheck.size()-1));
           s1.append("'");
           String s2=s1.toString();
        
		Connection con = null;
		Statement statement = null;
		ResultSet rSet = null;
		List<String> openCases = new ArrayList<String>();
		try {
			con= DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
		
			//System.out.println("string" +s2 );
	String sql="SELECT distinct casesysid FROM dimminterface  WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and caseid is not null and logicalkey in("+s2+")";
	//System.out.println(sql);
		
	statement = con.createStatement();
			
			rSet = statement.executeQuery(sql);
			//System.out.println(rSet);
			while(rSet.next())
			{
				//System.out.println("this is open"+ rSet.getString(1));
				openCases.add(rSet.getString(1));
			}
			
			
		} catch(Exception exception) {
			//System.out.println(exception);
			log.error("Unexpected error:: ", exception);
	
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getOpenCasesFromDIMM() || open cases found in DIMM: "+openCases.size() +" : for new alert logicalkeys");
		return openCases;
	}
	
	
	
	
public List<String> getOpenAlertsRecordSourceIdFromDIMM( List<String> logicalkeyforstatuscheck) {
		
		log.info("Begining of  getOpenAlertsRecordSourceIdFromDIMM()");
           StringBuilder s1=new StringBuilder();
           s1.append("'");
           for(int i=1;i<logicalkeyforstatuscheck.size();i++)
           {
        	   s1.append(logicalkeyforstatuscheck.get(i-1)); 
        	   s1.append("','"); 
           }
           s1.append(logicalkeyforstatuscheck.get(logicalkeyforstatuscheck.size()-1));
           s1.append("'");
           String s2=s1.toString();
        
		Connection con = null;
		Statement statement = null;
		ResultSet rSet = null;
		List<String> openCases = new ArrayList<String>();
		try {
			con= DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
		
			//System.out.println("string" +s2 );
	String sql="SELECT recordsourceid FROM dimminterface  WHERE casestatus NOT IN ('RESOL', 'CLOS', 'OOS', 'DUP') and alertprocessed=1 and caseid is null and logicalkey in("+s2+")";
	//System.out.println(sql);
		
	statement = con.createStatement();
			
			rSet = statement.executeQuery(sql);
			//System.out.println(rSet);
			while(rSet.next())
			{
				//System.out.println("this is open"+ rSet.getString(1));
				openCases.add(rSet.getString(1));
			}
			
			
		} catch(Exception exception) {
			//System.out.println(exception);
			log.error("Unexpected error:: ", exception);
	
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getOpenAlertsRecordSourceIdFromDIMM() || number of open alerts  found in DIMM for logicalkeys: "+openCases.size());
		return openCases;
	}
	
/*	
public List<String> getOpenCasesFromExternal( List<String> logicalkeyforstatuscheck) {
		
		log.info("Begining of getunprocessedloficalkey()");
           StringBuilder s1=new StringBuilder();
           s1.append("'");
           for(int i=1;i<logicalkeyforstatuscheck.size();i++)
           {
        	   s1.append(logicalkeyforstatuscheck.get(i-1)); 
        	   s1.append("','"); 
           }
           s1.append(logicalkeyforstatuscheck.get(logicalkeyforstatuscheck.size()-1));
           s1.append("'");
           String s2=s1.toString();
        
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		List<String> openCases = new ArrayList<String>();
		try {
			con= DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
		
			
	
			statement = con.prepareStatement(DIMMQueries.OPEN_CASES_FROM_ANTC_QUERYSTRING);
			statement.setString(1,s2);
			rSet = statement.executeQuery();
			
			while (rSet.next()) {
				openCases.add(rSet.getString(DIMMConstants.CASESYSID_COLUMN));
			}
			
		} catch(Exception exception) {
			log.error("Unexpected error:: ", exception);
	
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getOpenCasesFromANTC() || open cases found in ASTC: "+openCases.size());
		return openCases;
	}*/
	/**
	 * This method is used to get closed and solved cases from NEXUS.
	 * @param caseIdStatusMap key is case number and value is case status
	 * @return Nothing
	 */
	/*public Map<Long, String> getClosedCasesFromNexus(List<String> openCases) {
		
		log.info("Begining of getClosedCasesFromNexus()");
		
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		Map<Long, String> caseStatusMap = new HashMap<Long, String>();
		StringBuilder caseIdBuilder = new StringBuilder();
		String caseids = "";
		String queryString = "";
		int caseCount = 0;
		int caseCountForLastIteration = 0;
		try {
			if(openCases.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.nexusDbConfig);
				for(String caseid :openCases) {
					caseIdBuilder.append(caseid).append(",");
					caseCount = caseCount + 1;
					caseCountForLastIteration = caseCountForLastIteration + 1;
					
					if(caseCount == 1000 || caseCountForLastIteration == openCases.size()) {
						caseids = caseIdBuilder.toString().substring(0, caseIdBuilder.toString().length()-1);
						if(caseids.length() > 0) {
							queryString = DIMMQueries.CASESTATUS_FROM_NEXUS_QUERYSTRING.replace("case_id IN (", "case_id IN (" + caseids);
							statement = con.prepareStatement(queryString);
							rSet = statement.executeQuery();
							
							while (rSet.next()) {
								caseStatusMap.put(rSet.getLong(DIMMConstants.NEXUS_CASEID_COLUMN), rSet.getString(DIMMConstants.NEXUS_CASESTATUS_COLUMN) + "," + rSet.getString(DIMMConstants.NEXUS_CASE_CREATEDTIME_COLUMN));
							}
						}
						caseCount = 0;
						caseIdBuilder.delete(0, caseIdBuilder.length());
					}
				}
				
			}
			//System.out.println("Closed cases from NEXUS:: " + caseStatusMap.size());
			log.info("Closed cases from NEXUS:: " + caseStatusMap.size());
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getClosedCasesFromNexus()");
		return caseStatusMap;
	}*/
	
	
	
	
	
	/**
	 * This method is used to get closed and solved cases from NEXUS.
	 * @param caseIdStatusMap key is case number and value is case status
	 * @return Nothing
	 */
/*public Map<Long, String> getClosedCasesFromNexus(List<String> openCases) {
		
		log.info("Begining of getClosedCasesFromNexus()");
		
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		Map<Long, String> caseStatusMap = new HashMap<Long, String>();
		StringBuilder caseIdBuilder = new StringBuilder();
		String caseids = "";
		String queryString = "";
		int caseCount = 0;
		int caseCountForLastIteration = 0;
		try {
			if(openCases.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.nexusDbConfig);
				for(String caseid :openCases) {
					caseIdBuilder.append(caseid).append(",");
					caseCount = caseCount + 1;
					caseCountForLastIteration = caseCountForLastIteration + 1;
					
					if(caseCount == 1000 || caseCountForLastIteration == openCases.size()) {
						caseids = caseIdBuilder.toString().substring(0, caseIdBuilder.toString().length()-1);
						if(caseids.length() > 0) {
							queryString = DIMMQueries.CASESTATUS_FROM_NEXUS_QUERYSTRING.replace("case_id IN (", "case_id IN (" + caseids);
							statement = con.prepareStatement(queryString);
							rSet = statement.executeQuery();
							
							while (rSet.next()) {
								caseStatusMap.put(rSet.getLong(DIMMConstants.NEXUS_CASEID_COLUMN), rSet.getString(DIMMConstants.NEXUS_CASESTATUS_COLUMN));
							}
						}
						caseCount = 0;
						caseIdBuilder.delete(0, caseIdBuilder.length());
					}
				}
				
			}
			//System.out.println("Closed cases from NEXUS:: " + caseStatusMap.size());
			log.info("Closed cases from NEXUS:: " + caseStatusMap.size());
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getClosedCasesFromNexus()");
		return caseStatusMap;
	}*/
	
	
public List<String> getClosedCasesFromSnow(List<String> openCases)throws Exception {
		
		log.info("Begining of getClosedCasesFromSnow(): for open cases"+openCases.size() );
		  List<String> casesclosed = new ArrayList<>();
		//	SnowIncident  incident2      = new SnowIncident();
		  
		  if(openCases.size()>0)
		  {
				
			
			
			List<SnowIncident> sn = snowRequestor.getIncidentsByListOfSysId(openCases);
			log.info("Begining of if(openCases.size()>0): for open cases"+sn.size() );
			openCases.clear();
			
			for(SnowIncident sn2: sn)
			{
				log.info("Begining of : for open cases"+sn );
				log.info("Begining of : snow state"+sn2.getSnowState() );
				log.info("Begining of : number"+sn2.getSnowNumber() );
				log.info("Begining of : status"+sn2.getSnowStatus() );
				log.info("Begining of : sysid"+sn2.getSnowSysId() );
				log.info("Begining of : priority"+sn2.getSnowPriority() );
				
			//	if (sn2.getSnowState().equals(SnowConstants.STATE_RESOLVED) || sn2.getSnowState().equals(SnowConstants.STATE_CLOSED )) //for PDSM
				if (sn2.getSnowState().equals(SnowConstants.STATE_EPDSM_RESOLVED) || sn2.getSnowState().equals(SnowConstants.STATE_EPDSM_CLOSED ) || 
						sn2.getSnowState().equals(SnowConstants.STATE_EPDSM_CANCELED)) //|| name.equals("INC3899947")
				{
				//System.out.println("Incident " + name + " is RESOLVED or closed");
					log.info("Begining of if(openCases.size()>0): for open cases"+sn2.getSnowSysId() );
					log.info("Begining of if(openCases.size()>0): for open cases"+sn2.getSnowState() );
					
				casesclosed.add(sn2.getSnowSysId());
				//System.out.println("closed"+sn2.getSnowSysId());
				}
				
			}
				
		
			/*
			incident.setSnowState(SnowConstants.STATE_RESOLVED);
			for(String name: openCases){
			 incident2      = snowRequestor.getIncidentBySysId(name);
			 String state2 = incident2.getSnowState();
			if (state2.equals(SnowConstants.STATE_RESOLVED) || state2.equals(SnowConstants.STATE_CLOSED )) //|| name.equals("INC3899947")
				{
				//System.out.println("Incident " + name + " is RESOLVED or closed");
				casesclosed.add(name);
			
							
		} 
			}*/
		
		  }
		log.info("End of getClosedCasesFromSnow()");
		
		return casesclosed;
	}
	
	/**
	 * This method is used to update case status in ANTC if the case is closed or solved.
	 * @param caseIdStatusMap key is case number and value is case status
	 * @return Nothing
	 */
	
	/*public void updateCaseStatusIfClosedToANTC(List<String> caseIdClosedList) {
		
		log.info("Begining of updateCaseStatusIfClosedToANTC()");
		
		Connection con = null;
		PreparedStatement statement = null;
		try {
			if(caseIdClosedList.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
				statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_TO_ANTC_QUERYSTRING);
				
				for(String name: caseIdClosedList){
					
					statement.setString(1,name);
					statement.addBatch();
				}
					
				
				statement.executeBatch();
				con.commit();
			}
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
		
			DBConnectionFactory.getInstance().releaseConnection(con);
			log.info("End of updateCaseStatusIfClosedToANTC()");
		}
	}
	*/
	/*
	
	public void updateCaseStatusIfClosedToANTC(Map<Long, String> caseIdStatusMap) {
		
		log.info("Begining of updateCaseStatusIfClosedToANTC()");
		
		Connection con = null;
		PreparedStatement statement = null;
		try {
			if(caseIdStatusMap.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
				statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_TO_ANTC_QUERYSTRING);
				for(Long caseid :caseIdStatusMap.keySet()) {
					String statusCreatedTime = caseIdStatusMap.get(caseid);
					String[] statusCreatedTimeArray = statusCreatedTime.split(",");
					String status = statusCreatedTimeArray[0];
					String createdTime = statusCreatedTimeArray[1];
					if(Utilities.getCaseClosedStatusList().contains(status)) {
						statement.setString(1, status);
						statement.setString(2, caseid+"");
						statement.addBatch();
					}/* else {// For 8 hour rule
						if(Utilities.isCaseCreatedTimeGt8hours(createdTime)) {
							statement.setString(1, "RESOL");
							statement.setString(2, caseid+"");
							statement.addBatch();
						}
					}
				}
				statement.executeBatch();
			}
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
			log.info("End of updateCaseStatusIfClosedToANTC()");
		}
	} 
	*/
	/**
	 * This method is used to update case status in DIMM if the case status is in closed or solved.
	 * @param caseIdStatusMap key is case number and value is case status
	 * @return Nothing
	 */
	
	
	
public void updateCaseStatusIfClosedToDIMM(List< String> caseIdClosedList) {
		
		log.info("Begining of updateCaseStatusIfClosedToDIMM()");
		
		Connection con = null;
		PreparedStatement statement = null;
		try {
			if(caseIdClosedList.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
				statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_TO_DIMM_QUERYSTRING);
					for(String name: caseIdClosedList){
					
					statement.setString(1,name);
					statement.addBatch();
				}
					
				
				statement.executeBatch();
				//con.commit();
			}
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
			log.info("End of updateCaseStatusIfClosedToDIMM()");
		}
	}
	
	
	
	
	/*public void updateCaseStatusIfClosedToDIMM(Map<Long, String> caseIdStatusMap) {
		
		log.info("Begining of updateCaseStatusIfClosedToDIMM()");
		
		Connection con = null;
		PreparedStatement statement = null;
		try {
			if(caseIdStatusMap.size() > 0) {
				con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
				statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_TO_DIMM_QUERYSTRING);
				for(Long caseid :caseIdStatusMap.keySet()) {
					String statusCreatedTime = caseIdStatusMap.get(caseid);
					String[] statusCreatedTimeArray = statusCreatedTime.split(",");
					String status = statusCreatedTimeArray[0];
					//String createdTime = statusCreatedTimeArray[1];
					if(Utilities.getCaseClosedStatusList().contains(status)) {
						statement.setString(1, status);
						statement.setString(2, caseid+"");
						statement.addBatch();
					} else {// For 8 hour rule
						if(Utilities.isCaseCreatedTimeGt8hours(createdTime)) {
							statement.setString(1, "RESOL");
							statement.setString(2, caseid+"");
							statement.addBatch();
						}
					}
				}
				statement.executeBatch();
			}
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
			log.info("End of updateCaseStatusIfClosedToDIMM()");
		}
	}*/
	
	/**
	 * This method is used to get all physical alerts which are not having case number.
	 * @param Nothing
	 * @return Collection<PhysicalAlert> list of physical alerts with out case number
	 */
	public Collection<PhysicalAlert> getAllPhysicalAlertsWithoutNexusCaseNumber() {
		
		log.info("Begining of getAllPhysicalAlertsWithoutNexusCaseNumber() fetchs the new alerts");
		
		Collection<PhysicalAlert> alerts = new ArrayList<PhysicalAlert>();
		PhysicalAlert physicalAlert = null;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.PHYSICALALERTS_WITHOUTSNOWCASE_QUERYSTRING);
			rSet = statement.executeQuery();
			
			while (rSet.next()) {
				physicalAlert = new PhysicalAlert();
				physicalAlert.setPhysicalKey(rSet.getLong(DIMMConstants.PHYSICALKEY_COLUMN));
				physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
				physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
				physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
				physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
				physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
				physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
				physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
				physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
				physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
				physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
				physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
				physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
				physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
				physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
				alerts.add(physicalAlert);
			}
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getAllPhysicalAlertsWithoutSNOWCaseNumber(): new alerts"+alerts.size());
		return alerts;
	}
	
	
	
	
public List<AbstractAlert> getAllPhysicalAlertsWithoutNexusCaseNumberandwithlogicalkey() {
		
		log.info("Begining of getAllPhysicalAlertsWithoutNexusCaseNumberandwithlogicalkey()");
		
		List<AbstractAlert> alerts = new ArrayList<AbstractAlert>();
		AbstractAlert physicalAlert = null;
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.PHYSICALALERTS_WITHOUTSNOWCASE_QUERYSTRINGANDWITHLOGICALKEY );
			rSet = statement.executeQuery();
			
			while (rSet.next()) {
			/*	physicalAlert = new PhysicalAlert();
				physicalAlert.setAlertid(rSet.getString(DIMMConstants.PHYSICALKEY_COLUMN));
				physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
				physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
				physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
				physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
				physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
				physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
				physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
				physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
				physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
				physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
				physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
				physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
				physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
				physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
				alerts.add(physicalAlert);*/
					
				physicalAlert = new AbstractAlert();
				physicalAlert.setAlertid(rSet.getString(1));
				//System.out.println(rSet.getString(1));
				physicalAlert.setLogicalkey1(rSet.getString(2));
				physicalAlert.setDashboardName(rSet.getString(3));
				physicalAlert.setRecordSourceId(rSet.getString(4));
				physicalAlert.setCaseSummary(rSet.getString(5));
				physicalAlert.setCaseDescription1(rSet.getString(6));
				physicalAlert.setCaseDescription2(rSet.getString(7));
				physicalAlert.setCaseDescription3(rSet.getString(8));
				physicalAlert.setCaseDescription4(rSet.getString(9));
				physicalAlert.setCaseDescription5(rSet.getString(10));
				physicalAlert.setCaseDescription6(rSet.getString(11));
				physicalAlert.setCaseDescription7(rSet.getString(12));
				physicalAlert.setCaseDescription8(rSet.getString(13));
				physicalAlert.setCaseDescription9(rSet.getString(14));
				physicalAlert.setCreationTime(rSet.getTimestamp(15));
				alerts.add(physicalAlert);
				//System.out.println(physicalAlert);
			}
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			//System.out.println(exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("getAllPhysicalAlertsWithoutNexusCaseNumberandwithlogicalkey");
		return alerts;
	}



public void updateAlertPreoessedforaddnote() {
	
	log.info("Begining of updateAlertPreoessedforaddnote()");
	
	Connection con = null;
	PreparedStatement statement = null;
	try {
		con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.update2foraddnote);
			
	statement.executeUpdate();
	//con.commit();		
	} catch(Exception exception) {
		//LogFactory.getLogger().logException("Error: ",exception);
		log.error("Unexpected error:: ", exception);
	} finally {
		DBConnectionFactory.getInstance().releaseConnection(con);
		log.info("End of updateAlertPreoessedforaddnote()");
	}
}

public List<AbstractAlert> getAllPhysicalAlertsforNewCaseCreation() {
	
	log.info("Begining of getAllPhysicalAlertsforNewCaseCreation()");
	
	List<AbstractAlert> alerts = new ArrayList<AbstractAlert>();
	AbstractAlert physicalAlert = null;
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rSet = null;
	try {
		con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
		statement = con.prepareStatement(DIMMQueries.PHYSICALALERTSFORNEWCASECREATION);
		rSet = statement.executeQuery();
		
		while (rSet.next()) {
		/*	physicalAlert = new PhysicalAlert();
			physicalAlert.setAlertid(rSet.getString(DIMMConstants.PHYSICALKEY_COLUMN));
			physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
			physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
			physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
			physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
			physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
			physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
			physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
			physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
			physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
			physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
			physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
			physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
			physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
			physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
			alerts.add(physicalAlert);*/
				
			physicalAlert = new AbstractAlert();
			physicalAlert.setAlertid(rSet.getString(1));
			//System.out.println(rSet.getString(1));
			physicalAlert.setLogicalkey1(rSet.getString(2));
			physicalAlert.setDashboardName(rSet.getString(3));
			physicalAlert.setRecordSourceId(rSet.getString(4));
			physicalAlert.setCaseSummary(rSet.getString(5));
			physicalAlert.setCaseDescription1(rSet.getString(6));
			physicalAlert.setCaseDescription2(rSet.getString(7));
			physicalAlert.setCaseDescription3(rSet.getString(8));
			physicalAlert.setCaseDescription4(rSet.getString(9));
			physicalAlert.setCaseDescription5(rSet.getString(10));
			physicalAlert.setCaseDescription6(rSet.getString(11));
			physicalAlert.setCaseDescription7(rSet.getString(12));
			physicalAlert.setCaseDescription8(rSet.getString(13));
			physicalAlert.setCaseDescription9(rSet.getString(14));
			physicalAlert.setCreationTime(rSet.getTimestamp(15));
			alerts.add(physicalAlert);
			//System.out.println(physicalAlert);
		}
		
	} catch(Exception exception) {
		//LogFactory.getLogger().logException("Error: ",exception);
		//System.out.println(exception);
		log.error("Unexpected error:: ", exception);
	} finally {
		DBConnectionFactory.getInstance().releaseConnection(con);
	}
	log.info(" End of  getAllPhysicalAlertsforNewCaseCreation");
	return alerts;
}




public List<AbstractAlert> getAllPhysicalAlertsforCaseNumberNeedsUpdate() {
	
	log.info(" Begining of getAllPhysicalAlertsforCaseNumberNeedsUpdate()");
	
	List<AbstractAlert> alerts = new ArrayList<AbstractAlert>();
	AbstractAlert physicalAlert = null;
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rSet = null;
	try {
		con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
		statement = con.prepareStatement(DIMMQueries.PHYSICALALERTSWHICHCASENEEDTOBEUPDATED);
		rSet = statement.executeQuery();
		
		while (rSet.next()) {
		/*	physicalAlert = new PhysicalAlert();
			physicalAlert.setAlertid(rSet.getString(DIMMConstants.PHYSICALKEY_COLUMN));
			physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
			physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
			physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
			physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
			physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
			physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
			physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
			physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
			physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
			physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
			physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
			physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
			physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
			physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
			alerts.add(physicalAlert);*/
				
			physicalAlert = new AbstractAlert();
			physicalAlert.setAlertid(rSet.getString(1));
			//System.out.println(rSet.getString(1));
			physicalAlert.setLogicalkey1(rSet.getString(2));
			physicalAlert.setDashboardName(rSet.getString(3));
			physicalAlert.setRecordSourceId(rSet.getString(4));
			physicalAlert.setCaseSummary(rSet.getString(5));
			physicalAlert.setCaseDescription1(rSet.getString(6));
			physicalAlert.setCaseDescription2(rSet.getString(7));
			physicalAlert.setCaseDescription3(rSet.getString(8));
			physicalAlert.setCaseDescription4(rSet.getString(9));
			physicalAlert.setCaseDescription5(rSet.getString(10));
			physicalAlert.setCaseDescription6(rSet.getString(11));
			physicalAlert.setCaseDescription7(rSet.getString(12));
			physicalAlert.setCaseDescription8(rSet.getString(13));
			physicalAlert.setCaseDescription9(rSet.getString(14));
			physicalAlert.setCreationTime(rSet.getTimestamp(15));
			alerts.add(physicalAlert);
			//System.out.println(physicalAlert);
		}
		
	} catch(Exception exception) {
		//LogFactory.getLogger().logException("Error: ",exception);
		//System.out.println(exception);
		log.error("Unexpected error:: ", exception);
	} finally {
		DBConnectionFactory.getInstance().releaseConnection(con);
	}
	log.info("End of getAllPhysicalAlertsforCaseNumberNeedsUpdate");
	return alerts;
}

public List<AbstractAlert> getAllPhysicalAlertsforAddNote() {
	
	log.info("getAllPhysicalAlertsforNewCaseCreation()");
	
	List<AbstractAlert> alerts = new ArrayList<AbstractAlert>();
	AbstractAlert physicalAlert = null;
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rSet = null;
	try {
		con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
		statement = con.prepareStatement(DIMMQueries.PHYSICALALERTSFORNEWCASECREATION);
		rSet = statement.executeQuery();
		
		while (rSet.next()) {
		/*	physicalAlert = new PhysicalAlert();
			physicalAlert.setAlertid(rSet.getString(DIMMConstants.PHYSICALKEY_COLUMN));
			physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
			physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
			physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
			physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
			physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
			physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
			physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
			physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
			physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
			physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
			physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
			physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
			physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
			physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
			alerts.add(physicalAlert);*/
				
			physicalAlert = new AbstractAlert();
			physicalAlert.setAlertid(rSet.getString(1));
			//System.out.println(rSet.getString(1));
			physicalAlert.setLogicalkey1(rSet.getString(2));
			physicalAlert.setDashboardName(rSet.getString(3));
			physicalAlert.setRecordSourceId(rSet.getString(4));
			physicalAlert.setCaseSummary(rSet.getString(5));
			physicalAlert.setCaseDescription1(rSet.getString(6));
			physicalAlert.setCaseDescription2(rSet.getString(7));
			physicalAlert.setCaseDescription3(rSet.getString(8));
			physicalAlert.setCaseDescription4(rSet.getString(9));
			physicalAlert.setCaseDescription5(rSet.getString(10));
			physicalAlert.setCaseDescription6(rSet.getString(11));
			physicalAlert.setCaseDescription7(rSet.getString(12));
			physicalAlert.setCaseDescription8(rSet.getString(13));
			physicalAlert.setCaseDescription9(rSet.getString(14));
			physicalAlert.setCreationTime(rSet.getTimestamp(15));
			alerts.add(physicalAlert);
			//System.out.println(physicalAlert);
		}
		
	} catch(Exception exception) {
		//LogFactory.getLogger().logException("Error: ",exception);
		//System.out.println(exception);
		log.error("Unexpected error:: ", exception);
	} finally {
		DBConnectionFactory.getInstance().releaseConnection(con);
	}
	log.info("getAllPhysicalAlertsforNewCaseCreation");
	return alerts;
}



public List<AbstractAlert> getAllPhysicalAlertsforAddnote() {
	
	log.info(" Begining of getAllPhysicalAlertsforNewCaseCreation()");
	
	List<AbstractAlert> alerts = new ArrayList<AbstractAlert>();
	AbstractAlert physicalAlert = null;
	Connection con = null;
	PreparedStatement statement = null;
	ResultSet rSet = null;
	try {
		con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
		statement = con.prepareStatement(DIMMQueries.PHYSICALALERTSFORADDNOTE);
		rSet = statement.executeQuery();
		
		while (rSet.next()) {
		/*	physicalAlert = new PhysicalAlert();
			physicalAlert.setAlertid(rSet.getString(DIMMConstants.PHYSICALKEY_COLUMN));
			physicalAlert.setDashboardName(rSet.getString(DIMMConstants.DASHBOARDNAME_COLUMN));
			physicalAlert.setRecordSourceId(rSet.getString(DIMMConstants.RECORDSOURCE_ID_COLUMN));
			physicalAlert.setCaseSummary(rSet.getString(DIMMConstants.CASESUMMARY_COLUMN));
			physicalAlert.setLogicalKey(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN));
			physicalAlert.setCaseDescription1(rSet.getString(DIMMConstants.CASEDESCRIPTION1_COLUMN));
			physicalAlert.setCaseDescription2(rSet.getString(DIMMConstants.CASEDESCRIPTION2_COLUMN));
			physicalAlert.setCaseDescription3(rSet.getString(DIMMConstants.CASEDESCRIPTION3_COLUMN));
			physicalAlert.setCaseDescription4(rSet.getString(DIMMConstants.CASEDESCRIPTION4_COLUMN));
			physicalAlert.setCaseDescription5(rSet.getString(DIMMConstants.CASEDESCRIPTION5_COLUMN));
			physicalAlert.setCaseDescription6(rSet.getString(DIMMConstants.CASEDESCRIPTION6_COLUMN));
			physicalAlert.setCaseDescription7(rSet.getString(DIMMConstants.CASEDESCRIPTION7_COLUMN));
			physicalAlert.setCaseDescription8(rSet.getString(DIMMConstants.CASEDESCRIPTION8_COLUMN));
			physicalAlert.setCaseDescription9(rSet.getString(DIMMConstants.CASEDESCRIPTION9_COLUMN));
			physicalAlert.setCreationTime(rSet.getTimestamp(DIMMConstants.CREATIONTIME_COLUMN));
			alerts.add(physicalAlert);*/
				
			physicalAlert = new AbstractAlert();
			physicalAlert.setAlertid(rSet.getString(1));
			//System.out.println(rSet.getString(1));
			physicalAlert.setLogicalkey1(rSet.getString(2));
			physicalAlert.setDashboardName(rSet.getString(3));
			physicalAlert.setRecordSourceId(rSet.getString(4));
			physicalAlert.setCaseSummary(rSet.getString(5));
			physicalAlert.setCaseDescription1(rSet.getString(6));
			physicalAlert.setCaseDescription2(rSet.getString(7));
			physicalAlert.setCaseDescription3(rSet.getString(8));
			physicalAlert.setCaseDescription4(rSet.getString(9));
			physicalAlert.setCaseDescription5(rSet.getString(10));
			physicalAlert.setCaseDescription6(rSet.getString(11));
			physicalAlert.setCaseDescription7(rSet.getString(12));
			physicalAlert.setCaseDescription8(rSet.getString(13));
			physicalAlert.setCaseDescription9(rSet.getString(14));
			physicalAlert.setCreationTime(rSet.getTimestamp(15));
			alerts.add(physicalAlert);
			//System.out.println(physicalAlert);
		}
		
	} catch(Exception exception) {
		//LogFactory.getLogger().logException("Error: ",exception);
		//System.out.println(exception);
		log.error("Unexpected error:: ", exception);
	} finally {
		DBConnectionFactory.getInstance().releaseConnection(con);
	}
	log.info("End of getAllPhysicalAlertsforNewCaseCreation");
	return alerts;
}





	/**
	 * This method is used to get case number from ANTC.
	 * @param logicalKeyList list of logical keys
	 * @return Map<String, String> key is logical key and value is case number
	 */
	public Map<String, String> getNexusCaseNumberFromANTC(Set<String> logicalKeyList) {
		
		log.info("Begining of getNexusCaseNumberFromANTC()");
		
		Map<String, String> logicalKeyCaseIdMap = new HashMap<String, String>();
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		StringBuilder logicalKeyBuilder = new StringBuilder();
		String logicalKeys = "";
		String queryString = "";
		int logicalKeyCount = 0;
		int logicalKeyForLastIteration = 0;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			for(String logicalKey :logicalKeyList) {
				logicalKeyBuilder.append("'").append(logicalKey).append("'").append(",");
				logicalKeyCount = logicalKeyCount + 1;
				logicalKeyForLastIteration = logicalKeyForLastIteration + 1;
				if(logicalKeyCount == 1000 || logicalKeyForLastIteration == logicalKeyList.size()) {
					logicalKeys = logicalKeyBuilder.toString().substring(0, logicalKeyBuilder.toString().length()-1);
					queryString = DIMMQueries.GET_CASENUM_FROM_ANTC_QUERYSTRING.replace("logicalkey IN (", "recordsourceid IN (" + logicalKeys+")group by recordsourceid") ;
					
					//System.out.println(queryString);
					statement = con.prepareStatement(queryString);
					rSet = statement.executeQuery();
					while (rSet.next()) {
						logicalKeyCaseIdMap.put(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN), rSet.getString(DIMMConstants.CASEID_COLUMN));
					}
					logicalKeyCount = 0;
					logicalKeyBuilder.delete(0, logicalKeyBuilder.length());
				}
			}
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getNexusCaseNumberFromANTC()");
		return logicalKeyCaseIdMap;
	}
	
public Map<String, String> getNexusCaseNumberFromANTCForAddNote(Set<String> logicalKeyList) {
		
		log.info("Begining of getNexusCaseNumberFromANTC()");
		
		Map<String, String> logicalKeyCaseIdMap = new HashMap<String, String>();
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		StringBuilder logicalKeyBuilder = new StringBuilder();
		String logicalKeys = "";
		String queryString = "";
		int logicalKeyCount = 0;
		int logicalKeyForLastIteration = 0;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			for(String logicalKey :logicalKeyList) {
				logicalKeyBuilder.append("'").append(logicalKey).append("'").append(",");
				logicalKeyCount = logicalKeyCount + 1;
				logicalKeyForLastIteration = logicalKeyForLastIteration + 1;
				if(logicalKeyCount == 1000 || logicalKeyForLastIteration == logicalKeyList.size()) {
					logicalKeys = logicalKeyBuilder.toString().substring(0, logicalKeyBuilder.toString().length()-1);
					queryString = DIMMQueries.GET_CASENUM_FROM_ANTC_QUERYSTRINGFORADDNOTE.replace("logicalkey IN (", "logicalkey IN (" + logicalKeys+")group by logicalkey") ;
					
					//System.out.println(queryString);
					statement = con.prepareStatement(queryString);
					rSet = statement.executeQuery();
					while (rSet.next()) {
						logicalKeyCaseIdMap.put(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN), rSet.getString(DIMMConstants.CASEID_COLUMN));
					}
					logicalKeyCount = 0;
					logicalKeyBuilder.delete(0, logicalKeyBuilder.length());
				}
			}
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getNexusCaseNumberFromANTC()");
		return logicalKeyCaseIdMap;
	}
	
	
	
	/**
	 * This method is used to get record inserted timestamp from ANTC.
	 * @param logicalKeyList list of logical keys
	 * @return Map<String, String> key is logical key and value is creationtime
	 */
	public Map<String, String> getCreationTimeFromANTC(Set<String> logicalKeyList) {
		
		log.info("Begining of getCreationTimeFromANTC()");
		
		Map<String, String> logicalKeyCreationtimeMap = new HashMap<String, String>();
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		StringBuilder logicalKeyBuilder = new StringBuilder();
		String logicalKeys = "";
		String queryString = "";
		int logicalKeyCount = 0;
		int logicalKeyForLastIteration = 0;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			for(String logicalKey :logicalKeyList) {
				logicalKeyBuilder.append("'").append(logicalKey).append("'").append(",");
				logicalKeyCount = logicalKeyCount + 1;
				logicalKeyForLastIteration = logicalKeyForLastIteration + 1;
				if(logicalKeyCount == 1000 || logicalKeyForLastIteration == logicalKeyList.size()) {
					logicalKeys = logicalKeyBuilder.toString().substring(0, logicalKeyBuilder.toString().length()-1);
					queryString = DIMMQueries.GET_TIMESTAMP_FROM_ANTC_QUERYSTRING.replace("logicalkey IN (", "logicalkey IN (" + logicalKeys);
					statement = con.prepareStatement(queryString);
					rSet = statement.executeQuery();
					while (rSet.next()) {
						logicalKeyCreationtimeMap.put(rSet.getString(DIMMConstants.LOGICALKEY_COLUMN), rSet.getString(DIMMConstants.CREATIONTIME_COLUMN));
					}
					logicalKeyCount = 0;
					logicalKeyBuilder.delete(0, logicalKeyBuilder.length());
				}
			}
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getCreationTimeFromANTC()");
		return logicalKeyCreationtimeMap;
	}
	
	/**
	 * This method is used to update casestatus=RESOL if ANTC is down.
	 * @param logicalKeyList list of logical keys
	 * @return Nothing
	 */
	/*@SuppressWarnings("unused")
	public void updateCasestatusInANTCIfANTCDown(List<String> antcDownLogicalKeys) {
		
		log.info("Begining of updateCasestatusInANTCIfANTCDown()");
		
		Connection con = null;
		PreparedStatement statement = null;
		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_IN_ANTC_IF_ANTCDOWN_QUERYSTRING);
			for(String logicalKey :antcDownLogicalKeys) {
				statement.setString(1, logicalKey);
				statement.addBatch();
			}
			int[] updatedCount = statement.executeBatch();
		} catch(Exception exception) {
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of updateCasestatusInANTCIfANTCDown()");
	}*/
	
	/**
	 * This method is used to update casestatus=RESOL and logicalkey=ANTCISDOWN if ANTC is down.
	 * @param logicalKeyList list of logical keys
	 * @return Nothing
	 */
	/*@SuppressWarnings("unused")
	public void updateCasestatusInDIMMIfANTCDown(List<String> antcDownLogicalKeys) {
		
		log.info("Begining of updateCasestatusInDIMMIfANTCDown()");
		
		Connection con = null;
		PreparedStatement statement = null;
		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.UPDATE_CASESTATUS_IN_DIMM_IF_ANTCDOWN_QUERYSTRING);
			for(String logicalKey :antcDownLogicalKeys) {
				statement.setString(1, logicalKey);
				statement.addBatch();
			}
			int[] updatedCount = statement.executeBatch();
		} catch(Exception exception) {
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of updateCasestatusInDIMMIfANTCDown()");
	} */
	
	/**
	 * This method is used to update case number for physical alerts.
	 * @param alerts list of physical alerts
	 * @param logicalKeyCaseIdMap key is logical key and value is case number 
	 * @return Nothing
	 */
	public void updateSNOWCaseNumberForPhysicalAlert(List<AbstractAlert> alerts, Map<String, String> logicalKeyCaseIdMap) {
		
		log.info("Begining of updateSNOWCaseNumberForPhysicalAlert()");
		
		Connection con = null;
		PreparedStatement statement = null;
		PreparedStatement statement2 = null;

		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.UPDATE_CASENUM_FOR_PHYSICALALERT_QUERYSTRING);
			statement2 = con.prepareStatement(DIMMQueries.UPDATE_CASESYSID_FOR_PHYSICALALERT_QUERYSTRING);

			
			for(AbstractAlert alert :alerts) {
				String logicalKey = alert.getLogicalkey1();
				String caseNumber = logicalKeyCaseIdMap.get(logicalKey);
				statement.setString(1, caseNumber);
				statement.setString(2, alert.getAlertid());
				statement.addBatch();
			}
			
			
			for(AbstractAlert alert :alerts) {
				String logicalKey = alert.getLogicalkey1();
				String caseNumber = logicalKeyCaseIdMap.get(logicalKey);
				statement2.setString(1, caseNumber);
				statement2.setString(2, caseNumber);
				statement2.addBatch();
			}
			
			
			
		
			int[] updatedCount = statement.executeBatch();
		           statement2.executeBatch();
		           //con.commit();
			//LogFactory.getLogger().logDebug("Updated Rows with nexus case number for physical alerts:: " + updatedCount.length);
			log.info("Updated Rows with SNOW case number for physical alerts:: " + updatedCount.length);
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of updateNexusCaseNumberForPhysicalAlert()");
	}
	
	public String getNextAvailableLogicalKey(){
		//TODO: query the sequence to get the next available logical key value
		return "";
	}
	
	/**
	 * This method is used to update logical key for physical alerts in DIMM.
	 * @param alerts list of physical alerts
	 * @return Nothing
	 */
	public void updateLogicalKeyForPhysicalAlert(List<PhysicalAlert> alerts) {
		
		log.info("Begining of updateLogicalKeyForPhysicalAlert()");
				
				Connection con = null;
				PreparedStatement statement = null;
				
				try {
					con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
					
					statement = con.prepareStatement(DIMMQueries.UPDATE_LOGICALKEY_TO_PHYSICALALERT_QUERYSTRING);
					
					for(PhysicalAlert alert :alerts) {
						String logicalKey = alert.getLogicalKey();
						statement.setString(1, logicalKey);
						//if(logicalKey.equals("COMPONENT-3")) {
						//if(logicalKey.equals("OVOAlert")) {
						if(logicalKey.equals("ReferenceAlert")) {
							statement.setString(2, "RESOL");
						} else {
							statement.setString(2, "WORK");
						}
						statement.setLong(3, alert.getPhysicalKey());
						statement.addBatch();
					}
					int[] updatedCount = statement.executeBatch();
					//LogFactory.getLogger().logDebug("Updated Rows with logicalkey for physical alerts:: " + updatedCount.length);
					log.info("Updated Rows with logicalkey for physical alerts:: " + updatedCount.length);
					//con.commit();
				} catch(Exception exception) {
					//LogFactory.getLogger().logException("Error: ",exception);
					log.error("Unexpected error:: ", exception);
				} finally {
					DBConnectionFactory.getInstance().releaseConnection(con);
				}
				log.info("End of updateLogicalKeyForPhysicalAlert()");
			}
	
	/**
	 * This method is used to insert logical alerts into ANTC if they are not available in ANTC table.
	 * @param alerts list of logical alerts
	 * @return Nothing
	 */
	public void insertLogicalAlertIntoANTCIfAbsent(List<AbstractAlert> alerts) {
		
		log.info("Begining of insertLogicalAlertIntoANTCIfAbsent()");
		
		Connection con = null;
		PreparedStatement statement = null;
		PreparedStatement statement2 = null;
		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			statement = con.prepareStatement(DIMMQueries.INSERT_LOGICALALERT_QUERYSTRING);
			statement2 = con.prepareStatement(DIMMQueries.UPDATEALERTPROCESSEDTODIMMINTERFACE);
			for(AbstractAlert alert :alerts) {
				statement.setString(1, "DIMM:"+alert.getDashboardName());
				statement.setString(2, alert.getRecordSourceId());
				statement.setString(3, alert.getCaseSummary());
				statement.setString(4, alert.getLogicalkey1());
				statement.setString(5, alert.getCaseDescription1());
				statement.setString(6, alert.getCaseDescription2());
				statement.setString(7, alert.getCaseDescription3());
				statement.setString(8, alert.getCaseDescription4());
				statement.setString(9, alert.getCaseDescription5());
				statement.setString(10, alert.getCaseDescription6());
				statement.setString(11, alert.getCaseDescription7());
				statement.setString(12, alert.getCaseDescription8());
				statement.setString(13, alert.getCaseDescription9());
				
				statement2.setString(1,alert.getAlertid());
			
				statement.addBatch();
				statement2.addBatch();
			}		
			int[] updatedCount = statement.executeBatch();
			statement2.executeBatch();
			//con.commit();
			//LogFactory.getLogger().logDebug("Inserted logical rows into ANTC database :: " + updatedCount.length);
			log.info("Inserted logical rows into ANTC database :: " + updatedCount.length);
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of insertLogicalAlertIntoANTCIfAbsent()");
	}
	
	/**
	 * This method is used to insert logical alerts for add-note into ANTC if they are not available in ANTC table.
	 * @param alerts list of logical alerts
	 * @return Nothing
	 */
	public void insertLogicalAlertForAddNote(List<AbstractAlert> alerts) {
		
		log.info("Begining of insertLogicalAlertForAddNote()");
		
		Connection con = null;
		PreparedStatement statement = null;
		PreparedStatement statement2 = null;
		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			statement = con.prepareStatement(DIMMQueries.INSERT_ALERT_FOR_ADDNOTE_QUERYSTRING);
			statement2 = con.prepareStatement(DIMMQueries.UPDATE_CASESYSID_FOR_PHYSICALALERT_QUERYSTRING2);
			for(AbstractAlert alert :alerts) {
				statement.setString(1, alert.getRecordSourceId());
				//statement.setString(2, alert.getCaseSummary());
				statement.setString(2, alert.getLogicalkey1());
				statement.setString(3, alert.getCaseDescription1());
				statement.setString(4, alert.getCaseDescription2());
				statement.setString(5, alert.getCaseDescription3());
				statement.setString(6, alert.getCaseDescription4());
				statement.setString(7, alert.getCaseDescription5());
				statement.setString(8, alert.getCaseDescription6());
				statement.setString(9, alert.getCaseDescription7());
				statement.setString(10, alert.getCaseDescription8());
				statement.setString(11, alert.getCaseDescription9());
				statement.setString(12, alert.getNexusCaseNumber());
				
				statement2.setString(1, alert.getNexusCaseNumber());
				statement2.setString(2, alert.getNexusCaseNumber());
			
				statement.addBatch();
				statement2.addBatch();
			}		
			
			
			
		
			int[] updatedCount = statement.executeBatch();
		           statement2.executeBatch();
		           //con.commit();
			//LogFactory.getLogger().logDebug("Inserted logical rows for ADD-NOTE :: " + updatedCount.length);
			log.info("Inserted logical rows for ADD-NOTE :: " + updatedCount.length);
			
		} catch(Exception exception) {
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of insertLogicalAlertForAddNote()");
	}
	
		
	/**
	 * This method is used to get nexus case number from ovomessages table for Component_3.
	 * @param serverName 
	 * @return String nexus case number
	 */
	/*public String getNexusCaseNumberFromOvo(String serverName) {
		log.info("Begining of getNexusCaseNumberFromOvo()");
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rSet = null;
		String nexusCaseid = null;
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.antcDbConfig);
			statement = con.prepareStatement(DIMMQueries.NEXUSCASE_FROM_OVO_QUERYSTRING);
			statement.setString(1, serverName);
			rSet = statement.executeQuery();
			while (rSet.next()) {
				nexusCaseid = rSet.getString(DIMMConstants.CASEID_COLUMN);
			}
			log.info("Server Name:: " + serverName + "   Nexus case number from OVO:: " + nexusCaseid);
		} catch(Exception exception) {
			log.error("Unexpected error:: ", exception);
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of getNexusCaseNumberFromOvo()");
		return nexusCaseid;
	}*/
	
	
	
	public void upadteCaseStatusifLogicalkeyForUnprocessedAlert(List<String> opencaseresid)
	{
		log.info(" Begining of upadteCaseStatusifLogicalkeyForUnprocessedAlert()");
		
		
		
		Connection con = null;
		PreparedStatement statement = null;
		
		try {
			con = DBConnectionFactory.getInstance().getConnection(this.monitorAlertStagingDbConfig);
			statement = con.prepareStatement(DIMMQueries.UPDATECASESTATUSLOGICALKEYIFALERTPROCESSED);
			
			
			for(String resid :opencaseresid) {
				statement.setString(1, resid);
			statement.addBatch();
			}
			statement.executeBatch();
		} catch(Exception exception) {
			log.error("Unexpected error:: ", exception);
	
		} finally {
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		log.info("End of upadteCaseStatusifLogicalkeyForUnprocessedAlert()  ");
						
	}
}