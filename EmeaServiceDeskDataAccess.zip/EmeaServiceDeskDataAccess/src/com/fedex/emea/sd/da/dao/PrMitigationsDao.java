package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrMitigationsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrMitigations;
import com.fedex.emea.sd.da.objects.PrMitigationsPk;

public interface PrMitigationsDao
{
	
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrMitigationsDaoException;
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrMitigationsDaoException;
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrMitigationsPk
	 */
	public PrMitigationsPk insert(PrMitigations dto);

	/** 
	 * Updates a single row in the PR_MITIGATIONS table.
	 */
	public void update(PrMitigationsPk pk, PrMitigations dto) throws PrMitigationsDaoException;

	/** 
	 * Deletes a single row in the PR_MITIGATIONS table.
	 */
	public void delete(PrMitigationsPk pk) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId AND ITEM = :item'.
	 */
	public PrMitigations findByPrimaryKey(String cy, String eaiId, String ni2AppId, String item) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria ''.
	 */
	public List<PrMitigations> findAll() throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'CY = :cy'.
	 */
	public List<PrMitigations> findWhereCyEquals(String cy) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	public List<PrMitigations> findWhereEaiIdEquals(String eaiId) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	public List<PrMitigations> findWhereSymAppNameEquals(String symAppName) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	public List<PrMitigations> findWhereNi2AppIdEquals(String ni2AppId) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	public List<PrMitigations> findWhereNi2AppNameEquals(String ni2AppName) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	public List<PrMitigations> findWhereRespMdPinEquals(String respMdPin) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	public List<PrMitigations> findWhereRespMgrPinEquals(String respMgrPin) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'ITEM = :item'.
	 */
	public List<PrMitigations> findWhereItemEquals(String item) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'QUESTION = :question'.
	 */
	public List<PrMitigations> findWhereQuestionEquals(String question) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'ANSWER = :answer'.
	 */
	public List<PrMitigations> findWhereAnswerEquals(String answer) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'MITIGATION_STATUS = :mitigationStatus'.
	 */
	public List<PrMitigations> findWhereMitigationStatusEquals(String mitigationStatus) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	public List<PrMitigations> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrMitigationsDaoException;

	/** 
	 * Returns all rows from the PR_MITIGATIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	public List<PrMitigations> findWhereAuditIdEquals(int auditId) throws PrMitigationsDaoException;

	/** 
	 * Returns the rows from the PR_MITIGATIONS table that matches the specified primary-key value.
	 */
	public PrMitigations findByPrimaryKey(PrMitigationsPk pk) throws PrMitigationsDaoException;

}
