package com.fedex.emea.sd.da.objects;

import com.fedex.emea.sd.da.helpers.Constants;

public class MailTemplates {
	
	private static StringBuffer getCommonHeader() {
		StringBuffer mailHeader = new StringBuffer();
		
		mailHeader.append("<html>");
		mailHeader.append("<head>");
		mailHeader.append("<style type=\"text/css\">");
		mailHeader.append(".mailfieldreminder {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#FF0000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("}");
		mailHeader.append(".mailfieldimportant {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#FF0000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("}");
		mailHeader.append("table.main {");
		mailHeader.append("  width: 800px;");
		mailHeader.append("  border: 1px solid grey;");
		mailHeader.append("  border-width:0px 0px 0px 0px;");
		mailHeader.append("  border-collapse:collapse;");
		mailHeader.append("}");
		mailHeader.append("table.main td.title {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:18px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #660099;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:2px 2px 2px 2px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailfieldintro {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#000000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("  padding:5px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailsectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #999999;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailerrorsectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #FF0000;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailemptysectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  background-color: #FFFFFF;");
		mailHeader.append("}");

		mailHeader.append("table.main td.mailreminderredsectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #dd0000;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailreminderorangesectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#FFFFFF;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #ff6600;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailreminderyellowsectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#000000;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #eaf000;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailremindergreensectiontitle {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:14px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  color:#000000;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #a2cc0d;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");

		mailHeader.append("table.main td.mailfieldtitle {");
		mailHeader.append("  width: 150px;");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #ff6600;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailsectiontitleorange {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  background-color: #ff6600;");
		mailHeader.append("  color:#ffffff;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("  border: 1px solid black;");
		mailHeader.append("  border-width:1px 1px 1px 1px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailfieldtext {");
		mailHeader.append("  width: 250px;");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  font-weight:bold;");
		mailHeader.append("  text-align:center;");
		mailHeader.append("  color:#000000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailfieldtextblue {");
		mailHeader.append("  width: 650px;");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#0000AA;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("  padding:5px;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailfieldimportanttext {");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#FF0000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("}");
		mailHeader.append("table.main td.mailfieldseparator {");
		mailHeader.append("  width: 10px;");
		mailHeader.append("  font-family:Arial, Helvetica, Verdana, sans-serif;");
		mailHeader.append("  font-size:12px;");
		mailHeader.append("  text-align:left;");
		mailHeader.append("  color:#000000;");
		mailHeader.append("  vertical-align:top;");
		mailHeader.append("  padding:5px;");
		mailHeader.append("}");
		mailHeader.append("</style>");
		mailHeader.append("</head>");
		mailHeader.append("<body bgcolor=\"#ffffff\">");
		mailHeader.append("<center>");

		return mailHeader;
	}
	
	private static StringBuffer getCommonFooter() {
		StringBuffer mailFooter = new StringBuffer();
		
		mailFooter.append("</center>");
		mailFooter.append("<br/>");
		mailFooter.append("<hr size=\"2\" width=\"100%\" align=\"center\" tabindex=-1>");
		mailFooter.append("</body>");
		mailFooter.append("</html>");
		
		return mailFooter;
	}
	
	// ***************************************************************************************************
	//                                     N E X U S
	// ***************************************************************************************************
	
	public static StringBuffer createReminderMail(NexusInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer reminderMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic NEXUS Ticket Creator Application.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    <div class=\"mailfieldreminder\">");
		mailBody.append("    Below NEXUS Case has been already opened for a previous Alert but has not been processed yet.<br/>");
		mailBody.append("    In the meantime, another similar Alert has been generated which has triggered an additional Note.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    Please act accordingly by opening the Case in NEXUS and assigning correct Provider Group & Case Status (WIP)");
		mailBody.append("    </div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">Please check below NEXUS Case</td>");
		mailBody.append("  </tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">NEXUS Case Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Case Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCasePriority() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Case Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");	
		
		reminderMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return reminderMail;
	}
	
	public static StringBuffer createReOpenMail(NexusInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer reminderMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic NEXUS Ticket Creator Application.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    <div class=\"mailfieldreminder\">");
		mailBody.append("    Below NEXUS Case has already been <b>created and marked as Solved</b> for an identical Alert previously received.<br/>");
		mailBody.append("    In the meantime, another similar Alert has been generated which has triggered an additional Note into this Case.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    Please act accordingly by Re-Opening this Case in NEXUS and by handling it to resolution.");
		mailBody.append("    </div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">Please check below NEXUS Case</td>");
		mailBody.append("  </tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">NEXUS Case Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Case Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCasePriority() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Case Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");	
		
		reminderMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return reminderMail;
	}
	
	public static StringBuffer createAlertMail(NexusInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer alertMail = new StringBuffer();

		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic NEXUS Ticket Creator Application.<br/>");
		mailBody.append("    Below are the details of the NEXUS Case created based on information received.<br/>");
		mailBody.append("    <div class=\"mailfieldimportant\">**** Please act accordingly ****</div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">" + externalInterfaceRecord.getCaseSummary() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">NEXUS Case Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Case Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCasePriority() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Case Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");

		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		alertMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return alertMail;
	}
	
	public static StringBuffer createCaseCreatedUserMail(NexusInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer alertMail = new StringBuffer();

		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Service Desk Automation System.<br/>");
		mailBody.append("    Below are the details of the NEXUS Ticket created based on information you have provided.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">" + externalInterfaceRecord.getCaseSummary() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">NEXUS Case Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Case Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCasePriority() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Case Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");

		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		alertMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return alertMail;
	}
	
	public static StringBuffer createErrorMail(NexusInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer errorMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic NEXUS Ticket Creator listener.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailerrorsectiontitle\">ERROR - NEXUS Case not created</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldimportanttext\">Check Error.log file in /var/opt/AutomaticTicketCreator to determine root cause</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Alert Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getAlertId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Case Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCasePriority() + "</td>");
		mailBody.append("  </tr>");	
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Case Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		errorMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return errorMail;
	}
	
	// ***************************************************************************************************
	//                                S E R V I C E  N O W
	// ***************************************************************************************************
	
	public static StringBuffer createReminderMail(ExternalInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer reminderMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic Support Ticket Creator Application.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    <div class=\"mailfieldreminder\">");
		mailBody.append("    Below Incident has been already opened for a previous Alert but has not been processed yet.<br/>");
		mailBody.append("    In the meantime, another similar Alert has been generated which has triggered an additional Note.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    Please act accordingly by opening the Incident in ServiceNow and assigning correct Group & Incident State (In-Progress)");
		mailBody.append("    </div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">Please check below Incident</td>");
		mailBody.append("  </tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Number</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + getEpdsmPriority(externalInterfaceRecord.getCasePriority()) + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Incident Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");	
		
		reminderMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return reminderMail;
	}
	
	public static StringBuffer createReOpenMail(ExternalInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer reminderMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic Support Ticket Creator Application.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    <div class=\"mailfieldreminder\">");
		mailBody.append("    Below Incident has already been <b>created and marked as Solved</b> for an identical Alert previously received.<br/>");
		mailBody.append("    In the meantime, another similar Alert has been generated which has triggered an additional Note into this Case.<br/>");
		mailBody.append("    <br/>");
		mailBody.append("    Please act accordingly by Re-Opening this Incident in ServiceNow and by handling it to resolution.");
		mailBody.append("    </div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">Please check below Incident</td>");
		mailBody.append("  </tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Number</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + getEpdsmPriority(externalInterfaceRecord.getCasePriority()) + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Incident Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");	
		
		reminderMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return reminderMail;
	}
	
	public static StringBuffer createAlertMail(ExternalInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer alertMail = new StringBuffer();

		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic Support Ticket Creator Application.<br/>");
		mailBody.append("    Below are the details of the Incident created based on information received.<br/>");
		mailBody.append("    <div class=\"mailfieldimportant\">**** Please act accordingly ****</div>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">" + externalInterfaceRecord.getCaseSummary() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Number</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + getEpdsmPriority(externalInterfaceRecord.getCasePriority()) + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Incident Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");

		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		alertMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return alertMail;
	}
	
	public static StringBuffer createCaseCreatedUserMail(ExternalInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer alertMail = new StringBuffer();

		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Service Desk Automation System.<br/>");
		mailBody.append("    Below are the details of the Ticket created based on information you have provided.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">" + externalInterfaceRecord.getCaseSummary() + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Ticket Number</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getCaseId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Ticket Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + getEpdsmPriority(externalInterfaceRecord.getCasePriority()) + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Ticket Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");

		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		alertMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return alertMail;
	}
	
	public static StringBuffer createErrorMail(ExternalInterface externalInterfaceRecord) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer errorMail = new StringBuffer();
		
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation (Source: " + externalInterfaceRecord.getRecordSource() + ")</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic Support Ticket Creator listener.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailerrorsectiontitle\">ERROR - Incident not created</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldimportanttext\">Check Error.log file in /var/opt/AutomaticSupportTicketCreator to determine root cause</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Alert Id</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + externalInterfaceRecord.getAlertId() + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Incident Priority</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + getEpdsmPriority(externalInterfaceRecord.getCasePriority()) + "</td>");
		mailBody.append("  </tr>");	
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitleorange\">Incident Description</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldtextblue\">");
		if (externalInterfaceRecord.getCaseDescription1() != null) mailBody.append(externalInterfaceRecord.getCaseDescription1().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription2() != null) mailBody.append(externalInterfaceRecord.getCaseDescription2().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription3() != null) mailBody.append(externalInterfaceRecord.getCaseDescription3().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription4() != null) mailBody.append(externalInterfaceRecord.getCaseDescription4().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription5() != null) mailBody.append(externalInterfaceRecord.getCaseDescription5().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription6() != null) mailBody.append(externalInterfaceRecord.getCaseDescription6().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription7() != null) mailBody.append(externalInterfaceRecord.getCaseDescription7().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription8() != null) mailBody.append(externalInterfaceRecord.getCaseDescription8().replaceAll(System.getProperty("line.separator"), "<br/>"));
		if (externalInterfaceRecord.getCaseDescription9() != null) mailBody.append(externalInterfaceRecord.getCaseDescription9().replaceAll(System.getProperty("line.separator"), "<br/>"));
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		errorMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return errorMail;
	}
	
	public static StringBuffer createFailureMail(String moduleName, String exceptionText) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer failureMail = new StringBuffer();		

		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">Service Desk Automation</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail has been sent automatically by the Automatic Support Ticket Creator application.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">ERROR - Application Failure</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Problem</td>");
		mailBody.append("    <td class=\"mailfieldtext\">Exception generated</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Module</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + moduleName + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailerrorsectiontitle\">Exception</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldimportanttext\" coslpan=\"4\">" + exceptionText + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("</table>");

		failureMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return failureMail;
	}
	
	// ***************************************************************************************************
	//                                P E A K    R E A D I N E S S
	// ***************************************************************************************************
	
	public static StringBuffer createPeakReadinessMail(String actionPhase, String reminderType, StringBuffer reminderText, String mailTitle , int reminderCode) {
		StringBuffer mailBody = new StringBuffer();
		StringBuffer prMail = new StringBuffer();
				
		mailBody.append("<table class=\"main\">");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"title\">" + mailTitle + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailfieldintro\">");
		mailBody.append("    This mail is automatically sent by the EU & MEISA IT Peak Readiness Monitoring system.<br/>");
		mailBody.append("    Should you have any comment or question, please contact EU & MEISA IT BCDR Team by replying to this mail.<br/>");
		mailBody.append("    </td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">Summary</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtitle\">Reminder Type</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + reminderType + "</td>");
		mailBody.append("    <td class=\"mailfieldtitle\">Phase</td>");
		mailBody.append("    <td class=\"mailfieldtext\">" + actionPhase + "</td>");
		mailBody.append("  </tr>");
		mailBody.append("  <tr><td colspan=\"4\" class=\"mailemptysectiontitle\">&nbsp;</td></tr>");
		mailBody.append("  <tr>");
		if (reminderCode == 0) mailBody.append("    <td colspan=\"4\" class=\"mailremindergreensectiontitle\">INFORMATION REMINDER</td>");
		else {
			if (reminderCode == 1) mailBody.append("    <td colspan=\"4\" class=\"mailreminderyellowsectiontitle\">DELAY REMINDER</td>");
			else  {
				if (reminderCode == 2) mailBody.append("    <td colspan=\"4\" class=\"mailreminderorangesectiontitle\">DELAY REMINDER</td>");
				else {
					if (reminderCode == 3) mailBody.append("    <td colspan=\"4\" class=\"mailreminderredsectiontitle\">LATE ON SCHEDULE</td>");
					else {
						mailBody.append("    <td colspan=\"4\" class=\"mailsectiontitle\">INFORMATION</td>");
					}
				}
			}
		}
		mailBody.append("  </tr>");
		mailBody.append("  <tr>");
		mailBody.append("    <td class=\"mailfieldtextblue\" colspan=\"4\">" + reminderText.toString() + "</td>");
		mailBody.append("  </tr>");
		
		mailBody.append("</table>");

		prMail.append(getCommonHeader().toString()).append(mailBody.toString()).append(getCommonFooter().toString());
		return prMail;
	}
	
	private static String getEpdsmPriority(String externalInterfacePriority) {
		String prio = "";
		
		if (externalInterfacePriority != null) {
			if (externalInterfacePriority.equals(Constants.CASE_PRIORITY_CRITICAL)) {
				prio = "P2";
			} else { 
				if (externalInterfacePriority.equals(Constants.CASE_PRIORITY_HIGH)) {
					prio = "P4";   //to assign ticket priority FOR NORMAL ASTC TICKETS
				} else { 
					if (externalInterfacePriority.equals(Constants.CASE_PRIORITY_TOOHIGH)) {
						prio = "P3";   //to assign ticket priority FOR OVO TICKETS
					} else {
					prio = "P5";
				}
			}
		}
		
	}		
		return prio;
	}
}
