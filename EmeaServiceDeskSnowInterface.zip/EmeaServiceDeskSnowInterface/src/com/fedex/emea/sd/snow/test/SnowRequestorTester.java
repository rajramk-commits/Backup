package com.fedex.emea.sd.snow.test;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import com.fedex.emea.sd.snow.manager.SnowRESTCommunicator;
import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowAstcIncident;
import com.fedex.emea.sd.snow.objects.SnowCmdbCiServices;
import com.fedex.emea.sd.snow.objects.SnowCmdbCis;
import com.fedex.emea.sd.snow.objects.SnowCompanies;
import com.fedex.emea.sd.snow.objects.SnowCountries;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowIncidentMetrics;
import com.fedex.emea.sd.snow.objects.SnowIncidentSLA;
import com.fedex.emea.sd.snow.objects.SnowIncidentWorkNote;
import com.fedex.emea.sd.snow.objects.SnowLocations;
import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.objects.SnowTestObjects;
import com.fedex.emea.sd.snow.objects.SnowUserGroups;
import com.fedex.emea.sd.snow.objects.SnowUsers;
import com.fedex.emea.sd.snow.utilities.SnowConstants;
import com.fedex.emea.sd.snow.utilities.DebugUtilities;
import com.fedex.emea.sd.snow.utilities.SnowUtilities;

@SuppressWarnings("unused")
public class SnowRequestorTester {
	
	private static SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.EPDSM_UAT_DIRECT);
	private static Calendar      cal           = Calendar.getInstance();
	
	public static void main(String[] args) {
		
		System.out.println("ServiceNow Requestor Tester...");
		
		// E-PDSM
		// ----------------------
//		createEpdsmIncident();
		//createEpdsmIncidentsForPriorityMatrix();
//		updateEpdsmIncident();
		
		
//		createIncidentsOLD();
		
//		createKingstonIncidents();
		// SAND :    INC4601316 - c198b5fedb0a1b00a548f7871d9619be
		// PROD :    INC4464991 - d5f3ab06dbbf83809bbfe2a94b961910
		// UAT  :    INC4645308 - d7c00a7adb469f008437fba61d96193d
		
//		createKingstonWorkNote("3c871550dbc69b80eab5f3541d9619e5");
		
//		createIncidentsForPriorityMatrix();
//		createKeyNote("7b99a1cadb719740eab5f3541d96198c");

		
//		updateExistingIncident("54adcb65dbe65748feea8edf4b9619b0", null);
//		updateExistingIncident(null, "INC4037909");
				
//		getIncidentBy();
//		getIncidentsList();
		getFullIncidentDetails("INC4304248");
		
//		getRecordFromTable();
		
//		getTableCount();
		
//		deleteIncidentBySysId("");
		
//		getCmdbCiServiceDetails("e195665425645400d216b5853d1bd302");
		
		System.out.println("End Process.");
		System.exit(0);

	}
	
	private static boolean isKingstonVersion(String sysId) throws Exception {
		boolean kingstonVersion = false;
		
		List<SnowIncidentWorkNote> workNotesList = new ArrayList<SnowIncidentWorkNote>();
		try {
			workNotesList   = snowRequestor.getWorkNotesByIncidentSysId(sysId);
		} catch (Exception e) {
			if (e.getMessage().contains("User Not Authorized")) {
				kingstonVersion = true;
			} else {
				throw e;
			}
		}
		
		return kingstonVersion;
	}
	
	private static void getCmdbCiServiceDetails(String sysId) {
		List<HashMap<String, Object>> listFieldsMap = new ArrayList<HashMap<String, Object>>();
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		String foreignSysId;
		String foreignName;
		
		try {
			SnowCmdbCiServices service = snowRequestor.getCmdbCiServiceBySysId(sysId, null);
			System.out.println("Name: " + service.getSnowName());
			
			foreignSysId = service.getSnowU_BusinessServiceOwner();
			foreignName  = snowRequestor.getUserBySysId(foreignSysId,"name").getSnowName();
			System.out.println("Business Owner (" + foreignSysId + "): " + foreignName);
			
			foreignSysId = service.getSnowU_ApplicationServiceOwner();
			foreignName  = snowRequestor.getUserBySysId(foreignSysId,"name").getSnowName();
			System.out.println("Application Owner (" + foreignSysId + "): " + foreignName);
			
			foreignSysId = service.getSnowSupportGroup();
			foreignName = snowRequestor.getUserGroupBySysId(foreignSysId,"name").getSnowName();
			System.out.println("Support Group (" + foreignSysId + "): " + foreignName);
			
			foreignSysId = service.getSnowU_2NdEscalationWorkgroup();
			foreignName = snowRequestor.getUserGroupBySysId(foreignSysId,"name").getSnowName();
			System.out.println("2nd Escalation Group (" + foreignSysId + "): " + foreignName);
			
			foreignSysId = service.getSnowU_3RdEscalationWorkgroup();
			foreignName = snowRequestor.getUserGroupBySysId(foreignSysId,"name").getSnowName();
			System.out.println("3rd Escalation Group (" + foreignSysId + "): " + foreignName);
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		
	}
	
	private static List<SnowIncidentMetrics> getListByFieldFromIncidentMetrics(List<SnowIncidentMetrics> metrics, String value) {
		List<SnowIncidentMetrics> newList = new ArrayList<SnowIncidentMetrics>();
		for (SnowIncidentMetrics metric: metrics) {
			if (metric.getSnowMdField().equals(value)) {
				newList.add(metric);
			}
		}
		
		Collections.sort(newList, new Comparator<SnowIncidentMetrics>() {
	        @Override
	        public int compare(SnowIncidentMetrics obj2, SnowIncidentMetrics obj1)
	        {
	        	Date date1 = SnowUtilities.formatToDateFromSNOW(obj1.getSnowMiStart());
	        	Date date2 = SnowUtilities.formatToDateFromSNOW(obj2.getSnowMiStart());
	            return  date2.compareTo(date1);
	        }
	    });
		
		return newList;
	}
	
	private static void getTableCount() {
		List<SnowSearchFilter> filters     = new ArrayList<SnowSearchFilter>();
		
		cal = Calendar.getInstance();
		int todayYYYY = cal.get(Calendar.YEAR);
		int todayMM   = cal.get(Calendar.MONTH);
		int todayDD   = cal.get(Calendar.DAY_OF_MONTH); 
		
		cal.clear();
		cal.set(2017, Calendar.OCTOBER, 1, 0, 0, 0);
		Date startSelfRange = new Date(cal.getTimeInMillis());
		
		cal.clear();
		cal.set(todayYYYY, todayMM, todayDD + 1, 0, 0, 0);
		Date endSelfRange = new Date(cal.getTimeInMillis());
		
		filters.add(new SnowSearchFilter("sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startSelfRange), SnowUtilities.formatDateForSNOW(endSelfRange)));
		filters.add(new SnowSearchFilter("u_folder",       SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
				
		try {
			System.out.println("Total SrvReq: "  + snowRequestor.getTableCount("incident", filters));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void getRecordFromTable() {
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		
		cal.clear();
		cal.set(2017, Calendar.NOVEMBER, 1, 0, 0, 0);
		Date startRange = new Date(cal.getTimeInMillis());
		
		cal.clear();
		cal.set(2017, Calendar.NOVEMBER, 12, 0, 0, 0);
		Date endRange = new Date(cal.getTimeInMillis());

//		filters.add(new SnowSearchFilter("sys_created_on",      SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startRange), SnowUtilities.formatDateForSNOW(endRange)));
//		filters.add(new SnowSearchFilter("scr_u_folder",        SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER));
//		filters.add(new SnowSearchFilter("u_folder",            SnowConstants.OPER_EQUAL, "fedex"));
//		filters.add(new SnowSearchFilter("active",              SnowConstants.OPER_EQUAL, "true"));
//		filters.add(new SnowSearchFilter("sys_id",              SnowConstants.OPER_EQUAL, "76919ced0a0aa0210192edb6dfb3f89f"));
//		filters.add(new SnowSearchFilter("closed_at",           SnowConstants.OPER_ISEMPTY, ""));
//		filters.add(new SnowSearchFilter("priority",            SnowConstants.OPER_EQUAL, "4"));
//		filters.add(new SnowSearchFilter("contact_type",        SnowConstants.OPER_EQUAL, SnowConstants.CONTACT_MEDIUM_WEB));
//		filters.add(new SnowSearchFilter("scr_number",          SnowConstants.OPER_EQUAL, "REQ3472214"));
//		filters.add(new SnowSearchFilter("inc_number",          SnowConstants.OPER_EQUAL, "INC4213916"));
//		filters.add(new SnowSearchFilter("sys_class_name",      SnowConstants.OPER_EQUAL, SnowConstants.SYS_CLASS_SRVREQ));
//		filters.add(new SnowSearchFilter("u_support_structure", SnowConstants.OPER_EQUAL, SnowConstants.GROUP_3));
//		filters.add(new SnowSearchFilter("category",            SnowConstants.OPER_IN,    "rfi,rfq"));
//		filters.add(new SnowSearchFilter("state",               SnowConstants.OPER_EQUAL, SnowConstants.STATE_RESOLVED_PENDING_MASTER));
//		filters.add(new SnowSearchFilter("state",               SnowConstants.OPER_DIFF,  SnowConstants.STATE_RESOLVED));
//		filters.add(new SnowSearchFilter("u_fedex_ldap_id",                SnowConstants.OPER_EQUAL, "363609"));
//		filters.add(new SnowSearchFilter("u_top50_application",   SnowConstants.OPER_EQUAL, "Yes"));
//		filters.add(new SnowSearchFilter("used_for",              SnowConstants.OPER_EQUAL, "Production"));
		filters.add(new SnowSearchFilter("name",                  SnowConstants.OPER_IN, "SKYMASTER,COMNEX,ENGIN,OSIRIS"));
		
		try {
//			List<HashMap<String,Object>> tableRecords = snowRequestor.getTableContent("incident", "number,state,sys_created_on,sys_created_by,u_business_service", filters);
			List<HashMap<String,Object>> tableRecords = snowRequestor.getTableContent("cmdb_ci_service", null, filters);
			for (HashMap<String,Object> record: tableRecords) {
				DebugUtilities.listAllFields(record);
//				System.out.println(record.get("number") + " - " + record.get("state") + " - " + record.get("sys_created_on") + " - " + record.get("sys_created_by") + " - " + record.get("u_business_service"));
			}
			System.out.println(tableRecords.size());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void getIncidentsByFilters() {
		List<SnowIncident>     incidentsList = new ArrayList<SnowIncident>();
		List<SnowSearchFilter> filters       = new ArrayList<SnowSearchFilter>();
		
		String officeSupportMembers = "305770,5123522,5106000,5106003,5106004,136700";
		
		cal.clear();
		cal.set(2018, Calendar.MAY, 1, 0, 0, 0);
		Date startRange = new Date(cal.getTimeInMillis());
		
		cal.clear();
		cal.set(2018, Calendar.MAY, 2, 23, 59, 59);
		Date endRange = new Date(cal.getTimeInMillis());

		filters.add(new SnowSearchFilter("sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(startRange), SnowUtilities.formatDateForSNOW(endRange)));
		filters.add(new SnowSearchFilter("u_folder",       SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
//		filters.add(new SnowSearchFilter("state",          SnowConstants.OPER_EQUAL, SnowConstants.STATE_RESOLVED));
		filters.add(new SnowSearchFilter("category",       SnowConstants.OPER_EQUAL, SnowConstants.CATEGORY_INCIDENT));
//		filters.add(new SnowSearchFilter("sys_created_by", SnowConstants.OPER_NOT_IN, officeSupportMembers));
		
		try {
			incidentsList = snowRequestor.getIncidentsByFilters(filters, "number,sys_created_on,opened_at,sla_due,u_actual_start,u_aof_date__time,u_pickup_duration,resolved_at,closed_at,u_time_to_close,business_duration,calendar_duration,state,u_business_service,u_support_structure,priority,sys_created_by");
		} catch (Exception e) {
			System.out.println(e.getMessage());;
		}
		
		System.out.println( 
				  "Number" + ","
				+ "SysCreated" + ","
				+ "Opened" + ","
				+ "SLA due" + ","
				+ "Act.Start" + ","
				+ "AOF Time" + ","
				+ "PU Duration" + ","
				+ "Resolved" + ","
				+ "Closed" + ","
				+ "Time to Close" + ","
				+ "Bus. Duration" + ","
				+ "Cal. Duration" + ","
				+ "Status" + ","
				+ "Business Service" + ","
				+ "Support Group" + ","
				+ "Priority" + ","
				+ "Created By"
				);
		
		for (int i = 0; i < incidentsList.size(); i++) {
			System.out.println( 
					  incidentsList.get(i).getSnowNumber() + ","
					+ incidentsList.get(i).getDtSnowSysCreatedOn() + ","
					+ incidentsList.get(i).getDtSnowOpenedAt() + ","
					+ incidentsList.get(i).getDtSnowSlaDue() + ","
					+ incidentsList.get(i).getDtSnowU_ActualStart() + ","
					+ incidentsList.get(i).getDtSnowU_AofDateTime() + ","
					+ SnowUtilities.formatDuration(incidentsList.get(i).getDtSnowU_PickupDuration()) + ","
					+ incidentsList.get(i).getDtSnowResolvedAt() + ","
					+ incidentsList.get(i).getDtSnowClosedAt() + ","
					+ SnowUtilities.formatDuration(incidentsList.get(i).getDtSnowU_TimeToClose()) + ","
					+ SnowUtilities.formatDuration(incidentsList.get(i).getDtSnowBusinessDuration()) + ","
					+ SnowUtilities.formatDuration(incidentsList.get(i).getDtSnowCalendarDuration()) + ","
					+ incidentsList.get(i).getSnowState() + ","
					+ incidentsList.get(i).getSnowU_BusinessService() + ","
					+ incidentsList.get(i).getSnowU_SupportStructure() + ","
					+ incidentsList.get(i).getSnowPriority() + ","
					+ incidentsList.get(i).getSnowSysCreatedBy()
					);
		}
		System.out.println("Total: " + incidentsList.size());
	}
	
	private static void getFullIncidentDetails(String incidentNumber) {
		SnowIncident               incident      = new SnowIncident();
		
		try {
			incident                          = snowRequestor.getIncidentByIncidentNbr(incidentNumber, null);
			DebugUtilities.listIncidentKeyFields(incident);
			
			System.out.println(new Date());
			
			System.out.println("Incident NUMBER: "      + incident.getSnowNumber());
			System.out.println("Incident State: "       + incident.getSnowState());
			System.out.println("Initial Assign: "       + snowRequestor.getUserGroupBySysId(incident.getSnowU_InitialAssignment(),"name").getSnowName());
			System.out.println("Assign. Group: "        + snowRequestor.getUserGroupBySysId(incident.getSnowAssignmentGroup(),"name").getSnowName());
			System.out.println("Assigned To: "          + snowRequestor.getUserBySysId(incident.getSnowAssignedTo(),"name").getSnowName());
			System.out.println("Company: "              + snowRequestor.getCompanyBySysId(incident.getSnowCompany(),"name").getSnowName());
			System.out.println("Location: "             + snowRequestor.getLocationBySysId(incident.getSnowLocation(),"name").getSnowName());
			System.out.println("Affected User: "        + snowRequestor.getUserBySysId(incident.getSnowU_AffectedUser(),"name").getSnowName());
			System.out.println("Created by Workgroup: " + snowRequestor.getUserGroupBySysId(incident.getSnowU_CreatedByWorkgroup(),"name").getSnowName());
			System.out.println("Business Service: "     + snowRequestor.getCmdbCiServiceBySysId(incident.getSnowU_BusinessService(),"name").getSnowName());
			System.out.println("CMDB Ci (" + incident.getSnowCmdbCi() + "): "              + snowRequestor.getCmdbCiBySysId(incident.getSnowCmdbCi(),"name").getSnowName());
			System.out.println("Sys Created by: "       + snowRequestor.getUserByLdapId(incident.getSnowSysCreatedBy(),"name").getSnowName());
			System.out.println("Opened by: "            + snowRequestor.getUserBySysId(incident.getSnowOpenedBy(),"name").getSnowName());
			System.out.println("Resolv by Workgroup: "  + snowRequestor.getUserGroupBySysId(incident.getSnowU_ResolvedByWorkgroup(),"name").getSnowName());
			System.out.println("Resolved by: "          + snowRequestor.getUserBySysId(incident.getSnowResolvedBy(),"name").getSnowName());
			System.out.println("Closed by: "            + snowRequestor.getUserBySysId(incident.getSnowClosedBy(),"name").getSnowName());
			System.out.println("Knowledge User: "       + snowRequestor.getUserBySysId(incident.getSnowU_KnowledgeUser(),"name").getSnowName());
			
			System.out.println(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void getIncidentBy() {
		SnowIncident               incident      = new SnowIncident();
		HashMap<String,Object>     hmIncident1   = new HashMap<String,Object>();
		
		try {
			incident                          = snowRequestor.getIncidentBySysId("54adcb65dbe65748feea8edf4b9619b0", null);
			DebugUtilities.listIncidentKeyFields(incident);
//			
//			incident                          = snowRequestor.getIncidentByIncidentNbr("INC4715302", null);
//			DebugUtilities.listIncidentKeyFields(incident);
						
//			hmIncident1 = snowRequestor.getIncidentHashMapByIncidentNbr("INC4766412", null);
//			DebugUtilities.listAllFields(hmIncident1);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void getIncidentsList() {
		List<SnowIncident>         incidentsList = new ArrayList<SnowIncident>();
		List<String> sysIdList = new ArrayList<String>();
		sysIdList.add("469656fddb373e00eab5f3541d961915");
		sysIdList.add("7b7616fddb373e00eab5f3541d96195a");
		sysIdList.add("6e7656fddb373e00eab5f3541d961935");
		
		try {
			incidentsList                     = snowRequestor.getIncidentsByListOfSysId(sysIdList);
			for (int i = 0; i < incidentsList.size(); i++) {
				DebugUtilities.listIncidentKeyFields(incidentsList.get(i));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	private static void createKeyNote(String incidentSysId) {
		List<SnowIncidentWorkNote> workNotesList = new ArrayList<SnowIncidentWorkNote>();
		SnowIncidentWorkNote       workNote      = new SnowIncidentWorkNote();
		try {
//			workNote        = snowRequestor.createWorkNote(SnowTestObjects.getNewWorkNoteForIncidentSysId(incidentSysId));
//			DebugUtilities.listWorkNoteKeyFields(workNote);
			
			workNotesList   = snowRequestor.getWorkNotesByIncidentSysId(incidentSysId);
			for (int i = 0; i < workNotesList.size(); i++) {
				DebugUtilities.listWorkNoteKeyFields(workNotesList.get(i));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void updateExistingIncident(String incdientSysId, String incdientNbr) {
		SnowIncident snowIncident        = new SnowIncident();
		SnowIncident updatedSnowIncident = new SnowIncident();
		
		try {
			if (incdientSysId != null) {
				snowIncident = snowRequestor.getIncidentBySysId(incdientSysId, null);
			} else {
				if (incdientNbr != null) {
					snowIncident = snowRequestor.getIncidentByIncidentNbr(incdientNbr, null);
				}
			}
			
			if (snowIncident == null) {
				System.out.println("Cannot find Incident # " + incdientNbr);
			} else {
				System.out.println("INC Number: "                + snowIncident.getSnowNumber());
				System.out.println("Current Short Description: " + snowIncident.getSnowShortDescription());
				System.out.println("Current Description: "       + snowIncident.getSnowDescription());
				System.out.println("Current Status: "            + snowIncident.getSnowState());
				System.out.println("Current Notes: "             + snowIncident.getSnowWorkNotes());
				
				snowIncident.setSnowCausedBy("Unknown Factor");
//				snowIncident.setSnowShortDescription("G1/TESTER/Updated Description");
//				snowIncident.setSnowDescription(snowIncident.getSnowDescription() + System.lineSeparator() + "State Change: Resolved");
//				snowIncident.setSnowState(SnowConstants.STATE_RESOLVED);
//				snowIncident.setSnowWorkNotes("Second Notes TEST");
//				snowIncident.setSnowU_ApplicationCode("UPDATED - TEST Application Code");
//				snowIncident.setSnowU_BatchStep("UPDATED - TEST Batch Step");
//				snowIncident.setSnowU_JobNumber("UPDATED - TEST Job Number");
//				snowIncident.setSnowU_Escalated("false");
//				snowIncident.setSnowAssignedTo("ed942e02db493200e8acb04ffe961997");		
//				snowIncident.setSnowSubcategory(Constants.SUB_CATEGORY_EVENT);
				
//				snowIncident.setSnowU_BusinessService("ee2c042edbc67240e8acb04ffe961978"); // APOLLO
//				snowIncident.setSnowPriority(Constants.PRIORITY_MINOR);
//				snowIncident.setSnowUrgency("");
//				snowIncident.setSnowImpact("");
//				snowIncident.setSnowU_Classification(Constants.CLASSIFICATION_NET_COMM);
//				snowIncident.setSnowU_Instructions("Alert Instruction");
//				snowIncident.setSnowU_ThirdPartyReference("UPDATED - TEST Third Party Reference");
//				snowIncident.setSnowU_Folder(Constants.U_FOLDER);

				updatedSnowIncident = snowRequestor.updateIncident(snowIncident.getSnowSysId(), snowIncident);
				
				System.out.println("INC Number: "            + updatedSnowIncident.getSnowNumber());
				System.out.println("New Short Description: " + updatedSnowIncident.getSnowShortDescription());
				System.out.println("New Description: "       + updatedSnowIncident.getSnowDescription());
				System.out.println("New Status: "            + updatedSnowIncident.getSnowState());
				System.out.println("New Notes: "             + updatedSnowIncident.getSnowWorkNotes());
				
			}
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		}
	}
	
	private static void updateEpdsmIncident() {
		String returnedSysId = null;
		SnowAstcIncident resultingIncident = null;
		SnowAstcIncident inputIncident = null;
		PrintWriter writer = null;
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());
		
		// Only fields containing values will be updated.
		// Work Note added IF field contains value => Comment out for no new Work Note
		try {	
			inputIncident = new SnowAstcIncident();
			inputIncident.setSnowU_State(SnowConstants.STATE_EPDSM_NEW);
			inputIncident.setSnowU_Impact(SnowConstants.IMPACT_EPDSM_3_SINGLE);
			inputIncident.setSnowU_Urgency(SnowConstants.URGENCY_EPDSM_3_NOCRIT);
			inputIncident.setSnowU_Service(SnowConstants.SERVICE_EPDSM_OTHER);
			inputIncident.setSnowU_Classification("TBD");
			inputIncident.setSnowU_BusinessService("436fd808db03634494ac1230399619fc"); // EU-ACME-Architecture
			inputIncident.setSnowU_AssignmentGroup("cca0f38713a513005b85be395144b05d");	// FXE_SDESK_EU
			inputIncident.setSnowU_Caller("92a585a513289300f920b6f36144b019");		// Fix value
			inputIncident.setSnowU_ShortDescription("ASTC END-TO-END TEST - Short Description - " + currentTime);			
			inputIncident.setSnowU_Number("INC010863205");
//			inputIncident.setSnowU_WorkNotes("LAST Note created on " + currentTime);
			
			StringBuilder incidentDescription2 = new StringBuilder();
			incidentDescription2.append("ASTC END-TO-END TEST Description - Impact: 3 - Urgency: 3");
			inputIncident.setSnowU_Description(incidentDescription2.toString());
			
			resultingIncident = snowRequestor.updateAstcIncident(inputIncident);
			returnedSysId = resultingIncident.getSnowSysTargetSysId();
			
			SnowIncident inc = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
			System.out.println("Staging SysId: " + resultingIncident.getSnowSysId());
			System.out.println("Incident NBR: " + inc.getSnowNumber() + " - " + inc.getSnowSysId());
			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void createEpdsmIncident() {
		String returnedSysId = null;
		SnowAstcIncident resultingIncident = null;
		SnowAstcIncident inputIncident = null;
		PrintWriter writer = null;
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());
		
		try {	
			inputIncident = new SnowAstcIncident();
			inputIncident.setSnowU_Category(SnowConstants.CATEGORY_EPDSM_APP);
			inputIncident.setSnowU_State(SnowConstants.STATE_EPDSM_NEW);
			inputIncident.setSnowU_Subcategory(SnowConstants.SUB_CATEGORY_EVENT);
			inputIncident.setSnowU_ContactType(SnowConstants.CONTACT_EPDSM_EVENT);
			inputIncident.setSnowU_Impact(SnowConstants.IMPACT_EPDSM_2_MULTI);
			inputIncident.setSnowU_Urgency(SnowConstants.URGENCY_EPDSM_2_CRIT_WA);
			inputIncident.setSnowU_Service(SnowConstants.SERVICE_EPDSM_OTHER);
			inputIncident.setSnowU_Classification("TBD");
			inputIncident.setSnowU_BusinessService("436fd808db03634494ac1230399619fc"); // EU-ACME-Architecture
			inputIncident.setSnowU_AssignmentGroup("cca0f38713a513005b85be395144b05d");	// FXE_SDESK_EU
			inputIncident.setSnowU_Caller("92a585a513289300f920b6f36144b019");		// Fix value
			inputIncident.setSnowU_ShortDescription("ASTC END-TO-END TEST - Short Description - " + currentTime);
			inputIncident.setSnowU_Instructions("Alert ASTC TEST Instructions on " + currentTime);
			
			inputIncident.setSnowU_WorkNotes("Initial Note (I=2, U=2) created on " + currentTime);
			
			StringBuilder incidentDescription2 = new StringBuilder();
			incidentDescription2.append("ASTC END-TO-END TEST Description - Impact: 2 - Urgency: 2");
			inputIncident.setSnowU_Description(incidentDescription2.toString());
			
			resultingIncident = snowRequestor.createAstcIncident(inputIncident);
			returnedSysId = resultingIncident.getSnowSysTargetSysId();
			
			SnowIncident inc = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
			System.out.println("Staging SysId: " + resultingIncident.getSnowSysId());
			System.out.println("Incident NBR: " + inc.getSnowNumber() + " - " + inc.getSnowSysId());
			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void createEpdsmIncidentsForPriorityMatrix() {
		String returnedSysId = null;
		SnowAstcIncident resultingIncident = null;
		SnowAstcIncident inputIncident = null;
		SnowIncident inc = null;
		PrintWriter writer = null;
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());

		try {	
			inputIncident = new SnowAstcIncident();
			inputIncident.setSnowU_Category(SnowConstants.CATEGORY_EPDSM_APP);
			inputIncident.setSnowU_State(SnowConstants.STATE_EPDSM_NEW);
			inputIncident.setSnowU_Subcategory(SnowConstants.SUB_CATEGORY_EVENT);
			inputIncident.setSnowU_ContactType(SnowConstants.CONTACT_EPDSM_EVENT);
			inputIncident.setSnowU_Service(SnowConstants.SERVICE_EPDSM_OTHER);
			inputIncident.setSnowU_Classification("TBD");
			inputIncident.setSnowU_BusinessService("436fd808db03634494ac1230399619fc"); // EU-ACME-Architecture
			inputIncident.setSnowU_AssignmentGroup("cca0f38713a513005b85be395144b05d");	// FXE_SDESK_EU
			inputIncident.setSnowU_Caller("92a585a513289300f920b6f36144b019");		// Fix value
			inputIncident.setSnowU_ShortDescription("ASTC END-TO-END TEST - Short Description - " + currentTime);
			inputIncident.setSnowU_Instructions("Alert ASTC TEST Instructions on " + currentTime);
			
			writer = new PrintWriter("C:\\Temp\\EPDSM_Priority-Matrix.txt", "ISO-8859-1");
			writer.println("ID, NBR, Impact Set, Impact, Urgency Set, Urgency, Priority");
			
			
			for (int i = 1; i < 4; i++) {
				for (int u = 1; u < 4; u++) {
					inputIncident.setSnowU_Impact(String.valueOf(i));
					inputIncident.setSnowU_Urgency(String.valueOf(u));
					
					StringBuilder incidentDescription2 = new StringBuilder();
					incidentDescription2.append("ASTC END-TO-END TEST Description - Impact: " + i + " - Urgency: " + u);
					inputIncident.setSnowU_Description(incidentDescription2.toString());
					
					inputIncident.setSnowU_WorkNotes("Initial Note (I=" + i + ", U=" + u + ") created on " + currentTime);
					
					resultingIncident = snowRequestor.createAstcIncident(inputIncident);
					
					returnedSysId = resultingIncident.getSnowSysTargetSysId();
					inc = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
					
					writer.println(inc.getSnowSysId() + "," 
							+ inc.getSnowNumber() + ","	
							+ i + "," + inc.getSnowImpact() + ","
							+ u + "," + inc.getSnowUrgency() + ","
							+ inc.getSnowPriority());
					System.out.println("Incident NBR: " + inc.getSnowNumber() + " - " + inc.getSnowSysId());
				}
			}
			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void createKingstonIncidents() {
		String returnedSysId = null;
		SnowIncident resultingIncident = null;
		SnowIncident inputIncident = null;
		PrintWriter writer = null;
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());
		
		try {	
			inputIncident = new SnowIncident();
			inputIncident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
			inputIncident.setSnowState(SnowConstants.STATE_REGISTERED);
			inputIncident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
			inputIncident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
			inputIncident.setSnowU_Classification(SnowConstants.CLASSIFICATION_APP_SOFT_OS);
			inputIncident.setSnowU_BusinessService("a27d14e6db8dcb80528cfbc61d961933"); // SLASH
			inputIncident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDX-SD-Helpdesk
			inputIncident.setSnowShortDescription("ASTC END-TO-END TEST - Short Description - " + currentTime);
			inputIncident.setSnowU_Instructions("Alert ASTC TEST Instructions on " + currentTime);
			inputIncident.setSnowImpact(SnowConstants.IMPACT_ONE);
			inputIncident.setSnowUrgency(SnowConstants.URGENCY_FOUR);
			
			inputIncident.setSnowWorkNotes("FIRST Note (I=" + inputIncident.getSnowImpact() + ", U=" + inputIncident.getSnowUrgency() + ") created on " + currentTime);
			
			StringBuilder incidentDescription2 = new StringBuilder();
			incidentDescription2.append("ASTC END-TO-END TEST Description - Impact: " + inputIncident.getSnowImpact() + " - Urgency: " + inputIncident.getSnowUrgency());
			inputIncident.setSnowDescription(incidentDescription2.toString());
			
			resultingIncident = snowRequestor.createIncident(inputIncident);
//			resultingIncident = snowRequestor.updateIncident("ccddcd58db469b80eab5f3541d961983", inputIncident);
			returnedSysId = resultingIncident.getSnowSysId();
			
			SnowIncident inc = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
			System.out.println("Incident NBR: " + inc.getSnowNumber() + " - " + inc.getSnowSysId());
			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void createKingstonWorkNote(String incidentSysId) {
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());
		
		SnowIncident resultingIncident = null;
		
		try {
			String workNoteText = "SECOND Note created on " + currentTime;
			resultingIncident = snowRequestor.createKingstonWorkNote(incidentSysId, workNoteText);
			System.out.println("Incident NBR: " + resultingIncident.getSnowNumber() + " - " + resultingIncident.getSnowSysId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static void createIncidentsOLD() {
		String returnedSysId = null;
		SnowIncident resultingIncident = null;
		SnowIncident inputIncident = null;
		PrintWriter writer = null;
		SimpleDateFormat dateFrmDdMmYy = new SimpleDateFormat("dd-MMM-yy HH:mm:ss");
		String currentTime = dateFrmDdMmYy.format(cal.getTime());
		
		try {	
			inputIncident = new SnowIncident();
			inputIncident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
			inputIncident.setSnowState(SnowConstants.STATE_REGISTERED);
			inputIncident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
			inputIncident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
			inputIncident.setSnowU_Classification("TBD");
			inputIncident.setSnowU_BusinessService("a27d14e6db8dcb80528cfbc61d961933"); // SLASH
			inputIncident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDXEX_EMEA_SD_HELPDESK
			inputIncident.setSnowShortDescription("ASTC END-TO-END TEST - Short Description - " + currentTime);
			inputIncident.setSnowU_Instructions("Alert ASTC TEST Instructions on " + currentTime);
			inputIncident.setSnowImpact(SnowConstants.IMPACT_ONE);
			inputIncident.setSnowUrgency(SnowConstants.URGENCY_FOUR);
			
			StringBuilder incidentDescription2 = new StringBuilder();
			incidentDescription2.append("ASTC END-TO-END TEST Description - Impact: 1 - Urgency: 4");
			inputIncident.setSnowDescription(incidentDescription2.toString());
			
			inputIncident.setSnowWorkNotes("Initial Work Note");
			
			resultingIncident = snowRequestor.createIncident(inputIncident);
//			resultingIncident = snowRequestor.updateIncident(inputIncident);
			returnedSysId = resultingIncident.getSnowSysId();
			
			SnowIncident inc = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
			System.out.println("SysId: " + resultingIncident.getSnowSysId());
			System.out.println("Incident NBR: " + inc.getSnowNumber() + " - " + inc.getSnowSysId());
			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void createIncidentsForPriorityMatrix() {
		SnowIncident resultingIncident = null;
		SnowIncident inputIncident = null;
		PrintWriter writer = null;
		
		try {
						
			// PRIORITY MATRIX EXTRACTION (Lot of Incidents !!)
			writer = new PrintWriter("C:\\Temp\\ServiceNow_Priority-Matrix.txt", "ISO-8859-1");
			writer.println("ID, NBR, Priority Set, Priority in SN, Impact Set, Impact in SN, Urgency Set, Urgency in SN, Severity Set, Severity in SN");
			int count = 1;
//			for (int p = 0; p < 5; p++) {
				for (int i = 4; i < 8; i++) {
					for (int u = 4; u < 8; u++) {
						for (int s = 0; s < 5; s++) {
							inputIncident = SnowTestObjects.getNewIncident();
							// Priority, Impact, Urgency, Severity
							inputIncident.setPrioritySetters(null, i==0?null:String.valueOf(i), u==0?null:String.valueOf(u), s==0?null:String.valueOf(s));
							resultingIncident = snowRequestor.createIncident(inputIncident);
							writer.println(resultingIncident.getSnowSysId() + "," 
									+ resultingIncident.getSnowNumber() + ","
									+ inputIncident.getSnowPriority() + "," + resultingIncident.getSnowPriority() + ","
									+ inputIncident.getSnowImpact()   + "," + resultingIncident.getSnowImpact() + ","
									+ inputIncident.getSnowUrgency()  + "," + resultingIncident.getSnowUrgency() + ","
									+ inputIncident.getSnowSeverity() + "," + resultingIncident.getSnowSeverity());
							System.out.println(count + " - " + resultingIncident.getSnowSysId() + "," 
									+ resultingIncident.getSnowNumber() + ","
									+ inputIncident.getSnowPriority() + "," + resultingIncident.getSnowPriority() + ","
									+ inputIncident.getSnowImpact()   + "," + resultingIncident.getSnowImpact() + ","
									+ inputIncident.getSnowUrgency()  + "," + resultingIncident.getSnowUrgency() + ","
									+ inputIncident.getSnowSeverity() + "," + resultingIncident.getSnowSeverity());
							count++;
						}
					}
				}
//			}			
		} catch (Exception ex) {
			System.out.println("ERROR: " + ex.getMessage());
		} finally {
			if (writer != null) writer.close();
		}
	}
	
	private static void deleteIncidentBySysId(String incidentSysId) {
		List<SnowIncident>         incidentsList = new ArrayList<SnowIncident>();
		
		try {
			incidentsList = snowRequestor.deleteIncidentBySysId(incidentSysId);
			
			for (int i = 0; i < incidentsList.size(); i++) {
				DebugUtilities.listIncidentKeyFields(incidentsList.get(i));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	
}
