package com.fedex.emea.dimm.adaptor;

import java.util.Date;

public class LogicalKeySeedEntry {

	private String logicalKeySeed;
	
	private Date lastCreateTime;

	public LogicalKeySeedEntry(String logicalKeySeed, Date lastCreateTime) {
		super();
		this.logicalKeySeed = logicalKeySeed;
		this.lastCreateTime = lastCreateTime;
	}

	public String getLogicalKeySeed() {
		return logicalKeySeed;
	}

	public Date getLastCreateTime() {
		return lastCreateTime;
	}
	
}
