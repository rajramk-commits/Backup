package com.fedex.emea.sd.da.exceptions;

public class ApplicationDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 4437905763626531499L;

	/**
	 * Method 'ApplicationDaoException'
	 * 
	 * @param message
	 */
	public ApplicationDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'ApplicationDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public ApplicationDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
