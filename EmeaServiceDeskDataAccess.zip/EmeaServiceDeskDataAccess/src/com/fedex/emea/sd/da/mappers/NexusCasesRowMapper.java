package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.NexusCases;

public final class NexusCasesRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		NexusCases nexusCase = new NexusCases();
		
		nexusCase.setCaseId(rs.getInt("CASE_ID"));
		nexusCase.setCaseBusinessUnit(rs.getString("BUSINESS_UNIT"));
		nexusCase.setCaseSummary(rs.getString("RC_SUMMARY"));
		nexusCase.setCaseSource(rs.getString("RC_SOURCE"));
		nexusCase.setCaseStatus(rs.getString("RC_STATUS"));
		nexusCase.setCasePriority(rs.getString("RC_PRIORITY"));
		nexusCase.setCaseSeverity(rs.getString("RC_SEVERITY"));
		nexusCase.setCaseDescription(rs.getString("RC_DESCRLONG"));
		
		return nexusCase;	
	}
}
