package com.fedex.emea.sabreReport.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Month;
import com.fedex.emea.sabreReport.model.SabreBean;

public class ReportDao {

	public static final String SELECT_HUBSTACKCCTICKETS = 	"select CASEID, CREATIONTIME,RECORDSOURCE,CASEDESCRIPTION1,CASETYPE,CASEPRIORITY,CASESTATUS " + 
			" from SDTOOL_SCHEMA.DIMMINTERFACE " + 
			" where RECORDSOURCE = 'DIMM:HUBSTACK_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' " + 
			" order by CREATIONTIME DESC";
	public static final String COUNT_HUBSTACKCCTICKETS  = 	"select count(*) from SDTOOL_SCHEMA.DIMMINTERFACE " + 
			" where RECORDSOURCE = 'DIMM:HUBSTACK_PROD_DASHBOARD' and CASETYPE = 'INCID' and CASEPRIORITY = 'HIGH' and RECORDSOURCE != 'ADD-NOTE' order by CREATIONTIME DESC";
	
	public static final String SELECT_TICKETDATA  = 	"select CASEID,CREATIONTIME,casedescription1,casedescription2,casestatus,casepriority from SDTOOL_SCHEMA.external_interface "
			+ " where casedescription1 like 'Type[ERROR]%' and CREATIONTIME > ? and CREATIONTIME < ? "
			+ " and CASESUMMARY not in ('Similar Alert received') and RECORDSOURCE = 'DIMM:HUBSTACK_PROD_DASHBOARD'"  
			+ " and (casedescription1 like '%SABRE%' OR casedescription1 like '%LSRE%' OR casedescription1 like '%SBR_%'"  
			+ " OR casedescription2 like '%SABRE%' OR casedescription3 like '%SABRE%' OR casedescription4 like '%SABRE%' OR casedescription5 like '%SABRE%')";
	
	public static final String SELECT_USERDATA  = "select USER_ROLE from sdtool_schema.eval_roles where user_id= ?";
	public static final String INSERT_USERDATA  = "insert into sdtool_schema.eval_roles(user_id, user_role, given_by) values (?, ?, ?)";
	public static final String UPDATE_USERDATA  = "update sdtool_schema.EVAL_ROLES Set User_Role = ? ,Given_by=? where USER_ID = ?";
	public static final String DELETE_USERDATA  = "Delete sdtool_schema.EVAL_ROLES where User_ID = ? ";
	
	public static final String FILESYSTEM_DATA  = "select CASEID,CREATIONTIME,casedescription1,casedescription2,casestatus,casepriority from SDTOOL_SCHEMA.external_interface "
			+ " where CREATIONTIME > ? and CREATIONTIME < ? "
			+ " and ( casedescription1 like '%SABRE%' OR casedescription2 like '%SABRE%' OR casedescription3 like '%SABRE%' OR casedescription4 like '%SABRE%' OR casedescription5 like '%SABRE%')"
			+ " and ( casedescription1 like '%Filesystem%' or casedescription2 like '%Filesystem%' )";
	
	public static final String SELECT_GSSTICKETDATA  = 	"select CASEID,CREATIONTIME,casedescription1,casedescription2,casestatus,casepriority from SDTOOL_SCHEMA.DIMMINTERFACE " + 
			" where CREATIONTIME > ? and CREATIONTIME < ? and casedescription1 like 'Type[ERROR]%' and recordsource ='HUBSTACK_PROD_DASHBOARD'" + 
			" and (casedescription1 like '%GSS%' OR casedescription2 like '%GSS%' OR casedescription3 like '%GSS%' )";
	public static final String SELECT_ITIHTICKETDATA  = 	"select CASEID,CREATIONTIME,casedescription1,casedescription2,casestatus,casepriority from SDTOOL_SCHEMA.dimminterface"
			+ " where CREATIONTIME > ? and CREATIONTIME < ? and recordsource='ITIH_PROD_DASHBOARD' order by creationtime";
	
	public static String getRole(String uID)
	{
		String role = null;
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(SELECT_USERDATA);
			pstm.setString(1,uID);
			rs=pstm.executeQuery();
			if (rs.next() ) {
				role = rs.getString(1);
			}
			System.out.println("getRole :"+role);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		
		return role;
	}
	
	public static String addUser(String uID, String role, String appName)
	{
		String status = null;
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(INSERT_USERDATA);
			pstm.setString(1, uID);
			pstm.setString(2, role);
			pstm.setString(3, appName);
			if(uID != null && !uID.trim().equals("") && role != null && !role.trim().equals(""))
			{
			int res = pstm.executeUpdate();
			if (res ==1)
				status = "User "+uID+" added successfully";
			}
			System.out.println("status :"+status);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return status;
	}
	public static String updateUser(String uID, String role, String appName)
	{
		String status = null;
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(UPDATE_USERDATA);
			pstm.setString(1, uID);
			pstm.setString(2, role);
			pstm.setString(3, appName);
			if(uID != null && !uID.trim().equals("") && role != null && !role.trim().equals(""))
			{
			int res = pstm.executeUpdate();
			if (res ==1)
				status = "User "+uID+" updated successfully";
			}
			else
			{
				status = uID+" already exist !!!";
			}
			System.out.println("status :"+status);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
			status = " Error while adding "+uID+"!!!";
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return status;
	}
	public static String deleteUser(String uID)
	{
		String status = null;
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(DELETE_USERDATA);
			pstm.setString(1, uID);
			if(uID != null && !uID.trim().equals(""))
			{
			int res = pstm.executeUpdate();
			if (res >=1)
				status = "User "+uID+" removed successfully";
			}
			else
			{
				status = uID+" doesn't exist to remove";
			}
			System.out.println("status :"+status);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return status;
	}
	
	public static int getCountHubstackCC()
	{
		int count = 0;
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery(COUNT_HUBSTACKCCTICKETS);
			if (rs.next() ) {
				count = rs.getInt(1);
			}
			System.out.println("getCountHubstackCC :"+count);
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return count;
	}
	
	@SuppressWarnings("resource")
	public static List<SabreBean> getData(String startDate, String endDate) throws Exception
	{
		System.out.println("startDate :"+startDate);
		System.out.println("endDate :"+endDate);
		List<SabreBean> sabreList = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(SELECT_TICKETDATA);
			
			String sm = startDate.substring(4,7);
			String em = endDate.substring(4,7);
			String sd = startDate.substring(8,10);
			String ed = endDate.substring(8,10);
			String sy = startDate.substring(13,15);
			String ey = endDate.substring(13,15);
			String formatedSDate = sd+"-"+sm+"-"+sy+" 12.00.00.000000000 AM";
			String formatedEDate = ed+"-"+em+"-"+ey+" 12.00.00.000000000 AM";
			System.out.println("formatedSDate :"+formatedSDate);
			System.out.println("formatedEDate :"+formatedEDate);
			pstm.setString(1,formatedSDate);
    		pstm.setString(2,formatedEDate);
			//rs = ConnectionUtil.getConnection().executeQuery(SELECT_TICKETDATA);
            rs=pstm.executeQuery();
            
            SabreBean bean;
            while(rs.next()){
            	bean = new SabreBean(rs.getString(1),rs.getString(2),rs.getString(3)+rs.getString(4),"","","");
            	
            	if(bean.getShortDescr().contains("JMS_QUEUE"))
            		bean.setAlertType("JMS Queue");
            	else if(bean.getShortDescr().contains("is STOPPED"))
            		bean.setAlertType("ProcessStopped");
            	else if(bean.getShortDescr().contains("DATABASE"))
            		bean.setAlertType("Database");
            	else if(bean.getShortDescr().contains("Filesystem"))
            		;
            	else
            		bean.setAlertType("Others");
            	
            	if(bean.getAlertType().equalsIgnoreCase("ProcessStopped"))
            	{
            	 if(bean.getShortDescr().contains("CDG"))
            		bean.setLocation("CDG");
            	else if(bean.getShortDescr().contains("STN"))
            		bean.setLocation("STN");
            	else if(bean.getShortDescr().contains("MXP"))
            		bean.setLocation("MXP");
            	else if(bean.getShortDescr().contains("DXB"))
            		bean.setLocation("DXB");
            	else if(bean.getShortDescr().contains("CPH"))
            		bean.setLocation("CPH");
            	else if(bean.getShortDescr().contains("CGN"))
            		bean.setLocation("CGN");
            	else if(bean.getShortDescr().contains("JPN"))
            		bean.setLocation("JPN");
            	else if(bean.getShortDescr().contains("WAW"))
            		bean.setLocation("WAW");
            	else
            		bean.setLocation("EMEA");
            	}
            	System.out.println("bean :"+bean);
            	sabreList.add(bean);
            }
            //pstm.close();
            pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(FILESYSTEM_DATA);
			pstm.setString(1,formatedSDate);
    		pstm.setString(2,formatedEDate);
    		rs=pstm.executeQuery();
    		while(rs.next()){
    			bean = new SabreBean(rs.getString(1),rs.getString(2),rs.getString(3)+rs.getString(4),"","","");
            	bean.setAlertType("FileSystem");
            	sabreList.add(bean);
    		}
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
			throw e1;
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return sabreList;
	}
	
	@SuppressWarnings("resource")
	public static List<SabreBean> getGSSData(String startDate, String endDate) throws Exception
	{
		List<SabreBean> sabreList = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(SELECT_GSSTICKETDATA);
			String sm= "",em= "",sd= "",ed= "",sy= "",ey = "";
			try
			{
			String smonth = startDate.substring(5,7);
			String emonth = endDate.substring(5,7);
			sm = Month.of(Integer.parseInt(smonth)).name().substring(0, 3);
			em = Month.of(Integer.parseInt(emonth)).name().substring(0, 3);
			sd = startDate.substring(8,10);
			ed = endDate.substring(8,10);
			sy = startDate.substring(2,4);
			ey = endDate.substring(2,4);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				sm = startDate.substring(4,7); em = endDate.substring(4,7);
				sd = startDate.substring(8,10); ed = endDate.substring(8,10);
				sy = startDate.substring(13,15); ey = endDate.substring(13,15);
			}
			String formatedSDate = sd+"-"+sm+"-"+sy+" 01.00.00.000000000 AM";
			String formatedEDate = ed+"-"+em+"-"+ey+" 12.59.59.000000000 PM";
			System.out.println("formatedSDate :"+formatedSDate);
			System.out.println("formatedEDate :"+formatedEDate);
			pstm.setString(1,formatedSDate);
    		pstm.setString(2,formatedEDate);
            rs=pstm.executeQuery();
            
            SabreBean bean;
            while(rs.next()){
            	String component="";
            	bean = new SabreBean(rs.getString(1),rs.getString(2),rs.getString(3)+rs.getString(4),"","","");
            	String desc = bean.getShortDescr();
            	Matcher m = Pattern.compile("Module\\[(.*?)\\]").matcher(desc);
            	while (m.find()) {
            		component = m.group(1);
            	    System.out.println("component :"+m.group(1));
            	}
            	if(component.contains(".GSS."))
            	{
            		bean.setAlertType("JMS_Queue");            		
            	}
            	else if(component.contains(".SABRE."))
            		continue;
            	else if(component.contains("no_response"))
            		bean.setAlertType("SystCdockLoad1_No_Response");
            	else if(component.contains("read_error"))
            		bean.setAlertType("SystCbackupReceive_Read_Error");
            	else
            		bean.setAlertType(component);
            	
            	if(desc.toLowerCase().contains("cgn"))
            		bean.setLocation("DE-CGN");
            	else if(desc.toLowerCase().contains("mxp"))
            		bean.setLocation("IT-MXP");
            	else if(desc.toLowerCase().contains("cph"))
            		bean.setLocation("DK-CPH");
            	else if(desc.toLowerCase().contains("cdg") || desc.toLowerCase().contains("brehat") || desc.toLowerCase().contains("ushant") )
            		bean.setLocation("FR-CDG");
            	else if(desc.toLowerCase().contains("dxb"))
            		bean.setLocation("AE-DXB");
            	else if(desc.toLowerCase().contains("stn"))
            		bean.setLocation("GB-STN");
            	else
            		bean.setLocation("EMEA");
            	
            	if(desc.contains("log.error"))
            		bean.setComments("ERROR_LOG");
            	sabreList.add(bean);
            }
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
			throw e1;
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return sabreList;
	}
	
	
	@SuppressWarnings("resource")
	public static List<SabreBean> getITIHData(String startDate, String endDate) throws Exception
	{
		List<SabreBean> sabreList = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			PreparedStatement pstm=ConnectionUtil.getConnection().getConnection().prepareStatement(SELECT_ITIHTICKETDATA);
			String sm= "",em= "",sd= "",ed= "",sy= "",ey = "";
			try
			{
			String smonth = startDate.substring(5,7);
			String emonth = endDate.substring(5,7);
			sm = Month.of(Integer.parseInt(smonth)).name().substring(0, 3);
			em = Month.of(Integer.parseInt(emonth)).name().substring(0, 3);
			sd = startDate.substring(8,10);
			ed = endDate.substring(8,10);
			sy = startDate.substring(2,4);
			ey = endDate.substring(2,4);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
				sm = startDate.substring(4,7); em = endDate.substring(4,7);
				sd = startDate.substring(8,10); ed = endDate.substring(8,10);
				sy = startDate.substring(13,15); ey = endDate.substring(13,15);
			}
			String formatedSDate = sd+"-"+sm+"-"+sy+" 12.00.00.000000000 AM";
			String formatedEDate = ed+"-"+em+"-"+ey+" 11.59.59.000000000 PM";
			System.out.println("formatedSDate :"+formatedSDate);
			System.out.println("formatedEDate :"+formatedEDate);
			pstm.setString(1,formatedSDate);
    		pstm.setString(2,formatedEDate);
            rs=pstm.executeQuery();
            
            SabreBean bean;
            while(rs.next()){
            	String component="";
            	bean = new SabreBean(rs.getString(1),rs.getString(2),rs.getString(3)+rs.getString(4),"","","");
            	String desc = bean.getShortDescr();
            	Matcher m = Pattern.compile("Module\\[(.*?)\\]").matcher(desc);
            	while (m.find()) {
            		component = m.group(1);
            	    System.out.println("component :"+m.group(1));
            	    bean.setAlertType(component);   
            	}
				
            	sabreList.add(bean);
            }
		} catch (ClassNotFoundException | SQLException e1) {
			e1.printStackTrace();
			throw e1;
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return sabreList;
	}
	
	
	public static void main(String[] args) throws Exception
	{
		String startDate = "Tue Sep 06 2021 12:00:00 GMT 0530 (India Standard Time)";
		String endDate = "Fri Sep 12 2021 11:59:59 GMT 0530 (India Standard Time)";
		List<SabreBean> sabreList = new ArrayList<>();
		sabreList = getITIHData(startDate, endDate);
		
		System.out.println(sabreList);
		System.out.println("**********************Alert Types**********************");
		for(int i=0;i<sabreList.size();i++)
		{
			System.out.println(sabreList.get(i).getAlertType());
		}
	}
}
