package com.fedex.emea.dimm.adaptor.direct;

import java.util.Map;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;

public class DirectAlertDomainAdaptorConfig extends AbstractAlertDomainAdaptorConfig{

	public DirectAlertDomainAdaptorConfig() throws Exception {
		super();
	}

	@Override
	protected void loadAdatorSpecificConfigFromProperties(
			Map<String, String> propertyMap) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected String getPropertyFileName() {
		return "DirectAlertDomainAdaptorConfig.properties";
	}

}
