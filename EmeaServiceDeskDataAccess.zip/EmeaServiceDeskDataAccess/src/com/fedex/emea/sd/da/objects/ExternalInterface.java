package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;

import com.fedex.emea.sd.da.helpers.Utilities;

public class ExternalInterface implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private long      alertId;
	private String    recordSource;
	private String    recordSourceId;
	private byte[]    nexusCase;
	private String    caseOriginPin;
	private String    caseLocation;
	private String    caseBusinessUnit;
	private String    caseOwnership;
	private String    caseSummary;
	private String    caseDescription1;
	private String    caseDescription2;
	private String    caseDescription3;
	private String    caseDescription4;
	private String    caseDescription5;
	private String    caseDescription6;
	private String    caseDescription7;
	private String    caseDescription8;
	private String    caseDescription9;
	private String    casePriority;
	private String    caseType;
	private String    caseSeverity;
	private String    caseSource;
	private String    caseProviderGroup;
	private String    caseStatus;
	private String    caseFdxNode;
	private String    caseFdxVendor;
	private String    caseFdxVendorId;
	private String    caseFdxSystem;
	private String    caseFdxApplication;
	private String    caseCategory;
	private String    caseCallType;
	private String    caseProblemType;
	private String    caseProblemDetail;
	private String    caseProblemDescription;
	private String    caseAssignedTo;
	private String    caseSolution;
	private int       alertProcessed;
	private Timestamp creationTime;
	private Timestamp processedTime;
	private String    caseId;
	private long      sameCaseInterval;
	private String    logicalKey;
	private String    caseSysId;
	
	public ExternalInterface() {
	}
	
	public ExternalInterface(OvoObject ovoMessage, SupportTicketClassification supportTicketClassificator) {
		// Fixed Values
		this.setRecordSourceId(ovoMessage.getMessageID().trim());
		this.setNexusCase(null);
		this.setCaseLocation(null);
		this.setCaseOriginPin("");
		this.setCaseSeverity("USCHD");
		this.setCaseSource("AUTO");
		this.setCaseOwnership(null);
		this.setCaseProblemDescription(null);
		this.setCaseFdxNode(null);
		this.setCaseFdxVendor(null);
		this.setCaseFdxVendorId(null);
		this.setCaseFdxSystem(null);
		this.setCaseFdxApplication(null);
		this.setCaseAssignedTo(null);
		this.setCaseSolution("0");
		this.setAlertProcessed(0);
		this.setCreationTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		this.setProcessedTime(null);
		
		// Logic dependent Values
		//
		this.setCaseBusinessUnit(supportTicketClassificator.getCaseBusinessUnit());
		this.setCaseCategory(supportTicketClassificator.getCaseArea());
		this.setCaseCallType(supportTicketClassificator.getCaseService());
		this.setCaseProblemType(supportTicketClassificator.getCaseComponent());
		this.setCaseProblemDetail(supportTicketClassificator.getCaseFunction());
		this.setCaseProviderGroup(supportTicketClassificator.getCaseProviderGroup());
		this.setCaseStatus(supportTicketClassificator.getCaseStatus());
		this.setCasePriority(supportTicketClassificator.getCasePriority());
		
		String fullDescription = ovoMessage.getAlertDescription() + supportTicketClassificator.getCaseDescription();
		
		this.setFullDescription(fullDescription);
		
		this.setRecordSource(supportTicketClassificator.getCaseSource());
		this.setCaseSummary(supportTicketClassificator.getCaseSummary());
		this.setCaseId(supportTicketClassificator.getCaseId());
		this.setSameCaseInterval(supportTicketClassificator.getIntervalForSimilar());
		this.setCaseSysId(supportTicketClassificator.getCaseSysId());
		this.setCaseType(supportTicketClassificator.getCaseType());
	}
	
	public ExternalInterface(OvoObject ovoMessage, HashMap<String, String> ticketClassification) {
		// Fixed Values
		this.setRecordSourceId(ovoMessage.getMessageID().trim());
		this.setNexusCase(null);
		this.setCaseBusinessUnit("SDESK");
		this.setCaseLocation(null);
		this.setCaseOriginPin("");
		this.setCaseSeverity("USCHD");
		this.setCaseSource("AUTO");
		this.setCaseOwnership(null);
		this.setCaseProblemDescription(null);
		this.setCaseFdxNode(null);
		this.setCaseFdxVendor(null);
		this.setCaseFdxVendorId(null);
		this.setCaseFdxSystem(null);
		this.setCaseFdxApplication(null);
		this.setCaseAssignedTo(null);
		this.setCaseSolution("0");
		this.setAlertProcessed(0);
		this.setCreationTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		this.setProcessedTime(null);
		
		// Logic dependent Values
		// Keys: AREA, SERVICE, COMPONENT, FUNCTION, DESCRIPTION, PRIORITY, STATUS, PROVIDER
		//       SOURCE, SUMMARY, CASEID, INTERVAL, TYPE
		this.setCaseCategory(ticketClassification.get("AREA"));
		this.setCaseCallType(ticketClassification.get("SERVICE"));
		this.setCaseProblemType(ticketClassification.get("COMPONENT"));
		this.setCaseProblemDetail(ticketClassification.get("FUNCTION"));
		this.setCaseProviderGroup(ticketClassification.get("PROVIDER"));
		this.setCaseStatus(ticketClassification.get("STATUS"));
		this.setCasePriority(ticketClassification.get("PRIORITY"));
		
		String fullDescription = ovoMessage.getAlertDescription() + ticketClassification.get("DESCRIPTION");
		
		this.setFullDescription(fullDescription);
		
		this.setRecordSource(ticketClassification.get("SOURCE"));
		this.setCaseSummary(ticketClassification.get("SUMMARY"));
		this.setCaseId(ticketClassification.get("CASEID"));
		this.setSameCaseInterval(Long.parseLong(ticketClassification.get("INTERVAL")));
		this.setCaseType(ticketClassification.get("TYPE"));
	}
	
	public ExternalInterface(long alertId, String recordSource, String recordSourceId, byte[] nexusCase, String caseOriginPin, String caseLocation, String caseBusinessUnit, String caseOwnership, String caseSummary, String caseDescription1, String caseDescription2, String caseDescription3, String caseDescription4, String caseDescription5, String caseDescription6, String caseDescription7, String caseDescription8, String caseDescription9, String casePriority, String caseType, String caseSeverity, String caseSource, String caseProviderGroup, String caseStatus, String caseFdxNode, String caseFdxVendor, String caseFdxVendorId, String caseFdxSystem, String caseFdxApplication, String caseCategory, String caseCallType, String caseProblemType, String caseProblemDetail, String caseProblemDescription, String caseAssignedTo, String caseSolution, int alertProcessed, Timestamp processedTime, Timestamp creationTime) {
		this.alertId = alertId;
		this.recordSource = recordSource;
		this.recordSourceId = recordSourceId;
		this.nexusCase = nexusCase;
		this.caseOriginPin = caseOriginPin;
		this.caseLocation = caseLocation;
		this.caseBusinessUnit = caseBusinessUnit;
		this.caseOwnership = caseOwnership;
		this.caseSummary = caseSummary;
		this.caseDescription1 = caseDescription1;
		this.caseDescription2 = caseDescription2;
		this.caseDescription3 = caseDescription3;
		this.caseDescription4 = caseDescription4;
		this.caseDescription5 = caseDescription5;
		this.caseDescription6 = caseDescription6;
		this.caseDescription7 = caseDescription7;
		this.caseDescription8 = caseDescription8;
		this.caseDescription9 = caseDescription9;
		this.casePriority = casePriority;
		this.caseType = caseType;
		this.caseSeverity = caseSeverity;
		this.caseSource = caseSource;
		this.caseProviderGroup = caseProviderGroup;
		this.caseStatus = caseStatus;
		this.caseFdxNode = caseFdxNode;
		this.caseFdxVendor = caseFdxVendor;
		this.caseFdxVendorId = caseFdxVendorId;
		this.caseFdxSystem = caseFdxSystem;
		this.caseFdxApplication = caseFdxApplication;
		this.caseCategory = caseCategory;
		this.caseCallType = caseCallType;
		this.caseProblemType = caseProblemType;
		this.caseProblemDetail = caseProblemDetail;
		this.caseProblemDescription = caseProblemDescription;
		this.caseAssignedTo = caseAssignedTo;
		this.caseSolution = caseSolution;
		this.alertProcessed = alertProcessed;
		this.processedTime = processedTime;
		this.creationTime = creationTime;
	}
	
	public ExternalInterface(ExternalInterface ni) {
		this.alertId = ni.getAlertId();
		this.recordSource = ni.getRecordSource();
		this.recordSourceId = ni.getRecordSourceId();
		this.nexusCase = ni.getNexusCase();
		this.caseOriginPin = ni.getCaseOriginPin();
		this.caseLocation = ni.getCaseLocation();
		this.caseBusinessUnit = ni.getCaseBusinessUnit();
		this.caseOwnership = ni.getCaseOwnership();
		this.caseSummary = ni.getCaseSummary();
		this.caseDescription1 = ni.getCaseDescription1();
		this.caseDescription2 = ni.getCaseDescription2();
		this.caseDescription3 = ni.getCaseDescription3();
		this.caseDescription4 = ni.getCaseDescription4();
		this.caseDescription5 = ni.getCaseDescription5();
		this.caseDescription6 = ni.getCaseDescription6();
		this.caseDescription7 = ni.getCaseDescription7();
		this.caseDescription8 = ni.getCaseDescription8();
		this.caseDescription9 = ni.getCaseDescription9();
		this.casePriority = ni.getCasePriority();
		this.caseType = ni.getCaseType();
		this.caseSeverity = ni.getCaseSeverity();
		this.caseSource = ni.getCaseSource();
		this.caseProviderGroup = ni.getCaseProviderGroup();
		this.caseStatus = ni.getCaseStatus();
		this.caseFdxNode = ni.getCaseFdxNode();
		this.caseFdxVendor = ni.getCaseFdxVendor();
		this.caseFdxVendorId = ni.getCaseFdxVendorId();
		this.caseFdxSystem = ni.getCaseFdxSystem();
		this.caseFdxApplication = ni.getCaseFdxApplication();
		this.caseCategory = ni.getCaseCategory();
		this.caseCallType = ni.getCaseCallType();
		this.caseProblemType = ni.getCaseProblemType();
		this.caseProblemDetail = ni.getCaseProblemDetail();
		this.caseProblemDescription = ni.getCaseProblemDescription();
		this.caseAssignedTo = ni.getCaseAssignedTo();
		this.caseSolution = ni.getCaseSolution();
		this.alertProcessed = ni.getAlertProcessed();
		this.processedTime = ni.getProcessedTime();
		this.creationTime = ni.getCreationTime();
	}
				
	public StringBuilder getCaseDescription() {
		StringBuilder caseDescription = new StringBuilder();
		
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription1()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription2()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription3()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription4()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription5()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription6()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription7()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription8()));
		caseDescription.append(Utilities.nullToEmptyString(getCaseDescription9()));
		
		return caseDescription;
	}
	
	public void setFullDescription(String fullDescription) {
		this.setCaseDescription1(Utilities.getSubstring(fullDescription, 0, 255));
		this.setCaseDescription2(Utilities.getSubstring(fullDescription, 255, 510));
		this.setCaseDescription3(Utilities.getSubstring(fullDescription, 510, 765));
		this.setCaseDescription4(Utilities.getSubstring(fullDescription, 765, 1020));
		this.setCaseDescription5(Utilities.getSubstring(fullDescription, 1020, 1275));
		this.setCaseDescription6(Utilities.getSubstring(fullDescription, 1275, 1530));
		this.setCaseDescription7(Utilities.getSubstring(fullDescription, 1530, 1785));
		this.setCaseDescription8(Utilities.getSubstring(fullDescription, 1785, 2040));
		this.setCaseDescription9(Utilities.getSubstring(fullDescription, 2040, 2295));
	}

	public String getCaseBusinessUnit() {
		return caseBusinessUnit;
	}

	public void setCaseBusinessUnit(String caseBusinessUnit) {
		this.caseBusinessUnit = caseBusinessUnit;
	}
	
	public String getCaseOwnership() {
		return caseOwnership;
	}

	public void setCaseOwnership(String caseOwnership) {
		this.caseOwnership = caseOwnership;
	}

	public String getCaseSummary() {
		return caseSummary;
	}

	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}

	public String getCaseDescription1() {
		return caseDescription1;
	}

	public void setCaseDescription1(String caseDescription1) {
		this.caseDescription1 = caseDescription1;
	}

	public String getCasePriority() {
		return casePriority;
	}

	public void setCasePriority(String casePriority) {
		this.casePriority = casePriority;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getCaseSeverity() {
		return caseSeverity;
	}

	public void setCaseSeverity(String caseSeverity) {
		this.caseSeverity = caseSeverity;
	}

	public String getCaseSource() {
		return caseSource;
	}

	public void setCaseSource(String caseSource) {
		this.caseSource = caseSource;
	}

	public String getCaseProviderGroup() {
		return caseProviderGroup;
	}

	public void setCaseProviderGroup(String caseProviderGroup) {
		this.caseProviderGroup = caseProviderGroup;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getCaseFdxNode() {
		return caseFdxNode;
	}

	public void setCaseFdxNode(String caseFdxNode) {
		this.caseFdxNode = caseFdxNode;
	}

	public String getCaseFdxVendor() {
		return caseFdxVendor;
	}

	public void setCaseFdxVendor(String caseFdxVendor) {
		this.caseFdxVendor = caseFdxVendor;
	}

	public String getCaseFdxVendorId() {
		return caseFdxVendorId;
	}

	public void setCaseFdxVendorId(String caseFdxVendorId) {
		this.caseFdxVendorId = caseFdxVendorId;
	}

	public String getCaseFdxSystem() {
		return caseFdxSystem;
	}

	public void setCaseFdxSystem(String caseFdxSystem) {
		this.caseFdxSystem = caseFdxSystem;
	}

	public String getCaseFdxApplication() {
		return caseFdxApplication;
	}

	public void setCaseFdxApplication(String caseFdxApplication) {
		this.caseFdxApplication = caseFdxApplication;
	}

	public String getCaseCategory() {
		return caseCategory;
	}

	public void setCaseCategory(String caseCategory) {
		this.caseCategory = caseCategory;
	}

	public String getCaseCallType() {
		return caseCallType;
	}

	public void setCaseCallType(String caseCallType) {
		this.caseCallType = caseCallType;
	}

	public String getCaseProblemType() {
		return caseProblemType;
	}

	public void setCaseProblemType(String caseProblemType) {
		this.caseProblemType = caseProblemType;
	}

	public String getCaseProblemDetail() {
		return caseProblemDetail;
	}

	public void setCaseProblemDetail(String caseProblemDetail) {
		this.caseProblemDetail = caseProblemDetail;
	}

	public String getCaseProblemDescription() {
		return caseProblemDescription;
	}

	public void setCaseProblemDescription(String caseProblemDescription) {
		this.caseProblemDescription = caseProblemDescription;
	}

	public String getCaseAssignedTo() {
		return caseAssignedTo;
	}

	public void setCaseAssignedTo(String caseAssignedTo) {
		this.caseAssignedTo = caseAssignedTo;
	}

	public String getCaseSolution() {
		return caseSolution;
	}

	public void setCaseSolution(String caseSolution) {
		this.caseSolution = caseSolution;
	}

	public String getCaseOriginPin() {
		return caseOriginPin;
	}

	public void setCaseOriginPin(String caseOriginPin) {
		this.caseOriginPin = caseOriginPin;
	}

	public String getCaseLocation() {
		return caseLocation;
	}

	public void setCaseLocation(String caseLocation) {
		this.caseLocation = caseLocation;
	}

	public long getAlertId() {
		return alertId;
	}

	public void setAlertId(long alertId) {
		this.alertId = alertId;
	}

	public byte[] getNexusCase() {
		return nexusCase;
	}
	
	public void setNexusCase(byte[] nexusCase) {
		this.nexusCase = nexusCase;
	}

	public int getAlertProcessed() {
		return alertProcessed;
	}

	public void setAlertProcessed(int alertProcessed) {
		this.alertProcessed = alertProcessed;
	}

	public Timestamp getProcessedTime() {
		return processedTime;
	}

	public void setProcessedTime(Timestamp processedTime) {
		this.processedTime = processedTime;
	}

	public String getCaseDescription2() {
		return caseDescription2;
	}

	public void setCaseDescription2(String caseDescription2) {
		this.caseDescription2 = caseDescription2;
	}

	public String getCaseDescription3() {
		return caseDescription3;
	}

	public void setCaseDescription3(String caseDescription3) {
		this.caseDescription3 = caseDescription3;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getRecordSource() {
		return recordSource;
	}

	public void setRecordSource(String recordSource) {
		this.recordSource = recordSource;
	}

	public String getCaseDescription4() {
		return caseDescription4;
	}

	public void setCaseDescription4(String caseDescription4) {
		this.caseDescription4 = caseDescription4;
	}

	public String getCaseDescription5() {
		return caseDescription5;
	}

	public void setCaseDescription5(String caseDescription5) {
		this.caseDescription5 = caseDescription5;
	}

	public String getCaseDescription6() {
		return caseDescription6;
	}

	public void setCaseDescription6(String caseDescription6) {
		this.caseDescription6 = caseDescription6;
	}

	public String getCaseDescription7() {
		return caseDescription7;
	}

	public void setCaseDescription7(String caseDescription7) {
		this.caseDescription7 = caseDescription7;
	}

	public String getCaseDescription8() {
		return caseDescription8;
	}

	public void setCaseDescription8(String caseDescription8) {
		this.caseDescription8 = caseDescription8;
	}

	public String getCaseDescription9() {
		return caseDescription9;
	}

	public void setCaseDescription9(String caseDescription9) {
		this.caseDescription9 = caseDescription9;
	}

	public String getRecordSourceId() {
		return recordSourceId;
	}

	public void setRecordSourceId(String recordSourceId) {
		this.recordSourceId = recordSourceId;
	}

	public Timestamp getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}

	public long getSameCaseInterval() {
		return sameCaseInterval;
	}

	public void setSameCaseInterval(long sameCaseInterval) {
		this.sameCaseInterval = sameCaseInterval;
	}

	public String getLogicalKey() {
		return logicalKey;
	}

	public void setLogicalKey(String logicalKey) {
		this.logicalKey = logicalKey;
	}

	public String getCaseSysId() {
		return caseSysId;
	}

	public void setCaseSysId(String caseSysId) {
		this.caseSysId = caseSysId;
	}
}
