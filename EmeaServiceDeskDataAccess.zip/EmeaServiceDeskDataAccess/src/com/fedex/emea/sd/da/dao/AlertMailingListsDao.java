package com.fedex.emea.sd.da.dao;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.AlertMailingLists;

public interface AlertMailingListsDao {
	public AlertMailingLists createValueObject();
	public AlertMailingLists getObject(String alertSource, String userMail) throws SQLException;
	public List<String> getMailsByAlertSource(String alertSource) throws SQLException;
	public List<AlertMailingLists> loadAll() throws SQLException;
	public List<AlertMailingLists> loadByAlertSource(String alertSource) throws SQLException;
	public void create(AlertMailingLists valueObject) throws SQLException, DataAccessException, IOException;
	public void deleteByPK(AlertMailingLists valueObject);
	public void deleteByPin(String userPin);
	public void deleteAll() throws SQLException;
	public int countAll() throws SQLException;
}

