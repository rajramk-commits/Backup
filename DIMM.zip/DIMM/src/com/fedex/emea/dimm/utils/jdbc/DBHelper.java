package com.fedex.emea.dimm.utils.jdbc;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fedex.emea.dimm.log.LogFactory;

/**
 * database helper class
 * @author 651125
 *
 */
public class DBHelper {

	/**
	 * model the parameters set used for PreparedStatement 
	 * @author 651125
	 *
	 */
	public static class ParameterSet{
		private ArrayList params = new ArrayList(); 
		public ParameterSet(){}
		public void addParameter(Object parameter){
		     params.add(parameter);
		}
		public void addParameter(int idx,Object parameter){
			params.add(idx, parameter);
		}
		public void addParameters(Collection parameters){
			params.addAll(parameters);
		}
		public Object getParameter(int idx){
			return params.get(idx);
		}
		public int size(){
			return params.size();
		}
	}
	
	/**
	 * model the database query
	 * @author 651125
	 *
	 */
	public static class Query{
		//the sql of this query, it may take the '?' as the placeholder of the parameter
		private String sql = null;
		//the list of the parameterSet instances, each instance is a set of parameters. When more than one parameter set is provided
		//the 'batch' mode should be used to execute the query 
		private ArrayList parameterSetList = new ArrayList();
        
		public Query(String sql){
			this.sql = sql;
		}
		
		//get the number of the parameter sets
		public int getParameterSetNumber(){
			return parameterSetList.size();
		}
		//get one parameter set
		public ParameterSet getParameterSet(int idx){
			return (ParameterSet)parameterSetList.get(idx);
		}
		public void addParameterSet(ParameterSet parameterSet){
			if(parameterSet!=null)
				parameterSetList.add(parameterSet);
		}
		public void clearParameterSet(){
			if(parameterSetList != null)
				parameterSetList.clear();
		}
		public String getSql() {
			return sql;
		}
	    	
	}
	
	/**
	 * This method accepts the SQL type and returns the 
	 * corresponding Class Type.
	 */
	private static Class getSQLEqivalentClassType(int sqlColType){
		if (sqlColType == Types.DATE)
			return java.sql.Timestamp.class;
		else if (sqlColType == Types.TIMESTAMP)
			return java.sql.Timestamp.class;
		else if (sqlColType == Types.INTEGER || sqlColType == Types.NUMERIC)
			return long.class;
		else if (sqlColType == Types.FLOAT)
			return float.class;
		else
			return java.lang.String.class;
	}
	
	/**
	 * according to the sql exception, check whether that's the serious database problem
	 * @param exception
	 */
	private static boolean isSeriousDBProblem(SQLException exception){
		String exceptionMsg = exception.getMessage();
		String causeMsg = "";
		Throwable exceptionCause = exception.getCause();
		if(exceptionCause!=null)
			causeMsg = exceptionCause.getMessage();
		if(exceptionMsg.indexOf("ORA-00107")>=0 || causeMsg.indexOf("ORA-00107")>=0){
			return true;//ORA-00107: failed to connect to ORACLE listener process
		}else if(exceptionMsg.indexOf("ORA-06744")>=0 || causeMsg.indexOf("ORA-06744")>=0){
			return true;//ORA-06744: TLI Driver: listener cannot bind
		}else if(exceptionMsg.indexOf("ORA-12203")>=0 || causeMsg.indexOf("ORA-12203")>=0){
			return true;//ORA-12203: TNS:unable to connect to destination
		}else if(exceptionMsg.indexOf("ORA-12224")>=0 || causeMsg.indexOf("ORA-12224")>=0){
			return true;//ORA-12224: TNS:no listener
		}else if(exceptionMsg.indexOf("ORA-12225")>=0 || causeMsg.indexOf("ORA-12225")>=0){
			return true;//ORA-12225: TNS:destination host unreachable
		}else if(exceptionMsg.indexOf("ORA-12510")>=0 || causeMsg.indexOf("ORA-12510")>=0){
			return true;//ORA-12510: TNS:database temporarily lacks resources to handle the request
		}else if(exceptionMsg.indexOf("ORA-12511")>=0 || causeMsg.indexOf("ORA-12511")>=0){
			return true;//ORA-12511: TNS:service handler found but it is not accepting connections
		}else if(exceptionMsg.indexOf("ORA-01033")>=0 || causeMsg.indexOf("ORA-01033")>=0){
			return true;//ORA-01033: ORACLE initialization or shutdown in progress
		}else if(exceptionMsg.indexOf("ORA-01034")>=0 || causeMsg.indexOf("ORA-01034")>=0){
			return true;//ORA-01034: ORACLE not available
		}
		return false;	
	}
	
	public static ArrayList executeQuery(Query query,DBConfig dbConfig,Class valueObjectClass) throws Exception{
		ArrayList result = new ArrayList();
		Connection con = null;
		try{
			con = DBConnectionFactory.getInstance().getConnection(dbConfig);
			result = executeQueryOnce(query,dbConfig.getJdbcURL(),valueObjectClass,con);
		}catch(Exception exception){
			LogFactory.getLogger().logFatal("Error while fetching data from Database. Error message is -" + exception.getMessage());
			throw exception;
		}finally{
			// release the connection
			DBConnectionFactory.getInstance().releaseConnection(con);
		}
		return result;
	}
	
	/**
	 * execute the query and return the resultset
	 * @param query
	 * @param jdbcURL the JDBC URL of the target database where the connection points to
	 * @param valueObjClass - optional, if it is set, will try to fill in the value object using the reflection, the returned array list is a list of value objects
	 * if it is not set, the returned arraylist is a 2 dimension array storage, the first dim is the row of the data, the second dim is the column of the data
	 * @param connection  
	 * @return
	 * @throws SQLException
	 */
	private static ArrayList executeQueryOnce(Query query,String jdbcURL,Class valueObjectClass,Connection connection) throws Exception{
		ArrayList result = new ArrayList();
		Calendar oCal = Calendar.getInstance();
		if(query!=null){
			String sql = query.getSql();
			LogFactory.getLogger().logDebug("Executing SQL :: " + sql);
			int parameterSetNumber = query.getParameterSetNumber();
			PreparedStatement statement = null;
			ResultSet rSet = null;
		    try{
				statement = connection.prepareStatement(sql);
				//the count of the parameter
				//Oracle's driver doesn't implement the getParameterMetaData() interface, we only can evaluate the count of '?' in the sql
				//int parameterCount = statement.getParameterMetaData().getParameterCount();
				//build the regular expression patttern
				Pattern pattern = Pattern.compile("\\?",Pattern.CASE_INSENSITIVE);
				//build the matcher with the pattern created and the target string
				Matcher matcher = pattern.matcher(sql);
				//count the matches
				int parameterCount = 0;
				while(matcher.find()){
					parameterCount++;
				}
				for(int i=0;i<parameterSetNumber;i++){
					ParameterSet parameterSet = query.getParameterSet(i);
					if(parameterCount!=parameterSet.size()){
						LogFactory.getLogger().logError("Number "+i+" parameter set for the query ["+sql+"] is invalid, expected parameter count is "+parameterCount+" but the real parameter count is "+parameterSet.size());
					}
					for(int j=0;j<parameterSet.size();j++){
						Object parameter = parameterSet.getParameter(j);
						if (parameter instanceof Integer){
							statement.setInt(j+1, ((Integer)parameter).intValue());
						} else if (parameter instanceof Long){
							statement.setLong(j+1, ((Long)parameter).longValue());
						} else if (parameter instanceof Float){
							statement.setFloat(j+1, ((Float)parameter).floatValue());
						} else if (parameter instanceof java.util.Date){
							statement.setTimestamp(j+1, new java.sql.Timestamp( ((java.util.Date)parameter).getTime()) );
						} else if (parameter instanceof java.sql.Date){
							statement.setDate(j+1, (java.sql.Date)	parameter);
						} else if(parameter instanceof java.util.Date){
							statement.setTime(j+1, new java.sql.Time(((java.util.Date)parameter).getTime()));
						} else{
							statement.setString(j+1, String.valueOf(parameter));
						}
					}
					if(parameterSetNumber>1)//more than one parameter sets
						statement.addBatch();
				}
				
			    if(parameterSetNumber>1){
			    	statement.executeBatch();
			    }else{
			     //verify the sql, if it starts as 'SELECT', means we need executeQuery()
			     //otherwise if it starts as 'INSERT'/'UPDATE'/'DELETE' means we need executeUpdate()
			     if(sql.trim().toUpperCase().startsWith("SELECT")){
			    	 rSet = statement.executeQuery();
					 ResultSetMetaData metaData = rSet.getMetaData();
					 int colCount = metaData.getColumnCount();
					 while(rSet.next()){
						Object valueObject = null;
						ArrayList oneRowData = new ArrayList();
							
						if(valueObjectClass!=null){
							valueObject  = valueObjectClass.newInstance();
							result.add(valueObject);
						}else{
							result.add(oneRowData);
						}
						for(int i=0;i<colCount;i++){
							String colName = metaData.getColumnName(i+1);
							int colType = metaData.getColumnType(i+1);
							if(valueObject!=null){
		  			            Method method = valueObjectClass.getMethod("set"+ colName, 
												new Class[] {getSQLEqivalentClassType(colType)});
								// based on the data's type the invoke method if called.
								if (colType == Types.DATE)
									method.invoke(valueObject, new Object[]{rSet.getTimestamp(i+1)});
								else if (colType == Types.TIMESTAMP)
									method.invoke(valueObject, new Object[]{rSet.getTimestamp(i+1)});						
								else if (colType == Types.NUMERIC)
									method.invoke(valueObject, new Object[]{new Long(rSet.getLong(i+1))});
								else if (colType == Types.FLOAT)
									method.invoke(valueObject, new Object[]{new Float(rSet.getFloat(i+1))});
								else if (colType == Types.INTEGER)
									method.invoke(valueObject, new Object[]{new Long(rSet.getLong(i+1))});
								else
									method.invoke(valueObject, new Object[]{rSet.getString(i+1)});					
							}else{
								oneRowData.add(rSet.getObject(i+1));
							}
						}
					}					    	 
			     }else{
			    	 statement.executeUpdate();
			     }
			}
				
		    }catch(SQLException sqlException){
		    	throw sqlException;
		    }finally{
		    	try {
					if(rSet != null)
						rSet.close();
				} catch (Exception e) {}

		    	try{
					if(statement!=null)
		    			statement.close();
				} catch (Exception e) {}
		    }
		}
		return result;
	}
	
}
