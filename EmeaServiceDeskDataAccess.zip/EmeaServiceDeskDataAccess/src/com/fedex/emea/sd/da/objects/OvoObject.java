package com.fedex.emea.sd.da.objects;

import java.util.Properties;
import java.util.regex.Pattern;

import com.fedex.emea.sd.da.helpers.Constants;

public class OvoObject {

	private String messageID;							// Unique message number. Example value is c1c79228-ae12-71d6-1a8f-0f887ebe0000	
	private String messageNodeName;						// Example value is hpbbxyz3.bbn.hp.com
	private String messageNodeType;						// Example value is HP 900 PA-RISC
	private String messageReceiveDate_ManagedNode;		// Date(mm/dd/yyyy) on which the message was received on the managed node in the time zone (system-specific TZ variable) of the management server
	private String messageReceiveTime_ManagedNode;		// Time(hh:mm:ss) at which the message was received on the managed node. THis time uses a 24-hour clock in the time zone (system-secific TZ variable) of the management server
	private String messageReceiveDate_ManagementServer;	// Date(mm/dd/yyyy) on which the message was received on the management server in the time zone (system-specific TZ variable) of the management server
	private String messageReceiveTime_ManagementServer;	// Time(hh:mm:ss) at which the message was received on the management server. This time uses a 24-hour clock in the time zone (system-secific TZ variable) of the management server
	private String applicationName;						// Example value is "/bin/su(1) Switch User"
	private String messageGroup;						// Example value is "Security"
	private String objectName;							// Example value is "root"
	private String messageSeverity;						// Acceptable values are (unknown,normal,warning,minor,major or critical)
	private String[] ovoOperators;						// List of responsible OVO operators. Example value is "opc_op Bill John"
	private String messageText;							// Example value is "Succeeded switch user to root by charlie"
	private String messageInstructions;					// Instructions
	private Properties messageAttributes;				// Custom message attributes
	private String suppressedDuplicateNumber;			// Example value is "14"
	
	public OvoObject() {
	}
	
	public OvoObject(String message) throws Exception {
		if (message != null && message.trim().length() > 0) {
			Pattern p = Pattern.compile("[0-9]{1,2}\\[");
			String[] result = p.split(message);
			String[] parameterValues = new String[result.length];
			for (int j = 0; j < result.length; j++) {
				int lng = result[j].trim().length();
	        	if (lng > 0) {
	        		parameterValues[j] = result[j].substring(0, lng - 1);
	        	}
			}
			
			this.setMessageID(parameterValues[1]);
			this.setMessageNodeName(parameterValues[2]);
			this.setMessageNodeType(parameterValues[3]);
			this.setMessageReceiveDate_ManagedNode(parameterValues[4]);
			this.setMessageReceiveTime_ManagedNode(parameterValues[5]);
			this.setMessageReceiveDate_ManagementServer(parameterValues[6]);
			this.setMessageReceiveTime_ManagementServer(parameterValues[7]);
			this.setApplicationName(parameterValues[8]);
			this.setMessageGroup(parameterValues[9]);
			this.setObjectName(parameterValues[10]);
			this.setMessageSeverity(parameterValues[11]);
			
			if (parameterValues[12] != null && parameterValues[12].trim().length() > 0) {
				String[] operators = parameterValues[12].trim().split(" ");
				this.setOvoOperators(operators);
			} else {
				this.setOvoOperators(new String[0]);
			}
			this.setMessageText(parameterValues[13]);
			this.setMessageInstructions(parameterValues[14]);
			
			Properties properties = new Properties();
			if (parameterValues[15] != null && parameterValues[15].trim().length() > 0) {
				try
				{
					String[] tokens = parameterValues[15].trim().split(";;");
					if(tokens != null && tokens.length >0)
					{
						for (int i=0; i < tokens.length; i++) {
							String[] propertyNameValues = tokens[i].split("=");
							if(propertyNameValues != null && propertyNameValues.length >0)
							{
								properties.setProperty(propertyNameValues[0],propertyNameValues[1]);
							}
						}
					}
				}
				catch(java.lang.ArrayIndexOutOfBoundsException e)
				{
					//This Processing not required for OBM Data
				}
			}
			this.setMessageAttributes(properties);
			
			if (parameterValues[16] != null && parameterValues[16].trim().length() > 0) {
				this.setSuppressedDuplicateNumber(parameterValues[16]);
			} else {
				this.setSuppressedDuplicateNumber("");
			}
		}
	}
	
	public String getAlertDescription() {
		StringBuilder alertDescription = new StringBuilder();

		alertDescription.append(getMessageSeverity().toUpperCase() + " Alert received from OBM on " + getMessageReceiveDate_ManagementServer() + " at " + getMessageReceiveTime_ManagementServer() +" GMT "+ System.getProperty("line.separator"));
		alertDescription.append(Constants._LINE + System.getProperty("line.separator"));
		alertDescription.append("Impacted Node  : " + getMessageNodeName() + " (" + getMessageNodeType() + ")" + System.getProperty("line.separator"));
		alertDescription.append("Alert Object   : " + getObjectName() + System.getProperty("line.separator"));
		alertDescription.append("Alert Message  : " + getMessageText() + System.getProperty("line.separator"));
		alertDescription.append("Instructions   : " + getMessageInstructions() + System.getProperty("line.separator"));
		alertDescription.append(Constants._LINE + System.getProperty("line.separator"));
		alertDescription.append(System.getProperty("line.separator"));
		
		return alertDescription.toString();
	}
	
	public String getMessageID() {
		return messageID;
	}
	public void setMessageID(String messageID) {
		this.messageID = messageID;
	}
	public String getMessageNodeName() {
		return messageNodeName;
	}
	public void setMessageNodeName(String messageNodeName) {
		this.messageNodeName = messageNodeName;
	}
	public String getMessageNodeType() {
		return messageNodeType;
	}
	public void setMessageNodeType(String messageNodeType) {
		this.messageNodeType = messageNodeType;
	}
	public String getMessageReceiveDate_ManagedNode() {
		return messageReceiveDate_ManagedNode;
	}
	public void setMessageReceiveDate_ManagedNode(
			String messageReceiveDate_ManagedNode) {
		this.messageReceiveDate_ManagedNode = messageReceiveDate_ManagedNode;
	}
	public String getMessageReceiveTime_ManagedNode() {
		return messageReceiveTime_ManagedNode;
	}
	public void setMessageReceiveTime_ManagedNode(
			String messageReceiveTime_ManagedNode) {
		this.messageReceiveTime_ManagedNode = messageReceiveTime_ManagedNode;
	}
	public String getMessageReceiveDate_ManagementServer() {
		return messageReceiveDate_ManagementServer;
	}
	public void setMessageReceiveDate_ManagementServer(
			String messageReceiveDate_ManagementServer) {
		this.messageReceiveDate_ManagementServer = messageReceiveDate_ManagementServer;
	}
	public String getMessageReceiveTime_ManagementServer() {
		return messageReceiveTime_ManagementServer;
	}
	public void setMessageReceiveTime_ManagementServer(
			String messageReceiveTime_ManagementServer) {
		this.messageReceiveTime_ManagementServer = messageReceiveTime_ManagementServer;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public String getMessageGroup() {
		return messageGroup;
	}
	public void setMessageGroup(String messageGroup) {
		this.messageGroup = messageGroup;
	}
	public String getObjectName() {
		return objectName;
	}
	public void setObjectName(String objectName) {
		this.objectName = objectName;
	}
	public String getMessageSeverity() {
		return messageSeverity;
	}
	public void setMessageSeverity(String messageSeverity) {
		this.messageSeverity = messageSeverity;
	}
	public String[] getOvoOperators() {
		return ovoOperators;
	}
	public void setOvoOperators(String[] ovoOperators) {
		this.ovoOperators = ovoOperators;
	}
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}
	public String getMessageInstructions() {
		return messageInstructions;
	}
	public void setMessageInstructions(String messageInstructions) {
		this.messageInstructions = messageInstructions;
	}
	public Properties getMessageAttributes() {
		return messageAttributes;
	}
	public void setMessageAttributes(Properties messageAttributes) {
		this.messageAttributes = messageAttributes;
	}
	public String getSuppressedDuplicateNumber() {
		return suppressedDuplicateNumber;
	}
	public void setSuppressedDuplicateNumber(String suppressedDuplicateNumber) {
		this.suppressedDuplicateNumber = suppressedDuplicateNumber;
	}
	
}
