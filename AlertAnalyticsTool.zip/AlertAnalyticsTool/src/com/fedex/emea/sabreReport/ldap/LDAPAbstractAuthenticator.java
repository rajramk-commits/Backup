package com.fedex.emea.sabreReport.ldap;


public abstract class LDAPAbstractAuthenticator {

	public static final class AuthenticateResult{
		private boolean isAuthenticated;
		private String errorDesc;
		private LDAPUserInfo userInfo;

		public AuthenticateResult(boolean success){
			this.isAuthenticated = success;
		}
		public AuthenticateResult(boolean fail,String reason){
			this.isAuthenticated = fail;
			this.errorDesc = reason;
		}
		public String getErrorDesc() {
			return errorDesc;
		}
		public boolean isAuthenticated() {
			return isAuthenticated;
		}
		
		public void setUserInfo(LDAPUserInfo userInfo){
			this.userInfo = userInfo;
		}
		
		public LDAPUserInfo getUserInfo(){
			return this.userInfo;
		}
	}

	abstract public  AuthenticateResult isUserAuthenticated(String userName,String password) throws Exception; 

	abstract public String getAuthenticatorMeans();
}
