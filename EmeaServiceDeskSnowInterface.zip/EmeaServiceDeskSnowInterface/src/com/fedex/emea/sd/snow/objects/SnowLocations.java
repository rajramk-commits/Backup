package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowLocations implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowCity;
	private String snowCompany;
	private String snowContact;
	private String snowCountry;
	private String snowFaxPhone;
	private String snowFullName;
	private String snowLatLongError;
	private String snowLatitude;
	private String snowLatitudeOld;
	private String snowLongitude;
	private String snowLongitudeOld;
	private String snowName;
	private String snowParent;
	private String snowPhone;
	private String snowPhoneTerritory;
	private String snowState;
	private String snowStockRoom;
	private String snowStreet;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowTimeZone;
	private String snowU_Boolean1;
	private String snowU_ControllingStation;
	private String snowU_DepotCodes;
	private String snowU_LocCategory;
	private String snowU_LocDepotId;
	private String snowU_Locid;
	private String snowU_NetworkSite;
	private String snowU_TntSite;
	private String snowZip;
	
	public SnowLocations() {
	}
	
	public SnowLocations(HashMap<String, Object> jsonValues) {
		snowCity = SnowUtilities.getStringValueFromObject(jsonValues.get("city"));
		snowCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("company"));
		snowContact = SnowUtilities.getStringValueFromObject(jsonValues.get("contact"));
		snowCountry = SnowUtilities.getStringValueFromObject(jsonValues.get("country"));
		snowFaxPhone = SnowUtilities.getStringValueFromObject(jsonValues.get("fax_phone"));
		snowFullName = SnowUtilities.getStringValueFromObject(jsonValues.get("full_name"));
		snowLatLongError = SnowUtilities.getStringValueFromObject(jsonValues.get("lat_long_error"));
		snowLatitude = SnowUtilities.getStringValueFromObject(jsonValues.get("latitude"));
		snowLatitudeOld = SnowUtilities.getStringValueFromObject(jsonValues.get("latitude_old"));
		snowLongitude = SnowUtilities.getStringValueFromObject(jsonValues.get("longitude"));
		snowLongitudeOld = SnowUtilities.getStringValueFromObject(jsonValues.get("longitude_old"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowParent = SnowUtilities.getStringValueFromObject(jsonValues.get("parent"));
		snowPhone = SnowUtilities.getStringValueFromObject(jsonValues.get("phone"));
		snowPhoneTerritory = SnowUtilities.getStringValueFromObject(jsonValues.get("phone_territory"));
		snowState = SnowUtilities.getStringValueFromObject(jsonValues.get("state"));
		snowStockRoom = SnowUtilities.getStringValueFromObject(jsonValues.get("stock_room"));
		snowStreet = SnowUtilities.getStringValueFromObject(jsonValues.get("street"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowTimeZone = SnowUtilities.getStringValueFromObject(jsonValues.get("time_zone"));
		snowU_Boolean1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_boolean_1"));
		snowU_ControllingStation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_controlling_station"));
		snowU_DepotCodes = SnowUtilities.getStringValueFromObject(jsonValues.get("u_depot_codes"));
		snowU_LocCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_loc_category"));
		snowU_LocDepotId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_loc_depot_id"));
		snowU_Locid = SnowUtilities.getStringValueFromObject(jsonValues.get("u_locid"));
		snowU_NetworkSite = SnowUtilities.getStringValueFromObject(jsonValues.get("u_network_site"));
		snowU_TntSite = SnowUtilities.getStringValueFromObject(jsonValues.get("u_tnt_site"));
		snowZip = SnowUtilities.getStringValueFromObject(jsonValues.get("zip"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowCity != null && !snowCity.toString().isEmpty()) jsonObject.put("city", snowCity);
		if (snowCompany != null && !snowCompany.toString().isEmpty()) jsonObject.put("company", snowCompany);
		if (snowContact != null && !snowContact.toString().isEmpty()) jsonObject.put("contact", snowContact);
		if (snowCountry != null && !snowCountry.toString().isEmpty()) jsonObject.put("country", snowCountry);
		if (snowFaxPhone != null && !snowFaxPhone.toString().isEmpty()) jsonObject.put("fax_phone", snowFaxPhone);
		if (snowFullName != null && !snowFullName.toString().isEmpty()) jsonObject.put("full_name", snowFullName);
		if (snowLatLongError != null && !snowLatLongError.toString().isEmpty()) jsonObject.put("lat_long_error", snowLatLongError);
		if (snowLatitude != null && !snowLatitude.toString().isEmpty()) jsonObject.put("latitude", snowLatitude);
		if (snowLatitudeOld != null && !snowLatitudeOld.toString().isEmpty()) jsonObject.put("latitude_old", snowLatitudeOld);
		if (snowLongitude != null && !snowLongitude.toString().isEmpty()) jsonObject.put("longitude", snowLongitude);
		if (snowLongitudeOld != null && !snowLongitudeOld.toString().isEmpty()) jsonObject.put("longitude_old", snowLongitudeOld);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowParent != null && !snowParent.toString().isEmpty()) jsonObject.put("parent", snowParent);
		if (snowPhone != null && !snowPhone.toString().isEmpty()) jsonObject.put("phone", snowPhone);
		if (snowPhoneTerritory != null && !snowPhoneTerritory.toString().isEmpty()) jsonObject.put("phone_territory", snowPhoneTerritory);
		if (snowState != null && !snowState.toString().isEmpty()) jsonObject.put("state", snowState);
		if (snowStockRoom != null && !snowStockRoom.toString().isEmpty()) jsonObject.put("stock_room", snowStockRoom);
		if (snowStreet != null && !snowStreet.toString().isEmpty()) jsonObject.put("street", snowStreet);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowTimeZone != null && !snowTimeZone.toString().isEmpty()) jsonObject.put("time_zone", snowTimeZone);
		if (snowU_Boolean1 != null && !snowU_Boolean1.toString().isEmpty()) jsonObject.put("u_boolean_1", snowU_Boolean1);
		if (snowU_ControllingStation != null && !snowU_ControllingStation.toString().isEmpty()) jsonObject.put("u_controlling_station", snowU_ControllingStation);
		if (snowU_DepotCodes != null && !snowU_DepotCodes.toString().isEmpty()) jsonObject.put("u_depot_codes", snowU_DepotCodes);
		if (snowU_LocCategory != null && !snowU_LocCategory.toString().isEmpty()) jsonObject.put("u_loc_category", snowU_LocCategory);
		if (snowU_LocDepotId != null && !snowU_LocDepotId.toString().isEmpty()) jsonObject.put("u_loc_depot_id", snowU_LocDepotId);
		if (snowU_Locid != null && !snowU_Locid.toString().isEmpty()) jsonObject.put("u_locid", snowU_Locid);
		if (snowU_NetworkSite != null && !snowU_NetworkSite.toString().isEmpty()) jsonObject.put("u_network_site", snowU_NetworkSite);
		if (snowU_TntSite != null && !snowU_TntSite.toString().isEmpty()) jsonObject.put("u_tnt_site", snowU_TntSite);
		if (snowZip != null && !snowZip.toString().isEmpty()) jsonObject.put("zip", snowZip);
		
		return jsonObject;
	}

	public String getSnowCity() {
		return snowCity;
	}

	public void setSnowCity(String snowCity) {
		this.snowCity = snowCity;
	}

	public String getSnowCompany() {
		return snowCompany;
	}

	public void setSnowCompany(String snowCompany) {
		this.snowCompany = snowCompany;
	}

	public String getSnowContact() {
		return snowContact;
	}

	public void setSnowContact(String snowContact) {
		this.snowContact = snowContact;
	}

	public String getSnowCountry() {
		return snowCountry;
	}

	public void setSnowCountry(String snowCountry) {
		this.snowCountry = snowCountry;
	}

	public String getSnowFaxPhone() {
		return snowFaxPhone;
	}

	public void setSnowFaxPhone(String snowFaxPhone) {
		this.snowFaxPhone = snowFaxPhone;
	}

	public String getSnowFullName() {
		return snowFullName;
	}

	public void setSnowFullName(String snowFullName) {
		this.snowFullName = snowFullName;
	}

	public String getSnowLatLongError() {
		return snowLatLongError;
	}

	public void setSnowLatLongError(String snowLatLongError) {
		this.snowLatLongError = snowLatLongError;
	}

	public String getSnowLatitude() {
		return snowLatitude;
	}

	public void setSnowLatitude(String snowLatitude) {
		this.snowLatitude = snowLatitude;
	}

	public String getSnowLatitudeOld() {
		return snowLatitudeOld;
	}

	public void setSnowLatitudeOld(String snowLatitudeOld) {
		this.snowLatitudeOld = snowLatitudeOld;
	}

	public String getSnowLongitude() {
		return snowLongitude;
	}

	public void setSnowLongitude(String snowLongitude) {
		this.snowLongitude = snowLongitude;
	}

	public String getSnowLongitudeOld() {
		return snowLongitudeOld;
	}

	public void setSnowLongitudeOld(String snowLongitudeOld) {
		this.snowLongitudeOld = snowLongitudeOld;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowParent() {
		return snowParent;
	}

	public void setSnowParent(String snowParent) {
		this.snowParent = snowParent;
	}

	public String getSnowPhone() {
		return snowPhone;
	}

	public void setSnowPhone(String snowPhone) {
		this.snowPhone = snowPhone;
	}

	public String getSnowPhoneTerritory() {
		return snowPhoneTerritory;
	}

	public void setSnowPhoneTerritory(String snowPhoneTerritory) {
		this.snowPhoneTerritory = snowPhoneTerritory;
	}

	public String getSnowState() {
		return snowState;
	}

	public void setSnowState(String snowState) {
		this.snowState = snowState;
	}

	public String getSnowStockRoom() {
		return snowStockRoom;
	}

	public void setSnowStockRoom(String snowStockRoom) {
		this.snowStockRoom = snowStockRoom;
	}

	public String getSnowStreet() {
		return snowStreet;
	}

	public void setSnowStreet(String snowStreet) {
		this.snowStreet = snowStreet;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowTimeZone() {
		return snowTimeZone;
	}

	public void setSnowTimeZone(String snowTimeZone) {
		this.snowTimeZone = snowTimeZone;
	}

	public String getSnowU_Boolean1() {
		return snowU_Boolean1;
	}

	public void setSnowU_Boolean1(String snowU_Boolean1) {
		this.snowU_Boolean1 = snowU_Boolean1;
	}

	public String getSnowU_ControllingStation() {
		return snowU_ControllingStation;
	}

	public void setSnowU_ControllingStation(String snowU_ControllingStation) {
		this.snowU_ControllingStation = snowU_ControllingStation;
	}

	public String getSnowU_DepotCodes() {
		return snowU_DepotCodes;
	}

	public void setSnowU_DepotCodes(String snowU_DepotCodes) {
		this.snowU_DepotCodes = snowU_DepotCodes;
	}

	public String getSnowU_LocCategory() {
		return snowU_LocCategory;
	}

	public void setSnowU_LocCategory(String snowU_LocCategory) {
		this.snowU_LocCategory = snowU_LocCategory;
	}

	public String getSnowU_LocDepotId() {
		return snowU_LocDepotId;
	}

	public void setSnowU_LocDepotId(String snowU_LocDepotId) {
		this.snowU_LocDepotId = snowU_LocDepotId;
	}

	public String getSnowU_Locid() {
		return snowU_Locid;
	}

	public void setSnowU_Locid(String snowU_Locid) {
		this.snowU_Locid = snowU_Locid;
	}

	public String getSnowU_NetworkSite() {
		return snowU_NetworkSite;
	}

	public void setSnowU_NetworkSite(String snowU_NetworkSite) {
		this.snowU_NetworkSite = snowU_NetworkSite;
	}

	public String getSnowU_TntSite() {
		return snowU_TntSite;
	}

	public void setSnowU_TntSite(String snowU_TntSite) {
		this.snowU_TntSite = snowU_TntSite;
	}

	public String getSnowZip() {
		return snowZip;
	}

	public void setSnowZip(String snowZip) {
		this.snowZip = snowZip;
	}
	
}
