package com.fedex.emea.sabreReport.service;

import java.util.ArrayList;
import java.util.List;

import com.fedex.emea.sabreReport.dao.ReportDao;
import com.fedex.emea.sabreReport.model.SabreBean;

public class ReportDataService {
	public static List<SabreBean> generateReport(String startDate, String endDate)
	{
		List<SabreBean> list = new ArrayList<>();
		try
		{
			list = ReportDao.getData(startDate, endDate);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	public static List<SabreBean> generateGSSReport(String startDate, String endDate)
	{
		List<SabreBean> list = new ArrayList<>();
		try
		{
			list = ReportDao.getGSSData(startDate, endDate);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	public static List<SabreBean> generateITIHReport(String startDate, String endDate)
	{
		List<SabreBean> list = new ArrayList<>();
		try
		{
			list = ReportDao.getITIHData(startDate, endDate);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
}
