package com.fedex.dashboard.model;

import java.util.List;

public class HubActivityBean {

	private String hubActivities;
	private List<String> details;
	
	public String getHubActivities() {
		return hubActivities;
	}
	public void setHubActivities(String hubActivities) {
		this.hubActivities = hubActivities;
	}
	public List<String> getDetails() {
		return details;
	}
	public void setDetails(List<String> details) {
		this.details = details;
	}
	@Override
	public String toString() {
		return "HubActivityBean [hubActivities=" + hubActivities + ", details=" + details + "]\n";
	}
}
