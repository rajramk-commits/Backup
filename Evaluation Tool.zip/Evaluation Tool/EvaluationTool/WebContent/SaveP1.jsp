<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.Session"%>
  <jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
<%
	String qId = request.getParameter("qId");
	String qn = request.getParameter("Question");
	String opt1 = request.getParameter("OptionA");
	String opt2 =request.getParameter("OptionB");
	String opt3 =request.getParameter("OptionC");
	String opt4 =request.getParameter("OptionD");
	String crctAns =request.getParameter("CorrectAns");
	String res  = DAO.updateQnID(qn, opt1, opt2, opt3, opt4, crctAns, qId);
	System.out.println("SaveP1 : qnId :"+qId+", qn :"+qn+", opt1 :"+opt1+", crctAns :"+crctAns+", res :"+res);
	response.sendRedirect("ViewDelQuestion.jsp?status="+res);
%>
</head>
<body>
</body>
</html>