package com.fedex.emea.dimm.config;

import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.fedex.emea.dimm.log.LogFactory;
import com.fedex.emea.dimm.utils.FileChangeListener;
import com.fedex.emea.dimm.utils.FileMonitor;

public abstract class AbstractPropertyFileBasedConfig implements FileChangeListener{

	private static final Logger log = LogManager.getLogger(AbstractPropertyFileBasedConfig.class);
	
	private HashMap<String,String> propertyMap = new LinkedHashMap<String,String>();
	
	protected abstract String getPropertyFileName();
	
	protected abstract boolean isAutoReloadConfig();
	
	protected abstract void loadConfigFromProperties(Map<String,String> propertyMap)  throws Exception;
	
	public void dumpProperties(){
		//LogFactory.getLogger().logInfo("=============Properties loaded from "+getPropertyFileName()+"===============");
		log.info("=============Properties loaded from "+getPropertyFileName()+"===============");
		Iterator propertyNameI = propertyMap.keySet().iterator();
		while(propertyNameI.hasNext()){
			String propertyName = (String)propertyNameI.next();
			String propertyValue = (String)propertyMap.get(propertyName);
			LogFactory.getLogger().logInfo(propertyName+" = "+propertyValue);
		}
		//LogFactory.getLogger().logInfo("=============================================================================");
		log.info("=============================================================================");
	}
	
	public AbstractPropertyFileBasedConfig() throws Exception {
		String propertyFileName = getPropertyFileName();
		
		//first load the properties from the file
		loadProperties(propertyFileName);
		
		//then load the configuration from the properties
		loadConfigFromProperties(propertyMap);
		
		if(isAutoReloadConfig()){//register the property file to the file change listener
			URL propertyFileURL = this.getClass().getClassLoader().getResource(propertyFileName);
			if(propertyFileURL!=null){
				FileMonitor fileMonitor = FileMonitor.getInstance();
				try{
					//LogFactory.getLogger().logInfo("Registering the property file "+propertyFileName+" to the file change listener...");
					log.info("Registering the property file "+propertyFileName+" to the file change listener...");
					fileMonitor.addFileChangeListener(this, propertyFileURL.getFile(),1*60*1000);//very 1 mins check it
					//LogFactory.getLogger().logInfo("The file change listener for the property file "+propertyFileName+" has been registered successfully");
					log.info("The file change listener for the property file "+propertyFileName+" has been registered successfully");
				}catch(Exception exception){
					//LogFactory.getLogger().logException("Error : ",exception);
					log.error("Unexpected error:: ", exception);
					//LogFactory.getLogger().logInfo("Can not listen to the properties file "+propertyFileName+"'s change");
					log.info("Can not listen to the properties file "+propertyFileName+"'s change");
				}
			}else{
				throw new Exception("Property file "+propertyFileName+" doesn't exist in the classpath");
			}
		}
	}

	@Override
	public void fileChanged(String fileName) {
		try{
			//first load the properties from the file
			loadProperties(fileName);
			
			//then load the configuration from the properties
			loadConfigFromProperties(propertyMap);
			
		}catch(Exception exception){
			/*LogFactory.getLogger().logException("Error : ",exception);
			LogFactory.getLogger().logInfo("Faile to load the configuration from the property file "+fileName);*/
			log.error("Unexpected error:: ", exception);
			log.info("Faile to load the configuration from the property file "+fileName);
		}
	}
	
	protected void loadProperties(String propertyFileName) throws Exception {
		HashMap<String,String> newpropertyMap = new LinkedHashMap<String,String>();
		Properties properties = new Properties();
		InputStream is = this.getClass().getClassLoader().getResourceAsStream(propertyFileName);
		properties.load(is);
		is.close();
		Set propertyNameSet = properties.keySet();
		Iterator propertyNameI = propertyNameSet.iterator();
		while(propertyNameI.hasNext()){
			String propertyName = (String)propertyNameI.next();
			String propertyValue = properties.getProperty(propertyName);
			newpropertyMap.put(propertyName, propertyValue.trim());
		}
		//only when every thing is fine, we replace the old one
		synchronized (propertyMap){
			propertyMap.clear();
			propertyMap.putAll(newpropertyMap);
		}
		
		dumpProperties();
	}
}
