package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_SYM_NI2_LINKS table.
 */
public class PrSymNi2LinksPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8226066489256787122L;

	protected String symEaiId;

	protected String ni2AppId;

	/** 
	 * Sets the value of symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/** 
	 * Gets the value of symEaiId
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/** 
	 * Sets the value of ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/** 
	 * Gets the value of ni2AppId
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'PrSymNi2LinksPk'
	 * 
	 */
	public PrSymNi2LinksPk()
	{
	}

	/**
	 * Method 'PrSymNi2LinksPk'
	 * 
	 * @param symEaiId
	 * @param ni2AppId
	 */
	public PrSymNi2LinksPk(final String symEaiId, final String ni2AppId)
	{
		this.symEaiId = symEaiId;
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSymNi2LinksPk)) {
			return false;
		}
		
		final PrSymNi2LinksPk _cast = (PrSymNi2LinksPk) _other;
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSymNi2LinksPk: " );
		ret.append( "symEaiId=" + symEaiId );
		ret.append( ", ni2AppId=" + ni2AppId );
		return ret.toString();
	}

}
