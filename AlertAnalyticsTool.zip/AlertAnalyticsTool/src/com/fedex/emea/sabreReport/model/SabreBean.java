package com.fedex.emea.sabreReport.model;

public class SabreBean {
	
	private String incedent;
	private String created;
	private String shortDescr;
	private String alertType;
	private String location;
	private String comments;
	
	public SabreBean()
	{	}

	public SabreBean(String incedent, String created, String shortDescr, String alertType, String location,
			String comments) {
		super();
		this.incedent = incedent;
		this.created = created;
		this.shortDescr = shortDescr;
		this.alertType = alertType;
		this.location = location;
		this.comments = comments;
	}
	
	@Override
	public String toString() {
		return "SabreBean [incedent=" + incedent + ", created=" + created + ", shortDescr=" + shortDescr
				+ ", alertType=" + alertType + ", location=" + location + ", comments=" + comments + "]";
	}
	public String getIncedent() {
		return incedent;
	}
	public void setIncedent(String incedent) {
		this.incedent = incedent;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getShortDescr() {
		return shortDescr;
	}
	public void setShortDescr(String shortDescr) {
		this.shortDescr = shortDescr;
	}
	public String getAlertType() {
		return alertType;
	}
	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}
