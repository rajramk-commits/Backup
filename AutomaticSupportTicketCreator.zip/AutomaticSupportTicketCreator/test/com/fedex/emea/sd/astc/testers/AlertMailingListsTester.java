package com.fedex.emea.sd.astc.testers;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.dao.AlertMailingListsDao;
import com.fedex.emea.sd.da.objects.AlertMailingLists;

@SuppressWarnings("unused")
public class AlertMailingListsTester {
	
	private static AlertMailingListsDao alertMailingListsDao;
	
	public static void main(String[] args) {
		
		AlertMailingListsTester myTester = new AlertMailingListsTester();
		
		ClassPathResource classPathResource = new ClassPathResource("spring-config.xml");
		XmlBeanFactory beanFactory = new XmlBeanFactory(classPathResource);
		
		alertMailingListsDao = (AlertMailingListsDao) beanFactory.getBean("alertMailingListsDao");
		
		try {
			//myTester.testInsertAlertMailingList(alertMailingListsDao);
			//myTester.testGetAlertMailingListByAlertSource("OVO");
			//myTester.testListToArray();
			myTester.testMailingList();
		} catch (Exception ex) {
			System.out.println("Error occured...:");
			ex.printStackTrace();
		}
		
		// Refine test with additional parameters ! (dummy comm!)
		
	}
	
	private void testMailingList() throws SQLException {
		System.out.println("Mails for OBM: ");
		for (String s: alertMailingListsDao.getMailsByAlertSource("SELF")) {
			System.out.println("- " + s);
		}
	}
	
	private void testListToArray() throws SQLException {
		List<AlertMailingLists> alertMailingLists = alertMailingListsDao.loadByAlertSource("OBM");
		ArrayList<String> mailToList = new ArrayList<String>();
		for (AlertMailingLists alertMailingElement: alertMailingLists) {
			mailToList.add(alertMailingElement.getUserMail());
		}
		String[] mailTos = new String[mailToList.size()];
		mailTos = mailToList.toArray(mailTos);
		
		System.out.println("Mails for OBM: ");
		for (String s: mailTos) {
			System.out.println("- " + s);
		}
	}
	
	private void testInsertAlertMailingList(AlertMailingListsDao alertMailingListsDao) throws SQLException, DataAccessException, IOException {
		AlertMailingLists alertMailingListsRecord = getAlertMailingListsRecord();
		alertMailingListsDao.create(alertMailingListsRecord);
	}
	
	private void testGetAlertMailingListByAlertSource(String alertSource) throws SQLException {
		
		System.out.println("Mailing List for " + alertSource + " :");
		
		List<AlertMailingLists> alertMailingListsList = alertMailingListsDao.loadByAlertSource(alertSource);
		
		for (Iterator<?> iter = alertMailingListsList.iterator(); iter.hasNext();) {
			AlertMailingLists element = (AlertMailingLists) iter.next();
			System.out.println(element.getAlertSource() + " - " + element.getUserMail() + " - " + element.getUserPin());
		}		
		System.out.println("---------------------------------------------------------");
	}
	
	private static AlertMailingLists getAlertMailingListsRecord() throws IOException {
		
		AlertMailingLists alertMailingListsRecord = new AlertMailingLists();
		
		alertMailingListsRecord.setAlertSource("RIH_PREPROD_DASHBOARD");
		alertMailingListsRecord.setUserPin("261157");
		alertMailingListsRecord.setUserMail("jmeuleman@fedex.com");
		return alertMailingListsRecord;
	}	
}
