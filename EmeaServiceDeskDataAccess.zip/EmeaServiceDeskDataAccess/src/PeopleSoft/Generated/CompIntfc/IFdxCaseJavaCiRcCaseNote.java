
//*****************************************************************
//* 
//* FdxCaseJavaCiRcCaseNote.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public interface IFdxCaseJavaCiRcCaseNote 
  {
  public long getItemNum() throws JOAException;
  public String getNoteSummary() throws JOAException;
  public void setNoteSummary(String inNoteSummary) throws JOAException;
  public String getNoteType() throws JOAException;
  public void setNoteType(String inNoteType) throws JOAException;
  public String getNoteOrigin() throws JOAException;
  public void setNoteOrigin(String inNoteOrigin) throws JOAException;
  public String getNoteContactType() throws JOAException;
  public void setNoteContactType(String inNoteContactType) throws JOAException;
  public String getNoteDescrlong() throws JOAException;
  public void setNoteDescrlong(String inNoteDescrlong) throws JOAException;
  public Object getPropertyByName(String Name) throws JOAException;
  public long setPropertyByName(String Name, Object Value) throws JOAException;
  public ICompIntfcPropertyInfo getPropertyInfoByName(String Name) throws JOAException;
  }
