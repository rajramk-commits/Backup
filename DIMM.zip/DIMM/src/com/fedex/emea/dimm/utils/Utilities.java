package com.fedex.emea.dimm.utils;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;

public class Utilities {
	
	private static SimpleDateFormat dateFormatter = new SimpleDateFormat();

	 public static String replace(String str, String pattern, String replace) {
        int s = 0;
        int e = 0;
        StringBuffer result = new StringBuffer();
    
        while ((e = str.indexOf(pattern, s)) >= 0) {
            result.append(str.substring(s, e));
            result.append(replace);
            s = e+pattern.length();
        }
        result.append(str.substring(s));
        return result.toString();
    }
	 
		/**
		 * This method pads blank space to the left or right of a string
		 * @param str			The string which has to be padded with space.
		 * @param iMaxLen		The Max length till which space can be padded
		 * @param iAlign		Indicates text alignment to be center(0), left(1), right(2).
		 * @return the string with the blank space to the left or right 
		 */
		public static String padSpace(String str, int iMaxLen, int iAlign){
			StringBuffer strBuf = new StringBuffer();
			
			if (!isValidString(str)){
				return "";
			}
			
			if (str.length() > iMaxLen){
				return str;
			} else {
				
				int iPadLen = iMaxLen - str.length();
				byte[] bPadSide = new byte[iPadLen];
				int iCenterPadLen = Math.round(iPadLen/2);
				byte[] bCenterPad = new byte[iCenterPadLen];
				for (int iDx = 0; iDx < iPadLen; iDx++) {
					bPadSide[iDx] = ' ';
				}
				for (int iDx = 0; iDx < iCenterPadLen; iDx++) {
					bCenterPad[iDx] = ' ';
				}
				if (iAlign == 0)
					strBuf.append(new String(bCenterPad)).append(str).append(new String(bCenterPad));
				else if (iAlign == 1)
					strBuf.append(str).append(new String(bPadSide));
				else if (iAlign == 2)
					strBuf.append(new String(bPadSide)).append(str);
			}
			
			return strBuf.toString();
		}

	
	/**
	 * This method returns true if String is valid else false.
	 */
	public static boolean isValidString(String value){

		if (value == null || value.trim().length() == 0 || value.equals("null") || value.equals(""))
			return false;
		else
			return true;
	}
	
	/**
	 * This method loads the file into a properties object and returns it.
	 * The file contains information in the form of key = value.  
	 * 
	 * @param strFileName	The file that has to be loaded. The file name should be complete path	
	 * @return the standard java Properties object that holds the translated properties from the file
	 * @throws Exception
	 */
	public static Properties loadProperties(String strFileName) throws Exception {
		Properties prop = null;
		InputStream inStream = null;
		
		try {
			if (!isValidString(strFileName))
				throw new IllegalArgumentException("Invalid file  - " + strFileName);
			
			File file = new File(strFileName);
			
			// check if file exists in the mentioned path.
			// if it does not exist then check the file in the classpath
			if (!file.exists()){
				inStream = file.getClass().getResourceAsStream(strFileName);
			} else {
				inStream = new FileInputStream(file);
			}
			if (inStream == null)
				throw new FileNotFoundException("File not found - " + strFileName);
			
			prop = new Properties();
			prop.load(inStream);
			inStream.close();
			
		} catch (Exception exp) {
			throw exp;
		}
		return prop;
	}
	
	public static ArrayList searchSimilarKeys(Object oContainer, String strSearchKey) throws Exception {
		
		ArrayList arrLstKeys = new ArrayList();
		String strKey = null;
		try {
			if (oContainer == null)
				throw new Exception("Object is null");
			
			if (oContainer instanceof Properties){
				Enumeration enumKeys = ((Properties) oContainer).keys();
				
				while (enumKeys.hasMoreElements()){
					strKey = (String) enumKeys.nextElement();
					
					if (strKey.indexOf(strSearchKey) != -1)
						arrLstKeys.add(strKey);
				}				
			}
		} catch (Exception exp) {
			throw exp;
		}
		return arrLstKeys;
	}
	
	public static List<String> getOvoServerComponents() {
		
		String ovoServerMessages = DIMMConstants.OVO_SERVER_COMPONENTS;
		String[] ovoServerMessagesArray = ovoServerMessages.split(",");
		List<String> ovoServerComponents = new ArrayList<String>();
		for(String message :ovoServerMessagesArray) {
			ovoServerComponents.add(message);
		}
		return ovoServerComponents;
	}
	
	public static List<String> getITOApplicationList() {
		
		String itoApplications = DIMMConstants.ITO_APPLICATIONS;
		String[] itoApplicationsArray = itoApplications.split(",");
		List<String> itoApplicationComponents = new ArrayList<String>();
		for(String message :itoApplicationsArray) {
			itoApplicationComponents.add(message);
		}
		return itoApplicationComponents;
	}
	
public static List<String> getDTRCApplicationList() {
		
		String itoApplications = DIMMConstants.DTRC_APPLICATIONS;
		String[] itoApplicationsArray = itoApplications.split(",");
		List<String> itoApplicationComponents = new ArrayList<String>();
		for(String message :itoApplicationsArray) {
			itoApplicationComponents.add(message);
		}
		return itoApplicationComponents;
	}
	
	public static List<String> getCaseClosedStatusList() {
		
		String itoApplications = DIMMConstants.CASE_CLOSED_STATUS;
		String[] itoApplicationsArray = itoApplications.split(",");
		List<String> itoApplicationComponents = new ArrayList<String>();
		for(String message :itoApplicationsArray) {
			itoApplicationComponents.add(message);
		}
		return itoApplicationComponents;
	}
	/*
	public static boolean isCaseCreatedTimeGt8hours(String caseCreatedTime) {
		
		boolean eightHourRuleFlag = false;
		Date date = null;
		try {
			DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
			
			if(caseCreatedTime.contains("PM")) {
				String[] dateArray = caseCreatedTime.split(" ");
				String[] dateArray1 = dateArray[1].split(":");
				Integer hour = Integer.parseInt(dateArray1[0]);
				Integer pmhour = hour + 12;
				
				String mdate = dateArray[0] + " " + pmhour + ":" + dateArray1[1] + ":" + dateArray1[2];
				date = (Date) formatter.parse(mdate);
			} else {
				date = (Date) formatter.parse(caseCreatedTime);
			}
			
			Timestamp caseCreatedTimestamp = new Timestamp(date.getTime());
			//Timestamp currentTimeStampDate = new Timestamp(new Date().getTime());
			Timestamp currentTimeStampDate = new Timestamp(new Date().getTime());
			long timeDifference = currentTimeStampDate.getTime() - caseCreatedTimestamp.getTime();
			
			//8 hours  = 28800000 millisecond
			if(timeDifference > 28800000) {
				eightHourRuleFlag = true;
			}
			
		} catch (ParseException e) {
			System.out.println("Exception:: " + e);
		}
		
		return eightHourRuleFlag;
	}*/
	/*	
public static boolean isCaseCreatedTimeGt8hours(String caseCreatedTime) {
		
		boolean eightHourRuleFlag = false;
		//Date date = null;
		Date startDate = null;
		try {
			DateFormat df = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss a"); 
			startDate = df.parse(caseCreatedTime);
		    String newDateString = df.format(startDate);
		    System.out.println(newDateString);
		  
			Timestamp timeStampDate = new Timestamp(startDate.getTime());
			Timestamp currentTimeStampDate = new Timestamp(new Date().getTime());
			long timeDifference = currentTimeStampDate.getTime() - timeStampDate.getTime();
			
			//8 hours  = 28800000 millisecond
			if(timeDifference > 28800000) {
				eightHourRuleFlag = true;
			}
			System.out.println("eightHourRuleFlag"+eightHourRuleFlag);
			System.out.println("timeDifference:"+timeDifference);
		} catch (ParseException e) {
			System.out.println("Exception:: " + e);
		}
		
		return eightHourRuleFlag;
		} */

		
	
		}
	
	

