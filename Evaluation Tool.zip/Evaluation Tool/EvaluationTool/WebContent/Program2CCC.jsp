
<%@page import="com.fedex.emea.onlinequiz.objects.QuestionCCC"%>
<%@page import="java.util.ArrayList"%>
<jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>SD Evaluation</title>


<script>


window.history.forward();
function noBack() { window.history.forward(); 
}

function confirmSubmit()
{
	var conf = confirm("Are you sure to End the Exam?");
	return conf;
}
function customSubmit(){  
	 
	 document.questionForm.page.value = "submit";
	 document.questionForm.submit();  
	 }  
	 
var tim;       
var min = '${sessionScope.min}';
var sec = '${sessionScope.sec}';
var f = new Date();

function examTimer() {
    if (parseInt(sec) >0) {

	    document.getElementById("showtime").innerHTML = "Time Remaining <br> "+min+" Min : " + sec+" Sec";
        sec = parseInt(sec) - 1;                
        tim = setTimeout("examTimer()", 1000);
    }
    else {

	    if (parseInt(min)==0 && parseInt(sec)==0){
	    	document.getElementById("showtime").innerHTML = "Time Remaining <br> "+min+" Min : " + sec+" Sec";
		     alert("Time Up");
		     
			 document.questionForm.page.value = "submit";
		     document.questionForm.submit();
		     document.getElementByIdTagName("showtime").remove();

	     }

        if (parseInt(sec) == 0) {				
		    document.getElementById("showtime").innerHTML = "Time Remaining <br> "+min+" Min : " + sec+" Sec";					
            min = parseInt(min) - 1;
			sec=59;
            tim = setTimeout("examTimer()", 1000);
        }

    }
}


</script>

<script type="text/javascript">

//function checkckbox(ckgroup,ckid){
	
//}


function checkradio(rbgroup,rdid){
	
	var radio_group =document.getElementsByName(rbgroup); 
	for(var x=0;x<radio_group.length;x++){
		if(radio_group[x].checked){
			
			document.getElementById(rdid).className='error_p';
		return 0;		
		}
		
	}	
	document.getElementById(rdid).className='error_p';
	return 10;					
}
function questformval(){
	var error = 0;
	var radioname;
	var radioid;
	var radiocount; 
	var ddd;
	
	
		radiocount = "radiocount0";
		ddd = document.getElementsByName(radiocount);
	
	for(var x=0;x<50;x++){
		if(radiocount[x]==x){
		radioname = "ans"+x;
		radioid = "radiogroup"+x;
	error = error + checkradio(radioname,radioid);
	}
	}
	if(error>0){					
		alert("Please check"+ddd);		
		return false; 
		}
	else
		return true;
}


</script>

 
<style>
.normal_p{
color:#000000;
}
.error_p{
color:#F00;
}
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;
		
}
textarea{
  width: 650px;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-family:Calibri;
  
}
input[type=submit]{

background-color:#4B0082;
color:white;
padding:14px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:20%;
}
input[type=submit]:hover{
background-color:#7030a0;
}

.time{
font-family:Calibri;
background-color:red;
color:white;
position:fixed;
padding:5px;
font-size:16px;
font-weight:600;
}
.question{
font-family:Calibri;
}
.optiona{
font-family:Calibri;
}
.optionb{
font-family:Calibri;
}
.optionc{
font-family:Calibri;
}
.optiond{
font-family:Calibri;
}
table { 
    table-layout:fixed;
}
td { 
    overflow: hidden; 
    text-overflow: ellipsis; 
    word-wrap: break-word;
}
		
</style>	
	
</head>

	 <body onLoad="examTimer()" onkeydown="return (event.keyCode != 116)" >	 
		<%     	
	        if(session.getAttribute("sessionName")==null)
	        {
	            response.sendRedirect("Login.jsp");
			}				
			String userID = (String) session.getAttribute("sessionName");
			System.out.println("userID :"+userID);
			//out.println("<br>Welcome : "+userID+"</br></br>");
			
			if(session.getAttribute("examStarted")==null){
				response.sendRedirect("Login.jsp");
			}			
     	
     	System.out.println("Seesion values examStarted :"+session.getAttribute("examStarted"));
     		if(session.getAttribute("examStarted").equals("1")){
     			System.out.println("Seesion values Name :"+session.getAttribute("TestName"));
     			System.out.println("Seesion values Test :"+session.getAttribute("Test"));
     			String Test = (String) session.getAttribute("TestName");
     	%>
     		<div class="time" id="showtime"></div>
     		<div class="main">
     		<div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Program 2 Competency Center Test</p>
   			</div>
     	
     		<div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
      		  </div> 
      		 
 			<br><br>
 				<%
                ArrayList<QuestionCCC> list;
                
 				String teamName = request.getParameter("team");
 				System.out.println("Selected teamName :"+teamName);
 				
                list= DAO.getQuestionsCCC(teamName);
                QuestionCCC questionccc;
                %>     
     		
     		<div style="width:100%">
     		<form name="questionForm"  action="Program2CCCResult.jsp" method="post" onsubmit="return questformval()">                                        
                <input type="hidden" name="size" value="<%=list.size()%>">
                <input type="hidden" name="teamName" value="<%=teamName%>">                            
                <%
                int a=0,count=0, qnCount=0 ;
                
                System.out.println("Jsp list :"+list.size());
                %>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>MCQ Questions</b></label><br><hr><br><br>
                <%
               for(int i=0;i<list.size();i++)
                	{
            	   		questionccc=list.get(i);
            	   		System.out.println("Jsp questionccc :"+questionccc.getQuestionType());
                    	if(questionccc.getQuestionType().equalsIgnoreCase("MCQ"))
                    	{
                    
                			%>							
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>		
							<% if (questionccc.getCorrect().length()>1){ 
							%>
							<input type="checkbox"   name="cans" value="A"/>
							<label class="optiona" ><%=questionccc.getOpt1()%></label>
							<input type="checkbox"   name="cans" value="B" />
							<label class="optionb" ><%=questionccc.getOpt2()%></label>
							
							<% if(questionccc.getOpt3()!=null){%>
							<input type="checkbox"  name="cans" value="C" />
							<label class="optionc" ><%=questionccc.getOpt3()%></label>
							<%}%>
							<% if(questionccc.getOpt4()!=null){%>
							<input type="checkbox"   name="cans" value="D"/>
							<label class="optiond"  ><%=questionccc.getOpt4()%></label>							
							<%}%>
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">
							<input type="hidden" name="cans" value=":">														
							<%
							}
							else {%>														
							<input type="hidden" name="radiocount0" value="<%=i%>">
							<p id ="radiogroup<%=i%>">	
							
							<input type="radio"  name="ans<%=i %>" value="A"/>
							<label class="optiona" ><%=questionccc.getOpt1()%></label>
							
							
							<input type="radio"  name="ans<%=i %>" value="B" />
							<label class="optionb" ><%=questionccc.getOpt2()%></label>
							
							<% if(questionccc.getOpt3()!=null){%>
							
							<input type="radio"   name="ans<%=i %>" value="C" />
							<label class="optionc" ><%=questionccc.getOpt3()%></label>
							<%} %>
							
							<%if(questionccc.getOpt4()!=null){ %>
							<input type="radio"   name="ans<%=i %>" value="D"/>
							<label class="optiond"  ><%=questionccc.getOpt4()%></label>							
							
							</p>
							<%}%>
							<%}
                    
							%>
							
							<hr><br><br>
			                <input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
			                <input type="hidden" name="qoptiona<%=i%>" value="<%=questionccc.getOpt1()%>">
			                <input type="hidden" name="qoptionb<%=i%>" value="<%=questionccc.getOpt2()%>">
			                <input type="hidden" name="qoptionc<%=i%>" value="<%=questionccc.getOpt3()%>">
			                <input type="hidden" name="qoptiond<%=i%>" value="<%=questionccc.getOpt4()%>">
			                <input type="hidden" name="cansLength<%=i%>" value="<%=questionccc.getCorrect().length()%>">
					
			                <% 
                    }
                	}
                %><br><br>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>Descriptive Questions (One Marks)</b></label>
                <label style="color:Black;font-family:Calibri;font-size:10px; text-align: right;"><b>10-15 Words</b></label><br>
                <%
		               for(int i=0;i<list.size();i++)
		           	{
		       	   		questionccc=list.get(i);
                    	
                    	if(questionccc.getQuestionType().equalsIgnoreCase("1M"))
                    	{                    
                			%>
                			<hr><br><br>							
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>
							<textarea id="textAns" name="textAns<%=i%>" maxlength="255"></textarea>							
							<input type="hidden" name="textAns<%=i%>" value="<%=questionccc.getCorrect()%>">
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">
							<input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">	
							<input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
                    	<% 
                    	}
		           	}
                %><br><br>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>Two Marks Questions</b></label><br>
                <%
		               for(int i=0;i<list.size();i++)
                	{
            	   		questionccc=list.get(i);
                    	
                    	if(questionccc.getQuestionType().equalsIgnoreCase("2M"))
                    	{
                    
                			%>
                			<hr><br><br>						
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>
							<textarea id="textAns" name="textAns<%=i%>" maxlength="500"></textarea>
							
							<input type="hidden" name="textAns<%=i%>" value="<%=questionccc.getCorrect()%>">
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">
							<input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">	
							<input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
                    	<%
                    	}
                	}
                %><br><br>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>Three Marks Questions</b></label><br>
                <%
		               for(int i=0;i<list.size();i++)
	                	{
	            	   		questionccc=list.get(i);
                
                    	if(questionccc.getQuestionType().equalsIgnoreCase("3M"))
                    	{
                    
                			%>
                			<hr><br><br>							
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>
							<textarea id="textAns" name="textAns<%=i%>" maxlength="1500"></textarea>
							
							<input type="hidden" name="textAns<%=i%>" value="<%=questionccc.getCorrect()%>">
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">	
							<input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">
							<input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
                    	<% 
                    	}
	                	}
                %><br><br>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>Four Marks Questions</b></label><br>
                <%
		               for(int i=0;i<list.size();i++)
	                	{
	            	   		questionccc=list.get(i);
                    	
                    	if(questionccc.getQuestionType().equalsIgnoreCase("4M"))
                    	{
                    
                			%>
                			<hr><br><br>						
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>
							<textarea id="textAns" name="textAns<%=i%>" maxlength="2000"></textarea>
							
							<input type="hidden" name="textAns<%=i%>" value="<%=questionccc.getCorrect()%>">
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">
							<input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">	
							<input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
                    	<%
                    	}
                	}                
                %>
                <br><br>
                <br><hr><label style="color:Black;font-family:Calibri;font-size:20px"><b>Five Marks Questions</b></label><br>
                <%
		               for(int i=0;i<list.size();i++)
	                	{
	            	   		questionccc=list.get(i);
                    	
                    	if(questionccc.getQuestionType().equalsIgnoreCase("5M"))
                    	{
                    
                			%>
                			<hr><br><br>						
               				<label ><%=++qnCount %>.</label>
							<label class="questionccc"><%=questionccc.getQuestion() %><br></label>
							<textarea id="textAns" name="textAns<%=i%>" maxlength="4000"></textarea>
							
							<input type="hidden" name="textAns<%=i%>" value="<%=questionccc.getCorrect()%>">
							<input type="hidden" name="cqid" value="<%=questionccc.getQuestionId()%>">
							<input type="hidden" name="questiontype<%=i%>" value="<%=questionccc.getQuestionType()%>">	
							<input type="hidden" name="questionccc<%=i%>" value="<%=questionccc.getQuestion()%>">
			                <input type="hidden" name="qid<%=i%>" value="<%=questionccc.getQuestionId()%>">
                    	<%
                    	}
                	}                
                %>
                <input type="hidden" id= "count" name = "ckcount" value="<%=count%>">
                
                
           <input type="hidden" name="cqid" value="asdf">
             
             
              <input type="submit" name="page" value="submit" onclick="return confirmSubmit();">
             <input type="hidden" name="minute"/> 
			<input type="hidden" name="second"/> 
			<input type="hidden" name="page" value="submit"/>            
        </form>
        </div>
        
   		<%   			
     		}else {
     			response.sendRedirect("Login.jsp");
     		}
     	%>
     	<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
     </div>
     <div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>

</html>