package com.fedex.emea.sabreReport.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ProcessInFile {
	private static final String DATA_SHEET = "Data";
	private static final String FILESYSTEM_DATA_SHEET = "FileSystem Data";
	private static final int ALERT_COL_NUM = 3;
	private static final int PROCSTOPPED_COL_NUM = 4;
	private static final int SERVER_COL_NUM = 0;
	
	public static Map<String, Integer> getAlertTypeDetails(String sabreFilePath) throws IOException 
	{
		Map<String, Integer> alertTypeList = initializeAlertMap();
		FileInputStream fileInStream = new FileInputStream(sabreFilePath);
		XSSFWorkbook workBook = new XSSFWorkbook(fileInStream);
		XSSFSheet selectedSheet = workBook.getSheet(DATA_SHEET);
		
		Iterator<Row> rowIterator = selectedSheet.iterator();
		int rowCount = 0;
		while (rowIterator.hasNext()) {
			if(rowCount < 1){
				rowCount++; rowIterator.next(); continue; 
			}
			Row row = rowIterator.next();
			Cell cell = row.getCell(ALERT_COL_NUM);
			
			String val = cell.getStringCellValue();
			System.out.println("value :"+val);
			
			int currVal = alertTypeList.get(val);
			alertTypeList.put(val, ++currVal);			
		}
		System.out.println("Alert Type List :"+alertTypeList);
		workBook.close();
		return sortByValue(alertTypeList, false);
	}
	
	public static Map<String, Integer> initializeAlertMap()
	{
		Map<String, Integer> alertTypeList = new HashMap<String, Integer>();
		alertTypeList.put("ProcessStopped", 0);
		alertTypeList.put("Database Connection", 0);
		alertTypeList.put("FileSystem", 0);
		alertTypeList.put("JMS Queue", 0);
		alertTypeList.put("Reprocessing", 0);
		alertTypeList.put("Operation", 0);
		alertTypeList.put("Other", 0);
		return alertTypeList;
	}
	
	public static Map<String, Integer> initializeProcessStoppedMap()
	{
		Map<String, Integer> processStoppedList = new HashMap<String, Integer>();
		processStoppedList.put("EMEA", 0);
		processStoppedList.put("CDG", 0);
		//processStoppedList.put("Other", 0);
		return processStoppedList;
	}
	
	public static Map<String, Integer> getProcessStoppedDetails(String sabreFilePath) throws IOException 
	{
		Map<String, Integer> processStoppedList = initializeProcessStoppedMap();
		FileInputStream fileInStream = new FileInputStream(sabreFilePath);
		XSSFWorkbook workBook = new XSSFWorkbook(fileInStream);
		XSSFSheet selectedSheet = workBook.getSheet(DATA_SHEET);
		
		Iterator<Row> rowIterator = selectedSheet.iterator();
		int rowCount = 0;
		while (rowIterator.hasNext()) {
			if(rowCount < 1){
				rowCount++; rowIterator.next(); continue; 
			}
			Row row = rowIterator.next();
			Cell cell = row.getCell(PROCSTOPPED_COL_NUM);
			if (cell != null)
			{
				String val = cell.getStringCellValue();
				System.out.println("value :"+val);
				if (val != null && !val.trim().equals(""))
				{
					int currVal = processStoppedList.get(val);
					processStoppedList.put(val, ++currVal);
				}
			}
		}
		System.out.println("Process Stopped List :"+processStoppedList);
		workBook.close();
		return sortByValue(processStoppedList, false);
	}
	
	
	public static Map<String, Integer> getFileSystemDetails(String sabreFilePath) throws IOException 
	{
		Map<String, Integer> fileSystemDataList = new HashMap<String, Integer>();//initializeProcessStoppedMap();
		FileInputStream fileInStream = new FileInputStream(sabreFilePath);
		XSSFWorkbook workBook = new XSSFWorkbook(fileInStream);
		XSSFSheet selectedSheet = workBook.getSheet(FILESYSTEM_DATA_SHEET);
		
		Iterator<Row> rowIterator = selectedSheet.iterator();
		int rowCount = 0;
		while (rowIterator.hasNext()) {
			if(rowCount < 1){
				rowCount++; rowIterator.next(); continue; 
			}
			Row row = rowIterator.next();
			Cell cell = row.getCell(SERVER_COL_NUM);
			if (cell != null)
			{
				String val = cell.getStringCellValue();
				System.out.println("value :"+val);
				if (val != null && !val.trim().equals(""))
				{
					if(fileSystemDataList.get(val) == null)
					{
						fileSystemDataList.put(val, 1);
					}
					else
					{
						int currVal = fileSystemDataList.get(val);
						fileSystemDataList.put(val, ++currVal);
					}
				}
			}
		}
		System.out.println("file System Data List :"+fileSystemDataList);
		workBook.close();
		return sortByValue(fileSystemDataList, false);
	}
	
	
	public static Map<String, Integer> sortByValue(Map<String, Integer> map, final boolean order)   
	{  
	//convert HashMap into List   
	List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(map.entrySet());  
	//sorting the list elements  
	Collections.sort(list, new Comparator<Entry<String, Integer>>()   
		{  
		public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)   
		{  
			if (order)   
			{  
				//compare two object and return an integer  
				return o1.getValue().compareTo(o2.getValue());}   
			else   
			{  
				return o2.getValue().compareTo(o1.getValue());  
			}
		}
	});
	Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();  
	for (Entry<String, Integer> entry : list)   
	{  
	sortedMap.put(entry.getKey(), entry.getValue());  
	}  
	return sortedMap;  
	}
}

