
//*****************************************************************
//* 
//* FdxCaseJavaCiCollection.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public interface IFdxCaseJavaCiCollection 
  {
  public long getCount() throws JOAException;
  public IFdxCaseJavaCi item(long Index) throws JOAException;
  }
