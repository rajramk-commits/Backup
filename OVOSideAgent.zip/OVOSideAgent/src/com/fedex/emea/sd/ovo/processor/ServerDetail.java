package com.fedex.emea.sd.ovo.processor;

import com.fedex.emea.sd.da.logger.ApplicationLogger;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.regex.Pattern;

public class ServerDetail {
  private static ApplicationLogger logger = ApplicationLogger.getInstance();
  
  public static boolean getServerDetails(String serverName) throws IOException {
    ServerDetail ta = new ServerDetail();
    String serverNamelowCase = "";
    if (serverName != null)
      serverNamelowCase = serverName.toLowerCase(); 
    if (Pattern.matches(ta.getPropValue("ProdServerPattern"), serverNamelowCase)) {
      logger.logInfo("Pattern Matched for :" + serverNamelowCase);
      return true;
    }
    logger.logInfo("Querying ePDSM using pdsminterface API : https://dashboard.g.fedex.com:11301/pdsminterface/servers/"+serverName);
    URLConnection connection = (new URL(String.valueOf(ta.getPropValue("URL")) + serverName)).openConnection();
    InputStream is = connection.getInputStream();
    String jsonData = convertInputStreamToString(is);
    if (jsonData.contains("u_environment") && jsonData.contains("install_status")) {
      int start = jsonData.indexOf("u_environment");
      int end = start + 20;
      String serverType = jsonData.substring(start + 16, end);
      
      int instaStart = jsonData.indexOf("install_status");
      int instaEnd = instaStart + 26;
      String installStatus = jsonData.substring(instaStart + 17, instaEnd);
      logger.logInfo("serverType :" + serverType);
      logger.logInfo("installStatus :" + installStatus);
      
      if (serverType.equalsIgnoreCase("Prod") && installStatus.equalsIgnoreCase("Installed"))
        return true; 
    } 
    return false;
  }
  

  public static String getSupportGroupName(String serverName) throws Exception
  {
	  ServerDetail ta = new ServerDetail();
	  String providerGroup = "ATLAS";
	  try
	  {
		  URLConnection connection = (new URL(String.valueOf(ta.getPropValue("URL")) + serverName)).openConnection();
		  InputStream is = connection.getInputStream();
	   	  String jsonData = convertInputStreamToString(is);
	   	  if (jsonData.contains("u_environment") && jsonData.contains("install_status") && jsonData.contains("support_group.name")) {
	   		int suppStart = jsonData.indexOf("support_group.name");
	   		int end = jsonData.indexOf("support_group.email");	       
	   		providerGroup = jsonData.substring(suppStart+21, end-3);
	   		logger.logInfo("Support group name from pdsminterface API :" + providerGroup);
	   	  }
	  }
	  catch(Exception e)
	  {
		  logger.logError(e.getMessage());
	  }
   	  return providerGroup;
  }
  
  private static String convertInputStreamToString(InputStream is) throws IOException {
    ByteArrayOutputStream result = new ByteArrayOutputStream();
    byte[] buffer = new byte[8192];
    int length;
    while ((length = is.read(buffer)) != -1)
      result.write(buffer, 0, length); 
    return result.toString(StandardCharsets.UTF_8.name());
  }
  
  public static void main(String[] args) {
    try {
    	logger.logInfo("getSupportGroupName :" + getSupportGroupName("Dawn"));
    } catch (Exception e) {
    	e.printStackTrace();
    } 
  }
  
  public String getPropValue(String propName) throws IOException {
    String result = "";
    InputStream inputStream = null;
    try {
      Properties prop = new Properties();
      String propFileName = "config.properties";
      inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
      if (inputStream != null) {
        prop.load(inputStream);
      } else {
        throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
      } 
      result = prop.getProperty(propName);
      logger.logInfo(String.valueOf(propName) + " (Property):" + result);
    } catch (Exception e) {
    	logger.logError(e.getMessage());
    } finally {
      inputStream.close();
    } 
    return result;
  }
}