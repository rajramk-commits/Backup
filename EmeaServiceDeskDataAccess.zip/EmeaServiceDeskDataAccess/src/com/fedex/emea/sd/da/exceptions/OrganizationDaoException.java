package com.fedex.emea.sd.da.exceptions;

public class OrganizationDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4536978001610450250L;

	/**
	 * Method 'OrganizationDaoException'
	 * 
	 * @param message
	 */
	public OrganizationDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'OrganizationDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public OrganizationDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
