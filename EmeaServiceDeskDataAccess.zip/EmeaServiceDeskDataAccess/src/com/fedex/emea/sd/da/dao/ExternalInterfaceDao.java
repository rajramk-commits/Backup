package com.fedex.emea.sd.da.dao;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.ExternalInterface;

public interface ExternalInterfaceDao {
	public ExternalInterface createValueObject();
	public ExternalInterface getObject(int alertId) throws SQLException;
	public ExternalInterface getObjectByRecordSourceId(String recordSourceId) throws SQLException;
	public List<ExternalInterface> loadAll() throws SQLException;
	public List<ExternalInterface> loadNotProcessed() throws SQLException;
	public List<ExternalInterface> loadOnlyDashboard() throws SQLException;
	public void create(ExternalInterface valueObject) throws SQLException, DataAccessException, IOException;
	public void createFromDashboard(ExternalInterface valueObject) throws SQLException, DataAccessException, IOException;
	public void delete(ExternalInterface valueObject) throws SQLException;
	public void deleteAll() throws SQLException;
	public void deleteOlderThan(Timestamp limitDate) throws SQLException;
	public int countAll() throws SQLException;
	public void updateCaseId(ExternalInterface valueObject) throws SQLException;
	public void updateSysIdAndIncidentNumber(ExternalInterface valueObject) throws SQLException;
	public void updatePriorityStatusGroup(ExternalInterface valueObject) throws SQLException;
	public void updateRecordStatus(ExternalInterface valueObject) throws SQLException;
	public void updateAddNoteToNew(ExternalInterface valueObject) throws SQLException;
}

