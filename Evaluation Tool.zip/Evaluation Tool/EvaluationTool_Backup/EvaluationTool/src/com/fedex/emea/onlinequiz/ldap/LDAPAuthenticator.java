package com.fedex.emea.onlinequiz.ldap;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.StartTlsRequest;
import javax.naming.ldap.StartTlsResponse;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

public class LDAPAuthenticator extends LDAPAbstractAuthenticator
{
  static String LDAP_PROVIDER_URL;
  static String LDAP_SEARCH_BASE;
  static String[] LDAP_RETURN_ATTRIBUTES;
  static String LDAP_INITIAL_CONTEXT_FACTORY;
  static String INITIAL_CONTEXT_FACTORY;
  static String LDAP_PORT;
  static String SECURITY_AUTHENTICATION;
  static String SECURITY_PROTOCOL;

  static
  {
    try
    {
      Properties properties = new Properties();
      InputStream input = new LDAPAuthenticator().getClass().getClassLoader().getResourceAsStream("ldap.properties");
      properties.load(input);

      LDAP_INITIAL_CONTEXT_FACTORY = properties.getProperty("LDAP_INITIAL_CONTEXT_FACTORY");
      LDAP_PROVIDER_URL = properties.getProperty("LDAP_PROVIDER_URL");
      LDAP_SEARCH_BASE = properties.getProperty("LDAP_SEARCH_BASE");
      INITIAL_CONTEXT_FACTORY = properties.getProperty("INITIAL_CONTEXT_FACTORY");
      LDAP_PORT = properties.getProperty("LDAP_PORT");
      SECURITY_AUTHENTICATION = properties.getProperty("SECURITY_AUTHENTICATION");
      SECURITY_PROTOCOL = properties.getProperty("SECURITY_PROTOCOL");

      String returnAttributes = properties.getProperty("LDAP_RETURN_ATTRIBUTES");

      if (isValidObject(returnAttributes))
        LDAP_RETURN_ATTRIBUTES = returnAttributes.split("\\,");
    }
    catch (MissingResourceException mrex) {
      mrex.printStackTrace();
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private static boolean isValidObject(Object obj) {
    if ((obj instanceof String)) {
      String str = (String)obj;

      return (str != null) && (!str.equals("null")) && (str.trim().length() != 0);
    }

    return obj != null;
  }

  public String getAuthenticatorMeans()
  {
    return "LDAP";
  }

  public LDAPAbstractAuthenticator.AuthenticateResult isUserAuthenticated(String userName, String password) throws Exception
  {
    String trustStoreFileName = "";
    boolean useSSL = true;
    return isUserAuthenticatedTLS(userName, password, LDAP_RETURN_ATTRIBUTES, useSSL, trustStoreFileName, true);
  }

  public static LDAPAbstractAuthenticator.AuthenticateResult isUserAuthenticated(String userName, String password, String[] ldapReturnAttributes, boolean useSSL, String truststoreFileName, boolean logEnv2Debug)
    throws Exception
  {
    if ((truststoreFileName != null) && (truststoreFileName.trim().length() > 0)) {
      System.setProperty("javax.net.ssl.trustStore", truststoreFileName);
      System.setProperty("javax.net.ssl.trustStorePassword", "fedex666");
    }

    Hashtable env = new Hashtable();
    Attribute attribute = null;
    LDAPAbstractAuthenticator.AuthenticateResult ldapResult = null;

    env.put("java.naming.factory.initial", INITIAL_CONTEXT_FACTORY);
    if (!isValidObject(LDAP_PROVIDER_URL)) {
      throw new Exception("LDAP URL is not configured in the ldap.properties file.");
    }

    env.put("java.naming.provider.url", LDAP_PROVIDER_URL + ":" + LDAP_PORT);

    env.put("java.naming.security.authentication", SECURITY_AUTHENTICATION);
    env.put("java.naming.security.protocol", SECURITY_PROTOCOL);

    if (!isValidObject(LDAP_SEARCH_BASE)) {
      throw new Exception("The LDAP search base string is not configured in the ldap.properties file.");
    }

    String secPrincipal = "uid=" + userName.trim() + "," + LDAP_SEARCH_BASE;
    env.put("java.naming.security.principal", secPrincipal);
    env.put("java.naming.security.credentials", password);
    try
    {
      DirContext ctx = new InitialDirContext(env);

      LDAPUserInfo userInfo = new LDAPUserInfo();
      Method[] methods = userInfo.getClass().getDeclaredMethods();

      Attributes attrCols = ctx.getAttributes(secPrincipal, ldapReturnAttributes);
      Enumeration idEnumn = attrCols.getIDs();
      while (idEnumn.hasMoreElements()) {
        String id = idEnumn.nextElement().toString();
        id = id;
      }

      for (int iDx = 0; iDx < ldapReturnAttributes.length; iDx++) {
        attribute = attrCols.get(ldapReturnAttributes[iDx]);
        if (methods != null) {
          for (int i = 0; i < methods.length; i++) {
            if ((methods[i].getName().indexOf("set" + ldapReturnAttributes[iDx]) == -1) || 
              (attribute == null)) continue;
            methods[i].invoke(userInfo, new Object[] { attribute.get() });
            break;
          }
        }

      }

      ldapResult = new LDAPAbstractAuthenticator.AuthenticateResult(true);
      ldapResult.setUserInfo(userInfo);
    } catch (Exception exception) {
      if ((exception.getMessage() != null) && (exception.getMessage().trim().length() > 0)) {
        return new LDAPAbstractAuthenticator.AuthenticateResult(false, exception.getMessage());
      }
      return new LDAPAbstractAuthenticator.AuthenticateResult(false, exception.getCause().getMessage());
    }

    return ldapResult;
  }
  
  public static AuthenticateResult isUserAuthenticatedTLS(String userName,String password,String[] ldapReturnAttributes,
			boolean useSSL,String truststoreFileName,boolean logEnv2Debug){
	  
	  
		try{
		String port = "389";//default LDAP port for TLS
		
		if(truststoreFileName!=null && truststoreFileName.trim().length()>0){//use provided trust store
			System.setProperty("javax.net.ssl.trustStore",truststoreFileName);
			System.setProperty("javax.net.ssl.trustStorePassword","changeit");
		}//else use default trust store
		
		//Set up the environment for creating the initial context
		Hashtable<String,String> env = new Hashtable<String,String>();
		Attribute attribute = null;
		AuthenticateResult ldapResult = null;
		
		env.put("java.naming.factory.initial", INITIAL_CONTEXT_FACTORY);
	    if (!isValidObject(LDAP_PROVIDER_URL)) {
	      throw new Exception("LDAP URL is not configured in the ldap.properties file.");
	    }
		
		env.put("java.naming.provider.url", LDAP_PROVIDER_URL + ":" + LDAP_PORT);
		
		//LDAP_SEARCH_BASE=uid=?,ou=People,o=fedex,c=us
		if (!isValidObject(LDAP_SEARCH_BASE)) {
	        throw new Exception("The LDAP search base string is not configured in the ldap.properties file.");
	      }
	
		//Create the initial context
		LdapContext  ctx = new InitialLdapContext(env,null);
		
		SSLContext ssctx = SSLContext.getInstance("TLSv1.2");
		ssctx.init(null, null, null);
		SSLContext.setDefault(ssctx); 
		
		// Start TLS
	    StartTlsResponse tls = (StartTlsResponse) ctx.extendedOperation(new StartTlsRequest());
	    
	    System.out.println("Starting TLS negotiate..");
	    SSLSession sess = tls.negotiate();
	    System.out.println("Session protocol: "+sess.getProtocol());
	    System.out.println("TLS negotiation complete.");
		
		//Authentication mechanism
	    ctx.addToEnvironment(Context.SECURITY_AUTHENTICATION, "simple");
		
	    String secPrincipal = "uid=" + userName.trim() + "," + LDAP_SEARCH_BASE;
		ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, secPrincipal);
		ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
		
			LDAPUserInfo userInfo = new LDAPUserInfo();
			Method[] methods = userInfo.getClass().getDeclaredMethods();
			
			Attributes attrColl = ctx.getAttributes(secPrincipal,ldapReturnAttributes);
			for (int iDx = 0; iDx < ldapReturnAttributes.length; iDx++) {
				attribute = attrColl.get(ldapReturnAttributes[iDx]);
				if(methods != null){
					for (int i = 0; i < methods.length; i++) {
						if(methods[i].getName().indexOf("set"+ldapReturnAttributes[iDx]) != -1){
							if(attribute != null){
								methods[i].invoke(userInfo, new Object[]{attribute.get()});
								break;
							}
						}
					}
				}
			}
			
			ldapResult = new AuthenticateResult(true);
			ldapResult.setUserInfo(userInfo);
			
			tls.close();
			
			ctx.close();
			return ldapResult;
		}catch(Exception exception){
			System.out.println("Exception while authenticating user ["+userName+"]:"+ exception.getMessage());
			if(exception.getMessage()!=null && exception.getMessage().trim().length()>0)
				return new AuthenticateResult(false,exception.getMessage());
			else 
				return new AuthenticateResult(false,exception.getCause().getMessage());
		}
	}

  public LDAPUserInfo extractUserProfile(String userName, boolean useSSL, String truststoreFileName, boolean logEnv2Debug) {
    LDAPUserInfo userInfo = new LDAPUserInfo();

    if ((truststoreFileName != null) && (truststoreFileName.trim().length() > 0)) {
      System.setProperty("javax.net.ssl.trustStore", truststoreFileName);
      System.setProperty("javax.net.ssl.trustStorePassword", "fedex666");
    }

    Hashtable env = new Hashtable();
    Attribute attribute = null;
    try
    {
      env.put("java.naming.factory.initial", INITIAL_CONTEXT_FACTORY);
      if (!isValidObject(LDAP_PROVIDER_URL)) {
        throw new Exception("LDAP URL is not configured in the ldap.properties file.");
      }

      env.put("java.naming.provider.url", LDAP_PROVIDER_URL + ":" + LDAP_PORT);

      env.put("java.naming.security.authentication", "none");
      env.put("java.naming.security.protocol", SECURITY_PROTOCOL);

      if (!isValidObject(LDAP_SEARCH_BASE)) {
        throw new Exception("The LDAP search base string is not configured in the ldap.properties file.");
      }

      if (logEnv2Debug)
      {
        envToString(env);
      }

      DirContext ctx = new InitialDirContext(env);

      Method[] methods = userInfo.getClass().getDeclaredMethods();

      BasicAttributes matchAttr = new BasicAttributes(true);
      matchAttr.put(new BasicAttribute("uid", userName));
      NamingEnumeration resultEnumeration = ctx.search(LDAP_SEARCH_BASE, matchAttr, LDAP_RETURN_ATTRIBUTES);
      Attributes attrCols = null;
      if (resultEnumeration.hasMoreElements()) {
        SearchResult result = (SearchResult)resultEnumeration.nextElement();
        attrCols = result.getAttributes();
        if ((attrCols != null) && (attrCols.size() > 0)) {
          for (int iDx = 0; iDx < LDAP_RETURN_ATTRIBUTES.length; iDx++) {
            attribute = attrCols.get(LDAP_RETURN_ATTRIBUTES[iDx]);
            if (methods != null) {
              for (int i = 0; i < methods.length; i++) {
                if ((methods[i].getName().indexOf("set" + LDAP_RETURN_ATTRIBUTES[iDx]) == -1) || 
                  (attribute == null)) continue;
                methods[i].invoke(userInfo, new Object[] { attribute.get() });
                break;
              }
            }
          }
        }
      }

    }
    catch (Exception localException)
    {
    }

    return userInfo;
  }

  private static String envToString(Hashtable<String, String> env) {
    StringBuffer buffer = new StringBuffer();
    String initialContextFactory = (String)env.get("java.naming.factory.initial");
    String providerURL = (String)env.get("java.naming.provider.url");
    String securityAuthentication = (String)env.get("java.naming.security.authentication");
    String securityProtocal = (String)env.get("java.naming.security.protocol");
    String securityPrincipal = (String)env.get("java.naming.security.principal");

    buffer.append("INITIAL_CONTEXT_FACTORY = " + initialContextFactory).append("\n");
    buffer.append("PROVIDER_URL = " + providerURL).append("\n");
    buffer.append("SECURITY_AUTHENTICATION = " + securityAuthentication).append("\n");
    buffer.append("SECURITY_PROTOCAL = " + securityProtocal).append("\n");
    buffer.append("SECURITY_PRINCIPAL = " + securityPrincipal).append("\n");
    return buffer.toString();
  }
}














/*package com.fedex.emea.sos.ldap;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.MissingResourceException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.StartTlsRequest;
import javax.naming.ldap.StartTlsResponse;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;

import com.fedex.emea.sos.ldap.StringUtils;



//import com.fedex.emea.sos.logger.ApplicationLogger;

public class LDAPAuthenticator extends LDAPAbstractAuthenticator {
	
	static String LDAP_PROVIDER_URL;
	static String LDAP_SEARCH_BASE;
	static String[] LDAP_RETURN_ATTRIBUTES;
	static String LDAP_INITIAL_CONTEXT_FACTORY;
	static String INITIAL_CONTEXT_FACTORY;
	static String LDAP_PORT;
	static String SECURITY_AUTHENTICATION;
	static String SECURITY_PROTOCOL;
	
 	protected LDAPAuthenticator(){}
 	
 	static {
 		try{
			Properties properties = new Properties();
			InputStream input = new LDAPAuthenticator().getClass().getClassLoader().getResourceAsStream("ldap.properties");
			properties.load(input);
			
			LDAP_INITIAL_CONTEXT_FACTORY = properties.getProperty("LDAP_INITIAL_CONTEXT_FACTORY");
			LDAP_PROVIDER_URL = properties.getProperty("LDAP_PROVIDER_URL");
			System.out.println(LDAP_PROVIDER_URL);
			LDAP_SEARCH_BASE = properties.getProperty("LDAP_SEARCH_BASE");
			INITIAL_CONTEXT_FACTORY = properties.getProperty("INITIAL_CONTEXT_FACTORY");
			LDAP_PORT = properties.getProperty("LDAP_PORT");
			SECURITY_AUTHENTICATION = properties.getProperty("SECURITY_AUTHENTICATION");
			SECURITY_PROTOCOL = properties.getProperty("SECURITY_PROTOCOL");
			
			//////System.out.println("LDAP_INITIAL_CONTEXT_FACTORY:"+LDAP_INITIAL_CONTEXT_FACTORY);
			String returnAttributes = properties.getProperty("LDAP_RETURN_ATTRIBUTES");

			if(isValidObject(returnAttributes)) {
				LDAP_RETURN_ATTRIBUTES = returnAttributes.split("\\,");
			}
 		} catch (MissingResourceException mrex) {
			mrex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
 	}
 	
 	private static boolean isValidObject(Object obj){
		if ( obj instanceof java.lang.String ){
			String str = (String) obj;
			if ( str == null || str.equals("null") || str.trim().length() == 0)
				return false;
			else
				return true;
		} else {
			if ( obj == null )
				return false;
			else
				return true;
		}
	}
 	
	public String getAuthenticatorMeans() {
		return "LDAP";
	}
	
	
	public static AuthenticateResult isUserAuthenticatedTLS(String userName,String password,
			String providerURL,String searchBase,String contextFactory,String[] ldapReturnAttributes,
			boolean useSSL,String truststoreFileName,boolean logEnv2Debug){
		try{
		String port = "389";//default LDAP port for TLS
		
		if(truststoreFileName!=null && truststoreFileName.trim().length()>0){//use provided trust store
			System.setProperty("javax.net.ssl.trustStore",truststoreFileName);
			System.setProperty("javax.net.ssl.trustStorePassword","changeit");
		}//else use default trust store
		
		//Set up the environment for creating the initial context
		Hashtable<String,String> env = new Hashtable<String,String>();
		Attribute attribute = null;
		AuthenticateResult ldapResult = null;
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
		if(!StringUtils.isValidString(providerURL)){
			throw new Exception("LDAP URL is not configured");
		}
		
		env.put(Context.PROVIDER_URL, providerURL+":"+port);
		
		//LDAP_SEARCH_BASE=uid=?,ou=People,o=fedex,c=us
		if(!StringUtils.isValidString(searchBase)){
			throw new Exception("The LDAP search base string is not configured");
		}
		
		//if(logEnv2Debug)
			//LogHelper.writeDebug("Authenticating the user against the LDAP ...\n"+envToString(env));

		//Create the initial context;
	
			InitialLdapContext  ctx= new InitialLdapContext(env,null);
		
		SSLContext ssctx = SSLContext.getInstance("TLSv1.2");
		ssctx.init(null, null, null);
		SSLContext.setDefault(ssctx); 
		
		// Start TLS
	    StartTlsResponse tls = (StartTlsResponse) ctx.extendedOperation(new StartTlsRequest());
	    
	   // LogHelper.writeDebug("Starting TLS negotiate..");
	    SSLSession sess = tls.negotiate();
		//LogHelper.writeDebug("Session protocol: "+sess.getProtocol());
	  //  LogHelper.writeDebug("TLS negotiation complete.");
		
		//Authentication mechanism
	    ctx.addToEnvironment(Context.SECURITY_AUTHENTICATION, "simple");
		
		String secPrincipal = "uid="+userName.trim()+","+searchBase;
		ctx.addToEnvironment(Context.SECURITY_PRINCIPAL, secPrincipal);
		ctx.addToEnvironment(Context.SECURITY_CREDENTIALS, password);
		
		LDAPUserInfo userInfo = new LDAPUserInfo();
			Method[] methods = userInfo.getClass().getDeclaredMethods();
			
			Attributes attrColl = ctx.getAttributes(secPrincipal,ldapReturnAttributes);
			for (int iDx = 0; iDx < ldapReturnAttributes.length; iDx++) {
				attribute = attrColl.get(ldapReturnAttributes[iDx]);
				if(methods != null){
					for (int i = 0; i < methods.length; i++) {
						if(methods[i].getName().indexOf("set"+ldapReturnAttributes[iDx]) != -1){
							if(attribute != null){
								methods[i].invoke(userInfo, new Object[]{attribute.get()});
								break;
							}
						}
					}
				}
			}
			
			ldapResult = new AuthenticateResult(true);
			ldapResult.setUserInfo(userInfo);
			
			tls.close();
			
			ctx.close();
			return ldapResult;
		}catch(Exception exception){
			//LogHelper.writeException("Exception while authenticating user ["+userName+"]", exception);
			if(exception.getMessage()!=null && exception.getMessage().trim().length()>0)
				return new AuthenticateResult(false,exception.getMessage());
			else 
				return new AuthenticateResult(false,exception.getCause().getMessage());
		}
	}
	
	public AuthenticateResult isUserAuthenticated(String userName,
			String password) throws Exception {
		String trustStoreFileName = ""; // Use JVM default trust store
		boolean useSSL = true;
		return isUserAuthenticated(userName,password,LDAP_RETURN_ATTRIBUTES, useSSL,trustStoreFileName,true);
	}
	
	public static AuthenticateResult isUserAuthenticated(String userName,String password,
			String[] ldapReturnAttributes,
			boolean useSSL,String truststoreFileName,boolean logEnv2Debug) throws Exception{
		
		if(truststoreFileName!=null && truststoreFileName.trim().length()>0){
			System.setProperty("javax.net.ssl.trustStore",truststoreFileName);
			System.setProperty("javax.net.ssl.trustStorePassword","fedex666");
		}
	  
		//Set up the environment for creating the initial context
		Hashtable<String, String> env = new Hashtable<String, String>();
		Attribute attribute = null;
		AuthenticateResult ldapResult = null;
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
		if(!isValidObject(LDAP_PROVIDER_URL)){
			throw new Exception("LDAP URL is not configured in the ldap.properties file.");
		}
		
		env.put(Context.PROVIDER_URL, LDAP_PROVIDER_URL+":"+LDAP_PORT);

		//Authentication mechanism
		env.put(Context.SECURITY_AUTHENTICATION, SECURITY_AUTHENTICATION );
		env.put(Context.SECURITY_PROTOCOL, SECURITY_PROTOCOL );
		
		//LDAP_SEARCH_BASE=uid=?,ou=People,o=fedex,c=us
		if(!isValidObject(LDAP_SEARCH_BASE)){
			throw new Exception("The LDAP search base string is not configured in the ldap.properties file.");
		}
		
		String secPrincipal = "uid="+userName.trim()+","+LDAP_SEARCH_BASE;
		env.put(Context.SECURITY_PRINCIPAL, secPrincipal);
		env.put(Context.SECURITY_CREDENTIALS, password);
		
		//Create the initial context
		try{
			DirContext ctx = new InitialDirContext(env);
			
			LDAPUserInfo userInfo = new LDAPUserInfo();
			Method[] methods = userInfo.getClass().getDeclaredMethods();
			
			Attributes attrCols = ctx.getAttributes(secPrincipal,ldapReturnAttributes);
    		Enumeration<?> idEnumn = attrCols.getIDs();
    		while (idEnumn.hasMoreElements()) {
    			String id = idEnumn.nextElement().toString();
    			id = id + "";
    		}
    		
			for (int iDx = 0; iDx < ldapReturnAttributes.length; iDx++) {
				attribute = attrCols.get(ldapReturnAttributes[iDx]);
				if(methods != null){
					for (int i = 0; i < methods.length; i++) {
						if(methods[i].getName().indexOf("set"+ldapReturnAttributes[iDx]) != -1){
							if(attribute != null){
								methods[i].invoke(userInfo, new Object[]{attribute.get()});
								break;
							}
						}
					}
				}
			}
			ldapResult = new AuthenticateResult(true);
			ldapResult.setUserInfo(userInfo);
		}catch(Exception exception){
			if(exception.getMessage()!=null && exception.getMessage().trim().length()>0) {
				return new AuthenticateResult(false,exception.getMessage());
			} else {
				return new AuthenticateResult(false,exception.getCause().getMessage());
			}
		}
		return ldapResult;
	}
	
	public LDAPUserInfo extractUserProfile(String userName, boolean useSSL,String truststoreFileName,boolean logEnv2Debug){
		LDAPUserInfo userInfo = new LDAPUserInfo();
		
		if(truststoreFileName!=null && truststoreFileName.trim().length()>0){//use provided trust store
			System.setProperty("javax.net.ssl.trustStore",truststoreFileName);
			System.setProperty("javax.net.ssl.trustStorePassword","fedex666");
		}//else use default trust store
		
		//Set up the environment for creating the initial context
		Hashtable<String, String> env = new Hashtable<String, String>();
		Attribute attribute = null;
		//AuthenticateResult ldapResult = null;
		
		try{
		
		env.put(Context.INITIAL_CONTEXT_FACTORY, INITIAL_CONTEXT_FACTORY);
		if(!isValidObject(LDAP_PROVIDER_URL)){
			throw new Exception("LDAP URL is not configured in the ldap.properties file.");
		}
		
		env.put(Context.PROVIDER_URL, LDAP_PROVIDER_URL+":"+LDAP_PORT);
		//no authentication
		env.put(Context.SECURITY_AUTHENTICATION, "none");
		env.put(Context.SECURITY_PROTOCOL, SECURITY_PROTOCOL );
		
		//LDAP_SEARCH_BASE=uid=?,ou=People,o=fedex,c=us
		if(!isValidObject(LDAP_SEARCH_BASE)){
			throw new Exception("The LDAP search base string is not configured in the ldap.properties file.");
		}
		
		if(logEnv2Debug)
		//ApplicationLogger.getInstance().log(Level.DEBUG,"Fetching the profile of user "+userName+" against the LDAP ...\n"+envToString(env));
		envToString(env);
		//Create the initial context
		
			DirContext ctx = new InitialDirContext(env);
			
			Method[] methods = userInfo.getClass().getDeclaredMethods();
			
			BasicAttributes matchAttr = new BasicAttributes(true);
			matchAttr.put(new BasicAttribute("uid", userName));
			NamingEnumeration<?> resultEnumeration = ctx.search(LDAP_SEARCH_BASE, matchAttr, LDAP_RETURN_ATTRIBUTES);
			Attributes attrCols = null;
			if(resultEnumeration.hasMoreElements()){
				SearchResult result = (SearchResult) resultEnumeration.nextElement();
				attrCols = result.getAttributes();
				if(attrCols!=null && attrCols.size()>0){
					for (int iDx = 0; iDx < LDAP_RETURN_ATTRIBUTES.length; iDx++) {
						attribute = attrCols.get(LDAP_RETURN_ATTRIBUTES[iDx]);
						if(methods != null){
							for (int i = 0; i < methods.length; i++) {
								if(methods[i].getName().indexOf("set"+LDAP_RETURN_ATTRIBUTES[iDx]) != -1){
									if(attribute != null){
										methods[i].invoke(userInfo, new Object[]{attribute.get()});
										break;
									}
								}
							}
						}
					}		
				}
			}
		}catch(Exception exception){
			//ApplicationLogger.getInstance().log(Level.ERROR,"UserId is: "+userName);
			//ApplicationLogger.getInstance().log(exception);
		}
		return userInfo;		
	}
	
	private static String envToString(Hashtable<String, String> env){
		StringBuffer buffer = new StringBuffer();
		String initialContextFactory = (String)env.get(Context.INITIAL_CONTEXT_FACTORY);
		String providerURL = (String)env.get(Context.PROVIDER_URL);
		String securityAuthentication = (String)env.get(Context.SECURITY_AUTHENTICATION);
		String securityProtocal = (String)env.get(Context.SECURITY_PROTOCOL);
		String securityPrincipal = (String)env.get(Context.SECURITY_PRINCIPAL);
		//we will not echo the SECURITY_CREDENTIALS 
		buffer.append("INITIAL_CONTEXT_FACTORY = "+initialContextFactory).append("\n");
		buffer.append("PROVIDER_URL = "+providerURL).append("\n");
		buffer.append("SECURITY_AUTHENTICATION = "+securityAuthentication).append("\n");
		buffer.append("SECURITY_PROTOCAL = "+securityProtocal).append("\n");
		buffer.append("SECURITY_PRINCIPAL = "+securityPrincipal).append("\n");
		return buffer.toString();
	}
}
*/