package com.fedex.dashboard.model;

import java.util.List;

public class DepandancyBean {
	private String name;
	private List<HubActivityBean> details;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<HubActivityBean> getDetails() {
		return details;
	}
	public void setDetails(List<HubActivityBean> details) {
		this.details = details;
	}
	@Override
	public String toString() {
		return "DepandancyBean [name=" + name + ", details=" + details + "]";
	}
	
}
