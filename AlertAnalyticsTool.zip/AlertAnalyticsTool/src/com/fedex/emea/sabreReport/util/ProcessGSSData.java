package com.fedex.emea.sabreReport.util;

import java.io.File;

import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.chart.AxisCrosses;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.BarDirection;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.XDDFBarChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.fedex.emea.sabreReport.model.SabreBean;

public class ProcessGSSData {
	
	public String saveData(List<SabreBean> gssData, String dateStr)
	{
		try
		{
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Input_Data");
        int columnCount = -1;
        int rowCount = -1;
        for(int i=0; i<gssData.size();i++)
        {
        	SabreBean bean = gssData.get(i);
        	Row row = sheet.createRow(++rowCount);
        	Cell cell = row.createCell(++columnCount);
        	cell.setCellValue(bean.getIncedent());
        	Cell cell2 = row.createCell(++columnCount);
        	cell2.setCellValue(bean.getCreated());
        	Cell cell3 = row.createCell(++columnCount);
        	cell3.setCellValue(bean.getShortDescr());
        	Cell cell4 = row.createCell(++columnCount);
        	cell4.setCellValue(bean.getAlertType());
        	Cell cell5 = row.createCell(++columnCount);
        	cell5.setCellValue(bean.getLocation());
        	columnCount = -1;
        }		  
        try {
        	String path = "";
        	try
        	{        		
    		JFrame parentFrame = new JFrame();      		 
    		JFileChooser fileChooser = new JFileChooser();
    		fileChooser.setDialogTitle("Specify a file to save");    		 
    		int userSelection = fileChooser.showSaveDialog(parentFrame);    		 
    		if (userSelection == JFileChooser.APPROVE_OPTION) {    			
			    File fileToSave = fileChooser.getSelectedFile();
			    path = fileToSave.getPath();
	    		}
        	}
    		catch(Exception e1)
    		{
    			System.out.println(e1.getMessage());
    			try
    			{
    			String home = System.getProperty("user.home");
            	String filename = "GSSReport_"+dateStr+".xlsx";
        		File file = new File(home+"/Downloads/"+filename);
        		path = file.getAbsolutePath();
    			}
    			catch(Exception e2)
    			{
    				System.out.println(e2.getMessage());
    			}
    		}
    			if(path == null || path.trim().equalsIgnoreCase(""))
    				path ="/opt/automationtools/Deployments/AAT_Reports/GSS/"+"GSSReport_"+dateStr+".xlsx";
    		    FileOutputStream outputStream = new FileOutputStream(path);
                workbook.write(outputStream);
                Map<String, Integer> alertTypeList = ProcessGSSUtil.getAllTypeData(gssData);
                if(alertTypeList != null && alertTypeList.size() != 0)
                	allTypeAlertChat(path, workbook, alertTypeList, "AllType Alerts");
                
                Map<String, Integer> alertCGNList = ProcessGSSUtil.getCGNData(gssData);
                if(alertCGNList != null && alertCGNList.size() != 0)
                	allTypeAlertChat(path, workbook, alertCGNList, "CGN");
                
                Map<String, Integer> alertCPHList = ProcessGSSUtil.getCPHData(gssData);
                if(alertCPHList != null && alertCPHList.size() != 0)
                	allTypeAlertChat(path, workbook, alertCPHList, "CPH");
                
                Map<String, Integer> alertCDGList = ProcessGSSUtil.getCDGData(gssData);
                if(alertCDGList != null && alertCDGList.size() != 0)
                	allTypeAlertChat(path, workbook, alertCDGList, "CDG");
                
                Map<String, Integer> alertMXPList = ProcessGSSUtil.getMXPData(gssData);
                if(alertMXPList != null && alertMXPList.size() != 0)
                	allTypeAlertChat(path, workbook, alertMXPList, "MXP");
                
                Map<String, Integer> alertDXBList = ProcessGSSUtil.getDXBData(gssData);
                if(alertDXBList != null && alertDXBList.size() != 0)
                	allTypeAlertChat(path, workbook, alertDXBList, "DXB");
                
                Map<String, Integer> alertSTNList = ProcessGSSUtil.getSTNData(gssData);
                if(alertSTNList != null && alertSTNList.size() != 0)
                	allTypeAlertChat(path, workbook, alertSTNList, "STN");
                
                Map<String, Integer> alertERRORList = ProcessGSSUtil.getERRORData(gssData);
                if(alertERRORList != null && alertERRORList.size() != 0)
                	allTypeAlertChat(path, workbook, alertERRORList, "ERROR");
                
                Map<String, Integer> alertJMSList = ProcessGSSUtil.getJMSData(gssData);
                if(alertJMSList != null && alertJMSList.size() != 0)
                	allTypeAlertChat(path, workbook, alertJMSList, "JMS");
                
                workbook.close();
                return path;
    		//}
        }
        catch(Exception e)
        {
        	System.out.println(e.getMessage());
        }
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return null;
	}
	
	
public static boolean allTypeAlertChat(String path, XSSFWorkbook wb, Map<String, Integer> alertTypeList, String sheetName) 
{
		try {
			XSSFSheet sheet = wb.createSheet(sheetName);

			// Create row and put some cells in it. Rows and cells are 0 based.
			int rowCount = 0;
			Row row = sheet.createRow((short) rowCount);
			row.setRowStyle(getBoldCSS(wb));
			Cell cell = row.createCell((short) 0);
			cell.setCellValue("Row Labels");
			cell = row.createCell((short) 1);			
			cell.setCellValue("Count of Number");
			for (Map.Entry<String, Integer> mapElement : alertTypeList.entrySet()) { 
	            String key = mapElement.getKey(); 
	            int value = mapElement.getValue();
	            if(value != 0)
	            {
		            row = sheet.createRow((short) ++rowCount);
		            cell = row.createCell((short) 0);
					cell.setCellValue(key);
					cell = row.createCell((short) 1);			
					cell.setCellValue(value);
	            }
	        }
			XSSFDrawing drawing = sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 3, 6, 12, 22);

			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText(sheetName);
			chart.setTitleOverlay(false);

			//XDDFChartLegend legend = chart.getOrAddLegend();
			//legend.setPosition(LegendPosition.TOP_RIGHT);
			
			XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            //bottomAxis.setTitle("x");
            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            //leftAxis.setTitle("y");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

			XDDFDataSource<String> alertTypes = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(1, (alertTypeList.size()), 0, 0));

			XDDFNumericalDataSource<Double> counts = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, (alertTypeList.size()), 1, 1));
			
			XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
            XDDFChartData.Series series1 = data.addSeries(alertTypes, counts);
            series1.setTitle(sheetName, null);
			data.setVaryColors(false);
			chart.plot(data);
			
			// in order to transform a bar chart into a column chart, you just need to change the bar direction
            XDDFBarChartData bar = (XDDFBarChartData) data;
            //bar.setBarDirection(BarDirection.BAR);
            bar.setBarDirection(BarDirection.COL);

			// Write output to an excel file
            String filename = path;
			try (FileOutputStream fileOut = new FileOutputStream(filename)) {
				wb.write(fileOut);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return true;
	}
public static CellStyle getBoldCSS(Workbook wb)
{
	CellStyle style = wb.createCellStyle();
	XSSFFont  defaultFont= (XSSFFont) wb.createFont();
    defaultFont.setFontName("Arial");
    defaultFont.setColor(IndexedColors.BLACK.getIndex());
    defaultFont.setBold(false);
    style.setFont(defaultFont);
    return style;
}


}
