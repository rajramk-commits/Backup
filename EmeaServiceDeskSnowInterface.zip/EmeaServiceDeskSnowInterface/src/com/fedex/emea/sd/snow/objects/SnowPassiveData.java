package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;

public class SnowPassiveData implements Serializable {

	private static final long serialVersionUID = 8680815924104910269L;
	
	private String sysId;
	private String description;
	
	public SnowPassiveData() {
	}
	
	public SnowPassiveData(String sysId, String description) {
		this.setSysId(sysId);
		this.setDescription(description);		
	}

	public String getSysId() {
		return sysId;
	}

	public void setSysId(String sysId) {
		this.sysId = sysId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
}
