package com.fedex.emea.sabreReport.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fedex.emea.sabreReport.constants.ReportConstants;
import com.fedex.emea.sabreReport.model.SabreBean;

public class ProcessData {
	
	public void saveData(List<SabreBean> data)
	{
		try
		{
		XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Data");
        int columnCount = -1;
        int rowCount = -1;
        for(int i=0; i<data.size();i++)
        {
        	SabreBean bean = data.get(i);
        	Row row = sheet.createRow(++rowCount);
        	Cell cell = row.createCell(++columnCount);
        	cell.setCellValue(bean.getIncedent());
        	Cell cell2 = row.createCell(++columnCount);
        	cell2.setCellValue(bean.getCreated());
        	Cell cell3 = row.createCell(++columnCount);
        	cell3.setCellValue(bean.getShortDescr());
        	Cell cell4 = row.createCell(++columnCount);
        	cell4.setCellValue(bean.getAlertType());
        	Cell cell5 = row.createCell(++columnCount);
        	cell5.setCellValue(bean.getLocation());
        	columnCount = -1;
        }
        
        XSSFSheet sheet2 = workbook.createSheet("FileSystem Data");
        int rowCount2 = 0;
        for(int i=0; i<data.size();i++)
        {
        	if(rowCount2 == 0)
        	{
        		Row row = sheet2.createRow(0);
            	Cell cell = row.createCell(0);
            	cell.setCellValue("Servers");
            	rowCount2++;
        	}
        	else
        	{
	        	SabreBean bean = data.get(i);
	        	String shrtDesc = bean.getShortDescr();
				if(shrtDesc.contains(".emea.fedex.com]"))
				{
		        	Row row = sheet2.createRow(rowCount2);
		        	Cell cell = row.createCell(0);
		        	int endIndx = shrtDesc.indexOf(".emea.fedex.com");
					String filysys = shrtDesc.substring(19,endIndx);
		        	cell.setCellValue(filysys+".emea.fedex.com");
		        	System.out.println(filysys+".emea.fedex.com");
		        	rowCount2++;
				}
        	}
        }
		  
        try {
        	FileOutputStream outputStream = new FileOutputStream(ReportConstants.DIRECTORY_PATH+"Input_File.xlsx");
            workbook.write(outputStream);
        }
        catch(Exception e)
        {
        	System.out.println(e.getMessage());
        }
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static Map<String, Integer> sortByValue(Map<String, Integer> map, final boolean order)   
	{  
	//convert HashMap into List   
	List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(map.entrySet());  
	//sorting the list elements  
	Collections.sort(list, new Comparator<Entry<String, Integer>>()   
		{  
		public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)   
		{  
			if (order)   
			{  
				//compare two object and return an integer  
				return o1.getValue().compareTo(o2.getValue());}   
			else   
			{  
				return o2.getValue().compareTo(o1.getValue());  
			}
		}
	});
	Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();  
	for (Entry<String, Integer> entry : list)   
	{  
	sortedMap.put(entry.getKey(), entry.getValue());  
	}  
	return sortedMap;  
	}
	
	public static Map<String, Integer> initializeAlertMap()
	{
		Map<String, Integer> alertTypeList = new HashMap<String, Integer>();
		alertTypeList.put("ProcessStopped", 0);
		alertTypeList.put("JMS Queue", 0);
		alertTypeList.put("Database Connection", 0);
		alertTypeList.put("FileSystem", 0);
		alertTypeList.put("Reprocessing", 0);
		alertTypeList.put("Operation", 0);
		alertTypeList.put("Other", 0);
		return alertTypeList;
	}
	
	public static Map<String, Integer> initializeProcessStoppedMap()
	{
		Map<String, Integer> processStoppedList = new HashMap<String, Integer>();
		processStoppedList.put("EMEA", 0);
		processStoppedList.put("CDG", 0);
		//processStoppedList.put("Other", 0);
		return processStoppedList;
	}

}
