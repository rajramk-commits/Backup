<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="com.fedex.emea.sabreReport.dao.ReportDao"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
String uID = request.getParameter("username");
String passWord = request.getParameter("passWord");
	String role= ReportDao.getRole(uID);
	if(role != null)
	{
		response.sendRedirect("reportType.jsp");
	}
	else
	{
		response.sendRedirect("Login.jsp?status=Invalid User Id or Password!!!");
	}
//}
%>
</body>
</html>