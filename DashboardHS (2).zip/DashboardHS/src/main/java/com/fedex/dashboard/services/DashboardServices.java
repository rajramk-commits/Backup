package com.fedex.dashboard.services;


import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fedex.dashboard.model.UserDataBean;
import com.fedex.dashboard.dao.DashboardDao;
import com.fedex.dashboard.dao.EpdsmDao;;

@Configuration
@PropertySource("classpath:application.properties")
@Service
public class DashboardServices {	

	private final static Logger logger = LogManager.getLogger(DashboardServices.class);
	
	public ResponseEntity<?> ServerWithLocation(String location) {
		try {
			return new ResponseEntity<>(DashboardDao.getHubDetails(location), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> locationList() {
		try {
			return new ResponseEntity<>(DashboardDao.getHubLocations(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> updateLocStatus(String hubLocation, List<String> appName, String action) {
		try {
			return new ResponseEntity<>(DashboardDao.updateSpecificStatus(hubLocation, appName, action), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> updateAllStatus(List<String> appName, String action) {
		try {
			return new ResponseEntity<>(DashboardDao.updateAllStatus(appName, action), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> getHubstackCCPriorityTickets() {
		try {
			return new ResponseEntity<>(EpdsmDao.getHubstackCCTickets(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	public ResponseEntity<?> getClearacnceCCPriorityTickets() {
		try {
			return new ResponseEntity<>(EpdsmDao.getClearanceCCTickets(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	public ResponseEntity<?> getHubstackCCTicketsCounts() {
		try {
			return new ResponseEntity<>(EpdsmDao.getCountHubstackCC(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	public ResponseEntity<?> getClearanceCCTicketsCounts() {
		try {
			return new ResponseEntity<>(EpdsmDao.getCountClearanceCC(), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> getDepAppDetails(String appName) {
		try {
			return new ResponseEntity<>(DashboardDao.getAppDep(appName), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> getUserDetails(UserDataBean userDetails) {
		try {
			return new ResponseEntity<>(DashboardDao.getUserDetails(userDetails.getUsername(), userDetails.getPassword()), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
	
	public ResponseEntity<?> updateDepServerDetails(LinkedHashMap<String, List<Map<String, ?>>> mapSet) {
		try {
			return new ResponseEntity<>(DashboardDao.insertImpDetails(mapSet), HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e);
			return new ResponseEntity<>("Somthing went wrong!!!", HttpStatus.BAD_REQUEST);
		}
	}
}
