package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class AlertMailingLists implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String alertSource;
	private String userPin;
	private String userMail;
	
	public AlertMailingLists() {
	}
	
	public AlertMailingLists(String alertSource, String userPin, String userMail) {
		this.alertSource = alertSource;
		this.userPin = userPin;
		this.userMail = userMail;
	}
	
	public AlertMailingLists(String alertSource, String userMail) {
		this.alertSource = alertSource;
		this.userMail = userMail;
	}

	public String getAlertSource() {
		return alertSource;
	}

	public void setAlertSource(String alertSource) {
		this.alertSource = alertSource;
	}

	public String getUserPin() {
		return userPin;
	}

	public void setUserPin(String userPin) {
		this.userPin = userPin;
	}

	public String getUserMail() {
		return userMail;
	}

	public void setUserMail(String userMail) {
		this.userMail = userMail;
	}
	
	
}
