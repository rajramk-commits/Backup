package com.fedex.emea.dimm.alert;

public class LogicalAlert extends AbstractAlert{

	private String logicalKey;
	
	public String getLogicalKey() {
		return logicalKey;
	}

	public void setLogicalKey(String logicalKey) {
		this.logicalKey = logicalKey;
	}
	
	@Override
	public String toString() {
		return "PhysicalAlert [getLogicalKey()=" + getLogicalKey()
				+ ", getServer()="
				+ getServer() + ", getComponent()=" + getComponent()
				+ ", getApplication()=" + getApplication() + ", getModule()="
				+ getModule() + ", getMessage()=" + getMessage()
				+ ", getAction()=" + getAction() + ", getDashboardName()="
				+ getDashboardName() + "]";
	}
	
}
