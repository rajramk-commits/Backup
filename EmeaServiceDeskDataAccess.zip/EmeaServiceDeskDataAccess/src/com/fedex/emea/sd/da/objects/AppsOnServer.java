package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class AppsOnServer implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String appName;
	private String appDesc;
	private String appBc;
	private String appStatus;
	private String appLocation;
	private String appRespMgr;
	private String appRole;
	private String appEnviron;
	private String srvName;
	private String srvDc;
	private String srvType;
	private String srvTypeDesc;
	private String srvStatus;
	private String srvOs;
	private String srvSoftRev;
	private String srvSoftVer;
	
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getAppDesc() {
		return appDesc;
	}
	public void setAppDesc(String appDesc) {
		this.appDesc = appDesc;
	}
	public String getAppBc() {
		return appBc;
	}
	public void setAppBc(String appBc) {
		this.appBc = appBc;
	}
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	public String getAppLocation() {
		return appLocation;
	}
	public void setAppLocation(String appLocation) {
		this.appLocation = appLocation;
	}
	public String getAppRespMgr() {
		return appRespMgr;
	}
	public void setAppRespMgr(String appRespMgr) {
		this.appRespMgr = appRespMgr;
	}
	public String getAppRole() {
		return appRole;
	}
	public void setAppRole(String appRole) {
		this.appRole = appRole;
	}
	public String getAppEnviron() {
		return appEnviron;
	}
	public void setAppEnviron(String appEnviron) {
		this.appEnviron = appEnviron;
	}
	public String getSrvName() {
		return srvName;
	}
	public void setSrvName(String srvName) {
		this.srvName = srvName;
	}
	public String getSrvDc() {
		return srvDc;
	}
	public void setSrvDc(String srvDc) {
		this.srvDc = srvDc;
	}
	public String getSrvType() {
		return srvType;
	}
	public void setSrvType(String srvType) {
		this.srvType = srvType;
	}
	public String getSrvTypeDesc() {
		return srvTypeDesc;
	}
	public void setSrvTypeDesc(String srvTypeDesc) {
		this.srvTypeDesc = srvTypeDesc;
	}
	public String getSrvStatus() {
		return srvStatus;
	}
	public void setSrvStatus(String srvStatus) {
		this.srvStatus = srvStatus;
	}
	public String getSrvOs() {
		return srvOs;
	}
	public void setSrvOs(String srvOs) {
		this.srvOs = srvOs;
	}
	public String getSrvSoftRev() {
		return srvSoftRev;
	}
	public void setSrvSoftRev(String srvSoftRev) {
		this.srvSoftRev = srvSoftRev;
	}
	public String getSrvSoftVer() {
		return srvSoftVer;
	}
	public void setSrvSoftVer(String srvSoftVer) {
		this.srvSoftVer = srvSoftVer;
	}
	
}
