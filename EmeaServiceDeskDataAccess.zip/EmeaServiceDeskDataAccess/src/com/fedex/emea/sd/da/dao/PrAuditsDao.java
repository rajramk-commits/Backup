package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrAuditsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrAudits;
import com.fedex.emea.sd.da.objects.PrAuditsPk;

public interface PrAuditsDao
{
	
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrAuditsDaoException;
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrAuditsDaoException;
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrAuditsPk
	 */
	public PrAuditsPk insert(PrAudits dto);

	/** 
	 * Updates a single row in the PR_AUDITS table.
	 */
	public void update(PrAuditsPk pk, PrAudits dto) throws PrAuditsDaoException;

	/** 
	 * Deletes a single row in the PR_AUDITS table.
	 */
	public void delete(PrAuditsPk pk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CY = :cy AND SYM_EAI_ID = :symEaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	public PrAudits findByPrimaryKey(String cy, String symEaiId, String ni2AppId) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria ''.
	 */
	public List<PrAudits> findAll() throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CY = :cy'.
	 */
	public List<PrAudits> findWhereCyEquals(String cy) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	public List<PrAudits> findWhereSymEaiIdEquals(String symEaiId) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	public List<PrAudits> findWhereNi2AppNameEquals(String ni2AppName) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	public List<PrAudits> findWhereRespMdPinEquals(String respMdPin) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	public List<PrAudits> findWhereRespMgrPinEquals(String respMgrPin) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_BI = :ni2Bi'.
	 */
	public List<PrAudits> findWhereNi2BiEquals(String ni2Bi) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'EAI_TIER = :eaiTier'.
	 */
	public List<PrAudits> findWhereEaiTierEquals(String eaiTier) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'MAIN_DC = :mainDc'.
	 */
	public List<PrAudits> findWhereMainDcEquals(String mainDc) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC = :bcRac'.
	 */
	public List<PrAudits> findWhereBcRacEquals(String bcRac) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC_WGT = :bcRacWgt'.
	 */
	public List<PrAudits> findWhereBcRacWgtEquals(int bcRacWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC_RISK = :bcRacRisk'.
	 */
	public List<PrAudits> findWhereBcRacRiskEquals(String bcRacRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL = :bcLocal'.
	 */
	public List<PrAudits> findWhereBcLocalEquals(String bcLocal) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL_WGT = :bcLocalWgt'.
	 */
	public List<PrAudits> findWhereBcLocalWgtEquals(int bcLocalWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL_RISK = :bcLocalRisk'.
	 */
	public List<PrAudits> findWhereBcLocalRiskEquals(String bcLocalRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE = :bcRemote'.
	 */
	public List<PrAudits> findWhereBcRemoteEquals(String bcRemote) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE_WGT = :bcRemoteWgt'.
	 */
	public List<PrAudits> findWhereBcRemoteWgtEquals(int bcRemoteWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE_RISK = :bcRemoteRisk'.
	 */
	public List<PrAudits> findWhereBcRemoteRiskEquals(String bcRemoteRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN = :cntgncyPlan'.
	 */
	public List<PrAudits> findWhereCntgncyPlanEquals(String cntgncyPlan) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN_WGT = :cntgncyPlanWgt'.
	 */
	public List<PrAudits> findWhereCntgncyPlanWgtEquals(int cntgncyPlanWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN_RISK = :cntgncyPlanRisk'.
	 */
	public List<PrAudits> findWhereCntgncyPlanRiskEquals(String cntgncyPlanRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC = :drDoc'.
	 */
	public List<PrAudits> findWhereDrDocEquals(String drDoc) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC_WGT = :drDocWgt'.
	 */
	public List<PrAudits> findWhereDrDocWgtEquals(int drDocWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC_RISK = :drDocRisk'.
	 */
	public List<PrAudits> findWhereDrDocRiskEquals(String drDocRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER = :drArcher'.
	 */
	public List<PrAudits> findWhereDrArcherEquals(String drArcher) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER_WGT = :drArcherWgt'.
	 */
	public List<PrAudits> findWhereDrArcherWgtEquals(int drArcherWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER_RISK = :drArcherRisk'.
	 */
	public List<PrAudits> findWhereDrArcherRiskEquals(String drArcherRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT = :drLastTestDt'.
	 */
	public List<PrAudits> findWhereDrLastTestDtEquals(Date drLastTestDt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT_WGT = :drLastTestDtWgt'.
	 */
	public List<PrAudits> findWhereDrLastTestDtWgtEquals(int drLastTestDtWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT_RISK = :drLastTestDtRisk'.
	 */
	public List<PrAudits> findWhereDrLastTestDtRiskEquals(String drLastTestDtRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC = :suppOc'.
	 */
	public List<PrAudits> findWhereSuppOcEquals(String suppOc) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC_WGT = :suppOcWgt'.
	 */
	public List<PrAudits> findWhereSuppOcWgtEquals(int suppOcWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC_RISK = :suppOcRisk'.
	 */
	public List<PrAudits> findWhereSuppOcRiskEquals(String suppOcRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF = :suppStaff'.
	 */
	public List<PrAudits> findWhereSuppStaffEquals(String suppStaff) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF_WGT = :suppStaffWgt'.
	 */
	public List<PrAudits> findWhereSuppStaffWgtEquals(int suppStaffWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF_RISK = :suppStaffRisk'.
	 */
	public List<PrAudits> findWhereSuppStaffRiskEquals(String suppStaffRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN = :suppTrain'.
	 */
	public List<PrAudits> findWhereSuppTrainEquals(String suppTrain) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN_WGT = :suppTrainWgt'.
	 */
	public List<PrAudits> findWhereSuppTrainWgtEquals(int suppTrainWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN_RISK = :suppTrainRisk'.
	 */
	public List<PrAudits> findWhereSuppTrainRiskEquals(String suppTrainRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU = :suppTecbu'.
	 */
	public List<PrAudits> findWhereSuppTecbuEquals(String suppTecbu) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU_WGT = :suppTecbuWgt'.
	 */
	public List<PrAudits> findWhereSuppTecbuWgtEquals(int suppTecbuWgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU_RISK = :suppTecbuRisk'.
	 */
	public List<PrAudits> findWhereSuppTecbuRiskEquals(String suppTecbuRisk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2 = :suppNi2'.
	 */
	public List<PrAudits> findWhereSuppNi2Equals(String suppNi2) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2_WGT = :suppNi2Wgt'.
	 */
	public List<PrAudits> findWhereSuppNi2WgtEquals(int suppNi2Wgt) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2_RISK = :suppNi2Risk'.
	 */
	public List<PrAudits> findWhereSuppNi2RiskEquals(String suppNi2Risk) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'COMMENTS = :comments'.
	 */
	public List<PrAudits> findWhereCommentsEquals(String comments) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RISK_FACTOR = :riskFactor'.
	 */
	public List<PrAudits> findWhereRiskFactorEquals(int riskFactor) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	public List<PrAudits> findWhereNi2AppIdEquals(String ni2AppId) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'AUDIT_STATUS = :auditStatus'.
	 */
	public List<PrAudits> findWhereAuditStatusEquals(String auditStatus) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	public List<PrAudits> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrAuditsDaoException;

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	public List<PrAudits> findWhereAuditIdEquals(int auditId) throws PrAuditsDaoException;

	/** 
	 * Returns the rows from the PR_AUDITS table that matches the specified primary-key value.
	 */
	public PrAudits findByPrimaryKey(PrAuditsPk pk) throws PrAuditsDaoException;

}
