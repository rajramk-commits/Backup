<%@page import="com.fedex.emea.onlinequiz.dao.QuizDao"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%

String Question = request.getParameter("Question");
String OptionA = request.getParameter("OptionA");
String OptionB = request.getParameter("OptionB");
String OptionC = request.getParameter("OptionC");
String OptionD = request.getParameter("OptionD");
String CorrectAns = request.getParameter("CorrectAns");

QuizDao dao = new QuizDao();


if(request.getParameter("Submit")!=null){
	dao.insertQues(Question, OptionA, OptionB, OptionC, OptionD, CorrectAns);
	request.setAttribute("showMessage", "Question Successfully Added");
	RequestDispatcher rd = request.getRequestDispatcher("AddQuestion.jsp");
	rd.forward(request, response);
}
else{
	request.setAttribute("showMessage", "Please check");
	RequestDispatcher rd = request.getRequestDispatcher("AddQuestion.jsp");
	rd.forward(request, response);
} %>
</body>
</html>