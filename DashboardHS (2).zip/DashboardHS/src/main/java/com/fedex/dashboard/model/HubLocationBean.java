package com.fedex.dashboard.model;

public class HubLocationBean {
	private String hubLocation;

	public String getHubLocation() {
		return hubLocation;
	}

	public void setHubLocation(String hubLocation) {
		this.hubLocation = hubLocation;
	}

	@Override
	public String toString() {
		return "HubLocationBean [hubLocation=" + hubLocation + "]";
	}

}
