package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.Parameters;

/** * RowMapper is used by Spring to read a line from a database table
 *  * and to fill an instance of the class with the values */

public final class ParametersRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		Parameters parametersLists = new Parameters();
		
		parametersLists.setParameterEntity(rs.getString("PARAMETERENTITY"));
		parametersLists.setParameterName(rs.getString("PARAMETERNAME"));
		parametersLists.setParameterValue1(rs.getString("PARAMETERVALUE1"));
		parametersLists.setParameterValue2(rs.getString("PARAMETERVALUE2"));
		parametersLists.setParameterValue3(rs.getString("PARAMETERVALUE3"));
		
		return parametersLists;	
	}
}
