package com.fedex.emea.sd.snow.manager;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.objects.SnowTasks;
import com.fedex.emea.sd.snow.objects.SnowUserGroups;
import com.fedex.emea.sd.snow.objects.SnowUsers;
import com.fedex.emea.sd.snow.objects.SnowAstcIncident;
import com.fedex.emea.sd.snow.objects.SnowCmdbCiServices;
import com.fedex.emea.sd.snow.objects.SnowCmdbCis;
import com.fedex.emea.sd.snow.objects.SnowCompanies;
import com.fedex.emea.sd.snow.objects.SnowCompositeIncidentData;
import com.fedex.emea.sd.snow.objects.SnowConnectionParameters;
import com.fedex.emea.sd.snow.objects.SnowCountries;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowIncidentMetrics;
import com.fedex.emea.sd.snow.objects.SnowIncidentSLA;
import com.fedex.emea.sd.snow.objects.SnowIncidentWorkNote;
import com.fedex.emea.sd.snow.objects.SnowLocations;
import com.fedex.emea.sd.snow.objects.SnowPassiveData;
import com.fedex.emea.sd.snow.objects.SnowProblemMetrics;
import com.fedex.emea.sd.snow.objects.SnowRequestMetrics;
import com.fedex.emea.sd.snow.objects.SnowRequestSLA;
import com.fedex.emea.sd.snow.utilities.SnowConstants;
import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowRequestor {
	private static SnowRESTCommunicator  sc;
	private static SnowHttpRequest       shr;
	
	//public SnowRequestor() {
	//	sc  = new SnowRESTCommunicator(SnowConstants.SNOW_PROD.getSnowDNS(), SnowConstants.SNOW_PROD.getSnowPort(), SnowConstants.SNOW_PROD.getSnowType(), SnowConstants.SNOW_PROD.getSnowUid(), SnowConstants.SNOW_PROD.getSnowPwd(), true);
	//	shr = new SnowHttpRequest(SnowConstants.SNOW_PROD.getSnowQueryTableURL(), SnowConstants.SNOW_PROD.getSnowQueryIncidentURL(), SnowConstants.SNOW_PROD.getSnowQueryAstcIncidentUpdateURL(), SnowConstants.SNOW_PROD.getSnowQuerySysJournalFieldURL(), SnowConstants.SNOW_PROD.getSnowQueryStatsURL(), sc.getConfig());
	//}
//	public SnowRequestor() {
//		sc  = new SnowRESTCommunicator(SnowConstants.EPDSM_UAT_DIRECT.getSnowDNS(), SnowConstants.EPDSM_UAT_DIRECT.getSnowPort(), SnowConstants.EPDSM_UAT_DIRECT.getSnowType(), SnowConstants.EPDSM_UAT_DIRECT.getSnowUid(), SnowConstants.EPDSM_UAT_DIRECT.getSnowPwd(), true);
//		shr = new SnowHttpRequest(SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryTableURL(), SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryIncidentURL(), SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryAstcIncidentUpdateURL(), SnowConstants.EPDSM_UAT_DIRECT.getSnowQuerySysJournalFieldURL(), SnowConstants.EPDSM_UAT_DIRECT.getSnowQueryStatsURL(), sc.getConfig());
//	}
	public SnowRequestor() {
		sc  = new SnowRESTCommunicator(SnowConstants.EPDSM_PROD_DIRECT.getSnowDNS(), SnowConstants.EPDSM_PROD_DIRECT.getSnowPort(), SnowConstants.EPDSM_PROD_DIRECT.getSnowType(), SnowConstants.EPDSM_PROD_DIRECT.getSnowUid(), SnowConstants.EPDSM_UAT_DIRECT.getSnowPwd(), true);
		shr = new SnowHttpRequest(SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryTableURL(), SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryIncidentURL(), SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryAstcIncidentUpdateURL(), SnowConstants.EPDSM_PROD_DIRECT.getSnowQuerySysJournalFieldURL(), SnowConstants.EPDSM_PROD_DIRECT.getSnowQueryStatsURL(), sc.getConfig());
	}
	public SnowRequestor(SnowConnectionParameters scp) {
		sc  = new SnowRESTCommunicator(scp.getSnowDNS(), scp.getSnowPort(), scp.getSnowType(), scp.getSnowUid(), scp.getSnowPwd(), scp.isUseProxy());
		shr = new SnowHttpRequest(scp.getSnowQueryTableURL(), scp.getSnowQueryIncidentURL(), scp.getSnowQueryAstcIncidentUpdateURL(), scp.getSnowQuerySysJournalFieldURL(), scp.getSnowQueryStatsURL(), sc.getConfig());
	}
	
	public List<HashMap<String, Object>> getTableContent(String tableName, String fields, List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		try {
			if (filters == null || filters.size() == 0) {
				fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToGet(shr.getTableRequest(tableName, fields)));
			} else {
				fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToGet(shr.getTableRequestByMultiFilters(tableName, fields, filters)));
			}
			
		} catch (Exception e) {
			throw e;
		}	
		return fieldsMapList;
	}
	
	public List<SnowPassiveData> getPassiveDataByTable(String tableName, SnowSearchFilter filter) throws Exception {
		List<SnowPassiveData>         passiveDataList = new ArrayList<SnowPassiveData>();
		SnowPassiveData               passiveData;
		List<HashMap<String, Object>> fieldsMapList;
		HashMap<String, Object>       fieldsMap;
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		
		if (filter != null) filters.add(filter);
		fieldsMapList   = getTableContent(tableName, "sys_id,name", filters);
		
		int resultsCount = fieldsMapList.size();
		
		for (int i = 1; i < resultsCount; i++) {
			fieldsMap = fieldsMapList.get(i);
			passiveData = new SnowPassiveData((String)fieldsMap.get("sys_id"),(String)fieldsMap.get("name"));
			passiveDataList.add(passiveData);
		}
		
		return passiveDataList;
	}
	
	public int getTableCount(String tableName, List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		int recordCount = 0;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToGet(shr.getStatsOnTableRequestByMultiFilters(tableName, filters)));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList != null && fieldsMapList.get(0) != null) {
			recordCount = Integer.parseInt((String) fieldsMapList.get(0).get("count"));
		}
		return recordCount;
	}
	
	public SnowUsers getUserBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowUsers user = new SnowUsers();
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_SYS_USER;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_SYS_USER, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getUserBySysId");
		if (!fieldsMapList.isEmpty()) user = new SnowUsers(fieldsMapList.get(0));
		
		return user;
	}
	
	public SnowUsers getUserByLdapId(String ldapId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowUsers user = new SnowUsers();
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("u_fedex_ldap_id", SnowConstants.OPER_EQUAL, ldapId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_SYS_USER;
		
		try {
			if (ldapId != null && !ldapId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_SYS_USER, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getUserByLdapId");
		if (!fieldsMapList.isEmpty()) user = new SnowUsers(fieldsMapList.get(0));
		
		return user;
	}
	
	public SnowCmdbCis getCmdbCiBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowCmdbCis cmdbCi = new SnowCmdbCis();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_CMDB_CI, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getCmdbCiBySysId");
		if (!fieldsMapList.isEmpty()) cmdbCi = new SnowCmdbCis(fieldsMapList.get(0));
		
		return cmdbCi;
	}
	
	public List<SnowCmdbCiServices> getAllFedExCmdbCiServices(String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("u_folder", SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX_ID));
		filters.add(new SnowSearchFilter("active",   SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_CMDB_CI_SERVICE;
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_CMDB_CI_SERVICE, fields, filters);
		} catch (Exception e) {
			throw  e;
		}
		
		return SnowUtilities.getCmdbCiServicesFromHashMap(fieldsMapList);
	}
	
	public List<SnowCmdbCiServices> getTop50TNTCmdbCiServices(String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("u_top50_application", SnowConstants.OPER_EQUAL, "Yes"));
		filters.add(new SnowSearchFilter("used_for",            SnowConstants.OPER_EQUAL, "Production"));
		filters.add(new SnowSearchFilter("u_blocked",           SnowConstants.OPER_EQUAL, "FALSE"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_CMDB_CI_SERVICE;
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_CMDB_CI_SERVICE, fields, filters);
		} catch (Exception e) {
			throw  e;
		}
		
		return SnowUtilities.getCmdbCiServicesFromHashMap(fieldsMapList);
	}
	
	public SnowCmdbCiServices getCmdbCiServiceBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowCmdbCiServices cmdbCiService = new SnowCmdbCiServices();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_CMDB_CI_SERVICE, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getCmdbCiServiceBySysId");
		if (!fieldsMapList.isEmpty()) cmdbCiService = new SnowCmdbCiServices(fieldsMapList.get(0));
		
		return cmdbCiService;
	}
	
	public List<SnowUserGroups> getAllFedExUserGroups(String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		List<SnowSearchFilter> filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("u_folder", SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX_ID));
		filters.add(new SnowSearchFilter("active",   SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_SYS_USER_GROUP;
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_SYS_USER_GROUP, fields, filters);
		} catch (Exception e) {
			throw  e;
		}
		
		return SnowUtilities.getUserGroupsFromHashMap(fieldsMapList);
	}
	
	public SnowUserGroups getUserGroupBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowUserGroups userGroup = new SnowUserGroups();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_SYS_USER_GROUP;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_SYS_USER_GROUP, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getUserGroupBySysId");
		if (!fieldsMapList.isEmpty()) userGroup = new SnowUserGroups(fieldsMapList.get(0));
		
		return userGroup;
	}
	
	public SnowCompanies getCompanyBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowCompanies company = new SnowCompanies();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_CORE_COMPANY;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_CORE_COMPANY, SnowConstants.FIELDS_CORE_COMPANY, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getCompanyBySysId");
		if (!fieldsMapList.isEmpty()) company = new SnowCompanies(fieldsMapList.get(0));
		
		return company;
	}
	
	public SnowCountries getCountryBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowCountries country = new SnowCountries();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_CORE_COUNTRY;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_CORE_COUNTRY, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getCountryBySysId");
		if (!fieldsMapList.isEmpty()) country = new SnowCountries(fieldsMapList.get(0));
		
		return country;
	}
	
	public SnowLocations getLocationBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowLocations location = new SnowLocations();
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		filters.add(new SnowSearchFilter("active", SnowConstants.OPER_EQUAL, "true"));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_CMN_LOCATION;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_CMN_LOCATION, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getLocationBySysId");
		if (!fieldsMapList.isEmpty()) location = new SnowLocations(fieldsMapList.get(0));
		
		return location;
	}
		
	public List<SnowIncidentWorkNote> getWorkNotesByIncidentSysId(String incidentSysId) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("element_id", SnowConstants.OPER_EQUAL, incidentSysId));
		filters.add(new SnowSearchFilter("element",    SnowConstants.OPER_EQUAL, "work_notes"));
		try {
			if (incidentSysId != null && !incidentSysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_SYS_JOURNAL_FIELD, null, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		List<SnowIncidentWorkNote> returnedList = SnowUtilities.getWorkNotesFromHashMap(fieldsMapList);
		
		// Sort Work Notes by Creation Date/Time
		//
		Collections.sort(returnedList, new Comparator<SnowIncidentWorkNote>() {
	        @Override
	        public int compare(SnowIncidentWorkNote note2, SnowIncidentWorkNote note1)
	        {
	        	Date date1 = SnowUtilities.formatToDateFromSNOW(note1.getWorkNoteSysCreatedOn());
	        	Date date2 = SnowUtilities.formatToDateFromSNOW(note2.getWorkNoteSysCreatedOn());
	            return  date1.compareTo(date2);
	        }
	    });
		
		return returnedList;
	}
	
	public SnowIncident getIncidentBySysId(String sysId, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowIncident incident = null;
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_EQUAL, sysId));
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_INCIDENT;
		
		try {
			if (sysId != null && !sysId.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
				
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getIncidentBySysId");
		if (!fieldsMapList.isEmpty()) incident = new SnowIncident(fieldsMapList.get(0));
		
		return incident;
	}

	public SnowIncident getIncidentByIncidentNbr(String incidentNbr, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowIncident incident = null;
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("number", SnowConstants.OPER_EQUAL, incidentNbr)); //Number = incidentNbr
		
		if (fields == null || fields.isEmpty()) fields = SnowConstants.FIELDS_INCIDENT;
		
		try {
			if (incidentNbr != null && !incidentNbr.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getIncidentByIncidentNbr");
		
		incident = new SnowIncident(fieldsMapList.get(0));
				
		return incident;
	}
	
	public HashMap<String,Object> getIncidentHashMapByIncidentNbr(String incidentNbr, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("number", SnowConstants.OPER_EQUAL, incidentNbr));
		
		try {
			if (incidentNbr != null && !incidentNbr.trim().isEmpty()) {
				fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT, fields, filters);
			}
		} catch (Exception e) {
			throw  e;
		}
				
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getIncidentHashMapByIncidentNbr");
		
		return fieldsMapList.get(0);
	}
	
	public List<SnowIncident> getIncidentsByListOfSysId(List<String> sysIdList) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		List<SnowSearchFilter>        filters = new ArrayList<SnowSearchFilter>();
		StringBuilder inString = new StringBuilder();
		
		if (sysIdList.isEmpty()) return null;
		
		for (String str: sysIdList) {
			if (inString.length() == 0) {
				inString.append(str);
			} else {
				inString.append("," + str);
			}
		}
		
		filters.add(new SnowSearchFilter("sys_id", SnowConstants.OPER_IN, inString.toString()));
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT, SnowConstants.FIELDS_INCIDENT, filters);
		} catch (Exception e) {
			throw  e;
		}
		
		return SnowUtilities.getIncidentsFromHashMap(fieldsMapList);
	}
	
	public List<SnowIncident> getIncidentsByFilters(List<SnowSearchFilter> filters, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT, fields, filters);
		} catch (Exception e) {
			throw  e;
		}
		
		return SnowUtilities.getIncidentsFromHashMap(fieldsMapList);
	}
			
	public List<SnowTasks> getTasksByFilters(List<SnowSearchFilter> filters, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_TASK, fields, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getTasksFromHashMap(fieldsMapList);
	}
	
	public SnowTasks getTaskByNbr(String incidentNbr, String fields) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		List<SnowSearchFilter>             filters  = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("number", SnowConstants.OPER_EQUAL, incidentNbr));
		SnowTasks task = null;
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_TASK, fields, filters);
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - getTaskByNbr");
		
		task = new SnowTasks(fieldsMapList.get(0));
				
		return task;
	}
	
	public List<SnowIncidentMetrics> getIncidentMetricsByFilters(List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT_METRIC, SnowConstants.FIELDS_INCIDENT_METRIC, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getIncidentMetricsFromHashMap(fieldsMapList);
	}
	
	public List<SnowRequestMetrics> getRequestMetricsByFilters(List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_REQUEST_METRIC, SnowConstants.FIELDS_REQUEST_METRIC, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getRequestMetricsFromHashMap(fieldsMapList);
	}
	
	public List<SnowProblemMetrics> getProblemMetricsByFilters(List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_PROBLEM_METRIC, null, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getProblemMetricsFromHashMap(fieldsMapList);
	}
	
	public List<SnowIncidentSLA> getIncidentSLAByFilters(List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_INCIDENT_SLA, null, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getIncidentSLAFromHashMap(fieldsMapList);
	}
	
	public List<SnowRequestSLA> getRequestSLAByFilters(List<SnowSearchFilter> filters) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		
		try {
			fieldsMapList = getTableContent(SnowConstants.TBL_REQUEST_SLA, null, filters);
		} catch (Exception e) {
			throw e;
		}	
		return SnowUtilities.getRequestSLAFromHashMap(fieldsMapList);
	}
	
	// TODO Here we are processing REQUEST
	
	public List<SnowCompositeIncidentData> getRequestMetricsByCriteria(Date caseCreationDate, Date caseCreationDateMax, String casePriority, String caseStatus, Date caseCloseDate, Date caseCloseDateMax, String[] selectedBusinessUnits, String caseArea, String caseService, String[] selectedGroups, String caseId, String caseSource, String[] createdByIds, String creationDateComp, String closeDateComp, List<SnowCmdbCiServices> cmdbCiServicesList, List<SnowUserGroups> cmdbUserGroupsList) throws Exception {
		
		List<SnowSearchFilter>               filters  = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("scr_u_folder", SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
		
		ArrayList<SnowCompositeIncidentData> scidList = new ArrayList<SnowCompositeIncidentData>();
		Calendar                             cal      = Calendar.getInstance();
		
		// ======================================================== CREATION DATE		
		if (caseCreationDate != null) {
			if (creationDateComp != null) {
				if (creationDateComp.trim().isEmpty()) {	// From/To Date
					filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCreationDate), SnowUtilities.formatDateForSNOW(caseCreationDateMax)));
				} else {
					cal.clear();
					cal.setTime(caseCreationDate);
					cal.add(Calendar.DAY_OF_MONTH, 1);
					Date endStartDate = cal.getTime();
					if (creationDateComp.equals("="))  filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCreationDate), SnowUtilities.formatDateForSNOW(endStartDate)));
					if (creationDateComp.equals(">"))  filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_GT, SnowUtilities.formatDateForSNOW(endStartDate)));
					if (creationDateComp.equals(">=")) filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_GE, SnowUtilities.formatDateForSNOW(caseCreationDate)));
					if (creationDateComp.equals("<"))  filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_LT, SnowUtilities.formatDateForSNOW(caseCreationDate)));
					if (creationDateComp.equals("<=")) filters.add(new SnowSearchFilter("scr_sys_created_on", SnowConstants.OPER_LE, SnowUtilities.formatDateForSNOW(endStartDate)));
				}
			}
		}
		
		// ======================================================== CLOSE DATE
		if (caseCloseDate != null) {
			if (closeDateComp != null) {
				if (closeDateComp.trim().isEmpty()) {	// From/To Date
					filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCloseDate), SnowUtilities.formatDateForSNOW(caseCloseDateMax)));
				} else {
					cal.clear();
					cal.setTime(caseCloseDate);
					cal.add(Calendar.DAY_OF_MONTH, 1);
					Date endCloseDate = cal.getTime();
					if (closeDateComp.equals("="))  filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCloseDate), SnowUtilities.formatDateForSNOW(endCloseDate)));
					if (closeDateComp.equals(">"))  filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_GT, SnowUtilities.formatDateForSNOW(endCloseDate)));
					if (closeDateComp.equals(">=")) filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_GE, SnowUtilities.formatDateForSNOW(caseCloseDate)));
					if (closeDateComp.equals("<"))  filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_LT, SnowUtilities.formatDateForSNOW(caseCloseDate)));
					if (closeDateComp.equals("<=")) filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_LE, SnowUtilities.formatDateForSNOW(endCloseDate)));
				}
			}
		}
		
		// ======================================================== STATUS
		if (!caseStatus.trim().isEmpty()) {
			if (caseStatus.equals("ALLO")) {
				filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_ISEMPTY, ""));
			} else {
				if (caseStatus.equals("ALLC")) {
					filters.add(new SnowSearchFilter("scr_closed_at", SnowConstants.OPER_ISNOTEMPTY, ""));
				} else {
					filters.add(new SnowSearchFilter("scr_state", SnowConstants.OPER_EQUAL, caseStatus));
				}
			}
		}
		
		// ======================================================== BUSINESS UNIT
		
		// ======================================================== OPERATIONAL GROUP
		if ((selectedGroups != null) && (selectedGroups.length > 0)) {
			String groupList = "";
			for (String gr: selectedGroups) {
				if (groupList.isEmpty()) {
					groupList = gr;
				} else {
					groupList = groupList + "," + gr;
				}
			}
			filters.add(new SnowSearchFilter("scr_u_support_structure", SnowConstants.OPER_IN, groupList));
		}
		
		// ======================================================== CREATED BY
		if ((createdByIds != null) && (createdByIds.length > 0)) {
			String idList = "";
			for (String id: createdByIds) {
				if (idList.isEmpty()) {
					idList = id;
				} else {
					idList = idList + "," + id;
				}
			}
			filters.add(new SnowSearchFilter("scr_sys_created_by", SnowConstants.OPER_IN, idList));
		}
		
		// ======================================================== TYPE
		filters.add(new SnowSearchFilter("scr_sys_class_name", SnowConstants.OPER_EQUAL, SnowConstants.SYS_CLASS_SRVREQ));
		
		// ======================================================== ID, PRIORITY, SOURCE, SERVICE
		if (!caseId.trim().isEmpty())       filters.add(new SnowSearchFilter("scr_number",             SnowConstants.OPER_EQUAL, caseId));
		if (!casePriority.trim().isEmpty()) filters.add(new SnowSearchFilter("scr_priority",           SnowConstants.OPER_EQUAL, casePriority));
		if (!caseSource.trim().isEmpty())   filters.add(new SnowSearchFilter("scr_contact_type",       SnowConstants.OPER_EQUAL, caseSource));
		if (!caseService.trim().isEmpty())  filters.add(new SnowSearchFilter("scr_u_business_service", SnowConstants.OPER_EQUAL, caseService));
		
		HashMap<String, ArrayList<SnowRequestMetrics>> hmMetricsPerRequest = new HashMap<String, ArrayList<SnowRequestMetrics>>();
		ArrayList<SnowRequestMetrics> alWorkingArray;
		
		try {
			List<SnowRequestMetrics> metrics =  getRequestMetricsByFilters(filters);
			
			List<SnowRequestMetrics> metricsByNumber = new ArrayList<SnowRequestMetrics>();
			SnowCompositeIncidentData scid;
			
			for (SnowRequestMetrics record: metrics) {
				alWorkingArray = new ArrayList<SnowRequestMetrics>();
				if (hmMetricsPerRequest.containsKey(record.getSnowScrNumber())) {
					alWorkingArray = hmMetricsPerRequest.get(record.getSnowScrNumber());
				}
				alWorkingArray.add(record);
				hmMetricsPerRequest.put(record.getSnowScrNumber(), alWorkingArray);
			}
			
			List<String> L1SupportGroupList    = new ArrayList<String>();
			List<String> L2SupportGroupList    = new ArrayList<String>();
			List<String> L3SupportGroupList    = new ArrayList<String>();
			List<String> OtherSupportGroupList = new ArrayList<String>();
			
			for (SnowUserGroups group: cmdbUserGroupsList) {
				if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_1)) L1SupportGroupList.add(group.getSnowName());
				else if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_2)) L2SupportGroupList.add(group.getSnowName());
				else if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_3)) L3SupportGroupList.add(group.getSnowName());
				else OtherSupportGroupList.add(group.getSnowName());
			}
			
			for (String key: hmMetricsPerRequest.keySet()) {
				metricsByNumber = hmMetricsPerRequest.get(key);
				scid = new SnowCompositeIncidentData(metricsByNumber.get(0));
				scid.setCasePriorityDescr(SnowConstants.PRIORITY_REQ_LIST.get(scid.getCasePriority()));
				scid.setCaseStatusDescr(SnowConstants.STATE_LIST.get(scid.getCaseStatus()));
				scid.setCaseSourceDescr(SnowConstants.CONTACT_MEDIUM_LIST.get(scid.getCaseSource()));
				scid.setCaseTypeDescr(SnowConstants.CATEGORY_LIST.get(scid.getCaseType()));
				scid.setCaseAssignedToName(null);	// CaseAssignedTo
				scid.setCaseContactName(null);		// CaseContact
				scid.setProviderGroupDescr(getUserGroupNameById(cmdbUserGroupsList, scid.getProviderGroupId()));
				scid.setCaseAreaId(getAreaByServiceId(cmdbCiServicesList, scid.getCaseServiceId()));
				scid.setCaseAreaDescr(getAreaByServiceId(cmdbCiServicesList, scid.getCaseServiceId()));
				scid.setCaseServiceDescr(getServiceNameById(cmdbCiServicesList, scid.getCaseServiceId()));

				// =====================================================================
				// Timings calculation
				//
				
				long      caseTimeUnassigned = 0;
				long      caseTimeOwnedByHelpdesk = 0;
				long      caseTimeOwnedByApplicationSupport = 0;
				long      caseTimeOwnedByOthers = 0;
				long      caseTimeOwnedByLevel3 = 0;
				long      caseTimeToClosure = 0;
				long      caseTimeToResolution = 0;
				long      caseTimeNotHandled = 0;
				boolean   caseEscalatedToSdApp  = false;
				boolean   caseEscalatedToLevel3 = false;
				boolean   caseEscalatedToOther  = false;
				boolean   caseInSLA = false;
				long      sumL1, sumL2, sumL3, sumOthers;
				
				cal = Calendar.getInstance();
				
				List<SnowRequestMetrics> assignmentsList = getListByFieldFromRequestMetrics(metricsByNumber, "assignment_group");
				List<SnowRequestMetrics> statesList      = getListByFieldFromRequestMetrics(metricsByNumber, "state");
				
				Date creationDate = SnowUtilities.formatToDateFromSNOW(metricsByNumber.get(0).getSnowScrSysCreatedOn());
				Date closeDate    = SnowUtilities.formatToDateFromSNOW(metricsByNumber.get(0).getSnowScrClosedAt());
				Date resolvedDate = null;
				
				// resolveDate			   = Date/Time of status change to RESOLVED or COMPLETED 
				String state = null;
				for (SnowRequestMetrics metric: statesList) {
					state = metric.getSnowMiFieldValue();
					if (!state.isEmpty() 
							&& (state.equals(SnowConstants.STATE_RESOLVED) || state.equals(SnowConstants.STATE_COMPLETED))) {
						resolvedDate = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart());
						break;
					}
				}
				
				// If not RESOLVED or COMPLETED, check if CLOSED => Resolved Date = Closed Date
				if (resolvedDate == null) {
					for (SnowRequestMetrics metric: statesList) {
						state = metric.getSnowMiFieldValue();
						if (!state.isEmpty() && state.equals(SnowConstants.STATE_CLOSED)) {
							resolvedDate = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart());
							break;
						}
					}
				}
				
				if (resolvedDate != null) {
					scid.setCaseResolvedDate(new Timestamp(resolvedDate.getTime()));
				} else {
					scid.setCaseResolvedDate(null);
				}
				
				// caseTimeUnassigned      = First "assignment_group" time - Creation time (System)
				Date firstAssignment;
				if (assignmentsList.size() > 0) {
					firstAssignment = SnowUtilities.formatToDateFromSNOW(assignmentsList.get(0).getSnowMiStart());
				} else {
					firstAssignment = cal.getTime();
				}
				caseTimeUnassigned = firstAssignment.getTime() - creationDate.getTime();
				
				// caseTimeOwnedByHelpdesk = Sum of "mi_duration" where "mi_value" = L1 and "mi_calculation_complete" = TRUE
				//                           + "mi_value" = L1 and "mi_calculation_complete" = FALSE, current_time - "mi_start"
				// caseTimeOwnedByApplicationSupport = Same logic with "mi_value" = L2
				// caseTimeOwnedByLevel3             = Same logic with "mi_value" = L3
				// caseTimeOwnedByOthers             = Same logic with "mi_value" not L1, L2, L3
				// caseEscalatedToSdApp    = At least one "mi_value" = L2
				// caseEscalatedToLevel3   = At least one "mi_value" = L3
				// caseEscalatedToOther    = At least one "mi_value" is not L1, L2 or L3
				sumL1     = 0;
				sumL2     = 0;
				sumL3     = 0;
				sumOthers = 0;
				
				Set<String> providerGroups = new TreeSet<String>();
				
				for (SnowRequestMetrics metric: assignmentsList) {
					providerGroups.add(metric.getSnowMiValue());
					
					if (L1SupportGroupList.contains(metric.getSnowMiValue())) {
						sumL1 = sumL1 + calculateDurationForRequest(metric, cal, resolvedDate, closeDate);
					}
					if (L2SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToSdApp = true;
						sumL2 = sumL2 + calculateDurationForRequest(metric, cal, resolvedDate, closeDate);
					}
					if (L3SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToLevel3 = true;
						sumL3 = sumL3 + calculateDurationForRequest(metric, cal, resolvedDate, closeDate);
					}
					if (!L1SupportGroupList.contains(metric.getSnowMiValue()) && !L2SupportGroupList.contains(metric.getSnowMiValue()) && !L3SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToOther = true;
						sumOthers = sumOthers + calculateDurationForRequest(metric, cal, resolvedDate, closeDate);
					}
				}
				
				caseTimeOwnedByHelpdesk           = sumL1;
				caseTimeOwnedByApplicationSupport = sumL2;			
				caseTimeOwnedByLevel3             = sumL3;
				caseTimeOwnedByOthers             = sumOthers;
				
				// caseTimeToClosure       = Closed On - Creation Time. If Closed On empty, current_time - Creation Time
				if (closeDate != null) {
					caseTimeToClosure = closeDate.getTime() - creationDate.getTime();
				} else {
					caseTimeToClosure = cal.getTimeInMillis() - creationDate.getTime();
				}
				
				// caseTimeToResolution    = Resolved On - Creation Time. If Resolved On empty, current_time - Creation Time
				if (resolvedDate != null) {
					caseTimeToResolution = resolvedDate.getTime() - creationDate.getTime();
				} else {
					caseTimeToResolution = cal.getTimeInMillis() - creationDate.getTime();
				}
				
				// caseTimeNotHandled      = Time until first state IN-PROGRESS (mi_start) from Creation Time
				long handledStart = 0;
				boolean handled = false;
				for (SnowRequestMetrics metric: statesList) {
					if (!metric.getSnowMiFieldValue().isEmpty() && !metric.getSnowMiFieldValue().equals(SnowConstants.STATE_OPEN) && !metric.getSnowMiFieldValue().equals(SnowConstants.STATE_REGISTERED)) {
						handledStart = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
						caseTimeNotHandled = handledStart - creationDate.getTime();
						handled = true;
						break;
					}
				}
				if (!handled) caseTimeNotHandled = cal.getTimeInMillis() - creationDate.getTime();
				
				// caseInSLA               = Resolution Time <= SLA Due  OR "taskslatable_has_breached" of SLA is FALSE
				if (scid.getCaseTimeSlaDue() != null) {
					if (scid.getCaseResolvedDate() != null) {
						if (!scid.getCaseResolvedDate().after(scid.getCaseTimeSlaDue())) {
							caseInSLA = true;
						} else {
							caseInSLA = false;
						}
					} else {
						if (!cal.getTime().after(scid.getCaseTimeSlaDue())) {
							caseInSLA = true;
						} else {
							caseInSLA = false;
						}
					}
				} else {
					caseInSLA = false;
				}
				
				scid.setCaseTimeUnassigned(caseTimeUnassigned);
				scid.setCaseTimeOwnedByHelpdesk(caseTimeOwnedByHelpdesk);
				scid.setCaseTimeOwnedByApplicationSupport(caseTimeOwnedByApplicationSupport);
				scid.setCaseTimeOwnedByLevel3(caseTimeOwnedByLevel3);
				scid.setCaseTimeOwnedByOthers(caseTimeOwnedByOthers);
				scid.setCaseTimeToClosure(caseTimeToClosure);
				scid.setCaseTimeToResolution(caseTimeToResolution);
				scid.setCaseTimeNotHandled(caseTimeNotHandled);
				scid.setCaseEscalatedToSdApp(caseEscalatedToSdApp);
				scid.setCaseEscalatedToLevel3(caseEscalatedToLevel3);
				scid.setCaseEscalatedToOther(caseEscalatedToOther);
				scid.setCaseInSLA(caseInSLA);
				scid.setCaseProviderGroupsList(providerGroups.toString());
				scidList.add(scid);
			}
						
		} catch (Exception e) {
			throw e;
		}
		
		return scidList;
	}
	
	// TODO Here we are processing INCIDENT
	
	public List<SnowCompositeIncidentData> getIncidentMetricsByCriteria(Date caseCreationDate, Date caseCreationDateMax, String casePriority, String caseStatus, Date caseCloseDate, Date caseCloseDateMax, String[] selectedBusinessUnits, String caseArea, String caseService, String[] selectedGroups, String caseId, String caseSource, String[] createdByIds, String creationDateComp, String closeDateComp, List<SnowCmdbCiServices> cmdbCiServicesList, List<SnowUserGroups> cmdbUserGroupsList) throws Exception {
		
		List<SnowSearchFilter>               filters  = new ArrayList<SnowSearchFilter>();
		filters.add(new SnowSearchFilter("inc_u_folder", SnowConstants.OPER_EQUAL, SnowConstants.U_FOLDER_FEDEX));
		
		ArrayList<SnowCompositeIncidentData> scidList = new ArrayList<SnowCompositeIncidentData>();
		Calendar                             cal      = Calendar.getInstance();
		
		// ======================================================== CREATION DATE		
		if (caseCreationDate != null) {
			if (creationDateComp != null) {
				if (creationDateComp.trim().isEmpty()) {	// From/To Date
					filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCreationDate), SnowUtilities.formatDateForSNOW(caseCreationDateMax)));
				} else {
					cal.clear();
					cal.setTime(caseCreationDate);
					cal.add(Calendar.DAY_OF_MONTH, 1);
					Date endStartDate = cal.getTime();
					if (creationDateComp.equals("="))  filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCreationDate), SnowUtilities.formatDateForSNOW(endStartDate)));
					if (creationDateComp.equals(">"))  filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_GT, SnowUtilities.formatDateForSNOW(endStartDate)));
					if (creationDateComp.equals(">=")) filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_GE, SnowUtilities.formatDateForSNOW(caseCreationDate)));
					if (creationDateComp.equals("<"))  filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_LT, SnowUtilities.formatDateForSNOW(caseCreationDate)));
					if (creationDateComp.equals("<=")) filters.add(new SnowSearchFilter("inc_sys_created_on", SnowConstants.OPER_LE, SnowUtilities.formatDateForSNOW(endStartDate)));
				}
			}
		}
		
		// ======================================================== CLOSE DATE
		if (caseCloseDate != null) {
			if (closeDateComp != null) {
				if (closeDateComp.trim().isEmpty()) {	// From/To Date
					filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCloseDate), SnowUtilities.formatDateForSNOW(caseCloseDateMax)));
				} else {
					cal.clear();
					cal.setTime(caseCloseDate);
					cal.add(Calendar.DAY_OF_MONTH, 1);
					Date endCloseDate = cal.getTime();
					if (closeDateComp.equals("="))  filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_BETWEEN, SnowUtilities.formatDateForSNOW(caseCloseDate), SnowUtilities.formatDateForSNOW(endCloseDate)));
					if (closeDateComp.equals(">"))  filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_GT, SnowUtilities.formatDateForSNOW(endCloseDate)));
					if (closeDateComp.equals(">=")) filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_GE, SnowUtilities.formatDateForSNOW(caseCloseDate)));
					if (closeDateComp.equals("<"))  filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_LT, SnowUtilities.formatDateForSNOW(caseCloseDate)));
					if (closeDateComp.equals("<=")) filters.add(new SnowSearchFilter("inc_resolved_at", SnowConstants.OPER_LE, SnowUtilities.formatDateForSNOW(endCloseDate)));
				}
			}
		}
		
		// ======================================================== STATUS
		if (!caseStatus.trim().isEmpty()) {
			if (caseStatus.equals("ALLO")) {
				filters.add(new SnowSearchFilter("inc_closed_at", SnowConstants.OPER_ISEMPTY, ""));
			} else {
				if (caseStatus.equals("ALLC")) {
					filters.add(new SnowSearchFilter("inc_closed_at", SnowConstants.OPER_ISNOTEMPTY, ""));
				} else {
					filters.add(new SnowSearchFilter("inc_state", SnowConstants.OPER_EQUAL, caseStatus));
				}
			}
		}
		
		// ======================================================== BUSINESS UNIT
		
		// ======================================================== OPERATIONAL GROUP
		if ((selectedGroups != null) && (selectedGroups.length > 0)) {
			String groupList = "";
			for (String gr: selectedGroups) {
				if (groupList.isEmpty()) {
					groupList = gr;
				} else {
					groupList = groupList + "," + gr;
				}
			}
			filters.add(new SnowSearchFilter("inc_u_support_structure", SnowConstants.OPER_IN, groupList));
		}
		
		// ======================================================== CREATED BY
		if ((createdByIds != null) && (createdByIds.length > 0)) {
			String idList = "";
			for (String id: createdByIds) {
				if (idList.isEmpty()) {
					idList = id;
				} else {
					idList = idList + "," + id;
				}
			}
			filters.add(new SnowSearchFilter("inc_sys_created_by", SnowConstants.OPER_IN, idList));
		}
		
		// ======================================================== TYPE
		filters.add(new SnowSearchFilter("inc_sys_class_name", SnowConstants.OPER_EQUAL, SnowConstants.SYS_CLASS_INCIDENT));
		
		// ======================================================== ID, PRIORITY, SOURCE, SERVICE
		if (!caseId.trim().isEmpty())       filters.add(new SnowSearchFilter("inc_number",             SnowConstants.OPER_EQUAL, caseId));
		if (!casePriority.trim().isEmpty()) filters.add(new SnowSearchFilter("inc_priority",           SnowConstants.OPER_EQUAL, casePriority));
		if (!caseSource.trim().isEmpty())   filters.add(new SnowSearchFilter("inc_contact_type",       SnowConstants.OPER_EQUAL, caseSource));
		if (!caseService.trim().isEmpty())  filters.add(new SnowSearchFilter("inc_u_business_service", SnowConstants.OPER_EQUAL, caseService));
		
		HashMap<String, ArrayList<SnowIncidentMetrics>> hmMetricsPerIncident = new HashMap<String, ArrayList<SnowIncidentMetrics>>();
		ArrayList<SnowIncidentMetrics> alWorkingArray;
		
		try {
			List<SnowIncidentMetrics> metrics =  getIncidentMetricsByFilters(filters);
			
			List<SnowIncidentMetrics> metricsByNumber = new ArrayList<SnowIncidentMetrics>();
			SnowCompositeIncidentData scid;
			
			for (SnowIncidentMetrics record: metrics) {
				alWorkingArray = new ArrayList<SnowIncidentMetrics>();
				if (hmMetricsPerIncident.containsKey(record.getSnowIncNumber())) {
					alWorkingArray = hmMetricsPerIncident.get(record.getSnowIncNumber());
				}
				alWorkingArray.add(record);
				hmMetricsPerIncident.put(record.getSnowIncNumber(), alWorkingArray);
			}
			
			List<String> L1SupportGroupList    = new ArrayList<String>();
			List<String> L2SupportGroupList    = new ArrayList<String>();
			List<String> L3SupportGroupList    = new ArrayList<String>();
			List<String> OtherSupportGroupList = new ArrayList<String>();
			
			for (SnowUserGroups group: cmdbUserGroupsList) {
				if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_1)) L1SupportGroupList.add(group.getSnowName());
				else if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_2)) L2SupportGroupList.add(group.getSnowName());
				else if (group.getSnowU_WorkgroupRole().equals(SnowConstants.WORKGROUP_ROLE_3)) L3SupportGroupList.add(group.getSnowName());
				else OtherSupportGroupList.add(group.getSnowName());
			}
			
			for (String key: hmMetricsPerIncident.keySet()) {
				metricsByNumber = hmMetricsPerIncident.get(key);
				scid = new SnowCompositeIncidentData(metricsByNumber.get(0));
				scid.setCasePriorityDescr(SnowConstants.PRIORITY_LIST.get(scid.getCasePriority()));
				scid.setCaseStatusDescr(SnowConstants.STATE_LIST.get(scid.getCaseStatus()));
				scid.setCaseSourceDescr(SnowConstants.CONTACT_MEDIUM_LIST.get(scid.getCaseSource()));
				scid.setCaseTypeDescr(SnowConstants.CATEGORY_LIST.get(scid.getCaseType()));
				scid.setCaseAssignedToName(null);	// CaseAssignedTo
				scid.setCaseContactName(null);		// CaseContact
				scid.setProviderGroupDescr(getUserGroupNameById(cmdbUserGroupsList, scid.getProviderGroupId()));
				scid.setCaseAreaId(getAreaByServiceId(cmdbCiServicesList, scid.getCaseServiceId()));
				scid.setCaseAreaDescr(getAreaByServiceId(cmdbCiServicesList, scid.getCaseServiceId()));
				scid.setCaseServiceDescr(getServiceNameById(cmdbCiServicesList, scid.getCaseServiceId()));

				// =====================================================================
				// Timings calculation
				//
				
				long      caseTimeUnassigned = 0;
				long      caseTimeOwnedByHelpdesk = 0;
				long      caseTimeOwnedByApplicationSupport = 0;
				long      caseTimeOwnedByOthers = 0;
				long      caseTimeOwnedByLevel3 = 0;
				long      caseTimeToClosure = 0;
				long      caseTimeToResolution = 0;
				long      caseTimeNotHandled = 0;
				boolean   caseEscalatedToSdApp  = false;
				boolean   caseEscalatedToLevel3 = false;
				boolean   caseEscalatedToOther  = false;
				boolean   caseInSLA = false;
				long      sumL1, sumL2, sumL3, sumOthers;
				
				cal = Calendar.getInstance();
				
				List<SnowIncidentMetrics> assignmentsList = getListByFieldFromIncidentMetrics(metricsByNumber, "assignment_group");
				List<SnowIncidentMetrics> statesList      = getListByFieldFromIncidentMetrics(metricsByNumber, "state");
				
				Date creationDate = SnowUtilities.formatToDateFromSNOW(metricsByNumber.get(0).getSnowIncSysCreatedOn());
				Date closeDate    = SnowUtilities.formatToDateFromSNOW(metricsByNumber.get(0).getSnowIncClosedAt());
				Date resolveDate  = SnowUtilities.formatToDateFromSNOW(metricsByNumber.get(0).getSnowIncResolvedAt());
				
				// caseTimeUnassigned      = First "assignment_group" time - Creation time (System)
				Date firstAssignment;
				if (assignmentsList.size() > 0) {
					firstAssignment = SnowUtilities.formatToDateFromSNOW(assignmentsList.get(0).getSnowMiStart());
				} else {
					firstAssignment = cal.getTime();
				}
				caseTimeUnassigned = firstAssignment.getTime() - creationDate.getTime();
				
				// caseTimeOwnedByHelpdesk = Sum of "mi_duration" where "mi_value" = L1 and "mi_calculation_complete" = TRUE
				//                           + "mi_value" = L1 and "mi_calculation_complete" = FALSE, current_time - "mi_start"
				// caseTimeOwnedByApplicationSupport = Same logic with "mi_value" = L2
				// caseTimeOwnedByLevel3             = Same logic with "mi_value" = L3
				// caseTimeOwnedByOthers             = Same logic with "mi_value" not L1, L2, L3
				// caseEscalatedToSdApp    = At least one "mi_value" = L2
				// caseEscalatedToLevel3   = At least one "mi_value" = L3
				// caseEscalatedToOther    = At least one "mi_value" is not L1, L2 or L3
				sumL1     = 0;
				sumL2     = 0;
				sumL3     = 0;
				sumOthers = 0;
				
				Set<String> providerGroups = new TreeSet<String>();
				
				for (SnowIncidentMetrics metric: assignmentsList) {
					providerGroups.add(metric.getSnowMiValue());
					
					if (L1SupportGroupList.contains(metric.getSnowMiValue())) {
						sumL1 = sumL1 + calculateDurationForIncident(metric, cal, resolveDate, closeDate);
					}
					if (L2SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToSdApp = true;
						sumL2 = sumL2 + calculateDurationForIncident(metric, cal, resolveDate, closeDate);
					}
					if (L3SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToLevel3 = true;
						sumL3 = sumL3 + calculateDurationForIncident(metric, cal, resolveDate, closeDate);
					}
					if (!L1SupportGroupList.contains(metric.getSnowMiValue()) && !L2SupportGroupList.contains(metric.getSnowMiValue()) && !L3SupportGroupList.contains(metric.getSnowMiValue())) {
						caseEscalatedToOther = true;
						sumOthers = sumOthers + calculateDurationForIncident(metric, cal, resolveDate, closeDate);
					}
				}
				
				caseTimeOwnedByHelpdesk           = sumL1;
				caseTimeOwnedByApplicationSupport = sumL2;			
				caseTimeOwnedByLevel3             = sumL3;
				caseTimeOwnedByOthers             = sumOthers;
				
				// caseTimeToClosure       = Closed On - Creation Time. If Closed On empty, current_time - Creation Time
				if (closeDate != null) {
					caseTimeToClosure = closeDate.getTime() - creationDate.getTime();
				} else {
					caseTimeToClosure = cal.getTimeInMillis() - creationDate.getTime();
				}
				
				// caseTimeToResolution    = Resolved On - Creation Time. If Resolved On empty, current_time - Creation Time
				if (resolveDate != null) {
					caseTimeToResolution = resolveDate.getTime() - creationDate.getTime();
				} else {
					caseTimeToResolution = cal.getTimeInMillis() - creationDate.getTime();
				}
				
				// caseTimeNotHandled      = Time until first state IN-PROGRESS (mi_start) from Creation Time
				long handledStart = 0;
				boolean handled = false;
				for (SnowIncidentMetrics metric: statesList) {
					if (!metric.getSnowMiFieldValue().isEmpty() && !metric.getSnowMiFieldValue().equals(SnowConstants.STATE_OPEN) && !metric.getSnowMiFieldValue().equals(SnowConstants.STATE_REGISTERED)) {
						handledStart = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
						caseTimeNotHandled = handledStart - creationDate.getTime();
						handled = true;
						break;
					}
				}
				if (!handled) caseTimeNotHandled = cal.getTimeInMillis() - creationDate.getTime();
				
				// caseInSLA               = Resolution Time <= SLA Due  OR "taskslatable_has_breached" of SLA is FALSE
				if (scid.getCaseTimeSlaDue() != null) {
					if (scid.getCaseResolvedDate() != null) {
						if (!scid.getCaseResolvedDate().after(scid.getCaseTimeSlaDue())) {
							caseInSLA = true;
						} else {
							caseInSLA = false;
						}
					} else {
						if (!cal.getTime().after(scid.getCaseTimeSlaDue())) {
							caseInSLA = true;
						} else {
							caseInSLA = false;
						}
					}
				} else {
					caseInSLA = false;
				}
				
				scid.setCaseTimeUnassigned(caseTimeUnassigned);
				scid.setCaseTimeOwnedByHelpdesk(caseTimeOwnedByHelpdesk);
				scid.setCaseTimeOwnedByApplicationSupport(caseTimeOwnedByApplicationSupport);
				scid.setCaseTimeOwnedByLevel3(caseTimeOwnedByLevel3);
				scid.setCaseTimeOwnedByOthers(caseTimeOwnedByOthers);
				scid.setCaseTimeToClosure(caseTimeToClosure);
				scid.setCaseTimeToResolution(caseTimeToResolution);
				scid.setCaseTimeNotHandled(caseTimeNotHandled);
				scid.setCaseEscalatedToSdApp(caseEscalatedToSdApp);
				scid.setCaseEscalatedToLevel3(caseEscalatedToLevel3);
				scid.setCaseEscalatedToOther(caseEscalatedToOther);
				scid.setCaseInSLA(caseInSLA);
				scid.setCaseProviderGroupsList(providerGroups.toString());
				scidList.add(scid);
			}
						
		} catch (Exception e) {
			throw e;
		}
		
		return scidList;
	}
	
	private long calculateDurationForIncident(SnowIncidentMetrics metric, Calendar cal, Date resolveDate, Date closeDate) {
		long duration = 0, endLimit = 0;
		
		if (metric.getSnowMiCalculationComplete().equals("true")) {
			long startTime = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
			long endTime   = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiEnd()).getTime();
			if (closeDate != null && endTime > closeDate.getTime()) endTime = closeDate.getTime();
			duration = endTime - startTime;
		} else {
			long startTime = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
			if (resolveDate != null) endLimit = resolveDate.getTime();
			else if (closeDate != null) endLimit = closeDate.getTime();
			else endLimit = cal.getTimeInMillis();
			
			if ((closeDate == null && resolveDate == null) || (closeDate != null && startTime < closeDate.getTime()) || (resolveDate != null && startTime < resolveDate.getTime())) {
				duration = endLimit - startTime;
			}
		}
		
		return duration;
	}
	
	private long calculateDurationForRequest(SnowRequestMetrics metric, Calendar cal, Date resolveDate, Date closeDate) {
		long duration = 0, endLimit = 0;
		
		if (metric.getSnowMiCalculationComplete().equals("true")) {
			long startTime = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
			long endTime   = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiEnd()).getTime();
			if (closeDate != null && endTime > closeDate.getTime()) endTime = closeDate.getTime();
			duration = endTime - startTime;
		} else {
			long startTime = SnowUtilities.formatToDateFromSNOW(metric.getSnowMiStart()).getTime();
			if (resolveDate != null) endLimit = resolveDate.getTime();
			else if (closeDate != null) endLimit = closeDate.getTime();
			else endLimit = cal.getTimeInMillis();
			
			if ((closeDate == null && resolveDate == null) || (closeDate != null && startTime < closeDate.getTime()) || (resolveDate != null && startTime < resolveDate.getTime())) {
				duration = endLimit - startTime;
			}
		}
		
		return duration;
	}
	
	private String getAreaByServiceId(List<SnowCmdbCiServices> cmdbCiServicesList, String id) {
		String area = "Unknown";
		
		for (SnowCmdbCiServices service: cmdbCiServicesList) {
			if (service.getSnowSysId().equals(id)) {
				area = service.getSnowU_ServiceCategory();
				break;
			}
		}
		
		return area;
	}
	
	private String getServiceNameById(List<SnowCmdbCiServices> cmdbCiServicesList, String id) {
		String serviceName = "Unknown";
		
		for (SnowCmdbCiServices service: cmdbCiServicesList) {
			if (service.getSnowSysId().equals(id)) {
				serviceName = service.getSnowName();
				break;
			}
		}
		
		return serviceName;
	}
	
	private String getUserGroupNameById(List<SnowUserGroups> cmdbUserGroupsList, String id) {
		String groupName = "Unknown";
		for (SnowUserGroups group: cmdbUserGroupsList) {
			if (group.getSnowSysId().equals(id)) {
				groupName = group.getSnowName();
				break;
			}
		}
		return groupName;
	}
	
	private static List<SnowIncidentMetrics> getListByFieldFromIncidentMetrics(List<SnowIncidentMetrics> metrics, String value) {
		List<SnowIncidentMetrics> newList = new ArrayList<SnowIncidentMetrics>();
		for (SnowIncidentMetrics metric: metrics) {
			if (metric.getSnowMdField().equals(value)) {
				newList.add(metric);
			}
		}
		
		Collections.sort(newList, new Comparator<SnowIncidentMetrics>() {
	        @Override
	        public int compare(SnowIncidentMetrics obj2, SnowIncidentMetrics obj1)
	        {
	        	Date date1 = SnowUtilities.formatToDateFromSNOW(obj1.getSnowMiStart());
	        	Date date2 = SnowUtilities.formatToDateFromSNOW(obj2.getSnowMiStart());
	            return  date2.compareTo(date1);
	        }
	    });
		
		return newList;
	}
	
	private static List<SnowRequestMetrics> getListByFieldFromRequestMetrics(List<SnowRequestMetrics> metrics, String value) {
		List<SnowRequestMetrics> newList = new ArrayList<SnowRequestMetrics>();
		for (SnowRequestMetrics metric: metrics) {
			if (metric.getSnowMdField().equals(value)) {
				newList.add(metric);
			}
		}
		
		Collections.sort(newList, new Comparator<SnowRequestMetrics>() {
	        @Override
	        public int compare(SnowRequestMetrics obj2, SnowRequestMetrics obj1)
	        {
	        	Date date1 = SnowUtilities.formatToDateFromSNOW(obj1.getSnowMiStart());
	        	Date date2 = SnowUtilities.formatToDateFromSNOW(obj2.getSnowMiStart());
	            return  date2.compareTo(date1);
	        }
	    });
		
		return newList;
	}
	
	public SnowIncident createIncident(SnowIncident newIncident) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowIncident incident = null;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToPost(shr.postIncidentRequest(newIncident.toJSON())));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - createIncident");
		
		incident = new SnowIncident(fieldsMapList.get(0));
		
		return incident;
	}
	
	public SnowAstcIncident createAstcIncident(SnowAstcIncident newIncident) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowAstcIncident incident = null;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToPost(shr.postIncidentRequest(newIncident.toJSON())));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - createIncident");
		
		incident = new SnowAstcIncident(fieldsMapList.get(0));
		
		return incident;
	}
	
	public SnowAstcIncident updateAstcIncident(SnowAstcIncident updateIncident) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowAstcIncident incident = null;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToPost(shr.postAstcIncidentUpdateRequest(updateIncident.toJSON())));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - createIncident");
		
		incident = new SnowAstcIncident(fieldsMapList.get(0));
		
		return incident;
	}
	
	public SnowIncident updateIncident(String sysId, SnowIncident updatedIncident) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowIncident incident = null;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToPut(shr.putIncidentRequest(sysId, updatedIncident.toJSON())));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - updateIncident");
		
		incident = new SnowIncident(fieldsMapList.get(0));
		
		return incident;
	}
	
	public List<SnowIncident> deleteIncidentBySysId(String sysId) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToDelete(shr.deleteIncidentRequest(sysId)));
		} catch (Exception e) {
			throw e;
		}
		
		return SnowUtilities.getIncidentsFromHashMap(fieldsMapList);
	}
	
	public SnowIncidentWorkNote createWorkNote(SnowIncidentWorkNote newWorkNote) throws Exception {
		List<HashMap<String, Object>> fieldsMapList = new ArrayList<HashMap<String, Object>>();
		SnowIncidentWorkNote workNote = null;
		
		try {
			fieldsMapList = SnowUtilities.parseJSONresponse(sc.getResponseToPost(shr.postWorkNoteRequest(newWorkNote.toJSON())));
		} catch (Exception e) {
			throw e;
		}
		
		if (fieldsMapList.size() > 1) throw new Exception("More than 1 result - createWorkNote");
		
		workNote = new SnowIncidentWorkNote(fieldsMapList.get(0));
		
		return workNote;
	}
	
	public SnowIncident createKingstonWorkNote(String incidentSysId, String workNoteText) throws Exception {
		SnowIncident resultingIncident = null;
		
		try {
			SnowIncident inc = new SnowIncident();
			inc.setSnowSysId(incidentSysId);
			inc.setSnowWorkNotes(workNoteText);
			resultingIncident = updateIncident(incidentSysId, inc);
		} catch (Exception e) {
			throw e;
		}
		
		return resultingIncident;
	}
}
