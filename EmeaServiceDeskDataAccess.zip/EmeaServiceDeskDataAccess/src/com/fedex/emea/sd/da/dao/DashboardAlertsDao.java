package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.objects.DashboardAlerts;

public interface DashboardAlertsDao {
	public abstract void setDataSource(DataSource dataSource);
	public abstract void create(DashboardAlerts valueObject) throws SQLException, DataAccessException, IOException;
	public abstract DashboardAlerts createValueObject();
	public abstract void delete(DashboardAlerts valueObject);
	public abstract void deleteAll() throws SQLException;
	public abstract void deleteOlderThan(Timestamp limitDate) throws SQLException;
	public abstract DashboardAlerts getObject(String alertId) throws SQLException;
	public abstract List<DashboardAlerts> loadAll() throws SQLException;
	public abstract List<DashboardAlerts> loadSameAlerts(DashboardAlerts valueObject) throws SQLException;
	public abstract void save(DashboardAlerts valueObject);
	public abstract void updateNexusCaseId(DashboardAlerts valueObject);
}