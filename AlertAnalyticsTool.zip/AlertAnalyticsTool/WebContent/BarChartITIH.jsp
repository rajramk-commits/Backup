<%@ page language="java" contentType="text/html; charset=UTF-8"	pageEncoding="UTF-8"%>
<%@ page import="java.util.*,java.sql.*" %>
<%@ page import="com.google.gson.*"%>
<%@page import="com.fedex.emea.sabreReport.model.*"%>
<%@page import="com.fedex.emea.sabreReport.util.*"%>
<!DOCTYPE HTML>
 <html>
<%
String retStat = request.getParameter("status");
String SDate = (String)request.getSession().getAttribute("SDate");
String EDate = (String)request.getSession().getAttribute("EDate");
System.out.println("SDate:"+SDate+", EDate :"+EDate);

if(SDate.length()>15 && EDate.length()>15)
{
	SDate = SDate.substring(0, 15);
	EDate = EDate.substring(0, 15);
}

String Username = "";
String userID = "";
String userRole = "";
if(session.getAttribute("sessionName")==null)
{
	userID = (String)request.getSession().getAttribute("sessionName");
	userRole = (String)request.getSession().getAttribute("Sessionid");
	System.out.println("userID request GSS Home:"+userID);
	 if(userID == null && userRole == null)
    	{
		System.out.println("userID userRole are null");
    	} 
}
else
{
	userID = (String) session.getAttribute("sessionName");
	System.out.println("userID GSS Home:"+userID);
	userRole = (String) session.getAttribute("Sessionid");
}

Map<String, Integer> alltypeAlertData = new HashMap<>();

List<SabreBean> data = new ArrayList<>();


try{
   	data = (List<SabreBean>) request.getSession().getAttribute("gssList");
   	
	if(data != null && data.size() != 0)
	{
		// All type alerts Graphs
		for(int i=0; i< data.size();i++)
		{
			String alert = data.get(i).getAlertType();
			if(alltypeAlertData.containsKey(alert))
			{
				alltypeAlertData.put(alert, alltypeAlertData.get(alert)+1);
			}
			else
			{
				alltypeAlertData.put(alert, 1);
			}
		}
		alltypeAlertData = GraphUtil.sortByValue(alltypeAlertData);
		System.out.println("alltypeAlertData jsp:"+alltypeAlertData);		
		
				
	}
}
catch(Exception e){
	e.printStackTrace();
}
%>
 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script> -->

<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>
<!-- <script src="javascript/zebra_dialog.js"></script>
<script src="https://github.com/koffsyrup/FileSaver.js"></script> -->

<script type="text/javascript">

function goBack() 
{
	window.location = "reportType.jsp";
}

function Enable(ddl1)
{
	var div = document.getElementById("TrendBar");  
	switch (ddl1.value) {
    case 'CGN':enableCGN(checkboxElem);
    	break;
    case 'CDG':enableCDG(checkboxElem);
		break;
    case 'CPH':enableCPH(checkboxElem);
		break;
    case 'MXP':enableMXP(checkboxElem);
		break;
    case 'DXB':enableDXB(checkboxElem);
		break;
    case 'STN':enableSTN(checkboxElem);
		break;
	default: break;
	}
	div.style.display = "block"; 
}

function EnableTrends(ddl1)
{
	var div = document.getElementById("TrendBar");  
	div.style.display = "none"; 
	
	switch (ddl1.value) {
    case 'JMS Trends':enableJMS();
    	break;
    case 'File System Trends':enableFile();
		break;
    case 'Weekly Trends':enableWeek();
		break;
    case 'Monthly Trends':enableMonthly();
		break;
    case 'Error Log':enableERROR();
		break;
	default: break;
	}
}

//All Type
function getLabels()
{
	var labelList = [];
	<%
	for (String label : alltypeAlertData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableAll(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div = document.getElementById("TrendBar");
	div.style.display = "none"; 
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = 'none';
	document.getElementById("AlltypeChart").style.display="block";
	document.getElementById("AlltypeChart").style.visibility = "visible";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	var ctx = $("#AlltypeChart");
	var myLineChart = new Chart(ctx, {
				
	    type: 'bar',
	    data: {
	        labels: getLabels(),
	        datasets: [{
	            data: <%=alltypeAlertData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA","#f38b4a",
	                "#56d798","#ff8397", "#6970d5", "lightblue", "lightgreen","#0074D9",  "#2ECC40", "#FF851B" ],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	scaleShowValues: true,
	    	  scales: {
	    	    xAxes: [{
	    	      ticks: {
	    	        autoSkip: false
	    	      }
	    	    }],
	    	    yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	    	  },
	    	legend: {
	            display: false
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'All Types',
	            fontSize: 24
	        }
	    }
	});
	
	
	$("#AlltypeChart").click( 
	        function(evt){
	            var activePoints = myLineChart.getElementsAtEvent(evt);
	            if (activePoints[0]) {
	                var chartData = activePoints[0]['_chart'].config.data;
	                var idx = activePoints[0]['_index'];
	                var label = chartData.labels[idx];

	                $('#modalContent').load('ModalView.jsp?alertType=' + label,
	        				function() {
	        					$('#myModal').modal({
	        						show : true
	        					});
	        				});
	              }
	        }
	    ); 
}


window.onload = function() {
	
}

function data2blob(data, isBase64) {
	  var chars = "";

	  if (isBase64)
	    chars = atob(data);
	  else
	    chars = data;

	  var bytes = new Array(chars.length);
	  for (var i = 0; i < chars.length; i++) {
	    bytes[i] = chars.charCodeAt(i);
	  }

	  var blob = new Blob([new Uint8Array(bytes)]);
	  return blob;
	}

function saveReport()
{
	window.location = "saveGSSExcel.jsp";
	return false;
}

function save(){
	str = document.forms[0].t1.value;
	mydoc = document.open();
	mydoc.write(str);
	mydoc.execCommand("saveAs",true,".txt");
	mydoc.close();
	return false;
}

function weekNumber(){
	todaydate = new Date();  
     var oneJan =  new Date(todaydate.getFullYear(), 0, 1);   
     var numberOfDays =  Math.floor((todaydate - oneJan) / (24 * 60 * 60 * 1000));  
     var result = Math.ceil(( todaydate.getDay() + 1 + numberOfDays) / 7);   
     return result;  
}
function chkOnLoadStatus()
{
	<%
	if(retStat != null)
	{
	%>
		alert('<%=retStat%>');
	<%}%>
	var radio0 = document.getElementById("radio0");
	enableAll(radio0);
}
function logout()
{
	<%-- <% session.invalidate();%> --%>
	window.location = "Login.jsp";
}
function toggle()
{
	if(document.getElementById('customCheck0').checked)
	{
		document.getElementById("customCheck1").checked = true;
		document.getElementById("customCheck2").checked = true;
		document.getElementById("customCheck3").checked = true;
		document.getElementById("customCheck4").checked = true;
		document.getElementById("customCheck5").checked = true;
		document.getElementById("customCheck6").checked = true;
	}
	else
	{
		document.getElementById("customCheck1").checked = false;
		document.getElementById("customCheck2").checked = false;
		document.getElementById("customCheck3").checked = false;
		document.getElementById("customCheck4").checked = false;
		document.getElementById("customCheck5").checked = false;
		document.getElementById("customCheck6").checked = false;
	}
		
}
/* function EnableCGNTrends(CGNCheck)
{
	if(document.getElementById('customCheck0').checked)
	{
} */
</script>
<style type="text/css">

body {
  margin: 0;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 20%;
  background-color: #C0C0C0;
  position: fixed;
  height: 100%;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}

li a.active {
  background-color: #4CAF50;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}

li a:checked
{
  background: white;
  border-bottom: 1px solid white;
  z-index: 2;
}

.container
{
	display:flex;
	justify-content:center;
}
.toolbar {
    height: 70px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .out{
  float: right;
  font-size: 20px;
  color: white;
  margin: 1px;
  border-radius: 1px;
  border: 1px solid #eee;
  background-color: rgb(154 81 150); 
  width: 130px;
  height: 30px;
}
.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:1%;
	margin-left:25%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:25%;
	}
	
ul.topnav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
   height: 7%;
   width:75%;
}

ul.topnav li {float: left;}

ul.topnav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 10px 10px;
  text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: #04AA6D;}

ul.topnav li.right {float: right;}


.modal-body{
    height: 80vh;
    overflow-y: auto;
}
table, th, td {
  border: 1px solid black;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
		margin-left: 5%
	}
</style>
</head>
<body onload="chkOnLoadStatus()">
<div class="toolbar" role="banner">
<button class="out"  onclick="goBack()" >Home</button>
    <img
      width="143"
      alt="Angular Logo"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR4h9OKkNpZrtc-Z6l80kuRFy9wn3DPFOHaIncREOOreXAWEKLG"
      title= "FedEx"
      />
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
     
     <div style="margin-left: 40%">&nbsp;&nbsp;
     <label style = "color: white;" for="uID"><b> <%=userID %></b></label>
    <br>
     <button class="out" onclick="logout()" >Logout</button>
     </div>
</div>

<div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:5px 0 0 0; margin-left: 5%;">
        	GSS Alert Analytics  	 </p>
   		
   		</div>
   		
<ul>
 
  

</ul>

<div class="container" >
	<button class="buttonFont" onclick="saveReport()" > Export </button>
</div>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style=" width:900px; height: 600px; ">
        <div class="modal-header">
        <h3 class="modal-title" style="background-color: purple; color: white;" id="myModalLabel">Alert details</h3>  
          <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  
        </div>
        <div class="modal-body" id ="modalContent" >
         
       </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>                        