
//*****************************************************************
//* 
//* CompIntfcPropertyInfo.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public class CompIntfcPropertyInfo implements ICompIntfcPropertyInfo 
  {
  public CompIntfcPropertyInfo(IObject oThis) { m_oThis = oThis; }

  public ICompIntfcPropertyInfoCollection getPropertyInfoCollection() throws JOAException {
    return (ICompIntfcPropertyInfoCollection)m_oThis.getProperty("PropertyInfoCollection");
 }

  public String getName() throws JOAException {
    return (String)m_oThis.getProperty("Name");
 }

  public String getRecordName() throws JOAException {
    return (String)m_oThis.getProperty("RecordName");
 }

  public String getFieldName() throws JOAException {
    return (String)m_oThis.getProperty("FieldName");
 }

  public String getLabelLong() throws JOAException {
    return (String)m_oThis.getProperty("LabelLong");
 }

  public String getLabelShort() throws JOAException {
    return (String)m_oThis.getProperty("LabelShort");
 }

  public boolean getIsCollection() throws JOAException {
    return ((Boolean)m_oThis.getProperty("IsCollection")).booleanValue();
 }

  public long getType() throws JOAException {
    return ((Long)m_oThis.getProperty("Type")).longValue();
 }

  public long getOAType() throws JOAException {
    return ((Long)m_oThis.getProperty("OAType")).longValue();
 }

  public long getFormat() throws JOAException {
    return ((Long)m_oThis.getProperty("Format")).longValue();
 }

  public boolean getKey() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Key")).booleanValue();
 }

  public boolean getRequired() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Required")).booleanValue();
 }

  public boolean getXlat() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Xlat")).booleanValue();
 }

  public boolean getYesno() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Yesno")).booleanValue();
 }

  public boolean getPrompt() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Prompt")).booleanValue();
 }

  public long getLength() throws JOAException {
    return ((Long)m_oThis.getProperty("Length")).longValue();
 }

  public long getDecimalPosition() throws JOAException {
    return ((Long)m_oThis.getProperty("DecimalPosition")).longValue();
 }

  public boolean getIsReadOnly() throws JOAException {
    return ((Boolean)m_oThis.getProperty("IsReadOnly")).booleanValue();
 }

  public boolean getAltkey() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Altkey")).booleanValue();
 }

  public boolean getListboxitem() throws JOAException {
    return ((Boolean)m_oThis.getProperty("Listboxitem")).booleanValue();
 }

  public boolean getIsMobileReference() throws JOAException {
    return ((Boolean)m_oThis.getProperty("IsMobileReference")).booleanValue();
 }

  IObject m_oThis;
  }
