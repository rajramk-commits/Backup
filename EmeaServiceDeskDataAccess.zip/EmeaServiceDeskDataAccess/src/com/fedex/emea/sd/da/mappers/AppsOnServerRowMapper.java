package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.AppsOnServer;

public final class AppsOnServerRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		AppsOnServer appsOnServer = new AppsOnServer();
		appsOnServer.setAppName(rs.getString("AppName"));
		appsOnServer.setAppDesc(rs.getString("AppDesc"));
		appsOnServer.setAppBc(rs.getString("AppBc"));
		appsOnServer.setAppStatus(rs.getString("AppStatus"));
		appsOnServer.setAppLocation(rs.getString("AppLocation"));
		appsOnServer.setAppRespMgr(rs.getString("AppRespMgr"));
		appsOnServer.setAppRole(rs.getString("AppRole"));
		appsOnServer.setAppEnviron(rs.getString("AppEnviron"));
		appsOnServer.setSrvName(rs.getString("SrvName"));
		appsOnServer.setSrvDc(rs.getString("SrvDc"));
		appsOnServer.setSrvType(rs.getString("SrvType"));
		appsOnServer.setSrvTypeDesc(rs.getString("SrvTypeDesc"));
		appsOnServer.setSrvStatus(rs.getString("SrvStatus"));
		appsOnServer.setSrvOs(rs.getString("SrvOs"));
		appsOnServer.setSrvSoftRev(rs.getString("SrvSoftRev"));
		appsOnServer.setSrvSoftVer(rs.getString("SrvSoftVer"));
		
		return appsOnServer;	
	}
}
