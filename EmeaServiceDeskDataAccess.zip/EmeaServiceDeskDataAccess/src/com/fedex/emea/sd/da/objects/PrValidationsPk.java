package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_VALIDATIONS table.
 */
public class PrValidationsPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7007297871383268507L;

	protected String cy;

	protected String eaiId;

	protected String ni2AppId;

	/** 
	 * Sets the value of cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/** 
	 * Gets the value of cy
	 */
	public String getCy()
	{
		return cy;
	}

	/** 
	 * Sets the value of eaiId
	 */
	public void setEaiId(String eaiId)
	{
		this.eaiId = eaiId;
	}

	/** 
	 * Gets the value of eaiId
	 */
	public String getEaiId()
	{
		return eaiId;
	}

	/** 
	 * Sets the value of ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/** 
	 * Gets the value of ni2AppId
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'PrValidationsPk'
	 * 
	 */
	public PrValidationsPk()
	{
	}

	/**
	 * Method 'PrValidationsPk'
	 * 
	 * @param cy
	 * @param eaiId
	 * @param ni2AppId
	 */
	public PrValidationsPk(final String cy, final String eaiId, final String ni2AppId)
	{
		this.cy = cy;
		this.eaiId = eaiId;
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrValidationsPk)) {
			return false;
		}
		
		final PrValidationsPk _cast = (PrValidationsPk) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (eaiId == null ? _cast.eaiId != eaiId : !eaiId.equals( _cast.eaiId )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (eaiId != null) {
			_hashCode = 29 * _hashCode + eaiId.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrValidationsPk: " );
		ret.append( "cy=" + cy );
		ret.append( ", eaiId=" + eaiId );
		ret.append( ", ni2AppId=" + ni2AppId );
		return ret.toString();
	}

}
