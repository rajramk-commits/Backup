package com.fedex.emea.dimm.utils;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.utilities.SnowConstants;




public class SnowTester {

	public static void main(String[] args) {
		System.out.println("SNOW Test...");
		
		
		
		SnowRequestor snowRequestor = new SnowRequestor(SnowConstants.EPDSM_UAT_DIRECT); // (Available Environment: SNOW_DEV, SNOW_UAT)
		SnowIncident  incident      = new SnowIncident();
		
		
		
		try {
			String incidentToSearch = "INC3899947";
		//	incident      = snowRequestor.getIncidentByIncidentNbr(incidentToSearch);
			
			
			/*List<String> cases = new ArrayList<>();
			  List<String> casesclosed = new ArrayList<>();
			   List<String> casesopen = new ArrayList<>();
			  
			cases.add("INC3900182");
			cases.add("INC3899951");
			
			for(String name: cases){
				
				SnowIncident  incident2      = new SnowIncident();
					
				   
				   incident2      = snowRequestor.getIncidentByIncidentNbr(name);
				   String state2 = incident2.getSnowState();
				   
				 
							if (state2.equals(SnowConstants.STATE_RESOLVED) || state2.equals(SnowConstants.STATE_CLOSED))
							{
								System.out.println("Incident " + name + " is RESOLVED or closed");
								casesclosed.add(name);
							}
							if (state2.equals(SnowConstants.STATE_REGISTERED)) 
							{
								System.out.println("Incident " + name + " is REGISTERED");
								casesopen.add(name);
							}
			}
			
			for(String cas: casesopen)
			{
				System.out.println("case open:"+cas);
			}*/
			
			
	//		DebugUtilities.listIncidentKeyFields(incident);
	//		incident.setSnowState(SnowConstants.STATE_RESOLVED);
			String status = incident.getSnowStatus();
			System.out.println("Status:"+status);
			String state = incident.getSnowState();
			System.out.println("State:"+state);
			
			
			if (state.equals(SnowConstants.STATE_REGISTERED)) System.out.println("Incident " + incidentToSearch + " is REGISTERED");
			else {
				if (state.equals(SnowConstants.STATE_IN_PROGRESS)) System.out.println("Incident " + incidentToSearch + " is IN-PROGRESS");
				else {
					if (state.equals(SnowConstants.STATE_RESOLVED)) System.out.println("Incident " + incidentToSearch + " is RESOLVED");
					else {
						if (state.equals(SnowConstants.STATE_CLOSED)) System.out.println("Incident " + incidentToSearch + " is CLOSED");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.exit(0);
	}

}