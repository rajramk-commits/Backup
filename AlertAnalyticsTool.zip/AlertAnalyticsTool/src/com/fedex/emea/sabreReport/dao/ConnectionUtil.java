package com.fedex.emea.sabreReport.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionUtil {
	
	private static Connection con = null;
	
	public static Statement getConnection() throws SQLException, ClassNotFoundException 
    {
        if (con != null) return con.createStatement();
        return getConnectionStatement();
    }

	
	private static Statement getConnectionStatement() throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
		"jdbc:oracle:thin:@(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = tcbe007-scan.emea.fedex.com)(PORT = 1526)))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = TC007_COMB_ASTC_LX_SVC1.emea.fedex.com)(FAILOVER_MODE =(TYPE = select)(METHOD = basic)(RETRIES = 1)(DELAY = 5))))",
		"SDTOOL_APP", "YA5jmElhIQE5oyNWJ03BSIKsP");
		return con.createStatement();
	}
	
	public static Statement getConn() throws SQLException, ClassNotFoundException 
    {
		if (con != null) return con.createStatement();
        return getConnStatement();
    }
	
	private static Statement getConnStatement() throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
		"jdbc:oracle:thin:@(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = pcbe002-scan.emea.fedex.com)(PORT = 1526)))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = D002A_ASTC_PRD_SVC1.emea.fedex.com)(FAILOVER_MODE =(TYPE = select)(METHOD = basic)(RETRIES = 1)(DELAY = 1))))",
		"SDTOOL_APP", "Too1sd");
		return con.createStatement();
	}
	
}
