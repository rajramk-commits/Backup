package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_SYMPHONY_APPS table.
 */
public class PrSymphonyAppsPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4439151021155161267L;
	protected String symEaiId;

	/** 
	 * Sets the value of symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/** 
	 * Gets the value of symEaiId
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/**
	 * Method 'PrSymphonyAppsPk'
	 * 
	 */
	public PrSymphonyAppsPk()
	{
	}

	/**
	 * Method 'PrSymphonyAppsPk'
	 * 
	 * @param symEaiId
	 */
	public PrSymphonyAppsPk(final String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSymphonyAppsPk)) {
			return false;
		}
		
		final PrSymphonyAppsPk _cast = (PrSymphonyAppsPk) _other;
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSymphonyAppsPk: " );
		ret.append( "symEaiId=" + symEaiId );
		return ret.toString();
	}

}
