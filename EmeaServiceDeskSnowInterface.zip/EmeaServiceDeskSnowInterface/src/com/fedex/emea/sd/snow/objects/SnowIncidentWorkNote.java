package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowIncidentWorkNote implements Serializable {
	
	private static final long serialVersionUID = -3921323735709235130L;

	private String workNoteSysId;
	private String workNoteSysCreatedOn;
	private String workNoteName;
	private String workNoteElementId;
	private String workNoteSysTags; 
	private String workNoteValue;
	private String workNoteSysCreatedBy;
	private String workNoteElement;
	private String workNoteSubject;
	private String workNoteText;
	
	public SnowIncidentWorkNote() {
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (workNoteSysId != null && !workNoteSysId.toString().isEmpty()) jsonObject.put("sys_id", workNoteSysId);
		if (workNoteSysCreatedOn != null && !workNoteSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", workNoteSysCreatedOn);
		if (workNoteName != null && !workNoteName.toString().isEmpty()) jsonObject.put("name", workNoteName);
		if (workNoteElementId != null && !workNoteElementId.toString().isEmpty()) jsonObject.put("element_id", workNoteElementId);
		if (workNoteSysTags != null && !workNoteSysTags.toString().isEmpty()) jsonObject.put("sys_tags", workNoteSysTags);
		if (workNoteValue != null && !workNoteValue.toString().isEmpty()) {
			jsonObject.put("value", workNoteValue);
		} else {
			jsonObject.put("value", "Subject: " + workNoteSubject + "\r\n" + workNoteText);
		}
		if (workNoteSysCreatedBy != null && !workNoteSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", workNoteSysCreatedBy);
		if (workNoteElement != null && !workNoteElement.toString().isEmpty()) jsonObject.put("element", workNoteElement);
		
		return jsonObject;
	}
	
	public SnowIncidentWorkNote(HashMap<String, Object> jsonValues) {
		workNoteSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		workNoteSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		workNoteName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		workNoteElementId = SnowUtilities.getStringValueFromObject(jsonValues.get("element_id"));
		workNoteSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		workNoteValue = SnowUtilities.getStringValueFromObject(jsonValues.get("value"));
		workNoteSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		workNoteElement = SnowUtilities.getStringValueFromObject(jsonValues.get("element"));
		workNoteSubject = workNoteValue.substring(workNoteValue.indexOf(":") + 2, workNoteValue.indexOf("\n") - 1);
		workNoteText = workNoteValue.substring(workNoteValue.indexOf("\n") + 1);
	}
	
	public String getWorkNoteSubject() {
		return workNoteSubject;
	}
	
	public String getWorkNoteText() {
		return workNoteText;
	}
	
	public void setWorkNoteSubject(String workNoteSubject) {
		this.workNoteSubject = workNoteSubject;
	}
	
	public void setWorkNoteText(String workNoteText) {
		this.workNoteText = workNoteText;
	}

	public String getWorkNoteSysId() {
		return workNoteSysId;
	}

	public void setWorkNoteSysId(String workNoteSysId) {
		this.workNoteSysId = workNoteSysId;
	}

	public String getWorkNoteSysCreatedOn() {
		return workNoteSysCreatedOn;
	}

	public void setWorkNoteSysCreatedOn(String workNoteSysCreatedOn) {
		this.workNoteSysCreatedOn = workNoteSysCreatedOn;
	}

	public String getWorkNoteName() {
		return workNoteName;
	}

	public void setWorkNoteName(String workNoteName) {
		this.workNoteName = workNoteName;
	}

	public String getWorkNoteElementId() {
		return workNoteElementId;
	}

	public void setWorkNoteElementId(String workNoteElementId) {
		this.workNoteElementId = workNoteElementId;
	}

	public String getWorkNoteSysTags() {
		return workNoteSysTags;
	}

	public void setWorkNoteSysTags(String workNoteSysTags) {
		this.workNoteSysTags = workNoteSysTags;
	}

	public String getWorkNoteValue() {
		return workNoteValue;
	}

	public void setWorkNoteValue(String workNoteValue) {
		this.workNoteValue = workNoteValue;
	}

	public String getWorkNoteSysCreatedBy() {
		return workNoteSysCreatedBy;
	}

	public void setWorkNoteSysCreatedBy(String workNoteSysCreatedBy) {
		this.workNoteSysCreatedBy = workNoteSysCreatedBy;
	}

	public String getWorkNoteElement() {
		return workNoteElement;
	}

	public void setWorkNoteElement(String workNoteElement) {
		this.workNoteElement = workNoteElement;
	}
}
