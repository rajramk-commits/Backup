package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class Ni2CompositeAppsInScopeForPR implements Serializable {

	private static final long serialVersionUID = 7276558052820482211L;
	
	private String id;
	private String name;
	private String classification;
	private String role;
	private String location;
	private String businessCriticality;
	private String respMgrName;
	private String respPhoneActing;
	private String supportMgrName;
	private String symProfile;
	private String owner;
	private String description;
	private String comments;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getBusinessCriticality() {
		return businessCriticality;
	}
	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}
	public String getRespMgrName() {
		return respMgrName;
	}
	public void setRespMgrName(String respMgrName) {
		this.respMgrName = respMgrName;
	}
	public String getRespPhoneActing() {
		return respPhoneActing;
	}
	public void setRespPhoneActing(String respPhoneActing) {
		this.respPhoneActing = respPhoneActing;
	}
	public String getSupportMgrName() {
		return supportMgrName;
	}
	public void setSupportMgrName(String supportMgrName) {
		this.supportMgrName = supportMgrName;
	}
	public String getSymProfile() {
		return symProfile;
	}
	public void setSymProfile(String symProfile) {
		this.symProfile = symProfile;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
}
