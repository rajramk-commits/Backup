import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FullCalendar } from 'primeng/fullcalendar';
import { FullCalendarComponent } from './full-calendar/full-calendar.component';
import { EventService } from './full-calendar/eventservice';


const routes: Routes = [{
    path:"HolidayCalApp",
    component:FullCalendar
  },
  {
    path: "**",
    redirectTo: "HolidayCalApp",
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes , {useHash : true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
