package com.fedex.emea.dimm.config;

public class MailConfig {
	private String mailHost = null;
	private String fromAddress = null;
	private String toAddress = null;
	private String monitorAdminAddress = null;

	public MailConfig(){
	}
	
	public MailConfig(String mailHost, String fromAddress, String toAddress,
			String monitorAdminAddress) {
		super();
		this.mailHost = mailHost;
		this.fromAddress = fromAddress;
		this.toAddress = toAddress;
		this.monitorAdminAddress = monitorAdminAddress;
	}



	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getMailHost() {
		return mailHost;
	}

	public void setMailHost(String mailHost) {
		this.mailHost = mailHost;
	}

	public String getToAddress() {
		return toAddress;
	}

	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}
	
	public String getMonitorAdminAddress() {
		return monitorAdminAddress;
	}

	public void setMonitorAdminAddress(String monitorAdminAddress) {
		this.monitorAdminAddress = monitorAdminAddress;
	}

	public String toString(){
		return "MailHost="+mailHost+" FromAddress="+fromAddress+" ToAddress="+toAddress+" monitorAdminAddress="+monitorAdminAddress;
	}
}
