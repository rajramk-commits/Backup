package com.fedex.emea.onlinequiz.objects;

public class Role {

	private String userid;
	private String userrole;
	private String givenby;
	

	public Role(String user_id, String user_role, String given_by) {

		this.givenby = given_by;
		this.userid = user_id;
        this.userrole = user_role;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserrole() {
		return userrole;
	}
	public void setUserrole(String userrole) {
		this.userrole = userrole;
	}
	public String getGivenby() {
		return givenby;
	}
	public void setGivenby(String givenby) {
		this.givenby = givenby;
	}

}
