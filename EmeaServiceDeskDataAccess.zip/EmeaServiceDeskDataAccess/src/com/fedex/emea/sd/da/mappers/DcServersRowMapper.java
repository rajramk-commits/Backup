package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.DcServers;
import com.fedex.emea.sd.da.helpers.Utilities;

public class DcServersRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		DcServers dcServer = new DcServers();

		dcServer.setServerName(Utilities.cleanServerName(rs.getString("NAME")));
		dcServer.setServerType(rs.getString("TYPE"));
		dcServer.setServerDescription(rs.getString("DESCRIPTION"));
		dcServer.setServerDataCenter(rs.getString("LOCAL_DOMAIN_NAME"));
		dcServer.setServerStatus(rs.getString("STATUS"));
		dcServer.setServerSoftwareVersion(rs.getString("SOFTWARE_VERSION"));
		dcServer.setServerId(rs.getString("ID"));
		
		return dcServer;
	}

}
