package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.OvoMessagesRowMapper;
import com.fedex.emea.sd.da.objects.OvoMessages;

public class OvoMessagesDaoImp implements OvoMessagesDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int countAll() throws SQLException {
		String sql = "SELECT count(*) FROM OvoMessages";
        int allRows = 0;
        jdbcTemplate.queryForInt(sql);
        return allRows;
	}

	public void create(OvoMessages valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO OvoMessages (OVOMESSAGEID, OVONODE, OVOAPPNAME, OVOAPPGROUP, OVOAPPOBJECT, NEXUSCASEID, CREATIONTIME) " +
		               "VALUES (?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getOvoMessageId(), valueObject.getOvoNode(), valueObject.getOvoAppName(), valueObject.getOvoAppGroup(), valueObject.getOvoAppObject(), valueObject.getNexusCaseId(), valueObject.getCreationTime()});
	}

	public OvoMessages createValueObject() {
		return new OvoMessages();
	}
	
	public void deleteOlderThan(Timestamp limitDate) throws SQLException {
		String sql = "delete from OVOMESSAGES OM where OM.OVOMESSAGEID in (select NI.RECORDSOURCEID from NEXUSINTERFACE NI where NI.CREATIONTIME < ?)";
		jdbcTemplate.update(sql, new Object[] {limitDate});
	}

	public void delete(OvoMessages valueObject) {
		String sql = "DELETE FROM OvoMessages WHERE (OVOMESSAGEID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getOvoMessageId()});
	}

	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM OvoMessages";
		jdbcTemplate.update(sql);
	}

	@SuppressWarnings("unchecked")
	public OvoMessages getObject(String ovoMessageId) throws SQLException {
		OvoMessages valueObject = createValueObject();
		String sql = "SELECT * FROM OvoMessages WHERE (OVOMESSAGEID = ? ) ";
		List<OvoMessages> data = jdbcTemplate.query(sql, new Object[] {ovoMessageId}, new OvoMessagesRowMapper());
		if (!data.isEmpty()) {
			valueObject = data.get(0);
		} else {
			valueObject = null;
		}
		return valueObject;
	}
	
	@SuppressWarnings("unchecked")
	public List<OvoMessages> loadSimilarObject(String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject) throws SQLException {
		String sql = "SELECT Ovo.* FROM OvoMessages Ovo, NexusInterface Ni WHERE (Ovo.OVONODE = ? AND Ovo.OVOAPPGROUP = ? AND Ovo.OVOAPPNAME = ? AND Ovo.OVOAPPOBJECT = ? AND Ovo.NEXUSCASEID IS NOT NULL) AND (Ni.RECORDSOURCEID = Ovo.OVOMESSAGEID and Ni.RECORDSOURCE = 'OBM')";
		return jdbcTemplate.query(sql, new Object[] {ovoNode, ovoAppGroup, ovoAppName, ovoAppObject}, new OvoMessagesRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<OvoMessages> loadSimilarObjectFromExternalInterface(String ovoNode, String ovoAppGroup, String ovoAppName, String ovoAppObject) throws SQLException {
		String sql = "SELECT Ovo.* FROM OvoMessages Ovo, External_Interface Ei WHERE (Ovo.OVONODE = ? AND Ovo.OVOAPPGROUP = ? AND Ovo.OVOAPPNAME = ? AND Ovo.OVOAPPOBJECT = ? AND Ovo.NEXUSCASEID IS NOT NULL) AND (Ei.RECORDSOURCEID = Ovo.OVOMESSAGEID and Ei.RECORDSOURCE = 'OBM')";
		return jdbcTemplate.query(sql, new Object[] {ovoNode, ovoAppGroup, ovoAppName, ovoAppObject}, new OvoMessagesRowMapper());
	}

	@SuppressWarnings("unchecked")
	public List<OvoMessages> loadAll() throws SQLException {
		String sql = "SELECT * FROM OvoMessages ORDER BY CREATIONTIME DESC ";
		return jdbcTemplate.query(sql, new OvoMessagesRowMapper());
	}
	
	public void updateNexusCaseId(OvoMessages valueObject) {
		String sql = "UPDATE OvoMessages SET NEXUSCASEID = ? WHERE (OVOMESSAGEID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getNexusCaseId(), valueObject.getOvoMessageId()});
	}
}
