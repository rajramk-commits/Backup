package com.fedex.dashboard.model;

public class TicketsBean {
	private String caseID;
	private String creationTime;
	private String recordSource;
	private String caseDesc;
	private String caseType;
	private String casePriority;
	private String caseStatus;
	
	public String getCaseID() {
		return caseID;
	}
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	public String getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(String creationTime) {
		this.creationTime = creationTime;
	}
	public String getRecordSource() {
		return recordSource;
	}
	public void setRecordSource(String recordSource) {
		this.recordSource = recordSource;
	}
	public String getCaseDesc() {
		return caseDesc;
	}
	public void setCaseDesc(String caseDesc) {
		this.caseDesc = caseDesc;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCasePriority() {
		return casePriority;
	}
	public void setCasePriority(String casePriority) {
		this.casePriority = casePriority;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}
	@Override
	public String toString() {
		return "TicketsBean [caseID=" + caseID + ", creationTime=" + creationTime + ", recordSource=" + recordSource
				+ ", caseDesc=" + caseDesc + ", caseType=" + caseType + ", casePriority=" + casePriority
				+ ", caseStatus=" + caseStatus + "]";
	}
}
