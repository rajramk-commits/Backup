<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<%@ page import="java.util.*,java.sql.*" %>
<%@page import="com.fedex.emea.sabreReport.model.*"%>
<html>
<head>
<%
List<SabreBean> data = new ArrayList<>();
List<SabreBean> modalData = new ArrayList<>();
data = (List<SabreBean>) request.getSession().getAttribute("gssList");
String alertType = request.getParameter("alertType");
if(data != null && data.size() != 0)
{
	System.out.println("Data Not null....");
	if(alertType != null)
	{
		System.out.println("alertType :"+alertType);
	}

}

%>
<meta charset="ISO-8859-1">
</head>
<body>

<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style=" width:900px; height: 500px; ">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Incident details</h4>
        </div>
        <div class="modal-body" >
         <table style="border-width: 2px;border: thick; border-color: purple;">
				<thead>
				<th >Incident ID</th>
				<th >Created Date</th>
				<th >Short Description</th>
				<th >Alert Type</th>
				<th>Location</th>
				</thead>
				<tbody>
				
				<% 
				SabreBean bean = new SabreBean();
				for(int i=0; i< data.size(); i++)
				{
					bean = data.get(i);
					if(bean != null && bean.getAlertType() != null && bean.getAlertType().equalsIgnoreCase("Disconnect_Camera_Tunnel"))
					{
					%>
					<tr>
			 		<td><%=bean.getIncedent() %></td>
				    <td ><%=bean.getCreated() %> </td>
					<td ><%=bean.getShortDescr() %></td>
					<td ><%=bean.getAlertType() %></td>
					<td ><%=bean.getLocation() %></td>
				</tr>
				<%} 
				}%>
				</tbody>
				</table>
       </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

</body>
</html>