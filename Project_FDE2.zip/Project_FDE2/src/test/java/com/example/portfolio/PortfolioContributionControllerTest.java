package com.example.portfolio;

import com.example.portfolio.dto.PortfolioContributionRequest;
import com.example.portfolio.dto.PositionRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.math.BigDecimal;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class PortfolioContributionControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void shouldCalculateGroupContributionsAndMarkDegradedProcessingWhenPricingIsDelayed() throws Exception {
        PortfolioContributionRequest request = new PortfolioContributionRequest();
        request.setValuationDate("2026-06-30");

        PositionRequest equity = new PositionRequest();
        equity.setId("AAPL");
        equity.setAssetGroup("Equity");
        equity.setWeight(new BigDecimal("0.60"));
        equity.setReturnRate(new BigDecimal("0.12"));
        equity.setPriceStatus("AVAILABLE");

        PositionRequest bond = new PositionRequest();
        bond.setId("BOND01");
        bond.setAssetGroup("Fixed Income");
        bond.setWeight(new BigDecimal("0.25"));
        bond.setReturnRate(new BigDecimal("0.03"));
        bond.setPriceStatus("DELAYED");
        bond.setFallbackReturnRate(new BigDecimal("0.02"));

        PositionRequest cash = new PositionRequest();
        cash.setId("CASH01");
        cash.setAssetGroup("Cash");
        cash.setWeight(new BigDecimal("0.15"));
        cash.setReturnRate(new BigDecimal("0.01"));
        cash.setPriceStatus("UNAVAILABLE");

        request.setPositions(List.of(equity, bond, cash));

        mockMvc.perform(post("/api/portfolio/contribution")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pricingStatus", is("DEGRADED_FALLBACK")))
                .andExpect(jsonPath("$.totalContribution", is(0.086)))
                .andExpect(jsonPath("$.groupContributions", hasSize(3)))
                .andExpect(jsonPath("$.resiliency.fallbackPricingUsed", is(true)))
                .andExpect(jsonPath("$.resiliency.degradedProcessing", is(true)))
                .andExpect(jsonPath("$.resiliency.positionsWithPricingIssues", is(2)));
    }
}
