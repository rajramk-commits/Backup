<%@ page language="java" contentType="text/html; charset=UTF-8"	pageEncoding="UTF-8"%>
<%@ page import="java.util.*,java.sql.*" %>
<%@ page import="com.google.gson.*"%>
<%@page import="com.fedex.emea.sabreReport.model.*"%>
<%@page import="com.fedex.emea.sabreReport.util.*"%>
<!DOCTYPE HTML>
 <html>
<%
String retStat = request.getParameter("status");
String SDate = (String)request.getSession().getAttribute("SDate");
String EDate = (String)request.getSession().getAttribute("EDate");
System.out.println("SDate:"+SDate+", EDate :"+EDate);

if(SDate.length()>15 && EDate.length()>15)
{
	SDate = SDate.substring(0, 15);
	EDate = EDate.substring(0, 15);
}

String Username = "";
String userID = "";
String userRole = "";
if(session.getAttribute("sessionName")==null)
{
	userID = (String)request.getSession().getAttribute("sessionName");
	userRole = (String)request.getSession().getAttribute("Sessionid");
	System.out.println("userID request GSS Home:"+userID);
	 if(userID == null && userRole == null)
    	{
		System.out.println("userID userRole are null");
    	} 
}
else
{
	userID = (String) session.getAttribute("sessionName");
	System.out.println("userID GSS Home:"+userID);
	userRole = (String) session.getAttribute("Sessionid");
}

Map<String, Integer> alltypeAlertData = new HashMap<>();
Map<String, Integer> alertTypeCGNData = new HashMap<>();
Map<String, Integer> alertTypeCPHData = new HashMap<>();
Map<String, Integer> alertTypeCDGData = new HashMap<>();
Map<String, Integer> alertTypeMXPData = new HashMap<>();
Map<String, Integer> alertTypeDXBData = new HashMap<>();
Map<String, Integer> alertTypeSTNData = new HashMap<>();
Map<String, Integer> alertTypeERRORData = new HashMap<>();
Map<String, Integer> alertTypeJMSData = new HashMap<>();

List<SabreBean> data = new ArrayList<>();


try{
   	data = (List<SabreBean>) request.getSession().getAttribute("gssList");
   	
	if(data != null && data.size() != 0)
	{
		// All type alerts Graphs
		for(int i=0; i< data.size();i++)
		{
			String alert = data.get(i).getAlertType();
			if(alltypeAlertData.containsKey(alert))
			{
				alltypeAlertData.put(alert, alltypeAlertData.get(alert)+1);
			}
			else
			{
				alltypeAlertData.put(alert, 1);
			}
		}
		alltypeAlertData = GraphUtil.sortByValue(alltypeAlertData);
		System.out.println("alltypeAlertData jsp:"+alltypeAlertData);		
		
		//Alerts on CGN
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("DE-CGN"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeCGNData.containsKey(alert))
				{
					alertTypeCGNData.put(alert, alertTypeCGNData.get(alert)+1);
				}
				else
				{
					alertTypeCGNData.put(alert, 1);
				}
			}
		}
		alertTypeCGNData = GraphUtil.sortByValue(alertTypeCGNData);
		System.out.println("alertTypeCGNData jsp:"+alertTypeCGNData);
		
		//Alerts on CPH
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("DK-CPH"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeCPHData.containsKey(alert))
				{
					alertTypeCPHData.put(alert, alertTypeCPHData.get(alert)+1);
				}
				else
				{
					alertTypeCPHData.put(alert, 1);
				}
			}
		}
		alertTypeCPHData = GraphUtil.sortByValue(alertTypeCPHData);
		System.out.println("alertTypeCPHData jsp:"+alertTypeCPHData);
						
		//Alerts on CDG
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("FR-CDG"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeCDGData.containsKey(alert))
				{
					alertTypeCDGData.put(alert, alertTypeCDGData.get(alert)+1);
				}
				else
				{
					alertTypeCDGData.put(alert, 1);
				}
			}
		}
		alertTypeCDGData = GraphUtil.sortByValue(alertTypeCDGData);
		System.out.println("alertTypeCDGData jsp:"+alertTypeCDGData);
						
		//Alerts on MXP
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("IT-MXP"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeMXPData.containsKey(alert))
				{
					alertTypeMXPData.put(alert, alertTypeMXPData.get(alert)+1);
				}
				else
				{
					alertTypeMXPData.put(alert, 1);
				}
			}
		}
		alertTypeMXPData = GraphUtil.sortByValue(alertTypeMXPData);
		System.out.println("alertTypeMXPData jsp:"+alertTypeMXPData);
						
		//Alerts on DXB
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("AE-DXB"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeDXBData.containsKey(alert))
				{
					alertTypeDXBData.put(alert, alertTypeDXBData.get(alert)+1);
				}
				else
				{
					alertTypeDXBData.put(alert, 1);
				}
			}
		}
		alertTypeDXBData = GraphUtil.sortByValue(alertTypeDXBData);
		System.out.println("alertTypeDXBData jsp:"+alertTypeDXBData);
						
		//Alerts on STN
		for(int i=0; i< data.size();i++)
		{
			String loc = data.get(i).getLocation();
			if(loc.equalsIgnoreCase("GB-STN"))
			{
				String alert = data.get(i).getAlertType();
				if(alertTypeSTNData.containsKey(alert))
				{
					alertTypeSTNData.put(alert, alertTypeSTNData.get(alert)+1);
				}
				else
				{
					alertTypeSTNData.put(alert, 1);
				}
			}
		}
		alertTypeSTNData = GraphUtil.sortByValue(alertTypeSTNData);
		System.out.println("alertTypeSTNData jsp:"+alertTypeSTNData);
		
		// ERROR_LOG Alerts
		for(int i=0; i< data.size();i++)
		{
			String comments = data.get(i).getComments();
			if(comments.equalsIgnoreCase("ERROR_LOG"))
			{
				String loc = data.get(i).getLocation();
				if(alertTypeERRORData.containsKey(loc))
				{
					alertTypeERRORData.put(loc, alertTypeERRORData.get(loc)+1);
				}
				else
				{
					alertTypeERRORData.put(loc, 1);
				}
			}
		}
		alertTypeERRORData = GraphUtil.sortByValue(alertTypeERRORData);
		System.out.println("alertTypeERRORData jsp:"+alertTypeERRORData);
		
		// JMS TRENDS Alerts
				for(int i=0; i< data.size();i++)
				{
					String alert = data.get(i).getAlertType();
					if(alert.equalsIgnoreCase("JMS_Queue"))
					{
						String desc = data.get(i).getShortDescr();
						int sInd = desc.indexOf("Module[")+24;
						int eInd = desc.indexOf("]", sInd);
						String module= desc.substring(sInd, eInd);
						if(alertTypeJMSData.containsKey(module))
						{
							alertTypeJMSData.put(module, alertTypeJMSData.get(module)+1);
						}
						else
						{
							alertTypeJMSData.put(module, 1);
						}
					}
				}
				alertTypeJMSData = GraphUtil.sortByValue(alertTypeJMSData);
				System.out.println("alertTypeJMSData jsp:"+alertTypeJMSData);
		
	}
}
catch(Exception e){
	e.printStackTrace();
}
%>
 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js@3.3.2/dist/chart.min.js"></script> -->

<!-- <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> -->
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>
<!-- <script src="javascript/zebra_dialog.js"></script>
<script src="https://github.com/koffsyrup/FileSaver.js"></script> -->

<script type="text/javascript">

function goBack() 
{
	window.location = "reportType.jsp";
}

function Enable(ddl1)
{
	var div = document.getElementById("TrendBar");  
	switch (ddl1.value) {
    case 'CGN':enableCGN(checkboxElem);
    	break;
    case 'CDG':enableCDG(checkboxElem);
		break;
    case 'CPH':enableCPH(checkboxElem);
		break;
    case 'MXP':enableMXP(checkboxElem);
		break;
    case 'DXB':enableDXB(checkboxElem);
		break;
    case 'STN':enableSTN(checkboxElem);
		break;
	default: break;
	}
	div.style.display = "block"; 
}

function EnableTrends(ddl1)
{
	var div = document.getElementById("TrendBar");  
	div.style.display = "none"; 
	
	switch (ddl1.value) {
    case 'JMS Trends':enableJMS();
    	break;
    case 'File System Trends':enableFile();
		break;
    case 'Weekly Trends':enableWeek();
		break;
    case 'Monthly Trends':enableMonthly();
		break;
    case 'Error Log':enableERROR();
		break;
	default: break;
	}
}

//All Type
function getLabels()
{
	var labelList = [];
	<%
	for (String label : alltypeAlertData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableAll(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div = document.getElementById("TrendBar");
	div.style.display = "none"; 
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = 'none';
	document.getElementById("AlltypeChart").style.display="block";
	document.getElementById("AlltypeChart").style.visibility = "visible";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	var ctx = $("#AlltypeChart");
	var myLineChart = new Chart(ctx, {
				
	    type: 'bar',
	    data: {
	        labels: getLabels(),
	        datasets: [{
	            data: <%=alltypeAlertData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA","#f38b4a",
	                "#56d798","#ff8397", "#6970d5", "lightblue", "lightgreen","#0074D9",  "#2ECC40", "#FF851B" ],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	scaleShowValues: true,
	    	  scales: {
	    	    xAxes: [{
	    	      ticks: {
	    	        autoSkip: false
	    	      }
	    	    }],
	    	    yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	    	  },
	    	legend: {
	            display: false
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'All Types',
	            fontSize: 24
	        }
	    }
	});
	
	
	$("#AlltypeChart").click( 
	        function(evt){
	            var activePoints = myLineChart.getElementsAtEvent(evt);
	            if (activePoints[0]) {
	                var chartData = activePoints[0]['_chart'].config.data;
	                var idx = activePoints[0]['_index'];
	                var label = chartData.labels[idx];

	                $('#modalContent').load('ModalView.jsp?alertType=' + label,
	        				function() {
	        					$('#myModal').modal({
	        						show : true
	        					});
	        				});
	              }
	        }
	    ); 
}

//CGN
function getCGNLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeCGNData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}


function enableCGN(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("CGNChart").style.display="block";
	document.getElementById("CGNChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#CGNChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getCGNLabels(),
	        datasets: [{
	            data: <%=alertTypeCGNData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9", "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'CGN',
	            fontSize: 24
	        }
	    }
	});	
}

//CPH
function getCPHLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeCPHData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableCPH(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("CPHChart").style.display="block";
	document.getElementById("CPHChart").style.visibility = "visible";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#CPHChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getCPHLabels(),
	        datasets: [{
	            data: <%=alertTypeCPHData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'CPH',
	            fontSize: 24
	        }
	    }
	});	
}

//CDG
function getCDGLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeCDGData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableCDG(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("CDGChart").style.display="block";
	document.getElementById("CDGChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#CDGChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getCDGLabels(),
	        datasets: [{
	            data: <%=alertTypeCDGData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'CDG',
	            fontSize: 24
	        },
	    }
	});	
}

//MXP
function getMXPLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeMXPData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableMXP(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("MXPChart").style.display="block";
	document.getElementById("MXPChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#MXPChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getMXPLabels(),
	        datasets: [{
	            data: <%=alertTypeMXPData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45,
	                    beginAtZero: true
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'MXP',
	            fontSize: 24
	        }
	    }
	});	
}

//DXB
function getDXBLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeDXBData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableDXB(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("DXBChart").style.display="block";
	document.getElementById("DXBChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#DXBChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getDXBLabels(),
	        datasets: [{
	            data: <%=alertTypeDXBData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	                <% if (alertTypeDXBData.values().size()==0)
	                {%>
	                	document.getElementById('DXBChartEmpty').style.display = 'block';
	                    document.getElementById('DXBChart').style.display = 'none'
	                <%}
	                %>
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'DXB',
	            fontSize: 24
	        }
	    }
	});	
}

//STN
function getSTNLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeSTNData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableSTN(checkboxElem)
{
	if (!checkboxElem.checked) {
		return;
	}
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("STNChart").style.display="block";
	document.getElementById("STNChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#STNChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getSTNLabels(),
	        datasets: [{
	            data: <%=alertTypeSTNData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'STN',
	            fontSize: 24
	        }
	    }
	});	
}

//ERROR
function getERRORLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeERRORData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function enableERROR()
{
	var div = document.getElementById("TrendBar");
	div.style.display = "none"; 
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="block";
	document.getElementById("ErrorLogChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#ErrorLogChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getERRORLabels(),
	        datasets: [{
	            data: <%=alertTypeERRORData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'ERROR',
	            fontSize: 24
	        }
	    }
	});	
}

//JMS TREND
function getJMSLabels()
{
	var labelList = [];
	<%
	for (String label : alertTypeJMSData.keySet())
	{
		%>
		labelList.push("<%=label%>");
		<%
	}
	%>
	return labelList;
}

function getValueUsingClass() {
    var checkList1 = document.getElementById('LocSel2');
    var checkBoxList1 = checkList1.getElementsByTagName("input");
    var checkBoxSelectedItems1 = new Array();
    var ary="";
    for (var i = 0; i < checkBoxList1.length; i++) {
        if (checkBoxList1[i].checked) {
            checkBoxSelectedItems1.push(checkBoxList1[i].value);
            ary +=    checkBoxList1[i].value+",";
        }
    }
    alert(ary);
}

function enableJMS()
{
	getValueUsingClass();
	
	var div = document.getElementById("TrendBar");
	div.style.display = "none"; 
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="block";
	document.getElementById("JMSTrendsChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#JMSTrendsChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getJMSLabels(),
	        datasets: [{
	            data: <%=alertTypeJMSData.values()%>,
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'JMS Trends',
	            fontSize: 24
	        }
	    }
	});	
}

//FILE TREND
function getFileLabels()
{
	var labelList = ["brehat","ushant" ,"gsscgnh2" ,"harris" ,"lewis" ];	
	return labelList;
}

function enableFile()
{
	var div = document.getElementById("TrendBar");
	div.style.display = "none"; 
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "block"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="block";
	document.getElementById("FileTrendsChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#FileTrendsChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getFileLabels(),
	        datasets: [{
	            data: [21,17,13,4,3],
	            borderColor: "#458af7",
	            backgroundColor: ["#0074D9",  "#2ECC40", "#FF851B", "#7FDBFF", "#B10DC9", "#FFDC00", "#001f3f", "#39CCCC", "#01FF70", "#85144b", "#F012BE", "#3D9970", "#111111", "#AAAAAA"],
	            fill: false
	        }]
	    },
	    options: {
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: false
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'FileSystem Trends',
	            fontSize: 24
	        }
	    }
	});	
}

//WEEKLY TREND
function getWeekLabels()
{
	var currWeek = weekNumber();
	var labelList = ["Current Week", "Week "+(currWeek -1), "Week "+(currWeek -2), "Week "+(currWeek -3)];
	
	return labelList;
}

function enableWeek()
{
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "none"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="block";
	document.getElementById("WeeklyChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	
	var ctx = $("#WeeklyChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getWeekLabels(),
	        datasets: [	        	
		        	 {
		                 label: "Disconnect_Camera_Tunnel",
		                 backgroundColor: "#4F81BC",
		                 data: [12,11,2,4]
		             },
		             {
		                 label: "rfscPFrfMetNumber",
		                 backgroundColor: "#C0504E",
		                 data: [4,3,5,2]
		             },
		             {
		                 label: "FileSystem",
		                 backgroundColor: "silver",
		                 data: [4,2,1,3]
		             },
		     		{
		                 label: "JMS Queue",
		                 backgroundColor: "black",
		                 data: [15,10,11,6]
		             },
			    {
		                 label: "No_Chute_Asgnmt_found",
		                 backgroundColor: "yellow",
		                 data: [2,1,3,8]
		             }  

		        ]
	    },
	    options: {
	    	responsive: true,
	    	  legend: {
	    	    position: "right"
	    	  },
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: true
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'Weekly Trends',
	            fontSize: 24
	        }
	        
	    }
	});	
}

function getMonthlyLabels()
{
	var labelList = [ "Apr", "May", "Jun"];	
	return labelList;
}

//MONTHLY TREND
function enableMonthly()
{
	var div2 = document.getElementById("DateRangeLabel");
	div2.style.display = "none"; 
	document.getElementById('DXBChartEmpty').style.display = "none";
	document.getElementById("AlltypeChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="block";
	document.getElementById("MonthlyChart").style.visibility = "visible";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("CGNChart").style.display="none";
	
	var ctx = $("#MonthlyChart");
	var myLineChart = new Chart(ctx, {
	    type: 'bar',
	    data: {
	        labels: getMonthlyLabels(),
	        datasets: [
	        	 {
	                 label: "Disconnect_Camera_Tunnel",
	                 backgroundColor: "#4F81BC",
	                 data: [22,31,12]
	             },
	             {
	                 label: "rfscPFrfMetNumber",
	                 backgroundColor: "#C0504E",
	                 data: [18,34,51]
	             },
	             {
	                 label: "FileSystem",
	                 backgroundColor: "silver",
	                 data: [7,2,1]
	             },
	     		{
	                 label: "JMS Queue",
	                 backgroundColor: "black",
	                 data: [25,12,17]
	             }           
	            
	        ]
	    },
	    options: {
	    	responsive: true,
	    	  legend: {
	    	    position: "right"
	    	  },
	    	"hover": {
	              "animationDuration": 0
	            },
	             "animation": {
	                "duration": 1,
	              "onComplete": function() {
	                var chartInstance = this.chart,
	                  ctx = chartInstance.ctx;
	 
	                ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
	                ctx.textAlign = 'center';
	                ctx.textBaseline = 'bottom';
	 
	                this.data.datasets.forEach(function(dataset, i) {
	                  var meta = chartInstance.controller.getDatasetMeta(i);
	                  meta.data.forEach(function(bar, index) {
	                    var data = dataset.data[index];
	                    ctx.fillText(data, bar._model.x, bar._model.y - 5);
	                  });
	                });
	              }
	            },
	    	legend: {
	            display: true
	        },
	        scales: {
	            xAxes: [{
	            	barPercentage : 0.5,
	                ticks: {
	                    autoSkip: false,
	                    maxRotation: 45,
	                    minRotation: 45
	                }
	            }],
	            yAxes: [{
	                ticks: {
	                    beginAtZero: true
	                }
	            }]
	        },
	        tooltips: {
	            enabled: false
	         },
	        title: {
	            display: true,
	            text: 'Monthly Trends',
	            fontSize: 24
	        }
	    }
	});	
}

window.onload = function() {
	document.getElementById("AlltypeChart").style.visibility = "visible";
	document.getElementById("CGNChart").style.display="none";
	document.getElementById("CPHChart").style.display="none";
	document.getElementById("CDGChart").style.display="none";
	document.getElementById("MXPChart").style.display="none";
	document.getElementById("DXBChart").style.display="none";
	document.getElementById("STNChart").style.display="none";
	document.getElementById("ErrorLogChart").style.display="none";
	document.getElementById("JMSTrendsChart").style.display="none";
	document.getElementById("FileTrendsChart").style.display="none";
	document.getElementById("WeeklyChart").style.display="none";
	document.getElementById("MonthlyChart").style.display="none";
	var radio0 = document.getElementById("radio0");
	enableAll(radio0);
}

function data2blob(data, isBase64) {
	  var chars = "";

	  if (isBase64)
	    chars = atob(data);
	  else
	    chars = data;

	  var bytes = new Array(chars.length);
	  for (var i = 0; i < chars.length; i++) {
	    bytes[i] = chars.charCodeAt(i);
	  }

	  var blob = new Blob([new Uint8Array(bytes)]);
	  return blob;
	}

function saveReport()
{
	window.location = "saveGSSExcel.jsp";
	return false;
}

function save(){
	str = document.forms[0].t1.value;
	mydoc = document.open();
	mydoc.write(str);
	mydoc.execCommand("saveAs",true,".txt");
	mydoc.close();
	return false;
}

function weekNumber(){
	todaydate = new Date();  
     var oneJan =  new Date(todaydate.getFullYear(), 0, 1);   
     var numberOfDays =  Math.floor((todaydate - oneJan) / (24 * 60 * 60 * 1000));  
     var result = Math.ceil(( todaydate.getDay() + 1 + numberOfDays) / 7);   
     return result;  
}
function chkOnLoadStatus()
{
	<%
	if(retStat != null)
	{
	%>
		alert('<%=retStat%>');
	<%}%>
	var radio0 = document.getElementById("radio0");
	enableAll(radio0);
}
function logout()
{
	<%-- <% session.invalidate();%> --%>
	window.location = "Login.jsp";
}
function toggle()
{
	if(document.getElementById('customCheck0').checked)
	{
		document.getElementById("customCheck1").checked = true;
		document.getElementById("customCheck2").checked = true;
		document.getElementById("customCheck3").checked = true;
		document.getElementById("customCheck4").checked = true;
		document.getElementById("customCheck5").checked = true;
		document.getElementById("customCheck6").checked = true;
	}
	else
	{
		document.getElementById("customCheck1").checked = false;
		document.getElementById("customCheck2").checked = false;
		document.getElementById("customCheck3").checked = false;
		document.getElementById("customCheck4").checked = false;
		document.getElementById("customCheck5").checked = false;
		document.getElementById("customCheck6").checked = false;
	}
		
}
/* function EnableCGNTrends(CGNCheck)
{
	if(document.getElementById('customCheck0').checked)
	{
} */
</script>
<style type="text/css">

body {
  margin: 0;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 20%;
  background-color: #C0C0C0;
  position: fixed;
  height: 100%;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}

li a.active {
  background-color: #4CAF50;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}

li a:checked
{
  background: white;
  border-bottom: 1px solid white;
  z-index: 2;
}

.container
{
	display:flex;
	justify-content:center;
}
.toolbar {
    height: 70px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .out{
  float: right;
  font-size: 20px;
  color: white;
  margin: 1px;
  border-radius: 1px;
  border: 1px solid #eee;
  background-color: rgb(154 81 150); 
  width: 130px;
  height: 30px;
}
.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:1%;
	margin-left:25%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:25%;
	}
	
ul.topnav {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
   height: 7%;
   width:75%;
}

ul.topnav li {float: left;}

ul.topnav li a {
  display: block;
  color: white;
  text-align: center;
  padding: 10px 10px;
  text-decoration: none;
}

ul.topnav li a:hover:not(.active) {background-color: #111;}

ul.topnav li a.active {background-color: #04AA6D;}

ul.topnav li.right {float: right;}


.modal-body{
    height: 80vh;
    overflow-y: auto;
}
table, th, td {
  border: 1px solid black;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
		margin-left: 5%
	}
</style>
</head>
<body onload="chkOnLoadStatus()">
<div class="toolbar" role="banner">
<button class="out"  onclick="goBack()" >Home</button>
    <img
      width="143"
      alt="Angular Logo"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR4h9OKkNpZrtc-Z6l80kuRFy9wn3DPFOHaIncREOOreXAWEKLG"
      title= "FedEx"
      />
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
     
     <div style="margin-left: 40%">&nbsp;&nbsp;
     <label style = "color: white;" for="uID"><b> <%=userID %></b></label>
    <br>
     <button class="out" onclick="logout()" >Logout</button>
     </div>
</div>

<div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:5px 0 0 0; margin-left: 5%;">
        	GSS Alert Analytics  	 </p>
   		
   		</div>
   		
<ul>
 
  <li> <label style = "color: navy; background-color:green; width:95%; margin-left: 5% ;font-size: larger;"  for="Location"><b>Locations: </b>&nbsp;&nbsp;&nbsp;&nbsp;</label>
  <br>
  <div id = "LocSel" class="col-1" style = "margin-left: 5%; font-size: larger;">            
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio0" name="LocAlertRadio" onclick="enableAll(this)" checked="checked">
        <label class="custom-control-label" for="radio0">ALL</label>
      </div>      
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio1" name="LocAlertRadio" onclick="enableCGN(this)">
        <label class="custom-control-label" for="radio1">CGN</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio2" name="LocAlertRadio" onclick="enableCPH(this)">
        <label class="custom-control-label" for="radio2">CPH</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio3" name="LocAlertRadio" onclick="enableCDG(this)">
        <label class="custom-control-label" for="radio3">CDG</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio4" name="LocAlertRadio" onclick="enableMXP(this)">
        <label class="custom-control-label" for="radio4">MXP</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio5" name="LocAlertRadio" onclick="enableDXB(this)">
        <label class="custom-control-label" for="radio5">DXB</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" class="custom-control-input" id="radio6" name="LocAlertRadio" onclick="enableSTN(this)">
        <label class="custom-control-label" for="radio6">STN</label>
      </div>
    </div>

  
  <br> </li>
<li> <label  style = "color: navy; background-color:green; width:95%;;margin-left: 5%;font-size: larger;"  for="Trends"><b>Trends: </b>&nbsp;&nbsp;&nbsp;&nbsp;</label>
  
  <div id = "LocSel2" style = "margin-left: 5%; font-size: medium; background-color: threedhighlight;">
      <div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck0"  value="ALL" onchange="toggle()">
        <label class="form-check-label" for="customCheck0">ALL</label>
     </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck1"  value="CGN" onclick="EnableCGNTrends(this)">
        <label class="form-check-label" for="customCheck1">CGN</label>
     </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck2"  value="CPH">
        <label class="form-check-label" for="customCheck2">CPH</label>
      </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck3"  value="CDG">
        <label class="form-check-label" for="customCheck3">CDG</label>
     </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck4"  value="MXP">
        <label class="form-check-label" for="customCheck4">MXP</label>
      </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck5"  value="DXB">
        <label class="form-check-label" for="customCheck5">DXB</label>
      </div>
	<div class="form-check form-check-inline">
        <input type="checkbox" class="form-check-input" id="customCheck6"  value="STN">
        <label class="form-check-label" for="customCheck6">STN</label>
     </div>
    </div>
<br>
  <div class="col-8" style="margin-left: 5%;font-size: larger;">
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" id="customRadioInline1" name="customRadioInline1" class="custom-control-input" onclick="enableJMS()">
        <label class="custom-control-label" for="customRadioInline1">JMS </label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" id="customRadioInline2" name="customRadioInline1" class="custom-control-input" onclick="enableFile()">
        <label class="custom-control-label" for="customRadioInline2">File System </label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" id="customRadioInline5" name="customRadioInline1" class="custom-control-input" onclick="enableERROR()">
        <label class="custom-control-label" for="customRadioInline5">Error Log</label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" id="customRadioInline3" name="customRadioInline1" class="custom-control-input" onclick="enableWeek()">
        <label class="custom-control-label" for="customRadioInline3">Weekly </label>
      </div>
      <div class="custom-control custom-radio custom-control-inline">
        <input type="radio" id="customRadioInline4" name="customRadioInline1" class="custom-control-input" onclick="enableMonthly()">
        <label class="custom-control-label" for="customRadioInline4">Monthly </label>
      </div>
    </div>
  
    <br><br> </li>
</ul>

<div style="margin-left:20%;padding:5px 5px;height:500px; background-color: #f1f1f1">
 <ul id="TrendBar" class="topnav" style="display: none;">
  <li><a class="active" href="#WTrends" onclick="enableWeek()">Weekly Trends</a></li>
  <li><a href="#MTrends" onclick="enableMonthly()">Monthly Trends</a></li>
</ul>
	<div id="DateRangeLabel"> <span style="font-size: large; font-weight: bold; color: red; text-align: center;">For the date range : <%=SDate %>  to  <%=EDate %> (CEST)</span> </div>
	
	<div style="margin-bottom:10%; margin-right:10%;">
	<canvas id="AlltypeChart" class="chartjs-render-monitor" ></canvas>
	<canvas id="CGNChart" class="chartjs-render-monitor" ></canvas>
	<canvas id="CPHChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="CDGChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="MXPChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="DXBChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="STNChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="ErrorLogChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="JMSTrendsChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="FileTrendsChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="WeeklyChart"  class="chartjs-render-monitor" ></canvas>
	<canvas id="MonthlyChart"  class="chartjs-render-monitor" ></canvas>
	
	 <label id ="DXBChartEmpty" class="custom-control-label" style="font-weight: bold; font-size: x-large; display: none; " for="customRadioInline1">No data to display </label>
	<!-- style="display: inline; width: 299px; height: 200px;" -->
	</div>
</div><br><br>


<div class="container" >
	<button class="buttonFont" onclick="saveReport()" > Export </button>
</div>


<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content" style=" width:900px; height: 600px; ">
        <div class="modal-header">
        <h3 class="modal-title" style="background-color: purple; color: white;" id="myModalLabel">Alert details</h3>  
          <button type="button"  class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  
        </div>
        <div class="modal-body" id ="modalContent" >
         
       </div>
       <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</body>
</html>                        