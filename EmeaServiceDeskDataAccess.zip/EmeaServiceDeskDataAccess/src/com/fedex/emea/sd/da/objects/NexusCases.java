package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.ArrayList;

import com.fedex.emea.sd.da.helpers.Utilities;

public class NexusCases implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int    caseId;
	private String caseOriginPin;
	private String caseLocation;
	private String caseBusinessUnit;
	private String caseOwnership;
	private String caseSummary;
	private String caseDescription;
	private String casePriority;
	private String caseType;
	private String caseSeverity;
	private String caseSource;
	private String caseProviderGroup;
	private String caseStatus;
	private String caseFdxNode;
	private String caseFdxVendor;
	private String caseFdxVendorId;
	private String caseFdxSystem;
	private String caseFdxApplication;
	private String caseFdxBusImpact;
	private String caseFdxCause;
	private String caseFdxImpact;
	private String caseCategory;
	private String caseCallType;
	private String caseProblemType;
	private String caseProblemDetail;
	private String caseProblemDescription;
	private String caseAssignedTo;
	private String caseSolution;
	private ArrayList<NexusCasesNotes> caseNotes;
	private ArrayList<String>          caseResolutions;
	
	public NexusCases() {
	}
	
	public NexusCases(String caseOriginPin, String caseLocation, String caseBusinessUnit, String caseOwnership, String caseSummary, String caseDescription, String casePriority, String caseType, String caseSeverity, String caseSource, String caseProviderGroup, String caseStatus, String caseFdxNode, String caseFdxVendor, String caseFdxVendorId, String caseFdxSystem, String caseFdxApplication, String caseCategory, String caseCallType, String caseProblemType, String caseProblemDetail, String caseProblemDescription, String caseAssignedTo, String caseSolution) {
		this.caseOriginPin = caseOriginPin;
		this.caseLocation = caseLocation;
		this.caseBusinessUnit = caseBusinessUnit;
		this.caseOwnership = caseOwnership;
		this.caseSummary = caseSummary;
		this.caseDescription = caseDescription;
		this.casePriority = casePriority;
		this.caseType = caseType;
		this.caseSeverity = caseSeverity;
		this.caseSource = caseSource;
		this.caseProviderGroup = caseProviderGroup;
		this.caseStatus = caseStatus;
		this.caseFdxNode = caseFdxNode;
		this.caseFdxVendor = caseFdxVendor;
		this.caseFdxVendorId = caseFdxVendorId;
		this.caseFdxSystem = caseFdxSystem;
		this.caseFdxApplication = caseFdxApplication;
		this.caseCategory = caseCategory;
		this.caseCallType = caseCallType;
		this.caseProblemType = caseProblemType;
		this.caseProblemDetail = caseProblemDetail;
		this.caseProblemDescription = caseProblemDescription;
		this.caseAssignedTo = caseAssignedTo;
		this.caseSolution = caseSolution;
	}
	
	public NexusCases(NexusInterface nexusInterface) {
		this.caseOriginPin = nexusInterface.getCaseOriginPin();
		this.caseLocation = nexusInterface.getCaseLocation();
		this.caseBusinessUnit = nexusInterface.getCaseBusinessUnit();
		this.caseOwnership = nexusInterface.getCaseOwnership();
		this.caseSummary = nexusInterface.getCaseSummary();
		this.caseDescription = nexusInterface.getCaseDescription1();
		if (nexusInterface.getCaseDescription2() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription2();
		}
		if (nexusInterface.getCaseDescription3() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription3();
		}
		if (nexusInterface.getCaseDescription4() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription4();
		}
		if (nexusInterface.getCaseDescription5() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription5();
		}
		if (nexusInterface.getCaseDescription6() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription6();
		}
		if (nexusInterface.getCaseDescription7() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription7();
		}
		if (nexusInterface.getCaseDescription8() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription8();
		}
		if (nexusInterface.getCaseDescription9() != null) {
			this.caseDescription = this.caseDescription + nexusInterface.getCaseDescription9();
		}
		this.casePriority = nexusInterface.getCasePriority();
		this.caseType = nexusInterface.getCaseType();
		this.caseSeverity = nexusInterface.getCaseSeverity();
		this.caseSource = nexusInterface.getCaseSource();
		this.caseProviderGroup = nexusInterface.getCaseProviderGroup();
		this.caseStatus = nexusInterface.getCaseStatus();
		this.caseCategory = nexusInterface.getCaseCategory();
		this.caseCallType = nexusInterface.getCaseCallType();
		this.caseProblemDetail = nexusInterface.getCaseProblemDetail();
		this.caseProblemDescription = nexusInterface.getCaseProblemDescription();
		this.caseProblemType = nexusInterface.getCaseProblemType();
		this.caseAssignedTo = Utilities.nullToEmptyString(nexusInterface.getCaseAssignedTo());
		this.caseSolution = nexusInterface.getCaseSolution();
		this.caseFdxNode = Utilities.nullToEmptyString(nexusInterface.getCaseFdxNode());
		this.caseFdxVendor = Utilities.nullToEmptyString(nexusInterface.getCaseFdxVendor());
		this.caseFdxVendorId = Utilities.nullToEmptyString(nexusInterface.getCaseFdxVendorId());
		this.caseFdxSystem = Utilities.nullToEmptyString(nexusInterface.getCaseFdxSystem());
		this.caseFdxApplication = Utilities.nullToEmptyString(nexusInterface.getCaseFdxApplication());
	}

	public String getCaseBusinessUnit() {
		return caseBusinessUnit;
	}

	public void setCaseBusinessUnit(String caseBusinessUnit) {
		this.caseBusinessUnit = caseBusinessUnit;
	}
	
	public String getCaseOwnership() {
		return caseOwnership;
	}

	public void setCaseOwnership(String caseOwnership) {
		this.caseOwnership = caseOwnership;
	}

	public String getCaseSummary() {
		return caseSummary;
	}

	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}

	public String getCaseDescription() {
		return caseDescription;
	}

	public void setCaseDescription(String caseDescription) {
		this.caseDescription = caseDescription;
	}

	public String getCasePriority() {
		return casePriority;
	}

	public void setCasePriority(String casePriority) {
		this.casePriority = casePriority;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getCaseSeverity() {
		return caseSeverity;
	}

	public void setCaseSeverity(String caseSeverity) {
		this.caseSeverity = caseSeverity;
	}

	public String getCaseSource() {
		return caseSource;
	}

	public void setCaseSource(String caseSource) {
		this.caseSource = caseSource;
	}

	public String getCaseProviderGroup() {
		return caseProviderGroup;
	}

	public void setCaseProviderGroup(String caseProviderGroup) {
		this.caseProviderGroup = caseProviderGroup;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getCaseFdxNode() {
		return caseFdxNode;
	}

	public void setCaseFdxNode(String caseFdxNode) {
		this.caseFdxNode = caseFdxNode;
	}

	public String getCaseFdxVendor() {
		return caseFdxVendor;
	}

	public void setCaseFdxVendor(String caseFdxVendor) {
		this.caseFdxVendor = caseFdxVendor;
	}

	public String getCaseFdxVendorId() {
		return caseFdxVendorId;
	}

	public void setCaseFdxVendorId(String caseFdxVendorId) {
		this.caseFdxVendorId = caseFdxVendorId;
	}

	public String getCaseFdxSystem() {
		return caseFdxSystem;
	}

	public void setCaseFdxSystem(String caseFdxSystem) {
		this.caseFdxSystem = caseFdxSystem;
	}

	public String getCaseFdxApplication() {
		return caseFdxApplication;
	}

	public void setCaseFdxApplication(String caseFdxApplication) {
		this.caseFdxApplication = caseFdxApplication;
	}

	public String getCaseCategory() {
		return caseCategory;
	}

	public void setCaseCategory(String caseCategory) {
		this.caseCategory = caseCategory;
	}

	public String getCaseCallType() {
		return caseCallType;
	}

	public void setCaseCallType(String caseCallType) {
		this.caseCallType = caseCallType;
	}

	public String getCaseProblemType() {
		return caseProblemType;
	}

	public void setCaseProblemType(String caseProblemType) {
		this.caseProblemType = caseProblemType;
	}

	public String getCaseProblemDetail() {
		return caseProblemDetail;
	}

	public void setCaseProblemDetail(String caseProblemDetail) {
		this.caseProblemDetail = caseProblemDetail;
	}

	public String getCaseProblemDescription() {
		return caseProblemDescription;
	}

	public void setCaseProblemDescription(String caseProblemDescription) {
		this.caseProblemDescription = caseProblemDescription;
	}

	public String getCaseAssignedTo() {
		return caseAssignedTo;
	}

	public void setCaseAssignedTo(String caseAssignedTo) {
		this.caseAssignedTo = caseAssignedTo;
	}

	public String getCaseSolution() {
		return caseSolution;
	}

	public void setCaseSolution(String caseSolution) {
		this.caseSolution = caseSolution;
	}

	public String getCaseOriginPin() {
		return caseOriginPin;
	}

	public void setCaseOriginPin(String caseOriginPin) {
		this.caseOriginPin = caseOriginPin;
	}

	public String getCaseLocation() {
		return caseLocation;
	}

	public void setCaseLocation(String caseLocation) {
		this.caseLocation = caseLocation;
	}

	public int getCaseId() {
		return caseId;
	}

	public void setCaseId(int caseId) {
		this.caseId = caseId;
	}

	public ArrayList<NexusCasesNotes> getCaseNotes() {
		return caseNotes;
	}

	public void setCaseNotes(ArrayList<NexusCasesNotes> caseNotes) {
		this.caseNotes = caseNotes;
	}

	public ArrayList<String> getCaseResolutions() {
		return caseResolutions;
	}

	public void setCaseResolutions(ArrayList<String> caseResolutions) {
		this.caseResolutions = caseResolutions;
	}

	public String getCaseFdxBusImpact() {
		return caseFdxBusImpact;
	}

	public void setCaseFdxBusImpact(String caseFdxBusImpact) {
		this.caseFdxBusImpact = caseFdxBusImpact;
	}

	public String getCaseFdxCause() {
		return caseFdxCause;
	}

	public void setCaseFdxCause(String caseFdxCause) {
		this.caseFdxCause = caseFdxCause;
	}

	public String getCaseFdxImpact() {
		return caseFdxImpact;
	}

	public void setCaseFdxImpact(String caseFdxImpact) {
		this.caseFdxImpact = caseFdxImpact;
	}
}
