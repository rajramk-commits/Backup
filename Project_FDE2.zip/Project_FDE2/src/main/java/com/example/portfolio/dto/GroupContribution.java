package com.example.portfolio.dto;

import java.math.BigDecimal;

public class GroupContribution {
    private String groupName;;
    private BigDecimal contributionPct;
    public enum pricingMode {
        PRIMARY,
        FALLBACK_USED
    }

    public GroupContribution() {
    }

    public GroupContribution(String groupName, BigDecimal contributionPct) {
        this.groupName = groupName;
        this.contributionPct = contributionPct;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public BigDecimal getContributionPct() {
        return contributionPct  ;
    }

    public void setContributionPct(BigDecimal contributionPct) {
        this.contributionPct = contributionPct;
    }
}
