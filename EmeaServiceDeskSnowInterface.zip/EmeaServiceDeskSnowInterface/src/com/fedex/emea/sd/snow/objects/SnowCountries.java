package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowCountries implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowActive;
	private String snowIana;
	private String snowIso31662;
	private String snowIso31663;
	private String snowName;
	private String snowOrder;
	private String snowPopulation;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowU_Region;
	private String snowU_Region2;
	private String snowUnNumeric;
	
	public SnowCountries() {
	}
	
	public SnowCountries(HashMap<String, Object> jsonValues) {
		snowActive = SnowUtilities.getStringValueFromObject(jsonValues.get("active"));
		snowIana = SnowUtilities.getStringValueFromObject(jsonValues.get("iana"));
		snowIso31662 = SnowUtilities.getStringValueFromObject(jsonValues.get("iso3166_2"));
		snowIso31663 = SnowUtilities.getStringValueFromObject(jsonValues.get("iso3166_3"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("order"));
		snowPopulation = SnowUtilities.getStringValueFromObject(jsonValues.get("population"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowU_Region = SnowUtilities.getStringValueFromObject(jsonValues.get("u_region"));
		snowU_Region2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_region2"));
		snowUnNumeric = SnowUtilities.getStringValueFromObject(jsonValues.get("un_numeric"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowActive != null && !snowActive.toString().isEmpty()) jsonObject.put("active", snowActive);
		if (snowIana != null && !snowIana.toString().isEmpty()) jsonObject.put("iana", snowIana);
		if (snowIso31662 != null && !snowIso31662.toString().isEmpty()) jsonObject.put("iso3166_2", snowIso31662);
		if (snowIso31663 != null && !snowIso31663.toString().isEmpty()) jsonObject.put("iso3166_3", snowIso31663);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowOrder != null && !snowOrder.toString().isEmpty()) jsonObject.put("order", snowOrder);
		if (snowPopulation != null && !snowPopulation.toString().isEmpty()) jsonObject.put("population", snowPopulation);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowU_Region != null && !snowU_Region.toString().isEmpty()) jsonObject.put("u_region", snowU_Region);
		if (snowU_Region2 != null && !snowU_Region2.toString().isEmpty()) jsonObject.put("u_region2", snowU_Region2);
		if (snowUnNumeric != null && !snowUnNumeric.toString().isEmpty()) jsonObject.put("un_numeric", snowUnNumeric);
		
		return jsonObject;
	}

	public String getSnowActive() {
		return snowActive;
	}

	public void setSnowActive(String snowActive) {
		this.snowActive = snowActive;
	}

	public String getSnowIana() {
		return snowIana;
	}

	public void setSnowIana(String snowIana) {
		this.snowIana = snowIana;
	}

	public String getSnowIso31662() {
		return snowIso31662;
	}

	public void setSnowIso31662(String snowIso31662) {
		this.snowIso31662 = snowIso31662;
	}

	public String getSnowIso31663() {
		return snowIso31663;
	}

	public void setSnowIso31663(String snowIso31663) {
		this.snowIso31663 = snowIso31663;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowOrder() {
		return snowOrder;
	}

	public void setSnowOrder(String snowOrder) {
		this.snowOrder = snowOrder;
	}

	public String getSnowPopulation() {
		return snowPopulation;
	}

	public void setSnowPopulation(String snowPopulation) {
		this.snowPopulation = snowPopulation;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowU_Region() {
		return snowU_Region;
	}

	public void setSnowU_Region(String snowU_Region) {
		this.snowU_Region = snowU_Region;
	}

	public String getSnowU_Region2() {
		return snowU_Region2;
	}

	public void setSnowU_Region2(String snowU_Region2) {
		this.snowU_Region2 = snowU_Region2;
	}

	public String getSnowUnNumeric() {
		return snowUnNumeric;
	}

	public void setSnowUnNumeric(String snowUnNumeric) {
		this.snowUnNumeric = snowUnNumeric;
	}
	
}
