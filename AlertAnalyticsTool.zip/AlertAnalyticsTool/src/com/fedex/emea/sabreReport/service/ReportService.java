package com.fedex.emea.sabreReport.service;

import java.io.IOException;

import com.fedex.emea.sabreReport.constants.ReportConstants;
import com.fedex.emea.sabreReport.util.ReportUtil;

public class ReportService {
	
	public static String generateReport()
	{
		try
		{
			ReportUtil.allTypeAlertChat();
			return "Successfully created report under the selected folder :E:/AlertReports/";
		}
		catch(IOException e)
		{
			e.printStackTrace();
			return "Error detected while generating report";
		}
	}
}
