package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the PR_SPOCS table.
 */
public class PrSpocsPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -6797511641932385379L;

	protected String mdPin;

	protected String mgrPin;

	/** 
	 * Sets the value of mdPin
	 */
	public void setMdPin(String mdPin)
	{
		this.mdPin = mdPin;
	}

	/** 
	 * Gets the value of mdPin
	 */
	public String getMdPin()
	{
		return mdPin;
	}

	/** 
	 * Sets the value of mgrPin
	 */
	public void setMgrPin(String mgrPin)
	{
		this.mgrPin = mgrPin;
	}

	/** 
	 * Gets the value of mgrPin
	 */
	public String getMgrPin()
	{
		return mgrPin;
	}

	/**
	 * Method 'PrSpocsPk'
	 * 
	 */
	public PrSpocsPk()
	{
	}

	/**
	 * Method 'PrSpocsPk'
	 * 
	 * @param mdPin
	 * @param mgrPin
	 */
	public PrSpocsPk(final String mdPin, final String mgrPin)
	{
		this.mdPin = mdPin;
		this.mgrPin = mgrPin;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSpocsPk)) {
			return false;
		}
		
		final PrSpocsPk _cast = (PrSpocsPk) _other;
		if (mdPin == null ? _cast.mdPin != mdPin : !mdPin.equals( _cast.mdPin )) {
			return false;
		}
		
		if (mgrPin == null ? _cast.mgrPin != mgrPin : !mgrPin.equals( _cast.mgrPin )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (mdPin != null) {
			_hashCode = 29 * _hashCode + mdPin.hashCode();
		}
		
		if (mgrPin != null) {
			_hashCode = 29 * _hashCode + mgrPin.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSpocsPk: " );
		ret.append( "mdPin=" + mdPin );
		ret.append( ", mgrPin=" + mgrPin );
		return ret.toString();
	}

}
