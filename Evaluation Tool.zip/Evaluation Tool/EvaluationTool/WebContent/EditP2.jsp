<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%     	
String useridddd = (String) session.getAttribute("Userid");

        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
        %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>

<script>
function openLoginMenu() {
	window.close("EditP2.jsp");
	window.open("Admin.jsp");
}
function goBack()
{
	window.close("EditP2.jsp");
	window.open("ViewDelQuestionP2.jsp");
}
function QuestionValidation(){
    if(document.getElementById("Question").value==null || document.getElementById("Question").value==""){
	   document.getElementById("OptionABlank").innerHTML="";
	   document.getElementById("OptionBBlank").innerHTML="";
	   document.getElementById("CorrectAnsBlank").innerHTML="";
	   document.getElementById("QuestionBlank").innerHTML = "Please Enter the Question";
	   return false;
	}
   if(document.getElementById("OptionA").value==null || document.getElementById("OptionA").value===""){
	  
	   document.getElementById("OptionBBlank").innerHTML="";
	   document.getElementById("CorrectAnsBlank").innerHTML="";
	   document.getElementById("QuestionBlank").innerHTML = "";
	   document.getElementById("OptionABlank").innerHTML = "Please Enter the Option";
	   return false;
	}
    if(document.getElementById("OptionB").value==null || document.getElementById("OptionB").value==""){
    	 	document.getElementById("OptionABlank").innerHTML="";
		 
		   document.getElementById("CorrectAnsBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "";
	   document.getElementById("OptionBBlank").innerHTML = "Please Enter the Option";
	   return false;
	}
   
    if(document.getElementById("CorrectAns").value==null || document.getElementById("CorrectAns").value==""){
    	 document.getElementById("OptionABlank").innerHTML="";
		   document.getElementById("OptionBBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "";
	   document.getElementById("CorrectAnsBlank").innerHTML = "Please Enter the Value";
	   return false;
	}
    return true;
}

</script>
<style>
.main {
	margin-left: 10%;
	margin-right: 12%;
}

.head {
	height: 50px;
	background-color: #7030a0;
	margin: 0;
}

.logout {
	float: right;
	margin-right: 5%;
	background-color: #FF8C00;
	color: white;
	padding: 14px 20px;
	border: none;
	cursor: pointer;
}

.logout:hover {
	background-color: #4B0060;
}

.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

textarea{
  width: 650px;
  height: 60px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-family:Calibri;
  
}
input[type=text]{
  width: 650px;
  height: 50px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  
}
</style>
</head>
<body>
<div class="main">
		<div class="head">
			<center>
				<p
					style="font-family: Calibri; font-weight: 700; color: white; font-size: 20px; padding: 12px 0 0 0">Edit/Update the question for P1</p>
			</center>
		</div>

		<form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class="logout"
				style="margin-top: 6px; font-family: Calibri; font-size: 16px">Logout</button>
		</form>
		<div
			style="margin: 15px 0 0px 40px; font-family: Calibri; font-size: 16px">
			<b>Welcome :</b>
			<%=userID %>
		</div>
		<button class="home" onclick="openLoginMenu()">HOME</button>
		<br> <br>
	<form action="SaveP2.jsp" method="post" onsubmit="return QuestionValidation()" >
     <%	
     	String team = request.getParameter("team");
     	String qnType = request.getParameter("qnType");
     	String qId = request.getParameter("qId");
     	String qn = request.getParameter("qn");
     	String opt1 = request.getParameter("opt1");
     	String opt2 =request.getParameter("opt2");
     	String opt3 =request.getParameter("opt3");
     	String opt4 =request.getParameter("opt4");
     	String crctAns =request.getParameter("crctAns");
     	
     	System.out.println("EditP2 : team="+team+",qnType="+qnType+",qId="+qId+", qn="+qn+", opt1="+opt1+", opt2="+opt2+", opt3="+opt3+", opt4="+opt4+", crctAns="+crctAns);
     	
     	 %>
		<table>
			<tr><td><div style="color:red;font-family:Calibri;">${showMessage}</div></td></tr>
			<tr>
				<td>Team Name<br><textarea  class="quest" id="teamNm" name="teamNm" ><%=team %></textarea></td>
				<td><div id="QuestionBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td>Question Type<br><textarea  class="quest" id="QuestionType" name="QuestionType" ><%=qnType %></textarea></td>
				<td><div id="QuestionBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td>Question<br><textarea  class="quest" id="Question" name="Question"  ><%=qn %></textarea></td>
				<td><div id="QuestionBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<%if(qnType.equalsIgnoreCase("mcq")) 
			{
			%>
				<tr>
					<td><br>Option A<br><textarea id="OptionA" name="OptionA"   ><%=opt1 %></textarea></td>
					<td><div id="OptionABlank" style="color:red;font-family:Calibri;"></div></td>
				</tr>
				<tr>
					<td><br>Option B<br><textarea id="OptionB" name="OptionB" ><%=opt2 %></textarea></td>
					<td><div id="OptionBBlank" style="color:red;font-family:Calibri;"></div></td>
				</tr>
				<tr>
					<td><br>Option C<br><textarea id="OptionC" name="OptionC" ><%=opt3 %></textarea></td>
				</tr>
				<tr>
					<td><br>Option D<br><textarea id="OptionD" name="OptionD" ><%=opt4 %></textarea></td>
				</tr>
				<tr>
					<td><br>Correct Answer<br><input type="text" id="CorrectAns" name="CorrectAns" maxlength="3" value="<%=crctAns %>" ></td>
					<td><div id="CorrectAnsBlank" style="color:red;font-family:Calibri;"></div></td>
				</tr>
			<%} %>
		</table>
		<br>
		 <input type="hidden" name="qId" value="<%=qId%>">
		<input type="submit" name="Submit"  value="Submit" >
		<input type="button" name="Cancel"  value="Cancel" onclick="goBack()">
	</form>

	<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>
<%}%>