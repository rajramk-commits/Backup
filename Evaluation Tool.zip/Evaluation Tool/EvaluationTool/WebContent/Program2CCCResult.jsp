<%@page import="javax.mail.internet.MimeMultipart"%>
<%@page import="javax.mail.BodyPart"%>
<%@page import="javax.mail.Multipart"%>
<%@page import="javax.activation.DataHandler"%>
<%@page import="javax.activation.FileDataSource"%>
<%@page import="javax.activation.DataSource"%>
<%@page import="javax.mail.internet.MimeBodyPart"%>
<%@page import="java.io.IOException"%>
<%@page import="java.io.FileWriter"%>
<%@page import="java.io.BufferedWriter"%>
<%@page import="java.io.Writer"%>
<%@page import="java.io.File"%>
<%@page import="javax.mail.MessagingException"%>
<%@page import="javax.mail.internet.AddressException"%>
<%@page import="javax.mail.Transport"%>
<%@page import="javax.mail.Message"%>
<%@page import="javax.mail.internet.InternetAddress"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.time.LocalTime"%>
<%@page import="java.util.*"%>
<%@page import="java.nio.file.*"%>
<%@page import="java.io.*"%>
<%@page import="java.text.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<jsp:useBean id="dao" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>

<html>    
	 <head>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <title>SD Evaluation</title>
	 <script>
	 window.history.forward();
	 function noBack() { window.history.forward(); 
	 }
		function openLoginMenu() {	
			var number=document.getElementById("sessionid").value;  
			if(number==("user")){
	   			 window.close("Program2CCCResult.jsp");
	   			window.open("LoginMenu.jsp");
	   		 }else{
	   			window.close("Program2CCCResult.jsp");
	   			window.open("Admin.jsp");
	   		 }   		 
		}
	</script>
	<style type="text/css">		
			.head{
					height :50px;
					background-color: #4B0082;
					margin:0;					
			}						
			button{
			
			background-color:#4B0082;
			color:white;
			padding:14px 20px;
			margin: 8px 0;
			border:none;
			cursor:pointer;
			width:20%;
			}
			.login{
				
				display:flex;
				justify-content:center;
			}			
			.main{
				margin-left:10%;
				margin-right:12%;
			}
			.logout{
			float:right;
			margin-right:5%;
			background-color:#FF8C00;
			color:white;
			padding:8px 8px;
			border:none;
			cursor:pointer;
			}
			.logout:hover{
			background-color:#4B0060;
			}
			.questionccc{
			font-family:Calibri;
			}
			.optiona{
			font-family:Calibri;
			}
			.optionb{
			font-family:Calibri;
			}
			.optionc{
			font-family:Calibri;
			}
			.optiond{
			font-family:Calibri;
			}
			.textAnsCSS
			{
			font-family:Calibri;
			color: blue;
			}
		</style>
	 </head>
	 
	 <body>
<%
	 String dirName = "C:/Users/rahul.raj/Documents/finaaal/Resources/";
	 DateFormat df = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss"); 
     //String dirName = "/opt/automationtools/Deployments/resources/";
	 if(session.getAttribute("sessionName")==null)
     {
      	response.sendRedirect("Login.jsp");
	 }
	 String userPIN = (String) session.getAttribute("userPin");
	 String userID = (String) session.getAttribute("sessionName");
	 String sessionid = (String) session.getAttribute("sessionid");%>
	
	 <div class="main">
	 <div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Program 2 Clearance CC Result</p>
   	 </div>
     <form action=" ${pageContext.request.contextPath}/Logout" method="post">
		<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
	 </form>
     <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
       	<b>Welcome :</b> <%=userID %>
     </div>    
     
     <%	String question,questiontype,optiona,optionb,optionc,optiond,Answer,Result,ans;  
  		Integer qid,Total = 0,k;
  		ArrayList<String> canslist = new ArrayList<String>();
  		ArrayList<String> cqidlist = new ArrayList<String>();
		Integer size=Integer.parseInt(request.getParameter("size"));
		String teamName = request.getParameter("teamName");
		String [] Uans = request.getParameterValues("cans");
		String [] Cqid = request.getParameterValues("cqid");
		final StringBuilder sbf = new StringBuilder(); 
  		%>	    
 <br>
 <br>		
<%  if(Uans!=null)
	{
		for(k=0;k<Uans.length;k++)
		{
	     	if(Uans[k].equals(":"))
	     	{
	     		canslist.add(sbf.toString());
	     		int n = sbf.length();
	     		sbf.replace(0, n,"");        			
	     	}               		              	
	   		else
	   			sbf.append(Uans[k]);
	     	System.out.println("canslist :"+canslist);
     	} 
	}
	%>
	<% int j=0;   
	StringBuilder emailattachment = new StringBuilder();
	emailattachment.append("Test Results\r\n");
	emailattachment.append("\r\n");
	emailattachment.append(userPIN+" : "+userID+"\r\n");
	emailattachment.append("Team : "+teamName+"\r\n");
	emailattachment.append("\r\n");
	int qnCount =0;
	%>
	<label style="color:Black;font-family:Calibri;font-size:20px"><b>MCQ Questions</b></label>
	<%
	emailattachment.append("MCQ Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	for(int i=0;i<size;i++)
	{
		qid=Integer.parseInt(request.getParameter("qid"+i));  
        question=request.getParameter("questionccc"+i);
        questiontype=request.getParameter("questiontype"+i);
        System.out.println("question questiontype : "+questiontype);
        
        if(questiontype.equalsIgnoreCase("MCQ"))
        {
	        optiona=request.getParameter("qoptiona"+i);
	      	optionb=request.getParameter("qoptionb"+i);
	        optionc=request.getParameter("qoptionc"+i);
	        optiond=request.getParameter("qoptiond"+i);
	        String cansLength = request.getParameter("cansLength"+i);
	        if(cansLength.equalsIgnoreCase("1"))
	        	ans = request.getParameter("ans"+i);
	        else
	        	ans = canslist.get(j);
	        System.out.println("question res : "+question+","+ans);
	        System.out.println("question qid : "+qid);
	 		Answer = dao.getAnswerbycccqid(qid);
 			System.out.println("question DB : "+Answer);
 		
	 		emailattachment.append(++qnCount+". "+question+"\r\n");
	 		emailattachment.append("A."+optiona+"\r\n");
	 		emailattachment.append("B."+optionb+"\r\n");
		%>
 		<label class="questionccc"><br><%=qnCount%>) </label>
 		<label class="questionccc"><%= question %><br></label>
 		<label class="optiona">A. <%= optiona%><br></label>
 		<label class="optionb">B. <%= optionb%><br></label>
 		<%if(!optionc.equals("null")){
 			emailattachment.append("C."+optionc+"\r\n");	
 		%>
 		<label class="optionc">C. <%= optionc%><br></label>
 		<%}%>
 		<%if(!optiond.equals("null")){
 			emailattachment.append("D."+optiond+"\r\n \r\n");
 		%>
 		<label class="optiond">D. <%= optiond%><br></label>
 		<%}%>		 				
 		<%	 String ansNA = "None of the option selected";
 			
 			if(Integer.toString(qid).equals(Cqid[j]))
 			{
 				if(Answer.equals(canslist.get(j)))
 		 		{
 					emailattachment.append("Correct :"+canslist.get(j)+"\r\n");
 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=canslist.get(j) %><br></label> <%
 		 			Total++; j++;
 		 		}
 				else
 				{
 					if(canslist.get(j) == null || canslist.get(j).trim().equalsIgnoreCase("null") || canslist.get(j).trim().equalsIgnoreCase(""))
 	 				{
 						emailattachment.append("Wrong :"+ansNA+"\r\n");
 	 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=ansNA %><br></label> <%
 	 		 			j++;
 	 				}
 					else{
 		 			emailattachment.append("Wrong :"+canslist.get(j)+"\r\n");
 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=canslist.get(j) %><br></label> <%
 		 			j++;
 					}
 		 		}
 			}
 			else
 			{
 				if(Answer.equals(ans))
 		 		{
 					emailattachment.append("Correct :"+ans+"\r\n");
 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=ans %><br></label> <%
 		 			Total++;
 		 		}
 				else
 				{
 					if(ans == null || ans.trim().equalsIgnoreCase("null") || ans.trim().equalsIgnoreCase("")){
 						emailattachment.append("Wrong :"+ansNA+"\r\n");
 	 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=ansNA %><br></label> <%
 					}
 					else{
 		 			emailattachment.append("Wrong :"+ans+"\r\n");
 		 			
 		 			%> <label style="color:blue;font-family:Calibri;">User answer : <%=ans %><br></label> <%
 					}
 					}
 			}
 			emailattachment.append("---------------------------------------------------------------------\r\n");
    	} 		
	}

	%> <br><br><label style="color:Black;font-family:Calibri;font-size:20px"><b>Descriptive Questions (One Marks)</b></label> <%
	emailattachment.append("\nOne Marks Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	
	for(int i=0;i<size;i++)
	{
		questiontype=request.getParameter("questiontype"+i);
		if(questiontype.equalsIgnoreCase("1M") )
	    {
		 	qid=Integer.parseInt(request.getParameter("qid"+i));  
	    	question=request.getParameter("questionccc"+i);    
	    	String textAns = request.getParameter("textAns"+i);
	    	System.out.println("textAns :"+textAns);
	    	%>
	    	<label class="questionccc"><br><%=++qnCount%>) </label>
	 		<label class="questionccc"><%= question %><br></label>
	 		<label class="textAnsCSS">User Answer :</label>
	 		<label class="textAnsCSS"><%= textAns %><br></label>
	    	<%
			emailattachment.append(qnCount+". "+question+"\r\n");
	     	emailattachment.append("User Answer : "+textAns+"\r\n");
	     	emailattachment.append("---------------------------------------------------------------------\r\n");
	    }     
	}

	%>
	<br><br><label style="color:Black;font-family:Calibri;font-size:20px"><b>Two Marks Questions</b></label>
	<%
	emailattachment.append("\nTwo Marks Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	
	for(int i=0;i<size;i++)
	{
	   	questiontype=request.getParameter("questiontype"+i);
	   	if(questiontype.equalsIgnoreCase("2M") )
	   	{
		   	qid=Integer.parseInt(request.getParameter("qid"+i));  
		   	question=request.getParameter("questionccc"+i);
	   		String textAns = request.getParameter("textAns"+i);
	   		System.out.println("textAns :"+textAns);
	   		%>
	   		<label class="questionccc"><br><%=++qnCount%>) </label>
			<label class="questionccc"><%= question %><br></label>
			<label class="textAnsCSS">User Answer :</label>
			<label class="textAnsCSS"><%= textAns %><br></label>
		  	<%
			emailattachment.append(qnCount+". "+question+"\r\n");
	    	emailattachment.append("User Answer : "+textAns+"\r\n");
	    	emailattachment.append("---------------------------------------------------------------------\r\n");
	   	}    
	}

	%>
	<br><br><label style="color:Black;font-family:Calibri;font-size:20px"><b>Three Marks Questions</b></label>
	<%
	emailattachment.append("\nThree Marks Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	
	for(int i=0;i<size;i++)
	{
	   	questiontype=request.getParameter("questiontype"+i);
	   	if ( questiontype.equalsIgnoreCase("3M"))
	   	{
		   	qid=Integer.parseInt(request.getParameter("qid"+i));  
		   	question=request.getParameter("questionccc"+i);
	   		String textAns = request.getParameter("textAns"+i);
	   		System.out.println("textAns :"+textAns);
	   		%>
	   		<label class="questionccc"><br><%=++qnCount%>) </label>
			<label class="questionccc"><%= question %><br></label>
			<label class="textAnsCSS">User Answer :</label>
			<label class="textAnsCSS"><%= textAns %><br></label>
	   		<%
			emailattachment.append(qnCount+". "+question+"\r\n");
	    	emailattachment.append("User Answer : "+textAns+"\r\n");
	    	emailattachment.append("---------------------------------------------------------------------\r\n");
	   	}   
	}

	%>
	<br><br><label style="color:Black;font-family:Calibri;font-size:20px"><b>Four Marks Questions</b></label>
	<%
	emailattachment.append("\nFour Marks Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	
	for(int i=0;i<size;i++)
	{
	   	questiontype=request.getParameter("questiontype"+i);
	   	if( questiontype.equalsIgnoreCase("4M"))
	   	{
		   	qid=Integer.parseInt(request.getParameter("qid"+i));  
		   	question=request.getParameter("questionccc"+i);
	   		String textAns = request.getParameter("textAns"+i);
	   		System.out.println("textAns :"+textAns);
	   		%>
	   		<label class="questionccc"><br><%=++qnCount%>) </label>
			<label class="questionccc"><%= question %><br></label>
			<label class="textAnsCSS">User Answer :</label>
			<label class="textAnsCSS"><%= textAns %><br></label>
	   		<%
			emailattachment.append(qnCount+". "+question+"\r\n");
	    	emailattachment.append("User Answer : "+textAns+"\r\n");
	    	emailattachment.append("---------------------------------------------------------------------\r\n");
	   	}
	}
	
	%>
	<br><br><label style="color:Black;font-family:Calibri;font-size:20px"><b>Five Marks Questions</b></label>
	<%
	emailattachment.append("\nFive Marks Questions\r\n");
	emailattachment.append("---------------------------------------------------------------------\r\n");
	
	for(int i=0;i<size;i++)
	{
	   	questiontype=request.getParameter("questiontype"+i);
	   	if( questiontype.equalsIgnoreCase("5M"))
	   	{
		   	qid=Integer.parseInt(request.getParameter("qid"+i));  
		   	question=request.getParameter("questionccc"+i);
	   		String textAns = request.getParameter("textAns"+i);
	   		System.out.println("textAns :"+textAns);
	   		%>
	   		<label class="questionccc"><br><%=++qnCount%>) </label>
			<label class="questionccc"><%= question %><br></label>
			<label class="textAnsCSS">User Answer :</label>
			<label class="textAnsCSS"><%= textAns %><br></label>
	   		<%
			emailattachment.append(qnCount+". "+question+"\r\n");
	    	emailattachment.append("User Answer : "+textAns+"\r\n");
	    	emailattachment.append("---------------------------------------------------------------------\r\n");
	   	}
	}
		j=0;
     	session.setAttribute("Total", Total);
  		%> 	<hr>     
    		<br><b> <label style="color:blue;font-size:18px;font-family:Calibri;">Your Result is pending with Manager</label> </b>
	  	<% 
	  	emailattachment.append("\r\n");
	  	emailattachment.append("MCQ Total:"+Total+"\r\n");
	  	emailattachment.append("Result : Your Result is pending with Manager \r\n");
	 	
		 
	 	// Update Result file
	 	String resultFileName = dirName+"ResultDB.txt";
		boolean result;
		int attemptMade = 1;
		try   
		{
			File file = new File(resultFileName);
			result = file.createNewFile();
			
			StringBuilder newFileSB = new StringBuilder();
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			while ((st = br.readLine()) != null)
			{
				System.out.println("st :"+st);
				if(st.contains(userPIN) && st.split("_")[0].equalsIgnoreCase(teamName))
				{
					System.out.println("st contians:"+st);
					attemptMade = Integer.parseInt(st.split("_")[4]);
					++attemptMade;
				}
				newFileSB.append(st);
				newFileSB.append("\n");
			}
			br.close();
			
			if (file.exists()) {
			    RandomAccessFile raf = new RandomAccessFile(file, "rw");
			    raf.setLength(0);
			    raf.close();
			}
			System.out.println("newFileSB :"+newFileSB);
			Date examTakenDate = new Date();
			BufferedWriter bufferOut = new BufferedWriter(new FileWriter(file, false));
			bufferOut.write(newFileSB.toString());
			bufferOut.write(teamName+"_"+userID+"_"+userPIN+"_"+df.format(examTakenDate)+"_"+attemptMade+"_PENDING");
			bufferOut.newLine();
			bufferOut.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		
		// Test Server 
				// String filename = "/opt/automationtools/Deployments/resources/test.txt";   //dawn server
				String fileName =teamName+"_"+userID+"_"+userPIN+"_"+attemptMade;
				String filename = dirName+fileName+".txt";
			 	File myfile = new File(filename);
			 	boolean fileFound = myfile.createNewFile();
			 
			 	if (fileFound) {
					RandomAccessFile raf = new RandomAccessFile(myfile, "rw");
				    raf.setLength(0);
				    raf.close();
				}
			 	BufferedWriter objWriter = new BufferedWriter(new FileWriter(myfile, false));
			 	objWriter.write(emailattachment.toString());
			 	objWriter.close();
		
	 %>
	 <%	   
	 	String mailTo = (String) session.getAttribute("UserMail");	
	   // String mailTo1 = "ravi.lingegowda.osv@fedex.com";
		String mailcc = "ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";

	 	Properties props = System.getProperties();
		props.put("mail.smtp.host", "mapper.gslb.fedex.com");
		props.put("mail.smtp.port", "25");
		props.put("mail.smtp.connectiontimeout", 10000);
		props.put("mail.smtp.timeout", 10000);
		props.put("mail.smtp.writetimeout", 10000);
		
		Session session1 = Session.getDefaultInstance(props, null);
		MimeMessage message = new MimeMessage(session1);
		
		try {
			message.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
		  	message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo));
		  	//message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo1));
		  	message.addRecipient(Message.RecipientType.CC, new InternetAddress(mailcc));

			message.setSubject("Program 2 Clearance CC Evaluation Test Result");
			//message.setText(htmlText);
			StringBuilder email = new StringBuilder();
			email.append("<html><head>");
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">"+userID+"</label>");
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thank you for taking the evaluation test</label>");
			email.append("<br>");
			/* email.append("<label style=\"font-family:Calibri;font-size:16px\">You Scored :"+Total+"</label>");
			email.append("<br>"); */
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Your Result is pending with Manager </label><br>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
			email.append("</html></head>");						
			message.setContent(email.toString(),"text/html" ); 

			// Send message
			Transport.send(message);
			
		}  catch (MessagingException e) {
			//throw e;
			e.printStackTrace();
		}
	 	
	 	String reportMailTo = "ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";
	 	Properties props1 = System.getProperties();
		props1.put("mail.smtp.host", "mapper.gslb.fedex.com");
		props1.put("mail.smtp.port", "25");
		props1.put("mail.smtp.connectiontimeout", 10000);
		props1.put("mail.smtp.timeout", 10000);
		props1.put("mail.smtp.writetimeout", 10000);
		
		Session session11 = Session.getDefaultInstance(props, null);
		MimeMessage message1 = new MimeMessage(session11);
		
		try {
			message1.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
		  	message1.addRecipient(Message.RecipientType.TO, new InternetAddress(reportMailTo));
		  	//message1.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo1));
		  	BodyPart messageBodyPart1 = new MimeBodyPart();			
			message1.setSubject("Evaluation Test Details");
			
			StringBuilder email = new StringBuilder();
			email.append("<html><head>");					
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Please find attached the details of the test taken by:</label>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">"+userID+"</label>");
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
			email.append("</html></head>");		
			messageBodyPart1.setContent(email.toString(),"text/html" ); 			
			
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();
	        DataSource source = new FileDataSource(filename);  
	        messageBodyPart2.setDataHandler(new DataHandler(source));  
	        messageBodyPart2.setFileName("test.txt");  
	         
	        // create Multi part object and add MimeBodyPart objects to this object      
	        Multipart multipart = new MimeMultipart();  
	        multipart.addBodyPart(messageBodyPart1);  
	        multipart.addBodyPart(messageBodyPart2);  
	        message1.setContent(multipart);  
	        Transport.send(message1);

		}  catch (MessagingException e) {
			e.printStackTrace();
		}
	 %>	
	 <hr>
	  <br>
	   <input type="hidden" id="sessionid" value="<%=sessionid %>">
	  <button onclick="openLoginMenu()">HOME</button>
	  <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
	  </div>
 
     
     <div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;© 2020 FedEx Express EMEA		
	</div>
</body>
     </body>    
</html>
