<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
  <jsp:useBean id="ReportService" class="com.fedex.emea.sabreReport.service.ReportService" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>
<head>
<meta charset="ISO-8859-1">
<title>IAlert Analytics Tool</title>
</head>
<body>
<%
String res  = ReportService.generateReport();
System.out.println("Result :"+res);
response.sendRedirect("SabreHomePage.jsp?status="+res);
%>
</body>
</html>