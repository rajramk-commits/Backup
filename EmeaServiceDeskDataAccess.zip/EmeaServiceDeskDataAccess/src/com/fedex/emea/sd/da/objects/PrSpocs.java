package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class PrSpocs implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3376717416048068654L;

	protected String mdPin;
	protected String mdName;
	protected String mgrPin;
	protected String mgrName;
	protected String spocPin;
	protected String spocName;
	protected String auditStatus;
	protected String mitigReady;
	protected String mitigStatus;
	protected String corractReady;
	protected String corractStatus;
	protected String valtestStatus;
	protected String mdMail;
	protected String mgrMail;
	protected String mdSysId;
	protected String mgrSysId;
	protected String org;

	/**
	 * Method 'PrSpocs'
	 * 
	 */
	public PrSpocs()
	{
	}

	/**
	 * Method 'getMdPin'
	 * 
	 * @return String
	 */
	public String getMdPin()
	{
		return mdPin;
	}

	/**
	 * Method 'setMdPin'
	 * 
	 * @param mdPin
	 */
	public void setMdPin(String mdPin)
	{
		this.mdPin = mdPin;
	}

	/**
	 * Method 'getMdName'
	 * 
	 * @return String
	 */
	public String getMdName()
	{
		return mdName;
	}

	/**
	 * Method 'setMdName'
	 * 
	 * @param mdName
	 */
	public void setMdName(String mdName)
	{
		this.mdName = mdName;
	}

	/**
	 * Method 'getMgrPin'
	 * 
	 * @return String
	 */
	public String getMgrPin()
	{
		return mgrPin;
	}

	/**
	 * Method 'setMgrPin'
	 * 
	 * @param mgrPin
	 */
	public void setMgrPin(String mgrPin)
	{
		this.mgrPin = mgrPin;
	}

	/**
	 * Method 'getMgrName'
	 * 
	 * @return String
	 */
	public String getMgrName()
	{
		return mgrName;
	}

	/**
	 * Method 'setMgrName'
	 * 
	 * @param mgrName
	 */
	public void setMgrName(String mgrName)
	{
		this.mgrName = mgrName;
	}

	/**
	 * Method 'getSpocPin'
	 * 
	 * @return String
	 */
	public String getSpocPin()
	{
		return spocPin;
	}

	/**
	 * Method 'setSpocPin'
	 * 
	 * @param spocPin
	 */
	public void setSpocPin(String spocPin)
	{
		this.spocPin = spocPin;
	}

	/**
	 * Method 'getSpocName'
	 * 
	 * @return String
	 */
	public String getSpocName()
	{
		return spocName;
	}

	/**
	 * Method 'setSpocName'
	 * 
	 * @param spocName
	 */
	public void setSpocName(String spocName)
	{
		this.spocName = spocName;
	}

	/**
	 * Method 'getAuditStatus'
	 * 
	 * @return String
	 */
	public String getAuditStatus()
	{
		return auditStatus;
	}

	/**
	 * Method 'setAuditStatus'
	 * 
	 * @param auditStatus
	 */
	public void setAuditStatus(String auditStatus)
	{
		this.auditStatus = auditStatus;
	}

	/**
	 * Method 'getMitigReady'
	 * 
	 * @return String
	 */
	public String getMitigReady()
	{
		return mitigReady;
	}

	/**
	 * Method 'setMitigReady'
	 * 
	 * @param mitigReady
	 */
	public void setMitigReady(String mitigReady)
	{
		this.mitigReady = mitigReady;
	}

	/**
	 * Method 'getMitigStatus'
	 * 
	 * @return String
	 */
	public String getMitigStatus()
	{
		return mitigStatus;
	}

	/**
	 * Method 'setMitigStatus'
	 * 
	 * @param mitigStatus
	 */
	public void setMitigStatus(String mitigStatus)
	{
		this.mitigStatus = mitigStatus;
	}

	/**
	 * Method 'getCorractReady'
	 * 
	 * @return String
	 */
	public String getCorractReady()
	{
		return corractReady;
	}

	/**
	 * Method 'setCorractReady'
	 * 
	 * @param corractReady
	 */
	public void setCorractReady(String corractReady)
	{
		this.corractReady = corractReady;
	}

	/**
	 * Method 'getCorractStatus'
	 * 
	 * @return String
	 */
	public String getCorractStatus()
	{
		return corractStatus;
	}

	/**
	 * Method 'setCorractStatus'
	 * 
	 * @param corractStatus
	 */
	public void setCorractStatus(String corractStatus)
	{
		this.corractStatus = corractStatus;
	}

	/**
	 * Method 'getValtestStatus'
	 * 
	 * @return String
	 */
	public String getValtestStatus()
	{
		return valtestStatus;
	}

	/**
	 * Method 'setValtestStatus'
	 * 
	 * @param valtestStatus
	 */
	public void setValtestStatus(String valtestStatus)
	{
		this.valtestStatus = valtestStatus;
	}

	public String getMdMail() {
		return mdMail;
	}

	public void setMdMail(String mdMail) {
		this.mdMail = mdMail;
	}

	public String getMgrMail() {
		return mgrMail;
	}

	public void setMgrMail(String mgrMail) {
		this.mgrMail = mgrMail;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrSpocs)) {
			return false;
		}
		
		final PrSpocs _cast = (PrSpocs) _other;
		if (mdPin == null ? _cast.mdPin != mdPin : !mdPin.equals( _cast.mdPin )) {
			return false;
		}
		
		if (mdName == null ? _cast.mdName != mdName : !mdName.equals( _cast.mdName )) {
			return false;
		}
		
		if (mgrPin == null ? _cast.mgrPin != mgrPin : !mgrPin.equals( _cast.mgrPin )) {
			return false;
		}
		
		if (mgrName == null ? _cast.mgrName != mgrName : !mgrName.equals( _cast.mgrName )) {
			return false;
		}
		
		if (spocPin == null ? _cast.spocPin != spocPin : !spocPin.equals( _cast.spocPin )) {
			return false;
		}
		
		if (spocName == null ? _cast.spocName != spocName : !spocName.equals( _cast.spocName )) {
			return false;
		}
		
		if (auditStatus == null ? _cast.auditStatus != auditStatus : !auditStatus.equals( _cast.auditStatus )) {
			return false;
		}
		
		if (mitigReady == null ? _cast.mitigReady != mitigReady : !mitigReady.equals( _cast.mitigReady )) {
			return false;
		}
		
		if (mitigStatus == null ? _cast.mitigStatus != mitigStatus : !mitigStatus.equals( _cast.mitigStatus )) {
			return false;
		}
		
		if (corractReady == null ? _cast.corractReady != corractReady : !corractReady.equals( _cast.corractReady )) {
			return false;
		}
		
		if (corractStatus == null ? _cast.corractStatus != corractStatus : !corractStatus.equals( _cast.corractStatus )) {
			return false;
		}
		
		if (valtestStatus == null ? _cast.valtestStatus != valtestStatus : !valtestStatus.equals( _cast.valtestStatus )) {
			return false;
		}
		
		if (mdMail == null ? _cast.mdMail != mdMail : !mdMail.equals( _cast.mdMail )) {
			return false;
		}
		
		if (mgrMail == null ? _cast.mgrMail != mgrMail : !mgrMail.equals( _cast.mgrMail )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (mdPin != null) {
			_hashCode = 29 * _hashCode + mdPin.hashCode();
		}
		
		if (mdName != null) {
			_hashCode = 29 * _hashCode + mdName.hashCode();
		}
		
		if (mgrPin != null) {
			_hashCode = 29 * _hashCode + mgrPin.hashCode();
		}
		
		if (mgrName != null) {
			_hashCode = 29 * _hashCode + mgrName.hashCode();
		}
		
		if (spocPin != null) {
			_hashCode = 29 * _hashCode + spocPin.hashCode();
		}
		
		if (spocName != null) {
			_hashCode = 29 * _hashCode + spocName.hashCode();
		}
		
		if (auditStatus != null) {
			_hashCode = 29 * _hashCode + auditStatus.hashCode();
		}
		
		if (mitigReady != null) {
			_hashCode = 29 * _hashCode + mitigReady.hashCode();
		}
		
		if (mitigStatus != null) {
			_hashCode = 29 * _hashCode + mitigStatus.hashCode();
		}
		
		if (corractReady != null) {
			_hashCode = 29 * _hashCode + corractReady.hashCode();
		}
		
		if (corractStatus != null) {
			_hashCode = 29 * _hashCode + corractStatus.hashCode();
		}
		
		if (valtestStatus != null) {
			_hashCode = 29 * _hashCode + valtestStatus.hashCode();
		}
		
		if (mdMail != null) {
			_hashCode = 29 * _hashCode + mdMail.hashCode();
		}
		
		if (mgrMail != null) {
			_hashCode = 29 * _hashCode + mgrMail.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrSpocsPk
	 */
	public PrSpocsPk createPk()
	{
		return new PrSpocsPk(mdPin, mgrPin);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrSpocs: " );
		ret.append( "mdPin=" + mdPin );
		ret.append( ", mdName=" + mdName );
		ret.append( ", mgrPin=" + mgrPin );
		ret.append( ", mgrName=" + mgrName );
		ret.append( ", spocPin=" + spocPin );
		ret.append( ", spocName=" + spocName );
		ret.append( ", auditStatus=" + auditStatus );
		ret.append( ", mitigReady=" + mitigReady );
		ret.append( ", mitigStatus=" + mitigStatus );
		ret.append( ", corractReady=" + corractReady );
		ret.append( ", corractStatus=" + corractStatus );
		ret.append( ", valtestStatus=" + valtestStatus );
		ret.append( ", mdMail=" + mdMail );
		ret.append( ", mgrMail=" + mgrMail );
		return ret.toString();
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getMdSysId() {
		return mdSysId;
	}

	public void setMdSysId(String mdSysId) {
		this.mdSysId = mdSysId;
	}

	public String getMgrSysId() {
		return mgrSysId;
	}

	public void setMgrSysId(String mgrSysId) {
		this.mgrSysId = mgrSysId;
	}

}
