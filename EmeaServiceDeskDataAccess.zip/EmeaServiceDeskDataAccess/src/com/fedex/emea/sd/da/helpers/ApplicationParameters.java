package com.fedex.emea.sd.da.helpers;

import java.sql.SQLException;
import java.util.Hashtable;
import java.util.List;

import com.fedex.emea.sd.da.dao.ParametersDao;
import com.fedex.emea.sd.da.objects.Parameters;

public class ApplicationParameters {

	
	
	private ParametersDao parametersDao;
	private Hashtable<String, String> parametersTable;
	
	public ApplicationParameters(ParametersDao parametersDao) throws Exception {
		this.parametersDao = parametersDao;
	}
	
	public void initialize(String entityName) throws SQLException {
		parametersTable = new Hashtable<String, String>();
		List<Parameters> parametersPerEntity;
		parametersPerEntity = parametersDao.loadByEntity(entityName);
		for (Parameters p: parametersPerEntity) {
			if (p.getParameterValue1() != null)	parametersTable.put(p.getParameterName(), p.getParameterValue1());
		}
	}
	
	public String getParameter(String parameterName) {
		return parametersTable.get(parameterName);
	}

}
