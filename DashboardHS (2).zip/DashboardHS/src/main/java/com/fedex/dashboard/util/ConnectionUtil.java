package com.fedex.dashboard.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.stereotype.Component;

@Component
public class ConnectionUtil {
	
	private static Connection con = null;
	
	public static Statement getConnection() throws SQLException, ClassNotFoundException 
    {
        if (con != null) return con.createStatement();
        return getConnectionStatement();
    }

	
	private static Statement getConnectionStatement() throws SQLException, ClassNotFoundException {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con = DriverManager.getConnection(
				"jdbc:oracle:thin:@(DESCRIPTION =(ADDRESS_LIST =(ADDRESS = (PROTOCOL = TCP)(HOST = racdb40-scan.emea.fedex.com)(PORT = 1526)))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = SDTOOL_SVC1.emea.fedex.com)(FAILOVER_MODE =(TYPE = select)(METHOD = basic)(RETRIES = 1)(DELAY = 5))))",
				"SDTOOL_APP", "YA5jmElhIQE5oyNWJ03BSIKsP");
		return con.createStatement();
	}
}
