package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.NexusCasesRowMapper;
import com.fedex.emea.sd.da.objects.NexusCases;

public class NexusCasesDaoImp implements NexusCasesDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public int countAll() throws SQLException {
		String sql = "SELECT count(*) FROM SANEX8.PS_RC_CASE";
        int allRows = 0;
        jdbcTemplate.queryForInt(sql);
        return allRows;
	}

	@Override
	public NexusCases createValueObject() {
		return new NexusCases();
	}

	@Override
	public NexusCases getObject(int caseId) throws SQLException {
		NexusCases valueObject = createValueObject();
		String sql = "SELECT * FROM SANEX8.PS_RC_CASE WHERE (CASE_ID = ? ) ";
		valueObject = (NexusCases) jdbcTemplate.queryForObject(sql, new Object[] {caseId}, new NexusCasesRowMapper());
		return valueObject;
	}
	
	@Override
	public int getCaseId(String caseSummary) throws SQLException {
		NexusCases valueObject = createValueObject();
		String sql = "SELECT * FROM SANEX8.PS_RC_CASE WHERE (RC_SUMMARY = ? ) ";
		valueObject = (NexusCases) jdbcTemplate.queryForObject(sql, new Object[] {caseSummary}, new NexusCasesRowMapper());
		return valueObject.getCaseId();
	}
}
