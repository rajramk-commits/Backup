package com.fedex.emea.dimm.log;

public class DefaultLogger implements LoggingInterface {

	@Override
	public void logInfo(String message) {
		System.out.println("INFO: "+message);

	}

	@Override
	public void logDebug(String message) {
		System.out.println("DEBUG: "+message);

	}

	@Override
	public void logError(String message) {
		System.out.println("ERROR: "+message);
	}

	@Override
	public void logException(String message, Exception e) {
		System.out.println("EXCEPTION: "+message);
		e.printStackTrace();
	}
	
	@Override
	public void logFatal(String message) {
		System.out.println("FATAL: "+message);
	}

}
