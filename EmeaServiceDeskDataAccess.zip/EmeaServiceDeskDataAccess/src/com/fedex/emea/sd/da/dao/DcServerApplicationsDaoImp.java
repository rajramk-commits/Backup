package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.DcServerApplicationsRowMapper;
import com.fedex.emea.sd.da.objects.DcServerApplications;
import com.fedex.emea.sd.da.objects.DcServers;

public class DcServerApplicationsDaoImp implements DcServerApplicationsDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DcServerApplications> loadAllDcServerApplicationsByDataCenter(String dc) throws SQLException {
		String sql = "select SRV.NAME SrvName, " +
			     " APP.NAME AppName, APP.VENDOR RespMgr, APP.BUSINESS_CRITICALITY BusCrit, APP.STATUS AppStatus, APP.MANUFACTURER_ISSUE_NUMBER SuppGroup, " +
			     " NE.NAME ServerName, NE.LOCAL_DOMAIN_NAME ServerDc, NE.STATUS ServerStatus, " +
			     " NET.TYPE ServerType, NET.DESCRIPTION ServerDescr " +
			     "from FIT_SCHEMA.NETWORKEQUIPMENT NE " +
			     " inner join FIT_SCHEMA.NETWORKEQUIPMENTTYPE NET  " +
			     "   on NE.DEFINING_TYPE_KEY_PK = NET.ID and upper(NET.TYPE) in ('SERVER', 'VIRTUALSERVER')" +
			     " left join FIT_SCHEMA.RELATEDTOASSOCIATION RTA " +
			     "   on NE.ID = RTA.ITEM_A_KEY_PK and RTA.ITEM_A_KEY_TYPE = 'com.ni2.core.NetworkEquipmentValue' and RTA.ITEM_Z_KEY_TYPE = 'com.ni2.core.ServiceValue' " +
			     " left join FIT_SCHEMA.SERVICE SRV " +
			     "   on RTA.ITEM_Z_KEY_PK = SRV.ID " +
			     " left join FIT_SCHEMA.RELATEDTOASSOCIATION RTA2 " +
			     "   on RTA.ITEM_Z_KEY_PK = RTA2.ITEM_A_KEY_PK and RTA2.ITEM_A_KEY_TYPE = 'com.ni2.core.ServiceValue' and RTA2.ITEM_Z_KEY_TYPE = 'com.ni2.core.ApplicationValue' " +
			     " left join FIT_SCHEMA.APPLICATION APP " +
			     "   on RTA2.ITEM_Z_KEY_PK = APP.ID " +
			     " left join FIT_SCHEMA.ALLOCATEDTOASSOCIATION ATA " +
			     "   on RTA2.ITEM_Z_KEY_PK = ATA.ALLOCATEE_KEY_PK and ATA.ALLOCATEE_KEY_TYPE = 'com.ni2.core.ApplicationValue' and ATA.ALLOCATED_KEY_TYPE = 'com.ni2.core.OrganizationValue' " +
			     "where NE.LOCAL_DOMAIN_NAME = ? and NE.STATUS in ('Production', 'Pre-Production', 'Test', 'Development', 'Installed') " +
			     "order by APP.BUSINESS_CRITICALITY, SRV.NAME, upper(NE.NAME)";
		
		return jdbcTemplate.query(sql, new Object[] {dc}, new DcServerApplicationsRowMapper());
	}

	@Override
	public DcServers createValueObject() {
		return new DcServers();
	}

}
