package com.fedex.emea.sabreReport.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDup {

public static List<String> readExcel(String fileName) throws IOException {
int count =0;
int column=0;
List<String> engList = new ArrayList<>();
FileInputStream fileInStream = new FileInputStream(fileName);

 XSSFWorkbook workBook = new XSSFWorkbook(fileInStream);

 XSSFSheet selectedSheet = workBook.getSheetAt(0);

 Iterator<Row> rowIterator = selectedSheet.iterator();
while (rowIterator.hasNext()) {
if(count < 2)
{
count++;
rowIterator.next();
continue;
}
Row row = rowIterator.next();

 String engEntry = row.getCell(column).getStringCellValue();
engList.add(engEntry);
}
return engList;
}
}