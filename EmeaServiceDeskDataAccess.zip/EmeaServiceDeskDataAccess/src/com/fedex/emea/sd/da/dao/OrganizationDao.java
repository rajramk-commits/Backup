package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.OrganizationDaoException;
import com.fedex.emea.sd.da.objects.Organization;
import com.fedex.emea.sd.da.objects.OrganizationPk;

public interface OrganizationDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return OrganizationPk
	 */
	public OrganizationPk insert(Organization dto);

	/** 
	 * Updates a single row in the ORGANIZATION table.
	 */
	public void update(OrganizationPk pk, Organization dto) throws OrganizationDaoException;

	/** 
	 * Deletes a single row in the ORGANIZATION table.
	 */
	public void delete(OrganizationPk pk) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ID = :id'.
	 */
	public Organization findByPrimaryKey(String id) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria ''.
	 */
	public List<Organization> findAll() throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ID = :id'.
	 */
	public List<Organization> findWhereIdEquals(String id) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'NAME = :name'.
	 */
	public List<Organization> findWhereNameEquals(String name) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LOCATION_NAME = :locationName'.
	 */
	public List<Organization> findWhereLocationNameEquals(String locationName) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'COMMENTS = :comments'.
	 */
	public List<Organization> findWhereCommentsEquals(String comments) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'WEB_SITE = :webSite'.
	 */
	public List<Organization> findWhereWebSiteEquals(String webSite) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'RESOURCE_STATUS = :resourceStatus'.
	 */
	public List<Organization> findWhereResourceStatusEquals(String resourceStatus) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	public List<Organization> findWhereCustom1Equals(String custom1) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	public List<Organization> findWhereCustom2Equals(String custom2) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	public List<Organization> findWhereCustom3Equals(String custom3) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	public List<Organization> findWhereCustom4Equals(String custom4) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	public List<Organization> findWhereCustom5Equals(String custom5) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DEFINING_TYPE_KEY_TYPE = :definingTypeKeyType'.
	 */
	public List<Organization> findWhereDefiningTypeKeyTypeEquals(String definingTypeKeyType) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DEFINING_TYPE_KEY_PK = :definingTypeKeyPk'.
	 */
	public List<Organization> findWhereDefiningTypeKeyPkEquals(String definingTypeKeyPk) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	public List<Organization> findWhereDescriptionEquals(String description) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	public List<Organization> findWhereLongDescriptionEquals(String longDescription) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	public List<Organization> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	public List<Organization> findWhereLastModificationDateEquals(Date lastModificationDate) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	public List<Organization> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	public List<Organization> findWhereCustom6Equals(String custom6) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	public List<Organization> findWhereCustom7Equals(String custom7) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	public List<Organization> findWhereCustom8Equals(String custom8) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	public List<Organization> findWhereCustom9Equals(String custom9) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	public List<Organization> findWhereCustom10Equals(String custom10) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'SOURCE = :source'.
	 */
	public List<Organization> findWhereSourceEquals(String source) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'SOURCE_KEY = :sourceKey'.
	 */
	public List<Organization> findWhereSourceKeyEquals(String sourceKey) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	public List<Organization> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	public List<Organization> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'EMAIL = :email'.
	 */
	public List<Organization> findWhereEmailEquals(String email) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	public List<Organization> findWhereEnvironmentEquals(String environment) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	public List<Organization> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	public List<Organization> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws OrganizationDaoException;

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	public List<Organization> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws OrganizationDaoException;

	/** 
	 * Returns the rows from the ORGANIZATION table that matches the specified primary-key value.
	 */
	public Organization findByPrimaryKey(OrganizationPk pk) throws OrganizationDaoException;

}
