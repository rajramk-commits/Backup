package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.NexusInterface;

/** * RowMapper is used by Spring to read a line from a database table
 *  * and to fill an instance of the class with the values */

public final class NexusInterfaceRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		NexusInterface nexusInterface = new NexusInterface();
		
		nexusInterface.setAlertId(rs.getLong("ALERTID"));
		nexusInterface.setRecordSource(rs.getString("RECORDSOURCE"));
		nexusInterface.setRecordSourceId(rs.getString("RECORDSOURCEID"));
		nexusInterface.setNexusCase(rs.getBytes("NEXUSCASEOBJECT"));
		nexusInterface.setCaseBusinessUnit(rs.getString("CASEBUSINESSUNIT"));
		nexusInterface.setCaseLocation(rs.getString("CASELOCATION"));
		nexusInterface.setCaseOriginPin(rs.getString("CASEORIGINPIN"));
		nexusInterface.setCaseSummary(rs.getString("CASESUMMARY"));
		nexusInterface.setCaseDescription1(rs.getString("CASEDESCRIPTION1"));
		nexusInterface.setCaseDescription2(rs.getString("CASEDESCRIPTION2"));
		nexusInterface.setCaseDescription3(rs.getString("CASEDESCRIPTION3"));
		nexusInterface.setCaseDescription4(rs.getString("CASEDESCRIPTION4"));
		nexusInterface.setCaseDescription5(rs.getString("CASEDESCRIPTION5"));
		nexusInterface.setCaseDescription6(rs.getString("CASEDESCRIPTION6"));
		nexusInterface.setCaseDescription7(rs.getString("CASEDESCRIPTION7"));
		nexusInterface.setCaseDescription8(rs.getString("CASEDESCRIPTION8"));
		nexusInterface.setCaseDescription9(rs.getString("CASEDESCRIPTION9"));
		nexusInterface.setCaseType(rs.getString("CASETYPE"));
		nexusInterface.setCasePriority(rs.getString("CASEPRIORITY"));
		nexusInterface.setCaseStatus(rs.getString("CASESTATUS"));
		nexusInterface.setCaseSeverity(rs.getString("CASESEVERITY"));
		nexusInterface.setCaseSource(rs.getString("CASESOURCE"));
		nexusInterface.setCaseProviderGroup(rs.getString("CASEPROVIDERGROUP"));
		nexusInterface.setCaseOwnership(rs.getString("CASEOWNERSHIP"));
		nexusInterface.setCaseCategory(rs.getString("CASECATEGORY"));
		nexusInterface.setCaseCallType(rs.getString("CASECALLTYPE"));
		nexusInterface.setCaseProblemType(rs.getString("CASEPROBLEMTYPE"));
		nexusInterface.setCaseProblemDetail(rs.getString("CASEPROBLEMDETAIL"));
		nexusInterface.setCaseProblemDescription(rs.getString("CASEPROBLEMDESCRIPTION"));
		nexusInterface.setCaseFdxNode(rs.getString("CASEFDXNODE"));
		nexusInterface.setCaseFdxVendor(rs.getString("CASEFDXVENDOR"));
		nexusInterface.setCaseFdxVendorId(rs.getString("CASEFDXVENDORID"));
		nexusInterface.setCaseFdxSystem(rs.getString("CASEFDXSYSTEM"));
		nexusInterface.setCaseFdxApplication(rs.getString("CASEFDXAPPLICATION"));
		nexusInterface.setCaseAssignedTo(rs.getString("CASEASSIGNEDTO"));
		nexusInterface.setCaseSolution(rs.getString("CASESOLUTION"));
		nexusInterface.setAlertProcessed(rs.getInt("ALERTPROCESSED"));
		nexusInterface.setProcessedTime(rs.getTimestamp("PROCESSEDTIME"));
		nexusInterface.setCreationTime(rs.getTimestamp("CREATIONTIME"));
		nexusInterface.setCaseId(rs.getString("CASEID"));
		nexusInterface.setLogicalKey(rs.getString("LOGICALKEY"));
		
		return nexusInterface;	
	}
}
