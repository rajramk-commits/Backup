package com.fedex.dashboard.model;

public class DepDetailsBean {	
	private String depAppName;
	private String hubActivities;
	
	public String getDepAppName() {
		return depAppName;
	}
	public void setDepAppName(String depAppName) {
		this.depAppName = depAppName;
	}
	public String getHubActivities() {
		return hubActivities;
	}
	public void setHubActivities(String hubActivities) {
		this.hubActivities = hubActivities;
	}
	@Override
	public String toString() {
		return "DepDetailsBean [depAppName=" + depAppName + ", hubActivities=" + hubActivities + "]\n";
	}
}
