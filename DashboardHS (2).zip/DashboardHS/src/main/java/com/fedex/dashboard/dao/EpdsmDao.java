package com.fedex.dashboard.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fedex.dashboard.constants.DashboardConstants;
import com.fedex.dashboard.model.TicketsBean;
import com.fedex.dashboard.util.ConnectionUtil;
import org.apache.logging.log4j.*;


public class EpdsmDao {

	private final static Logger logger = LogManager.getLogger(EpdsmDao.class);
	
	/**
	 * 
	 * @return
	 */
	public static List<TicketsBean> getHubstackCCTickets()
	{
		List<TicketsBean> tickets = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery(DashboardConstants.SELECT_HUBSTACKCCTICKETS);
			while (rs.next() ) {
				TicketsBean bean = new TicketsBean();
				bean.setCaseID(rs.getString(1));
				bean.setCreationTime(rs.getString(2));
				bean.setRecordSource(rs.getString(3));				
				bean.setCaseDesc(rs.getString(4));
				bean.setCaseType(rs.getString(5));
				bean.setCasePriority(rs.getString(6));
				bean.setCaseStatus(rs.getString(7));
				tickets.add(bean);
			}
			logger.info("getHubstackCCTickets : "+tickets);
		} catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return tickets;
	}
	
	/**
	 * 
	 * @return
	 */
	public static List<TicketsBean> getClearanceCCTickets()
	{
		List<TicketsBean> tickets = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery(DashboardConstants.SELECT_CLEARANCECCTICKETS);
			while (rs.next() ) {
				TicketsBean bean = new TicketsBean();
				bean.setCaseID(rs.getString(1));
				bean.setCreationTime(rs.getString(2));
				bean.setRecordSource(rs.getString(3));				
				bean.setCaseDesc(rs.getString(4));
				bean.setCaseType(rs.getString(5));
				bean.setCasePriority(rs.getString(6));
				bean.setCaseStatus(rs.getString(7));
				tickets.add(bean);
			}
			logger.info("getClearanceCCTickets : "+tickets);
		} catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return tickets;
	}
	
	/**
	 * 
	 * @return
	 */
	public static int getCountHubstackCC()
	{
		int count = 0;
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery(DashboardConstants.COUNT_HUBSTACKCCTICKETS);
			if (rs.next() ) {
				count = rs.getInt(1);
			}
			logger.info("getCountHubstackCC :"+count);
		} catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return count;
	}
	
	/**
	 * 
	 * @return
	 */
	public static int getCountClearanceCC()
	{
		int count = 0;
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery(DashboardConstants.COUNT_CLEARANCECCTICKETS);
			if (rs.next() ) {
				count = rs.getInt(1);
			}
			logger.info("getCountClearanceCC :"+count);
		} catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return count;
	}
	
	// For Testing Only
	public static void main(String args[]) {
		logger.info("Application started!!!!");
		getCountHubstackCC();
	}
}
