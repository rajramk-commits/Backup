<html>
<head></head>

<script type='text/javascript'>
function saveReport()
{
	alert('Downloading..!!');
}
</script>

<body >
<button class="buttonFont" onclick="return saveReport()"><a href="#" style="text-decoration:none" download="data.csv" id="btnSave" >Export data into Excel</a></button>
</body>
</html>