package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.AlertMailingLists;

/** * RowMapper is used by Spring to read a line from a database table
 *  * and to fill an instance of the class with the values */

public final class AlertMailingListsRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		AlertMailingLists alertMailingLists = new AlertMailingLists();
		
		alertMailingLists.setAlertSource(rs.getString("ALERTSOURCE"));
		alertMailingLists.setUserPin(rs.getString("USERPIN"));
		alertMailingLists.setUserMail(rs.getString("USERMAIL"));
		
		return alertMailingLists;	
	}
}
