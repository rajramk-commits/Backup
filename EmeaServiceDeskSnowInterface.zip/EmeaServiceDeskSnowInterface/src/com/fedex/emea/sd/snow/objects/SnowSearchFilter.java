package com.fedex.emea.sd.snow.objects;

public class SnowSearchFilter {
	
	private String searchFilter;
	
	public SnowSearchFilter() {
	}
	
	public SnowSearchFilter(String fieldId, String operator, String fieldValue) {
		searchFilter = fieldId + operator + fieldValue;
	}
	
	public SnowSearchFilter(String fieldId, String operator, String fieldValue1, String fieldValue2) {
		searchFilter = fieldId + operator + fieldValue1 + "@" + fieldValue2;
	}
	
	public String toString() {
		return searchFilter;
	}
}
