
//*****************************************************************
//* 
//* FdxCaseJavaCiCollection.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public class FdxCaseJavaCiCollection implements IFdxCaseJavaCiCollection 
  {
  public FdxCaseJavaCiCollection(IObject oThis) { m_oThis = oThis; }

  public long getCount() throws JOAException {
    return ((Long)m_oThis.getProperty("Count")).longValue();
 }

  public IFdxCaseJavaCi item(long Index) throws JOAException {
    Object[] args = new Object[1];
    args[0] = new Long(Index);
    return (IFdxCaseJavaCi)m_oThis.invokeMethod("Item", args);
    }

  IObject m_oThis;
  }
