package com.fedex.emea.sd.astc.listener;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import com.fedex.emea.sd.astc.utils.ExternalDataConverter;
import com.fedex.emea.sd.da.dao.AlertMailingListsDao;
import com.fedex.emea.sd.da.dao.DashboardAlertsDao;
import com.fedex.emea.sd.da.dao.ExternalInterfaceDao;
import com.fedex.emea.sd.da.dao.OvoMessagesDao;
import com.fedex.emea.sd.da.dao.ParametersDao;
import com.fedex.emea.sd.da.helpers.ApplicationParameters;
import com.fedex.emea.sd.da.helpers.Constants;
import com.fedex.emea.sd.da.logger.ApplicationLogger;
import com.fedex.emea.sd.da.objects.ExternalInterface;
import com.fedex.emea.sd.da.objects.Parameters;
import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowPassiveData;
import com.fedex.emea.sd.snow.objects.SnowSearchFilter;
import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class ExternalInterfaceRecordListener {

	//private static final boolean         IN_PRODUCTION     = true;
	private static final boolean         IN_PRODUCTION     = false; //EPDSM UAT(testing)
	private static final boolean         IS_EPDSM          = true;
	
	private static long                  LISTENER_DELAY    = 0L;
	private static final long            PURGE_DELAY       = 1000L * 60 * 60 * 24 * 60;		// 60 days
	private static final long            DB_ERROR_DELAY    = 1000L * 60 * 5;				// 5 Minutes
	private static String                parametersEntity;
	
	private static AlertMailingListsDao  alertMailingListsDao;
	private static ParametersDao         parametersDao;
	private static OvoMessagesDao        ovoMessagesDao;
	private static DashboardAlertsDao    dashboardAlertsDao;
	private static ExternalInterfaceDao  externalInterfaceDao;
	
	private static ApplicationLogger     logger = ApplicationLogger.getInstance();
	private static ApplicationParameters appParams;
	
	private static SnowRequestor         snowRequestor;
	private static List<SnowPassiveData> snowCiServiceList      = new ArrayList<SnowPassiveData>();
	private static List<SnowPassiveData> snowCiBusinessAppList  = new ArrayList<SnowPassiveData>();
	private static List<SnowPassiveData> snowUserGroupsList     = new ArrayList<SnowPassiveData>();
	
	// ExternalDataConverter will be initialized with Passive Data of given ServiceNow instance (DEV, SAND, PREPROD, PROD)
	//
	private static ExternalDataConverter edc                = new ExternalDataConverter();
	
	public static void main(String[] args) throws InterruptedException {
		
		logger.logInfo("Automatic Support Ticket Creator started.");
		
		initDao();
		initParameters();
		if (IS_EPDSM) {
			initEpdsmPassiveData();
			edc.setEPDSM(true);
		} else {
			initSnowPassiveData();
			edc.setEPDSM(false);
		}
		
		ExternalInterface                element                = null;
		ExternalInterfaceRecordProcessor eiProcessor            = null;
		List<ExternalInterface>          externalInterfacesList = null;
		List<ExternalInterface>          processedList          = new ArrayList<ExternalInterface>();
		
		LISTENER_DELAY = Integer.valueOf(appParams.getParameter(Constants.LISTENER_INTERVAL)) * 1000;
		
		logger.logInfo("External_Interface Table Listener started...");
		
		while (true) {
			try {
				externalInterfacesList = getExternalInterfaceNotProcessedList();

				if (externalInterfacesList.size() > 0) {
					logger.logInfo(externalInterfacesList.size() + " External_Interface record(s) received!");
					processedList.clear();
					
					updateAllStatusToProcessing(externalInterfacesList);	// To avoid duplicate processing
					
					eiProcessor = new ExternalInterfaceRecordProcessor(snowRequestor, edc, externalInterfaceDao, alertMailingListsDao, ovoMessagesDao, logger, appParams, IN_PRODUCTION, IS_EPDSM);
					
					for (Iterator<ExternalInterface> iter = externalInterfacesList.iterator(); iter.hasNext();) {
						element = iter.next();
						eiProcessor.process(element);
						processedList.add(element);
					}
					
					eiProcessor = null;
					logger.logInfo(processedList.size() + " External_Interface record(s) Processed");
				}
				
				if (IN_PRODUCTION) performDbPurge();
				
				Thread.sleep(LISTENER_DELAY);
				
			} catch (SQLException sqlEx) {
				StringWriter errors = new StringWriter();
				sqlEx.printStackTrace(new PrintWriter(errors));
				logger.logWarn("DB Error: Failed to get External_Interface List. See Error.log for details. Waiting 5 minutes.");
				logger.logError(errors.toString());
				Thread.sleep(DB_ERROR_DELAY);
			} catch (CannotGetJdbcConnectionException exc) {
				StringWriter errors = new StringWriter();
				exc.printStackTrace(new PrintWriter(errors));
				logger.logWarn("DB Error: Failed to get JDBC Connection. See Error.log for details. Waiting 5 minutes.");
				logger.logError(errors.toString());
				Thread.sleep(DB_ERROR_DELAY);
			} catch (Exception e) {
				StringWriter errors = new StringWriter();
				e.printStackTrace(new PrintWriter(errors));
				
				// Reset ALERTPROCESSED = 0 for unprocessed records
				updateUnprocessedToUnprocessedStatus(externalInterfacesList, processedList);
				
				logger.logError("Critical Error - Exception in Main()");
				logger.logError(errors.toString());
				logger.logInfo("Automatic Support Ticket Creator unexpectedly stopped !");
				System.exit(-1);
			}
		}
	}
	
	private static void initDao() {
		XmlBeanFactory    beanFactory       = new XmlBeanFactory(new ClassPathResource("spring-config.xml"));
		
		if (IN_PRODUCTION) {
			parametersEntity = "AutomaticNexusTicketCreator-Prd";
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceDao");
			alertMailingListsDao = (AlertMailingListsDao) beanFactory.getBean("alertMailingListsDao");
			parametersDao        = (ParametersDao)        beanFactory.getBean("parametersDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesDao");
			dashboardAlertsDao   = (DashboardAlertsDao)   beanFactory.getBean("dashboardAlertsDao");
			if (IS_EPDSM) {
				snowRequestor        = new SnowRequestor(SnowConstants.EPDSM_PROD_DIRECT);
			} else {
				snowRequestor        = new SnowRequestor(SnowConstants.SNOW_PROD);	
			}
			
		} else {
			parametersEntity = "AutomaticNexusTicketCreator-Tst";
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceTestDao");
			alertMailingListsDao = (AlertMailingListsDao) beanFactory.getBean("alertMailingListsTestDao");
			parametersDao        = (ParametersDao)        beanFactory.getBean("parametersTestDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesTestDao");
			dashboardAlertsDao   = (DashboardAlertsDao)   beanFactory.getBean("dashboardAlertsTestDao");
			if (IS_EPDSM) {
				snowRequestor        = new SnowRequestor(SnowConstants.EPDSM_UAT_DIRECT);
			} else {
				snowRequestor        = new SnowRequestor(SnowConstants.SNOW_PREPROD);
			}
		}		
	}
	
	private static void initParameters() {
		try {
			appParams = new ApplicationParameters(parametersDao);
			appParams.initialize(parametersEntity);
		} catch (Exception e) {
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			logger.logError("Critical Error - Failed to get Application Parameters. See Error.log. Exception: " + e.getMessage());
			logger.logError(errors.toString());
			System.exit(-1);
		}
	}
	
	private static void initSnowPassiveData() {
		SnowSearchFilter fedexFolderFilter    = new SnowSearchFilter("u_folder",    SnowConstants.OPER_EQUAL, "1a0e8689dbe5fac0c9a7b14ffe9619a5");
		
		boolean snowCiServiceListOK   = false;
		boolean snowUserGroupsListOK  = false;
		
		while (!snowCiServiceListOK && !snowUserGroupsListOK) {
			logger.logInfo("Retrieving Passive Data from ServiceNow...");
			
			if (!snowCiServiceListOK) {
				try {
					snowCiServiceList  = snowRequestor.getPassiveDataByTable(SnowConstants.TBL_CMDB_CI_SERVICE, fedexFolderFilter);
					edc.setSnowCiServiceList(snowCiServiceList);
					snowCiServiceListOK = true;
					logger.logInfo("CMDB_CI_SERVICE retrieved");
				} catch (Exception ex) {
					edc.setSnowCiServiceList(null);
					snowCiServiceListOK = false;
					logger.logInfo("Failed to retrieve CMDB_CI_SERVICE from ServiceNow. See Error.log for details.");
					logger.logError("Failed to retrieve CMDB_CI_SERVICE from ServiceNow: " + ex.getMessage());
				}
			}
			
			if (!snowUserGroupsListOK) {
				try {
					snowUserGroupsList = snowRequestor.getPassiveDataByTable(SnowConstants.TBL_SYS_USER_GROUP, fedexFolderFilter);
					edc.setSnowUserGroupsList(snowUserGroupsList);
					snowUserGroupsListOK = true;
					logger.logInfo("SYS_USER_GROUP retrieved");
				} catch (Exception ex) {
					edc.setSnowUserGroupsList(null);
					snowUserGroupsListOK = false;
					logger.logInfo("Failed to retrieve SYS_USER_GROUP from ServiceNow. See Error.log for details.");
					logger.logError("Failed to retrieve SYS_USER_GROUP from ServiceNow: " + ex.getMessage());
				}
			}
			
			if (!snowCiServiceListOK || !snowUserGroupsListOK) {
				logger.logInfo("Failed to retrieve Passive Data from ServiceNow. Waiting 2 minutes.");
				try {
					Thread.sleep(120000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		logger.logInfo("Passive Data retrieving from ServiceNow completed.");
	}
	
	private static void initEpdsmPassiveData() {
//		SnowSearchFilter fedexFolderFilter    = new SnowSearchFilter("u_folder",    SnowConstants.OPER_EQUAL, "1a0e8689dbe5fac0c9a7b14ffe9619a5");
		SnowSearchFilter activeFilter    = new SnowSearchFilter("active",    SnowConstants.OPER_EQUAL, "TRUE");
		
		boolean snowCiServiceListOK   = false;
		boolean snowUserGroupsListOK  = false;
		boolean snowBusinessAppListOK = false;
		
		while (!snowCiServiceListOK && !snowUserGroupsListOK && !snowBusinessAppListOK) {
			logger.logInfo("Retrieving Passive Data from E-PDSM...");
			
			if (!snowBusinessAppListOK) {
				try {
					snowCiBusinessAppList  = snowRequestor.getPassiveDataByTable(SnowConstants.TBL_CMDB_CI_BUSINESS_APP, activeFilter);
					edc.setSnowCiBusinessAppList(snowCiBusinessAppList);
					snowBusinessAppListOK = true;
					logger.logInfo("CMDB_CI_BUSINESS_APP retrieved");
				} catch (Exception ex) {
					edc.setSnowCiBusinessAppList(null);
					snowBusinessAppListOK = false;
					logger.logInfo("Failed to retrieve CMDB_CI_BUSINESS_APP from E-PDSM. See Error.log for details.");
					logger.logError("Failed to retrieve CMDB_CI_BUSINESS_APP from E-PDSM: " + ex.getMessage());
				}
			}
			
			if (!snowCiServiceListOK) {
				try {
					snowCiServiceList  = snowRequestor.getPassiveDataByTable(SnowConstants.TBL_CMDB_CI_SERVICE, null);
					edc.setSnowCiServiceList(snowCiServiceList);
					snowCiServiceListOK = true;
					logger.logInfo("CMDB_CI_SERVICE retrieved");
				} catch (Exception ex) {
					edc.setSnowCiServiceList(null);
					snowCiServiceListOK = false;
					logger.logInfo("Failed to retrieve CMDB_CI_SERVICE from ServiceNow. See Error.log for details.");
					logger.logError("Failed to retrieve CMDB_CI_SERVICE from ServiceNow: " + ex.getMessage());
				}
			}
			
			if (!snowUserGroupsListOK) {
				try {
					snowUserGroupsList = snowRequestor.getPassiveDataByTable(SnowConstants.TBL_SYS_USER_GROUP, null);
					edc.setSnowUserGroupsList(snowUserGroupsList);
					snowUserGroupsListOK = true;
					logger.logInfo("SYS_USER_GROUP retrieved");
				} catch (Exception ex) {
					edc.setSnowUserGroupsList(null);
					snowUserGroupsListOK = false;
					logger.logInfo("Failed to retrieve SYS_USER_GROUP from E-PDSM. See Error.log for details.");
					logger.logError("Failed to retrieve SYS_USER_GROUP from E-PDSM: " + ex.getMessage());
				}
			}
			
			if (!snowCiServiceListOK || !snowUserGroupsListOK || !snowBusinessAppListOK) {
				logger.logInfo("Failed to retrieve Passive Data from E-PDSM. Waiting 2 minutes.");
				try {
					Thread.sleep(120000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
		logger.logInfo("Passive Data retrieving from E-PDSM completed.");
	}
	
	private static void updateAllStatusToProcessing(List<ExternalInterface> externalInterfacesList) throws SQLException {
		ExternalInterface eiRecord = null;
		for (Iterator<ExternalInterface> iter = externalInterfacesList.iterator(); iter.hasNext();) {
			eiRecord = iter.next();
			eiRecord.setAlertProcessed(Constants.PROCESSING);
			externalInterfaceDao.updateRecordStatus(eiRecord);
		}
	}
	
	private static void updateUnprocessedToUnprocessedStatus(List<ExternalInterface> externalInterfacesList, List<ExternalInterface> processedList) {
		boolean isProcessed;
		for (ExternalInterface eiRecord: externalInterfacesList) {
			isProcessed = false;
			for (ExternalInterface processedRecord: processedList) {
				if (eiRecord.getAlertId() == processedRecord.getAlertId()) {
					isProcessed = true;
					break;
				}
			}
			if (!isProcessed) {
				eiRecord.setAlertProcessed(Constants.UNPROCESSED);
				eiRecord.setProcessedTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
				try {
					externalInterfaceDao.updateRecordStatus(eiRecord);
				} catch (SQLException e) {
					logger.logWarn("SQL Exception: Alert ID " + eiRecord.getAlertId() + " will remain with status = Processing (2)");
				}
			}
		}
	}
	
	private static void performDbPurge() {
		long currentMs = Calendar.getInstance().getTimeInMillis();
		long lastPurgeMs = 0;
		long purgeInterval = 0;
		
		try {
			Parameters lastPurgeParam = parametersDao.getObject(parametersEntity, Constants.LAST_PURGE);
			if (lastPurgeParam.getParameterValue1() == null) {
				parametersDao.create(new Parameters(parametersEntity,Constants.LAST_PURGE, String.valueOf(currentMs),null,null));
			} else {
				lastPurgeMs = Long.parseLong(lastPurgeParam.getParameterValue1());
				purgeInterval = currentMs - lastPurgeMs;
				
				if (purgeInterval > PURGE_DELAY) {
						dashboardAlertsDao.deleteOlderThan(new Timestamp(lastPurgeMs));
						ovoMessagesDao.deleteOlderThan(new Timestamp(lastPurgeMs));
						externalInterfaceDao.deleteOlderThan(new Timestamp(lastPurgeMs));
						parametersDao.save(new Parameters(parametersEntity,Constants.LAST_PURGE, String.valueOf(currentMs),null,null));
						logger.logInfo("DB Maintenance: Purge completed");
				}
			}
		} catch (Exception ex) {
			logger.logWarn("DB Warning: Purge not executed");
			StringWriter errors = new StringWriter();
			ex.printStackTrace(new PrintWriter(errors));
			logger.logError(errors.toString());
		}		
	}
	
	private static List<ExternalInterface> getExternalInterfaceNotProcessedList() throws SQLException {
		List<ExternalInterface> externalInterfaceList = null;
		try {
			externalInterfaceList = externalInterfaceDao.loadNotProcessed();
		} catch (SQLException e) {
			throw e;
		}
		return externalInterfaceList;
	}
		
}
