<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<script type="text/javascript">

function save(){
	str = document.forms[0].t1.value;
	mydoc = document.open(); 
	mydoc.write(str);
	mydoc.execCommand("saveAs",true,".txt");
	mydoc.close();
	return false;
}

</script>
</head>

<body class="body">
<form id="form1" action="" onsubmit="">
	<input type="text" name="t1"/>
	<input type="button" value="process" onclick="save()"/>
</form>
</body>
</html>