package com.fedex.emea.sabreReport.util;

import java.io.File;

public class Test {

	public static void main(String[] args)
	{
		String home = System.getProperty("user.home");
		File file = new File(home+"/Downloads/xyz.txt"); 
		System.out.println(file);
		System.out.println(file.getAbsolutePath());
		System.out.println(file.getPath());
		System.out.println(home);
	}
}
