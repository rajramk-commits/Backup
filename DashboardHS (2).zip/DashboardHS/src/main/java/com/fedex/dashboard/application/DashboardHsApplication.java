package com.fedex.dashboard.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.fedex.dashboard.controller.DashboardController;
 
@SpringBootApplication(scanBasePackages = {"com.fedex.dashboard"},scanBasePackageClasses=DashboardController.class) 
public class DashboardHsApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(DashboardHsApplication.class, args);
	}
}
