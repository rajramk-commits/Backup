package com.fedex.dashboard.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fedex.dashboard.constants.DashboardConstants;
import com.fedex.dashboard.model.DepandancyBean;
import com.fedex.dashboard.model.HubActivityBean;
import com.fedex.dashboard.model.HubAppBean;
import com.fedex.dashboard.util.ConnectionUtil;

public class DashboardDao {
	
private final static Logger logger = LogManager.getLogger(DashboardDao.class);

	/**
	 * 
	 * @param location
	 * @return
	 */
	public static List<HubAppBean> getHubDetails(String location) {
		List<HubAppBean> hubDetails = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select HubLocation, AppName, AppStatus from SDTOOL_SCHEMA.HubApplication where HubLocation = '"+location+"'" );
			while (rs.next() ) {
				HubAppBean bean = new HubAppBean();
				bean.setHubLocation(rs.getString(1));
				bean.setAppName(rs.getString(2));
				bean.setServerStatus(rs.getString(3));
				hubDetails.add(bean);
			}
			logger.info(hubDetails);
		} catch (ClassNotFoundException  | SQLException e1 ) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return hubDetails;
	}
	/**
	 * 
	 * @param appName
	 * @return
	 */
	public static List<DepandancyBean> getAppDep(String appName) {
		List<DepandancyBean> depAppDetails = new ArrayList<>();
		List<String> depNames = new ArrayList<>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select AppName, DepAppNames, Appdesc  from SDTOOL_SCHEMA.AppDependancy "
					+ "where AppName = '"+appName+"'" );
			while (rs.next() ) {
				String depAppNames = rs.getString(2);
				depNames = Arrays.asList(depAppNames.split(","));
				for(String name : depNames)
				{
					DepandancyBean bean = new DepandancyBean();
					bean.setName(name);
					bean.setDetails(getDetails(name));
					depAppDetails.add(bean);
				}
			}
			logger.info(depAppDetails);
		} catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
	return depAppDetails;
}
	/**
	 * 
	 * @param name
	 * @return
	 */
	private static List<HubActivityBean> getDetails(String name) 
	{
		List<HubActivityBean> details = new ArrayList<HubActivityBean>();
		List<String> hubActivityList = new ArrayList<>();
		String hubActivities = getHubActivities(name);
		if(hubActivities != null && !hubActivities.isEmpty())
		{
			hubActivityList = Arrays.asList(hubActivities.split(","));
			for(String activity : hubActivityList)
			{
				HubActivityBean bean = getImpDetails(activity.trim());
				logger.info("bean :"+bean);
				details.add(bean);
			}
			logger.info("details : "+details);
		}
		return details;
	}
	/**
	 * 
	 * @param depApp
	 * @return
	 */
	private static String getHubActivities(String depApp) {
		String hubActivities = "";
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select DepAppName, HubActivities from SDTOOL_SCHEMA.DepDetails "
					+ "where  DepAppName = '"+depApp+"'" );
			while (rs.next() ) {
				hubActivities = rs.getString(2);
				if("No Hub operations are impacted".equalsIgnoreCase(hubActivities))
				{
					hubActivities = "";
				}
				logger.info("Final hubActivities :"+hubActivities);
			}
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return hubActivities;
	}
	
	/**
	 * 
	 * @param activity
	 * @return
	 */
	public static HubActivityBean getImpDetails(String activity) {
		HubActivityBean bean = new HubActivityBean();
		List<String> activityDetails = new ArrayList<String>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select HubActivities, hubDetails, hubdesc from SDTOOL_SCHEMA.ImpactHubAreas "
					+ " where HubActivities = '"+activity+"'" );
			while (rs.next() ) {
				activityDetails.add(rs.getString(2));
			}
			logger.info("activity, activityDetails :"+activity+", "+activityDetails);
			bean.setHubActivities(activity);
			bean.setDetails(activityDetails);
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return bean;
	}
	
	/**
	 * 
	 * @param activity
	 * @return
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	@SuppressWarnings("unchecked")
	public static int insertImpDetails(LinkedHashMap<String, List<Map<String, ?>>> impDetailsList) throws ClassNotFoundException, SQLException {
		String activity = null;
		int insResult = 0;
		List<String> detailsList = new ArrayList<String>();
		for (Map.Entry<String, List<Map<String, ?>>> values : impDetailsList.entrySet()) 
		{
			logger.info("Key = " + values.getKey() + ", Value = " + values.getValue());
			List<Map<String, ?>> impDetails = (List<Map<String, ?>>) values.getValue();
			Iterator<Map<String, ?>> i = impDetails.iterator();
			while (i.hasNext()) 
			{
				Map<String, ?> beans = i.next();
				for (Map.Entry<String, ?> bean : beans.entrySet()) 
				{
					if (bean.getKey().equalsIgnoreCase("hubActivities"))
						activity = (String) bean.getValue();
					if (bean.getKey().equalsIgnoreCase("details"))
						detailsList = (List<String>) bean.getValue();
					
					deleteImpactHubAreas(activity);
					
					for (String details : detailsList) {
						try {
							String insertQuery = "insert into SDTOOL_SCHEMA.ImpactHubAreas values ('" + activity+ "', '" + details + "', ' ')";
							insResult = ConnectionUtil.getConnection().executeUpdate(insertQuery);
							logger.info("insertQuery -> :" + insertQuery);
							logger.info("insResult -> result :" + insResult);
						} catch (SQLIntegrityConstraintViolationException e) {
							continue;
						}
					}
				}
			}
		}
		return insResult;
	}
	
	private static int deleteImpactHubAreas(String param) throws ClassNotFoundException, SQLException
	{
		String deleteQuery = "DELETE FROM SDTOOL_SCHEMA.ImpactHubAreas where HubActivities ='"+param+"'";
		int delResult = ConnectionUtil.getConnection().executeUpdate(deleteQuery);
		logger.info("deleteQuery -> param : "+param+", result count :" + delResult);
		return delResult;
	}
	
	/**
	 * 
	 * @param userName
	 * @param password
	 * @return
	 */
	public static String getUserDetails(String userName, String password) 
	{
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select usrname, usrpwd from SDTOOL_SCHEMA.UsrDetails "
					+ "where usrname = '"+userName+"' and usrpwd = '"+password+"'" );
			if (rs.next() ) {
				return DashboardConstants.VALIDATED;
			}
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return DashboardConstants.INVALIDATED;
	}
	
	/**
	 * 
	 * @param action
	 * @return
	 */
	public static String getStatus(String action) {
		if (action.equalsIgnoreCase("stop")) {
			return  DashboardConstants.STOPPED;
		} else if (action.equalsIgnoreCase("start")) {
			return DashboardConstants.RUNNING;
		}
		return "";
	}
	
	/**
	 * 
	 * @param appNames
	 * @param action
	 * @return
	 */
	public static boolean updateAllStatus(List<String> appNames, String action) {
		boolean status = false;
		try 
		{
			String updateQuery = "Update SDTOOL_SCHEMA.HubApplication "
					+ "set AppStatus = '"+getStatus(action)+"' "
					+ "where AppName in ("+getAppNameString(appNames)+") ";
			int result = ConnectionUtil.getConnection().executeUpdate(updateQuery);
			logger.info("updateExcel -> Executing query :"+updateQuery);
			logger.info("updateExcel -> result :"+result);
			status = true;
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		return status;
	}
	
	/**
	 * 
	 * @param appNames
	 * @return
	 */
	private static String getAppNameString(List<String> appNames)
	{
		String finalString ="";
		for (String entry : appNames)
		{
			finalString +="'"+ entry+"',";
		}
		if(finalString.length() >= 1)
			return finalString.substring(0, finalString.length() -1);
		else
			return finalString;
	}
	
	/**
	 * 
	 * @param location
	 * @param appNames
	 * @param action
	 * @return
	 */
	public static boolean updateSpecificStatus(String location, List<String> appNames, String action) {
		boolean status = false;
		try 
		{
			String updateQuery = "Update SDTOOL_SCHEMA.HubApplication "
					+ "set AppStatus = '"+getStatus(action)+"' "
					+ "where HubLocation = '"+location+"' and AppName in ("+getAppNameString(appNames)+")";
			int result = ConnectionUtil.getConnection().executeUpdate(updateQuery);
			logger.info("updateExcel_Loc -> Executing query :"+updateQuery);
			logger.info("updateExcel_Loc -> result :"+result);
			status = true;
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}
		return status;
	}
	
	/**
	 * 
	 * @return
	 */
	public static List<String> getHubLocations()
	{
		List<String> hubList  = new ArrayList<String>();
		ResultSet rs = null;
		try 
		{
			rs = ConnectionUtil.getConnection().executeQuery("select distinct(HubLocation) from SDTOOL_SCHEMA.HubApplication");
			while (rs.next() ) {
				hubList.add(rs.getString(1));
			}
			logger.info("getHubLocations - Hub List :"+hubList);
		}
		catch (ClassNotFoundException | SQLException e1) {
			logger.error(e1);
		}

		finally {
			try {
				if (rs != null)
					rs.close();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return hubList;
	}
}
