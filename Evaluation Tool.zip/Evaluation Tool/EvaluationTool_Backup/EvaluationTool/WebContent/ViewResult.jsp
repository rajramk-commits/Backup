<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="java.io.*"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<script type="text/javascript" language="javascript">
</script>
<title>View Result Page</title>
</head>
<body>
<form name="ViewForm">
	<%
		try {
			String dirName = "C:/Users/rahul.raj/Documents/finaaal/Resources/";
			String fileName = dirName;
			boolean fileFound = false;
			File directoryPath = new File(dirName);
			String contents[] = directoryPath.list();
			String uId = request.getParameter("id");
			%>
				<input type="hidden" name="uId" value="<%=uId%>">
			<%
			for(int i=0; i<contents.length; i++) {
		         System.out.println(contents[i]);
		         System.out.println("uId"+uId);
		         
		         if(uId != null && contents[i].contains(uId))
		         {
		        	 fileName+= contents[i];
		        	 fileFound = true;
		        	 break;
		         }
		      }
			
			System.out.println("fileName :"+fileName);
			
			if(fileFound)
			{
				File file = new File(fileName);
				BufferedReader br = new BufferedReader(new FileReader(file));
				String st;
				int count = 0;
				while ((st = br.readLine()) != null)
				{
					if(count < 4)
					{
						++count;
						%>
						<label style="font-size: x-large;font-family: sans-serif; color:purple;"><b><%=st %></b></label><br>
						<% 
						continue;
					}
					if(st.startsWith("User Answer"))
					{%>
					<br><label style="font-size:medium; font-family: sans-serif; color: red;"><%=st %></label><br>
					<% 
					}
					else if(st.endsWith("Questions"))
					{%>
					<label style="font-size: x-large;font-family: sans-serif; color: black;"><b><%=st %></b></label><br>
					<% 
					}
					else if(st.contains("Marks Obtained"))
					{%>
					<label style="font-size: medium;font-family: sans-serif; color: blue;"><b><%=st %></b></label><br>
					<% 
					}
					else if(st.contains("Result"))
					{
						if(st.contains("PASS"))
						{
							%>
							<label style="font-size: large;font-family: sans-serif; color: green;"><b><%=st %></b></label><br>
							<%
						}
						if(st.contains("FAIL"))
						{
							%>
							<label style="font-size: large;font-family: sans-serif; color: red;"><b><%=st %></b></label><br>
							<%
						}
					}
					else if(st.contains("Correct"))
					{
						%>
						<label style="font-size: medium;font-family: sans-serif; color: green;"><b><%=st %></b></label><br>
						<%
					}
					else if(st.contains("Wrong"))
					{
						%>
						<label style="font-size: medium;font-family: sans-serif; color: red;"><b><%=st %></b></label><br>
						<%
					}
					
					else if(st.contains("Average"))
					{%>
					<label style="font-size: large;font-family: sans-serif; color: blue;"><b><%=st %></b></label><br>
					<% 
					}
					else if (st.contains("Total"))
					{
					%>
					<br>
					<label style="font-size: large;font-family: sans-serif; color: black;"><b><%=st %></b></label><br>
					<%}
					else
					{
						%>
						<label style="font-size:medium; font-family: sans-serif; color: black;"><%=st %></label><br>
						<% 
					}
				}
				br.close();
		 	}
			else{
				%>
					<label>No data found for the user : <%=uId %></label>
				<%
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	%>
	<br><br>
</form>
</body>
</html>