package com.fedex.emea.sabreReport.util;

public class StringUtils {
	 public static synchronized boolean isValidString(String string) {
	        return string!= null && string.trim().length() > 0;
	    }
}
