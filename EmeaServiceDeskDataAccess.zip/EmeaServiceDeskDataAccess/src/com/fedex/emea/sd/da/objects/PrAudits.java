package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;

public class PrAudits implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7018973337987767334L;

	protected String cy;
	protected String symEaiId;
	protected String ni2AppName;
	protected String respMdPin;
	protected String respMgrPin;
	protected String ni2Bi;
	protected String eaiTier;
	protected String mainDc;
	protected String bcRac;
	protected int bcRacWgt;
	protected boolean bcRacWgtNull = true;
	protected String bcRacRisk;
	protected String bcLocal;
	protected int bcLocalWgt;
	protected boolean bcLocalWgtNull = true;
	protected String bcLocalRisk;
	protected String bcRemote;
	protected int bcRemoteWgt;
	protected boolean bcRemoteWgtNull = true;
	protected String bcRemoteRisk;
	protected String cntgncyPlan;
	protected int cntgncyPlanWgt;
	protected boolean cntgncyPlanWgtNull = true;
	protected String cntgncyPlanRisk;
	protected String drDoc;
	protected int drDocWgt;
	protected boolean drDocWgtNull = true;
	protected String drDocRisk;
	protected String drArcher;
	protected int drArcherWgt;
	protected boolean drArcherWgtNull = true;
	protected String drArcherRisk;
	protected Date drLastTestDt;
	protected int drLastTestDtWgt;
	protected boolean drLastTestDtWgtNull = true;
	protected String drLastTestDtRisk;
	protected String suppOc;
	protected int suppOcWgt;
	protected boolean suppOcWgtNull = true;
	protected String suppOcRisk;
	protected String suppStaff;
	protected int suppStaffWgt;
	protected boolean suppStaffWgtNull = true;
	protected String suppStaffRisk;
	protected String suppTrain;
	protected int suppTrainWgt;
	protected boolean suppTrainWgtNull = true;
	protected String suppTrainRisk;
	protected String suppTecbu;
	protected int suppTecbuWgt;
	protected boolean suppTecbuWgtNull = true;
	protected String suppTecbuRisk;
	protected String suppNi2;
	protected int suppNi2Wgt;
	protected boolean suppNi2WgtNull = true;
	protected String suppNi2Risk;
	protected String comments;
	protected int riskFactor;
	protected boolean riskFactorNull = true;
	protected String ni2AppId;
	protected String auditStatus;
	protected Date lastUpdateDttm;
	protected int auditId;
	protected boolean auditIdNull = true;
	protected String org;

	/**
	 * Method 'PrAudits'
	 * 
	 */
	public PrAudits()
	{
	}

	/**
	 * Method 'getCy'
	 * 
	 * @return String
	 */
	public String getCy()
	{
		return cy;
	}

	/**
	 * Method 'setCy'
	 * 
	 * @param cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/**
	 * Method 'getSymEaiId'
	 * 
	 * @return String
	 */
	public String getSymEaiId()
	{
		return symEaiId;
	}

	/**
	 * Method 'setSymEaiId'
	 * 
	 * @param symEaiId
	 */
	public void setSymEaiId(String symEaiId)
	{
		this.symEaiId = symEaiId;
	}

	/**
	 * Method 'getNi2AppName'
	 * 
	 * @return String
	 */
	public String getNi2AppName()
	{
		return ni2AppName;
	}

	/**
	 * Method 'setNi2AppName'
	 * 
	 * @param ni2AppName
	 */
	public void setNi2AppName(String ni2AppName)
	{
		this.ni2AppName = ni2AppName;
	}

	/**
	 * Method 'getRespMdPin'
	 * 
	 * @return String
	 */
	public String getRespMdPin()
	{
		return respMdPin;
	}

	/**
	 * Method 'setRespMdPin'
	 * 
	 * @param respMdPin
	 */
	public void setRespMdPin(String respMdPin)
	{
		this.respMdPin = respMdPin;
	}

	/**
	 * Method 'getRespMgrPin'
	 * 
	 * @return String
	 */
	public String getRespMgrPin()
	{
		return respMgrPin;
	}

	/**
	 * Method 'setRespMgrPin'
	 * 
	 * @param respMgrPin
	 */
	public void setRespMgrPin(String respMgrPin)
	{
		this.respMgrPin = respMgrPin;
	}

	/**
	 * Method 'getNi2Bi'
	 * 
	 * @return String
	 */
	public String getNi2Bi()
	{
		return ni2Bi;
	}

	/**
	 * Method 'setNi2Bi'
	 * 
	 * @param ni2Bi
	 */
	public void setNi2Bi(String ni2Bi)
	{
		this.ni2Bi = ni2Bi;
	}

	/**
	 * Method 'getEaiTier'
	 * 
	 * @return String
	 */
	public String getEaiTier()
	{
		return eaiTier;
	}

	/**
	 * Method 'setEaiTier'
	 * 
	 * @param eaiTier
	 */
	public void setEaiTier(String eaiTier)
	{
		this.eaiTier = eaiTier;
	}

	/**
	 * Method 'getMainDc'
	 * 
	 * @return String
	 */
	public String getMainDc()
	{
		return mainDc;
	}

	/**
	 * Method 'setMainDc'
	 * 
	 * @param mainDc
	 */
	public void setMainDc(String mainDc)
	{
		this.mainDc = mainDc;
	}

	/**
	 * Method 'getBcRac'
	 * 
	 * @return String
	 */
	public String getBcRac()
	{
		return bcRac;
	}

	/**
	 * Method 'setBcRac'
	 * 
	 * @param bcRac
	 */
	public void setBcRac(String bcRac)
	{
		this.bcRac = bcRac;
	}

	/**
	 * Method 'getBcRacWgt'
	 * 
	 * @return int
	 */
	public int getBcRacWgt()
	{
		return bcRacWgt;
	}

	/**
	 * Method 'setBcRacWgt'
	 * 
	 * @param bcRacWgt
	 */
	public void setBcRacWgt(int bcRacWgt)
	{
		this.bcRacWgt = bcRacWgt;
		this.bcRacWgtNull = false;
	}

	/**
	 * Method 'setBcRacWgtNull'
	 * 
	 * @param value
	 */
	public void setBcRacWgtNull(boolean value)
	{
		this.bcRacWgtNull = value;
	}

	/**
	 * Method 'isBcRacWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isBcRacWgtNull()
	{
		return bcRacWgtNull;
	}

	/**
	 * Method 'getBcRacRisk'
	 * 
	 * @return String
	 */
	public String getBcRacRisk()
	{
		return bcRacRisk;
	}

	/**
	 * Method 'setBcRacRisk'
	 * 
	 * @param bcRacRisk
	 */
	public void setBcRacRisk(String bcRacRisk)
	{
		this.bcRacRisk = bcRacRisk;
	}

	/**
	 * Method 'getBcLocal'
	 * 
	 * @return String
	 */
	public String getBcLocal()
	{
		return bcLocal;
	}

	/**
	 * Method 'setBcLocal'
	 * 
	 * @param bcLocal
	 */
	public void setBcLocal(String bcLocal)
	{
		this.bcLocal = bcLocal;
	}

	/**
	 * Method 'getBcLocalWgt'
	 * 
	 * @return int
	 */
	public int getBcLocalWgt()
	{
		return bcLocalWgt;
	}

	/**
	 * Method 'setBcLocalWgt'
	 * 
	 * @param bcLocalWgt
	 */
	public void setBcLocalWgt(int bcLocalWgt)
	{
		this.bcLocalWgt = bcLocalWgt;
		this.bcLocalWgtNull = false;
	}

	/**
	 * Method 'setBcLocalWgtNull'
	 * 
	 * @param value
	 */
	public void setBcLocalWgtNull(boolean value)
	{
		this.bcLocalWgtNull = value;
	}

	/**
	 * Method 'isBcLocalWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isBcLocalWgtNull()
	{
		return bcLocalWgtNull;
	}

	/**
	 * Method 'getBcLocalRisk'
	 * 
	 * @return String
	 */
	public String getBcLocalRisk()
	{
		return bcLocalRisk;
	}

	/**
	 * Method 'setBcLocalRisk'
	 * 
	 * @param bcLocalRisk
	 */
	public void setBcLocalRisk(String bcLocalRisk)
	{
		this.bcLocalRisk = bcLocalRisk;
	}

	/**
	 * Method 'getBcRemote'
	 * 
	 * @return String
	 */
	public String getBcRemote()
	{
		return bcRemote;
	}

	/**
	 * Method 'setBcRemote'
	 * 
	 * @param bcRemote
	 */
	public void setBcRemote(String bcRemote)
	{
		this.bcRemote = bcRemote;
	}

	/**
	 * Method 'getBcRemoteWgt'
	 * 
	 * @return int
	 */
	public int getBcRemoteWgt()
	{
		return bcRemoteWgt;
	}

	/**
	 * Method 'setBcRemoteWgt'
	 * 
	 * @param bcRemoteWgt
	 */
	public void setBcRemoteWgt(int bcRemoteWgt)
	{
		this.bcRemoteWgt = bcRemoteWgt;
		this.bcRemoteWgtNull = false;
	}

	/**
	 * Method 'setBcRemoteWgtNull'
	 * 
	 * @param value
	 */
	public void setBcRemoteWgtNull(boolean value)
	{
		this.bcRemoteWgtNull = value;
	}

	/**
	 * Method 'isBcRemoteWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isBcRemoteWgtNull()
	{
		return bcRemoteWgtNull;
	}

	/**
	 * Method 'getBcRemoteRisk'
	 * 
	 * @return String
	 */
	public String getBcRemoteRisk()
	{
		return bcRemoteRisk;
	}

	/**
	 * Method 'setBcRemoteRisk'
	 * 
	 * @param bcRemoteRisk
	 */
	public void setBcRemoteRisk(String bcRemoteRisk)
	{
		this.bcRemoteRisk = bcRemoteRisk;
	}

	/**
	 * Method 'getCntgncyPlan'
	 * 
	 * @return String
	 */
	public String getCntgncyPlan()
	{
		return cntgncyPlan;
	}

	/**
	 * Method 'setCntgncyPlan'
	 * 
	 * @param cntgncyPlan
	 */
	public void setCntgncyPlan(String cntgncyPlan)
	{
		this.cntgncyPlan = cntgncyPlan;
	}

	/**
	 * Method 'getCntgncyPlanWgt'
	 * 
	 * @return int
	 */
	public int getCntgncyPlanWgt()
	{
		return cntgncyPlanWgt;
	}

	/**
	 * Method 'setCntgncyPlanWgt'
	 * 
	 * @param cntgncyPlanWgt
	 */
	public void setCntgncyPlanWgt(int cntgncyPlanWgt)
	{
		this.cntgncyPlanWgt = cntgncyPlanWgt;
		this.cntgncyPlanWgtNull = false;
	}

	/**
	 * Method 'setCntgncyPlanWgtNull'
	 * 
	 * @param value
	 */
	public void setCntgncyPlanWgtNull(boolean value)
	{
		this.cntgncyPlanWgtNull = value;
	}

	/**
	 * Method 'isCntgncyPlanWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isCntgncyPlanWgtNull()
	{
		return cntgncyPlanWgtNull;
	}

	/**
	 * Method 'getCntgncyPlanRisk'
	 * 
	 * @return String
	 */
	public String getCntgncyPlanRisk()
	{
		return cntgncyPlanRisk;
	}

	/**
	 * Method 'setCntgncyPlanRisk'
	 * 
	 * @param cntgncyPlanRisk
	 */
	public void setCntgncyPlanRisk(String cntgncyPlanRisk)
	{
		this.cntgncyPlanRisk = cntgncyPlanRisk;
	}

	/**
	 * Method 'getDrDoc'
	 * 
	 * @return String
	 */
	public String getDrDoc()
	{
		return drDoc;
	}

	/**
	 * Method 'setDrDoc'
	 * 
	 * @param drDoc
	 */
	public void setDrDoc(String drDoc)
	{
		this.drDoc = drDoc;
	}

	/**
	 * Method 'getDrDocWgt'
	 * 
	 * @return int
	 */
	public int getDrDocWgt()
	{
		return drDocWgt;
	}

	/**
	 * Method 'setDrDocWgt'
	 * 
	 * @param drDocWgt
	 */
	public void setDrDocWgt(int drDocWgt)
	{
		this.drDocWgt = drDocWgt;
		this.drDocWgtNull = false;
	}

	/**
	 * Method 'setDrDocWgtNull'
	 * 
	 * @param value
	 */
	public void setDrDocWgtNull(boolean value)
	{
		this.drDocWgtNull = value;
	}

	/**
	 * Method 'isDrDocWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isDrDocWgtNull()
	{
		return drDocWgtNull;
	}

	/**
	 * Method 'getDrDocRisk'
	 * 
	 * @return String
	 */
	public String getDrDocRisk()
	{
		return drDocRisk;
	}

	/**
	 * Method 'setDrDocRisk'
	 * 
	 * @param drDocRisk
	 */
	public void setDrDocRisk(String drDocRisk)
	{
		this.drDocRisk = drDocRisk;
	}

	/**
	 * Method 'getDrArcher'
	 * 
	 * @return String
	 */
	public String getDrArcher()
	{
		return drArcher;
	}

	/**
	 * Method 'setDrArcher'
	 * 
	 * @param drArcher
	 */
	public void setDrArcher(String drArcher)
	{
		this.drArcher = drArcher;
	}

	/**
	 * Method 'getDrArcherWgt'
	 * 
	 * @return int
	 */
	public int getDrArcherWgt()
	{
		return drArcherWgt;
	}

	/**
	 * Method 'setDrArcherWgt'
	 * 
	 * @param drArcherWgt
	 */
	public void setDrArcherWgt(int drArcherWgt)
	{
		this.drArcherWgt = drArcherWgt;
		this.drArcherWgtNull = false;
	}

	/**
	 * Method 'setDrArcherWgtNull'
	 * 
	 * @param value
	 */
	public void setDrArcherWgtNull(boolean value)
	{
		this.drArcherWgtNull = value;
	}

	/**
	 * Method 'isDrArcherWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isDrArcherWgtNull()
	{
		return drArcherWgtNull;
	}

	/**
	 * Method 'getDrArcherRisk'
	 * 
	 * @return String
	 */
	public String getDrArcherRisk()
	{
		return drArcherRisk;
	}

	/**
	 * Method 'setDrArcherRisk'
	 * 
	 * @param drArcherRisk
	 */
	public void setDrArcherRisk(String drArcherRisk)
	{
		this.drArcherRisk = drArcherRisk;
	}

	/**
	 * Method 'getDrLastTestDt'
	 * 
	 * @return Date
	 */
	public Date getDrLastTestDt()
	{
		return drLastTestDt;
	}

	/**
	 * Method 'setDrLastTestDt'
	 * 
	 * @param drLastTestDt
	 */
	public void setDrLastTestDt(Date drLastTestDt)
	{
		this.drLastTestDt = drLastTestDt;
	}

	/**
	 * Method 'getDrLastTestDtWgt'
	 * 
	 * @return int
	 */
	public int getDrLastTestDtWgt()
	{
		return drLastTestDtWgt;
	}

	/**
	 * Method 'setDrLastTestDtWgt'
	 * 
	 * @param drLastTestDtWgt
	 */
	public void setDrLastTestDtWgt(int drLastTestDtWgt)
	{
		this.drLastTestDtWgt = drLastTestDtWgt;
		this.drLastTestDtWgtNull = false;
	}

	/**
	 * Method 'setDrLastTestDtWgtNull'
	 * 
	 * @param value
	 */
	public void setDrLastTestDtWgtNull(boolean value)
	{
		this.drLastTestDtWgtNull = value;
	}

	/**
	 * Method 'isDrLastTestDtWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isDrLastTestDtWgtNull()
	{
		return drLastTestDtWgtNull;
	}

	/**
	 * Method 'getDrLastTestDtRisk'
	 * 
	 * @return String
	 */
	public String getDrLastTestDtRisk()
	{
		return drLastTestDtRisk;
	}

	/**
	 * Method 'setDrLastTestDtRisk'
	 * 
	 * @param drLastTestDtRisk
	 */
	public void setDrLastTestDtRisk(String drLastTestDtRisk)
	{
		this.drLastTestDtRisk = drLastTestDtRisk;
	}

	/**
	 * Method 'getSuppOc'
	 * 
	 * @return String
	 */
	public String getSuppOc()
	{
		return suppOc;
	}

	/**
	 * Method 'setSuppOc'
	 * 
	 * @param suppOc
	 */
	public void setSuppOc(String suppOc)
	{
		this.suppOc = suppOc;
	}

	/**
	 * Method 'getSuppOcWgt'
	 * 
	 * @return int
	 */
	public int getSuppOcWgt()
	{
		return suppOcWgt;
	}

	/**
	 * Method 'setSuppOcWgt'
	 * 
	 * @param suppOcWgt
	 */
	public void setSuppOcWgt(int suppOcWgt)
	{
		this.suppOcWgt = suppOcWgt;
		this.suppOcWgtNull = false;
	}

	/**
	 * Method 'setSuppOcWgtNull'
	 * 
	 * @param value
	 */
	public void setSuppOcWgtNull(boolean value)
	{
		this.suppOcWgtNull = value;
	}

	/**
	 * Method 'isSuppOcWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isSuppOcWgtNull()
	{
		return suppOcWgtNull;
	}

	/**
	 * Method 'getSuppOcRisk'
	 * 
	 * @return String
	 */
	public String getSuppOcRisk()
	{
		return suppOcRisk;
	}

	/**
	 * Method 'setSuppOcRisk'
	 * 
	 * @param suppOcRisk
	 */
	public void setSuppOcRisk(String suppOcRisk)
	{
		this.suppOcRisk = suppOcRisk;
	}

	/**
	 * Method 'getSuppStaff'
	 * 
	 * @return String
	 */
	public String getSuppStaff()
	{
		return suppStaff;
	}

	/**
	 * Method 'setSuppStaff'
	 * 
	 * @param suppStaff
	 */
	public void setSuppStaff(String suppStaff)
	{
		this.suppStaff = suppStaff;
	}

	/**
	 * Method 'getSuppStaffWgt'
	 * 
	 * @return int
	 */
	public int getSuppStaffWgt()
	{
		return suppStaffWgt;
	}

	/**
	 * Method 'setSuppStaffWgt'
	 * 
	 * @param suppStaffWgt
	 */
	public void setSuppStaffWgt(int suppStaffWgt)
	{
		this.suppStaffWgt = suppStaffWgt;
		this.suppStaffWgtNull = false;
	}

	/**
	 * Method 'setSuppStaffWgtNull'
	 * 
	 * @param value
	 */
	public void setSuppStaffWgtNull(boolean value)
	{
		this.suppStaffWgtNull = value;
	}

	/**
	 * Method 'isSuppStaffWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isSuppStaffWgtNull()
	{
		return suppStaffWgtNull;
	}

	/**
	 * Method 'getSuppStaffRisk'
	 * 
	 * @return String
	 */
	public String getSuppStaffRisk()
	{
		return suppStaffRisk;
	}

	/**
	 * Method 'setSuppStaffRisk'
	 * 
	 * @param suppStaffRisk
	 */
	public void setSuppStaffRisk(String suppStaffRisk)
	{
		this.suppStaffRisk = suppStaffRisk;
	}

	/**
	 * Method 'getSuppTrain'
	 * 
	 * @return String
	 */
	public String getSuppTrain()
	{
		return suppTrain;
	}

	/**
	 * Method 'setSuppTrain'
	 * 
	 * @param suppTrain
	 */
	public void setSuppTrain(String suppTrain)
	{
		this.suppTrain = suppTrain;
	}

	/**
	 * Method 'getSuppTrainWgt'
	 * 
	 * @return int
	 */
	public int getSuppTrainWgt()
	{
		return suppTrainWgt;
	}

	/**
	 * Method 'setSuppTrainWgt'
	 * 
	 * @param suppTrainWgt
	 */
	public void setSuppTrainWgt(int suppTrainWgt)
	{
		this.suppTrainWgt = suppTrainWgt;
		this.suppTrainWgtNull = false;
	}

	/**
	 * Method 'setSuppTrainWgtNull'
	 * 
	 * @param value
	 */
	public void setSuppTrainWgtNull(boolean value)
	{
		this.suppTrainWgtNull = value;
	}

	/**
	 * Method 'isSuppTrainWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isSuppTrainWgtNull()
	{
		return suppTrainWgtNull;
	}

	/**
	 * Method 'getSuppTrainRisk'
	 * 
	 * @return String
	 */
	public String getSuppTrainRisk()
	{
		return suppTrainRisk;
	}

	/**
	 * Method 'setSuppTrainRisk'
	 * 
	 * @param suppTrainRisk
	 */
	public void setSuppTrainRisk(String suppTrainRisk)
	{
		this.suppTrainRisk = suppTrainRisk;
	}

	/**
	 * Method 'getSuppTecbu'
	 * 
	 * @return String
	 */
	public String getSuppTecbu()
	{
		return suppTecbu;
	}

	/**
	 * Method 'setSuppTecbu'
	 * 
	 * @param suppTecbu
	 */
	public void setSuppTecbu(String suppTecbu)
	{
		this.suppTecbu = suppTecbu;
	}

	/**
	 * Method 'getSuppTecbuWgt'
	 * 
	 * @return int
	 */
	public int getSuppTecbuWgt()
	{
		return suppTecbuWgt;
	}

	/**
	 * Method 'setSuppTecbuWgt'
	 * 
	 * @param suppTecbuWgt
	 */
	public void setSuppTecbuWgt(int suppTecbuWgt)
	{
		this.suppTecbuWgt = suppTecbuWgt;
		this.suppTecbuWgtNull = false;
	}

	/**
	 * Method 'setSuppTecbuWgtNull'
	 * 
	 * @param value
	 */
	public void setSuppTecbuWgtNull(boolean value)
	{
		this.suppTecbuWgtNull = value;
	}

	/**
	 * Method 'isSuppTecbuWgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isSuppTecbuWgtNull()
	{
		return suppTecbuWgtNull;
	}

	/**
	 * Method 'getSuppTecbuRisk'
	 * 
	 * @return String
	 */
	public String getSuppTecbuRisk()
	{
		return suppTecbuRisk;
	}

	/**
	 * Method 'setSuppTecbuRisk'
	 * 
	 * @param suppTecbuRisk
	 */
	public void setSuppTecbuRisk(String suppTecbuRisk)
	{
		this.suppTecbuRisk = suppTecbuRisk;
	}

	/**
	 * Method 'getSuppNi2'
	 * 
	 * @return String
	 */
	public String getSuppNi2()
	{
		return suppNi2;
	}

	/**
	 * Method 'setSuppNi2'
	 * 
	 * @param suppNi2
	 */
	public void setSuppNi2(String suppNi2)
	{
		this.suppNi2 = suppNi2;
	}

	/**
	 * Method 'getSuppNi2Wgt'
	 * 
	 * @return int
	 */
	public int getSuppNi2Wgt()
	{
		return suppNi2Wgt;
	}

	/**
	 * Method 'setSuppNi2Wgt'
	 * 
	 * @param suppNi2Wgt
	 */
	public void setSuppNi2Wgt(int suppNi2Wgt)
	{
		this.suppNi2Wgt = suppNi2Wgt;
		this.suppNi2WgtNull = false;
	}

	/**
	 * Method 'setSuppNi2WgtNull'
	 * 
	 * @param value
	 */
	public void setSuppNi2WgtNull(boolean value)
	{
		this.suppNi2WgtNull = value;
	}

	/**
	 * Method 'isSuppNi2WgtNull'
	 * 
	 * @return boolean
	 */
	public boolean isSuppNi2WgtNull()
	{
		return suppNi2WgtNull;
	}

	/**
	 * Method 'getSuppNi2Risk'
	 * 
	 * @return String
	 */
	public String getSuppNi2Risk()
	{
		return suppNi2Risk;
	}

	/**
	 * Method 'setSuppNi2Risk'
	 * 
	 * @param suppNi2Risk
	 */
	public void setSuppNi2Risk(String suppNi2Risk)
	{
		this.suppNi2Risk = suppNi2Risk;
	}

	/**
	 * Method 'getComments'
	 * 
	 * @return String
	 */
	public String getComments()
	{
		return comments;
	}

	/**
	 * Method 'setComments'
	 * 
	 * @param comments
	 */
	public void setComments(String comments)
	{
		this.comments = comments;
	}

	/**
	 * Method 'getRiskFactor'
	 * 
	 * @return int
	 */
	public int getRiskFactor()
	{
		return riskFactor;
	}

	/**
	 * Method 'setRiskFactor'
	 * 
	 * @param riskFactor
	 */
	public void setRiskFactor(int riskFactor)
	{
		this.riskFactor = riskFactor;
		this.riskFactorNull = false;
	}

	/**
	 * Method 'setRiskFactorNull'
	 * 
	 * @param value
	 */
	public void setRiskFactorNull(boolean value)
	{
		this.riskFactorNull = value;
	}

	/**
	 * Method 'isRiskFactorNull'
	 * 
	 * @return boolean
	 */
	public boolean isRiskFactorNull()
	{
		return riskFactorNull;
	}

	/**
	 * Method 'getNi2AppId'
	 * 
	 * @return String
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'setNi2AppId'
	 * 
	 * @param ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'getAuditStatus'
	 * 
	 * @return String
	 */
	public String getAuditStatus()
	{
		return auditStatus;
	}

	/**
	 * Method 'setAuditStatus'
	 * 
	 * @param auditStatus
	 */
	public void setAuditStatus(String auditStatus)
	{
		this.auditStatus = auditStatus;
	}

	/**
	 * Method 'getLastUpdateDttm'
	 * 
	 * @return Date
	 */
	public Date getLastUpdateDttm()
	{
		return lastUpdateDttm;
	}

	/**
	 * Method 'setLastUpdateDttm'
	 * 
	 * @param lastUpdateDttm
	 */
	public void setLastUpdateDttm(Date lastUpdateDttm)
	{
		this.lastUpdateDttm = lastUpdateDttm;
	}

	/**
	 * Method 'getAuditId'
	 * 
	 * @return int
	 */
	public int getAuditId()
	{
		return auditId;
	}

	/**
	 * Method 'setAuditId'
	 * 
	 * @param auditId
	 */
	public void setAuditId(int auditId)
	{
		this.auditId = auditId;
		this.auditIdNull = false;
	}

	/**
	 * Method 'setAuditIdNull'
	 * 
	 * @param value
	 */
	public void setAuditIdNull(boolean value)
	{
		this.auditIdNull = value;
	}

	/**
	 * Method 'isAuditIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isAuditIdNull()
	{
		return auditIdNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrAudits)) {
			return false;
		}
		
		final PrAudits _cast = (PrAudits) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (symEaiId == null ? _cast.symEaiId != symEaiId : !symEaiId.equals( _cast.symEaiId )) {
			return false;
		}
		
		if (ni2AppName == null ? _cast.ni2AppName != ni2AppName : !ni2AppName.equals( _cast.ni2AppName )) {
			return false;
		}
		
		if (respMdPin == null ? _cast.respMdPin != respMdPin : !respMdPin.equals( _cast.respMdPin )) {
			return false;
		}
		
		if (respMgrPin == null ? _cast.respMgrPin != respMgrPin : !respMgrPin.equals( _cast.respMgrPin )) {
			return false;
		}
		
		if (ni2Bi == null ? _cast.ni2Bi != ni2Bi : !ni2Bi.equals( _cast.ni2Bi )) {
			return false;
		}
		
		if (eaiTier == null ? _cast.eaiTier != eaiTier : !eaiTier.equals( _cast.eaiTier )) {
			return false;
		}
		
		if (mainDc == null ? _cast.mainDc != mainDc : !mainDc.equals( _cast.mainDc )) {
			return false;
		}
		
		if (bcRac == null ? _cast.bcRac != bcRac : !bcRac.equals( _cast.bcRac )) {
			return false;
		}
		
		if (bcRacWgt != _cast.bcRacWgt) {
			return false;
		}
		
		if (bcRacWgtNull != _cast.bcRacWgtNull) {
			return false;
		}
		
		if (bcRacRisk == null ? _cast.bcRacRisk != bcRacRisk : !bcRacRisk.equals( _cast.bcRacRisk )) {
			return false;
		}
		
		if (bcLocal == null ? _cast.bcLocal != bcLocal : !bcLocal.equals( _cast.bcLocal )) {
			return false;
		}
		
		if (bcLocalWgt != _cast.bcLocalWgt) {
			return false;
		}
		
		if (bcLocalWgtNull != _cast.bcLocalWgtNull) {
			return false;
		}
		
		if (bcLocalRisk == null ? _cast.bcLocalRisk != bcLocalRisk : !bcLocalRisk.equals( _cast.bcLocalRisk )) {
			return false;
		}
		
		if (bcRemote == null ? _cast.bcRemote != bcRemote : !bcRemote.equals( _cast.bcRemote )) {
			return false;
		}
		
		if (bcRemoteWgt != _cast.bcRemoteWgt) {
			return false;
		}
		
		if (bcRemoteWgtNull != _cast.bcRemoteWgtNull) {
			return false;
		}
		
		if (bcRemoteRisk == null ? _cast.bcRemoteRisk != bcRemoteRisk : !bcRemoteRisk.equals( _cast.bcRemoteRisk )) {
			return false;
		}
		
		if (cntgncyPlan == null ? _cast.cntgncyPlan != cntgncyPlan : !cntgncyPlan.equals( _cast.cntgncyPlan )) {
			return false;
		}
		
		if (cntgncyPlanWgt != _cast.cntgncyPlanWgt) {
			return false;
		}
		
		if (cntgncyPlanWgtNull != _cast.cntgncyPlanWgtNull) {
			return false;
		}
		
		if (cntgncyPlanRisk == null ? _cast.cntgncyPlanRisk != cntgncyPlanRisk : !cntgncyPlanRisk.equals( _cast.cntgncyPlanRisk )) {
			return false;
		}
		
		if (drDoc == null ? _cast.drDoc != drDoc : !drDoc.equals( _cast.drDoc )) {
			return false;
		}
		
		if (drDocWgt != _cast.drDocWgt) {
			return false;
		}
		
		if (drDocWgtNull != _cast.drDocWgtNull) {
			return false;
		}
		
		if (drDocRisk == null ? _cast.drDocRisk != drDocRisk : !drDocRisk.equals( _cast.drDocRisk )) {
			return false;
		}
		
		if (drArcher == null ? _cast.drArcher != drArcher : !drArcher.equals( _cast.drArcher )) {
			return false;
		}
		
		if (drArcherWgt != _cast.drArcherWgt) {
			return false;
		}
		
		if (drArcherWgtNull != _cast.drArcherWgtNull) {
			return false;
		}
		
		if (drArcherRisk == null ? _cast.drArcherRisk != drArcherRisk : !drArcherRisk.equals( _cast.drArcherRisk )) {
			return false;
		}
		
		if (drLastTestDt == null ? _cast.drLastTestDt != drLastTestDt : !drLastTestDt.equals( _cast.drLastTestDt )) {
			return false;
		}
		
		if (drLastTestDtWgt != _cast.drLastTestDtWgt) {
			return false;
		}
		
		if (drLastTestDtWgtNull != _cast.drLastTestDtWgtNull) {
			return false;
		}
		
		if (drLastTestDtRisk == null ? _cast.drLastTestDtRisk != drLastTestDtRisk : !drLastTestDtRisk.equals( _cast.drLastTestDtRisk )) {
			return false;
		}
		
		if (suppOc == null ? _cast.suppOc != suppOc : !suppOc.equals( _cast.suppOc )) {
			return false;
		}
		
		if (suppOcWgt != _cast.suppOcWgt) {
			return false;
		}
		
		if (suppOcWgtNull != _cast.suppOcWgtNull) {
			return false;
		}
		
		if (suppOcRisk == null ? _cast.suppOcRisk != suppOcRisk : !suppOcRisk.equals( _cast.suppOcRisk )) {
			return false;
		}
		
		if (suppStaff == null ? _cast.suppStaff != suppStaff : !suppStaff.equals( _cast.suppStaff )) {
			return false;
		}
		
		if (suppStaffWgt != _cast.suppStaffWgt) {
			return false;
		}
		
		if (suppStaffWgtNull != _cast.suppStaffWgtNull) {
			return false;
		}
		
		if (suppStaffRisk == null ? _cast.suppStaffRisk != suppStaffRisk : !suppStaffRisk.equals( _cast.suppStaffRisk )) {
			return false;
		}
		
		if (suppTrain == null ? _cast.suppTrain != suppTrain : !suppTrain.equals( _cast.suppTrain )) {
			return false;
		}
		
		if (suppTrainWgt != _cast.suppTrainWgt) {
			return false;
		}
		
		if (suppTrainWgtNull != _cast.suppTrainWgtNull) {
			return false;
		}
		
		if (suppTrainRisk == null ? _cast.suppTrainRisk != suppTrainRisk : !suppTrainRisk.equals( _cast.suppTrainRisk )) {
			return false;
		}
		
		if (suppTecbu == null ? _cast.suppTecbu != suppTecbu : !suppTecbu.equals( _cast.suppTecbu )) {
			return false;
		}
		
		if (suppTecbuWgt != _cast.suppTecbuWgt) {
			return false;
		}
		
		if (suppTecbuWgtNull != _cast.suppTecbuWgtNull) {
			return false;
		}
		
		if (suppTecbuRisk == null ? _cast.suppTecbuRisk != suppTecbuRisk : !suppTecbuRisk.equals( _cast.suppTecbuRisk )) {
			return false;
		}
		
		if (suppNi2 == null ? _cast.suppNi2 != suppNi2 : !suppNi2.equals( _cast.suppNi2 )) {
			return false;
		}
		
		if (suppNi2Wgt != _cast.suppNi2Wgt) {
			return false;
		}
		
		if (suppNi2WgtNull != _cast.suppNi2WgtNull) {
			return false;
		}
		
		if (suppNi2Risk == null ? _cast.suppNi2Risk != suppNi2Risk : !suppNi2Risk.equals( _cast.suppNi2Risk )) {
			return false;
		}
		
		if (comments == null ? _cast.comments != comments : !comments.equals( _cast.comments )) {
			return false;
		}
		
		if (riskFactor != _cast.riskFactor) {
			return false;
		}
		
		if (riskFactorNull != _cast.riskFactorNull) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		if (auditStatus == null ? _cast.auditStatus != auditStatus : !auditStatus.equals( _cast.auditStatus )) {
			return false;
		}
		
		if (lastUpdateDttm == null ? _cast.lastUpdateDttm != lastUpdateDttm : !lastUpdateDttm.equals( _cast.lastUpdateDttm )) {
			return false;
		}
		
		if (auditId != _cast.auditId) {
			return false;
		}
		
		if (auditIdNull != _cast.auditIdNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (symEaiId != null) {
			_hashCode = 29 * _hashCode + symEaiId.hashCode();
		}
		
		if (ni2AppName != null) {
			_hashCode = 29 * _hashCode + ni2AppName.hashCode();
		}
		
		if (respMdPin != null) {
			_hashCode = 29 * _hashCode + respMdPin.hashCode();
		}
		
		if (respMgrPin != null) {
			_hashCode = 29 * _hashCode + respMgrPin.hashCode();
		}
		
		if (ni2Bi != null) {
			_hashCode = 29 * _hashCode + ni2Bi.hashCode();
		}
		
		if (eaiTier != null) {
			_hashCode = 29 * _hashCode + eaiTier.hashCode();
		}
		
		if (mainDc != null) {
			_hashCode = 29 * _hashCode + mainDc.hashCode();
		}
		
		if (bcRac != null) {
			_hashCode = 29 * _hashCode + bcRac.hashCode();
		}
		
		_hashCode = 29 * _hashCode + bcRacWgt;
		_hashCode = 29 * _hashCode + (bcRacWgtNull ? 1 : 0);
		if (bcRacRisk != null) {
			_hashCode = 29 * _hashCode + bcRacRisk.hashCode();
		}
		
		if (bcLocal != null) {
			_hashCode = 29 * _hashCode + bcLocal.hashCode();
		}
		
		_hashCode = 29 * _hashCode + bcLocalWgt;
		_hashCode = 29 * _hashCode + (bcLocalWgtNull ? 1 : 0);
		if (bcLocalRisk != null) {
			_hashCode = 29 * _hashCode + bcLocalRisk.hashCode();
		}
		
		if (bcRemote != null) {
			_hashCode = 29 * _hashCode + bcRemote.hashCode();
		}
		
		_hashCode = 29 * _hashCode + bcRemoteWgt;
		_hashCode = 29 * _hashCode + (bcRemoteWgtNull ? 1 : 0);
		if (bcRemoteRisk != null) {
			_hashCode = 29 * _hashCode + bcRemoteRisk.hashCode();
		}
		
		if (cntgncyPlan != null) {
			_hashCode = 29 * _hashCode + cntgncyPlan.hashCode();
		}
		
		_hashCode = 29 * _hashCode + cntgncyPlanWgt;
		_hashCode = 29 * _hashCode + (cntgncyPlanWgtNull ? 1 : 0);
		if (cntgncyPlanRisk != null) {
			_hashCode = 29 * _hashCode + cntgncyPlanRisk.hashCode();
		}
		
		if (drDoc != null) {
			_hashCode = 29 * _hashCode + drDoc.hashCode();
		}
		
		_hashCode = 29 * _hashCode + drDocWgt;
		_hashCode = 29 * _hashCode + (drDocWgtNull ? 1 : 0);
		if (drDocRisk != null) {
			_hashCode = 29 * _hashCode + drDocRisk.hashCode();
		}
		
		if (drArcher != null) {
			_hashCode = 29 * _hashCode + drArcher.hashCode();
		}
		
		_hashCode = 29 * _hashCode + drArcherWgt;
		_hashCode = 29 * _hashCode + (drArcherWgtNull ? 1 : 0);
		if (drArcherRisk != null) {
			_hashCode = 29 * _hashCode + drArcherRisk.hashCode();
		}
		
		if (drLastTestDt != null) {
			_hashCode = 29 * _hashCode + drLastTestDt.hashCode();
		}
		
		_hashCode = 29 * _hashCode + drLastTestDtWgt;
		_hashCode = 29 * _hashCode + (drLastTestDtWgtNull ? 1 : 0);
		if (drLastTestDtRisk != null) {
			_hashCode = 29 * _hashCode + drLastTestDtRisk.hashCode();
		}
		
		if (suppOc != null) {
			_hashCode = 29 * _hashCode + suppOc.hashCode();
		}
		
		_hashCode = 29 * _hashCode + suppOcWgt;
		_hashCode = 29 * _hashCode + (suppOcWgtNull ? 1 : 0);
		if (suppOcRisk != null) {
			_hashCode = 29 * _hashCode + suppOcRisk.hashCode();
		}
		
		if (suppStaff != null) {
			_hashCode = 29 * _hashCode + suppStaff.hashCode();
		}
		
		_hashCode = 29 * _hashCode + suppStaffWgt;
		_hashCode = 29 * _hashCode + (suppStaffWgtNull ? 1 : 0);
		if (suppStaffRisk != null) {
			_hashCode = 29 * _hashCode + suppStaffRisk.hashCode();
		}
		
		if (suppTrain != null) {
			_hashCode = 29 * _hashCode + suppTrain.hashCode();
		}
		
		_hashCode = 29 * _hashCode + suppTrainWgt;
		_hashCode = 29 * _hashCode + (suppTrainWgtNull ? 1 : 0);
		if (suppTrainRisk != null) {
			_hashCode = 29 * _hashCode + suppTrainRisk.hashCode();
		}
		
		if (suppTecbu != null) {
			_hashCode = 29 * _hashCode + suppTecbu.hashCode();
		}
		
		_hashCode = 29 * _hashCode + suppTecbuWgt;
		_hashCode = 29 * _hashCode + (suppTecbuWgtNull ? 1 : 0);
		if (suppTecbuRisk != null) {
			_hashCode = 29 * _hashCode + suppTecbuRisk.hashCode();
		}
		
		if (suppNi2 != null) {
			_hashCode = 29 * _hashCode + suppNi2.hashCode();
		}
		
		_hashCode = 29 * _hashCode + suppNi2Wgt;
		_hashCode = 29 * _hashCode + (suppNi2WgtNull ? 1 : 0);
		if (suppNi2Risk != null) {
			_hashCode = 29 * _hashCode + suppNi2Risk.hashCode();
		}
		
		if (comments != null) {
			_hashCode = 29 * _hashCode + comments.hashCode();
		}
		
		_hashCode = 29 * _hashCode + riskFactor;
		_hashCode = 29 * _hashCode + (riskFactorNull ? 1 : 0);
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		if (auditStatus != null) {
			_hashCode = 29 * _hashCode + auditStatus.hashCode();
		}
		
		if (lastUpdateDttm != null) {
			_hashCode = 29 * _hashCode + lastUpdateDttm.hashCode();
		}
		
		_hashCode = 29 * _hashCode + auditId;
		_hashCode = 29 * _hashCode + (auditIdNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrAuditsPk
	 */
	public PrAuditsPk createPk()
	{
		return new PrAuditsPk(cy, symEaiId, ni2AppId);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrAudits: " );
		ret.append( "cy=" + cy );
		ret.append( ", symEaiId=" + symEaiId );
		ret.append( ", ni2AppName=" + ni2AppName );
		ret.append( ", respMdPin=" + respMdPin );
		ret.append( ", respMgrPin=" + respMgrPin );
		ret.append( ", ni2Bi=" + ni2Bi );
		ret.append( ", eaiTier=" + eaiTier );
		ret.append( ", mainDc=" + mainDc );
		ret.append( ", bcRac=" + bcRac );
		ret.append( ", bcRacWgt=" + bcRacWgt );
		ret.append( ", bcRacRisk=" + bcRacRisk );
		ret.append( ", bcLocal=" + bcLocal );
		ret.append( ", bcLocalWgt=" + bcLocalWgt );
		ret.append( ", bcLocalRisk=" + bcLocalRisk );
		ret.append( ", bcRemote=" + bcRemote );
		ret.append( ", bcRemoteWgt=" + bcRemoteWgt );
		ret.append( ", bcRemoteRisk=" + bcRemoteRisk );
		ret.append( ", cntgncyPlan=" + cntgncyPlan );
		ret.append( ", cntgncyPlanWgt=" + cntgncyPlanWgt );
		ret.append( ", cntgncyPlanRisk=" + cntgncyPlanRisk );
		ret.append( ", drDoc=" + drDoc );
		ret.append( ", drDocWgt=" + drDocWgt );
		ret.append( ", drDocRisk=" + drDocRisk );
		ret.append( ", drArcher=" + drArcher );
		ret.append( ", drArcherWgt=" + drArcherWgt );
		ret.append( ", drArcherRisk=" + drArcherRisk );
		ret.append( ", drLastTestDt=" + drLastTestDt );
		ret.append( ", drLastTestDtWgt=" + drLastTestDtWgt );
		ret.append( ", drLastTestDtRisk=" + drLastTestDtRisk );
		ret.append( ", suppOc=" + suppOc );
		ret.append( ", suppOcWgt=" + suppOcWgt );
		ret.append( ", suppOcRisk=" + suppOcRisk );
		ret.append( ", suppStaff=" + suppStaff );
		ret.append( ", suppStaffWgt=" + suppStaffWgt );
		ret.append( ", suppStaffRisk=" + suppStaffRisk );
		ret.append( ", suppTrain=" + suppTrain );
		ret.append( ", suppTrainWgt=" + suppTrainWgt );
		ret.append( ", suppTrainRisk=" + suppTrainRisk );
		ret.append( ", suppTecbu=" + suppTecbu );
		ret.append( ", suppTecbuWgt=" + suppTecbuWgt );
		ret.append( ", suppTecbuRisk=" + suppTecbuRisk );
		ret.append( ", suppNi2=" + suppNi2 );
		ret.append( ", suppNi2Wgt=" + suppNi2Wgt );
		ret.append( ", suppNi2Risk=" + suppNi2Risk );
		ret.append( ", comments=" + comments );
		ret.append( ", riskFactor=" + riskFactor );
		ret.append( ", ni2AppId=" + ni2AppId );
		ret.append( ", auditStatus=" + auditStatus );
		ret.append( ", lastUpdateDttm=" + lastUpdateDttm );
		ret.append( ", auditId=" + auditId );
		return ret.toString();
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

}
