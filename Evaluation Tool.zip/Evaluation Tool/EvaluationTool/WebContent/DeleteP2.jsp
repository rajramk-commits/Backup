<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
</head>
<body>
	<%
	String qnId = request.getParameter("id");
	String res = DAO.deleteQnIDP2(qnId);
	System.out.println("DeleteP2 : qnId :"+qnId+",res :"+res);
	response.sendRedirect("ViewDelQuestionP2.jsp?status="+res);
	%>
</body>
</html>