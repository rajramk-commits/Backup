package com.fedex.emea.sabreReport.util;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class GraphUtil {
    public static HashMap<String, Integer> sortByValue(Map<String, Integer> hm)
    {
        List<Map.Entry<String, Integer> > list = new LinkedList<Map.Entry<String, Integer> >(hm.entrySet());
        
        Collections.sort(list, new Comparator<Map.Entry<String, Integer> >() {
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2)
            {
                return (o2.getValue()).compareTo(o1.getValue());
            }
        });
        
        HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
        for (Map.Entry<String, Integer> aa : list) {
            temp.put(aa.getKey(), aa.getValue());
        }
        return temp;
    }
    public static void main(String[] args)
    {
    	Map<String, Integer> alertTypeJMSData = new HashMap<>();
    	alertTypeJMSData.put("7", 7);
    	alertTypeJMSData.put("4", 4);
    	alertTypeJMSData.put("5", 5);
    	alertTypeJMSData.put("2", 2);
    	alertTypeJMSData.put("8", 8);
    	alertTypeJMSData.put("4.5", 4);
    	System.out.println(sortByValue(alertTypeJMSData));
    }
}
