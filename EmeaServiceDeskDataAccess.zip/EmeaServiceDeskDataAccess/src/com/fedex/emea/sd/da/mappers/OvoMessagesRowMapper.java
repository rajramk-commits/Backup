package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.OvoMessages;

/** * RowMapper is used by Spring to read a line from a database table
 *  * and to fill an instance of the class with the values */

public final class OvoMessagesRowMapper implements RowMapper {

	public Object mapRow(ResultSet rs, int arg1) throws SQLException {
		OvoMessages ovoMessages = new OvoMessages();
		
		ovoMessages.setOvoMessageId(rs.getString("OVOMESSAGEID"));
		ovoMessages.setOvoNode(rs.getString("OVONODE"));
		ovoMessages.setOvoAppGroup(rs.getString("OVOAPPGROUP"));
		ovoMessages.setOvoAppName(rs.getString("OVOAPPNAME"));
		ovoMessages.setOvoAppObject(rs.getString("OVOAPPOBJECT"));
		ovoMessages.setCreationTime(rs.getTimestamp("CREATIONTIME"));
		ovoMessages.setNexusCaseId(rs.getString("NEXUSCASEID"));
		
		return ovoMessages;
	}

}
