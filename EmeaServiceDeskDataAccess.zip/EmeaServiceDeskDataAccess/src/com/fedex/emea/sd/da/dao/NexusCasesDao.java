package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;

import com.fedex.emea.sd.da.objects.NexusCases;

public interface NexusCasesDao {
	public NexusCases createValueObject();
	public NexusCases getObject(int alertId) throws SQLException;
	public int countAll() throws SQLException;
	public int getCaseId(String caseSummary) throws SQLException;
}

