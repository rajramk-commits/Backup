package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowCmdbCiBusinessApp implements Serializable {

	private static final long serialVersionUID = -1662252340662507431L;
	
	private String snowActive;
	private String snowActiveUserCount;
	private String snowAge;
	private String snowApmBusinessProcess;
	private String snowApplicationManager;
	private String snowApplicationPortfolioManager;
	private String snowApplicationType;
	private String snowApplicationUrl;
	private String snowAppraisalFiscalType;
	private String snowArchitectureType;
	private String snowAsset;
	private String snowAssetTag;
	private String snowAssigned;
	private String snowAssignedTo;
	private String snowAssignmentGroup;
	private String snowAttributes;
	private String snowAudienceType;
	private String snowBusinessCriticality;
	private String snowBusinessProcess;
	private String snowCanPrint;
	private String snowCategory;
	private String snowCertified;
	private String snowChangeControl;
	private String snowCheckedIn;
	private String snowCheckedOut;
	private String snowCmdbSoftwareProductModel;
	private String snowComments;
	private String snowCompany;
	private String snowContractEndDate;
	private String snowCorrelationId;
	private String snowCost;
	private String snowCostCc;
	private String snowCreatedByQualys;
	private String snowCurrency;
	private String snowDataClassification;
	private String snowDeliveryDate;
	private String snowDepartment;
	private String snowDiscoverySource;
	private String snowDnsDomain;
	private String snowDue;
	private String snowDueIn;
	private String snowEmergencyTier;
	private String snowFaultCount;
	private String snowFirstDiscovered;
	private String snowFqdn;
	private String snowGlAccount;
	private String snowInstallDate;
	private String snowInstallStatus;
	private String snowInstallType;
	private String snowInvoiceNumber;
	private String snowIpAddress;
	private String snowItApplicationOwner;
	private String snowJustification;
	private String snowLastChangeAppliedDate;
	private String snowLastChangeDate;
	private String snowLastDiscovered;
	private String snowLeaseId;
	private String snowLicense;
	private String snowLocation;
	private String snowMacAddress;
	private String snowMaintenanceSchedule;
	private String snowManagedBy;
	private String snowManufacturer;
	private String snowModelId;
	private String snowModelNumber;
	private String snowMonitor;
	private String snowName;
	private String snowNextAssessmentDate;
	private String snowNumber;
	private String snowOperationalStatus;
	private String snowOrderDate;
	private String snowOrganizationUnitCount;
	private String snowOwnedBy;
	private String snowPlatform;
	private String snowPoNumber;
	private String snowProductSupportStatus;
	private String snowPurchaseDate;
	private String snowSchedule;
	private String snowScoreTrendFrequency;
	private String snowSerialNumber;
	private String snowShortDescription;
	private String snowSkipSync;
	private String snowSnVulQualysHostId;
	private String snowSnVulQualysHostTags;
	private String snowSnVulQualysId;
	private String snowSoftwareLicense;
	private String snowStartDate;
	private String snowSubcategory;
	private String snowSupportGroup;
	private String snowSupportVendor;
	private String snowSupportedBy;
	private String snowSysClassName;
	private String snowSysClassPath;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysDomain;
	private String snowSysDomainPath;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowTechnologyStack;
	private String snowU_Acronym;
	private String snowU_AppUse;
	private String snowU_ApplicationCategory;
	private String snowU_BusinessFunction;
	private String snowU_BusinessOwner;
	private String snowU_BusinessService;
	private String snowU_CategoryGroup;
	private String snowU_EaiId;
	private String snowU_EnterpriseService;
	private String snowU_EnterpriseServiceDesired;
	private String snowU_Environment;
	private String snowU_Function;
	private String snowU_Gateway;
	private String snowU_Gateways;
	private String snowU_Hippa;
	private String snowU_IdentifiedPrimaryUser;
	private String snowU_Imei;
	private String snowU_Imeis;
	private String snowU_ImpactedOpco;
	private String snowU_IntegrationId;
	private String snowU_IntegrationSource;
	private String snowU_ItLead;
	private String snowU_LastLoggedOnUser;
	private String snowU_LastPhysicallyInventoried;
	private String snowU_LastSeenInIntegrationSource;
	private String snowU_ManagingOpco;
	private String snowU_ManagingOpcos;
	private String snowU_Meids;
	private String snowU_OwningVp;
	private String snowU_PatchStatus;
	private String snowU_Pci;
	private String snowU_Pii;
	private String snowU_ProjectedDisposition;
	private String snowU_ProjectedDispositionDate;
	private String snowU_PublicFacing;
	private String snowU_RegulatoryRestriction;
	private String snowU_ServiceLevelClass;
	private String snowU_Sim;
	private String snowU_Sims;
	private String snowU_Sox;
	private String snowU_ThirdPartySupport;
	private String snowU_Version;
	private String snowUnverified;
	private String snowUrl;
	private String snowUserBase;
	private String snowVendor;
	private String snowWarrantyExpiration;
	private String snowWorkNotes;
	
	public SnowCmdbCiBusinessApp(HashMap<String, Object> jsonValues) {
		snowActive = SnowUtilities.getStringValueFromObject(jsonValues.get("active"));
		snowActiveUserCount = SnowUtilities.getStringValueFromObject(jsonValues.get("active_user_count"));
		snowAge = SnowUtilities.getStringValueFromObject(jsonValues.get("age"));
		snowApmBusinessProcess = SnowUtilities.getStringValueFromObject(jsonValues.get("apm_business_process"));
		snowApplicationManager = SnowUtilities.getStringValueFromObject(jsonValues.get("application_manager"));
		snowApplicationPortfolioManager = SnowUtilities.getStringValueFromObject(jsonValues.get("application_portfolio_manager"));
		snowApplicationType = SnowUtilities.getStringValueFromObject(jsonValues.get("application_type"));
		snowApplicationUrl = SnowUtilities.getStringValueFromObject(jsonValues.get("application_url"));
		snowAppraisalFiscalType = SnowUtilities.getStringValueFromObject(jsonValues.get("appraisal_fiscal_type"));
		snowArchitectureType = SnowUtilities.getStringValueFromObject(jsonValues.get("architecture_type"));
		snowAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("asset"));
		snowAssetTag = SnowUtilities.getStringValueFromObject(jsonValues.get("asset_tag"));
		snowAssigned = SnowUtilities.getStringValueFromObject(jsonValues.get("assigned"));
		snowAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("assigned_to"));
		snowAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("assignment_group"));
		snowAttributes = SnowUtilities.getStringValueFromObject(jsonValues.get("attributes"));
		snowAudienceType = SnowUtilities.getStringValueFromObject(jsonValues.get("audience_type"));
		snowBusinessCriticality = SnowUtilities.getStringValueFromObject(jsonValues.get("business_criticality"));
		snowBusinessProcess = SnowUtilities.getStringValueFromObject(jsonValues.get("business_process"));
		snowCanPrint = SnowUtilities.getStringValueFromObject(jsonValues.get("can_print"));
		snowCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("category"));
		snowCertified = SnowUtilities.getStringValueFromObject(jsonValues.get("certified"));
		snowChangeControl = SnowUtilities.getStringValueFromObject(jsonValues.get("change_control"));
		snowCheckedIn = SnowUtilities.getStringValueFromObject(jsonValues.get("checked_in"));
		snowCheckedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("checked_out"));
		snowCmdbSoftwareProductModel = SnowUtilities.getStringValueFromObject(jsonValues.get("cmdb_software_product_model"));
		snowComments = SnowUtilities.getStringValueFromObject(jsonValues.get("comments"));
		snowCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("company"));
		snowContractEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("contract_end_date"));
		snowCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("correlation_id"));
		snowCost = SnowUtilities.getStringValueFromObject(jsonValues.get("cost"));
		snowCostCc = SnowUtilities.getStringValueFromObject(jsonValues.get("cost_cc"));
		snowCreatedByQualys = SnowUtilities.getStringValueFromObject(jsonValues.get("created_by_qualys"));
		snowCurrency = SnowUtilities.getStringValueFromObject(jsonValues.get("currency"));
		snowDataClassification = SnowUtilities.getStringValueFromObject(jsonValues.get("data_classification"));
		snowDeliveryDate = SnowUtilities.getStringValueFromObject(jsonValues.get("delivery_date"));
		snowDepartment = SnowUtilities.getStringValueFromObject(jsonValues.get("department"));
		snowDiscoverySource = SnowUtilities.getStringValueFromObject(jsonValues.get("discovery_source"));
		snowDnsDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("dns_domain"));
		snowDue = SnowUtilities.getStringValueFromObject(jsonValues.get("due"));
		snowDueIn = SnowUtilities.getStringValueFromObject(jsonValues.get("due_in"));
		snowEmergencyTier = SnowUtilities.getStringValueFromObject(jsonValues.get("emergency_tier"));
		snowFaultCount = SnowUtilities.getStringValueFromObject(jsonValues.get("fault_count"));
		snowFirstDiscovered = SnowUtilities.getStringValueFromObject(jsonValues.get("first_discovered"));
		snowFqdn = SnowUtilities.getStringValueFromObject(jsonValues.get("fqdn"));
		snowGlAccount = SnowUtilities.getStringValueFromObject(jsonValues.get("gl_account"));
		snowInstallDate = SnowUtilities.getStringValueFromObject(jsonValues.get("install_date"));
		snowInstallStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("install_status"));
		snowInstallType = SnowUtilities.getStringValueFromObject(jsonValues.get("install_type"));
		snowInvoiceNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("invoice_number"));
		snowIpAddress = SnowUtilities.getStringValueFromObject(jsonValues.get("ip_address"));
		snowItApplicationOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("it_application_owner"));
		snowJustification = SnowUtilities.getStringValueFromObject(jsonValues.get("justification"));
		snowLastChangeAppliedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("last_change_applied_date"));
		snowLastChangeDate = SnowUtilities.getStringValueFromObject(jsonValues.get("last_change_date"));
		snowLastDiscovered = SnowUtilities.getStringValueFromObject(jsonValues.get("last_discovered"));
		snowLeaseId = SnowUtilities.getStringValueFromObject(jsonValues.get("lease_id"));
		snowLicense = SnowUtilities.getStringValueFromObject(jsonValues.get("license"));
		snowLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("location"));
		snowMacAddress = SnowUtilities.getStringValueFromObject(jsonValues.get("mac_address"));
		snowMaintenanceSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("maintenance_schedule"));
		snowManagedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("managed_by"));
		snowManufacturer = SnowUtilities.getStringValueFromObject(jsonValues.get("manufacturer"));
		snowModelId = SnowUtilities.getStringValueFromObject(jsonValues.get("model_id"));
		snowModelNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("model_number"));
		snowMonitor = SnowUtilities.getStringValueFromObject(jsonValues.get("monitor"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowNextAssessmentDate = SnowUtilities.getStringValueFromObject(jsonValues.get("next_assessment_date"));
		snowNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("number"));
		snowOperationalStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("operational_status"));
		snowOrderDate = SnowUtilities.getStringValueFromObject(jsonValues.get("order_date"));
		snowOrganizationUnitCount = SnowUtilities.getStringValueFromObject(jsonValues.get("organization_unit_count"));
		snowOwnedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("owned_by"));
		snowPlatform = SnowUtilities.getStringValueFromObject(jsonValues.get("platform"));
		snowPoNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("po_number"));
		snowProductSupportStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("product_support_status"));
		snowPurchaseDate = SnowUtilities.getStringValueFromObject(jsonValues.get("purchase_date"));
		snowSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("schedule"));
		snowScoreTrendFrequency = SnowUtilities.getStringValueFromObject(jsonValues.get("score_trend_frequency"));
		snowSerialNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("serial_number"));
		snowShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("short_description"));
		snowSkipSync = SnowUtilities.getStringValueFromObject(jsonValues.get("skip_sync"));
		snowSnVulQualysHostId = SnowUtilities.getStringValueFromObject(jsonValues.get("sn_vul_qualys_host_id"));
		snowSnVulQualysHostTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sn_vul_qualys_host_tags"));
		snowSnVulQualysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sn_vul_qualys_id"));
		snowSoftwareLicense = SnowUtilities.getStringValueFromObject(jsonValues.get("software_license"));
		snowStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("start_date"));
		snowSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("subcategory"));
		snowSupportGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("support_group"));
		snowSupportVendor = SnowUtilities.getStringValueFromObject(jsonValues.get("support_vendor"));
		snowSupportedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("supported_by"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysClassPath = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_path"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain"));
		snowSysDomainPath = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain_path"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowTechnologyStack = SnowUtilities.getStringValueFromObject(jsonValues.get("technology_stack"));
		snowU_Acronym = SnowUtilities.getStringValueFromObject(jsonValues.get("u_acronym"));
		snowU_AppUse = SnowUtilities.getStringValueFromObject(jsonValues.get("u_app_use"));
		snowU_ApplicationCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_application_category"));
		snowU_BusinessFunction = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_function"));
		snowU_BusinessOwner = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_owner"));
		snowU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_service"));
		snowU_CategoryGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_category_group"));
		snowU_EaiId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_eai_id"));
		snowU_EnterpriseService = SnowUtilities.getStringValueFromObject(jsonValues.get("u_enterprise_service"));
		snowU_EnterpriseServiceDesired = SnowUtilities.getStringValueFromObject(jsonValues.get("u_enterprise_service_desired"));
		snowU_Environment = SnowUtilities.getStringValueFromObject(jsonValues.get("u_environment"));
		snowU_Function = SnowUtilities.getStringValueFromObject(jsonValues.get("u_function"));
		snowU_Gateway = SnowUtilities.getStringValueFromObject(jsonValues.get("u_gateway"));
		snowU_Gateways = SnowUtilities.getStringValueFromObject(jsonValues.get("u_gateways"));
		snowU_Hippa = SnowUtilities.getStringValueFromObject(jsonValues.get("u_hippa"));
		snowU_IdentifiedPrimaryUser = SnowUtilities.getStringValueFromObject(jsonValues.get("u_identified_primary_user"));
		snowU_Imei = SnowUtilities.getStringValueFromObject(jsonValues.get("u_imei"));
		snowU_Imeis = SnowUtilities.getStringValueFromObject(jsonValues.get("u_imeis"));
		snowU_ImpactedOpco = SnowUtilities.getStringValueFromObject(jsonValues.get("u_impacted_opco"));
		snowU_IntegrationId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_integration_id"));
		snowU_IntegrationSource = SnowUtilities.getStringValueFromObject(jsonValues.get("u_integration_source"));
		snowU_ItLead = SnowUtilities.getStringValueFromObject(jsonValues.get("u_it_lead"));
		snowU_LastLoggedOnUser = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_logged_on_user"));
		snowU_LastPhysicallyInventoried = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_physically_inventoried"));
		snowU_LastSeenInIntegrationSource = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_seen_in_integration_source"));
		snowU_ManagingOpco = SnowUtilities.getStringValueFromObject(jsonValues.get("u_managing_opco"));
		snowU_ManagingOpcos = SnowUtilities.getStringValueFromObject(jsonValues.get("u_managing_opcos"));
		snowU_Meids = SnowUtilities.getStringValueFromObject(jsonValues.get("u_meids"));
		snowU_OwningVp = SnowUtilities.getStringValueFromObject(jsonValues.get("u_owning_vp"));
		snowU_PatchStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_patch_status"));
		snowU_Pci = SnowUtilities.getStringValueFromObject(jsonValues.get("u_pci"));
		snowU_Pii = SnowUtilities.getStringValueFromObject(jsonValues.get("u_pii"));
		snowU_ProjectedDisposition = SnowUtilities.getStringValueFromObject(jsonValues.get("u_projected_disposition"));
		snowU_ProjectedDispositionDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_projected_disposition_date"));
		snowU_PublicFacing = SnowUtilities.getStringValueFromObject(jsonValues.get("u_public_facing"));
		snowU_RegulatoryRestriction = SnowUtilities.getStringValueFromObject(jsonValues.get("u_regulatory_restriction"));
		snowU_ServiceLevelClass = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service_level_class"));
		snowU_Sim = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sim"));
		snowU_Sims = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sims"));
		snowU_Sox = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sox"));
		snowU_ThirdPartySupport = SnowUtilities.getStringValueFromObject(jsonValues.get("u_third_party_support"));
		snowU_Version = SnowUtilities.getStringValueFromObject(jsonValues.get("u_version"));
		snowUnverified = SnowUtilities.getStringValueFromObject(jsonValues.get("unverified"));
		snowUrl = SnowUtilities.getStringValueFromObject(jsonValues.get("url"));
		snowUserBase = SnowUtilities.getStringValueFromObject(jsonValues.get("user_base"));
		snowVendor = SnowUtilities.getStringValueFromObject(jsonValues.get("vendor"));
		snowWarrantyExpiration = SnowUtilities.getStringValueFromObject(jsonValues.get("warranty_expiration"));
		snowWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("work_notes"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (snowActive != null && !snowActive.toString().isEmpty()) jsonObject.put("active", snowActive);
		if (snowActiveUserCount != null && !snowActiveUserCount.toString().isEmpty()) jsonObject.put("active_user_count", snowActiveUserCount);
		if (snowAge != null && !snowAge.toString().isEmpty()) jsonObject.put("age", snowAge);
		if (snowApmBusinessProcess != null && !snowApmBusinessProcess.toString().isEmpty()) jsonObject.put("apm_business_process", snowApmBusinessProcess);
		if (snowApplicationManager != null && !snowApplicationManager.toString().isEmpty()) jsonObject.put("application_manager", snowApplicationManager);
		if (snowApplicationPortfolioManager != null && !snowApplicationPortfolioManager.toString().isEmpty()) jsonObject.put("application_portfolio_manager", snowApplicationPortfolioManager);
		if (snowApplicationType != null && !snowApplicationType.toString().isEmpty()) jsonObject.put("application_type", snowApplicationType);
		if (snowApplicationUrl != null && !snowApplicationUrl.toString().isEmpty()) jsonObject.put("application_url", snowApplicationUrl);
		if (snowAppraisalFiscalType != null && !snowAppraisalFiscalType.toString().isEmpty()) jsonObject.put("appraisal_fiscal_type", snowAppraisalFiscalType);
		if (snowArchitectureType != null && !snowArchitectureType.toString().isEmpty()) jsonObject.put("architecture_type", snowArchitectureType);
		if (snowAsset != null && !snowAsset.toString().isEmpty()) jsonObject.put("asset", snowAsset);
		if (snowAssetTag != null && !snowAssetTag.toString().isEmpty()) jsonObject.put("asset_tag", snowAssetTag);
		if (snowAssigned != null && !snowAssigned.toString().isEmpty()) jsonObject.put("assigned", snowAssigned);
		if (snowAssignedTo != null && !snowAssignedTo.toString().isEmpty()) jsonObject.put("assigned_to", snowAssignedTo);
		if (snowAssignmentGroup != null && !snowAssignmentGroup.toString().isEmpty()) jsonObject.put("assignment_group", snowAssignmentGroup);
		if (snowAttributes != null && !snowAttributes.toString().isEmpty()) jsonObject.put("attributes", snowAttributes);
		if (snowAudienceType != null && !snowAudienceType.toString().isEmpty()) jsonObject.put("audience_type", snowAudienceType);
		if (snowBusinessCriticality != null && !snowBusinessCriticality.toString().isEmpty()) jsonObject.put("business_criticality", snowBusinessCriticality);
		if (snowBusinessProcess != null && !snowBusinessProcess.toString().isEmpty()) jsonObject.put("business_process", snowBusinessProcess);
		if (snowCanPrint != null && !snowCanPrint.toString().isEmpty()) jsonObject.put("can_print", snowCanPrint);
		if (snowCategory != null && !snowCategory.toString().isEmpty()) jsonObject.put("category", snowCategory);
		if (snowCertified != null && !snowCertified.toString().isEmpty()) jsonObject.put("certified", snowCertified);
		if (snowChangeControl != null && !snowChangeControl.toString().isEmpty()) jsonObject.put("change_control", snowChangeControl);
		if (snowCheckedIn != null && !snowCheckedIn.toString().isEmpty()) jsonObject.put("checked_in", snowCheckedIn);
		if (snowCheckedOut != null && !snowCheckedOut.toString().isEmpty()) jsonObject.put("checked_out", snowCheckedOut);
		if (snowCmdbSoftwareProductModel != null && !snowCmdbSoftwareProductModel.toString().isEmpty()) jsonObject.put("cmdb_software_product_model", snowCmdbSoftwareProductModel);
		if (snowComments != null && !snowComments.toString().isEmpty()) jsonObject.put("comments", snowComments);
		if (snowCompany != null && !snowCompany.toString().isEmpty()) jsonObject.put("company", snowCompany);
		if (snowContractEndDate != null && !snowContractEndDate.toString().isEmpty()) jsonObject.put("contract_end_date", snowContractEndDate);
		if (snowCorrelationId != null && !snowCorrelationId.toString().isEmpty()) jsonObject.put("correlation_id", snowCorrelationId);
		if (snowCost != null && !snowCost.toString().isEmpty()) jsonObject.put("cost", snowCost);
		if (snowCostCc != null && !snowCostCc.toString().isEmpty()) jsonObject.put("cost_cc", snowCostCc);
		if (snowCreatedByQualys != null && !snowCreatedByQualys.toString().isEmpty()) jsonObject.put("created_by_qualys", snowCreatedByQualys);
		if (snowCurrency != null && !snowCurrency.toString().isEmpty()) jsonObject.put("currency", snowCurrency);
		if (snowDataClassification != null && !snowDataClassification.toString().isEmpty()) jsonObject.put("data_classification", snowDataClassification);
		if (snowDeliveryDate != null && !snowDeliveryDate.toString().isEmpty()) jsonObject.put("delivery_date", snowDeliveryDate);
		if (snowDepartment != null && !snowDepartment.toString().isEmpty()) jsonObject.put("department", snowDepartment);
		if (snowDiscoverySource != null && !snowDiscoverySource.toString().isEmpty()) jsonObject.put("discovery_source", snowDiscoverySource);
		if (snowDnsDomain != null && !snowDnsDomain.toString().isEmpty()) jsonObject.put("dns_domain", snowDnsDomain);
		if (snowDue != null && !snowDue.toString().isEmpty()) jsonObject.put("due", snowDue);
		if (snowDueIn != null && !snowDueIn.toString().isEmpty()) jsonObject.put("due_in", snowDueIn);
		if (snowEmergencyTier != null && !snowEmergencyTier.toString().isEmpty()) jsonObject.put("emergency_tier", snowEmergencyTier);
		if (snowFaultCount != null && !snowFaultCount.toString().isEmpty()) jsonObject.put("fault_count", snowFaultCount);
		if (snowFirstDiscovered != null && !snowFirstDiscovered.toString().isEmpty()) jsonObject.put("first_discovered", snowFirstDiscovered);
		if (snowFqdn != null && !snowFqdn.toString().isEmpty()) jsonObject.put("fqdn", snowFqdn);
		if (snowGlAccount != null && !snowGlAccount.toString().isEmpty()) jsonObject.put("gl_account", snowGlAccount);
		if (snowInstallDate != null && !snowInstallDate.toString().isEmpty()) jsonObject.put("install_date", snowInstallDate);
		if (snowInstallStatus != null && !snowInstallStatus.toString().isEmpty()) jsonObject.put("install_status", snowInstallStatus);
		if (snowInstallType != null && !snowInstallType.toString().isEmpty()) jsonObject.put("install_type", snowInstallType);
		if (snowInvoiceNumber != null && !snowInvoiceNumber.toString().isEmpty()) jsonObject.put("invoice_number", snowInvoiceNumber);
		if (snowIpAddress != null && !snowIpAddress.toString().isEmpty()) jsonObject.put("ip_address", snowIpAddress);
		if (snowItApplicationOwner != null && !snowItApplicationOwner.toString().isEmpty()) jsonObject.put("it_application_owner", snowItApplicationOwner);
		if (snowJustification != null && !snowJustification.toString().isEmpty()) jsonObject.put("justification", snowJustification);
		if (snowLastChangeAppliedDate != null && !snowLastChangeAppliedDate.toString().isEmpty()) jsonObject.put("last_change_applied_date", snowLastChangeAppliedDate);
		if (snowLastChangeDate != null && !snowLastChangeDate.toString().isEmpty()) jsonObject.put("last_change_date", snowLastChangeDate);
		if (snowLastDiscovered != null && !snowLastDiscovered.toString().isEmpty()) jsonObject.put("last_discovered", snowLastDiscovered);
		if (snowLeaseId != null && !snowLeaseId.toString().isEmpty()) jsonObject.put("lease_id", snowLeaseId);
		if (snowLicense != null && !snowLicense.toString().isEmpty()) jsonObject.put("license", snowLicense);
		if (snowLocation != null && !snowLocation.toString().isEmpty()) jsonObject.put("location", snowLocation);
		if (snowMacAddress != null && !snowMacAddress.toString().isEmpty()) jsonObject.put("mac_address", snowMacAddress);
		if (snowMaintenanceSchedule != null && !snowMaintenanceSchedule.toString().isEmpty()) jsonObject.put("maintenance_schedule", snowMaintenanceSchedule);
		if (snowManagedBy != null && !snowManagedBy.toString().isEmpty()) jsonObject.put("managed_by", snowManagedBy);
		if (snowManufacturer != null && !snowManufacturer.toString().isEmpty()) jsonObject.put("manufacturer", snowManufacturer);
		if (snowModelId != null && !snowModelId.toString().isEmpty()) jsonObject.put("model_id", snowModelId);
		if (snowModelNumber != null && !snowModelNumber.toString().isEmpty()) jsonObject.put("model_number", snowModelNumber);
		if (snowMonitor != null && !snowMonitor.toString().isEmpty()) jsonObject.put("monitor", snowMonitor);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowNextAssessmentDate != null && !snowNextAssessmentDate.toString().isEmpty()) jsonObject.put("next_assessment_date", snowNextAssessmentDate);
		if (snowNumber != null && !snowNumber.toString().isEmpty()) jsonObject.put("number", snowNumber);
		if (snowOperationalStatus != null && !snowOperationalStatus.toString().isEmpty()) jsonObject.put("operational_status", snowOperationalStatus);
		if (snowOrderDate != null && !snowOrderDate.toString().isEmpty()) jsonObject.put("order_date", snowOrderDate);
		if (snowOrganizationUnitCount != null && !snowOrganizationUnitCount.toString().isEmpty()) jsonObject.put("organization_unit_count", snowOrganizationUnitCount);
		if (snowOwnedBy != null && !snowOwnedBy.toString().isEmpty()) jsonObject.put("owned_by", snowOwnedBy);
		if (snowPlatform != null && !snowPlatform.toString().isEmpty()) jsonObject.put("platform", snowPlatform);
		if (snowPoNumber != null && !snowPoNumber.toString().isEmpty()) jsonObject.put("po_number", snowPoNumber);
		if (snowProductSupportStatus != null && !snowProductSupportStatus.toString().isEmpty()) jsonObject.put("product_support_status", snowProductSupportStatus);
		if (snowPurchaseDate != null && !snowPurchaseDate.toString().isEmpty()) jsonObject.put("purchase_date", snowPurchaseDate);
		if (snowSchedule != null && !snowSchedule.toString().isEmpty()) jsonObject.put("schedule", snowSchedule);
		if (snowScoreTrendFrequency != null && !snowScoreTrendFrequency.toString().isEmpty()) jsonObject.put("score_trend_frequency", snowScoreTrendFrequency);
		if (snowSerialNumber != null && !snowSerialNumber.toString().isEmpty()) jsonObject.put("serial_number", snowSerialNumber);
		if (snowShortDescription != null && !snowShortDescription.toString().isEmpty()) jsonObject.put("short_description", snowShortDescription);
		if (snowSkipSync != null && !snowSkipSync.toString().isEmpty()) jsonObject.put("skip_sync", snowSkipSync);
		if (snowSnVulQualysHostId != null && !snowSnVulQualysHostId.toString().isEmpty()) jsonObject.put("sn_vul_qualys_host_id", snowSnVulQualysHostId);
		if (snowSnVulQualysHostTags != null && !snowSnVulQualysHostTags.toString().isEmpty()) jsonObject.put("sn_vul_qualys_host_tags", snowSnVulQualysHostTags);
		if (snowSnVulQualysId != null && !snowSnVulQualysId.toString().isEmpty()) jsonObject.put("sn_vul_qualys_id", snowSnVulQualysId);
		if (snowSoftwareLicense != null && !snowSoftwareLicense.toString().isEmpty()) jsonObject.put("software_license", snowSoftwareLicense);
		if (snowStartDate != null && !snowStartDate.toString().isEmpty()) jsonObject.put("start_date", snowStartDate);
		if (snowSubcategory != null && !snowSubcategory.toString().isEmpty()) jsonObject.put("subcategory", snowSubcategory);
		if (snowSupportGroup != null && !snowSupportGroup.toString().isEmpty()) jsonObject.put("support_group", snowSupportGroup);
		if (snowSupportVendor != null && !snowSupportVendor.toString().isEmpty()) jsonObject.put("support_vendor", snowSupportVendor);
		if (snowSupportedBy != null && !snowSupportedBy.toString().isEmpty()) jsonObject.put("supported_by", snowSupportedBy);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysClassPath != null && !snowSysClassPath.toString().isEmpty()) jsonObject.put("sys_class_path", snowSysClassPath);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysDomain != null && !snowSysDomain.toString().isEmpty()) jsonObject.put("sys_domain", snowSysDomain);
		if (snowSysDomainPath != null && !snowSysDomainPath.toString().isEmpty()) jsonObject.put("sys_domain_path", snowSysDomainPath);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowTechnologyStack != null && !snowTechnologyStack.toString().isEmpty()) jsonObject.put("technology_stack", snowTechnologyStack);
		if (snowU_Acronym != null && !snowU_Acronym.toString().isEmpty()) jsonObject.put("u_acronym", snowU_Acronym);
		if (snowU_AppUse != null && !snowU_AppUse.toString().isEmpty()) jsonObject.put("u_app_use", snowU_AppUse);
		if (snowU_ApplicationCategory != null && !snowU_ApplicationCategory.toString().isEmpty()) jsonObject.put("u_application_category", snowU_ApplicationCategory);
		if (snowU_BusinessFunction != null && !snowU_BusinessFunction.toString().isEmpty()) jsonObject.put("u_business_function", snowU_BusinessFunction);
		if (snowU_BusinessOwner != null && !snowU_BusinessOwner.toString().isEmpty()) jsonObject.put("u_business_owner", snowU_BusinessOwner);
		if (snowU_BusinessService != null && !snowU_BusinessService.toString().isEmpty()) jsonObject.put("u_business_service", snowU_BusinessService);
		if (snowU_CategoryGroup != null && !snowU_CategoryGroup.toString().isEmpty()) jsonObject.put("u_category_group", snowU_CategoryGroup);
		if (snowU_EaiId != null && !snowU_EaiId.toString().isEmpty()) jsonObject.put("u_eai_id", snowU_EaiId);
		if (snowU_EnterpriseService != null && !snowU_EnterpriseService.toString().isEmpty()) jsonObject.put("u_enterprise_service", snowU_EnterpriseService);
		if (snowU_EnterpriseServiceDesired != null && !snowU_EnterpriseServiceDesired.toString().isEmpty()) jsonObject.put("u_enterprise_service_desired", snowU_EnterpriseServiceDesired);
		if (snowU_Environment != null && !snowU_Environment.toString().isEmpty()) jsonObject.put("u_environment", snowU_Environment);
		if (snowU_Function != null && !snowU_Function.toString().isEmpty()) jsonObject.put("u_function", snowU_Function);
		if (snowU_Gateway != null && !snowU_Gateway.toString().isEmpty()) jsonObject.put("u_gateway", snowU_Gateway);
		if (snowU_Gateways != null && !snowU_Gateways.toString().isEmpty()) jsonObject.put("u_gateways", snowU_Gateways);
		if (snowU_Hippa != null && !snowU_Hippa.toString().isEmpty()) jsonObject.put("u_hippa", snowU_Hippa);
		if (snowU_IdentifiedPrimaryUser != null && !snowU_IdentifiedPrimaryUser.toString().isEmpty()) jsonObject.put("u_identified_primary_user", snowU_IdentifiedPrimaryUser);
		if (snowU_Imei != null && !snowU_Imei.toString().isEmpty()) jsonObject.put("u_imei", snowU_Imei);
		if (snowU_Imeis != null && !snowU_Imeis.toString().isEmpty()) jsonObject.put("u_imeis", snowU_Imeis);
		if (snowU_ImpactedOpco != null && !snowU_ImpactedOpco.toString().isEmpty()) jsonObject.put("u_impacted_opco", snowU_ImpactedOpco);
		if (snowU_IntegrationId != null && !snowU_IntegrationId.toString().isEmpty()) jsonObject.put("u_integration_id", snowU_IntegrationId);
		if (snowU_IntegrationSource != null && !snowU_IntegrationSource.toString().isEmpty()) jsonObject.put("u_integration_source", snowU_IntegrationSource);
		if (snowU_ItLead != null && !snowU_ItLead.toString().isEmpty()) jsonObject.put("u_it_lead", snowU_ItLead);
		if (snowU_LastLoggedOnUser != null && !snowU_LastLoggedOnUser.toString().isEmpty()) jsonObject.put("u_last_logged_on_user", snowU_LastLoggedOnUser);
		if (snowU_LastPhysicallyInventoried != null && !snowU_LastPhysicallyInventoried.toString().isEmpty()) jsonObject.put("u_last_physically_inventoried", snowU_LastPhysicallyInventoried);
		if (snowU_LastSeenInIntegrationSource != null && !snowU_LastSeenInIntegrationSource.toString().isEmpty()) jsonObject.put("u_last_seen_in_integration_source", snowU_LastSeenInIntegrationSource);
		if (snowU_ManagingOpco != null && !snowU_ManagingOpco.toString().isEmpty()) jsonObject.put("u_managing_opco", snowU_ManagingOpco);
		if (snowU_ManagingOpcos != null && !snowU_ManagingOpcos.toString().isEmpty()) jsonObject.put("u_managing_opcos", snowU_ManagingOpcos);
		if (snowU_Meids != null && !snowU_Meids.toString().isEmpty()) jsonObject.put("u_meids", snowU_Meids);
		if (snowU_OwningVp != null && !snowU_OwningVp.toString().isEmpty()) jsonObject.put("u_owning_vp", snowU_OwningVp);
		if (snowU_PatchStatus != null && !snowU_PatchStatus.toString().isEmpty()) jsonObject.put("u_patch_status", snowU_PatchStatus);
		if (snowU_Pci != null && !snowU_Pci.toString().isEmpty()) jsonObject.put("u_pci", snowU_Pci);
		if (snowU_Pii != null && !snowU_Pii.toString().isEmpty()) jsonObject.put("u_pii", snowU_Pii);
		if (snowU_ProjectedDisposition != null && !snowU_ProjectedDisposition.toString().isEmpty()) jsonObject.put("u_projected_disposition", snowU_ProjectedDisposition);
		if (snowU_ProjectedDispositionDate != null && !snowU_ProjectedDispositionDate.toString().isEmpty()) jsonObject.put("u_projected_disposition_date", snowU_ProjectedDispositionDate);
		if (snowU_PublicFacing != null && !snowU_PublicFacing.toString().isEmpty()) jsonObject.put("u_public_facing", snowU_PublicFacing);
		if (snowU_RegulatoryRestriction != null && !snowU_RegulatoryRestriction.toString().isEmpty()) jsonObject.put("u_regulatory_restriction", snowU_RegulatoryRestriction);
		if (snowU_ServiceLevelClass != null && !snowU_ServiceLevelClass.toString().isEmpty()) jsonObject.put("u_service_level_class", snowU_ServiceLevelClass);
		if (snowU_Sim != null && !snowU_Sim.toString().isEmpty()) jsonObject.put("u_sim", snowU_Sim);
		if (snowU_Sims != null && !snowU_Sims.toString().isEmpty()) jsonObject.put("u_sims", snowU_Sims);
		if (snowU_Sox != null && !snowU_Sox.toString().isEmpty()) jsonObject.put("u_sox", snowU_Sox);
		if (snowU_ThirdPartySupport != null && !snowU_ThirdPartySupport.toString().isEmpty()) jsonObject.put("u_third_party_support", snowU_ThirdPartySupport);
		if (snowU_Version != null && !snowU_Version.toString().isEmpty()) jsonObject.put("u_version", snowU_Version);
		if (snowUnverified != null && !snowUnverified.toString().isEmpty()) jsonObject.put("unverified", snowUnverified);
		if (snowUrl != null && !snowUrl.toString().isEmpty()) jsonObject.put("url", snowUrl);
		if (snowUserBase != null && !snowUserBase.toString().isEmpty()) jsonObject.put("user_base", snowUserBase);
		if (snowVendor != null && !snowVendor.toString().isEmpty()) jsonObject.put("vendor", snowVendor);
		if (snowWarrantyExpiration != null && !snowWarrantyExpiration.toString().isEmpty()) jsonObject.put("warranty_expiration", snowWarrantyExpiration);
		if (snowWorkNotes != null && !snowWorkNotes.toString().isEmpty()) jsonObject.put("work_notes", snowWorkNotes);
		
		return jsonObject;
	}
	

	public String getSnowActive() {
		return snowActive;
	}

	public void setSnowActive(String snowActive) {
		this.snowActive = snowActive;
	}

	public String getSnowActiveUserCount() {
		return snowActiveUserCount;
	}

	public void setSnowActiveUserCount(String snowActiveUserCount) {
		this.snowActiveUserCount = snowActiveUserCount;
	}

	public String getSnowAge() {
		return snowAge;
	}

	public void setSnowAge(String snowAge) {
		this.snowAge = snowAge;
	}

	public String getSnowApmBusinessProcess() {
		return snowApmBusinessProcess;
	}

	public void setSnowApmBusinessProcess(String snowApmBusinessProcess) {
		this.snowApmBusinessProcess = snowApmBusinessProcess;
	}

	public String getSnowApplicationManager() {
		return snowApplicationManager;
	}

	public void setSnowApplicationManager(String snowApplicationManager) {
		this.snowApplicationManager = snowApplicationManager;
	}

	public String getSnowApplicationPortfolioManager() {
		return snowApplicationPortfolioManager;
	}

	public void setSnowApplicationPortfolioManager(String snowApplicationPortfolioManager) {
		this.snowApplicationPortfolioManager = snowApplicationPortfolioManager;
	}

	public String getSnowApplicationType() {
		return snowApplicationType;
	}

	public void setSnowApplicationType(String snowApplicationType) {
		this.snowApplicationType = snowApplicationType;
	}

	public String getSnowApplicationUrl() {
		return snowApplicationUrl;
	}

	public void setSnowApplicationUrl(String snowApplicationUrl) {
		this.snowApplicationUrl = snowApplicationUrl;
	}

	public String getSnowAppraisalFiscalType() {
		return snowAppraisalFiscalType;
	}

	public void setSnowAppraisalFiscalType(String snowAppraisalFiscalType) {
		this.snowAppraisalFiscalType = snowAppraisalFiscalType;
	}

	public String getSnowArchitectureType() {
		return snowArchitectureType;
	}

	public void setSnowArchitectureType(String snowArchitectureType) {
		this.snowArchitectureType = snowArchitectureType;
	}

	public String getSnowAsset() {
		return snowAsset;
	}

	public void setSnowAsset(String snowAsset) {
		this.snowAsset = snowAsset;
	}

	public String getSnowAssetTag() {
		return snowAssetTag;
	}

	public void setSnowAssetTag(String snowAssetTag) {
		this.snowAssetTag = snowAssetTag;
	}

	public String getSnowAssigned() {
		return snowAssigned;
	}

	public void setSnowAssigned(String snowAssigned) {
		this.snowAssigned = snowAssigned;
	}

	public String getSnowAssignedTo() {
		return snowAssignedTo;
	}

	public void setSnowAssignedTo(String snowAssignedTo) {
		this.snowAssignedTo = snowAssignedTo;
	}

	public String getSnowAssignmentGroup() {
		return snowAssignmentGroup;
	}

	public void setSnowAssignmentGroup(String snowAssignmentGroup) {
		this.snowAssignmentGroup = snowAssignmentGroup;
	}

	public String getSnowAttributes() {
		return snowAttributes;
	}

	public void setSnowAttributes(String snowAttributes) {
		this.snowAttributes = snowAttributes;
	}

	public String getSnowAudienceType() {
		return snowAudienceType;
	}

	public void setSnowAudienceType(String snowAudienceType) {
		this.snowAudienceType = snowAudienceType;
	}

	public String getSnowBusinessCriticality() {
		return snowBusinessCriticality;
	}

	public void setSnowBusinessCriticality(String snowBusinessCriticality) {
		this.snowBusinessCriticality = snowBusinessCriticality;
	}

	public String getSnowBusinessProcess() {
		return snowBusinessProcess;
	}

	public void setSnowBusinessProcess(String snowBusinessProcess) {
		this.snowBusinessProcess = snowBusinessProcess;
	}

	public String getSnowCanPrint() {
		return snowCanPrint;
	}

	public void setSnowCanPrint(String snowCanPrint) {
		this.snowCanPrint = snowCanPrint;
	}

	public String getSnowCategory() {
		return snowCategory;
	}

	public void setSnowCategory(String snowCategory) {
		this.snowCategory = snowCategory;
	}

	public String getSnowCertified() {
		return snowCertified;
	}

	public void setSnowCertified(String snowCertified) {
		this.snowCertified = snowCertified;
	}

	public String getSnowChangeControl() {
		return snowChangeControl;
	}

	public void setSnowChangeControl(String snowChangeControl) {
		this.snowChangeControl = snowChangeControl;
	}

	public String getSnowCheckedIn() {
		return snowCheckedIn;
	}

	public void setSnowCheckedIn(String snowCheckedIn) {
		this.snowCheckedIn = snowCheckedIn;
	}

	public String getSnowCheckedOut() {
		return snowCheckedOut;
	}

	public void setSnowCheckedOut(String snowCheckedOut) {
		this.snowCheckedOut = snowCheckedOut;
	}

	public String getSnowCmdbSoftwareProductModel() {
		return snowCmdbSoftwareProductModel;
	}

	public void setSnowCmdbSoftwareProductModel(String snowCmdbSoftwareProductModel) {
		this.snowCmdbSoftwareProductModel = snowCmdbSoftwareProductModel;
	}

	public String getSnowComments() {
		return snowComments;
	}

	public void setSnowComments(String snowComments) {
		this.snowComments = snowComments;
	}

	public String getSnowCompany() {
		return snowCompany;
	}

	public void setSnowCompany(String snowCompany) {
		this.snowCompany = snowCompany;
	}

	public String getSnowContractEndDate() {
		return snowContractEndDate;
	}

	public void setSnowContractEndDate(String snowContractEndDate) {
		this.snowContractEndDate = snowContractEndDate;
	}

	public String getSnowCorrelationId() {
		return snowCorrelationId;
	}

	public void setSnowCorrelationId(String snowCorrelationId) {
		this.snowCorrelationId = snowCorrelationId;
	}

	public String getSnowCost() {
		return snowCost;
	}

	public void setSnowCost(String snowCost) {
		this.snowCost = snowCost;
	}

	public String getSnowCostCc() {
		return snowCostCc;
	}

	public void setSnowCostCc(String snowCostCc) {
		this.snowCostCc = snowCostCc;
	}

	public String getSnowCreatedByQualys() {
		return snowCreatedByQualys;
	}

	public void setSnowCreatedByQualys(String snowCreatedByQualys) {
		this.snowCreatedByQualys = snowCreatedByQualys;
	}

	public String getSnowCurrency() {
		return snowCurrency;
	}

	public void setSnowCurrency(String snowCurrency) {
		this.snowCurrency = snowCurrency;
	}

	public String getSnowDataClassification() {
		return snowDataClassification;
	}

	public void setSnowDataClassification(String snowDataClassification) {
		this.snowDataClassification = snowDataClassification;
	}

	public String getSnowDeliveryDate() {
		return snowDeliveryDate;
	}

	public void setSnowDeliveryDate(String snowDeliveryDate) {
		this.snowDeliveryDate = snowDeliveryDate;
	}

	public String getSnowDepartment() {
		return snowDepartment;
	}

	public void setSnowDepartment(String snowDepartment) {
		this.snowDepartment = snowDepartment;
	}

	public String getSnowDiscoverySource() {
		return snowDiscoverySource;
	}

	public void setSnowDiscoverySource(String snowDiscoverySource) {
		this.snowDiscoverySource = snowDiscoverySource;
	}

	public String getSnowDnsDomain() {
		return snowDnsDomain;
	}

	public void setSnowDnsDomain(String snowDnsDomain) {
		this.snowDnsDomain = snowDnsDomain;
	}

	public String getSnowDue() {
		return snowDue;
	}

	public void setSnowDue(String snowDue) {
		this.snowDue = snowDue;
	}

	public String getSnowDueIn() {
		return snowDueIn;
	}

	public void setSnowDueIn(String snowDueIn) {
		this.snowDueIn = snowDueIn;
	}

	public String getSnowEmergencyTier() {
		return snowEmergencyTier;
	}

	public void setSnowEmergencyTier(String snowEmergencyTier) {
		this.snowEmergencyTier = snowEmergencyTier;
	}

	public String getSnowFaultCount() {
		return snowFaultCount;
	}

	public void setSnowFaultCount(String snowFaultCount) {
		this.snowFaultCount = snowFaultCount;
	}

	public String getSnowFirstDiscovered() {
		return snowFirstDiscovered;
	}

	public void setSnowFirstDiscovered(String snowFirstDiscovered) {
		this.snowFirstDiscovered = snowFirstDiscovered;
	}

	public String getSnowFqdn() {
		return snowFqdn;
	}

	public void setSnowFqdn(String snowFqdn) {
		this.snowFqdn = snowFqdn;
	}

	public String getSnowGlAccount() {
		return snowGlAccount;
	}

	public void setSnowGlAccount(String snowGlAccount) {
		this.snowGlAccount = snowGlAccount;
	}

	public String getSnowInstallDate() {
		return snowInstallDate;
	}

	public void setSnowInstallDate(String snowInstallDate) {
		this.snowInstallDate = snowInstallDate;
	}

	public String getSnowInstallStatus() {
		return snowInstallStatus;
	}

	public void setSnowInstallStatus(String snowInstallStatus) {
		this.snowInstallStatus = snowInstallStatus;
	}

	public String getSnowInstallType() {
		return snowInstallType;
	}

	public void setSnowInstallType(String snowInstallType) {
		this.snowInstallType = snowInstallType;
	}

	public String getSnowInvoiceNumber() {
		return snowInvoiceNumber;
	}

	public void setSnowInvoiceNumber(String snowInvoiceNumber) {
		this.snowInvoiceNumber = snowInvoiceNumber;
	}

	public String getSnowIpAddress() {
		return snowIpAddress;
	}

	public void setSnowIpAddress(String snowIpAddress) {
		this.snowIpAddress = snowIpAddress;
	}

	public String getSnowItApplicationOwner() {
		return snowItApplicationOwner;
	}

	public void setSnowItApplicationOwner(String snowItApplicationOwner) {
		this.snowItApplicationOwner = snowItApplicationOwner;
	}

	public String getSnowJustification() {
		return snowJustification;
	}

	public void setSnowJustification(String snowJustification) {
		this.snowJustification = snowJustification;
	}

	public String getSnowLastChangeAppliedDate() {
		return snowLastChangeAppliedDate;
	}

	public void setSnowLastChangeAppliedDate(String snowLastChangeAppliedDate) {
		this.snowLastChangeAppliedDate = snowLastChangeAppliedDate;
	}

	public String getSnowLastChangeDate() {
		return snowLastChangeDate;
	}

	public void setSnowLastChangeDate(String snowLastChangeDate) {
		this.snowLastChangeDate = snowLastChangeDate;
	}

	public String getSnowLastDiscovered() {
		return snowLastDiscovered;
	}

	public void setSnowLastDiscovered(String snowLastDiscovered) {
		this.snowLastDiscovered = snowLastDiscovered;
	}

	public String getSnowLeaseId() {
		return snowLeaseId;
	}

	public void setSnowLeaseId(String snowLeaseId) {
		this.snowLeaseId = snowLeaseId;
	}

	public String getSnowLicense() {
		return snowLicense;
	}

	public void setSnowLicense(String snowLicense) {
		this.snowLicense = snowLicense;
	}

	public String getSnowLocation() {
		return snowLocation;
	}

	public void setSnowLocation(String snowLocation) {
		this.snowLocation = snowLocation;
	}

	public String getSnowMacAddress() {
		return snowMacAddress;
	}

	public void setSnowMacAddress(String snowMacAddress) {
		this.snowMacAddress = snowMacAddress;
	}

	public String getSnowMaintenanceSchedule() {
		return snowMaintenanceSchedule;
	}

	public void setSnowMaintenanceSchedule(String snowMaintenanceSchedule) {
		this.snowMaintenanceSchedule = snowMaintenanceSchedule;
	}

	public String getSnowManagedBy() {
		return snowManagedBy;
	}

	public void setSnowManagedBy(String snowManagedBy) {
		this.snowManagedBy = snowManagedBy;
	}

	public String getSnowManufacturer() {
		return snowManufacturer;
	}

	public void setSnowManufacturer(String snowManufacturer) {
		this.snowManufacturer = snowManufacturer;
	}

	public String getSnowModelId() {
		return snowModelId;
	}

	public void setSnowModelId(String snowModelId) {
		this.snowModelId = snowModelId;
	}

	public String getSnowModelNumber() {
		return snowModelNumber;
	}

	public void setSnowModelNumber(String snowModelNumber) {
		this.snowModelNumber = snowModelNumber;
	}

	public String getSnowMonitor() {
		return snowMonitor;
	}

	public void setSnowMonitor(String snowMonitor) {
		this.snowMonitor = snowMonitor;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowNextAssessmentDate() {
		return snowNextAssessmentDate;
	}

	public void setSnowNextAssessmentDate(String snowNextAssessmentDate) {
		this.snowNextAssessmentDate = snowNextAssessmentDate;
	}

	public String getSnowNumber() {
		return snowNumber;
	}

	public void setSnowNumber(String snowNumber) {
		this.snowNumber = snowNumber;
	}

	public String getSnowOperationalStatus() {
		return snowOperationalStatus;
	}

	public void setSnowOperationalStatus(String snowOperationalStatus) {
		this.snowOperationalStatus = snowOperationalStatus;
	}

	public String getSnowOrderDate() {
		return snowOrderDate;
	}

	public void setSnowOrderDate(String snowOrderDate) {
		this.snowOrderDate = snowOrderDate;
	}

	public String getSnowOrganizationUnitCount() {
		return snowOrganizationUnitCount;
	}

	public void setSnowOrganizationUnitCount(String snowOrganizationUnitCount) {
		this.snowOrganizationUnitCount = snowOrganizationUnitCount;
	}

	public String getSnowOwnedBy() {
		return snowOwnedBy;
	}

	public void setSnowOwnedBy(String snowOwnedBy) {
		this.snowOwnedBy = snowOwnedBy;
	}

	public String getSnowPlatform() {
		return snowPlatform;
	}

	public void setSnowPlatform(String snowPlatform) {
		this.snowPlatform = snowPlatform;
	}

	public String getSnowPoNumber() {
		return snowPoNumber;
	}

	public void setSnowPoNumber(String snowPoNumber) {
		this.snowPoNumber = snowPoNumber;
	}

	public String getSnowProductSupportStatus() {
		return snowProductSupportStatus;
	}

	public void setSnowProductSupportStatus(String snowProductSupportStatus) {
		this.snowProductSupportStatus = snowProductSupportStatus;
	}

	public String getSnowPurchaseDate() {
		return snowPurchaseDate;
	}

	public void setSnowPurchaseDate(String snowPurchaseDate) {
		this.snowPurchaseDate = snowPurchaseDate;
	}

	public String getSnowSchedule() {
		return snowSchedule;
	}

	public void setSnowSchedule(String snowSchedule) {
		this.snowSchedule = snowSchedule;
	}

	public String getSnowScoreTrendFrequency() {
		return snowScoreTrendFrequency;
	}

	public void setSnowScoreTrendFrequency(String snowScoreTrendFrequency) {
		this.snowScoreTrendFrequency = snowScoreTrendFrequency;
	}

	public String getSnowSerialNumber() {
		return snowSerialNumber;
	}

	public void setSnowSerialNumber(String snowSerialNumber) {
		this.snowSerialNumber = snowSerialNumber;
	}

	public String getSnowShortDescription() {
		return snowShortDescription;
	}

	public void setSnowShortDescription(String snowShortDescription) {
		this.snowShortDescription = snowShortDescription;
	}

	public String getSnowSkipSync() {
		return snowSkipSync;
	}

	public void setSnowSkipSync(String snowSkipSync) {
		this.snowSkipSync = snowSkipSync;
	}

	public String getSnowSnVulQualysHostId() {
		return snowSnVulQualysHostId;
	}

	public void setSnowSnVulQualysHostId(String snowSnVulQualysHostId) {
		this.snowSnVulQualysHostId = snowSnVulQualysHostId;
	}

	public String getSnowSnVulQualysHostTags() {
		return snowSnVulQualysHostTags;
	}

	public void setSnowSnVulQualysHostTags(String snowSnVulQualysHostTags) {
		this.snowSnVulQualysHostTags = snowSnVulQualysHostTags;
	}

	public String getSnowSnVulQualysId() {
		return snowSnVulQualysId;
	}

	public void setSnowSnVulQualysId(String snowSnVulQualysId) {
		this.snowSnVulQualysId = snowSnVulQualysId;
	}

	public String getSnowSoftwareLicense() {
		return snowSoftwareLicense;
	}

	public void setSnowSoftwareLicense(String snowSoftwareLicense) {
		this.snowSoftwareLicense = snowSoftwareLicense;
	}

	public String getSnowStartDate() {
		return snowStartDate;
	}

	public void setSnowStartDate(String snowStartDate) {
		this.snowStartDate = snowStartDate;
	}

	public String getSnowSubcategory() {
		return snowSubcategory;
	}

	public void setSnowSubcategory(String snowSubcategory) {
		this.snowSubcategory = snowSubcategory;
	}

	public String getSnowSupportGroup() {
		return snowSupportGroup;
	}

	public void setSnowSupportGroup(String snowSupportGroup) {
		this.snowSupportGroup = snowSupportGroup;
	}

	public String getSnowSupportVendor() {
		return snowSupportVendor;
	}

	public void setSnowSupportVendor(String snowSupportVendor) {
		this.snowSupportVendor = snowSupportVendor;
	}

	public String getSnowSupportedBy() {
		return snowSupportedBy;
	}

	public void setSnowSupportedBy(String snowSupportedBy) {
		this.snowSupportedBy = snowSupportedBy;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysClassPath() {
		return snowSysClassPath;
	}

	public void setSnowSysClassPath(String snowSysClassPath) {
		this.snowSysClassPath = snowSysClassPath;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysDomain() {
		return snowSysDomain;
	}

	public void setSnowSysDomain(String snowSysDomain) {
		this.snowSysDomain = snowSysDomain;
	}

	public String getSnowSysDomainPath() {
		return snowSysDomainPath;
	}

	public void setSnowSysDomainPath(String snowSysDomainPath) {
		this.snowSysDomainPath = snowSysDomainPath;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowTechnologyStack() {
		return snowTechnologyStack;
	}

	public void setSnowTechnologyStack(String snowTechnologyStack) {
		this.snowTechnologyStack = snowTechnologyStack;
	}

	public String getSnowU_Acronym() {
		return snowU_Acronym;
	}

	public void setSnowU_Acronym(String snowU_Acronym) {
		this.snowU_Acronym = snowU_Acronym;
	}

	public String getSnowU_AppUse() {
		return snowU_AppUse;
	}

	public void setSnowU_AppUse(String snowU_AppUse) {
		this.snowU_AppUse = snowU_AppUse;
	}

	public String getSnowU_ApplicationCategory() {
		return snowU_ApplicationCategory;
	}

	public void setSnowU_ApplicationCategory(String snowU_ApplicationCategory) {
		this.snowU_ApplicationCategory = snowU_ApplicationCategory;
	}

	public String getSnowU_BusinessFunction() {
		return snowU_BusinessFunction;
	}

	public void setSnowU_BusinessFunction(String snowU_BusinessFunction) {
		this.snowU_BusinessFunction = snowU_BusinessFunction;
	}

	public String getSnowU_BusinessOwner() {
		return snowU_BusinessOwner;
	}

	public void setSnowU_BusinessOwner(String snowU_BusinessOwner) {
		this.snowU_BusinessOwner = snowU_BusinessOwner;
	}

	public String getSnowU_BusinessService() {
		return snowU_BusinessService;
	}

	public void setSnowU_BusinessService(String snowU_BusinessService) {
		this.snowU_BusinessService = snowU_BusinessService;
	}

	public String getSnowU_CategoryGroup() {
		return snowU_CategoryGroup;
	}

	public void setSnowU_CategoryGroup(String snowU_CategoryGroup) {
		this.snowU_CategoryGroup = snowU_CategoryGroup;
	}

	public String getSnowU_EaiId() {
		return snowU_EaiId;
	}

	public void setSnowU_EaiId(String snowU_EaiId) {
		this.snowU_EaiId = snowU_EaiId;
	}

	public String getSnowU_EnterpriseService() {
		return snowU_EnterpriseService;
	}

	public void setSnowU_EnterpriseService(String snowU_EnterpriseService) {
		this.snowU_EnterpriseService = snowU_EnterpriseService;
	}

	public String getSnowU_EnterpriseServiceDesired() {
		return snowU_EnterpriseServiceDesired;
	}

	public void setSnowU_EnterpriseServiceDesired(String snowU_EnterpriseServiceDesired) {
		this.snowU_EnterpriseServiceDesired = snowU_EnterpriseServiceDesired;
	}

	public String getSnowU_Environment() {
		return snowU_Environment;
	}

	public void setSnowU_Environment(String snowU_Environment) {
		this.snowU_Environment = snowU_Environment;
	}

	public String getSnowU_Function() {
		return snowU_Function;
	}

	public void setSnowU_Function(String snowU_Function) {
		this.snowU_Function = snowU_Function;
	}

	public String getSnowU_Gateway() {
		return snowU_Gateway;
	}

	public void setSnowU_Gateway(String snowU_Gateway) {
		this.snowU_Gateway = snowU_Gateway;
	}

	public String getSnowU_Gateways() {
		return snowU_Gateways;
	}

	public void setSnowU_Gateways(String snowU_Gateways) {
		this.snowU_Gateways = snowU_Gateways;
	}

	public String getSnowU_Hippa() {
		return snowU_Hippa;
	}

	public void setSnowU_Hippa(String snowU_Hippa) {
		this.snowU_Hippa = snowU_Hippa;
	}

	public String getSnowU_IdentifiedPrimaryUser() {
		return snowU_IdentifiedPrimaryUser;
	}

	public void setSnowU_IdentifiedPrimaryUser(String snowU_IdentifiedPrimaryUser) {
		this.snowU_IdentifiedPrimaryUser = snowU_IdentifiedPrimaryUser;
	}

	public String getSnowU_Imei() {
		return snowU_Imei;
	}

	public void setSnowU_Imei(String snowU_Imei) {
		this.snowU_Imei = snowU_Imei;
	}

	public String getSnowU_Imeis() {
		return snowU_Imeis;
	}

	public void setSnowU_Imeis(String snowU_Imeis) {
		this.snowU_Imeis = snowU_Imeis;
	}

	public String getSnowU_ImpactedOpco() {
		return snowU_ImpactedOpco;
	}

	public void setSnowU_ImpactedOpco(String snowU_ImpactedOpco) {
		this.snowU_ImpactedOpco = snowU_ImpactedOpco;
	}

	public String getSnowU_IntegrationId() {
		return snowU_IntegrationId;
	}

	public void setSnowU_IntegrationId(String snowU_IntegrationId) {
		this.snowU_IntegrationId = snowU_IntegrationId;
	}

	public String getSnowU_IntegrationSource() {
		return snowU_IntegrationSource;
	}

	public void setSnowU_IntegrationSource(String snowU_IntegrationSource) {
		this.snowU_IntegrationSource = snowU_IntegrationSource;
	}

	public String getSnowU_ItLead() {
		return snowU_ItLead;
	}

	public void setSnowU_ItLead(String snowU_ItLead) {
		this.snowU_ItLead = snowU_ItLead;
	}

	public String getSnowU_LastLoggedOnUser() {
		return snowU_LastLoggedOnUser;
	}

	public void setSnowU_LastLoggedOnUser(String snowU_LastLoggedOnUser) {
		this.snowU_LastLoggedOnUser = snowU_LastLoggedOnUser;
	}

	public String getSnowU_LastPhysicallyInventoried() {
		return snowU_LastPhysicallyInventoried;
	}

	public void setSnowU_LastPhysicallyInventoried(String snowU_LastPhysicallyInventoried) {
		this.snowU_LastPhysicallyInventoried = snowU_LastPhysicallyInventoried;
	}

	public String getSnowU_LastSeenInIntegrationSource() {
		return snowU_LastSeenInIntegrationSource;
	}

	public void setSnowU_LastSeenInIntegrationSource(String snowU_LastSeenInIntegrationSource) {
		this.snowU_LastSeenInIntegrationSource = snowU_LastSeenInIntegrationSource;
	}

	public String getSnowU_ManagingOpco() {
		return snowU_ManagingOpco;
	}

	public void setSnowU_ManagingOpco(String snowU_ManagingOpco) {
		this.snowU_ManagingOpco = snowU_ManagingOpco;
	}

	public String getSnowU_ManagingOpcos() {
		return snowU_ManagingOpcos;
	}

	public void setSnowU_ManagingOpcos(String snowU_ManagingOpcos) {
		this.snowU_ManagingOpcos = snowU_ManagingOpcos;
	}

	public String getSnowU_Meids() {
		return snowU_Meids;
	}

	public void setSnowU_Meids(String snowU_Meids) {
		this.snowU_Meids = snowU_Meids;
	}

	public String getSnowU_OwningVp() {
		return snowU_OwningVp;
	}

	public void setSnowU_OwningVp(String snowU_OwningVp) {
		this.snowU_OwningVp = snowU_OwningVp;
	}

	public String getSnowU_PatchStatus() {
		return snowU_PatchStatus;
	}

	public void setSnowU_PatchStatus(String snowU_PatchStatus) {
		this.snowU_PatchStatus = snowU_PatchStatus;
	}

	public String getSnowU_Pci() {
		return snowU_Pci;
	}

	public void setSnowU_Pci(String snowU_Pci) {
		this.snowU_Pci = snowU_Pci;
	}

	public String getSnowU_Pii() {
		return snowU_Pii;
	}

	public void setSnowU_Pii(String snowU_Pii) {
		this.snowU_Pii = snowU_Pii;
	}

	public String getSnowU_ProjectedDisposition() {
		return snowU_ProjectedDisposition;
	}

	public void setSnowU_ProjectedDisposition(String snowU_ProjectedDisposition) {
		this.snowU_ProjectedDisposition = snowU_ProjectedDisposition;
	}

	public String getSnowU_ProjectedDispositionDate() {
		return snowU_ProjectedDispositionDate;
	}

	public void setSnowU_ProjectedDispositionDate(String snowU_ProjectedDispositionDate) {
		this.snowU_ProjectedDispositionDate = snowU_ProjectedDispositionDate;
	}

	public String getSnowU_PublicFacing() {
		return snowU_PublicFacing;
	}

	public void setSnowU_PublicFacing(String snowU_PublicFacing) {
		this.snowU_PublicFacing = snowU_PublicFacing;
	}

	public String getSnowU_RegulatoryRestriction() {
		return snowU_RegulatoryRestriction;
	}

	public void setSnowU_RegulatoryRestriction(String snowU_RegulatoryRestriction) {
		this.snowU_RegulatoryRestriction = snowU_RegulatoryRestriction;
	}

	public String getSnowU_ServiceLevelClass() {
		return snowU_ServiceLevelClass;
	}

	public void setSnowU_ServiceLevelClass(String snowU_ServiceLevelClass) {
		this.snowU_ServiceLevelClass = snowU_ServiceLevelClass;
	}

	public String getSnowU_Sim() {
		return snowU_Sim;
	}

	public void setSnowU_Sim(String snowU_Sim) {
		this.snowU_Sim = snowU_Sim;
	}

	public String getSnowU_Sims() {
		return snowU_Sims;
	}

	public void setSnowU_Sims(String snowU_Sims) {
		this.snowU_Sims = snowU_Sims;
	}

	public String getSnowU_Sox() {
		return snowU_Sox;
	}

	public void setSnowU_Sox(String snowU_Sox) {
		this.snowU_Sox = snowU_Sox;
	}

	public String getSnowU_ThirdPartySupport() {
		return snowU_ThirdPartySupport;
	}

	public void setSnowU_ThirdPartySupport(String snowU_ThirdPartySupport) {
		this.snowU_ThirdPartySupport = snowU_ThirdPartySupport;
	}

	public String getSnowU_Version() {
		return snowU_Version;
	}

	public void setSnowU_Version(String snowU_Version) {
		this.snowU_Version = snowU_Version;
	}

	public String getSnowUnverified() {
		return snowUnverified;
	}

	public void setSnowUnverified(String snowUnverified) {
		this.snowUnverified = snowUnverified;
	}

	public String getSnowUrl() {
		return snowUrl;
	}

	public void setSnowUrl(String snowUrl) {
		this.snowUrl = snowUrl;
	}

	public String getSnowUserBase() {
		return snowUserBase;
	}

	public void setSnowUserBase(String snowUserBase) {
		this.snowUserBase = snowUserBase;
	}

	public String getSnowVendor() {
		return snowVendor;
	}

	public void setSnowVendor(String snowVendor) {
		this.snowVendor = snowVendor;
	}

	public String getSnowWarrantyExpiration() {
		return snowWarrantyExpiration;
	}

	public void setSnowWarrantyExpiration(String snowWarrantyExpiration) {
		this.snowWarrantyExpiration = snowWarrantyExpiration;
	}

	public String getSnowWorkNotes() {
		return snowWorkNotes;
	}

	public void setSnowWorkNotes(String snowWorkNotes) {
		this.snowWorkNotes = snowWorkNotes;
	}
}
