package com.fedex.emea.sabreReport.ldap;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;

public class LDAPUserInfo implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// these parameters are exact match of the LDAP properties
	private String Uid;
	private String Xuid;
	private String Country;
	private String GivenName;
	private String Xdomain;
	private String PostalAddress;
	private String TelephoneNumber;
	private String Mail;
	private String Departmentname;
	private String Sn;
	private String Countrycode;
	private String Comatstationid;
	private String Manager;
	private String ManagementLevel;
	private String Mobile;
	private String Title;
	
	// these parameters are mapped to table columns 
	private String userRoid;
	private String authenticator;
	private String userName;
	private String managerId;
	private String managerName;
	private String accountCreateReason;
	private String departmentInfo;
	private int sessionTimeout = 30;
	
	
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public String getGivenName() {
		return GivenName;
	}
	public void setGivenName(String givenName) {
		GivenName = givenName;
	}
	public String getPostalAddress() {
		return PostalAddress;
	}
	public void setPostalAddress(String postalAddress) {
		PostalAddress = postalAddress;
	}
	public String getTelephoneNumber() {
		return TelephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber) {
		TelephoneNumber = telephoneNumber;
	}
	public String getUid() {
		return Uid;
	}
	public void setUid(String uid) {
		Uid = uid;
	}
	public String getXdomain() {
		return Xdomain;
	}
	public void setXdomain(String xdomain) {
		Xdomain = xdomain;
	}
	public String getXuid() {
		return Xuid;
	}
	public void setXuid(String xuid) {
		Xuid = xuid;
	}
	
	public String getCountrycode() {
		return Countrycode;
	}
	public void setCountrycode(String countrycode) {
		Countrycode = countrycode;
	}
	public String getComatstationid() {
		return Comatstationid;
	}
	public void setComatstationid(String comatstationid) {
		Comatstationid = comatstationid;
	}
	public String getManager() {
		return Manager;
	}
	public void setManager(String manager) {
		Manager = manager;
	}
	public int getSessionTimeout() {
		return sessionTimeout;
	}
	public void setSessionTimeout(int sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}
	public String getAuthenticator() {
		return authenticator;
	}
	public void setAuthenticator(String authenticator) {
		this.authenticator = authenticator;
	}
	public String getDepartmentInfo() {
		return departmentInfo;
	}
	public void setDepartmentInfo(String departmentInfo) {
		this.departmentInfo = departmentInfo;
	}
	public String getManagerId() {
		return managerId;
	}
	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserRoid() {
		return userRoid;
	}
	public void setUserRoid(String userRoid) {
		this.userRoid = userRoid;
	}
	public String getAccountCreateReason() {
		return accountCreateReason;
	}
	public void setAccountCreateReason(String accountCreateReason) {
		this.accountCreateReason = accountCreateReason;
	}
	public String getMail() {
		return Mail;
	}
	public void setMail(String mail) {
		Mail = mail;
	}	
	
	public boolean isAdminUser(){
		boolean isAdmin = false;
		if(userRoid!=null && userRoid.trim().length()>0){
			if(userRoid.equalsIgnoreCase("ADMIN") || userRoid.equalsIgnoreCase("ADMINISTRATOR"))
				isAdmin = true;
		}
		return isAdmin;
	}

	public String getSn(){
		return Sn;
	}
	public void setSn(String sn){
		Sn = sn;
	}
	
	public String getDepartmentname(){
		return Departmentname;
	}
	public void setDepartmentname(String departmentname){
		Departmentname = departmentname;
	}
	
	public String getPersonXml(){

		String xmlString = null;
		StringWriter stringWriter = new StringWriter();
		BufferedWriter bufWriter = new BufferedWriter(stringWriter);
		try {
			bufWriter.write("<Person>");
			bufWriter.newLine();
			bufWriter.write("<DisplayName>"+GivenName+" "+Sn+"</DisplayName>");
			bufWriter.newLine();
			bufWriter.write("<PhysicalDeliveryOfficeName>"+Countrycode+"/"+Comatstationid+"</PhysicalDeliveryOfficeName>");
			bufWriter.newLine();
			bufWriter.write("<Mail>"+Mail+"</Mail>");
			bufWriter.newLine();
			String managerID = Manager;
			if(Manager.indexOf(',')>0){
				managerID = Manager.split(",")[0];
				managerID = managerID.trim();
				if(managerID.indexOf('=')>0)
					managerID = managerID.split("=")[1].trim();
			}
			bufWriter.write("<Manager>"+managerID+"</Manager>");
			bufWriter.newLine();
			bufWriter.write("</Person>");
			bufWriter.flush();
			xmlString = (stringWriter.getBuffer()).toString();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
            try {
				stringWriter.close();
				bufWriter.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return xmlString;
		
	}
	public String getManagementLevel() {
		return ManagementLevel;
	}
	public void setManagementLevel(String managementLevel) {
		ManagementLevel = managementLevel;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	

}
