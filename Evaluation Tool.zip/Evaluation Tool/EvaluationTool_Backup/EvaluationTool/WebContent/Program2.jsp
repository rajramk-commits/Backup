<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>SD Evaluation</title>
<script >

</script>
<style type="text/css">
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;
		
	}
.logout{
float:right;
margin-right:5%;
background-color:#FF8C00;
color:white;
padding:14px 20px;
border:none;
cursor:pointer;
}
.logout:hover{
background-color:#4B0060;
}

input[type=submit]{

background-color:#4B0082;
color:white;
padding:14px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:20%;
}

input[type=submit]:hover{
background-color:#7030a0;

}
.login{
	
	display:flex;
	justify-content:center;
}
/* .dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
} */

.dropdown {
  position: relative;
  display: inline-block;
  background-color: #4CAF50;
  color: white;
  padding: 1px;
  font-size: 20px;
  border: none;
  cursor: pointer;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  /* box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); */
  z-index: 1;
}

/*  .dropdown-content {
   display: none; 
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}  */
.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #f1f1f1}

.dropdown:hover .dropdown-content {
  display: block;
}

.dropdown:hover .dropbtn {
  background-color: #3e8e41;
}

</style>
	
</head>
<body>
		<%     	
	        if(session.getAttribute("sessionName")==null)
	        {
	            response.sendRedirect("Login.jsp");
			}
			session.setAttribute("min",30);
			session.setAttribute("sec",00);
			String userID = (String) session.getAttribute("sessionName");
			//out.println("Welcome : "+userID);
     	%>
     	<div class="main"> 
     	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Instructions - Program 2 Test</p></center>
   		</div>
   		
   		 <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div> 

        <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form>  
     	</br>    	
     	    
     	<br><br>
     	 
     
     	<div style="font-family:Calibri;font-size:16px;">
		<b style="font-size:20px;">Instructions :</b><br><br>

		
		1.Please read the instructions carefully. Once you "Start Test"", you cannot come back to this page. <br>
		2.Timer will start when you click "Start Test".<br>
		3.Questions are with multiple choice, short and long answers. Mark the correct answer. If a question has multiple correct answers, it will be indicated as part of the question.<br>
		4.While on the test page, do not click "F5" or "Refresh" the page. This will terminate your test.<br>
		5.Once you complete the test, please press "Submit".<br>
		6.After Submit your Test paper will be evaluated and results will be shared by you.<br>
		7.Before you start the test, ensure you have a good network and power connection to your machine.<br><br>
		Good Luck!
		</br>
		</br>
		</div>
		<form action="Controller.jsp">
		<br><br>
		<div class="dropdown">
            
            <select name="TeamName" >
            <option value="null" selected="selected" style = "size: 20px; font-family: sans-serif;">Choose your Department:</option>
            <option value="ClearanceCC" style = "size: 20px; font-family: sans-serif;">ClearanceCC</option>
            <option value="HubstackCC" style = "size: 20px; font-family: sans-serif;">HubstackCC</option>
            <option value="Application_Support" style = "size: 20px; font-family: sans-serif;">Application Support</option>
            </select>
         
         </div>	
         <br><br><br><br>	
            <input type="hidden" name="page" value="exam2">
            <input type="hidden" name="TestName" value="Program2">
            <input type="submit" value="Start Test">
        </form>
            
        <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>