package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import com.fedex.emea.sd.da.objects.AppsOnServer;
import com.fedex.emea.sd.da.objects.NetworkEquipments;

public interface NetworkEquipmentDao {
	public NetworkEquipments createValueObject();
	public List<AppsOnServer>      getApplicationsOnServer(String serverName) throws SQLException;
	public List<NetworkEquipments> getActiveServerDetails(String serverName) throws SQLException;
}

