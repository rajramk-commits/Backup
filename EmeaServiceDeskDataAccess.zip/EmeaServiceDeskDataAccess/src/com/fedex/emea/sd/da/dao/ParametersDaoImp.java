package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.ParametersRowMapper;
import com.fedex.emea.sd.da.objects.Parameters;

public class ParametersDaoImp implements ParametersDao {
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void create(Parameters valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO Parameters (PARAMETERENTITY, PARAMETERNAME, PARAMETERVALUE1, PARAMETERVALUE2, PARAMETERVALUE3) " +
		               "VALUES (?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getParameterEntity(), valueObject.getParameterName(), valueObject.getParameterValue1(), valueObject.getParameterValue2(), valueObject.getParameterValue3()});
	}
	
	@Override
	public Parameters createValueObject() {
		return new Parameters();
	}

	@Override
	public void delete(Parameters valueObject) {
		String sql = "DELETE FROM Parameters WHERE (PARAMETERENTITY = ? and PARAMETERNAME = ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getParameterEntity(), valueObject.getParameterName()});
	}

	@Override
	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM Parameters";
		jdbcTemplate.update(sql);
	}

	@Override
	public Parameters getObject(String parameterEntity, String parameterName) throws SQLException {
		Parameters valueObject = createValueObject();
		String sql = "SELECT * FROM Parameters WHERE (PARAMETERENTITY = ? and PARAMETERNAME = ?) ";
		valueObject = (Parameters) jdbcTemplate.queryForObject(sql, new Object[] {parameterEntity, parameterName}, new ParametersRowMapper());
		return valueObject;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Parameters> loadAll() throws SQLException {
		String sql = "SELECT * FROM Parameters ORDER BY PARAMETERENTITY ASC, PARAMETERNAME ASC ";
		return jdbcTemplate.query(sql, new ParametersRowMapper());
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Parameters> loadByEntity(String parameterEntity) throws SQLException {
		String sql = "SELECT * FROM Parameters WHERE PARAMETERENTITY = ? ORDER BY PARAMETERNAME ASC ";
		return jdbcTemplate.query(sql, new Object[] {parameterEntity}, new ParametersRowMapper());
	}

	@Override
	public void save(Parameters valueObject) throws DataAccessException {
		String sql = "UPDATE Parameters SET PARAMETERVALUE1 = ?, PARAMETERVALUE2 = ?, PARAMETERVALUE3 = ? WHERE (PARAMETERENTITY = ? and PARAMETERNAME = ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getParameterValue1(), valueObject.getParameterValue2(), valueObject.getParameterValue3(), valueObject.getParameterEntity(), valueObject.getParameterName()});
	}
}
