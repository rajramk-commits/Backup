package com.fedex.emea.sd.da.exceptions;

public class ApplicationtypeDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7908769619090685130L;

	/**
	 * Method 'ApplicationtypeDaoException'
	 * 
	 * @param message
	 */
	public ApplicationtypeDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'ApplicationtypeDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public ApplicationtypeDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
