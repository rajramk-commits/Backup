<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="com.fedex.emea.sabreReport.dao.ReportDao"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
String uID = request.getParameter("username");
String role = request.getParameter("role");
String app = request.getParameter("appName");
String action = request.getParameter("actn");
System.out.println("uID :"+uID);
System.out.println("role :"+role);
System.out.println("app :"+app);
System.out.println("action :"+action);
String status="";
if(action.equalsIgnoreCase("add"))
{
	if(ReportDao.getRole(uID) != null)
		status= ReportDao.addUser(uID, role, app);
	else
		status= ReportDao.addUser(uID, role, app);
}
else if (action.equalsIgnoreCase("del"))
	status= ReportDao.deleteUser(uID);

response.sendRedirect("reportType.jsp?status="+status);
%>
</body>
</html>