package com.example.portfolio.dto;

import java.math.BigDecimal;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Groups {
   
    @NotBlank
    private String groupName;

    @NotNull
    @DecimalMin("0.0")
    private BigDecimal weightPct;

    @NotNull
    @DecimalMin("-1.0")
    private BigDecimal returnPct;

    
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public BigDecimal getWeightPct() {
        return weightPct;
    }

    public void setWeightPct(BigDecimal weightPct) {
        this.weightPct = weightPct;
    }

    public BigDecimal getReturnPct() {
        return returnPct;
    }

    public void setReturnPct(BigDecimal returnPct) {
        this.returnPct = returnPct;
    }

}
