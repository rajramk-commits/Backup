package com.fedex.emea.sd.da.dao.spring;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.dao.ServerAvailabilitiesDao;
import com.fedex.emea.sd.da.mappers.ServerAvailabilitiesRowMapper;
import com.fedex.emea.sd.da.objects.ServerAvailabilities;

public class ServerAvailabilitiesDaoImp implements ServerAvailabilitiesDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public ServerAvailabilities getServerAvailability(String serverName) throws SQLException {
		ServerAvailabilities valueObject = createValueObject();
		String sql = "select * from SERVERAVAILABILITIES where SERVERNAME = ?";
		valueObject = (ServerAvailabilities) jdbcTemplate.queryForObject(sql, new Object[] {serverName}, new ServerAvailabilitiesRowMapper());
		
		return valueObject;
	}
	
	public ServerAvailabilities getServerLastAvailability(String serverName) throws SQLException {
		ServerAvailabilities valueObject = createValueObject();
		String sql = "select * from SERVERAVAILABILITIES where SERVERNAME = ? and LASTCHECKTIME in (select max(LASTCHECKTIME) from SERVERAVAILABILITIES where SERVERNAME = ?)";
		valueObject = (ServerAvailabilities) jdbcTemplate.queryForObject(sql, new Object[] {serverName, serverName}, new ServerAvailabilitiesRowMapper());
		
		return valueObject;
	}

	@Override
	public ServerAvailabilities createValueObject() {
		return new ServerAvailabilities();
	}

	@Override
	public void updateServerAvailability(ServerAvailabilities valueObject, Timestamp oldCheckTime)	throws SQLException {
		String sql = "update SERVERAVAILABILITIES set ALIVE = ?, LASTCHECKTIME = ?, OLDSTATUSTIME = ?, STATUSCHANGETIME = ?, SERVERSOFTWAREVERSION = ?, SERVERSTATUS = ?, SERVERID = ? where SERVERNAME = ? and SERVERDC = ? and LASTCHECKTIME = ?";
		jdbcTemplate.update(sql, new Object[] {valueObject.isServerAlive(), valueObject.getLastCheckTime(), valueObject.getOldStatusTime(), valueObject.getStatusChangeTime(), valueObject.getServerSoftwareVersion(), valueObject.getServerStatus(), valueObject.getServerId(), valueObject.getServerName(), valueObject.getServerDc(), oldCheckTime});
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ServerAvailabilities> loadServerAvailabilitiesByDataCenter(String dataCenter) throws SQLException {
		String sql = "select * from SERVERAVAILABILITIES where SERVERDC = ? ORDER BY SERVERNAME ";
		return jdbcTemplate.query(sql, new Object[] {dataCenter}, new ServerAvailabilitiesRowMapper());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServerAvailabilities> loadAvailableServers() throws SQLException {
		String sql = "select * from SERVERAVAILABILITIES where ALIVE='1' ORDER BY SERVERNAME ";
		return jdbcTemplate.query(sql, new ServerAvailabilitiesRowMapper());
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ServerAvailabilities> loadUnavailableServers() throws SQLException {
		String sql = "select * from SERVERAVAILABILITIES where ALIVE='0' ORDER BY SERVERNAME ";
		return jdbcTemplate.query(sql, new ServerAvailabilitiesRowMapper());
	}

	@Override
	public void create(ServerAvailabilities valueObject) throws SQLException {
		String sql = "insert into SERVERAVAILABILITIES ( SERVERNAME, SERVERDC, ALIVE, LASTCHECKTIME, OLDSTATUSTIME, STATUSCHANGETIME, SERVERSOFTWAREVERSION, SERVERSTATUS, SERVERID) " +
	               "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getServerName(), valueObject.getServerDc(), valueObject.isServerAlive(), valueObject.getLastCheckTime(), valueObject.getOldStatusTime(), valueObject.getStatusChangeTime(), valueObject.getServerSoftwareVersion(), valueObject.getServerStatus(), valueObject.getServerId()});
	}

}
