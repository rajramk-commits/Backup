package com.fedex.emea.sd.snow.manager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class SnowRESTCommunicator {
		
	private CloseableHttpClient httpclient;
	private HttpClientContext   context;
	private HttpHost            targetHost;
	private RequestConfig       config;
	
	public SnowRESTCommunicator() {
	}
	
	public SnowRESTCommunicator(String snowDns, int snowPort, String snowType, String snowUid, String snowPwd, boolean useProxy) {
		UsernamePasswordCredentials userCredentials = new UsernamePasswordCredentials(snowUid, snowPwd);
		this.targetHost = new HttpHost(snowDns, snowPort, snowType);
		
		CredentialsProvider credsProvider = new BasicCredentialsProvider();
		credsProvider.setCredentials(new AuthScope(targetHost.getHostName(), targetHost.getPort()), userCredentials);
		
		AuthCache authCache = new BasicAuthCache();
		authCache.put(targetHost, new BasicScheme());
		
		if (useProxy) {
			HttpHost proxy = new HttpHost(SnowConstants.PROXY_DNS, SnowConstants.PROXY_PORT, SnowConstants.PROXY_TYPE);
			this.config = RequestConfig.custom().setProxy(proxy).build();
		} else {
			this.config = null;
		}
		
		this.httpclient = HttpClientBuilder.create().build();
		
		this.context = HttpClientContext.create();
		this.context.setCredentialsProvider(credsProvider);
		this.context.setAuthCache(authCache);
	}
	
	public JSONObject getResponseToGet(HttpRequest getRequest) throws Exception {
		JSONObject retObj = null;
		try {
			retObj = getHttpResponseAsJSON(getRequest);
		} catch (Exception e) {
			System.out.println("Error getting GET Response");
			throw e;
		}
		return retObj;
	}
	
	public JSONObject getResponseToDelete(HttpRequest deleteRequest) throws Exception {
		JSONObject retObj = null;
		try {
			retObj = getHttpResponseAsJSON(deleteRequest);
		} catch (Exception e) {
			System.out.println("Error getting DELETE Response");
			throw e;
		}
		return retObj;
	}
	
	public JSONObject getResponseToPost(HttpRequest postRequest) throws Exception {
		JSONObject retObj = null;
		try {
			retObj = getHttpResponseAsJSON(postRequest);
		} catch (Exception e) {
			System.out.println("Error getting POST Response");
			throw e;
		}
		return retObj;
	}
	
	public JSONObject getResponseToPut(HttpRequest putRequest) throws Exception {
		JSONObject retObj = null;
		try {
			retObj = getHttpResponseAsJSON(putRequest);
		} catch (Exception e) {
			System.out.println("Error getting PUT Response");
			throw e;
		}
		return retObj;
	}
						
	private JSONObject getHttpResponseAsJSON(HttpRequest request) throws Exception {
		StringBuilder strHttpResponse = new StringBuilder();
		JSONObject jsonObject = null;
		CloseableHttpResponse httpResponse;
		
		try {
			httpResponse = httpclient.execute(targetHost, request, context);
//			System.out.println("Status: " + httpResponse.getStatusLine());
		} catch (IOException e) {
			System.out.println("Error Getting HTTP Response from SNOW");
			throw e;
		}
		
		InputStreamReader inStream = new InputStreamReader(httpResponse.getEntity().getContent());
		BufferedReader rd = new BufferedReader(inStream);
		
		String line = "";
		try {
			while ((line = rd.readLine()) != null) {
				strHttpResponse.append(line);
			}
			if (strHttpResponse.length() > 0) jsonObject = new JSONObject(strHttpResponse.toString());
		} catch (Exception e) {
			System.out.println("Error Reading HTTP Response: " + strHttpResponse);
			throw e;
		} finally {
			httpResponse.close();
		}
		
		return jsonObject;
	}

	public RequestConfig getConfig() {
		return config;
	}

	public void setConfig(RequestConfig config) {
		this.config = config;
	}

}
