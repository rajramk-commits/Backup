package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.DashboardAlertsRowMapper;
import com.fedex.emea.sd.da.objects.DashboardAlerts;

public class DashboardAlertsDaoImp implements DashboardAlertsDao {
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public void create(DashboardAlerts valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO DashboardAlerts (ID, SERVER, COMPONENT, APPLICATION, MODULE, CREATIONTIME, NEXUSCASEID, ALERTID) " +
		               "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertId(), valueObject.getImpactedServer(), valueObject.getImpactedComponent(), valueObject.getImpactedApplication(), valueObject.getImpactedModule(), valueObject.getCreationTime(), valueObject.getNexusCaseId(), valueObject.getNiAlertId()});
	}
	
	@Override
	public DashboardAlerts createValueObject() {
		return new DashboardAlerts();
	}
	
	@Override
	public void deleteOlderThan(Timestamp limitDate) throws SQLException {
		String sql = "delete from DASHBOARDALERTS DA where DA.ALERTID in (select NI.ALERTID from NEXUSINTERFACE NI where NI.CREATIONTIME < ?)";
		jdbcTemplate.update(sql, new Object[] {limitDate});
	}

	@Override
	public void delete(DashboardAlerts valueObject) {
		String sql = "DELETE FROM DashboardAlerts WHERE (ID = ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertId()});
	}

	@Override
	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM DashboardAlerts";
		jdbcTemplate.update(sql);
	}

	@Override
	public DashboardAlerts getObject(String alertId) throws SQLException {
		DashboardAlerts valueObject = createValueObject();
		String sql = "SELECT * FROM DashboardAlerts WHERE (ID = ?) ";
		valueObject = (DashboardAlerts) jdbcTemplate.queryForObject(sql, new Object[] {alertId}, new DashboardAlertsRowMapper());
		return valueObject;
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<DashboardAlerts> loadAll() throws SQLException {
		String sql = "SELECT * FROM DashboardAlerts ORDER BY ID ASC ";
		return jdbcTemplate.query(sql, new DashboardAlertsRowMapper());
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public List<DashboardAlerts> loadSameAlerts(DashboardAlerts valueObject) throws SQLException {
		String sql = "SELECT * FROM DashboardAlerts WHERE SERVER = ? and COMPONENT = ? and APPLICATION = ? and MODULE = ? ORDER BY CREATIONTIME DESC ";
		return jdbcTemplate.query(sql, new Object[] {valueObject.getImpactedServer(), valueObject.getImpactedComponent(), valueObject.getImpactedApplication(), valueObject.getImpactedModule()}, new DashboardAlertsRowMapper());
	}

	@Override
	public void save(DashboardAlerts valueObject) {
		String sql = "UPDATE DashboardAlerts SET SERVER = ?, COMPONENT = ?, APPLICATION = ?, MODULE = ?, CREATIONTIME = ?, NEXUSCASEID = ?, ALERTID = ? WHERE (ID = ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getImpactedServer(), valueObject.getImpactedComponent(), valueObject.getImpactedApplication(), valueObject.getImpactedModule()});
	}
	
	public void updateNexusCaseId(DashboardAlerts valueObject) {
		String sql = "UPDATE DashboardAlerts SET NEXUSCASEID = ? WHERE (ID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getNexusCaseId(), valueObject.getAlertId()});
	}
}
