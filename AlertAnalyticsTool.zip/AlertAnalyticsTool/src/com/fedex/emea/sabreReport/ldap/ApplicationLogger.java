package com.fedex.emea.sabreReport.ldap;

import org.apache.log4j.Logger;

public class ApplicationLogger implements LoggingInterface {
	
	private Logger LogDebug = Logger.getLogger("Evaluation_DebugLogger");
	private Logger LogInfo = Logger.getLogger("Evaluation_InfoLogger");
	private Logger LogError = Logger.getLogger("Evaluation_ErrorLogger");
	private Logger LogFatal = Logger.getLogger("Evaluation_FatalLogger");
	

	 public static void getInstance()
	 {
		 
	 }
	@Override
	public void logInfo(String message) {
		LogInfo.info(message);
	}

	@Override
	public void logDebug(String message) {
		LogDebug.debug(message);
	}

	@Override
	public void logError(String message) {
		LogError.error(message);
	}

	@Override
	public void logException(String message, Exception e) {
		LogError.error(message, e);
	}
	
	@Override
	public void logFatal(String message) {
		LogFatal.fatal(message);
	}

}
