package com.fedex.emea.sabreReport.model;

public class UserProfile {

}
