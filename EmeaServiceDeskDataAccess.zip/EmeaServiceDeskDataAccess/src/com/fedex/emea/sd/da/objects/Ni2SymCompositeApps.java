package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.List;

import com.fedex.emea.sd.da.objects.PrAudits;
import com.fedex.emea.sd.da.objects.PrCorrActions;
import com.fedex.emea.sd.da.objects.PrMitigations;
import com.fedex.emea.sd.da.objects.PrSymphonyApps;

public class Ni2SymCompositeApps implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String id;
	private String name;
	private String classification;
	private String role;
	private String location;
	private String businessCriticality;
	private String respMgrName;
	private String respMgrPin;
	private String respMdName;
	private String respMdPin;
	private String respPhoneActing;
	private String supportMgrName;
	private String symProfile;
	private String owner;
	private String description;
	private String comments;
	private String symEaiId;
	private String symAppName;
	private String symProfName;
	private String symItLead;
	private String symProjDispo;
	private String symDomain;
	private String symTier;
	private String symAppState;
	private String symFrmwrk;
	private String symDwnImp;
	private String symAvgTxDay;
	private String symRpo;
	private String symRto;
	private String symAccessTyp;
	private String symPlatform;
	private String symArchDsgn;
	private String symBacklogMeth;
	private String symBusFunc;
	private String symExtUsr;
	private String symIntUsr;
	private String symReglLegalFlg;
	private List<PrSymphonyApps> symAppsList;
	private List<PrAudits>       auditsList;
	private List<PrMitigations>  mitigationsList;
	private List<PrCorrActions>  corrActionsList;
	private PrSymphonyApps symhonyApp;
	private PrAudits       auditData;
	
	public Ni2SymCompositeApps() {
	}
	
	public Ni2SymCompositeApps(Ni2SymCompositeApps app, PrSymphonyApps symApp) {
		this.setId(app.getId());
		this.setName(app.getName());
		this.setClassification(app.getClassification());
		this.setRole(app.getRole());
		this.setLocation(app.getLocation());
		this.setBusinessCriticality(app.getBusinessCriticality());
		this.setRespMgrName(app.getRespMgrName());
		this.setRespMgrPin(app.getRespMgrPin());
		this.setRespMdName(app.getRespMdName());
		this.setRespMdPin(app.getRespMdPin());
		this.setRespPhoneActing(app.getRespPhoneActing());
		this.setSupportMgrName(app.getSupportMgrName());
		this.setSymProfile(app.getSymProfName());
		this.setOwner(app.getOwner());
		this.setDescription(app.getDescription());
		this.setComments(app.getComments());
		
		this.setSymEaiId(symApp.getSymEaiId());
		this.setSymAppName(symApp.getSymAppName());
		this.setSymProfName(symApp.getSymProfName());
		this.setSymItLead(symApp.getSymItLead());
		this.setSymProjDispo(symApp.getSymProjDispo());
		this.setSymDomain(symApp.getSymDomain());
		this.setSymTier(symApp.getSymTier());
		this.setSymAppState(symApp.getSymAppState());
		this.setSymFrmwrk(symApp.getSymFrmwrk());
		this.setSymDwnImp(symApp.getSymDwnImp());
		this.setSymAvgTxDay(symApp.getSymAvgTxDay());
		this.setSymRpo(symApp.getSymRpo());
		this.setSymRto(symApp.getSymRto());
		this.setSymAccessTyp(symApp.getSymAccessTyp());
		this.setSymPlatform(symApp.getSymPlatform());
		this.setSymArchDsgn(symApp.getSymArchDsgn());
		this.setSymBacklogMeth(symApp.getSymBacklogMeth());
		this.setSymBusFunc(symApp.getSymBusFunc());
		this.setSymExtUsr(symApp.getSymExtUsr());
		this.setSymIntUsr(symApp.getSymIntUsr());
		this.setSymReglLegalFlg(symApp.getSymReglLegalFlg());
		
		this.setSymAppsList(app.symAppsList);
		this.setAuditsList(app.auditsList);
		this.setMitigationsList(app.mitigationsList);
		this.setCorrActionsList(app.corrActionsList);
	}
	
	public Ni2SymCompositeApps(Ni2SymCompositeApps app) {
		this.setId(app.getId());
		this.setName(app.getName());
		this.setClassification(app.getClassification());
		this.setRole(app.getRole());
		this.setLocation(app.getLocation());
		this.setBusinessCriticality(app.getBusinessCriticality());
		this.setRespMgrName(app.getRespMgrName());
		this.setRespMgrPin(app.getRespMgrPin());
		this.setRespMdName(app.getRespMdName());
		this.setRespMdPin(app.getRespMdPin());
		this.setRespPhoneActing(app.getRespPhoneActing());
		this.setSupportMgrName(app.getSupportMgrName());
		this.setSymProfile(app.getSymProfName());
		this.setOwner(app.getOwner());
		this.setDescription(app.getDescription());
		this.setComments(app.getComments());
		
		this.setSymEaiId("N/A");
		this.setSymAppName("N/A");
		this.setSymProfName("N/A");
		this.setSymItLead("N/A");
		this.setSymProjDispo("N/A");
		this.setSymDomain("N/A");
		this.setSymTier("N/A");
		this.setSymAppState("N/A");
		this.setSymFrmwrk("N/A");
		this.setSymDwnImp("N/A");
		this.setSymAvgTxDay("N/A");
		this.setSymRpo("N/A");
		this.setSymRto("N/A");
		this.setSymAccessTyp("N/A");
		this.setSymPlatform("N/A");
		this.setSymArchDsgn("N/A");
		this.setSymBacklogMeth("N/A");
		this.setSymBusFunc("N/A");
		this.setSymExtUsr("N/A");
		this.setSymIntUsr("N/A");
		this.setSymReglLegalFlg("N/A");
		
		this.setSymAppsList(app.symAppsList);
		this.setAuditsList(app.auditsList);
		this.setMitigationsList(app.mitigationsList);
		this.setCorrActionsList(app.corrActionsList);
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getClassification() {
		return classification;
	}
	public void setClassification(String classification) {
		this.classification = classification;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getBusinessCriticality() {
		return businessCriticality;
	}
	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}
	public String getRespMgrName() {
		return respMgrName;
	}
	public void setRespMgrName(String respMgrName) {
		this.respMgrName = respMgrName;
	}
	public String getRespPhoneActing() {
		return respPhoneActing;
	}
	public void setRespPhoneActing(String respPhoneActing) {
		this.respPhoneActing = respPhoneActing;
	}
	public String getSupportMgrName() {
		return supportMgrName;
	}
	public void setSupportMgrName(String supportMgrName) {
		this.supportMgrName = supportMgrName;
	}
	public String getSymProfile() {
		return symProfile;
	}
	public void setSymProfile(String symProfile) {
		this.symProfile = symProfile;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSymEaiId() {
		return symEaiId;
	}
	public void setSymEaiId(String symEaiId) {
		this.symEaiId = symEaiId;
	}
	public String getSymAppName() {
		return symAppName;
	}
	public void setSymAppName(String symAppName) {
		this.symAppName = symAppName;
	}
	public String getSymProfName() {
		return symProfName;
	}
	public void setSymProfName(String symProfName) {
		this.symProfName = symProfName;
	}
	public String getSymItLead() {
		return symItLead;
	}
	public void setSymItLead(String symItLead) {
		this.symItLead = symItLead;
	}
	public String getSymProjDispo() {
		return symProjDispo;
	}
	public void setSymProjDispo(String symProjDispo) {
		this.symProjDispo = symProjDispo;
	}
	public String getSymDomain() {
		return symDomain;
	}
	public void setSymDomain(String symDomain) {
		this.symDomain = symDomain;
	}
	public String getSymTier() {
		return symTier;
	}
	public void setSymTier(String symTier) {
		this.symTier = symTier;
	}
	public String getSymAppState() {
		return symAppState;
	}
	public void setSymAppState(String symAppState) {
		this.symAppState = symAppState;
	}
	public String getSymFrmwrk() {
		return symFrmwrk;
	}
	public void setSymFrmwrk(String symFrmwrk) {
		this.symFrmwrk = symFrmwrk;
	}
	public String getSymDwnImp() {
		return symDwnImp;
	}
	public void setSymDwnImp(String symDwnImp) {
		this.symDwnImp = symDwnImp;
	}
	public String getSymAvgTxDay() {
		return symAvgTxDay;
	}
	public void setSymAvgTxDay(String symAvgTxDay) {
		this.symAvgTxDay = symAvgTxDay;
	}
	public String getSymRpo() {
		return symRpo;
	}
	public void setSymRpo(String symRpo) {
		this.symRpo = symRpo;
	}
	public String getSymRto() {
		return symRto;
	}
	public void setSymRto(String symRto) {
		this.symRto = symRto;
	}
	public String getSymAccessTyp() {
		return symAccessTyp;
	}
	public void setSymAccessTyp(String symAccessTyp) {
		this.symAccessTyp = symAccessTyp;
	}
	public String getSymPlatform() {
		return symPlatform;
	}
	public void setSymPlatform(String symPlatform) {
		this.symPlatform = symPlatform;
	}
	public String getSymArchDsgn() {
		return symArchDsgn;
	}
	public void setSymArchDsgn(String symArchDsgn) {
		this.symArchDsgn = symArchDsgn;
	}
	public String getSymBacklogMeth() {
		return symBacklogMeth;
	}
	public void setSymBacklogMeth(String symBacklogMeth) {
		this.symBacklogMeth = symBacklogMeth;
	}
	public String getSymBusFunc() {
		return symBusFunc;
	}
	public void setSymBusFunc(String symBusFunc) {
		this.symBusFunc = symBusFunc;
	}
	public String getSymExtUsr() {
		return symExtUsr;
	}
	public void setSymExtUsr(String symExtUsr) {
		this.symExtUsr = symExtUsr;
	}
	public String getSymIntUsr() {
		return symIntUsr;
	}
	public void setSymIntUsr(String symIntUsr) {
		this.symIntUsr = symIntUsr;
	}
	public String getSymReglLegalFlg() {
		return symReglLegalFlg;
	}
	public void setSymReglLegalFlg(String symReglLegalFlg) {
		this.symReglLegalFlg = symReglLegalFlg;
	}
	public String getRespMgrPin() {
		return respMgrPin;
	}
	public void setRespMgrPin(String respMgrPin) {
		this.respMgrPin = respMgrPin;
	}
	public String getRespMdName() {
		return respMdName;
	}
	public void setRespMdName(String respMdName) {
		this.respMdName = respMdName;
	}
	public String getRespMdPin() {
		return respMdPin;
	}
	public void setRespMdPin(String respMdPin) {
		this.respMdPin = respMdPin;
	}
	public List<PrAudits> getAuditsList() {
		return auditsList;
	}
	public void setAuditsList(List<PrAudits> auditsList) {
		this.auditsList = auditsList;
	}
	public List<PrMitigations> getMitigationsList() {
		return mitigationsList;
	}
	public void setMitigationsList(List<PrMitigations> mitigationsList) {
		this.mitigationsList = mitigationsList;
	}
	public List<PrCorrActions> getCorrActionsList() {
		return corrActionsList;
	}
	public void setCorrActionsList(List<PrCorrActions> corrActionsList) {
		this.corrActionsList = corrActionsList;
	}
	public List<PrSymphonyApps> getSymAppsList() {
		return symAppsList;
	}
	public void setSymAppsList(List<PrSymphonyApps> symAppsList) {
		this.symAppsList = symAppsList;
	}
	
	public PrSymphonyApps getSymhonyApp() {
		return symhonyApp;
	}

	public void setSymhonyApp(PrSymphonyApps symhonyApp) {
		this.symhonyApp = symhonyApp;
	}

	public PrAudits getAuditData() {
		return auditData;
	}

	public void setAuditData(PrAudits auditData) {
		this.auditData = auditData;
	}
	
}
