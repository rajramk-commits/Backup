package com.fedex.emea.sd.da.dao.spring;

import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrSpocsDao;
import com.fedex.emea.sd.da.exceptions.PrSpocsDaoException;
import com.fedex.emea.sd.da.objects.PrSpocs;
import com.fedex.emea.sd.da.objects.PrSpocsPk;

public class PrSpocsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrSpocs>, PrSpocsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSpocsPk
	 */
	@Transactional
	public PrSpocsPk insert(PrSpocs dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_SYSID, MGR_SYSID, ORG ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getMdPin(),dto.getMdName(),dto.getMgrPin(),dto.getMgrName(),dto.getSpocPin(),dto.getSpocName(),dto.getAuditStatus(),dto.getMitigReady(),dto.getMitigStatus(),dto.getCorractReady(),dto.getCorractStatus(),dto.getValtestStatus(),dto.getMdSysId(),dto.getMgrSysId(),dto.getOrg());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_SPOCS table.
	 */
	@Transactional
	public void update(PrSpocsPk pk, PrSpocs dto) throws PrSpocsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET MD_PIN = ?, MD_NAME = ?, MGR_PIN = ?, MGR_NAME = ?, SPOC_PIN = ?, SPOC_NAME = ?, AUDIT_STATUS = ?, MITIG_READY = ?, MITIG_STATUS = ?, CORRACT_READY = ?, CORRACT_STATUS = ?, VALTEST_STATUS = ?, MD_MAIL = ?, MGR_MAIL = ?, MD_SYSID = ?, MGR_SYSID = ?, ORG = ? WHERE MD_PIN = ? AND MGR_PIN = ?",dto.getMdPin(),dto.getMdName(),dto.getMgrPin(),dto.getMgrName(),dto.getSpocPin(),dto.getSpocName(),dto.getAuditStatus(),dto.getMitigReady(),dto.getMitigStatus(),dto.getCorractReady(),dto.getCorractStatus(),dto.getValtestStatus(),dto.getMdMail(),dto.getMgrMail(),dto.getMdSysId(),dto.getMgrSysId(),dto.getOrg(),pk.getMdPin(),pk.getMgrPin());
	}

	/** 
	 * Deletes a single row in the PR_SPOCS table.
	 */
	@Transactional
	public void delete(PrSpocsPk pk) throws PrSpocsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE MD_PIN = ? AND MGR_PIN = ?",pk.getMdPin(),pk.getMgrPin());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrSpocs
	 */
	public PrSpocs mapRow(ResultSet rs, int row) throws SQLException
	{
		PrSpocs dto = new PrSpocs();
		dto.setMdPin( rs.getString( 1 ) );
		dto.setMdName( rs.getString( 2 ) );
		dto.setMgrPin( rs.getString( 3 ) );
		dto.setMgrName( rs.getString( 4 ) );
		dto.setSpocPin( rs.getString( 5 ) );
		dto.setSpocName( rs.getString( 6 ) );
		dto.setAuditStatus( rs.getString( 7 ) );
		dto.setMitigReady( rs.getString( 8 ) );
		dto.setMitigStatus( rs.getString( 9 ) );
		dto.setCorractReady( rs.getString( 10 ) );
		dto.setCorractStatus( rs.getString( 11 ) );
		dto.setValtestStatus( rs.getString( 12 ) );
		dto.setMdMail( rs.getString( 13 ) );
		dto.setMgrMail( rs.getString( 14 ) );
		dto.setMdSysId( rs.getString( 15 ) );
		dto.setMgrSysId( rs.getString( 16 ) );
		dto.setOrg( rs.getString( 17 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_SPOCS";
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_PIN = :mdPin AND MGR_PIN = :mgrPin'.
	 */
	@Transactional
	public PrSpocs findByPrimaryKey(String mdPin, String mgrPin) throws PrSpocsDaoException
	{
		try {
			List<PrSpocs> list = jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MD_PIN = ? AND MGR_PIN = ?", this,mdPin,mgrPin);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria ''.
	 */
	@Transactional
	public List<PrSpocs> findAll() throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " ORDER BY MD_PIN, MGR_PIN", this);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_PIN = :mdPin'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMdPinEquals(String mdPin) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MD_PIN = ? ORDER BY MD_PIN", this,mdPin);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MD_NAME = :mdName'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMdNameEquals(String mdName) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MD_NAME = ? ORDER BY MD_NAME", this,mdName);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MGR_PIN = :mgrPin'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMgrPinEquals(String mgrPin) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MGR_PIN = ? ORDER BY MGR_PIN", this,mgrPin);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MGR_NAME = :mgrName'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMgrNameEquals(String mgrName) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MGR_NAME = ? ORDER BY MGR_NAME", this,mgrName);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'SPOC_PIN = :spocPin'.
	 */
	@Transactional
	public List<PrSpocs> findWhereSpocPinEquals(String spocPin) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE SPOC_PIN = ? ORDER BY SPOC_PIN", this,spocPin);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'SPOC_NAME = :spocName'.
	 */
	@Transactional
	public List<PrSpocs> findWhereSpocNameEquals(String spocName) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE SPOC_NAME = ? ORDER BY SPOC_NAME", this,spocName);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'AUDIT_STATUS = :auditStatus'.
	 */
	@Transactional
	public List<PrSpocs> findWhereAuditStatusEquals(String auditStatus) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE AUDIT_STATUS = ? ORDER BY AUDIT_STATUS", this,auditStatus);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MITIG_READY = :mitigReady'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMitigReadyEquals(String mitigReady) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MITIG_READY = ? ORDER BY MITIG_READY", this,mitigReady);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'MITIG_STATUS = :mitigStatus'.
	 */
	@Transactional
	public List<PrSpocs> findWhereMitigStatusEquals(String mitigStatus) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE MITIG_STATUS = ? ORDER BY MITIG_STATUS", this,mitigStatus);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'CORRACT_READY = :corractReady'.
	 */
	@Transactional
	public List<PrSpocs> findWhereCorractReadyEquals(String corractReady) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE CORRACT_READY = ? ORDER BY CORRACT_READY", this,corractReady);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'CORRACT_STATUS = :corractStatus'.
	 */
	@Transactional
	public List<PrSpocs> findWhereCorractStatusEquals(String corractStatus) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE CORRACT_STATUS = ? ORDER BY CORRACT_STATUS", this,corractStatus);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SPOCS table that match the criteria 'VALTEST_STATUS = :valtestStatus'.
	 */
	@Transactional
	public List<PrSpocs> findWhereValtestStatusEquals(String valtestStatus) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE VALTEST_STATUS = ? ORDER BY VALTEST_STATUS", this,valtestStatus);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_SPOCS table that matches the specified primary-key value.
	 */
	public PrSpocs findByPrimaryKey(PrSpocsPk pk) throws PrSpocsDaoException
	{
		return findByPrimaryKey( pk.getMdPin(), pk.getMgrPin() );
	}
	
	@Transactional
	public List<PrSpocs> findWhereOrgEquals(String org) throws PrSpocsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT MD_PIN, MD_NAME, MGR_PIN, MGR_NAME, SPOC_PIN, SPOC_NAME, AUDIT_STATUS, MITIG_READY, MITIG_STATUS, CORRACT_READY, CORRACT_STATUS, VALTEST_STATUS, MD_MAIL, MGR_MAIL, MD_SYSID, MGR_SYSID, ORG FROM " + getTableName() + " WHERE ORG = ?", this,org);
		}
		catch (Exception e) {
			throw new PrSpocsDaoException("Query failed", e);
		}
		
	}

}
