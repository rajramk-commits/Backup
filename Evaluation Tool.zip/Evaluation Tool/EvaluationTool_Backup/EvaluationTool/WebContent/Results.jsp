<%@page import="com.fedex.emea.onlinequiz.objects.Role"%>
<%@page import="java.util.*"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.io.*"%>
<%@page import="java.nio.file.*"%>
<%@page import="java.nio.charset.*"%>
<jsp:useBean id="DAO" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page" />
<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<%     	
String useridddd = (String) session.getAttribute("Userid");

        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
		
        %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
<script type="text/javascript" language="javascript">
		window.history.forward();
		function noBack() {
			window.history.forward();
		}
		function openLoginMenu() {
			window.close("Results.jsp");
			window.open("Admin.jsp");
		}
		function evaluateRes(id)
		{
			window.open("ManagerEval.jsp?id="+id);		
		}
		function ViewRes(id)
		{
			window.open("ViewResult.jsp?id="+id);		
		}
	</script>
<style>
.main {
	margin-left: 10%;
	margin-right: 12%;
}

.head {
	height: 50px;
	background-color: #7030a0;
	margin: 0;
}

.logout {
	float: right;
	margin-right: 5%;
	background-color: #FF8C00;
	color: white;
	padding: 14px 20px;
	border: none;
	cursor: pointer;
}

.logout:hover {
	background-color: #4B0060;
}

.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

table {
	font-family: arial, sans-serif;
	border-collapse: collapse;
	width: 100%;
}

td, th {
	border: 1px solid #dddddd;
	text-align: left;
	padding: 8px;
}

tr:nth-child(even) {
	background-color: #dddddd;
}
</style>
</head>
<body>

	<div class="main">
		<div class="head">
			<center>
				<p
					style="font-family: Calibri; font-weight: 700; color: white; font-size: 20px; padding: 12px 0 0 0">FedEx
					Support - Results</p>
			</center>
		</div>

		<form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class="logout"
				style="margin-top: 6px; font-family: Calibri; font-size: 16px">Logout</button>
		</form>
		<div
			style="margin: 15px 0 0px 40px; font-family: Calibri; font-size: 16px">
			<b>Welcome :</b>
			<%=userID %>
		</div>
		<button class="home" onclick="openLoginMenu()">HOME</button>
		<br> <br>
		<%
		String dirName = "C:/Users/rajarama.kaniyoor/Documents/Evaluation Tool/Resources/";;
		String fileName = dirName+"ResultDB.txt";
		File file = new File(fileName);
		file.createNewFile();
		
		String uId = request.getParameter("uId");
		String result = "", score="";
		System.out.println("Res uId :"+uId);
		if(uId != null)
		{
			float  totMarks=0, max = 31;
			int mcqTot=0;
			System.out.println("mcqTotal :"+request.getParameter("mcqTotal"));
			
			if(request.getParameter("mcqTotal") != null)
			{
				try
				{
					mcqTot = Integer.parseInt(request.getParameter("mcqTotal"));
				}
				catch(NumberFormatException e){
					System.out.println(e);
				}
			}
			for (int i =1; i< 12;i++)
			{
				int mark=0;
				String var = request.getParameter("textMarks"+i);
				if(var != null && !var.trim().isEmpty())
				{
					try
					{
						mark = Integer.parseInt(var);
						System.out.println("mark :"+mark);
					}
					catch(NumberFormatException e){
						System.out.println(e);
					}
					totMarks += mark;
					System.out.println("Test Area :"+mark);
				}
			}
			totMarks = totMarks + mcqTot;
			System.out.println("totMarks :"+totMarks);
			float avg = (totMarks/max)*100;
			System.out.println("avg :"+avg);
			if (avg >= 80)
			{
				result = "PASS";
		    }
			else if (avg >0 && avg < 80)
			{
				result = "FAIL";
			}
			score = "Marks Obtained : " + totMarks  +"_Average : " + avg;
			List<String> newLines = new ArrayList<>();
			for (String line : Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8))
			{
				System.out.println("line :"+line);
			    if (line.contains(uId)) {
			    	String updatedLine = line.replace("PENDING", result+"_") + score;
			       	newLines.add(updatedLine);
			       	System.out.println("updatedLine :"+updatedLine);
			    } else {
			       newLines.add(line);
			    }
			}
			Files.write(Paths.get(fileName), newLines, StandardCharsets.UTF_8);
			
			// Write scores and result to User files
			String userFileName = dirName;
			boolean fileFound = false;
			File directoryPath = new File(dirName);
			String contents[] = directoryPath.list();
			for(int i=0; i<contents.length; i++) {
		         if(uId != null && contents[i].contains(uId))
		         {
		        	 userFileName+= contents[i];
		        	 fileFound = true;
		        	 break;
		         }
		      }
			
			System.out.println("userFileName :"+userFileName);
			
			if(fileFound)
			{
				List<String> scoreList = new ArrayList<String>();
				for (int i =1; i< 12; i++)
				{
					scoreList.add(request.getParameter("textMarks"+i));
				}
				System.out.println("scoreList :"+scoreList);
				
				File userFile = new File(userFileName);
				userFile.createNewFile();
			
				StringBuilder newFileSB = new StringBuilder();
				BufferedReader br = new BufferedReader(new FileReader(userFile));
				String st;
				int index = 0;
				
				while ((st = br.readLine()) != null)
				{
					System.out.println("User File st :"+st);
					if(st.contains("Result"))
						continue;
					if(st.contains("MCQ Total"))
					{
						newFileSB.append(" Total Marks : "+totMarks);
						newFileSB.append("\n Average : "+avg);
						newFileSB.append("\n Result : "+result);
						continue;
					}
					newFileSB.append(st);
					newFileSB.append("\n");
					if(st.contains("User Answer"))
					{
						System.out.println("st contians:"+st);
						newFileSB.append("\nMarks Obtained : "+scoreList.get(index)+"\n");
						++index;
					}
				}
				br.close();
				
				// Clear old file content
				if (userFile.exists()) {
				    RandomAccessFile raf = new RandomAccessFile(userFile, "rw");
				    raf.setLength(0);
				    raf.close();
				}
				System.out.println("newFileSB :"+newFileSB);
				
				//Write New content
				BufferedWriter bufferOut = new BufferedWriter(new FileWriter(userFile, false));
				bufferOut.write(newFileSB.toString());
				bufferOut.newLine();
				bufferOut.close();
			}
		}
		%>
			
		<table>
		<tr>
				<th>Teams</th>
				<th>Name</th>
				<th>Fedex ID</th>
				<th>Results</th>
				<th>Scores</th>
				<th>Action</th>
		</tr>
		<%
			BufferedReader br = new BufferedReader(new FileReader(file));
			String st;
			while ((st = br.readLine()) != null)
			{
				String[] fields = st.split("_");
				for(int i=0;i<fields.length; i++)
					System.out.println("fileds :"+fields[i]);
				%>
				<tr>
					<td><%=fields[0] %></td>
					<td><%=fields[1] %></td>
					<td><%=fields[2] %></td>
					<td><%=fields[3] %></td>
					<%
					String scoreDetails = "";
					try
					{
						%>
						<td>Total Marks : 31<br><%=fields[4] %><br><%=fields[5] %></td>
						<%
					}
					catch (Exception e)
					{
						System.out.println(e);
					}
					if(fields[3] != null && fields[3].equalsIgnoreCase("Pending"))
					{%>
						<td><button id="Evaluate" name="Evaluate" onclick="evaluateRes('<%=fields[2] %>')">Evaluate</button></td>
					<%}
					else if(fields[3] != null && ( fields[3].equalsIgnoreCase("Pass") || fields[3].equalsIgnoreCase("Fail")))
					{%>
						<td><button id="View" name="View" onclick="ViewRes('<%=fields[2] %>')">View</button></td>
					<%}
					%>
				</tr>
			<%}
			br.close();
		%>
		</table>
	</div>
	<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>
<%}%>