package com.fedex.emea.dimm.utils;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Decoder;


public class Test {

	public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {
		// TODO Auto-generated method stub
		
			Cipher cipher = Cipher.getInstance("AES");
			SecretKey aesKey = new SecretKeySpec(getCiphyerKey(), "AES");
			cipher.init(Cipher.DECRYPT_MODE, aesKey);
			BASE64Decoder base64decoder = new BASE64Decoder();
			String decryptedString = new String(cipher.doFinal(base64decoder.decodeBuffer("9ySj+efLtBGIZLEF0FEulJcNYrR8YdegVPQQ6QA+Xug=")));
			System.out.println(decryptedString);
			
			String todayDate = formatTimestampToString(getCurrentTimeInTimezone(), "dd-MMM-yy");
			System.out.println(todayDate);
		
	}
	public static byte[] getCiphyerKey() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MMdd-HHmmss");
	    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
	    return sdf.format(new Date(0)).getBytes();
	}

	
	
	
	public static Timestamp getCurrentTimeInTimezone() {
		Timestamp tm = null;
		Calendar cal = Calendar.getInstance();
		long timeMs = 0;
		int zoneOffset = 0;
		int dlOffset = 0;
		timeMs = cal.getTimeInMillis();
		
		if (!cal.getTimeZone().getDisplayName().equals("Central European Time")) {
			cal.setTimeZone(TimeZone.getTimeZone("Europe/Brussels"));
			zoneOffset = cal.get(Calendar.ZONE_OFFSET);
			dlOffset = cal.get(Calendar.DST_OFFSET);
			timeMs = timeMs + zoneOffset + dlOffset;
		}
		
		tm = new Timestamp(timeMs);
		return tm;
	}
	public static String formatTimestampToString(Timestamp dateToFormat, String stringFormat) {
		if (dateToFormat == null) return "";
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateToFormat);
		SimpleDateFormat sdf2 = new java.text.SimpleDateFormat(stringFormat);
		return sdf2.format(cal.getTime());
	}
	
	
}
