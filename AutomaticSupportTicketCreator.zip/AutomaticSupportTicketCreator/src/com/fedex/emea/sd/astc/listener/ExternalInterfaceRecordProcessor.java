package com.fedex.emea.sd.astc.listener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import com.fedex.emea.sd.astc.utils.ExternalDataConverter;
import com.fedex.emea.sd.bl.mailer.MailSender;
import com.fedex.emea.sd.bl.rulers.AstcBusinessLogic;
import com.fedex.emea.sd.da.dao.AlertMailingListsDao;
import com.fedex.emea.sd.da.dao.ExternalInterfaceDao;
import com.fedex.emea.sd.da.dao.OvoMessagesDao;
import com.fedex.emea.sd.da.helpers.ApplicationParameters;
import com.fedex.emea.sd.da.helpers.Constants;
import com.fedex.emea.sd.da.logger.ApplicationLogger;
import com.fedex.emea.sd.da.objects.ExternalInterface;
import com.fedex.emea.sd.da.objects.MailTemplates;
import com.fedex.emea.sd.da.objects.OvoMessages;
import com.fedex.emea.sd.snow.manager.SnowRequestor;
import com.fedex.emea.sd.snow.objects.SnowAstcIncident;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowIncidentWorkNote;
import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class ExternalInterfaceRecordProcessor {
	
	private boolean               IN_PRODUCTION;
	private boolean               IS_EPDSM;
	
	private ExternalInterfaceDao  externalInterfaceDao;
	private AlertMailingListsDao  alertMailingListsDao;
	private OvoMessagesDao        ovoMessagesDao;
	private ApplicationParameters applicationParameters;
	private AstcBusinessLogic     businessLogic;
	private ExternalInterface     externalInterfaceRecord;
	private String                failureMessage;
	private String                moduleName;
	private ApplicationLogger     logger;
	
	private SnowRequestor         snowRequestor;
	private SnowIncident          snowIncident;
	
	private ExternalDataConverter externalDataConverter;
	
	public ExternalInterfaceRecordProcessor(SnowRequestor snowRequestor, ExternalDataConverter edc, ExternalInterfaceDao externalInterfaceDao, AlertMailingListsDao alertMailingListsDao, OvoMessagesDao ovoMessagesDao, ApplicationLogger logger, ApplicationParameters applicationParameters, boolean productionStatus, boolean isEPDSM) {
		this.externalInterfaceDao  = externalInterfaceDao;
		this.ovoMessagesDao        = ovoMessagesDao;
		this.alertMailingListsDao  = alertMailingListsDao;
		this.logger                = logger;
		this.applicationParameters = applicationParameters;
		this.snowRequestor         = snowRequestor;
		this.externalDataConverter = edc;
		this.IN_PRODUCTION         = productionStatus;
		this.IS_EPDSM              = isEPDSM;
	}
	
	// ================================================================================================
	// Process EXTERNAL_INTERFACE Record
	//
	public void process(ExternalInterface externalInterfaceCurrentRecord) throws Exception {
		
		logger.logInfo("Alert ID " + externalInterfaceCurrentRecord.getAlertId() + " - Processing...");
		
		try {
			businessLogic = new AstcBusinessLogic(externalInterfaceCurrentRecord);
			
			this.externalInterfaceRecord = businessLogic.getExternalInterfaceRecord();
			
			if (IS_EPDSM) {
				if (businessLogic.ADD_TICKET_NOTE) {
					doAddWorkNoteEPDSM();
				} else {
					if (businessLogic.CREATE_TICKET) {
						doTicketCreationEPDSM();
					} else {
						updateRecordStatus(Constants.COMPLETED);
						logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Skipped Record (" + externalInterfaceRecord.getRecordSource() + ")");
					}
				}
			} else {
				if (businessLogic.ADD_TICKET_NOTE) {
					doAddWorkNote();
				} else {
					if (businessLogic.CREATE_TICKET) {
						doTicketCreation();
					} else {
						updateRecordStatus(Constants.COMPLETED);
						logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Skipped Record (" + externalInterfaceRecord.getRecordSource() + ")");
					}
				}
			}			
		} catch (Exception ex) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to process External Interface record. Exception: " + ex.getMessage());
		}
				
		logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - End Processing (Incident = " + externalInterfaceRecord.getCaseId() + ")");
	}
	
	// ================================================================================================
	// Create new Ticket in EPDSM
	// 
	private void doTicketCreationEPDSM() throws Exception {
		
		SnowIncident     newIncident;
		
		SnowAstcIncident inputIncident     = null;
		SnowAstcIncident resultingIncident = null;
		String           returnedSysId     = null;

		try {

			inputIncident = createIncidentObjectForEPDSM(externalInterfaceRecord);
			
			// TODO To be decided - What are minimal Info to create Incident ????
			if (inputIncident.isValid()) {
				
				logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket creation...");
				
				resultingIncident = snowRequestor.createAstcIncident(inputIncident);
				returnedSysId     = resultingIncident.getSnowSysTargetSysId();
				newIncident       = snowRequestor.getIncidentBySysId(returnedSysId, "sys_id,short_description,number,severity,impact,urgency,priority,sys_created_on,opened_at,resolved_at,closed_at,state,business_service");
								
				String incidentSysId  = newIncident.getSnowSysId();
				String incidentNumber = newIncident.getSnowNumber();
				
				if (incidentSysId != null && !incidentSysId.trim().isEmpty()) {
					try {
						externalInterfaceRecord.setCaseSysId(incidentSysId);
						externalInterfaceRecord.setCaseId(incidentNumber);
						externalInterfaceDao.updateSysIdAndIncidentNumber(externalInterfaceRecord);
						
						// If OBM Alert => If PRODUCTION => Acknowledge in OBM & Update Case Id
						//
						if (businessLogic.OBM_ALERT) {
							OvoMessages ovoMsg = null;
							ovoMsg = ovoMessagesDao.getObject(externalInterfaceRecord.getRecordSourceId());
							ovoMsg.setNexusCaseId(incidentNumber);
							ovoMessagesDao.updateNexusCaseId(ovoMsg);

							if (IN_PRODUCTION) {
								boolean ackStatus = acknowledgeOvoAlert(ovoMsg.getOvoMessageId(), "Incident: " + externalInterfaceRecord.getCaseId(), "SDAUTO");
								if (!ackStatus) {
									handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to Acknowledge OVO Alert ("+ ovoMsg.getOvoMessageId() +") for Incident " + externalInterfaceRecord.getCaseId() + ". OVO Alert will remain visible.");
								}
							}
						}
						
						// Mail sent only for Tickets with BU=SDESK and Priority=HIGH
						//
						if (externalInterfaceRecord.getCaseBusinessUnit().equals(Constants.BU_SDESK) 
								&& externalInterfaceRecord.getCasePriority().equals(Constants.CASE_PRIORITY_HIGH)) {
							doMailing(Constants.COMPLETED);
						}
						
						// If SELF Service Ticket, mail sent to User
						//
						if (businessLogic.SELF_SERVICE) {
							List<String> mailToList = new ArrayList<String>();
							String userMail = externalInterfaceRecord.getRecordSourceId().substring(externalInterfaceRecord.getRecordSourceId().indexOf(":") + 1).trim();
							mailToList.add(userMail);
							doIndividualsMailing("SELF-CASE", mailToList, "New Incident Ticket " + externalInterfaceRecord.getCaseId() + " has been created");
						}
						
						updateRecordStatus(Constants.COMPLETED);
						logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket created.");
						
					} catch (Exception e) {
						handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to update Incident Id in External Interface DB Table (AlertId: " + externalInterfaceRecord.getAlertId() + "). Exception: " + e.getMessage());
						updateRecordStatus(Constants.ERROR);
					}					
				} else {
					handleException(Constants.ERROR, Thread.currentThread().getStackTrace()[1].getMethodName(), "Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to create Incident Ticket: Returned ID is null");
					updateRecordStatus(Constants.ERROR);
				}
				
			} else {
				logger.logWarn("Alert ID " + externalInterfaceRecord.getAlertId() + " - Invalid Incident Ticket data. Mandatory Fields missing");
				updateRecordStatus(Constants.ERROR);
			}
		} catch (IOException e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": IO Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		} catch (ClassNotFoundException e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": ClassNotFound Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		} catch (Exception e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		}
	}

	// ================================================================================================
	// Create new Ticket
	// 
	private void doTicketCreation() throws Exception {
		SnowIncident newIncident   = null;

		try {

			snowIncident = createServiceNowIncidentObject(externalInterfaceRecord);
			
			// TODO To be decided - What are minimal Info to create Ticket ????
			if (snowIncident.isValid()) {
				
				logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket creation...");
				
				newIncident = snowRequestor.createIncident(snowIncident);
				
				try {
					SnowIncidentWorkNote workNote = createServiceNowWorkNoteObject(newIncident.getSnowSysId(), SnowConstants.WORKNOTE_SUBJECT_COMMUNICATION, "Master Note: Incident created by Automatic Support Ticket Creator (ASTC)");					
					snowRequestor.createKingstonWorkNote(newIncident.getSnowSysId(), workNote.getWorkNoteText());					
				} catch (Exception ex) {
					logger.logWarn("Alert ID " + externalInterfaceRecord.getAlertId() + " - Cannot create Master Note for " + newIncident.getSnowNumber());
				}
				
				String incidentSysId  = newIncident.getSnowSysId();
				String incidentNumber = newIncident.getSnowNumber();
				
				if (incidentSysId != null && !incidentSysId.trim().isEmpty()) {
					try {
						externalInterfaceRecord.setCaseSysId(incidentSysId);
						externalInterfaceRecord.setCaseId(incidentNumber);
						externalInterfaceDao.updateSysIdAndIncidentNumber(externalInterfaceRecord);
						
						// If OVO Alert => If PRODUCTION => Acknowledge in OVO & Update Case Id
						//
						if (businessLogic.OBM_ALERT) {
							OvoMessages ovoMsg = null;
							ovoMsg = ovoMessagesDao.getObject(externalInterfaceRecord.getRecordSourceId());
							ovoMsg.setNexusCaseId(incidentNumber);
							ovoMessagesDao.updateNexusCaseId(ovoMsg);

							if (IN_PRODUCTION) {
								boolean ackStatus = acknowledgeOvoAlert(ovoMsg.getOvoMessageId(), "Incident: " + externalInterfaceRecord.getCaseId(), "SDAUTO");
								if (!ackStatus) {
									handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to Acknowledge OBM Alert ("+ ovoMsg.getOvoMessageId() +") for Incident " + externalInterfaceRecord.getCaseId() + ". OVO Alert will remain visible.");
								}
							}
						}
						
						// Mail sent only for Tickets with BU=SDESK and Priority=HIGH
						//
						if (externalInterfaceRecord.getCaseBusinessUnit().equals(Constants.BU_SDESK) 
								&& externalInterfaceRecord.getCasePriority().equals(Constants.CASE_PRIORITY_HIGH)) {
							doMailing(Constants.COMPLETED);
						}
						
						
						// If SELF Service Ticket, mail sent to User
						//
						if (businessLogic.SELF_SERVICE) {
							List<String> mailToList = new ArrayList<String>();
							String userMail = externalInterfaceRecord.getRecordSourceId().substring(externalInterfaceRecord.getRecordSourceId().indexOf(":") + 1).trim();
							mailToList.add(userMail);
							doIndividualsMailing("SELF-CASE", mailToList, "New Incident Ticket " + externalInterfaceRecord.getCaseId() + " has been created");
						}
						
						updateRecordStatus(Constants.COMPLETED);
						logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket created.");
						
					} catch (Exception e) {
						handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to update Incident Id in External Interface DB Table (AlertId: " + externalInterfaceRecord.getAlertId() + "). Exception: " + e.getMessage());
						updateRecordStatus(Constants.ERROR);
					}					
				} else {
					handleException(Constants.ERROR, Thread.currentThread().getStackTrace()[1].getMethodName(), "Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to create Incident Ticket: Returned ID is null");
					updateRecordStatus(Constants.ERROR);
				}
				
			} else {
				logger.logWarn("Alert ID " + externalInterfaceRecord.getAlertId() + " - Invalid Incident Ticket data. Mandatory Fields missing");
				updateRecordStatus(Constants.ERROR);
			}
		} catch (IOException e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": IO Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		} catch (ClassNotFoundException e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": ClassNotFound Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		} catch (Exception e) {
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": Exception : " + e.getMessage());
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Incident Ticket NOT created. See Error.log for details.");
			updateRecordStatus(Constants.ERROR);
		}
	}
	
	// ================================================================================================
	// Add Work Note in EPDSM
	// 
	private void doAddWorkNoteEPDSM() throws Exception {
		
		SnowAstcIncident inputIncident     = null;
		SnowAstcIncident resultingIncident = null;
		String           returnedSysId     = null;
		
		String           description      = null;
		boolean          isOBM            = false;
		boolean          isAlreadyClosed  = false;
		boolean          isHighNotHandled = false;
		int              indexON          = 0;
		String           summaryDateTime  = null;
		
		try {
			
			snowIncident = snowRequestor.getIncidentBySysId(externalInterfaceRecord.getCaseSysId(), "sys_id,number,state,priority");
			
			if (snowIncident != null) {
				description = externalInterfaceRecord.getCaseDescription1();
				isOBM = description.contains("OBM");
				isAlreadyClosed = snowIncident.getSnowState().equals(SnowConstants.STATE_EPDSM_RESOLVED) || 
						          snowIncident.getSnowState().equals(SnowConstants.STATE_EPDSM_CLOSED) || snowIncident.getSnowState().equals(SnowConstants.STATE_EPDSM_CANCELED) ;
				isHighNotHandled = snowIncident.getSnowState().equals(SnowConstants.STATE_EPDSM_NEW) &&
						           snowIncident.getSnowPriority().equals(SnowConstants.PRIORITY_EPDSM_HIGH);
				
				// If Incident OBM and already CLOSED or RESOLVED, then Create a New Incident
				// Else Add a Work Note
				//
				if (isOBM && isAlreadyClosed) {
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Attempt to Add Work Note for Closed Incident ("+ externalInterfaceRecord.getCaseId() +"). New Incident will be created.");
					
					indexON = description.indexOf("on");
					if (indexON > 0) {
						summaryDateTime = description.substring(indexON, indexON + 25);
					} else {
						summaryDateTime = "same as " + externalInterfaceRecord.getCaseId();
					}
					externalInterfaceRecord.setRecordSource("OBM");
					externalInterfaceRecord.setCaseSummary("GA/OBM Alert " + summaryDateTime + " GMT");
					externalInterfaceRecord.setCaseId("");
					externalInterfaceRecord.setCaseSysId("");
					externalInterfaceRecord.setProcessedTime(null);

					externalInterfaceDao.updateAddNoteToNew(externalInterfaceRecord);
					
					// Change BusinessLogic as it's now CREATE_TICKET for OVO_ALERT
					//
					businessLogic.ADD_TICKET_NOTE = false;
					businessLogic.CREATE_TICKET   = true;
					businessLogic.OBM_ALERT       = true;
					
					doTicketCreationEPDSM();
				} else {
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Adding Work Note (Incident: "+ externalInterfaceRecord.getCaseId() +") ...");
					
					StringBuilder workNoteText = new StringBuilder();
					workNoteText.append(externalInterfaceRecord.getCaseSummary() + System.lineSeparator() + System.lineSeparator());
					workNoteText.append(externalInterfaceRecord.getCaseDescription().toString());
					
					inputIncident = new SnowAstcIncident();
					inputIncident.setSnowSysTargetSysId(snowIncident.getSnowSysId());
					inputIncident.setSnowU_Number(snowIncident.getSnowNumber());
					inputIncident.setSnowU_WorkNotes(workNoteText.toString());
					
					resultingIncident = snowRequestor.updateAstcIncident(inputIncident);
					returnedSysId     = resultingIncident.getSnowSysTargetSysId();
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note added (Incident: "+ snowIncident.getSnowNumber() +" - " + returnedSysId + ").");
					
					// If OVO Alert available => Acknowledge
					//
					OvoMessages ovoMsg = ovoMessagesDao.getObject(externalInterfaceRecord.getRecordSourceId());
					if ((ovoMsg != null) && (!ovoMsg.getOvoMessageId().trim().equals(""))) {	
						boolean ackStatus = acknowledgeOvoAlert(ovoMsg.getOvoMessageId(), "Incident: " + externalInterfaceRecord.getCaseId(), "SDAUTO");
						if (!ackStatus) {
							handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to Acknowledge OBM Alert ("+ ovoMsg.getOvoMessageId() +") for Incident " + externalInterfaceRecord.getCaseId() + ". OVO Alert will remain visible.");
						}
					}
					
					// If Incident already exists and is still Registered and Priority=High
					// => Send Reminder Mail
					//  
					if (isHighNotHandled) doMailing(Constants.REMINDER);
					
					updateRecordStatus(Constants.COMPLETED);
				}
			} else {
				logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note NOT added (Incident ID does not exist).");
				updateRecordStatus(Constants.COMPLETED);
			}			
		} catch (Exception e) {
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note NOT added (Incident: "+ externalInterfaceRecord.getCaseId() +"). See Error.log for details");
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to add Work Note for Incident " + externalInterfaceRecord.getCaseId() + " - Exception : " + e.getMessage());
			updateRecordStatus(Constants.ERROR);
		}
		
	}
	
	// ================================================================================================
	// Add Work Note
	// 
	private void doAddWorkNote() throws Exception {
		
		String  description     = null;
		boolean isOBM           = false;
		int     indexON         = 0;
		String  summaryDateTime = null;
		
		try {
			
			snowIncident = snowRequestor.getIncidentBySysId(externalInterfaceRecord.getCaseSysId(), "sys_id,number,state,priority");
			
			if (snowIncident != null) {
				description = externalInterfaceRecord.getCaseDescription1();
				isOBM = description.contains("OBM");
				
				// If Incident OVO and already CLOSED or RESOLVED, then Create a New Incident
				// Else Add a Work Note
				//
				if (isOBM && (snowIncident.getSnowState().equals(SnowConstants.STATE_RESOLVED) 
						|| snowIncident.getSnowState().equals(SnowConstants.STATE_CLOSED))) {
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Attempt to Add Work Note for Closed Incident ("+ externalInterfaceRecord.getCaseId() +"). New Incident will be created.");
					
					indexON = description.indexOf("on");
					if (indexON > 0) {
						summaryDateTime = description.substring(indexON, indexON + 25);
					} else {
						summaryDateTime = "same as " + externalInterfaceRecord.getCaseId();
					}
					externalInterfaceRecord.setRecordSource("OBM");
					externalInterfaceRecord.setCaseSummary("GA/OBM Alert " + summaryDateTime + " GMT");
					externalInterfaceRecord.setCaseId("");
					externalInterfaceRecord.setCaseSysId("");
					externalInterfaceRecord.setProcessedTime(null);

					externalInterfaceDao.updateAddNoteToNew(externalInterfaceRecord);
					
					// Change BusinessLogic as it's now CREATE_TICKET for OVO_ALERT
					//
					businessLogic.ADD_TICKET_NOTE = false;
					businessLogic.CREATE_TICKET   = true;
					businessLogic.OBM_ALERT       = true;
					
					doTicketCreation();
				} else {
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Adding Work Note (Incident: "+ externalInterfaceRecord.getCaseId() +") ...");
					
					StringBuilder workNoteText = new StringBuilder();
					workNoteText.append(externalInterfaceRecord.getCaseSummary() + System.lineSeparator() + System.lineSeparator());
					workNoteText.append(externalInterfaceRecord.getCaseDescription().toString());
					
					SnowIncidentWorkNote workNote = createServiceNowWorkNoteObject(externalInterfaceRecord.getCaseSysId(), SnowConstants.WORKNOTE_SUBJECT_COMMUNICATION, workNoteText.toString());					
					snowRequestor.createKingstonWorkNote(externalInterfaceRecord.getCaseSysId(), workNote.getWorkNoteText());
					
					logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note added (Incident: "+ externalInterfaceRecord.getCaseId() +").");
					
					// If OVO Alert available => Acknowledge
					//
					OvoMessages ovoMsg = ovoMessagesDao.getObject(externalInterfaceRecord.getRecordSourceId());
					if ((ovoMsg != null) && (!ovoMsg.getOvoMessageId().trim().equals(""))) {	
						boolean ackStatus = acknowledgeOvoAlert(ovoMsg.getOvoMessageId(), "Incident: " + externalInterfaceRecord.getCaseId(), "SDAUTO");
						if (!ackStatus) {
							handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to Acknowledge OBM Alert ("+ ovoMsg.getOvoMessageId() +") for Incident " + externalInterfaceRecord.getCaseId() + ". OVO Alert will remain visible.");
						}
					}
					
					// If Incident already exists and is still Registered and Priority=High
					// => Send Reminder Mail
					//  
					if (snowIncident.getSnowState().equals(SnowConstants.STATE_REGISTERED)
							&& snowIncident.getSnowPriority().equals(SnowConstants.PRIORITY_HIGH)) {
						doMailing(Constants.REMINDER);
					}
					updateRecordStatus(Constants.COMPLETED);
				}
			} else {
				logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note NOT added (Incident ID does not exist).");
				updateRecordStatus(Constants.COMPLETED);
			}			
		} catch (Exception e) {
			logger.logInfo("Alert ID " + externalInterfaceRecord.getAlertId() + " - Work Note NOT added (Incident: "+ externalInterfaceRecord.getCaseId() +"). See Error.log for details");
			handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to add Work Note for Incident " + externalInterfaceRecord.getCaseId() + " - Exception : " + e.getMessage());
			updateRecordStatus(Constants.ERROR);
		}
		
	}
		
	// ================================================================================================
	// Create new ServiceNow Incident Object based on EXTERNAL_INTERFACE record
	//
	private SnowIncident createServiceNowIncidentObject(ExternalInterface eiRecord) {
		SnowIncident incident = new SnowIncident();		
		externalDataConverter.setEiRecord(eiRecord);

		// If Record Source is Self-NPF, Sub-Category is User Incident, else is Event
		//
		if (eiRecord.getRecordSource().equals(Constants.SELF_SERVICE_NPF)) {
			incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_USER);
		} else {
			incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
		}
		
		incident.setSnowShortDescription(eiRecord.getCaseSummary());
		incident.setSnowDescription(eiRecord.getCaseDescription().toString());
		
		// Set ServiceNow values based on OLD NEXUS values from EXTERNAL_INTERFACE
		//
		incident.setSnowCategory(externalDataConverter.getSnowCategory());
		incident.setSnowState(externalDataConverter.getSnowState());
		incident.setSnowPriority(externalDataConverter.getSnowPriority());
		incident.setSnowImpact(externalDataConverter.getSnowImpact());
		incident.setSnowUrgency(externalDataConverter.getSnowUrgency());
		incident.setSnowSeverity(externalDataConverter.getSnowSeverity());
		incident.setSnowAssignmentGroup(externalDataConverter.getSnowAssignmentGroup());
		incident.setSnowU_Instructions(externalDataConverter.getSnowU_Instructions());
		incident.setSnowContactType(externalDataConverter.getSnowContactType());
		
		// TODO To be decided by "someone" - Value Mapping  ???????????????????????????
		incident.setSnowU_Classification(externalDataConverter.getSnowU_Classification());
		incident.setSnowU_BusinessService(externalDataConverter.getSnowU_BusinessService());
		
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}
	
	// ================================================================================================
	// Create new EPDSM Incident Object based on EXTERNAL_INTERFACE record
	//
	private SnowAstcIncident createIncidentObjectForEPDSM(ExternalInterface eiRecord) {
		SnowAstcIncident incident = new SnowAstcIncident();		
		externalDataConverter.setEiRecord(eiRecord);
		
		incident.setSnowU_ShortDescription(eiRecord.getCaseSummary());
		incident.setSnowU_Description(eiRecord.getCaseDescription().toString());
		
		// Set EPDSM values based on OLD NEXUS values from EXTERNAL_INTERFACE
		//
		incident.setSnowU_Caller("92a585a513289300f920b6f36144b019");		// Fix value
		incident.setSnowU_Category(externalDataConverter.getSnowCategory());
		incident.setSnowU_State(externalDataConverter.getSnowState());
		incident.setSnowU_Impact(externalDataConverter.getSnowImpact());
		incident.setSnowU_Urgency(externalDataConverter.getSnowUrgency());
		incident.setSnowU_AssignmentGroup(externalDataConverter.getSnowAssignmentGroup());
		incident.setSnowU_Instructions(externalDataConverter.getSnowU_Instructions());
		incident.setSnowU_ContactType(externalDataConverter.getSnowContactType());
		incident.setSnowU_WorkNotes("Master Note: Incident created by Automatic Support Ticket Creator (ASTC)");
		
		// TODO To be decided by "someone" - Value Mapping  ???????????????????????????
		incident.setSnowU_Classification(externalDataConverter.getSnowU_Classification());
		incident.setSnowU_BusinessService(externalDataConverter.getSnowU_BusinessService());
		
		return incident;
	}
	
	// ================================================================================================
	// Create new Work Note Object
	//
	private SnowIncidentWorkNote createServiceNowWorkNoteObject(String sysId, String subject, String noteText) {
		SnowIncidentWorkNote workNote = new SnowIncidentWorkNote();
		
		workNote.setWorkNoteElement("work_notes");
		workNote.setWorkNoteElementId(sysId);
		workNote.setWorkNoteName("task");
		workNote.setWorkNoteValue("");
		workNote.setWorkNoteSubject(subject);
		workNote.setWorkNoteText(noteText);
		
		return workNote;
	}
	
	// ================================================================================================
	// Send Mail to Individuals
	//
	private void doIndividualsMailing(String mailType, List<String> mailToList, String mailSubject) {
		StringBuffer mailContent = null;
		
		MailSender mailSender = new MailSender(applicationParameters.getParameter(Constants.MAIL_SERVER_DNS), applicationParameters.getParameter(Constants.MAIL_SERVER_PORT));
		mailSender.setMailFrom(applicationParameters.getParameter(Constants.MAIL_NOTIFICATION_FROM));
		mailSender.setMailTos(mailToList);
		
		if (mailType.equals("SELF-CASE")) {
			mailContent = MailTemplates.createCaseCreatedUserMail(externalInterfaceRecord);
		}
		
		mailSender.setMailSubject(mailSubject);
		mailSender.setMailContent(mailContent.toString());
		try {
			mailSender.sendMail();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// ================================================================================================
	// Send Status Mail to Mailing List
	//
	private void doMailing(int status) {
		
		logger.logInfo("Mailing Starts.");
		
		StringBuffer mailContent = null;
		String       mailSubject = null;
		
		try {
			List<String> mailToListPerSource = new ArrayList<String>();
			if (IN_PRODUCTION) {
				//prv version
				/*if (externalInterfaceRecord.getRecordSource().contains(Constants.ANY_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.DASHBOARD_ALERT);
				} else {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(externalInterfaceRecord.getRecordSource());
				}*/
				
				if (externalInterfaceRecord.getRecordSource().contains(Constants.HUBSTACK_PROD_DASHBOARD)||externalInterfaceRecord.getRecordSource().contains(Constants.CDG_PROD_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.HUBSTACK_PROD_DASHBOARD);
					
				}
				else if (externalInterfaceRecord.getRecordSource().contains(Constants.GENIUS_PROD_DASHBOARD)||externalInterfaceRecord.getRecordSource().contains(Constants.EISTC_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.DE_PROD_DASHBOARD) || externalInterfaceRecord.getRecordSource().contains(Constants.GEMINI_PROD_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.GENIUS_PROD_DASHBOARD);
					
				}
				else if (externalInterfaceRecord.getRecordSource().contains(Constants.RIH_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.ITIH_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.CT_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.EDGE_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.SCM_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.MISC_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.POLAND_PROD_DASHBOARD)||
						externalInterfaceRecord.getRecordSource().contains(Constants.PRICING_PROD_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.ITIH_PROD_DASHBOARD);					
				}
				else if (externalInterfaceRecord.getRecordSource().contains(Constants.XSORT_PROD_DASHBOARD)){
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.XSORT_PROD_DASHBOARD);
				}
				else
				mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource("SD-Helpdesk");
//				mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource("JO");							
				
			} else {
				if (externalInterfaceRecord.getRecordSource().contains(Constants.HUBSTACK_PROD_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.HUBSTACK_PROD_DASHBOARD);
					
				}
				else if (externalInterfaceRecord.getRecordSource().contains(Constants.GENIUS_PROD_DASHBOARD)||externalInterfaceRecord.getRecordSource().contains(Constants.EISTC_PROD_DASHBOARD)
						|| externalInterfaceRecord.getRecordSource().contains(Constants.GEMINI_PROD_DASHBOARD)) {
					mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource(Constants.GENIUS_PROD_DASHBOARD);
					
				}
				else
				mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource("TEST");
//				mailToListPerSource  = alertMailingListsDao.getMailsByAlertSource("JO");
			}
			List<String> mailToListForFailure = alertMailingListsDao.getMailsByAlertSource("APP_OWNER");
			List<String> mailToListForError   = alertMailingListsDao.getMailsByAlertSource("APP_ERROR");
//			List<String> mailToListForFailure = alertMailingListsDao.getMailsByAlertSource("JO");
//			List<String> mailToListForError   = alertMailingListsDao.getMailsByAlertSource("JO");
									
			MailSender mailSender = new MailSender(applicationParameters.getParameter(Constants.MAIL_SERVER_DNS), applicationParameters.getParameter(Constants.MAIL_SERVER_PORT));
	
			mailSender.setMailFrom(applicationParameters.getParameter(Constants.MAIL_NOTIFICATION_FROM));
			
			if (status == Constants.COMPLETED) {
				mailSender.setMailTos(mailToListPerSource);
				logger.logInfo("Alert mailToListPerSource:"+mailToListPerSource);
				mailSubject = "ASTC Communication - ServiceNow Incident created: " + externalInterfaceRecord.getCaseId();
				mailContent = MailTemplates.createAlertMail(externalInterfaceRecord);
			} else {
				if (status == Constants.ERROR) {
					mailSender.setMailTos(mailToListForError);
					mailSubject = "ASTC Communication - ServiceNow Incident NOT created";
					mailContent = MailTemplates.createErrorMail(externalInterfaceRecord);
				} else {
					if (status == Constants.FAILURE) {
						mailSender.setMailTos(mailToListForFailure);
						mailSubject = "ASTC Application failure";
						mailContent = MailTemplates.createFailureMail(moduleName, failureMessage);
					} else {
						if (status == Constants.REMINDER) {
							mailSender.setMailTos(mailToListPerSource);
							logger.logInfo("Reminder mailToListPerSource:"+mailToListPerSource);
							mailSubject = "ASTC Communication - Existing ServiceNow Incident (" + externalInterfaceRecord.getCaseId() + ") not yet processed";
							mailContent = MailTemplates.createReminderMail(externalInterfaceRecord);
						} else {
							if (status == Constants.REOPEN) {
								mailSender.setMailTos(mailToListPerSource);
								mailSubject = "ASTC Communication - Solved ServiceNow Incident (" + externalInterfaceRecord.getCaseId() + ") to Re-Open";
								mailContent = MailTemplates.createReOpenMail(externalInterfaceRecord);
							} else {
								mailSender.setMailTos(mailToListForFailure);
								mailSubject = "ASTC Communication";
								mailContent = new StringBuffer("Generic Mail. No Status available.");
							}
						}
					}
				}
				
			}
			mailSender.setMailSubject(mailSubject);
			mailSender.setMailContent(mailContent.toString());
			mailSender.sendMail();
		} catch (Exception e) {
			logger.logError("Alert ID " + externalInterfaceRecord.getAlertId() + " - Failed to Send Mail. Exception: " + e.getMessage());
		}
	}
	
	// ================================================================================================
	// Update Record Status in EXTERNAL_INTERFACE
	//
	private void updateRecordStatus(int recordStatus) throws Exception {
			try {
				externalInterfaceRecord.setAlertProcessed(recordStatus);
				externalInterfaceDao.updateRecordStatus(externalInterfaceRecord);
			} catch (Exception e) { 
				handleException(Constants.FAILURE, Thread.currentThread().getStackTrace()[1].getMethodName(), "Failed to process External_Interface AlertId " + externalInterfaceRecord.getAlertId() + ": Cannot change Process status (updateRecordStatus) : " + e.getMessage());
				throw e;
			}
	}
	
	// ================================================================================================
	// Handle Exception by logging Error message and sending Error Mail
	//
	private void handleException(int level, String methodName, String exceptionMessage) {
		failureMessage = exceptionMessage;
		moduleName = methodName;
		logger.logError(failureMessage);
		doMailing(level);
	}
	
	// ================================================================================================
	// Shell process to ACK OVO Alert
	//
	private boolean acknowledgeOvoAlert(String ovoAlertId, String alertAnnot, String userId) {
		
		boolean returnStatus = true;
		
		if (IN_PRODUCTION) {
			String ovoServer  = applicationParameters.getParameter(Constants.OVO_SERVER);
			String annotCmd   = applicationParameters.getParameter(Constants.OVO_ANNOT_COMMAND);
			String ackCmd     = applicationParameters.getParameter(Constants.OVO_ACK_COMMAND);
			
			String sshAnnotCommand = "ssh " + ovoServer + " " + annotCmd + " " + ovoAlertId + " \"" + alertAnnot + "\"";
			String sshAckCommand   = "ssh " + ovoServer + " " + ackCmd   + " -u " + userId + " " + ovoAlertId;
			
			BufferedReader outReader = null;
			BufferedReader errorReader = null;
			StringBuffer output = new StringBuffer();
			StringBuffer error  = new StringBuffer();
			String line = "";
			int exitValue = 0;
			
			Process p;

			try {
				
				p = Runtime.getRuntime().exec(sshAnnotCommand);
				
				outReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
				while ((line = outReader.readLine())!= null) output.append(line + "\n");
				
				errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
				while ((line = errorReader.readLine())!= null) error.append(line + "\n");
							
				exitValue = p.waitFor();
				
				if (exitValue == 0) {
					p = Runtime.getRuntime().exec(sshAckCommand);
					outReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
					while ((line = outReader.readLine())!= null) output.append(line + "\n");
					
					errorReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
					while ((line = errorReader.readLine())!= null) error.append(line + "\n");
								
					exitValue = p.waitFor();
					
					if (exitValue != 0) {
						returnStatus = false;
					}
				} else {
					returnStatus = false;
				}
			} catch (Exception e) {
				returnStatus = false;
			}
		}

		return returnStatus;
	}
}