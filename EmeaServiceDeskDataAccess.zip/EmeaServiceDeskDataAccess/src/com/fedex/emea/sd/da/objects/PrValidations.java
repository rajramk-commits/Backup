package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.Date;

public class PrValidations implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8664563667986164838L;

	protected String cy;
	protected String eaiId;
	protected String symAppName;
	protected String ni2AppId;
	protected String ni2AppName;
	protected String respMdPin;
	protected String respMgrPin;
	protected String drDocRecvd;
	protected String valType;
	protected String valComponent;
	protected String valScenario;
	protected String valJustif;
	protected Date valEstmatedTestDttm;
	protected Date valConfirmedTestDttm;
	protected String valStatus;
	protected String valRemarks;
	protected String valResult;
	protected String valGaps;
	protected String valPropActions;
	protected Date lastUpdateDttm;
	protected String symProfName;
	protected String ni2BusCrit;
	protected int auditId;
	protected boolean auditIdNull = true;
	protected int valRta;
	protected boolean valRtaNull = true;
	protected String org;

	/**
	 * Method 'PrValidations'
	 * 
	 */
	public PrValidations()
	{
	}

	/**
	 * Method 'getCy'
	 * 
	 * @return String
	 */
	public String getCy()
	{
		return cy;
	}

	/**
	 * Method 'setCy'
	 * 
	 * @param cy
	 */
	public void setCy(String cy)
	{
		this.cy = cy;
	}

	/**
	 * Method 'getEaiId'
	 * 
	 * @return String
	 */
	public String getEaiId()
	{
		return eaiId;
	}

	/**
	 * Method 'setEaiId'
	 * 
	 * @param eaiId
	 */
	public void setEaiId(String eaiId)
	{
		this.eaiId = eaiId;
	}

	/**
	 * Method 'getSymAppName'
	 * 
	 * @return String
	 */
	public String getSymAppName()
	{
		return symAppName;
	}

	/**
	 * Method 'setSymAppName'
	 * 
	 * @param symAppName
	 */
	public void setSymAppName(String symAppName)
	{
		this.symAppName = symAppName;
	}

	/**
	 * Method 'getNi2AppId'
	 * 
	 * @return String
	 */
	public String getNi2AppId()
	{
		return ni2AppId;
	}

	/**
	 * Method 'setNi2AppId'
	 * 
	 * @param ni2AppId
	 */
	public void setNi2AppId(String ni2AppId)
	{
		this.ni2AppId = ni2AppId;
	}

	/**
	 * Method 'getNi2AppName'
	 * 
	 * @return String
	 */
	public String getNi2AppName()
	{
		return ni2AppName;
	}

	/**
	 * Method 'setNi2AppName'
	 * 
	 * @param ni2AppName
	 */
	public void setNi2AppName(String ni2AppName)
	{
		this.ni2AppName = ni2AppName;
	}

	/**
	 * Method 'getRespMdPin'
	 * 
	 * @return String
	 */
	public String getRespMdPin()
	{
		return respMdPin;
	}

	/**
	 * Method 'setRespMdPin'
	 * 
	 * @param respMdPin
	 */
	public void setRespMdPin(String respMdPin)
	{
		this.respMdPin = respMdPin;
	}

	/**
	 * Method 'getRespMgrPin'
	 * 
	 * @return String
	 */
	public String getRespMgrPin()
	{
		return respMgrPin;
	}

	/**
	 * Method 'setRespMgrPin'
	 * 
	 * @param respMgrPin
	 */
	public void setRespMgrPin(String respMgrPin)
	{
		this.respMgrPin = respMgrPin;
	}

	/**
	 * Method 'getDrDocRecvd'
	 * 
	 * @return String
	 */
	public String getDrDocRecvd()
	{
		return drDocRecvd;
	}

	/**
	 * Method 'setDrDocRecvd'
	 * 
	 * @param drDocRecvd
	 */
	public void setDrDocRecvd(String drDocRecvd)
	{
		this.drDocRecvd = drDocRecvd;
	}

	/**
	 * Method 'getValType'
	 * 
	 * @return String
	 */
	public String getValType()
	{
		return valType;
	}

	/**
	 * Method 'setValType'
	 * 
	 * @param valType
	 */
	public void setValType(String valType)
	{
		this.valType = valType;
	}

	/**
	 * Method 'getValComponent'
	 * 
	 * @return String
	 */
	public String getValComponent()
	{
		return valComponent;
	}

	/**
	 * Method 'setValComponent'
	 * 
	 * @param valComponent
	 */
	public void setValComponent(String valComponent)
	{
		this.valComponent = valComponent;
	}

	/**
	 * Method 'getValScenario'
	 * 
	 * @return String
	 */
	public String getValScenario()
	{
		return valScenario;
	}

	/**
	 * Method 'setValScenario'
	 * 
	 * @param valScenario
	 */
	public void setValScenario(String valScenario)
	{
		this.valScenario = valScenario;
	}

	/**
	 * Method 'getValJustif'
	 * 
	 * @return String
	 */
	public String getValJustif()
	{
		return valJustif;
	}

	/**
	 * Method 'setValJustif'
	 * 
	 * @param valJustif
	 */
	public void setValJustif(String valJustif)
	{
		this.valJustif = valJustif;
	}

	/**
	 * Method 'getValEstmatedTestDttm'
	 * 
	 * @return Date
	 */
	public Date getValEstmatedTestDttm()
	{
		return valEstmatedTestDttm;
	}

	/**
	 * Method 'setValEstmatedTestDttm'
	 * 
	 * @param valEstmatedTestDttm
	 */
	public void setValEstmatedTestDttm(Date valEstmatedTestDttm)
	{
		this.valEstmatedTestDttm = valEstmatedTestDttm;
	}

	/**
	 * Method 'getValConfirmedTestDttm'
	 * 
	 * @return Date
	 */
	public Date getValConfirmedTestDttm()
	{
		return valConfirmedTestDttm;
	}

	/**
	 * Method 'setValConfirmedTestDttm'
	 * 
	 * @param valConfirmedTestDttm
	 */
	public void setValConfirmedTestDttm(Date valConfirmedTestDttm)
	{
		this.valConfirmedTestDttm = valConfirmedTestDttm;
	}

	/**
	 * Method 'getValStatus'
	 * 
	 * @return String
	 */
	public String getValStatus()
	{
		return valStatus;
	}

	/**
	 * Method 'setValStatus'
	 * 
	 * @param valStatus
	 */
	public void setValStatus(String valStatus)
	{
		this.valStatus = valStatus;
	}

	/**
	 * Method 'getValRemarks'
	 * 
	 * @return String
	 */
	public String getValRemarks()
	{
		return valRemarks;
	}

	/**
	 * Method 'setValRemarks'
	 * 
	 * @param valRemarks
	 */
	public void setValRemarks(String valRemarks)
	{
		this.valRemarks = valRemarks;
	}

	/**
	 * Method 'getValResult'
	 * 
	 * @return String
	 */
	public String getValResult()
	{
		return valResult;
	}

	/**
	 * Method 'setValResult'
	 * 
	 * @param valResult
	 */
	public void setValResult(String valResult)
	{
		this.valResult = valResult;
	}

	/**
	 * Method 'getValGaps'
	 * 
	 * @return String
	 */
	public String getValGaps()
	{
		return valGaps;
	}

	/**
	 * Method 'setValGaps'
	 * 
	 * @param valGaps
	 */
	public void setValGaps(String valGaps)
	{
		this.valGaps = valGaps;
	}

	/**
	 * Method 'getValPropActions'
	 * 
	 * @return String
	 */
	public String getValPropActions()
	{
		return valPropActions;
	}

	/**
	 * Method 'setValPropActions'
	 * 
	 * @param valPropActions
	 */
	public void setValPropActions(String valPropActions)
	{
		this.valPropActions = valPropActions;
	}

	/**
	 * Method 'getLastUpdateDttm'
	 * 
	 * @return Date
	 */
	public Date getLastUpdateDttm()
	{
		return lastUpdateDttm;
	}

	/**
	 * Method 'setLastUpdateDttm'
	 * 
	 * @param lastUpdateDttm
	 */
	public void setLastUpdateDttm(Date lastUpdateDttm)
	{
		this.lastUpdateDttm = lastUpdateDttm;
	}

	/**
	 * Method 'getSymProfName'
	 * 
	 * @return String
	 */
	public String getSymProfName()
	{
		return symProfName;
	}

	/**
	 * Method 'setSymProfName'
	 * 
	 * @param symProfName
	 */
	public void setSymProfName(String symProfName)
	{
		this.symProfName = symProfName;
	}

	/**
	 * Method 'getNi2BusCrit'
	 * 
	 * @return String
	 */
	public String getNi2BusCrit()
	{
		return ni2BusCrit;
	}

	/**
	 * Method 'setNi2BusCrit'
	 * 
	 * @param ni2BusCrit
	 */
	public void setNi2BusCrit(String ni2BusCrit)
	{
		this.ni2BusCrit = ni2BusCrit;
	}

	/**
	 * Method 'getAuditId'
	 * 
	 * @return int
	 */
	public int getAuditId()
	{
		return auditId;
	}

	/**
	 * Method 'setAuditId'
	 * 
	 * @param auditId
	 */
	public void setAuditId(int auditId)
	{
		this.auditId = auditId;
		this.auditIdNull = false;
	}

	/**
	 * Method 'setAuditIdNull'
	 * 
	 * @param value
	 */
	public void setAuditIdNull(boolean value)
	{
		this.auditIdNull = value;
	}

	/**
	 * Method 'isAuditIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isAuditIdNull()
	{
		return auditIdNull;
	}

	/**
	 * Method 'getValRta'
	 * 
	 * @return int
	 */
	public int getValRta()
	{
		return valRta;
	}

	/**
	 * Method 'setValRta'
	 * 
	 * @param valRta
	 */
	public void setValRta(int valRta)
	{
		this.valRta = valRta;
		this.valRtaNull = false;
	}

	/**
	 * Method 'setValRtaNull'
	 * 
	 * @param value
	 */
	public void setValRtaNull(boolean value)
	{
		this.valRtaNull = value;
	}

	/**
	 * Method 'isValRtaNull'
	 * 
	 * @return boolean
	 */
	public boolean isValRtaNull()
	{
		return valRtaNull;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof PrValidations)) {
			return false;
		}
		
		final PrValidations _cast = (PrValidations) _other;
		if (cy == null ? _cast.cy != cy : !cy.equals( _cast.cy )) {
			return false;
		}
		
		if (eaiId == null ? _cast.eaiId != eaiId : !eaiId.equals( _cast.eaiId )) {
			return false;
		}
		
		if (symAppName == null ? _cast.symAppName != symAppName : !symAppName.equals( _cast.symAppName )) {
			return false;
		}
		
		if (ni2AppId == null ? _cast.ni2AppId != ni2AppId : !ni2AppId.equals( _cast.ni2AppId )) {
			return false;
		}
		
		if (ni2AppName == null ? _cast.ni2AppName != ni2AppName : !ni2AppName.equals( _cast.ni2AppName )) {
			return false;
		}
		
		if (respMdPin == null ? _cast.respMdPin != respMdPin : !respMdPin.equals( _cast.respMdPin )) {
			return false;
		}
		
		if (respMgrPin == null ? _cast.respMgrPin != respMgrPin : !respMgrPin.equals( _cast.respMgrPin )) {
			return false;
		}
		
		if (drDocRecvd == null ? _cast.drDocRecvd != drDocRecvd : !drDocRecvd.equals( _cast.drDocRecvd )) {
			return false;
		}
		
		if (valType == null ? _cast.valType != valType : !valType.equals( _cast.valType )) {
			return false;
		}
		
		if (valComponent == null ? _cast.valComponent != valComponent : !valComponent.equals( _cast.valComponent )) {
			return false;
		}
		
		if (valScenario == null ? _cast.valScenario != valScenario : !valScenario.equals( _cast.valScenario )) {
			return false;
		}
		
		if (valJustif == null ? _cast.valJustif != valJustif : !valJustif.equals( _cast.valJustif )) {
			return false;
		}
		
		if (valEstmatedTestDttm == null ? _cast.valEstmatedTestDttm != valEstmatedTestDttm : !valEstmatedTestDttm.equals( _cast.valEstmatedTestDttm )) {
			return false;
		}
		
		if (valConfirmedTestDttm == null ? _cast.valConfirmedTestDttm != valConfirmedTestDttm : !valConfirmedTestDttm.equals( _cast.valConfirmedTestDttm )) {
			return false;
		}
		
		if (valStatus == null ? _cast.valStatus != valStatus : !valStatus.equals( _cast.valStatus )) {
			return false;
		}
		
		if (valRemarks == null ? _cast.valRemarks != valRemarks : !valRemarks.equals( _cast.valRemarks )) {
			return false;
		}
		
		if (valResult == null ? _cast.valResult != valResult : !valResult.equals( _cast.valResult )) {
			return false;
		}
		
		if (valGaps == null ? _cast.valGaps != valGaps : !valGaps.equals( _cast.valGaps )) {
			return false;
		}
		
		if (valPropActions == null ? _cast.valPropActions != valPropActions : !valPropActions.equals( _cast.valPropActions )) {
			return false;
		}
		
		if (lastUpdateDttm == null ? _cast.lastUpdateDttm != lastUpdateDttm : !lastUpdateDttm.equals( _cast.lastUpdateDttm )) {
			return false;
		}
		
		if (symProfName == null ? _cast.symProfName != symProfName : !symProfName.equals( _cast.symProfName )) {
			return false;
		}
		
		if (ni2BusCrit == null ? _cast.ni2BusCrit != ni2BusCrit : !ni2BusCrit.equals( _cast.ni2BusCrit )) {
			return false;
		}
		
		if (auditId != _cast.auditId) {
			return false;
		}
		
		if (auditIdNull != _cast.auditIdNull) {
			return false;
		}
		
		if (valRta != _cast.valRta) {
			return false;
		}
		
		if (valRtaNull != _cast.valRtaNull) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (cy != null) {
			_hashCode = 29 * _hashCode + cy.hashCode();
		}
		
		if (eaiId != null) {
			_hashCode = 29 * _hashCode + eaiId.hashCode();
		}
		
		if (symAppName != null) {
			_hashCode = 29 * _hashCode + symAppName.hashCode();
		}
		
		if (ni2AppId != null) {
			_hashCode = 29 * _hashCode + ni2AppId.hashCode();
		}
		
		if (ni2AppName != null) {
			_hashCode = 29 * _hashCode + ni2AppName.hashCode();
		}
		
		if (respMdPin != null) {
			_hashCode = 29 * _hashCode + respMdPin.hashCode();
		}
		
		if (respMgrPin != null) {
			_hashCode = 29 * _hashCode + respMgrPin.hashCode();
		}
		
		if (drDocRecvd != null) {
			_hashCode = 29 * _hashCode + drDocRecvd.hashCode();
		}
		
		if (valType != null) {
			_hashCode = 29 * _hashCode + valType.hashCode();
		}
		
		if (valComponent != null) {
			_hashCode = 29 * _hashCode + valComponent.hashCode();
		}
		
		if (valScenario != null) {
			_hashCode = 29 * _hashCode + valScenario.hashCode();
		}
		
		if (valJustif != null) {
			_hashCode = 29 * _hashCode + valJustif.hashCode();
		}
		
		if (valEstmatedTestDttm != null) {
			_hashCode = 29 * _hashCode + valEstmatedTestDttm.hashCode();
		}
		
		if (valConfirmedTestDttm != null) {
			_hashCode = 29 * _hashCode + valConfirmedTestDttm.hashCode();
		}
		
		if (valStatus != null) {
			_hashCode = 29 * _hashCode + valStatus.hashCode();
		}
		
		if (valRemarks != null) {
			_hashCode = 29 * _hashCode + valRemarks.hashCode();
		}
		
		if (valResult != null) {
			_hashCode = 29 * _hashCode + valResult.hashCode();
		}
		
		if (valGaps != null) {
			_hashCode = 29 * _hashCode + valGaps.hashCode();
		}
		
		if (valPropActions != null) {
			_hashCode = 29 * _hashCode + valPropActions.hashCode();
		}
		
		if (lastUpdateDttm != null) {
			_hashCode = 29 * _hashCode + lastUpdateDttm.hashCode();
		}
		
		if (symProfName != null) {
			_hashCode = 29 * _hashCode + symProfName.hashCode();
		}
		
		if (ni2BusCrit != null) {
			_hashCode = 29 * _hashCode + ni2BusCrit.hashCode();
		}
		
		_hashCode = 29 * _hashCode + auditId;
		_hashCode = 29 * _hashCode + (auditIdNull ? 1 : 0);
		_hashCode = 29 * _hashCode + valRta;
		_hashCode = 29 * _hashCode + (valRtaNull ? 1 : 0);
		return _hashCode;
	}

	/**
	 * Method 'createPk'
	 * 
	 * @return PrValidationsPk
	 */
	public PrValidationsPk createPk()
	{
		return new PrValidationsPk(cy, eaiId, ni2AppId);
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.mycompany.myapp.dto.PrValidations: " );
		ret.append( "cy=" + cy );
		ret.append( ", eaiId=" + eaiId );
		ret.append( ", symAppName=" + symAppName );
		ret.append( ", ni2AppId=" + ni2AppId );
		ret.append( ", ni2AppName=" + ni2AppName );
		ret.append( ", respMdPin=" + respMdPin );
		ret.append( ", respMgrPin=" + respMgrPin );
		ret.append( ", drDocRecvd=" + drDocRecvd );
		ret.append( ", valType=" + valType );
		ret.append( ", valComponent=" + valComponent );
		ret.append( ", valScenario=" + valScenario );
		ret.append( ", valJustif=" + valJustif );
		ret.append( ", valEstmatedTestDttm=" + valEstmatedTestDttm );
		ret.append( ", valConfirmedTestDttm=" + valConfirmedTestDttm );
		ret.append( ", valStatus=" + valStatus );
		ret.append( ", valRemarks=" + valRemarks );
		ret.append( ", valResult=" + valResult );
		ret.append( ", valGaps=" + valGaps );
		ret.append( ", valPropActions=" + valPropActions );
		ret.append( ", lastUpdateDttm=" + lastUpdateDttm );
		ret.append( ", symProfName=" + symProfName );
		ret.append( ", ni2BusCrit=" + ni2BusCrit );
		ret.append( ", auditId=" + auditId );
		ret.append( ", valRta=" + valRta );
		return ret.toString();
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

}
