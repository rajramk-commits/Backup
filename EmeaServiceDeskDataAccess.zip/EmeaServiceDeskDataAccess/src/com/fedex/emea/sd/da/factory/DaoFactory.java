package com.fedex.emea.sd.da.factory;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.fedex.emea.sd.da.dao.AllocatedtoassociationDao;
import com.fedex.emea.sd.da.dao.ApplicationDao;
import com.fedex.emea.sd.da.dao.ApplicationtypeDao;
import com.fedex.emea.sd.da.dao.OrganizationDao;
import com.fedex.emea.sd.da.dao.ParametersDao;
import com.fedex.emea.sd.da.dao.PrAuditsDao;
import com.fedex.emea.sd.da.dao.PrCorrActionsDao;
import com.fedex.emea.sd.da.dao.PrMitigationsDao;
import com.fedex.emea.sd.da.dao.PrSpocsDao;
import com.fedex.emea.sd.da.dao.PrSymNi2LinksDao;
import com.fedex.emea.sd.da.dao.PrSymphonyAppsDao;
import com.fedex.emea.sd.da.dao.PrValidationsDao;

public class DaoFactory
{
	
	// PRODUCTION
	//
	public static PrAuditsDao createPrAuditsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrAuditsDao) bf.getBean( "PrAuditsDao" );
	}

	public static PrCorrActionsDao createPrCorrActionsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrCorrActionsDao) bf.getBean( "PrCorrActionsDao" );
	}

	public static PrMitigationsDao createPrMitigationsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrMitigationsDao) bf.getBean( "PrMitigationsDao" );
	}

	public static PrSpocsDao createPrSpocsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSpocsDao) bf.getBean( "PrSpocsDao" );
	}

	public static PrSymphonyAppsDao createPrSymphonyAppsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSymphonyAppsDao) bf.getBean( "PrSymphonyAppsDao" );
	}

	public static PrSymNi2LinksDao createPrSymNi2LinksDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSymNi2LinksDao) bf.getBean( "PrSymNi2LinksDao" );
	}

	public static PrValidationsDao createPrValidationsDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrValidationsDao) bf.getBean( "PrValidationsDao" );
	}

	public static AllocatedtoassociationDao createAllocatedtoassociationDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (AllocatedtoassociationDao) bf.getBean( "AllocatedtoassociationDao" );
	}

	public static ApplicationDao createApplicationDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (ApplicationDao) bf.getBean( "ApplicationDao" );
	}

	public static ApplicationtypeDao createApplicationtypeDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (ApplicationtypeDao) bf.getBean( "ApplicationtypeDao" );
	}

	public static OrganizationDao createOrganizationDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (OrganizationDao) bf.getBean( "OrganizationDao" );
	}
	
	public static ParametersDao createParametersDao() {
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (ParametersDao) bf.getBean( "parametersDao" );
	}

	// TEST
	//
	public static PrAuditsDao createPrAuditsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrAuditsDao) bf.getBean( "PrAuditsTestDao" );
	}

	public static PrCorrActionsDao createPrCorrActionsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrCorrActionsDao) bf.getBean( "PrCorrActionsTestDao" );
	}

	public static PrMitigationsDao createPrMitigationsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrMitigationsDao) bf.getBean( "PrMitigationsTestDao" );
	}

	public static PrSpocsDao createPrSpocsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSpocsDao) bf.getBean( "PrSpocsTestDao" );
	}

	public static PrSymphonyAppsDao createPrSymphonyAppsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSymphonyAppsDao) bf.getBean( "PrSymphonyAppsTestDao" );
	}

	public static PrSymNi2LinksDao createPrSymNi2LinksTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrSymNi2LinksDao) bf.getBean( "PrSymNi2LinksTestDao" );
	}

	public static PrValidationsDao createPrValidationsTestDao()
	{
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (PrValidationsDao) bf.getBean( "PrValidationsTestDao" );
	}
	
	public static ParametersDao createParametersTestDao() {
		BeanFactory bf = new XmlBeanFactory( new ClassPathResource("spring-config.xml") );
		return (ParametersDao) bf.getBean( "parametersTestDao" );
	}

}
