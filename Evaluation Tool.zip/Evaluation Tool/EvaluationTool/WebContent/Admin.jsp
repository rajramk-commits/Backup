<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>

<!DOCTYPE html   "http://www.w3.org/TR/html4/loose.dtd">
		<%   
		session.removeAttribute("removeMessage");
		session.removeAttribute("accessMessage");
        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
		
        %>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>SD Evaluation</title>
<script type="text/javascript" >

window.history.forward();
    function noBack() { window.history.forward(); 
    }
    
function openProgram1() {
	
    window.open("Program1.jsp");
}
function openProgram2() {
	
    window.open("Program2.jsp");
}
function openAddQuestion() {
	window.close("Admin.jsp");
    window.open("AddQuestion.jsp");
}
function openAddQuestion2() {
	window.close("Admin.jsp");
    window.open("AddQuestionP2.jsp");
}
function openViewDelQuestion() {
	window.close("Admin.jsp");
    window.open("ViewDelQuestion.jsp");
}
function openViewDelQuestion2() {
	window.close("Admin.jsp");
    window.open("ViewDelQuestionP2.jsp");
}
function openManageroles() {
	window.close("Admin.jsp");
    window.open("Access.jsp");
}
function openresults() {
	window.close("Admin.jsp");
    window.open("Results.jsp");
}
</script>

<style>
.main{
	margin-left:10%;
	margin-right:12%;
	
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
	}
.logout{
float:right;
margin-right:5%;
background-color:#C35817;
color:white;
padding:14px 20px;
border-radius: 10px;
border:none;
cursor:pointer;
}
.logout:hover{
background-color:#F88017;
}

.program1{
font-family:Calibri;
font-size:18px;
background-color:#2C3539;
color:white;
padding:14px 20px;
margin-top:10%;
 border-radius: 10px;
border:none;
cursor:pointer;
width:30%;
}

.program1:hover{
background-color:#504A4B;
}
.program2{
font-size:18px;
font-family:Calibri;
background-color:#C11B17;
color:white;
padding:14px 20px;
margin-top:3%;
 border-radius: 10px;
border:none;
cursor:pointer;
width:30%;
}
.program2:hover{
background-color:#C24641;
}

.program3{
font-size:18px;
font-family:Calibri;
background-color:#008080;
color:white;
padding:14px 20px;
margin-top:3%;
 border-radius: 10px;
border:none;
cursor:pointer;
width:30%;
}
.program3:hover{
background-color:#438D80;
}
.program4{
font-size:18px;
font-family:Calibri;
background-color:#1569C7;
color:white;
padding:14px 20px;
margin-top:3%;
 border-radius: 10px;
border:none;
cursor:pointer;
width:30%;
}
.program4:hover{
background-color:#368BC1;
}
.program5{
font-size:18px;
font-family:Calibri;
background-color:#bcf7f1;
color:white;
padding:14px 20px;
margin-top:3%;
 border-radius: 10px;
border:none;
cursor:pointer;
width:30%;
}
.program5:hover{
background-color:#e1fcfa;
}

</style>

</head>
<body onload="noBack();"
    onpageshow="if (event.persisted) noBack();" onunload="">	 
		<div class="main">
		
        <div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">FedEx Support - Evaluation</p>
   		</div>
        
        <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form>
        <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div>       
		<div ><br><br><br>
			<button class="program2" onclick="openProgram1()">PROGRAM 1 </button>
			<button class="program3" onclick="openAddQuestion()">Add Question for P1 </button>
			<button class="program4" onclick="openViewDelQuestion()">View/Delete Question for P1 </button><br><br>
			<button class="program2" onclick="openProgram2()">PROGRAM 2 </button>			
			<button class="program3" onclick="openAddQuestion2()">Add Question for P2 </button>
			<button class="program4" onclick="openViewDelQuestion2()">View/Delete Question for P2 </button><br><br>
			<button class="program1" onclick="openManageroles()">Manage User Roles</button> 
			<button class="program1" onclick="openresults()">Results</button>  
		</div>
		<br>
		<br>
		<img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
		<%} %>
</body>
</html>