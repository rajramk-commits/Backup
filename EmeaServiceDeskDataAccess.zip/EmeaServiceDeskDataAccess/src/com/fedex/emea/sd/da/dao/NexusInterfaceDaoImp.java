package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.NexusInterfaceRowMapper;
import com.fedex.emea.sd.da.objects.NexusInterface;

public class NexusInterfaceDaoImp implements NexusInterfaceDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int countAll() throws SQLException {
		String sql = "SELECT count(*) FROM NexusInterface";
        int allRows = 0;
        jdbcTemplate.queryForInt(sql);
        return allRows;
	}

	public void createFromDashboard(NexusInterface valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO NexusInterface ( RECORDSOURCE, RECORDSOURCEID, CASESUMMARY, CASEDESCRIPTION1, CASEDESCRIPTION2, CASEDESCRIPTION3, CASEDESCRIPTION4, CASEDESCRIPTION5, CASEDESCRIPTION6, CASEDESCRIPTION7, CASEDESCRIPTION8, CASEDESCRIPTION9) " +
		               "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getRecordSource(), valueObject.getRecordSourceId(), valueObject.getCaseSummary(), valueObject.getCaseDescription1(), valueObject.getCaseDescription2(), valueObject.getCaseDescription3(), valueObject.getCaseDescription4(), valueObject.getCaseDescription5(), valueObject.getCaseDescription6(), valueObject.getCaseDescription7(), valueObject.getCaseDescription8(), valueObject.getCaseDescription9()});
	}
	
	public void create(NexusInterface valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO NexusInterface ( RECORDSOURCE, RECORDSOURCEID, NEXUSCASEOBJECT, CASEBUSINESSUNIT, CASELOCATION, CASEORIGINPIN, CASESUMMARY, CASEDESCRIPTION1, CASEDESCRIPTION2, CASEDESCRIPTION3, CASEDESCRIPTION4, CASEDESCRIPTION5, CASEDESCRIPTION6, CASEDESCRIPTION7, CASEDESCRIPTION8, CASEDESCRIPTION9, CASETYPE, CASEPRIORITY, CASESTATUS, CASESEVERITY, CASESOURCE, CASEPROVIDERGROUP, CASEOWNERSHIP, CASECATEGORY, CASECALLTYPE, CASEPROBLEMTYPE, CASEPROBLEMDETAIL, CASEPROBLEMDESCRIPTION, CASEFDXNODE, CASEFDXVENDOR, CASEFDXVENDORID, CASEFDXSYSTEM, CASEFDXAPPLICATION, CASEASSIGNEDTO, CASESOLUTION, ALERTPROCESSED, PROCESSEDTIME, CREATIONTIME, CASEID) " +
		               "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getRecordSource(), valueObject.getRecordSourceId(), valueObject.getNexusCase(), valueObject.getCaseBusinessUnit(), valueObject.getCaseLocation(), valueObject.getCaseOriginPin(), valueObject.getCaseSummary(), valueObject.getCaseDescription1(), valueObject.getCaseDescription2(), valueObject.getCaseDescription3(), valueObject.getCaseDescription4(), valueObject.getCaseDescription5(), valueObject.getCaseDescription6(), valueObject.getCaseDescription7(), valueObject.getCaseDescription8(), valueObject.getCaseDescription9(), valueObject.getCaseType(), valueObject.getCasePriority(), valueObject.getCaseStatus(), valueObject.getCaseSeverity(), valueObject.getCaseSource(), valueObject.getCaseProviderGroup(), valueObject.getCaseOwnership(), valueObject.getCaseCategory(), valueObject.getCaseCallType(), valueObject.getCaseProblemType(), valueObject.getCaseProblemDetail(), valueObject.getCaseProblemDescription(), valueObject.getCaseFdxNode(), valueObject.getCaseFdxVendor(), valueObject.getCaseFdxVendorId(), valueObject.getCaseFdxSystem(), valueObject.getCaseFdxApplication(), valueObject.getCaseAssignedTo(), valueObject.getCaseSolution(), valueObject.getAlertProcessed(), valueObject.getProcessedTime(), valueObject.getCreationTime(), valueObject.getCaseId()});
	}

	public NexusInterface createValueObject() {
		return new NexusInterface();
	}
	
	public void deleteOlderThan(Timestamp limitDate) throws SQLException {
		String sql = "delete from NEXUSINTERFACE NI where NI.CREATIONTIME < ?";
		jdbcTemplate.update(sql, new Object[] {limitDate});
	}

	public void delete(NexusInterface valueObject) throws SQLException {
		String sql = "DELETE FROM NexusInterface WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertId()});
	}

	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM NexusInterface";
		jdbcTemplate.update(sql);
	}
	
	public NexusInterface getObjectByRecordSourceId(String recordSourceId) throws SQLException {
		NexusInterface valueObject = createValueObject();
		String sql = "SELECT * FROM NexusInterface WHERE (RECORDSOURCEID = ? AND ALERTPROCESSED = '1') ";
		valueObject = (NexusInterface) jdbcTemplate.queryForObject(sql, new Object[] {recordSourceId}, new NexusInterfaceRowMapper());
		return valueObject;
	}

	public NexusInterface getObject(int alertId) throws SQLException {
		NexusInterface valueObject = createValueObject();
		String sql = "SELECT * FROM NexusInterface WHERE (ALERTID = ? ) ";
		valueObject = (NexusInterface) jdbcTemplate.queryForObject(sql, new Object[] {alertId}, new NexusInterfaceRowMapper());
		return valueObject;
	}

	@SuppressWarnings("unchecked")
	public List<NexusInterface> loadAll() throws SQLException {
		String sql = "SELECT * FROM NexusInterface ORDER BY ALERTID ASC ";
		return jdbcTemplate.query(sql, new NexusInterfaceRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<NexusInterface> loadNotProcessed() throws SQLException {
		String sql = "SELECT * FROM NexusInterface WHERE ALERTPROCESSED='0' ORDER BY ALERTID ASC ";
		// To re-process errors (9) created less than 10 minutes ago.
		// String sql = "SELECT * FROM NexusInterface WHERE ALERTPROCESSED='0' OR (ALERTPROCESSED='9' AND CURRENT_TIMESTAMP - CREATIONTIME < interval '10' minute) ORDER BY ALERTID ASC ";
		return jdbcTemplate.query(sql, new NexusInterfaceRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<NexusInterface> loadOnlyDashboard() throws SQLException {
		String sql = "SELECT * FROM NexusInterface WHERE ALERTPROCESSED='3' ORDER BY ALERTID ASC ";
		return jdbcTemplate.query(sql, new NexusInterfaceRowMapper());
	}

	public void saveCompleted(NexusInterface valueObject) throws SQLException {
		String sql = "UPDATE NexusInterface SET ALERTPROCESSED = ?, PROCESSEDTIME = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertProcessed(), valueObject.getProcessedTime(), valueObject.getAlertId()});
	}
	
	public void updateRecordStatus(NexusInterface valueObject) throws SQLException {
		String sql = "UPDATE NexusInterface SET ALERTPROCESSED = ?, PROCESSEDTIME = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertProcessed(), new Timestamp(Calendar.getInstance().getTimeInMillis()), valueObject.getAlertId()});
	}
	
	public void updateCaseId(NexusInterface valueObject) throws SQLException {
		String sql = "UPDATE NexusInterface SET CASEID = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getCaseId(), valueObject.getAlertId()});
	}
	
	public void updatePriorityStatusGroup(NexusInterface valueObject) throws SQLException {
		String sql = "UPDATE NexusInterface SET CASEPRIORITY = ?, CASESTATUS = ?, CASEPROVIDERGROUP = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getCasePriority(), valueObject.getCaseStatus(), valueObject.getCaseProviderGroup(), valueObject.getAlertId()});
	}
}
