package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowUsers implements Serializable {

	private static final long serialVersionUID = 8948602635526874758L;
	
	private String snowActive;
	private String snowAuditor;
	private String snowBuilding;
	private String snowCalendarIntegration;
	private String snowCity;
	private String snowCompany;
	private String snowCost_Center;
	private String snowCountry;
	private String snowDateFormat;
	private String snowDepartment;
	private String snowEmail;
	private String snowEmployeeNumber;
	private String snowFailedattempts;
	private String snowFirstName;
	private String snowGender;
	private String snowHomePhone;
	private String snowInternalintegrationUser;
	private String snowIntroduction;
	private String snowLastLogin;
	private String snowLastLoginTime;
	private String snowLastName;
	private String snowLdapServer;
	private String snowLocation;
	private String snowLockedOut;
	private String snowManager;
	private String snowMiddleName;
	private String snowMobilePhone;
	private String snowName;
	private String snowNotification;
	private String snowPasswordNeedsReset;
	private String snowPhone;
	private String snowPhoto;
	private String snowPreferredLanguage;
	private String snowSchedule;
	private String snowSource;
	private String snowSsoSource;
	private String snowState;
	private String snowStreet;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysDomain;
	private String snowSysid;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowTimeFormat;
	private String snowTimeZone;
	private String snowTitle;
	private String snowU_Active_Directory_Override;
	private String snowU_Alternative_Contact;
	private String snowU_Authenticated;
	private String snowU_Category;
	private String snowU_Cit_Data_1;
	private String snowU_Cit_Data_2;
	private String snowU_Cit_Data_3;
	private String snowU_Cit_Data_4;
	private String snowU_Cit_Data_5;
	private String snowU_Cit_Data_6;
	private String snowU_Cit_Data_7;
	private String snowU_Contact_Preference;
	private String snowU_Controlling_Depot;
	private String snowU_Created_User;
	private String snowU_Creation_Request_No;
	private String snowU_Department_Name;
	private String snowU_Entity;
	private String snowU_Exempt_Frominactive_License;
	private String snowU_Extension;
	private String snowU_Familiar_Name;
	private String snowU_Fedex_Contract;
	private String snowU_Fedex_Ldapid;
	private String snowU_Fedex_Run_Sequence;
	private String snowU_Folder;
	private String snowU_Function;
	private String snowU_Functional_Area;
	private String snowU_Functional_Category;
	private String snowU_Functional_Subcategory;
	private String snowU_Functional_Value;
	private String snowU_Ics_Last_Dayin_Office;
	private String snowU_Ics_Leaver_S_Date;
	private String snowU_Itil_Only;
	private String snowU_Job_Role;
	private String snowU_Job_Title;
	private String snowU_Last_Date;
	private String snowU_Leaving_Date;
	private String snowU_License_Category;
	private String snowU_License_Remark;
	private String snowU_Local_Helpdesk;
	private String snowU_Localid;
	private String snowU_Nameid;
	private String snowU_Notes_Dn;
	private String snowU_Outsource_Company;
	private String snowU_Payrollid;
	private String snowU_Person_Remark;
	private String snowU_Person_Unique_Key;
	private String snowU_Pin;
	private String snowU_Primary_Workgroup;
	private String snowU_Sd_Account;
	private String snowU_Search_Code;
	private String snowU_Self_Serviceaccount;
	private String snowU_Sso_User;
	private String snowU_Ssp_Role;
	private String snowU_Ssp_Role___Overrideautomati;
	private String snowU_Start_Date;
	private String snowU_Sub_Department;
	private String snowU_Temp_Fedex_Flag;
	private String snowUserName;
	private String snowUserPassword;
	private String snowVip;
	private String snowZip;
	
	public SnowUsers() {	
	}
	
	public SnowUsers(HashMap<String, Object> jsonValues) {	
		snowActive = SnowUtilities.getStringValueFromObject(jsonValues.get("active"));
		snowAuditor = SnowUtilities.getStringValueFromObject(jsonValues.get("auditor"));
		snowBuilding = SnowUtilities.getStringValueFromObject(jsonValues.get("building"));
		snowCalendarIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("calendar_integration"));
		snowCity = SnowUtilities.getStringValueFromObject(jsonValues.get("city"));
		snowCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("company"));
		snowCost_Center = SnowUtilities.getStringValueFromObject(jsonValues.get("cost_center"));
		snowCountry = SnowUtilities.getStringValueFromObject(jsonValues.get("country"));
		snowDateFormat = SnowUtilities.getStringValueFromObject(jsonValues.get("date_format"));
		snowDepartment = SnowUtilities.getStringValueFromObject(jsonValues.get("department"));
		snowEmail = SnowUtilities.getStringValueFromObject(jsonValues.get("email"));
		snowEmployeeNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("employee_number"));
		snowFailedattempts = SnowUtilities.getStringValueFromObject(jsonValues.get("failed_attempts"));
		snowFirstName = SnowUtilities.getStringValueFromObject(jsonValues.get("first_name"));
		snowGender = SnowUtilities.getStringValueFromObject(jsonValues.get("gender"));
		snowHomePhone = SnowUtilities.getStringValueFromObject(jsonValues.get("home_phone"));
		snowInternalintegrationUser = SnowUtilities.getStringValueFromObject(jsonValues.get("internal_integration_user"));
		snowIntroduction = SnowUtilities.getStringValueFromObject(jsonValues.get("introduction"));
		snowLastLogin = SnowUtilities.getStringValueFromObject(jsonValues.get("last_login"));
		snowLastLoginTime = SnowUtilities.getStringValueFromObject(jsonValues.get("last_login_time"));
		snowLastName = SnowUtilities.getStringValueFromObject(jsonValues.get("last_name"));
		snowLdapServer = SnowUtilities.getStringValueFromObject(jsonValues.get("ldap_server"));
		snowLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("location"));
		snowLockedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("locked_out"));
		snowManager = SnowUtilities.getStringValueFromObject(jsonValues.get("manager"));
		snowMiddleName = SnowUtilities.getStringValueFromObject(jsonValues.get("middle_name"));
		snowMobilePhone = SnowUtilities.getStringValueFromObject(jsonValues.get("mobile_phone"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowNotification = SnowUtilities.getStringValueFromObject(jsonValues.get("notification"));
		snowPasswordNeedsReset = SnowUtilities.getStringValueFromObject(jsonValues.get("password_needs_reset"));
		snowPhone = SnowUtilities.getStringValueFromObject(jsonValues.get("phone"));
		snowPhoto = SnowUtilities.getStringValueFromObject(jsonValues.get("photo"));
		snowPreferredLanguage = SnowUtilities.getStringValueFromObject(jsonValues.get("preferred_language"));
		snowSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("schedule"));
		snowSource = SnowUtilities.getStringValueFromObject(jsonValues.get("source"));
		snowSsoSource = SnowUtilities.getStringValueFromObject(jsonValues.get("sso_source"));
		snowState = SnowUtilities.getStringValueFromObject(jsonValues.get("state"));
		snowStreet = SnowUtilities.getStringValueFromObject(jsonValues.get("street"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain"));
		snowSysid = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowTimeFormat = SnowUtilities.getStringValueFromObject(jsonValues.get("time_format"));
		snowTimeZone = SnowUtilities.getStringValueFromObject(jsonValues.get("time_zone"));
		snowTitle = SnowUtilities.getStringValueFromObject(jsonValues.get("title"));
		snowU_Active_Directory_Override = SnowUtilities.getStringValueFromObject(jsonValues.get("u_active_directory_override"));
		snowU_Alternative_Contact = SnowUtilities.getStringValueFromObject(jsonValues.get("u_alternative_contact"));
		snowU_Authenticated = SnowUtilities.getStringValueFromObject(jsonValues.get("u_authenticated"));
		snowU_Category = SnowUtilities.getStringValueFromObject(jsonValues.get("u_category"));
		snowU_Cit_Data_1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_1"));
		snowU_Cit_Data_2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_2"));
		snowU_Cit_Data_3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_3"));
		snowU_Cit_Data_4 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_4"));
		snowU_Cit_Data_5 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_5"));
		snowU_Cit_Data_6 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_6"));
		snowU_Cit_Data_7 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cit_data_7"));
		snowU_Contact_Preference = SnowUtilities.getStringValueFromObject(jsonValues.get("u_contact_preference"));
		snowU_Controlling_Depot = SnowUtilities.getStringValueFromObject(jsonValues.get("u_controlling_depot"));
		snowU_Created_User = SnowUtilities.getStringValueFromObject(jsonValues.get("u_created_user"));
		snowU_Creation_Request_No = SnowUtilities.getStringValueFromObject(jsonValues.get("u_creation_request_no"));
		snowU_Department_Name = SnowUtilities.getStringValueFromObject(jsonValues.get("u_department_name"));
		snowU_Entity = SnowUtilities.getStringValueFromObject(jsonValues.get("u_entity"));
		snowU_Exempt_Frominactive_License = SnowUtilities.getStringValueFromObject(jsonValues.get("u_exempt_from_inactive_license"));
		snowU_Extension = SnowUtilities.getStringValueFromObject(jsonValues.get("u_extension"));
		snowU_Familiar_Name = SnowUtilities.getStringValueFromObject(jsonValues.get("u_familiar_name"));
		snowU_Fedex_Contract = SnowUtilities.getStringValueFromObject(jsonValues.get("u_fedex_contract"));
		snowU_Fedex_Ldapid = SnowUtilities.getStringValueFromObject(jsonValues.get("u_fedex_ldap_id"));
		snowU_Fedex_Run_Sequence = SnowUtilities.getStringValueFromObject(jsonValues.get("u_fedex_run_sequence"));
		snowU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("u_folder"));
		snowU_Function = SnowUtilities.getStringValueFromObject(jsonValues.get("u_function"));
		snowU_Functional_Area = SnowUtilities.getStringValueFromObject(jsonValues.get("u_functional_area"));
		snowU_Functional_Category = SnowUtilities.getStringValueFromObject(jsonValues.get("u_functional_category"));
		snowU_Functional_Subcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_functional_subcategory"));
		snowU_Functional_Value = SnowUtilities.getStringValueFromObject(jsonValues.get("u_functional_value"));
		snowU_Ics_Last_Dayin_Office = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ics_last_day_in_office"));
		snowU_Ics_Leaver_S_Date = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ics_leaver_s_date"));
		snowU_Itil_Only = SnowUtilities.getStringValueFromObject(jsonValues.get("u_itil_only"));
		snowU_Job_Role = SnowUtilities.getStringValueFromObject(jsonValues.get("u_job_role"));
		snowU_Job_Title = SnowUtilities.getStringValueFromObject(jsonValues.get("u_job_title"));
		snowU_Last_Date = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_date"));
		snowU_Leaving_Date = SnowUtilities.getStringValueFromObject(jsonValues.get("u_leaving_date"));
		snowU_License_Category = SnowUtilities.getStringValueFromObject(jsonValues.get("u_license_category"));
		snowU_License_Remark = SnowUtilities.getStringValueFromObject(jsonValues.get("u_license_remark"));
		snowU_Local_Helpdesk = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_helpdesk"));
		snowU_Localid = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_id"));
		snowU_Nameid = SnowUtilities.getStringValueFromObject(jsonValues.get("u_name_id"));
		snowU_Notes_Dn = SnowUtilities.getStringValueFromObject(jsonValues.get("u_notes_dn"));
		snowU_Outsource_Company = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_company"));
		snowU_Payrollid = SnowUtilities.getStringValueFromObject(jsonValues.get("u_payroll_id"));
		snowU_Person_Remark = SnowUtilities.getStringValueFromObject(jsonValues.get("u_person_remark"));
		snowU_Person_Unique_Key = SnowUtilities.getStringValueFromObject(jsonValues.get("u_person_unique_key"));
		snowU_Pin = SnowUtilities.getStringValueFromObject(jsonValues.get("u_pin"));
		snowU_Primary_Workgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_primary_workgroup"));
		snowU_Sd_Account = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sd_account"));
		snowU_Search_Code = SnowUtilities.getStringValueFromObject(jsonValues.get("u_search_code"));
		snowU_Self_Serviceaccount = SnowUtilities.getStringValueFromObject(jsonValues.get("u_self_service_account"));
		snowU_Sso_User = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sso_user"));
		snowU_Ssp_Role = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ssp_role"));
		snowU_Ssp_Role___Overrideautomati = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ssp_role___override_automati"));
		snowU_Start_Date = SnowUtilities.getStringValueFromObject(jsonValues.get("u_start_date"));
		snowU_Sub_Department = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sub_department"));
		snowU_Temp_Fedex_Flag = SnowUtilities.getStringValueFromObject(jsonValues.get("u_temp_fedex_flag"));
		snowUserName = SnowUtilities.getStringValueFromObject(jsonValues.get("user_name"));
		snowUserPassword = SnowUtilities.getStringValueFromObject(jsonValues.get("user_password"));
		snowVip = SnowUtilities.getStringValueFromObject(jsonValues.get("vip"));
		snowZip = SnowUtilities.getStringValueFromObject(jsonValues.get("zip"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (snowActive != null && !snowActive.toString().isEmpty()) jsonObject.put("active", snowActive);
		if (snowAuditor != null && !snowAuditor.toString().isEmpty()) jsonObject.put("auditor", snowAuditor);
		if (snowBuilding != null && !snowBuilding.toString().isEmpty()) jsonObject.put("building", snowBuilding);
		if (snowCalendarIntegration != null && !snowCalendarIntegration.toString().isEmpty()) jsonObject.put("calendar_integration", snowCalendarIntegration);
		if (snowCity != null && !snowCity.toString().isEmpty()) jsonObject.put("city", snowCity);
		if (snowCompany != null && !snowCompany.toString().isEmpty()) jsonObject.put("company", snowCompany);
		if (snowCost_Center != null && !snowCost_Center.toString().isEmpty()) jsonObject.put("cost_center", snowCost_Center);
		if (snowCountry != null && !snowCountry.toString().isEmpty()) jsonObject.put("country", snowCountry);
		if (snowDateFormat != null && !snowDateFormat.toString().isEmpty()) jsonObject.put("date_format", snowDateFormat);
		if (snowDepartment != null && !snowDepartment.toString().isEmpty()) jsonObject.put("department", snowDepartment);
		if (snowEmail != null && !snowEmail.toString().isEmpty()) jsonObject.put("email", snowEmail);
		if (snowEmployeeNumber != null && !snowEmployeeNumber.toString().isEmpty()) jsonObject.put("employee_number", snowEmployeeNumber);
		if (snowFailedattempts != null && !snowFailedattempts.toString().isEmpty()) jsonObject.put("failed_attempts", snowFailedattempts);
		if (snowFirstName != null && !snowFirstName.toString().isEmpty()) jsonObject.put("first_name", snowFirstName);
		if (snowGender != null && !snowGender.toString().isEmpty()) jsonObject.put("gender", snowGender);
		if (snowHomePhone != null && !snowHomePhone.toString().isEmpty()) jsonObject.put("home_phone", snowHomePhone);
		if (snowInternalintegrationUser != null && !snowInternalintegrationUser.toString().isEmpty()) jsonObject.put("internal_integration_user", snowInternalintegrationUser);
		if (snowIntroduction != null && !snowIntroduction.toString().isEmpty()) jsonObject.put("introduction", snowIntroduction);
		if (snowLastLogin != null && !snowLastLogin.toString().isEmpty()) jsonObject.put("last_login", snowLastLogin);
		if (snowLastLoginTime != null && !snowLastLoginTime.toString().isEmpty()) jsonObject.put("last_login_time", snowLastLoginTime);
		if (snowLastName != null && !snowLastName.toString().isEmpty()) jsonObject.put("last_name", snowLastName);
		if (snowLdapServer != null && !snowLdapServer.toString().isEmpty()) jsonObject.put("ldap_server", snowLdapServer);
		if (snowLocation != null && !snowLocation.toString().isEmpty()) jsonObject.put("location", snowLocation);
		if (snowLockedOut != null && !snowLockedOut.toString().isEmpty()) jsonObject.put("locked_out", snowLockedOut);
		if (snowManager != null && !snowManager.toString().isEmpty()) jsonObject.put("manager", snowManager);
		if (snowMiddleName != null && !snowMiddleName.toString().isEmpty()) jsonObject.put("middle_name", snowMiddleName);
		if (snowMobilePhone != null && !snowMobilePhone.toString().isEmpty()) jsonObject.put("mobile_phone", snowMobilePhone);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowNotification != null && !snowNotification.toString().isEmpty()) jsonObject.put("notification", snowNotification);
		if (snowPasswordNeedsReset != null && !snowPasswordNeedsReset.toString().isEmpty()) jsonObject.put("password_needs_reset", snowPasswordNeedsReset);
		if (snowPhone != null && !snowPhone.toString().isEmpty()) jsonObject.put("phone", snowPhone);
		if (snowPhoto != null && !snowPhoto.toString().isEmpty()) jsonObject.put("photo", snowPhoto);
		if (snowPreferredLanguage != null && !snowPreferredLanguage.toString().isEmpty()) jsonObject.put("preferred_language", snowPreferredLanguage);
		if (snowSchedule != null && !snowSchedule.toString().isEmpty()) jsonObject.put("schedule", snowSchedule);
		if (snowSource != null && !snowSource.toString().isEmpty()) jsonObject.put("source", snowSource);
		if (snowSsoSource != null && !snowSsoSource.toString().isEmpty()) jsonObject.put("sso_source", snowSsoSource);
		if (snowState != null && !snowState.toString().isEmpty()) jsonObject.put("state", snowState);
		if (snowStreet != null && !snowStreet.toString().isEmpty()) jsonObject.put("street", snowStreet);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysDomain != null && !snowSysDomain.toString().isEmpty()) jsonObject.put("sys_domain", snowSysDomain);
		if (snowSysid != null && !snowSysid.toString().isEmpty()) jsonObject.put("sys_id", snowSysid);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowTimeFormat != null && !snowTimeFormat.toString().isEmpty()) jsonObject.put("time_format", snowTimeFormat);
		if (snowTimeZone != null && !snowTimeZone.toString().isEmpty()) jsonObject.put("time_zone", snowTimeZone);
		if (snowTitle != null && !snowTitle.toString().isEmpty()) jsonObject.put("title", snowTitle);
		if (snowU_Active_Directory_Override != null && !snowU_Active_Directory_Override.toString().isEmpty()) jsonObject.put("u_active_directory_override", snowU_Active_Directory_Override);
		if (snowU_Alternative_Contact != null && !snowU_Alternative_Contact.toString().isEmpty()) jsonObject.put("u_alternative_contact", snowU_Alternative_Contact);
		if (snowU_Authenticated != null && !snowU_Authenticated.toString().isEmpty()) jsonObject.put("u_authenticated", snowU_Authenticated);
		if (snowU_Category != null && !snowU_Category.toString().isEmpty()) jsonObject.put("u_category", snowU_Category);
		if (snowU_Cit_Data_1 != null && !snowU_Cit_Data_1.toString().isEmpty()) jsonObject.put("u_cit_data_1", snowU_Cit_Data_1);
		if (snowU_Cit_Data_2 != null && !snowU_Cit_Data_2.toString().isEmpty()) jsonObject.put("u_cit_data_2", snowU_Cit_Data_2);
		if (snowU_Cit_Data_3 != null && !snowU_Cit_Data_3.toString().isEmpty()) jsonObject.put("u_cit_data_3", snowU_Cit_Data_3);
		if (snowU_Cit_Data_4 != null && !snowU_Cit_Data_4.toString().isEmpty()) jsonObject.put("u_cit_data_4", snowU_Cit_Data_4);
		if (snowU_Cit_Data_5 != null && !snowU_Cit_Data_5.toString().isEmpty()) jsonObject.put("u_cit_data_5", snowU_Cit_Data_5);
		if (snowU_Cit_Data_6 != null && !snowU_Cit_Data_6.toString().isEmpty()) jsonObject.put("u_cit_data_6", snowU_Cit_Data_6);
		if (snowU_Cit_Data_7 != null && !snowU_Cit_Data_7.toString().isEmpty()) jsonObject.put("u_cit_data_7", snowU_Cit_Data_7);
		if (snowU_Contact_Preference != null && !snowU_Contact_Preference.toString().isEmpty()) jsonObject.put("u_contact_preference", snowU_Contact_Preference);
		if (snowU_Controlling_Depot != null && !snowU_Controlling_Depot.toString().isEmpty()) jsonObject.put("u_controlling_depot", snowU_Controlling_Depot);
		if (snowU_Created_User != null && !snowU_Created_User.toString().isEmpty()) jsonObject.put("u_created_user", snowU_Created_User);
		if (snowU_Creation_Request_No != null && !snowU_Creation_Request_No.toString().isEmpty()) jsonObject.put("u_creation_request_no", snowU_Creation_Request_No);
		if (snowU_Department_Name != null && !snowU_Department_Name.toString().isEmpty()) jsonObject.put("u_department_name", snowU_Department_Name);
		if (snowU_Entity != null && !snowU_Entity.toString().isEmpty()) jsonObject.put("u_entity", snowU_Entity);
		if (snowU_Exempt_Frominactive_License != null && !snowU_Exempt_Frominactive_License.toString().isEmpty()) jsonObject.put("u_exempt_from_inactive_license", snowU_Exempt_Frominactive_License);
		if (snowU_Extension != null && !snowU_Extension.toString().isEmpty()) jsonObject.put("u_extension", snowU_Extension);
		if (snowU_Familiar_Name != null && !snowU_Familiar_Name.toString().isEmpty()) jsonObject.put("u_familiar_name", snowU_Familiar_Name);
		if (snowU_Fedex_Contract != null && !snowU_Fedex_Contract.toString().isEmpty()) jsonObject.put("u_fedex_contract", snowU_Fedex_Contract);
		if (snowU_Fedex_Ldapid != null && !snowU_Fedex_Ldapid.toString().isEmpty()) jsonObject.put("u_fedex_ldap_id", snowU_Fedex_Ldapid);
		if (snowU_Fedex_Run_Sequence != null && !snowU_Fedex_Run_Sequence.toString().isEmpty()) jsonObject.put("u_fedex_run_sequence", snowU_Fedex_Run_Sequence);
		if (snowU_Folder != null && !snowU_Folder.toString().isEmpty()) jsonObject.put("u_folder", snowU_Folder);
		if (snowU_Function != null && !snowU_Function.toString().isEmpty()) jsonObject.put("u_function", snowU_Function);
		if (snowU_Functional_Area != null && !snowU_Functional_Area.toString().isEmpty()) jsonObject.put("u_functional_area", snowU_Functional_Area);
		if (snowU_Functional_Category != null && !snowU_Functional_Category.toString().isEmpty()) jsonObject.put("u_functional_category", snowU_Functional_Category);
		if (snowU_Functional_Subcategory != null && !snowU_Functional_Subcategory.toString().isEmpty()) jsonObject.put("u_functional_subcategory", snowU_Functional_Subcategory);
		if (snowU_Functional_Value != null && !snowU_Functional_Value.toString().isEmpty()) jsonObject.put("u_functional_value", snowU_Functional_Value);
		if (snowU_Ics_Last_Dayin_Office != null && !snowU_Ics_Last_Dayin_Office.toString().isEmpty()) jsonObject.put("u_ics_last_day_in_office", snowU_Ics_Last_Dayin_Office);
		if (snowU_Ics_Leaver_S_Date != null && !snowU_Ics_Leaver_S_Date.toString().isEmpty()) jsonObject.put("u_ics_leaver_s_date", snowU_Ics_Leaver_S_Date);
		if (snowU_Itil_Only != null && !snowU_Itil_Only.toString().isEmpty()) jsonObject.put("u_itil_only", snowU_Itil_Only);
		if (snowU_Job_Role != null && !snowU_Job_Role.toString().isEmpty()) jsonObject.put("u_job_role", snowU_Job_Role);
		if (snowU_Job_Title != null && !snowU_Job_Title.toString().isEmpty()) jsonObject.put("u_job_title", snowU_Job_Title);
		if (snowU_Last_Date != null && !snowU_Last_Date.toString().isEmpty()) jsonObject.put("u_last_date", snowU_Last_Date);
		if (snowU_Leaving_Date != null && !snowU_Leaving_Date.toString().isEmpty()) jsonObject.put("u_leaving_date", snowU_Leaving_Date);
		if (snowU_License_Category != null && !snowU_License_Category.toString().isEmpty()) jsonObject.put("u_license_category", snowU_License_Category);
		if (snowU_License_Remark != null && !snowU_License_Remark.toString().isEmpty()) jsonObject.put("u_license_remark", snowU_License_Remark);
		if (snowU_Local_Helpdesk != null && !snowU_Local_Helpdesk.toString().isEmpty()) jsonObject.put("u_local_helpdesk", snowU_Local_Helpdesk);
		if (snowU_Localid != null && !snowU_Localid.toString().isEmpty()) jsonObject.put("u_local_id", snowU_Localid);
		if (snowU_Nameid != null && !snowU_Nameid.toString().isEmpty()) jsonObject.put("u_name_id", snowU_Nameid);
		if (snowU_Notes_Dn != null && !snowU_Notes_Dn.toString().isEmpty()) jsonObject.put("u_notes_dn", snowU_Notes_Dn);
		if (snowU_Outsource_Company != null && !snowU_Outsource_Company.toString().isEmpty()) jsonObject.put("u_outsource_company", snowU_Outsource_Company);
		if (snowU_Payrollid != null && !snowU_Payrollid.toString().isEmpty()) jsonObject.put("u_payroll_id", snowU_Payrollid);
		if (snowU_Person_Remark != null && !snowU_Person_Remark.toString().isEmpty()) jsonObject.put("u_person_remark", snowU_Person_Remark);
		if (snowU_Person_Unique_Key != null && !snowU_Person_Unique_Key.toString().isEmpty()) jsonObject.put("u_person_unique_key", snowU_Person_Unique_Key);
		if (snowU_Pin != null && !snowU_Pin.toString().isEmpty()) jsonObject.put("u_pin", snowU_Pin);
		if (snowU_Primary_Workgroup != null && !snowU_Primary_Workgroup.toString().isEmpty()) jsonObject.put("u_primary_workgroup", snowU_Primary_Workgroup);
		if (snowU_Sd_Account != null && !snowU_Sd_Account.toString().isEmpty()) jsonObject.put("u_sd_account", snowU_Sd_Account);
		if (snowU_Search_Code != null && !snowU_Search_Code.toString().isEmpty()) jsonObject.put("u_search_code", snowU_Search_Code);
		if (snowU_Self_Serviceaccount != null && !snowU_Self_Serviceaccount.toString().isEmpty()) jsonObject.put("u_self_service_account", snowU_Self_Serviceaccount);
		if (snowU_Sso_User != null && !snowU_Sso_User.toString().isEmpty()) jsonObject.put("u_sso_user", snowU_Sso_User);
		if (snowU_Ssp_Role != null && !snowU_Ssp_Role.toString().isEmpty()) jsonObject.put("u_ssp_role", snowU_Ssp_Role);
		if (snowU_Ssp_Role___Overrideautomati != null && !snowU_Ssp_Role___Overrideautomati.toString().isEmpty()) jsonObject.put("u_ssp_role___override_automati", snowU_Ssp_Role___Overrideautomati);
		if (snowU_Start_Date != null && !snowU_Start_Date.toString().isEmpty()) jsonObject.put("u_start_date", snowU_Start_Date);
		if (snowU_Sub_Department != null && !snowU_Sub_Department.toString().isEmpty()) jsonObject.put("u_sub_department", snowU_Sub_Department);
		if (snowU_Temp_Fedex_Flag != null && !snowU_Temp_Fedex_Flag.toString().isEmpty()) jsonObject.put("u_temp_fedex_flag", snowU_Temp_Fedex_Flag);
		if (snowUserName != null && !snowUserName.toString().isEmpty()) jsonObject.put("user_name", snowUserName);
		if (snowUserPassword != null && !snowUserPassword.toString().isEmpty()) jsonObject.put("user_password", snowUserPassword);
		if (snowVip != null && !snowVip.toString().isEmpty()) jsonObject.put("vip", snowVip);
		if (snowZip != null && !snowZip.toString().isEmpty()) jsonObject.put("zip", snowZip);
		
		return jsonObject;
	}

	public String getSnowActive() {
		return snowActive;
	}

	public void setSnowActive(String snowActive) {
		this.snowActive = snowActive;
	}

	public String getSnowAuditor() {
		return snowAuditor;
	}

	public void setSnowAuditor(String snowAuditor) {
		this.snowAuditor = snowAuditor;
	}

	public String getSnowBuilding() {
		return snowBuilding;
	}

	public void setSnowBuilding(String snowBuilding) {
		this.snowBuilding = snowBuilding;
	}

	public String getSnowCalendarIntegration() {
		return snowCalendarIntegration;
	}

	public void setSnowCalendarIntegration(String snowCalendarIntegration) {
		this.snowCalendarIntegration = snowCalendarIntegration;
	}

	public String getSnowCity() {
		return snowCity;
	}

	public void setSnowCity(String snowCity) {
		this.snowCity = snowCity;
	}

	public String getSnowCompany() {
		return snowCompany;
	}

	public void setSnowCompany(String snowCompany) {
		this.snowCompany = snowCompany;
	}

	public String getSnowCost_Center() {
		return snowCost_Center;
	}

	public void setSnowCost_Center(String snowCost_Center) {
		this.snowCost_Center = snowCost_Center;
	}

	public String getSnowCountry() {
		return snowCountry;
	}

	public void setSnowCountry(String snowCountry) {
		this.snowCountry = snowCountry;
	}

	public String getSnowDateFormat() {
		return snowDateFormat;
	}

	public void setSnowDateFormat(String snowDateFormat) {
		this.snowDateFormat = snowDateFormat;
	}

	public String getSnowDepartment() {
		return snowDepartment;
	}

	public void setSnowDepartment(String snowDepartment) {
		this.snowDepartment = snowDepartment;
	}

	public String getSnowEmail() {
		return snowEmail;
	}

	public void setSnowEmail(String snowEmail) {
		this.snowEmail = snowEmail;
	}

	public String getSnowEmployeeNumber() {
		return snowEmployeeNumber;
	}

	public void setSnowEmployeeNumber(String snowEmployeeNumber) {
		this.snowEmployeeNumber = snowEmployeeNumber;
	}

	public String getSnowFailedattempts() {
		return snowFailedattempts;
	}

	public void setSnowFailedattempts(String snowFailedattempts) {
		this.snowFailedattempts = snowFailedattempts;
	}

	public String getSnowFirstName() {
		return snowFirstName;
	}

	public void setSnowFirstName(String snowFirstName) {
		this.snowFirstName = snowFirstName;
	}

	public String getSnowGender() {
		return snowGender;
	}

	public void setSnowGender(String snowGender) {
		this.snowGender = snowGender;
	}

	public String getSnowHomePhone() {
		return snowHomePhone;
	}

	public void setSnowHomePhone(String snowHomePhone) {
		this.snowHomePhone = snowHomePhone;
	}

	public String getSnowInternalintegrationUser() {
		return snowInternalintegrationUser;
	}

	public void setSnowInternalintegrationUser(String snowInternalintegrationUser) {
		this.snowInternalintegrationUser = snowInternalintegrationUser;
	}

	public String getSnowIntroduction() {
		return snowIntroduction;
	}

	public void setSnowIntroduction(String snowIntroduction) {
		this.snowIntroduction = snowIntroduction;
	}

	public String getSnowLastLogin() {
		return snowLastLogin;
	}

	public void setSnowLastLogin(String snowLastLogin) {
		this.snowLastLogin = snowLastLogin;
	}

	public String getSnowLastLoginTime() {
		return snowLastLoginTime;
	}

	public void setSnowLastLoginTime(String snowLastLoginTime) {
		this.snowLastLoginTime = snowLastLoginTime;
	}

	public String getSnowLastName() {
		return snowLastName;
	}

	public void setSnowLastName(String snowLastName) {
		this.snowLastName = snowLastName;
	}

	public String getSnowLdapServer() {
		return snowLdapServer;
	}

	public void setSnowLdapServer(String snowLdapServer) {
		this.snowLdapServer = snowLdapServer;
	}

	public String getSnowLocation() {
		return snowLocation;
	}

	public void setSnowLocation(String snowLocation) {
		this.snowLocation = snowLocation;
	}

	public String getSnowLockedOut() {
		return snowLockedOut;
	}

	public void setSnowLockedOut(String snowLockedOut) {
		this.snowLockedOut = snowLockedOut;
	}

	public String getSnowManager() {
		return snowManager;
	}

	public void setSnowManager(String snowManager) {
		this.snowManager = snowManager;
	}

	public String getSnowMiddleName() {
		return snowMiddleName;
	}

	public void setSnowMiddleName(String snowMiddleName) {
		this.snowMiddleName = snowMiddleName;
	}

	public String getSnowMobilePhone() {
		return snowMobilePhone;
	}

	public void setSnowMobilePhone(String snowMobilePhone) {
		this.snowMobilePhone = snowMobilePhone;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowNotification() {
		return snowNotification;
	}

	public void setSnowNotification(String snowNotification) {
		this.snowNotification = snowNotification;
	}

	public String getSnowPasswordNeedsReset() {
		return snowPasswordNeedsReset;
	}

	public void setSnowPasswordNeedsReset(String snowPasswordNeedsReset) {
		this.snowPasswordNeedsReset = snowPasswordNeedsReset;
	}

	public String getSnowPhone() {
		return snowPhone;
	}

	public void setSnowPhone(String snowPhone) {
		this.snowPhone = snowPhone;
	}

	public String getSnowPhoto() {
		return snowPhoto;
	}

	public void setSnowPhoto(String snowPhoto) {
		this.snowPhoto = snowPhoto;
	}

	public String getSnowPreferredLanguage() {
		return snowPreferredLanguage;
	}

	public void setSnowPreferredLanguage(String snowPreferredLanguage) {
		this.snowPreferredLanguage = snowPreferredLanguage;
	}

	public String getSnowSchedule() {
		return snowSchedule;
	}

	public void setSnowSchedule(String snowSchedule) {
		this.snowSchedule = snowSchedule;
	}

	public String getSnowSource() {
		return snowSource;
	}

	public void setSnowSource(String snowSource) {
		this.snowSource = snowSource;
	}

	public String getSnowSsoSource() {
		return snowSsoSource;
	}

	public void setSnowSsoSource(String snowSsoSource) {
		this.snowSsoSource = snowSsoSource;
	}

	public String getSnowState() {
		return snowState;
	}

	public void setSnowState(String snowState) {
		this.snowState = snowState;
	}

	public String getSnowStreet() {
		return snowStreet;
	}

	public void setSnowStreet(String snowStreet) {
		this.snowStreet = snowStreet;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysDomain() {
		return snowSysDomain;
	}

	public void setSnowSysDomain(String snowSysDomain) {
		this.snowSysDomain = snowSysDomain;
	}

	public String getSnowSysid() {
		return snowSysid;
	}

	public void setSnowSysid(String snowSysid) {
		this.snowSysid = snowSysid;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowTimeFormat() {
		return snowTimeFormat;
	}

	public void setSnowTimeFormat(String snowTimeFormat) {
		this.snowTimeFormat = snowTimeFormat;
	}

	public String getSnowTimeZone() {
		return snowTimeZone;
	}

	public void setSnowTimeZone(String snowTimeZone) {
		this.snowTimeZone = snowTimeZone;
	}

	public String getSnowTitle() {
		return snowTitle;
	}

	public void setSnowTitle(String snowTitle) {
		this.snowTitle = snowTitle;
	}

	public String getSnowU_Active_Directory_Override() {
		return snowU_Active_Directory_Override;
	}

	public void setSnowU_Active_Directory_Override(String snowU_Active_Directory_Override) {
		this.snowU_Active_Directory_Override = snowU_Active_Directory_Override;
	}

	public String getSnowU_Alternative_Contact() {
		return snowU_Alternative_Contact;
	}

	public void setSnowU_Alternative_Contact(String snowU_Alternative_Contact) {
		this.snowU_Alternative_Contact = snowU_Alternative_Contact;
	}

	public String getSnowU_Authenticated() {
		return snowU_Authenticated;
	}

	public void setSnowU_Authenticated(String snowU_Authenticated) {
		this.snowU_Authenticated = snowU_Authenticated;
	}

	public String getSnowU_Category() {
		return snowU_Category;
	}

	public void setSnowU_Category(String snowU_Category) {
		this.snowU_Category = snowU_Category;
	}

	public String getSnowU_Cit_Data_1() {
		return snowU_Cit_Data_1;
	}

	public void setSnowU_Cit_Data_1(String snowU_Cit_Data_1) {
		this.snowU_Cit_Data_1 = snowU_Cit_Data_1;
	}

	public String getSnowU_Cit_Data_2() {
		return snowU_Cit_Data_2;
	}

	public void setSnowU_Cit_Data_2(String snowU_Cit_Data_2) {
		this.snowU_Cit_Data_2 = snowU_Cit_Data_2;
	}

	public String getSnowU_Cit_Data_3() {
		return snowU_Cit_Data_3;
	}

	public void setSnowU_Cit_Data_3(String snowU_Cit_Data_3) {
		this.snowU_Cit_Data_3 = snowU_Cit_Data_3;
	}

	public String getSnowU_Cit_Data_4() {
		return snowU_Cit_Data_4;
	}

	public void setSnowU_Cit_Data_4(String snowU_Cit_Data_4) {
		this.snowU_Cit_Data_4 = snowU_Cit_Data_4;
	}

	public String getSnowU_Cit_Data_5() {
		return snowU_Cit_Data_5;
	}

	public void setSnowU_Cit_Data_5(String snowU_Cit_Data_5) {
		this.snowU_Cit_Data_5 = snowU_Cit_Data_5;
	}

	public String getSnowU_Cit_Data_6() {
		return snowU_Cit_Data_6;
	}

	public void setSnowU_Cit_Data_6(String snowU_Cit_Data_6) {
		this.snowU_Cit_Data_6 = snowU_Cit_Data_6;
	}

	public String getSnowU_Cit_Data_7() {
		return snowU_Cit_Data_7;
	}

	public void setSnowU_Cit_Data_7(String snowU_Cit_Data_7) {
		this.snowU_Cit_Data_7 = snowU_Cit_Data_7;
	}

	public String getSnowU_Contact_Preference() {
		return snowU_Contact_Preference;
	}

	public void setSnowU_Contact_Preference(String snowU_Contact_Preference) {
		this.snowU_Contact_Preference = snowU_Contact_Preference;
	}

	public String getSnowU_Controlling_Depot() {
		return snowU_Controlling_Depot;
	}

	public void setSnowU_Controlling_Depot(String snowU_Controlling_Depot) {
		this.snowU_Controlling_Depot = snowU_Controlling_Depot;
	}

	public String getSnowU_Created_User() {
		return snowU_Created_User;
	}

	public void setSnowU_Created_User(String snowU_Created_User) {
		this.snowU_Created_User = snowU_Created_User;
	}

	public String getSnowU_Creation_Request_No() {
		return snowU_Creation_Request_No;
	}

	public void setSnowU_Creation_Request_No(String snowU_Creation_Request_No) {
		this.snowU_Creation_Request_No = snowU_Creation_Request_No;
	}

	public String getSnowU_Department_Name() {
		return snowU_Department_Name;
	}

	public void setSnowU_Department_Name(String snowU_Department_Name) {
		this.snowU_Department_Name = snowU_Department_Name;
	}

	public String getSnowU_Entity() {
		return snowU_Entity;
	}

	public void setSnowU_Entity(String snowU_Entity) {
		this.snowU_Entity = snowU_Entity;
	}

	public String getSnowU_Exempt_Frominactive_License() {
		return snowU_Exempt_Frominactive_License;
	}

	public void setSnowU_Exempt_Frominactive_License(String snowU_Exempt_Frominactive_License) {
		this.snowU_Exempt_Frominactive_License = snowU_Exempt_Frominactive_License;
	}

	public String getSnowU_Extension() {
		return snowU_Extension;
	}

	public void setSnowU_Extension(String snowU_Extension) {
		this.snowU_Extension = snowU_Extension;
	}

	public String getSnowU_Familiar_Name() {
		return snowU_Familiar_Name;
	}

	public void setSnowU_Familiar_Name(String snowU_Familiar_Name) {
		this.snowU_Familiar_Name = snowU_Familiar_Name;
	}

	public String getSnowU_Fedex_Contract() {
		return snowU_Fedex_Contract;
	}

	public void setSnowU_Fedex_Contract(String snowU_Fedex_Contract) {
		this.snowU_Fedex_Contract = snowU_Fedex_Contract;
	}

	public String getSnowU_Fedex_Ldapid() {
		return snowU_Fedex_Ldapid;
	}

	public void setSnowU_Fedex_Ldapid(String snowU_Fedex_Ldapid) {
		this.snowU_Fedex_Ldapid = snowU_Fedex_Ldapid;
	}

	public String getSnowU_Fedex_Run_Sequence() {
		return snowU_Fedex_Run_Sequence;
	}

	public void setSnowU_Fedex_Run_Sequence(String snowU_Fedex_Run_Sequence) {
		this.snowU_Fedex_Run_Sequence = snowU_Fedex_Run_Sequence;
	}

	public String getSnowU_Folder() {
		return snowU_Folder;
	}

	public void setSnowU_Folder(String snowU_Folder) {
		this.snowU_Folder = snowU_Folder;
	}

	public String getSnowU_Function() {
		return snowU_Function;
	}

	public void setSnowU_Function(String snowU_Function) {
		this.snowU_Function = snowU_Function;
	}

	public String getSnowU_Functional_Area() {
		return snowU_Functional_Area;
	}

	public void setSnowU_Functional_Area(String snowU_Functional_Area) {
		this.snowU_Functional_Area = snowU_Functional_Area;
	}

	public String getSnowU_Functional_Category() {
		return snowU_Functional_Category;
	}

	public void setSnowU_Functional_Category(String snowU_Functional_Category) {
		this.snowU_Functional_Category = snowU_Functional_Category;
	}

	public String getSnowU_Functional_Subcategory() {
		return snowU_Functional_Subcategory;
	}

	public void setSnowU_Functional_Subcategory(String snowU_Functional_Subcategory) {
		this.snowU_Functional_Subcategory = snowU_Functional_Subcategory;
	}

	public String getSnowU_Functional_Value() {
		return snowU_Functional_Value;
	}

	public void setSnowU_Functional_Value(String snowU_Functional_Value) {
		this.snowU_Functional_Value = snowU_Functional_Value;
	}

	public String getSnowU_Ics_Last_Dayin_Office() {
		return snowU_Ics_Last_Dayin_Office;
	}

	public void setSnowU_Ics_Last_Dayin_Office(String snowU_Ics_Last_Dayin_Office) {
		this.snowU_Ics_Last_Dayin_Office = snowU_Ics_Last_Dayin_Office;
	}

	public String getSnowU_Ics_Leaver_S_Date() {
		return snowU_Ics_Leaver_S_Date;
	}

	public void setSnowU_Ics_Leaver_S_Date(String snowU_Ics_Leaver_S_Date) {
		this.snowU_Ics_Leaver_S_Date = snowU_Ics_Leaver_S_Date;
	}

	public String getSnowU_Itil_Only() {
		return snowU_Itil_Only;
	}

	public void setSnowU_Itil_Only(String snowU_Itil_Only) {
		this.snowU_Itil_Only = snowU_Itil_Only;
	}

	public String getSnowU_Job_Role() {
		return snowU_Job_Role;
	}

	public void setSnowU_Job_Role(String snowU_Job_Role) {
		this.snowU_Job_Role = snowU_Job_Role;
	}

	public String getSnowU_Job_Title() {
		return snowU_Job_Title;
	}

	public void setSnowU_Job_Title(String snowU_Job_Title) {
		this.snowU_Job_Title = snowU_Job_Title;
	}

	public String getSnowU_Last_Date() {
		return snowU_Last_Date;
	}

	public void setSnowU_Last_Date(String snowU_Last_Date) {
		this.snowU_Last_Date = snowU_Last_Date;
	}

	public String getSnowU_Leaving_Date() {
		return snowU_Leaving_Date;
	}

	public void setSnowU_Leaving_Date(String snowU_Leaving_Date) {
		this.snowU_Leaving_Date = snowU_Leaving_Date;
	}

	public String getSnowU_License_Category() {
		return snowU_License_Category;
	}

	public void setSnowU_License_Category(String snowU_License_Category) {
		this.snowU_License_Category = snowU_License_Category;
	}

	public String getSnowU_License_Remark() {
		return snowU_License_Remark;
	}

	public void setSnowU_License_Remark(String snowU_License_Remark) {
		this.snowU_License_Remark = snowU_License_Remark;
	}

	public String getSnowU_Local_Helpdesk() {
		return snowU_Local_Helpdesk;
	}

	public void setSnowU_Local_Helpdesk(String snowU_Local_Helpdesk) {
		this.snowU_Local_Helpdesk = snowU_Local_Helpdesk;
	}

	public String getSnowU_Localid() {
		return snowU_Localid;
	}

	public void setSnowU_Localid(String snowU_Localid) {
		this.snowU_Localid = snowU_Localid;
	}

	public String getSnowU_Nameid() {
		return snowU_Nameid;
	}

	public void setSnowU_Nameid(String snowU_Nameid) {
		this.snowU_Nameid = snowU_Nameid;
	}

	public String getSnowU_Notes_Dn() {
		return snowU_Notes_Dn;
	}

	public void setSnowU_Notes_Dn(String snowU_Notes_Dn) {
		this.snowU_Notes_Dn = snowU_Notes_Dn;
	}

	public String getSnowU_Outsource_Company() {
		return snowU_Outsource_Company;
	}

	public void setSnowU_Outsource_Company(String snowU_Outsource_Company) {
		this.snowU_Outsource_Company = snowU_Outsource_Company;
	}

	public String getSnowU_Payrollid() {
		return snowU_Payrollid;
	}

	public void setSnowU_Payrollid(String snowU_Payrollid) {
		this.snowU_Payrollid = snowU_Payrollid;
	}

	public String getSnowU_Person_Remark() {
		return snowU_Person_Remark;
	}

	public void setSnowU_Person_Remark(String snowU_Person_Remark) {
		this.snowU_Person_Remark = snowU_Person_Remark;
	}

	public String getSnowU_Person_Unique_Key() {
		return snowU_Person_Unique_Key;
	}

	public void setSnowU_Person_Unique_Key(String snowU_Person_Unique_Key) {
		this.snowU_Person_Unique_Key = snowU_Person_Unique_Key;
	}

	public String getSnowU_Pin() {
		return snowU_Pin;
	}

	public void setSnowU_Pin(String snowU_Pin) {
		this.snowU_Pin = snowU_Pin;
	}

	public String getSnowU_Primary_Workgroup() {
		return snowU_Primary_Workgroup;
	}

	public void setSnowU_Primary_Workgroup(String snowU_Primary_Workgroup) {
		this.snowU_Primary_Workgroup = snowU_Primary_Workgroup;
	}

	public String getSnowU_Sd_Account() {
		return snowU_Sd_Account;
	}

	public void setSnowU_Sd_Account(String snowU_Sd_Account) {
		this.snowU_Sd_Account = snowU_Sd_Account;
	}

	public String getSnowU_Search_Code() {
		return snowU_Search_Code;
	}

	public void setSnowU_Search_Code(String snowU_Search_Code) {
		this.snowU_Search_Code = snowU_Search_Code;
	}

	public String getSnowU_Self_Serviceaccount() {
		return snowU_Self_Serviceaccount;
	}

	public void setSnowU_Self_Serviceaccount(String snowU_Self_Serviceaccount) {
		this.snowU_Self_Serviceaccount = snowU_Self_Serviceaccount;
	}

	public String getSnowU_Sso_User() {
		return snowU_Sso_User;
	}

	public void setSnowU_Sso_User(String snowU_Sso_User) {
		this.snowU_Sso_User = snowU_Sso_User;
	}

	public String getSnowU_Ssp_Role() {
		return snowU_Ssp_Role;
	}

	public void setSnowU_Ssp_Role(String snowU_Ssp_Role) {
		this.snowU_Ssp_Role = snowU_Ssp_Role;
	}

	public String getSnowU_Ssp_Role___Overrideautomati() {
		return snowU_Ssp_Role___Overrideautomati;
	}

	public void setSnowU_Ssp_Role___Overrideautomati(String snowU_Ssp_Role___Overrideautomati) {
		this.snowU_Ssp_Role___Overrideautomati = snowU_Ssp_Role___Overrideautomati;
	}

	public String getSnowU_Start_Date() {
		return snowU_Start_Date;
	}

	public void setSnowU_Start_Date(String snowU_Start_Date) {
		this.snowU_Start_Date = snowU_Start_Date;
	}

	public String getSnowU_Sub_Department() {
		return snowU_Sub_Department;
	}

	public void setSnowU_Sub_Department(String snowU_Sub_Department) {
		this.snowU_Sub_Department = snowU_Sub_Department;
	}

	public String getSnowU_Temp_Fedex_Flag() {
		return snowU_Temp_Fedex_Flag;
	}

	public void setSnowU_Temp_Fedex_Flag(String snowU_Temp_Fedex_Flag) {
		this.snowU_Temp_Fedex_Flag = snowU_Temp_Fedex_Flag;
	}

	public String getSnowUserName() {
		return snowUserName;
	}

	public void setSnowUserName(String snowUserName) {
		this.snowUserName = snowUserName;
	}

	public String getSnowUserPassword() {
		return snowUserPassword;
	}

	public void setSnowUserPassword(String snowUserPassword) {
		this.snowUserPassword = snowUserPassword;
	}

	public String getSnowVip() {
		return snowVip;
	}

	public void setSnowVip(String snowVip) {
		this.snowVip = snowVip;
	}

	public String getSnowZip() {
		return snowZip;
	}

	public void setSnowZip(String snowZip) {
		this.snowZip = snowZip;
	}
	
	
}
