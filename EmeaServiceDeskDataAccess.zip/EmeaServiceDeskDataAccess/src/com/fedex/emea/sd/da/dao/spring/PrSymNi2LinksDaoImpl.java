package com.fedex.emea.sd.da.dao.spring;

import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrSymNi2LinksDao;
import com.fedex.emea.sd.da.exceptions.PrSymNi2LinksDaoException;
import com.fedex.emea.sd.da.objects.PrSymNi2Links;
import com.fedex.emea.sd.da.objects.PrSymNi2LinksPk;

public class PrSymNi2LinksDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrSymNi2Links>, PrSymNi2LinksDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSymNi2LinksPk
	 */
	@Transactional
	public PrSymNi2LinksPk insert(PrSymNi2Links dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID ) VALUES ( ?, ?, ? )",dto.getSymEaiId(),dto.getNi2AppName(),dto.getNi2AppId());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_SYM_NI2_LINKS table.
	 */
	@Transactional
	public void update(PrSymNi2LinksPk pk, PrSymNi2Links dto) throws PrSymNi2LinksDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET SYM_EAI_ID = ?, NI2_APP_NAME = ?, NI2_APP_ID = ? WHERE SYM_EAI_ID = ? AND NI2_APP_ID = ?",dto.getSymEaiId(),dto.getNi2AppName(),dto.getNi2AppId(),pk.getSymEaiId(),pk.getNi2AppId());
	}

	/** 
	 * Deletes a single row in the PR_SYM_NI2_LINKS table.
	 */
	@Transactional
	public void delete(PrSymNi2LinksPk pk) throws PrSymNi2LinksDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE SYM_EAI_ID = ? AND NI2_APP_ID = ?",pk.getSymEaiId(),pk.getNi2AppId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrSymNi2Links
	 */
	public PrSymNi2Links mapRow(ResultSet rs, int row) throws SQLException
	{
		PrSymNi2Links dto = new PrSymNi2Links();
		dto.setSymEaiId( rs.getString( 1 ) );
		dto.setNi2AppName( rs.getString( 2 ) );
		dto.setNi2AppId( rs.getString( 3 ) );
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_SYM_NI2_LINKS";
	}

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'SYM_EAI_ID = :symEaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public PrSymNi2Links findByPrimaryKey(String symEaiId, String ni2AppId) throws PrSymNi2LinksDaoException
	{
		try {
			List<PrSymNi2Links> list = jdbcTemplate.query("SELECT SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID FROM " + getTableName() + " WHERE SYM_EAI_ID = ? AND NI2_APP_ID = ?", this,symEaiId,ni2AppId);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrSymNi2LinksDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria ''.
	 */
	@Transactional
	public List<PrSymNi2Links> findAll() throws PrSymNi2LinksDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID FROM " + getTableName() + " ORDER BY SYM_EAI_ID, NI2_APP_ID", this);
		}
		catch (Exception e) {
			throw new PrSymNi2LinksDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	@Transactional
	public List<PrSymNi2Links> findWhereSymEaiIdEquals(String symEaiId) throws PrSymNi2LinksDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID FROM " + getTableName() + " WHERE SYM_EAI_ID = ? ORDER BY SYM_EAI_ID", this,symEaiId);
		}
		catch (Exception e) {
			throw new PrSymNi2LinksDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	@Transactional
	public List<PrSymNi2Links> findWhereNi2AppNameEquals(String ni2AppName) throws PrSymNi2LinksDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID FROM " + getTableName() + " WHERE NI2_APP_NAME = ? ORDER BY NI2_APP_NAME", this,ni2AppName);
		}
		catch (Exception e) {
			throw new PrSymNi2LinksDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public List<PrSymNi2Links> findWhereNi2AppIdEquals(String ni2AppId) throws PrSymNi2LinksDaoException
	{
		try {
			return jdbcTemplate.query("SELECT SYM_EAI_ID, NI2_APP_NAME, NI2_APP_ID FROM " + getTableName() + " WHERE NI2_APP_ID = ? ORDER BY NI2_APP_ID", this,ni2AppId);
		}
		catch (Exception e) {
			throw new PrSymNi2LinksDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_SYM_NI2_LINKS table that matches the specified primary-key value.
	 */
	public PrSymNi2Links findByPrimaryKey(PrSymNi2LinksPk pk) throws PrSymNi2LinksDaoException
	{
		return findByPrimaryKey( pk.getSymEaiId(), pk.getNi2AppId() );
	}

}
