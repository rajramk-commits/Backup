/********************************* Package section ****************************/
package com.fedex.emea.dimm.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import com.fedex.emea.dimm.config.MailConfig;
import com.fedex.emea.dimm.log.LogFactory;

/********************************* Import Section *****************************/
//Java packages

public class MailService {
	
	private MailConfig oMailConfig;
	
	public MailService(MailConfig oMailConfig){
		this.oMailConfig = oMailConfig;
	}

	/**
	 * This method establishes a session & sends a mail. The to address field can have 
	 * multiple mail address separated by ';'.
	 * 
	 * @param strToId			Contains ; separated mail ids. 
	 * @param strFromId			Contains a single mail address.
	 * @param strMailSubject	Contains the email subject.
	 * @param strMailBody		Contains the content of the mail. 
	 *
	 * @throws Exception
	 */
	public void sendMail(String strToId, String strFromId, String strMailSubject, String strMailBody) throws Exception {
		String msgBody = "<PRE>"+strMailBody+"</PRE>";
		sendMailNotification(strToId, null, strMailSubject, msgBody, null);
	}
	
	public void notifyServiceStartFail(Exception exception, String additionalInfo, String emailTo) {
		try {
			if(emailTo != null && emailTo.trim().length()>0 ){
				StringWriter sw = new StringWriter();
			    PrintWriter pw = new PrintWriter(sw);
			    exception.printStackTrace(pw);
			    String mailMessage= "<pre>"+additionalInfo+"\n"+sw.toString()+"</pre>";
				String mailSubject = "Exception occurred. Please make a check.";
				sendMailNotification(emailTo, null, mailSubject, mailMessage, null);
			}else{
				LogFactory.getLogger().logError("Can not send error notification email because EmailTo is null. additional info is ["+additionalInfo+"] Exception Message is ["+exception.getMessage()+"]");
			}
		}catch(Exception ex){
			LogFactory.getLogger().logError("Can not send error notification email");
			LogFactory.getLogger().logException("Error:",ex);
		}
	}
	
	public void sendMailNotification(String emailTo, String emailCc, String subject, String msgBody) {
		sendMailNotification(emailTo, emailCc, subject, msgBody, null);
	}
	
    public void sendMailNotification(String emailTo, String emailCc, String subject, String msgBody, ArrayList<String> attachments) {
		try {
			Properties props = System.getProperties();
			props.put("mail.smtp.host", oMailConfig.getMailHost());
			javax.mail.Session mailSession = javax.mail.Session.getDefaultInstance(props);
			Message msg = new MimeMessage(mailSession);
			msg.setFrom(new InternetAddress(oMailConfig.getFromAddress()));
			msg.setSubject(subject);
			if(!Utilities.isValidString(emailTo)){
				emailTo = oMailConfig.getToAddress();
			}
			if (Utilities.isValidString(emailTo)){
				String[] toEmails = emailTo.split(",");
				InternetAddress[] toInternetAddress = new InternetAddress[toEmails.length];
				for(int i=0;i<toEmails.length;i++){
					if(toEmails[i] != null)
						toInternetAddress[i] = new InternetAddress(toEmails[i].trim());
				}
				msg.setRecipients(Message.RecipientType.TO, toInternetAddress);
			}
			if (Utilities.isValidString(emailCc)){
				String[] ccEmails = emailCc.split(",");
				InternetAddress[] ccInternetAddress = new InternetAddress[ccEmails.length];
				for(int i=0;i<ccEmails.length;i++){
					ccInternetAddress[i] = new InternetAddress(ccEmails[i]); 
				}					
				msg.setRecipients(Message.RecipientType.CC, ccInternetAddress);	
			}			
			msgBody=msgBody!=null?"<DIV>"+msgBody+"</DIV>":"";
			
			msgBody+="<BR/><BR/>"+							
			"Regards,"+"<BR/>"+
			"EMEA Monitoring Team.<BR/>"+"<BR/>"+
			"<h3>This is a automatically generated message. Please don't reply to this mail.</h3>";				
			
			LogFactory.getLogger().logDebug("@@@@@@@@@@@@@@ - "+ subject +" - @@@@@@@ - To[ - "+emailTo+"] Cc[ - "+emailCc+"] @@@@@@@@ \n" + msgBody);

			MimeBodyPart mbp1 = new MimeBodyPart();
			mbp1.setText(msgBody);
			mbp1.setContent(msgBody, "text/html");
			
			Multipart mp = new MimeMultipart();
			mp.addBodyPart(mbp1);
			
			if(attachments != null && !attachments.isEmpty())
			for (String fileName : attachments){
			    MimeBodyPart mbp = new MimeBodyPart();
			    FileDataSource fds = new FileDataSource(fileName);
			    mbp.setDataHandler(new DataHandler(fds));
			    mbp.setFileName(fds.getName());
			    mp.addBodyPart(mbp);
			}
			msg.setContent(mp);
			msg.setSentDate(new Date());
			msg.setHeader("X-Mailer", "FedEx");
			Transport.send(msg);
			
			LogFactory.getLogger().logInfo("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Mail Details START @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			LogFactory.getLogger().logInfo("Email From: ["+oMailConfig.getFromAddress()+"]");
			LogFactory.getLogger().logInfo("Email To: ["+emailTo+"]");
			LogFactory.getLogger().logInfo("Email Cc: ["+emailCc+"]");
			LogFactory.getLogger().logInfo("Email Subject: ["+subject+"]");
			LogFactory.getLogger().logInfo("Email Sent: ["+Calendar.getInstance().getTime()+"]");
			LogFactory.getLogger().logInfo("Email Body: ["+msgBody+"]");
			LogFactory.getLogger().logInfo("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Mail Details ENDSS @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");				
			
		}catch(Exception exception){
			LogFactory.getLogger().logError("Exception while sending mail. Please check error.log for more details. "+exception.getMessage());
			LogFactory.getLogger().logException("Error:",exception);
		}
    }
	
}
