package com.fedex.emea.dimm.alert;

import java.sql.Timestamp;

public class AbstractAlert {

	private String logicalkey1;
	private String server;
	private String component;
	private String application;
	private String module;
	private String message;
	private String action;
	private String dashboardName;
	private String recordSourceId;
	private String caseSummary;
	private String caseDescription1;
	private String caseDescription2;
	private String caseDescription3;
	private String caseDescription4;
	private String caseDescription5;
	private String caseDescription6;
	private String caseDescription7;
	private String caseDescription8;
	private String caseDescription9;
	private String nexusCaseNumber;
	private String alertid;
	private String casesysid;
	private Timestamp creationTime;
	
	public String getCasesysid() {
		return casesysid;
	}
	public void setCasesysid(String casesysid) {
		this.casesysid = casesysid;
	}
	public String getAlertid() {
		return alertid;
	}
	public void setAlertid(String alertid) {
		this.alertid = alertid;
	}
	public String getNexusCaseNumber() {
		return nexusCaseNumber;
	}
	public void setNexusCaseNumber(String nexusCaseNumber) {
		this.nexusCaseNumber = nexusCaseNumber;
	}
	public String getRecordSourceId() {
		return recordSourceId;
	}
	public void setRecordSourceId(String recordSourceId) {
		this.recordSourceId = recordSourceId;
	}
	public String getCaseSummary() {
		return caseSummary;
	}
	public void setCaseSummary(String caseSummary) {
		this.caseSummary = caseSummary;
	}
	public String getCaseDescription1() {
		return caseDescription1;
	}
	public void setCaseDescription1(String caseDescription1) {
		this.caseDescription1 = caseDescription1;
	}
	public String getCaseDescription2() {
		return caseDescription2;
	}
	public void setCaseDescription2(String caseDescription2) {
		this.caseDescription2 = caseDescription2;
	}
	public String getCaseDescription3() {
		return caseDescription3;
	}
	public void setCaseDescription3(String caseDescription3) {
		this.caseDescription3 = caseDescription3;
	}
	public String getCaseDescription4() {
		return caseDescription4;
	}
	public void setCaseDescription4(String caseDescription4) {
		this.caseDescription4 = caseDescription4;
	}
	public String getCaseDescription5() {
		return caseDescription5;
	}
	public void setCaseDescription5(String caseDescription5) {
		this.caseDescription5 = caseDescription5;
	}
	public String getCaseDescription6() {
		return caseDescription6;
	}
	public void setCaseDescription6(String caseDescription6) {
		this.caseDescription6 = caseDescription6;
	}
	public String getCaseDescription7() {
		return caseDescription7;
	}
	public void setCaseDescription7(String caseDescription7) {
		this.caseDescription7 = caseDescription7;
	}
	public String getCaseDescription8() {
		return caseDescription8;
	}
	public void setCaseDescription8(String caseDescription8) {
		this.caseDescription8 = caseDescription8;
	}
	public String getCaseDescription9() {
		return caseDescription9;
	}
	public void setCaseDescription9(String caseDescription9) {
		this.caseDescription9 = caseDescription9;
	}
	public String getServer() {
		return server;
	}
	public void setServer(String server) {
		this.server = server;
	}
	public String getComponent() {
		return component;
	}
	public void setComponent(String component) {
		this.component = component;
	}
	public String getApplication() {
		return application;
	}
	public void setApplication(String application) {
		this.application = application;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}

	public String getDashboardName() {
		return dashboardName;
	}
	public void setDashboardName(String dashboardName) {
		this.dashboardName = dashboardName;
	}
	public Timestamp getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Timestamp creationTime) {
		this.creationTime = creationTime;
	}
	public String getLogicalkey1() {
		return logicalkey1;
	}
	public void setLogicalkey1(String logicalkey1) {
		this.logicalkey1 = logicalkey1;
	}
}
