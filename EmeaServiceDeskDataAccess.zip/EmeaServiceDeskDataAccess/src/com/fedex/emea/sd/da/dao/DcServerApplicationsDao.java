package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import com.fedex.emea.sd.da.objects.DcServerApplications;
import com.fedex.emea.sd.da.objects.DcServers;

public interface DcServerApplicationsDao {
	public DcServers createValueObject();
	public List<DcServerApplications> loadAllDcServerApplicationsByDataCenter(String dataCenter) throws SQLException;
}
