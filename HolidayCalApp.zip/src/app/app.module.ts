import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FullCalendarComponent } from './full-calendar/full-calendar.component';
import {FullCalendarModule} from 'primeng/fullcalendar';
import {  HttpClientModule } from '@angular/common/http';
import { NgMarqueeModule } from 'ng-marquee';
import { EventService } from './full-calendar/eventservice';



@NgModule({
  declarations: [
    AppComponent,
    FullCalendarComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FullCalendarModule,
    HttpClientModule,
    NgMarqueeModule
    
  ],
  exports: [    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
