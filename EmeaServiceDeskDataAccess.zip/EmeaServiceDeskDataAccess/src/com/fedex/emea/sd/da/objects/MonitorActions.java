package com.fedex.emea.sd.da.objects;

import com.fedex.emea.sd.da.objects.PrSpocs;

public class MonitorActions {
	
	private String actionType;
	private String actionPhase;
	private String targetMail;
	private String targetName;
	private String auditDeadline;
	private String mitigationsDeadline;
	private String correctiveActionsDeadline;
	private String validationsDeadline;
	private long   auditDaysLeft;
	private long   mitigationsDaysLeft;
	private long   correctiveActionsDaysLeft;
	private long   validationsDaysLeft;
	private String auditStatus;
	private String mitigationsStatus;
	private String correctiveActionsStatus;
	private String validationsStatus;
	private String escalationMail;
	private String escalationName;
	
	public MonitorActions() {
	}
	
	public MonitorActions(String actionType, String actionPhase, PrSpocs spoc, String strAuditDL, String strMitigationsDL, String strCorrActionsDL, String strValidationsDL, long auditDaysLeft, long mitigationsDaysLeft, long corrActionsDaysLeft, long validationsDaysLeft) {
		this.setTargets(spoc.getMgrMail(), spoc.getMgrName(), spoc.getMdMail(), spoc.getMdName());
		this.setDeadlines(strAuditDL, strMitigationsDL, strCorrActionsDL, strValidationsDL);
		this.setDaysLeft(auditDaysLeft, mitigationsDaysLeft, corrActionsDaysLeft, validationsDaysLeft);
		this.setStatus(spoc.getAuditStatus(), spoc.getMitigStatus(), spoc.getCorractStatus(), spoc.getValtestStatus());
		this.setActionType(actionType);
		this.setActionPhase(actionPhase);
	}
	
	public void setTargets(String targetMail, String targetName, String escalationMail, String escalationName) {
		this.setTargetMail(targetMail);
		this.setTargetName(targetName);
		this.setEscalationMail(escalationMail);
		this.setEscalationName(escalationName);
	}
	
	public void setDeadlines(String auditDeadline, String mitigationsDeadline, String correctiveActionsDeadline, String validationsDeadline) {
		this.setAuditDeadline(auditDeadline);
		this.setMitigationsDeadline(mitigationsDeadline);
		this.setCorrectiveActionsDeadline(correctiveActionsDeadline);
		this.setValidationsDeadline(validationsDeadline);
	}
	
	public void setDaysLeft(long auditDaysLeft, long mitigationsDaysLeft, long correctiveActionsDaysLeft, long validationsDaysLeft) {
		this.setAuditDaysLeft(auditDaysLeft);
		this.setMitigationsDaysLeft(mitigationsDaysLeft);
		this.setCorrectiveActionsDaysLeft(correctiveActionsDaysLeft);
		this.setValidationsDaysLeft(validationsDaysLeft);
	}
	
	public void setStatus(String auditStatus, String mitigationsStatus, String correctiveActionsStatus, String validationsStatus) {
		this.setAuditStatus(auditStatus);
		this.setMitigationsStatus(mitigationsStatus);
		this.setCorrectiveActionsStatus(correctiveActionsStatus);
		this.setValidationsStatus(validationsStatus);
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public String getTargetMail() {
		return targetMail;
	}

	public void setTargetMail(String targetMail) {
		this.targetMail = targetMail;
	}

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public String getAuditDeadline() {
		return auditDeadline;
	}

	public void setAuditDeadline(String auditDeadline) {
		this.auditDeadline = auditDeadline;
	}

	public String getMitigationsDeadline() {
		return mitigationsDeadline;
	}

	public void setMitigationsDeadline(String mitigationsDeadline) {
		this.mitigationsDeadline = mitigationsDeadline;
	}

	public String getCorrectiveActionsDeadline() {
		return correctiveActionsDeadline;
	}

	public void setCorrectiveActionsDeadline(String correctiveActionsDeadline) {
		this.correctiveActionsDeadline = correctiveActionsDeadline;
	}

	public String getValidationsDeadline() {
		return validationsDeadline;
	}

	public void setValidationsDeadline(String validationsDeadline) {
		this.validationsDeadline = validationsDeadline;
	}

	public long getAuditDaysLeft() {
		return auditDaysLeft;
	}

	public void setAuditDaysLeft(long auditDaysLeft) {
		this.auditDaysLeft = auditDaysLeft;
	}

	public long getMitigationsDaysLeft() {
		return mitigationsDaysLeft;
	}

	public void setMitigationsDaysLeft(long mitigationsDaysLeft) {
		this.mitigationsDaysLeft = mitigationsDaysLeft;
	}

	public long getCorrectiveActionsDaysLeft() {
		return correctiveActionsDaysLeft;
	}

	public void setCorrectiveActionsDaysLeft(long correctiveActionsDaysLeft) {
		this.correctiveActionsDaysLeft = correctiveActionsDaysLeft;
	}

	public long getValidationsDaysLeft() {
		return validationsDaysLeft;
	}

	public void setValidationsDaysLeft(long validationsDaysLeft) {
		this.validationsDaysLeft = validationsDaysLeft;
	}

	public String getEscalationMail() {
		return escalationMail;
	}

	public void setEscalationMail(String escalationMail) {
		this.escalationMail = escalationMail;
	}

	public String getEscalationName() {
		return escalationName;
	}

	public void setEscalationName(String escalationName) {
		this.escalationName = escalationName;
	}

	public String getAuditStatus() {
		return auditStatus;
	}

	public void setAuditStatus(String auditStatus) {
		this.auditStatus = auditStatus;
	}

	public String getMitigationsStatus() {
		return mitigationsStatus;
	}

	public void setMitigationsStatus(String mitigationsStatus) {
		this.mitigationsStatus = mitigationsStatus;
	}

	public String getCorrectiveActionsStatus() {
		return correctiveActionsStatus;
	}

	public void setCorrectiveActionsStatus(String correctiveActionsStatus) {
		this.correctiveActionsStatus = correctiveActionsStatus;
	}

	public String getValidationsStatus() {
		return validationsStatus;
	}

	public void setValidationsStatus(String validationsStatus) {
		this.validationsStatus = validationsStatus;
	}

	public String getActionPhase() {
		return actionPhase;
	}

	public void setActionPhase(String actionPhase) {
		this.actionPhase = actionPhase;
	}
	
	
}
