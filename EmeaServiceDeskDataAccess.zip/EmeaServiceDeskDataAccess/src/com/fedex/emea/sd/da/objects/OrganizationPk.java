package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

/** 
 * This class represents the primary key of the ORGANIZATION table.
 */
public class OrganizationPk implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3049315602658048785L;
	protected String id;

	/** 
	 * Sets the value of id
	 */
	public void setId(String id)
	{
		this.id = id;
	}

	/** 
	 * Gets the value of id
	 */
	public String getId()
	{
		return id;
	}

	/**
	 * Method 'OrganizationPk'
	 * 
	 */
	public OrganizationPk()
	{
	}

	/**
	 * Method 'OrganizationPk'
	 * 
	 * @param id
	 */
	public OrganizationPk(final String id)
	{
		this.id = id;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	public boolean equals(Object _other)
	{
		if (_other == null) {
			return false;
		}
		
		if (_other == this) {
			return true;
		}
		
		if (!(_other instanceof OrganizationPk)) {
			return false;
		}
		
		final OrganizationPk _cast = (OrganizationPk) _other;
		if (id == null ? _cast.id != id : !id.equals( _cast.id )) {
			return false;
		}
		
		return true;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode()
	{
		int _hashCode = 0;
		if (id != null) {
			_hashCode = 29 * _hashCode + id.hashCode();
		}
		
		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString()
	{
		StringBuffer ret = new StringBuffer();
		ret.append( "com.fedex.emea.sd.dto.OrganizationPk: " );
		ret.append( "id=" + id );
		return ret.toString();
	}

}
