package com.fedex.emea.sd.da.dao.spring;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.AllocatedtoassociationDao;
import com.fedex.emea.sd.da.exceptions.AllocatedtoassociationDaoException;
import com.fedex.emea.sd.da.objects.Allocatedtoassociation;
import com.fedex.emea.sd.da.objects.AllocatedtoassociationPk;

public class AllocatedtoassociationDaoImpl extends AbstractDAO implements ParameterizedRowMapper<Allocatedtoassociation>, AllocatedtoassociationDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return AllocatedtoassociationPk
	 */
	@Transactional
	public AllocatedtoassociationPk insert(Allocatedtoassociation dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getId(),dto.getAllocateeKeyPk(),dto.getAllocateeKeyType(),dto.getAllocatedKeyPk(),dto.getAllocatedKeyType(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.isIsOverlayComponentNull()?null:dto.getIsOverlayComponent());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the ALLOCATEDTOASSOCIATION table.
	 */
	@Transactional
	public void update(AllocatedtoassociationPk pk, Allocatedtoassociation dto) throws AllocatedtoassociationDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET ID = ?, ALLOCATEE_KEY_PK = ?, ALLOCATEE_KEY_TYPE = ?, ALLOCATED_KEY_PK = ?, ALLOCATED_KEY_TYPE = ?, DESCRIPTION = ?, LONG_DESCRIPTION = ?, LAST_MODIFICATION_USER_ID = ?, LAST_MODIFICATION_DATE = ?, LASTUPDATEVERSIONNUMBER = ?, CUSTOM_1 = ?, CUSTOM_2 = ?, CUSTOM_3 = ?, CUSTOM_4 = ?, CUSTOM_5 = ?, CUSTOM_6 = ?, CUSTOM_7 = ?, CUSTOM_8 = ?, CUSTOM_9 = ?, CUSTOM_10 = ?, IS_OVERLAY_COMPONENT = ? WHERE ID = ?",dto.getId(),dto.getAllocateeKeyPk(),dto.getAllocateeKeyType(),dto.getAllocatedKeyPk(),dto.getAllocatedKeyType(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getIsOverlayComponent(),pk.getId());
	}

	/** 
	 * Deletes a single row in the ALLOCATEDTOASSOCIATION table.
	 */
	@Transactional
	public void delete(AllocatedtoassociationPk pk) throws AllocatedtoassociationDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE ID = ?",pk.getId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return Allocatedtoassociation
	 */
	public Allocatedtoassociation mapRow(ResultSet rs, int row) throws SQLException
	{
		Allocatedtoassociation dto = new Allocatedtoassociation();
		dto.setId( rs.getString( 1 ) );
		dto.setAllocateeKeyPk( rs.getString( 2 ) );
		dto.setAllocateeKeyType( rs.getString( 3 ) );
		dto.setAllocatedKeyPk( rs.getString( 4 ) );
		dto.setAllocatedKeyType( rs.getString( 5 ) );
		dto.setDescription( rs.getString( 6 ) );
		dto.setLongDescription( rs.getString( 7 ) );
		dto.setLastModificationUserId( rs.getString( 8 ) );
		dto.setLastModificationDate( rs.getTimestamp(9 ) );
		dto.setLastupdateversionnumber( rs.getBigDecimal(10));
		dto.setCustom1( rs.getString( 11 ) );
		dto.setCustom2( rs.getString( 12 ) );
		dto.setCustom3( rs.getString( 13 ) );
		dto.setCustom4( rs.getString( 14 ) );
		dto.setCustom5( rs.getString( 15 ) );
		dto.setCustom6( rs.getString( 16 ) );
		dto.setCustom7( rs.getString( 17 ) );
		dto.setCustom8( rs.getString( 18 ) );
		dto.setCustom9( rs.getString( 19 ) );
		dto.setCustom10( rs.getString( 20 ) );
		dto.setIsOverlayComponent( rs.getInt( 21 ) );
		if (rs.wasNull()) {
			dto.setIsOverlayComponentNull( true );
		}
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "FIT_SCHEMA.ALLOCATEDTOASSOCIATION";
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public Allocatedtoassociation findByPrimaryKey(String id) throws AllocatedtoassociationDaoException
	{
		try {
			List<Allocatedtoassociation> list = jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ?", this,id);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria ''.
	 */
	@Transactional
	public List<Allocatedtoassociation> findAll() throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " ORDER BY ID", this);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table related to Peak Readiness In Scope Applications.
	 */
	@Transactional
	public Allocatedtoassociation findRelatedToInPrScope(String appId) throws AllocatedtoassociationDaoException
	{
		String selectFields = "ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT";
		String whereClause  = "ALLOCATEE_KEY_PK = ? " +
			                  "and ALLOCATEE_KEY_TYPE = 'com.ni2.core.ApplicationValue' " +
				              "and ALLOCATED_KEY_TYPE = 'com.ni2.core.OrganizationValue'";
		
		String sql = "SELECT " + selectFields 
				  + " FROM " + getTableName()
				  + " WHERE " + whereClause;
		
		try {
			List<Allocatedtoassociation> list = jdbcTemplate.query(sql, this, appId); 
			return list.size() == 0 ? null : list.get(0); 
		} catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
	}
	
	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereIdEquals(String id) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ? ORDER BY ID", this,id);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATEE_KEY_PK = :allocateeKeyPk'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereAllocateeKeyPkEquals(String allocateeKeyPk) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ALLOCATEE_KEY_PK = ? ORDER BY ALLOCATEE_KEY_PK", this,allocateeKeyPk);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATEE_KEY_TYPE = :allocateeKeyType'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereAllocateeKeyTypeEquals(String allocateeKeyType) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ALLOCATEE_KEY_TYPE = ? ORDER BY ALLOCATEE_KEY_TYPE", this,allocateeKeyType);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATED_KEY_PK = :allocatedKeyPk'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereAllocatedKeyPkEquals(String allocatedKeyPk) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ALLOCATED_KEY_PK = ? ORDER BY ALLOCATED_KEY_PK", this,allocatedKeyPk);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'ALLOCATED_KEY_TYPE = :allocatedKeyType'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereAllocatedKeyTypeEquals(String allocatedKeyType) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ALLOCATED_KEY_TYPE = ? ORDER BY ALLOCATED_KEY_TYPE", this,allocatedKeyType);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereDescriptionEquals(String description) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DESCRIPTION = ? ORDER BY DESCRIPTION", this,description);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereLongDescriptionEquals(String longDescription) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LONG_DESCRIPTION = ? ORDER BY LONG_DESCRIPTION", this,longDescription);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_USER_ID = ? ORDER BY LAST_MODIFICATION_USER_ID", this,lastModificationUserId);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereLastModificationDateEquals(Date lastModificationDate) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_DATE = ? ORDER BY LAST_MODIFICATION_DATE", this,lastModificationDate);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LASTUPDATEVERSIONNUMBER = ? ORDER BY LASTUPDATEVERSIONNUMBER", this,lastupdateversionnumber);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom1Equals(String custom1) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_1 = ? ORDER BY CUSTOM_1", this,custom1);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom2Equals(String custom2) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_2 = ? ORDER BY CUSTOM_2", this,custom2);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom3Equals(String custom3) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_3 = ? ORDER BY CUSTOM_3", this,custom3);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom4Equals(String custom4) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_4 = ? ORDER BY CUSTOM_4", this,custom4);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom5Equals(String custom5) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_5 = ? ORDER BY CUSTOM_5", this,custom5);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom6Equals(String custom6) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_6 = ? ORDER BY CUSTOM_6", this,custom6);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom7Equals(String custom7) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_7 = ? ORDER BY CUSTOM_7", this,custom7);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom8Equals(String custom8) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_8 = ? ORDER BY CUSTOM_8", this,custom8);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom9Equals(String custom9) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_9 = ? ORDER BY CUSTOM_9", this,custom9);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereCustom10Equals(String custom10) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_10 = ? ORDER BY CUSTOM_10", this,custom10);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ALLOCATEDTOASSOCIATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	@Transactional
	public List<Allocatedtoassociation> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws AllocatedtoassociationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, ALLOCATEE_KEY_PK, ALLOCATEE_KEY_TYPE, ALLOCATED_KEY_PK, ALLOCATED_KEY_TYPE, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE IS_OVERLAY_COMPONENT = ? ORDER BY IS_OVERLAY_COMPONENT", this,isOverlayComponent);
		}
		catch (Exception e) {
			throw new AllocatedtoassociationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the ALLOCATEDTOASSOCIATION table that matches the specified primary-key value.
	 */
	public Allocatedtoassociation findByPrimaryKey(AllocatedtoassociationPk pk) throws AllocatedtoassociationDaoException
	{
		return findByPrimaryKey( pk.getId() );
	}

}
