<%@page import="javax.mail.internet.MimeMultipart"%>
<%@page import="javax.mail.BodyPart"%>
<%@page import="javax.mail.Multipart"%>
<%@page import="javax.activation.DataHandler"%>
<%@page import="javax.activation.FileDataSource"%>
<%@page import="javax.activation.DataSource"%>
<%@page import="javax.mail.internet.MimeBodyPart"%>
<%@page import="java.io.IOException"%>
<%@page import="java.io.FileWriter"%>
<%@page import="java.io.BufferedWriter"%>
<%@page import="java.io.Writer"%>
<%@page import="java.io.File"%>
<%@page import="javax.mail.MessagingException"%>
<%@page import="javax.mail.internet.AddressException"%>
<%@page import="javax.mail.Transport"%>
<%@page import="javax.mail.Message"%>
<%@page import="javax.mail.internet.InternetAddress"%>
<%@page import="javax.mail.internet.MimeMessage"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.time.LocalTime"%>
<%@page import="java.util.*"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<jsp:useBean id="dao" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>

<html>    
	 <head>
	 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	 <title>SD Evaluation</title>
	 <script>
	 window.history.forward();
	 function noBack() { window.history.forward(); 
	 }
		function openLoginMenu() {	
			var number=document.getElementById("sessionid").value;  
			if(number==("user")){
	   			 window.close("Program1Result.jsp");
	   			window.open("LoginMenu.jsp");
	   		 }else{
	   			window.close("Program1Result.jsp");
	   			window.open("Admin.jsp");
	   		 }   		 
		}
	</script>
	<style type="text/css">		
			.head{
					height :50px;
					background-color: #4B0082;
					margin:0;					
			}						
			button{
			
			background-color:#4B0082;
			color:white;
			padding:14px 20px;
			margin: 8px 0;
			border:none;
			cursor:pointer;
			width:20%;
			}
			.login{
				
				display:flex;
				justify-content:center;
			}			
			.main{
				margin-left:10%;
				margin-right:12%;
			}
			.logout{
			float:right;
			margin-right:5%;
			background-color:#FF8C00;
			color:white;
			padding:8px 8px;
			border:none;
			cursor:pointer;
			}
			.logout:hover{
			background-color:#4B0060;
			}
			.question{
			font-family:Calibri;
			}
			.optiona{
			font-family:Calibri;
			}
			.optionb{
			font-family:Calibri;
			}
			.optionc{
			font-family:Calibri;
			}
			.optiond{
			font-family:Calibri;
			}
		</style>
	 </head>
	 
	 <body>
	 <%
	 if(session.getAttribute("sessionName")==null)
     {
         response.sendRedirect("Login.jsp");
		}
	
	 
	 String userID = (String) session.getAttribute("sessionName");
	 String sessionid = (String) session.getAttribute("sessionid");%>
	
	 <div class="main">
	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Program 1 Test Result</p></center>
   	</div>
        
     <form action=" ${pageContext.request.contextPath}/Logout" method="post">
		<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
	</form>
    <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
       <b>Welcome :</b> <%=userID %>
    </div>    
     <%	String question,optiona,optionb,optionc,optiond,Answer,Result,ans;  
  		Integer qid,Total = 0,k;
  		ArrayList<String> canslist = new ArrayList<String>();
  		ArrayList<String> cqidlist = new ArrayList<String>();
		Integer size=Integer.parseInt(request.getParameter("size"));
		
		
		String [] Uans = request.getParameterValues("cans");
		String [] Cqid = request.getParameterValues("cqid");
		
		final StringBuilder sbf = new StringBuilder(); 
  		%>	    
 <br>
 <br>		
<%   if(Uans!=null){
		for(k=0;k<Uans.length;k++){     		
			//out.println("after append "+Uans[k]+"</br>");
     	if(Uans[k].equals(":")){
     		canslist.add(sbf.toString());
     			int n = sbf.length();
     			sbf.replace(0, n,"");        			
     		}               		              	
     		else{
     			sbf.append(Uans[k]);
     			//out.println("after append "+sbf+"</br>");
     		} 
     	} 
}
%>
<% int j=0;   
StringBuilder emailattachment = new StringBuilder();
emailattachment.append("Test Results\r\n");
emailattachment.append("\r\n");
emailattachment.append(userID+"\r\n");
emailattachment.append("\r\n");

for(int i=0;i<size;i++){
	
         question=request.getParameter("question"+i);
         optiona=request.getParameter("qoptiona"+i);
         optionb=request.getParameter("qoptionb"+i);
         optionc=request.getParameter("qoptionc"+i);
         optiond=request.getParameter("qoptiond"+i);
         ans = request.getParameter("ans"+i);
         
         qid=Integer.parseInt(request.getParameter("qid"+i));         
 		 Answer = dao.getAnswerbyqid(qid);
 		
 		emailattachment.append((i+1)+". "+question+"\r\n");
 		emailattachment.append("A."+optiona+"\r\n");
 		emailattachment.append("B."+optionb+"\r\n");
 		
 		
 		
%>
 		<label class="question"><br><%=i+1%>) </label>
 		<label class="question"><%= question %><br></label>
 		<label class="optiona">A. <%= optiona%><br></label>
 		<label class="optionb">B. <%= optionb%><br></label>
 		<%if(!optionc.equals("null")){
 			emailattachment.append("C."+optionc+"\r\n");	
 		%>
 		<label class="optionc">C. <%= optionc%><br></label>
 		<%}%>
 		<%if(!optiond.equals("null")){
 			emailattachment.append("D."+optiond+"\r\n \r\n");
 		%>
 		<label class="optiond">D. <%= optiond%><br></label>
 		<%}%>		 				
 		<%	 			 			
 			if(Integer.toString(qid).equals(Cqid[j]))
 			{
 				
 				if(Answer.equals(canslist.get(j)))
 		 		{
 					emailattachment.append("Correct :"+canslist.get(j)+"\r\n");
 		 		%>
 		 			<label style="color:green;font-family:Calibri;">Correct : <%=canslist.get(j) %><br></label>
 		 			<%
 		 			Total++;
 		 			j++;
 		 		}else{
 		 			emailattachment.append("Wrong :"+canslist.get(j)+"\r\n");
 		 			%>
 		 			<label style="color:red;font-family:Calibri;">Wrong : <%=canslist.get(j) %><br></label>
 		 			<%
 		 			j++;
 		 		}
 			}
 			else{
 				if(Answer.equals(ans))
 		 		{
 					emailattachment.append("Correct :"+ans+"\r\n");
 		 		%>
 		 			<label style="color:green;font-family:Calibri;">Correct : <%=ans %><br></label>
 		 			<%
 		 			Total++;
 		 		}else{
 		 			emailattachment.append("Wrong :"+ans+"\r\n");
 		 			%>
 		 			<label style="color:red;font-family:Calibri;">Wrong : <%=ans %><br></label>
 		 			<%
 		 		}
 			}
 		
 		
 		emailattachment.append("---------------------------------------------------------------------\r\n");
 		
     } 
j=0;
     session.setAttribute("Total", Total);
     %>
     <hr>
     <label style="font-family:Calibri;font-size:18px;">You Scored : <%= Total %></label>  <br>  
	  <% 
	 
	  if(Total>=40){
		  Result ="Pass";%>Your Result is :
		  <label style="color:green;font-size:18px;font-family:Calibri;">Pass</label>    
		<%}else{
			Result ="Fail";%>Your Result is :
			<label style="color:red;font-size:18px;font-family:Calibri;">Fail</label>   
			<% 
		}
	  emailattachment.append("\r\n");
	  emailattachment.append("Total :"+Total+"\r\n");
	  emailattachment.append("Result :"+Result+"\r\n");
	  
	
	 %>	
	 <% 
	 //Development
	 //String contextPath = getServletContext().getRealPath("/");
	// String filename=contextPath+"\\test.txt";
	// out.println(filename);
	// File myfile = new File(filename);
	 
	//Test Server 
	String filename = "/automationtools/AutomationTools/deployments/test.txt";
	 File myfile = new File(filename);

	 myfile.createNewFile();
	 Writer objWriter = new BufferedWriter(new FileWriter(myfile));
	 objWriter.write(emailattachment.toString());
	 objWriter.flush();
	 objWriter.close();

	 %>
	 <%	   
	 	String mailTo = (String) session.getAttribute("UserMail");	
		String mailcc = "ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";

	 	Properties props = System.getProperties();
		props.put("mail.smtp.host", "mapper.gslb.fedex.com");
		props.put("mail.smtp.port", "25");
		props.put("mail.smtp.connectiontimeout", 10000);
		props.put("mail.smtp.timeout", 10000);
		props.put("mail.smtp.writetimeout", 10000);
		
		Session session1 = Session.getDefaultInstance(props, null);
		MimeMessage message = new MimeMessage(session1);
		
		try {
			message.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
		  	message.addRecipient(Message.RecipientType.TO, new InternetAddress(mailTo));
		  	message.addRecipient(Message.RecipientType.CC, new InternetAddress(mailcc));

			message.setSubject("Program 1 Evaluation Test Result");
			//message.setText(htmlText);
			StringBuilder email = new StringBuilder();
			email.append("<html><head>");		
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">"+userID+"</label>");
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thank you for taking the evaluation test</label>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">You Scored :"+Total+"</label>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Your Result is :"+Result+"</label><br>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
			email.append("</html></head>");						
			message.setContent(email.toString(),"text/html" ); 

			// Send message
			Transport.send(message);
			
		}  catch (MessagingException e) {
			throw e;
		}
	 %>
	 
	  <%
	 	String reportMailTo = "ApplicationSupport_Evaluation_Result@corp.ds.fedex.com";

	 	Properties props1 = System.getProperties();
		props1.put("mail.smtp.host", "mapper.gslb.fedex.com");
		props1.put("mail.smtp.port", "25");
		props1.put("mail.smtp.connectiontimeout", 10000);
		props1.put("mail.smtp.timeout", 10000);
		props1.put("mail.smtp.writetimeout", 10000);
		
		Session session11 = Session.getDefaultInstance(props, null);
		MimeMessage message1 = new MimeMessage(session11);
		
		try {
			message1.setFrom(new InternetAddress("Evaluation.noreply@fedex.com"));
		  	message1.addRecipient(Message.RecipientType.TO, new InternetAddress(reportMailTo));
			
		  	BodyPart messageBodyPart1 = new MimeBodyPart(); 
			
			message1.setSubject("Evaluation Test Details");
			
			StringBuilder email = new StringBuilder();
			email.append("<html><head>");					
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Please find attached the details of the test taken by:</label>");
			email.append("<br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">"+userID+"</label>");
			email.append("<br><br>");
			email.append("<label style=\"font-family:Calibri;font-size:16px\">Thanks and Regards,<br>FedEx Application Support Evaluation Team</label>");
			email.append("</html></head>");		
			messageBodyPart1.setContent(email.toString(),"text/html" ); 			
			
			MimeBodyPart messageBodyPart2 = new MimeBodyPart();  	        
	        
	        DataSource source = new FileDataSource(filename);  
	        messageBodyPart2.setDataHandler(new DataHandler(source));  
	        messageBodyPart2.setFileName("test.txt");  
	         
	        // create Multi part object and add MimeBodyPart objects to this object      
	        Multipart multipart = new MimeMultipart();  
	        multipart.addBodyPart(messageBodyPart1);  
	        multipart.addBodyPart(messageBodyPart2);  
	        message1.setContent(multipart);  
	        Transport.send(message1);

		}  catch (MessagingException e) {
			throw e;
		}
	 %>
	 
	 
	 <hr>
	  <br>
	   <input type="hidden" id="sessionid" value="<%=sessionid %>">
	  <button onclick="openLoginMenu()">HOME</button>
	  <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
	  </div>
 
     
     <div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;© 2020 FedEx Express EMEA		
	</div>
</body>
     </body>    
</html>
