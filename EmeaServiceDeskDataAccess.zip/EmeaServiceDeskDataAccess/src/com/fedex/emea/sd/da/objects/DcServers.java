package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class DcServers implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String serverId;
	private String serverName;
	private String serverType;
	private String serverDescription;
	private String serverDataCenter;
	private String serverStatus;
	private String serverSoftwareVersion;
	
	public DcServers() {	
	}
	
	
	public DcServers(String serverId, String serverName, String serverType, String serverDescription, String serverDataCenter, String serverStatus) {
		this.setServerId(serverId);
		this.setServerName(serverName);
		this.setServerType(serverType);
		this.setServerDescription(serverDescription);
		this.setServerDataCenter(serverDataCenter);
		this.setServerStatus(serverStatus);
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getServerStatus() {
		return serverStatus;
	}

	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}

	public String getServerType() {
		return serverType;
	}

	public void setServerType(String serverType) {
		this.serverType = serverType;
	}

	public String getServerDescription() {
		return serverDescription;
	}

	public void setServerDescription(String serverDescription) {
		this.serverDescription = serverDescription;
	}

	public String getServerDataCenter() {
		return serverDataCenter;
	}

	public void setServerDataCenter(String serverDataCenter) {
		this.serverDataCenter = serverDataCenter;
	}


	public String getServerSoftwareVersion() {
		return serverSoftwareVersion;
	}


	public void setServerSoftwareVersion(String serverSoftwareVersion) {
		this.serverSoftwareVersion = serverSoftwareVersion;
	}


	public String getServerId() {
		return serverId;
	}


	public void setServerId(String serverId) {
		this.serverId = serverId;
	}
	
}
