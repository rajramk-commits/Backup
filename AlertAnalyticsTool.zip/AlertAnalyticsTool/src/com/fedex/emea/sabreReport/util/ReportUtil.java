package com.fedex.emea.sabreReport.util;

import java.util.Map;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.chart.AxisCrosses;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.BarDirection;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.XDDFBarChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.fedex.emea.sabreReport.constants.ReportConstants;

public class ReportUtil {
	
	public static void main(String[] args) throws IOException {
		allTypeAlertChat();
		//processStoppedChat();
	}

	public static boolean allTypeAlertChat() throws FileNotFoundException, IOException {
		
		Map<String, Integer> alertTypeList = ProcessInFile.getAlertTypeDetails(ReportConstants.DIRECTORY_PATH + "Input_File.xlsx");
		System.out.println("alertTypeList :"+alertTypeList);
		
		try (XSSFWorkbook wb = new XSSFWorkbook()) {

			String sheetName = "AllType Alerts";
			XSSFSheet sheet = wb.createSheet(sheetName);

			// Create row and put some cells in it. Rows and cells are 0 based.
			int rowCount = 0;
			Row row = sheet.createRow((short) rowCount);
			row.setRowStyle(getBoldCSS(wb));
			Cell cell = row.createCell((short) 0);
			cell.setCellValue("Row Labels");
			cell = row.createCell((short) 1);			
			cell.setCellValue("Count of Number");
			int excludeCnt = 0;
			for (Map.Entry<String, Integer> mapElement : alertTypeList.entrySet()) { 
	            String key = mapElement.getKey(); 
	            int value = mapElement.getValue();
	            if(value != 0)
	            {
		            row = sheet.createRow((short) ++rowCount);
		            cell = row.createCell((short) 0);
					cell.setCellValue(key);
					cell = row.createCell((short) 1);			
					cell.setCellValue(value);
					excludeCnt++;
	            }
	        }
			XSSFDrawing drawing = sheet.createDrawingPatriarch();
			XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 3, 6, 12, 22);

			XSSFChart chart = drawing.createChart(anchor);
			chart.setTitleText("AllType Alerts");
			chart.setTitleOverlay(false);

			//XDDFChartLegend legend = chart.getOrAddLegend();
			//legend.setPosition(LegendPosition.TOP_RIGHT);
			
			XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            //bottomAxis.setTitle("x");
            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            //leftAxis.setTitle("y");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

			XDDFDataSource<String> alertTypes = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(1, (alertTypeList.size()-excludeCnt), 0, 0));

			XDDFNumericalDataSource<Double> counts = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, (alertTypeList.size()-excludeCnt), 1, 1));
			
			XDDFChartData data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
            XDDFChartData.Series series1 = data.addSeries(alertTypes, counts);
            series1.setTitle("AllType Alerts", null);
			data.setVaryColors(false);
			chart.plot(data);
			
			// in order to transform a bar chart into a column chart, you just need to change the bar direction
            XDDFBarChartData bar = (XDDFBarChartData) data;
            //bar.setBarDirection(BarDirection.BAR);
            bar.setBarDirection(BarDirection.COL);

			// Write output to an excel file
            String filename = ReportConstants.DIRECTORY_PATH + "SABRE Report.xlsx";
			try (FileOutputStream fileOut = new FileOutputStream(filename)) {
				wb.write(fileOut);
			}
			
	/**
	 * ProcessStopped Alerts
	 * 
	 */
	Map<String, Integer> processStoppedList = ProcessInFile.getProcessStoppedDetails(ReportConstants.DIRECTORY_PATH + "Input_File.xlsx");
	System.out.println("ProcessStopped Alerts :"+processStoppedList);
			
			sheetName = "ProcessStopped Alerts";
			sheet = wb.createSheet(sheetName);

			// Create row and put some cells in it. Rows and cells are 0 based.
			rowCount = 0;
			row = sheet.createRow((short) rowCount);
			row.setRowStyle(getBoldCSS(wb));
			cell = row.createCell((short) 0);
			cell.setCellValue("Row Labels");
			cell = row.createCell((short) 1);			
			cell.setCellValue("Count of Number");
			
			for (Map.Entry<String, Integer> mapElement : processStoppedList.entrySet()) { 
	            String key = mapElement.getKey(); 
	            int value = mapElement.getValue();
	            row = sheet.createRow((short) ++rowCount);
	            cell = row.createCell((short) 0);
				cell.setCellValue(key);
				cell = row.createCell((short) 1);			
				cell.setCellValue(value);            
	        }
			drawing = sheet.createDrawingPatriarch();
			anchor = drawing.createAnchor(0, 0, 0, 0, 3, 6, 8, 16);

			chart = drawing.createChart(anchor);
			chart.setTitleText("ProcessStopped Alerts");
			chart.setTitleOverlay(false);

			//XDDFChartLegend legend = chart.getOrAddLegend();
			//legend.setPosition(LegendPosition.TOP_RIGHT);
			
			bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            //bottomAxis.setTitle("x");
            leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            //leftAxis.setTitle("y");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

			alertTypes = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(1, processStoppedList.size(), 0, 0));

			counts = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, processStoppedList.size(), 1, 1));
			
			data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
            series1 = data.addSeries(alertTypes, counts);
            series1.setTitle("ProcessStopped Alerts", null);
			data.setVaryColors(false);
			chart.plot(data);
			
			// in order to transform a bar chart into a column chart, you just need to change the bar direction
            bar = (XDDFBarChartData) data;
            //bar.setBarDirection(BarDirection.BAR);
            bar.setBarDirection(BarDirection.COL);

			// Write output to an excel file
            filename = ReportConstants.DIRECTORY_PATH + "SABRE Report.xlsx";
			try (FileOutputStream fileOut = new FileOutputStream(filename)) {
			wb.write(fileOut);
            }
			
	/**
	 * FileSystem Alerts
	 * 
	 */
	Map<String, Integer> fileSystemDataList = ProcessInFile.getFileSystemDetails(ReportConstants.DIRECTORY_PATH + "Input_File.xlsx");
	System.out.println("fileSystemDataList Alerts :"+fileSystemDataList);
	System.out.println("fileSystemDataList.size() :"+fileSystemDataList.size());
			try {
			sheetName = "FileSystem Alerts";
			sheet = wb.createSheet(sheetName);

			// Create row and put some cells in it. Rows and cells are 0 based.
			rowCount = 0;
			row = sheet.createRow((short) rowCount);
			row.setRowStyle(getBoldCSS(wb));
			cell = row.createCell((short) 0);
			cell.setCellValue("Row Labels");
			cell = row.createCell((short) 1);			
			cell.setCellValue("Count of Number");
			
			for (Map.Entry<String, Integer> mapElement : fileSystemDataList.entrySet()) { 
	            String key = mapElement.getKey(); 
	            int value = mapElement.getValue();
	            row = sheet.createRow((short) ++rowCount);
	            cell = row.createCell((short) 0);
				cell.setCellValue(key);
				cell = row.createCell((short) 1);			
				cell.setCellValue(value);            
	        }
			drawing = sheet.createDrawingPatriarch();
			anchor = drawing.createAnchor(0, 0, 0, 0, 3, 6, 15, 25);

			chart = drawing.createChart(anchor);
			chart.setTitleText("FileSystem Alerts");
			chart.setTitleOverlay(false);

			//XDDFChartLegend legend = chart.getOrAddLegend();
			//legend.setPosition(LegendPosition.TOP_RIGHT);
			
			bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            //bottomAxis.setTitle("x");
            leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            //leftAxis.setTitle("y");
            leftAxis.setCrosses(AxisCrosses.AUTO_ZERO);

			alertTypes = XDDFDataSourcesFactory.fromStringCellRange(sheet,
					new CellRangeAddress(1, fileSystemDataList.size(), 0, 0));

			counts = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
					new CellRangeAddress(1, fileSystemDataList.size(), 1, 1));
			
			data = chart.createData(ChartTypes.BAR, bottomAxis, leftAxis);
            series1 = data.addSeries(alertTypes, counts);
            series1.setTitle("FileSystem Alerts", null);
			data.setVaryColors(false);
			chart.plot(data);
			
			// in order to transform a bar chart into a column chart, you just need to change the bar direction
            bar = (XDDFBarChartData) data;
            //bar.setBarDirection(BarDirection.BAR);
            bar.setBarDirection(BarDirection.COL);
			
			// Write output to an excel file
            filename = ReportConstants.DIRECTORY_PATH + "SABRE Report.xlsx";
			try (FileOutputStream fileOut = new FileOutputStream(filename)) {
			wb.write(fileOut);
            }
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public static CellStyle getBoldCSS(Workbook wb)
	{
		CellStyle style = wb.createCellStyle();
		XSSFFont  defaultFont= (XSSFFont) wb.createFont();
	    defaultFont.setFontName("Arial");
	    defaultFont.setColor(IndexedColors.BLACK.getIndex());
	    defaultFont.setBold(false);
	    style.setFont(defaultFont);
	    return style;
	}
}
