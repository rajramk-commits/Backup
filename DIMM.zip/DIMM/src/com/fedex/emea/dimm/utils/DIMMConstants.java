package com.fedex.emea.dimm.utils;

public class DIMMConstants {

	public static final String PHYSICALKEY_COLUMN = "alertid";
	public static final String DASHBOARDNAME_COLUMN = "recordsource";
	public static final String RECORDSOURCE_ID_COLUMN = "recordsourceid";
	public static final String CASESUMMARY_COLUMN = "casesummary";
	public static final String LOGICALKEY_COLUMN = "logicalkey";
	public static final String CASEID_COLUMN = "caseid";
	public static final String CASESYSID_COLUMN = "casesysid";
	//public static final String NEXUS_CASEID_OVO_COLUMN = "nexuscaseid";
	public static final String NEXUS_CASEID_COLUMN = "case_id";
	public static final String NEXUS_CASESTATUS_COLUMN = "rc_status";
	public static final String NEXUS_CASE_CREATEDTIME_COLUMN = "createdtime";
	public static final String CASEDESCRIPTION1_COLUMN = "casedescription1";
	public static final String CASEDESCRIPTION2_COLUMN = "casedescription2";
	public static final String CASEDESCRIPTION3_COLUMN = "casedescription3";
	public static final String CASEDESCRIPTION4_COLUMN = "casedescription4";
	public static final String CASEDESCRIPTION5_COLUMN = "casedescription5";
	public static final String CASEDESCRIPTION6_COLUMN = "casedescription6";
	public static final String CASEDESCRIPTION7_COLUMN = "casedescription7";
	public static final String CASEDESCRIPTION8_COLUMN = "casedescription8";
	public static final String CASEDESCRIPTION9_COLUMN = "casedescription9";
	//public static final String NO_MSG_CONSUME = "NO_MSG_CONSUME";
	public static final String ITO_APPLICATIONS = "NO_MSG_CONSUME,ABOVE_CRITICAL_LEVEL,JMSVolumeAlert,JMSVolumeFull";
	public static final String DTRC_APPLICATIONS = "genius.dtrc.ftp.gb.upload,genius.dtrc.upload,genius.dtrc.ftp.fr.upload,genius.dtrc.gb.upload.check,genius.dtrc.fr.upload.check";
	//public static final String ABOVE_CRITICAL_LEVEL = "ABOVE_CRITICAL_LEVEL";
	//public static final String NO_MSG_CONSUME_OR_ABOVE_CRITICAL_LEVEL = "NO_MSG_CONSUME_OR_ABOVE_CRITICAL_LEVEL";
	public static final String ITO_APPLICATION_GNERICVALUE = "NO_MSG_CONSUME_OR_ABOVE_CRITICAL_LEVEL_OR_JMSVolumeAlert_OR_JMSVolumeFull";
	public static final String ITIH_RECORDSOURCE = "itih.recordsource";
	public static final String ITIH_SERVER = "ITIHServer";
	public static final String GENERIC_SERVER = "GenericServer";
	public static final String OVO_SERVER_COMPONENTS = "FILE_SYSTEM,ServerResponseDetection,ServerRebootDetection,ServerReachableDetection";
	public static final String CREATIONTIME_COLUMN = "creationtime";
	
	//For 8 hour rule
	public static final String CASE_CLOSED_STATUS = "RESOL,CLOS,OOS,DUP";
}