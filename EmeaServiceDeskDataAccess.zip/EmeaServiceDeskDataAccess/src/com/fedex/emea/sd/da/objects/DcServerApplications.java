package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class DcServerApplications implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String businessCriticality;
	private String serviceName;
	private String applicationName;
	private DcServers hostingServer;
	private String responsibleManager;
	
	public DcServerApplications() {
	}
	
	public DcServerApplications(String businessCriticality, String serviceName, String applicationName, DcServers hostingServer, String responsibleManager) {
		this.setBusinessCriticality(businessCriticality);
		this.setServiceName(serviceName);
		this.setApplicationName(applicationName);
		this.setHostingServer(hostingServer);
		this.setResponsibleManager(responsibleManager);
	}

	public String getBusinessCriticality() {
		return businessCriticality;
	}

	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public DcServers getHostingServer() {
		return hostingServer;
	}

	public void setHostingServer(DcServers hostingServer) {
		this.hostingServer = hostingServer;
	}

	public String getResponsibleManager() {
		return responsibleManager;
	}

	public void setResponsibleManager(String responsibleManager) {
		this.responsibleManager = responsibleManager;
	}
	
}
