<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
    <%@page import="java.util.*"%> 
    <%@page import="com.fedex.emea.sabreReport.model.*"%>
  <jsp:useBean id="ReportService" class="com.fedex.emea.sabreReport.service.ReportService" scope="page"/>
  <jsp:useBean id="ProcessData" class="com.fedex.emea.sabreReport.util.ProcessData" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
@SuppressWarnings("unchecked")
	List<SabreBean> data = (List<SabreBean>) request.getSession().getAttribute("sabreList");
if(data == null || data.size() ==0)
{
	data = (List<SabreBean>) request.getSession().getAttribute("gssList");
}
if(data != null && data.size() != 0)
{
	try
	{
	ProcessData.saveData(data);
	
	String res  = "Successfully created report under the selected folder :C:/Users/rajarama.kaniyoor/Documents/SabreConnect/Results";
			//ReportService.generateReport();
	System.out.println("Result :"+res);
	response.sendRedirect("SabreHomePage.jsp?status="+res);
	}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
}
else
	response.sendRedirect("SabreHomePage.jsp?status=No Data found to store");
%>
</body>
</html>