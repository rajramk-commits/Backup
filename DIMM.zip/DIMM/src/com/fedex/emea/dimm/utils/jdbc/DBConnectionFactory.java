package com.fedex.emea.dimm.utils.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fedex.emea.dimm.app.DIMMDao;

public class DBConnectionFactory {
	
	private static final Logger log = LogManager.getLogger(DIMMDao.class);
	
	private static DBConnectionFactory instance = new DBConnectionFactory();

	public static DBConnectionFactory getInstance() {
		return instance;
	}
	
	public DBConnectionFactory() {		
		try{
			//Load the Oracle JDBC driver
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		}catch(Exception exception){
			//LogFactory.getLogger().logException("Error: ",exception);
			log.error("Unexpected error:: ", exception);
		}
	}
	
	public Connection getConnection(DBConfig dbConfig) throws Exception{
		if(dbConfig!=null){

			//LogFactory.getLogger().logDebug("Direct JDBC Connection for URL ["+dbConfig.getJdbcURL()+" User["+dbConfig.getUserName()+"]");
			//log.info("Direct JDBC Connection for URL ["+dbConfig.getJdbcURL()+" User["+dbConfig.getUserName()+"]");
			
			return DriverManager.getConnection(dbConfig.getJdbcURL(), dbConfig.getUserName(), dbConfig.getPassword());
		}else{
			return null;
		}
	}
	
	
	public void releaseConnection(Connection con) {
		try {
			/* returning connection to the pool*/
			if(con == null)
				return;
			con.close();
			con = null;
		} catch (Exception exception) {
			//LogFactory.getLogger().logException("Exception : ",exception);
			log.error("Unexpected error:: ", exception);
		}
	}
	
}
