package com.fedex.emea.sd.snow.objects;

import java.util.Calendar;

import com.fedex.emea.sd.snow.utilities.SnowConstants;

public class SnowTestObjects {
	
	public static SnowIncident getNewCriticalIncident() {
		SnowIncident incident = new SnowIncident();
		
		incident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
		incident.setSnowState(SnowConstants.STATE_REGISTERED);
		incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
		incident.setSnowU_Classification(SnowConstants.CLASSIFICATION_APP_SOFT_OS);
		
		incident.setSnowPriority(SnowConstants.PRIORITY_CRITICAL);
		incident.setSnowUrgency("2");
		incident.setSnowImpact(SnowConstants.IMPACT_PART_FAILURE);
		
		incident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
		incident.setSnowU_BusinessService("347dd0e6db8dcb80528cfbc61d9619b6"); 	// APOLLO
		incident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDX-SD-Helpdesk
		incident.setSnowShortDescription("TEST - Critical APOLLO AppSoftOS Event to SD");
		incident.setSnowDescription("TEST - Description - Critical APOLLO AppSoftOS Event to SD");
		incident.setSnowU_Instructions("Alert Instructions...CRITICAL");
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}
	
	public static SnowIncident getNewHighIncident() {
		SnowIncident incident = new SnowIncident();
		
		incident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
		incident.setSnowState(SnowConstants.STATE_REGISTERED);
		incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
		incident.setSnowU_Classification(SnowConstants.CLASSIFICATION_HARDW);
		
		incident.setSnowPriority(SnowConstants.PRIORITY_HIGH);
		incident.setSnowUrgency("2");
		incident.setSnowImpact(SnowConstants.IMPACT_PART_FAILURE);
		
		incident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
		incident.setSnowU_BusinessService("347dd0e6db8dcb80528cfbc61d9619b6"); 	// APOLLO
		incident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDX-SD-Helpdesk
		incident.setSnowShortDescription("TEST - High APOLLO Hardw Event to SD");
		incident.setSnowDescription("TEST - Description - High APOLLO Hardw Event to SD");
		incident.setSnowU_Instructions("Alert Instructions...HIGH");
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}

	/*public static SnowIncident getNewMajorIncident() {
		SnowIncident incident = new SnowIncident();
		
		incident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
		incident.setSnowState(SnowConstants.STATE_REGISTERED);
		incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
		incident.setSnowU_Classification(SnowConstants.CLASSIFICATION_NET_COMM);
		
		incident.setSnowPriority(SnowConstants.PRIORITY_MAJOR);  
		incident.setSnowUrgency("2");
		incident.setSnowImpact(SnowConstants.IMPACT_PART_FAILURE);
		
		incident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
		incident.setSnowU_BusinessService("347dd0e6db8dcb80528cfbc61d9619b6"); 	// APOLLO
		incident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDX-SD-Helpdesk
		incident.setSnowShortDescription("TEST - Major APOLLO NetComm Event to SD");
		incident.setSnowDescription("TEST - Description - Major APOLLO NetComm Event to SD");
		incident.setSnowU_Instructions("Alert Instructions...MAJOR");
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}*/

	public static SnowIncident getNewMinorIncident() {
		SnowIncident incident = new SnowIncident();
		
		incident.setSnowCategory(SnowConstants.CATEGORY_INCIDENT);
		incident.setSnowState(SnowConstants.STATE_REGISTERED);
		incident.setSnowSubcategory(SnowConstants.SUB_CATEGORY_EVENT);
		incident.setSnowU_Classification(SnowConstants.CLASSIFICATION_NET_COMM);
		
		incident.setSnowPriority(SnowConstants.PRIORITY_MINOR);
		incident.setSnowUrgency("2");
		incident.setSnowImpact(SnowConstants.IMPACT_PART_FAILURE);
		
		incident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);
		incident.setSnowU_BusinessService("347dd0e6db8dcb80528cfbc61d9619b6"); 	// APOLLO
		incident.setSnowAssignmentGroup("621add04dbd6f600eab5f3541d961972");	// FDX-SD-Helpdesk
		incident.setSnowShortDescription("TEST - Minor APOLLO NetComm Event to SD");
		incident.setSnowDescription("TEST - Description - Minor APOLLO NetComm Event to SD");
		incident.setSnowU_Instructions("Alert Instructions...MINOR");
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}
	
	public static SnowIncident getNewIncident() {
		SnowIncident incident = new SnowIncident();
				
		incident.setSnowContactType(SnowConstants.CONTACT_MEDIUM_EVENT);		
//		incident.setSnowU_ServiceState(Constants.SERVICE_STATE_NOT_AFFECTED); // ONLY for "In Progress" !!!
//		incident.setSnowU_SitesAffected(SnowConstants.SITES_AFFECTED_SINGLE);
		
		// !!! Set "In Progress" automatically when filled-in !!!!
		//incident.setSnowAssignedTo("ed942e02db493200e8acb04ffe961997"); // ONLY when "In Progress"
		
		incident.setSnowShortDescription("TEST - Short Description TEST");
		
		StringBuilder incidentDescription = new StringBuilder();
		incidentDescription.append("TEST Description");
		incident.setSnowDescription(incidentDescription.toString());
		
		incident.setSnowU_Instructions("Alert TEST Instructions...");
		incident.setSnowU_Escalated("false");
		incident.setSnowU_RepeatIncident("false");
		incident.setSnowU_ApplicationCode("TEST Application Code");
		incident.setSnowU_BatchStep("TEST Batch Step");
		incident.setSnowU_JobNumber("TEST Job Number");
		incident.setSnowU_ThirdPartyReference("TEST Third Party Reference");
		
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}
	
	public static SnowAstcIncident getNewAstcIncident() {
		SnowAstcIncident incident = new SnowAstcIncident();
				
//		incident.setSnowU_ContactType(SnowConstants.CONTACT_MEDIUM_EVENT);		
//		incident.setSnowU_ServiceState(Constants.SERVICE_STATE_NOT_AFFECTED); // ONLY for "In Progress" !!!
//		incident.setSnowU_SitesAffected(SnowConstants.SITES_AFFECTED_SINGLE);
		
		// !!! Set "In Progress" automatically when filled-in !!!!
		//incident.setSnowAssignedTo("ed942e02db493200e8acb04ffe961997"); // ONLY when "In Progress"
		
		incident.setSnowU_ShortDescription("TEST - Short Description TEST");
		
		StringBuilder incidentDescription = new StringBuilder();
		incidentDescription.append("TEST Description");
		incident.setSnowU_Description(incidentDescription.toString());
		incident.setSnowU_Instructions("Alert TEST Instructions...");
		incident.setSnowU_Folder(SnowConstants.U_FOLDER_FEDEX);
		
		return incident;
	}
	
	public static SnowIncident getUpdatedIncident() {
		SnowIncident incident = new SnowIncident();
		
		incident.setSnowShortDescription("UPDATED 1 - TEST Short Description");
		
		return incident;
	}
	
	public static SnowIncidentWorkNote getNewWorkNoteForIncidentSysId(String sysId) {
		SnowIncidentWorkNote workNote = new SnowIncidentWorkNote();
		
		workNote.setWorkNoteElement("work_notes");
		workNote.setWorkNoteElementId(sysId);
		workNote.setWorkNoteName("task");
		workNote.setWorkNoteValue("");
		workNote.setWorkNoteSubject(SnowConstants.WORKNOTE_SUBJECT_COMMUNICATION);
		workNote.setWorkNoteText("TEST Work Note Action at " + Calendar.getInstance().getTimeInMillis());
		
		return workNote;
	}
	
 }
