package com.fedex.emea.sd.da.dao.spring;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.ApplicationtypeDao;
import com.fedex.emea.sd.da.exceptions.ApplicationtypeDaoException;
import com.fedex.emea.sd.da.objects.Applicationtype;
import com.fedex.emea.sd.da.objects.ApplicationtypePk;

public class ApplicationtypeDaoImpl extends AbstractDAO implements ParameterizedRowMapper<Applicationtype>, ApplicationtypeDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return ApplicationtypePk
	 */
	@Transactional
	public ApplicationtypePk insert(Applicationtype dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getId(),dto.getType(),dto.getApplicationRevision(),dto.getApplicationVersion(),dto.getManagementStatus(),dto.getManufacturerPk(),dto.getManufacturerType(),dto.getManufacturerPartNumber(),dto.getManufacturerPartCode(),dto.getManufacturerBrandName(),dto.isManufacturerUnitCostNull()?null:dto.getManufacturerUnitCost(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getSubCategoryKeyType(),dto.getSubCategoryKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.isIsOverlayComponentNull()?null:dto.getIsOverlayComponent());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the APPLICATIONTYPE table.
	 */
	@Transactional
	public void update(ApplicationtypePk pk, Applicationtype dto) throws ApplicationtypeDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET ID = ?, TYPE = ?, APPLICATION_REVISION = ?, APPLICATION_VERSION = ?, MANAGEMENT_STATUS = ?, MANUFACTURER_PK = ?, MANUFACTURER_TYPE = ?, MANUFACTURER_PART_NUMBER = ?, MANUFACTURER_PART_CODE = ?, MANUFACTURER_BRAND_NAME = ?, MANUFACTURER_UNIT_COST = ?, CUSTOM_1 = ?, CUSTOM_2 = ?, CUSTOM_3 = ?, CUSTOM_4 = ?, CUSTOM_5 = ?, OBJECT_DEFAULT_KEY_TYPE = ?, OBJECT_DEFAULT_KEY_PK = ?, SUB_CATEGORY_KEY_TYPE = ?, SUB_CATEGORY_KEY_PK = ?, DESCRIPTION = ?, LONG_DESCRIPTION = ?, LAST_MODIFICATION_USER_ID = ?, LAST_MODIFICATION_DATE = ?, LASTUPDATEVERSIONNUMBER = ?, CUSTOM_6 = ?, CUSTOM_7 = ?, CUSTOM_8 = ?, CUSTOM_9 = ?, CUSTOM_10 = ?, ENVIRONMENT = ?, INVENTORY_KEY_TYPE = ?, INVENTORY_KEY_PK = ?, IS_OVERLAY_COMPONENT = ? WHERE ID = ?",dto.getId(),dto.getType(),dto.getApplicationRevision(),dto.getApplicationVersion(),dto.getManagementStatus(),dto.getManufacturerPk(),dto.getManufacturerType(),dto.getManufacturerPartNumber(),dto.getManufacturerPartCode(),dto.getManufacturerBrandName(),dto.getManufacturerUnitCost(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getSubCategoryKeyType(),dto.getSubCategoryKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.getIsOverlayComponent(),pk.getId());
	}

	/** 
	 * Deletes a single row in the APPLICATIONTYPE table.
	 */
	@Transactional
	public void delete(ApplicationtypePk pk) throws ApplicationtypeDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE ID = ?",pk.getId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return Applicationtype
	 */
	public Applicationtype mapRow(ResultSet rs, int row) throws SQLException
	{
		Applicationtype dto = new Applicationtype();
		dto.setId( rs.getString( 1 ) );
		dto.setType( rs.getString( 2 ) );
		dto.setApplicationRevision( rs.getString( 3 ) );
		dto.setApplicationVersion( rs.getString( 4 ) );
		dto.setManagementStatus( rs.getString( 5 ) );
		dto.setManufacturerPk( rs.getString( 6 ) );
		dto.setManufacturerType( rs.getString( 7 ) );
		dto.setManufacturerPartNumber( rs.getString( 8 ) );
		dto.setManufacturerPartCode( rs.getString( 9 ) );
		dto.setManufacturerBrandName( rs.getString( 10 ) );
		dto.setManufacturerUnitCost( rs.getFloat( 11 ) );
		if (rs.wasNull()) {
			dto.setManufacturerUnitCostNull( true );
		}
		
		dto.setCustom1( rs.getString( 12 ) );
		dto.setCustom2( rs.getString( 13 ) );
		dto.setCustom3( rs.getString( 14 ) );
		dto.setCustom4( rs.getString( 15 ) );
		dto.setCustom5( rs.getString( 16 ) );
		dto.setObjectDefaultKeyType( rs.getString( 17 ) );
		dto.setObjectDefaultKeyPk( rs.getString( 18 ) );
		dto.setSubCategoryKeyType( rs.getString( 19 ) );
		dto.setSubCategoryKeyPk( rs.getString( 20 ) );
		dto.setDescription( rs.getString( 21 ) );
		dto.setLongDescription( rs.getString( 22 ) );
		dto.setLastModificationUserId( rs.getString( 23 ) );
		dto.setLastModificationDate( rs.getTimestamp(24 ) );
		dto.setLastupdateversionnumber( rs.getBigDecimal(25));
		dto.setCustom6( rs.getString( 26 ) );
		dto.setCustom7( rs.getString( 27 ) );
		dto.setCustom8( rs.getString( 28 ) );
		dto.setCustom9( rs.getString( 29 ) );
		dto.setCustom10( rs.getString( 30 ) );
		dto.setEnvironment( rs.getString( 31 ) );
		dto.setInventoryKeyType( rs.getString( 32 ) );
		dto.setInventoryKeyPk( rs.getString( 33 ) );
		dto.setIsOverlayComponent( rs.getInt( 34 ) );
		if (rs.wasNull()) {
			dto.setIsOverlayComponentNull( true );
		}
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "FIT_SCHEMA.APPLICATIONTYPE";
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public Applicationtype findByPrimaryKey(String id) throws ApplicationtypeDaoException
	{
		try {
			List<Applicationtype> list = jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ?", this,id);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria ''.
	 */
	@Transactional
	public List<Applicationtype> findAll() throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " ORDER BY ID", this);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all rows from the APPLICATIONTYPE table related to Peak Readiness In Scope Applications.
	 */
	@Transactional
	public Applicationtype findRelatedToInPrScope(String appDefiningTypeKeyPk) throws ApplicationtypeDaoException
	{
		String selectFields = "ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT";
		String whereClause  = "ID = ? ";
		
		String sql = "SELECT " + selectFields 
				  + " FROM " + getTableName()
				  + " WHERE " + whereClause;
		
		try {
			List<Applicationtype> list = jdbcTemplate.query(sql, this, appDefiningTypeKeyPk); 
			return list.size() == 0 ? null : list.get(0); 
		} catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public List<Applicationtype> findWhereIdEquals(String id) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ? ORDER BY ID", this,id);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'TYPE = :type'.
	 */
	@Transactional
	public List<Applicationtype> findWhereTypeEquals(String type) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE TYPE = ? ORDER BY TYPE", this,type);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'APPLICATION_REVISION = :applicationRevision'.
	 */
	@Transactional
	public List<Applicationtype> findWhereApplicationRevisionEquals(String applicationRevision) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE APPLICATION_REVISION = ? ORDER BY APPLICATION_REVISION", this,applicationRevision);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'APPLICATION_VERSION = :applicationVersion'.
	 */
	@Transactional
	public List<Applicationtype> findWhereApplicationVersionEquals(String applicationVersion) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE APPLICATION_VERSION = ? ORDER BY APPLICATION_VERSION", this,applicationVersion);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANAGEMENT_STATUS = :managementStatus'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManagementStatusEquals(String managementStatus) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANAGEMENT_STATUS = ? ORDER BY MANAGEMENT_STATUS", this,managementStatus);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PK = :manufacturerPk'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerPkEquals(String manufacturerPk) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_PK = ? ORDER BY MANUFACTURER_PK", this,manufacturerPk);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_TYPE = :manufacturerType'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerTypeEquals(String manufacturerType) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_TYPE = ? ORDER BY MANUFACTURER_TYPE", this,manufacturerType);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PART_NUMBER = :manufacturerPartNumber'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerPartNumberEquals(String manufacturerPartNumber) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_PART_NUMBER = ? ORDER BY MANUFACTURER_PART_NUMBER", this,manufacturerPartNumber);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_PART_CODE = :manufacturerPartCode'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerPartCodeEquals(String manufacturerPartCode) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_PART_CODE = ? ORDER BY MANUFACTURER_PART_CODE", this,manufacturerPartCode);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_BRAND_NAME = :manufacturerBrandName'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerBrandNameEquals(String manufacturerBrandName) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_BRAND_NAME = ? ORDER BY MANUFACTURER_BRAND_NAME", this,manufacturerBrandName);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'MANUFACTURER_UNIT_COST = :manufacturerUnitCost'.
	 */
	@Transactional
	public List<Applicationtype> findWhereManufacturerUnitCostEquals(float manufacturerUnitCost) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE MANUFACTURER_UNIT_COST = ? ORDER BY MANUFACTURER_UNIT_COST", this,manufacturerUnitCost);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom1Equals(String custom1) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_1 = ? ORDER BY CUSTOM_1", this,custom1);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom2Equals(String custom2) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_2 = ? ORDER BY CUSTOM_2", this,custom2);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom3Equals(String custom3) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_3 = ? ORDER BY CUSTOM_3", this,custom3);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom4Equals(String custom4) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_4 = ? ORDER BY CUSTOM_4", this,custom4);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom5Equals(String custom5) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_5 = ? ORDER BY CUSTOM_5", this,custom5);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	@Transactional
	public List<Applicationtype> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_TYPE = ? ORDER BY OBJECT_DEFAULT_KEY_TYPE", this,objectDefaultKeyType);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	@Transactional
	public List<Applicationtype> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_PK = ? ORDER BY OBJECT_DEFAULT_KEY_PK", this,objectDefaultKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'SUB_CATEGORY_KEY_TYPE = :subCategoryKeyType'.
	 */
	@Transactional
	public List<Applicationtype> findWhereSubCategoryKeyTypeEquals(String subCategoryKeyType) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SUB_CATEGORY_KEY_TYPE = ? ORDER BY SUB_CATEGORY_KEY_TYPE", this,subCategoryKeyType);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'SUB_CATEGORY_KEY_PK = :subCategoryKeyPk'.
	 */
	@Transactional
	public List<Applicationtype> findWhereSubCategoryKeyPkEquals(String subCategoryKeyPk) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SUB_CATEGORY_KEY_PK = ? ORDER BY SUB_CATEGORY_KEY_PK", this,subCategoryKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'DESCRIPTION = :description'.
	 */
	@Transactional
	public List<Applicationtype> findWhereDescriptionEquals(String description) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DESCRIPTION = ? ORDER BY DESCRIPTION", this,description);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	@Transactional
	public List<Applicationtype> findWhereLongDescriptionEquals(String longDescription) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LONG_DESCRIPTION = ? ORDER BY LONG_DESCRIPTION", this,longDescription);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	@Transactional
	public List<Applicationtype> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_USER_ID = ? ORDER BY LAST_MODIFICATION_USER_ID", this,lastModificationUserId);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	@Transactional
	public List<Applicationtype> findWhereLastModificationDateEquals(Date lastModificationDate) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_DATE = ? ORDER BY LAST_MODIFICATION_DATE", this,lastModificationDate);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	@Transactional
	public List<Applicationtype> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LASTUPDATEVERSIONNUMBER = ? ORDER BY LASTUPDATEVERSIONNUMBER", this,lastupdateversionnumber);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom6Equals(String custom6) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_6 = ? ORDER BY CUSTOM_6", this,custom6);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom7Equals(String custom7) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_7 = ? ORDER BY CUSTOM_7", this,custom7);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom8Equals(String custom8) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_8 = ? ORDER BY CUSTOM_8", this,custom8);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom9Equals(String custom9) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_9 = ? ORDER BY CUSTOM_9", this,custom9);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	@Transactional
	public List<Applicationtype> findWhereCustom10Equals(String custom10) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_10 = ? ORDER BY CUSTOM_10", this,custom10);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	@Transactional
	public List<Applicationtype> findWhereEnvironmentEquals(String environment) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ENVIRONMENT = ? ORDER BY ENVIRONMENT", this,environment);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	@Transactional
	public List<Applicationtype> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_TYPE = ? ORDER BY INVENTORY_KEY_TYPE", this,inventoryKeyType);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	@Transactional
	public List<Applicationtype> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_PK = ? ORDER BY INVENTORY_KEY_PK", this,inventoryKeyPk);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the APPLICATIONTYPE table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	@Transactional
	public List<Applicationtype> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws ApplicationtypeDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, TYPE, APPLICATION_REVISION, APPLICATION_VERSION, MANAGEMENT_STATUS, MANUFACTURER_PK, MANUFACTURER_TYPE, MANUFACTURER_PART_NUMBER, MANUFACTURER_PART_CODE, MANUFACTURER_BRAND_NAME, MANUFACTURER_UNIT_COST, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, SUB_CATEGORY_KEY_TYPE, SUB_CATEGORY_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE IS_OVERLAY_COMPONENT = ? ORDER BY IS_OVERLAY_COMPONENT", this,isOverlayComponent);
		}
		catch (Exception e) {
			throw new ApplicationtypeDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the APPLICATIONTYPE table that matches the specified primary-key value.
	 */
	public Applicationtype findByPrimaryKey(ApplicationtypePk pk) throws ApplicationtypeDaoException
	{
		return findByPrimaryKey( pk.getId() );
	}

}
