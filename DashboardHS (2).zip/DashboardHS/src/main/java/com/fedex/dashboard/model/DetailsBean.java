package com.fedex.dashboard.model;

import java.util.List;
import java.util.Map;

public class DetailsBean {
	Map<String, List<String>> hubActivities;

	public Map<String, List<String>> getHubActivities() {
		return hubActivities;
	}

	public void setHubActivities(Map<String, List<String>> hubActivities) {
		this.hubActivities = hubActivities;
	}

	@Override
	public String toString() {
		return "DetailsBean [hubActivities=" + hubActivities + "]";
	}	
}
