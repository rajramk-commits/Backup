package com.fedex.emea.sd.bl.rulers;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import com.fedex.emea.sd.da.dao.DashboardAlertsDao;
import com.fedex.emea.sd.da.helpers.Constants;
import com.fedex.emea.sd.da.helpers.Utilities;
import com.fedex.emea.sd.da.nexus.NexusCommunicator;
import com.fedex.emea.sd.da.objects.DashboardAlerts;
import com.fedex.emea.sd.da.objects.NexusCases;
import com.fedex.emea.sd.da.objects.NexusInterface;

public class AntcBusinessLogic {
	
	public boolean DASHBOARD_ALERT;
	public boolean CREATE_TICKET;
	public boolean EXISTING_DASHBOARD_ALERT;
	public boolean OVO_ALERT;
	public boolean SELF_SERVICE;
	public boolean DIMM;
	public boolean CHANGE_PROVIDER_GROUP;
	public boolean ADD_TICKET_NOTE;
	
	private NexusInterface        nexusInterfaceRecord;
	private DashboardAlerts       dashboardAlert;
	private DashboardAlertsDao    dashboardAlertsDao;
	private NexusCommunicator     nexusCommunicator;
	private NexusCases            nexusCaseObject;
	
	private String existingNiAlertId;
	private String existingCaseId;
	
	public AntcBusinessLogic() {	
	}
	
	public AntcBusinessLogic(NexusInterface pNexusInterfaceRecord, DashboardAlertsDao pDashboardAlertsDao, NexusCommunicator pNexusCommunicator) {
		this.nexusInterfaceRecord = pNexusInterfaceRecord;
		this.dashboardAlertsDao   = pDashboardAlertsDao;
		this.nexusCommunicator    = pNexusCommunicator;
		
		DASHBOARD_ALERT          = false;
		CREATE_TICKET            = false;
		EXISTING_DASHBOARD_ALERT = false;
		OVO_ALERT                = false;
		SELF_SERVICE             = false;
		DIMM                     = false;
		CHANGE_PROVIDER_GROUP    = false;
		ADD_TICKET_NOTE          = false;
		existingNiAlertId        = "";
		existingCaseId           = "";
		
		String recordSource = nexusInterfaceRecord.getRecordSource();
		
		OVO_ALERT             = recordSource.equals(Constants.OBM);
		ADD_TICKET_NOTE       = recordSource.equals(Constants.ADDNOTE);
		DASHBOARD_ALERT       = recordSource.contains(Constants.ANY_DASHBOARD);
		SELF_SERVICE          = recordSource.equals(Constants.SELF_SERVICE_TICKET) ||
				                recordSource.equals(Constants.SELF_SERVICE_NPF);
		CHANGE_PROVIDER_GROUP = recordSource.equals(Constants.WEBSSD);
		
		int colPos = recordSource.indexOf(":");
		if ((colPos >= 0) && (recordSource.substring(0, colPos).toUpperCase().equals(Constants.DIMM))) {
			DIMM = true;
			nexusInterfaceRecord.setRecordSource(recordSource.substring(colPos + 1));
		}
						
		if (OVO_ALERT || SELF_SERVICE || DIMM) CREATE_TICKET = true;
		
		if (DASHBOARD_ALERT) {
			dashboardAlert = new DashboardAlerts(nexusInterfaceRecord.getCaseDescription().toString());
			
//			nexusInterfaceRecord.setCaseStatus(Constants.CASE_STATUS_NEW_CASE);
			nexusInterfaceRecord.setFullDescription(dashboardAlert.getNexusCaseDescription());
			
			if (recordSource.equals(Constants.ITIH_PROD_DASHBOARD)) {
				nexusInterfaceRecord.setCaseProviderGroup(Constants.PROVIDER_SD_APP_SUPPORT);
			}
			
			if (!DIMM) {
				boolean isComponentFileSystem               = dashboardAlert.getImpactedComponent().equals(Constants.COMPONENT_FILESYSTEM);
				boolean isComponentServerRebootDetection    = dashboardAlert.getImpactedComponent().equals(Constants.COMPONENT_SERVERREBOOT);
				boolean isComponentServerReachableDetection = dashboardAlert.getImpactedComponent().equals(Constants.COMPONENT_SERVERREACHABLE);
				boolean isComponentServerResponseDetection  = dashboardAlert.getImpactedComponent().equals(Constants.COMPONENT_SERVERRESPONSE);
				
				if (!isComponentFileSystem && !isComponentServerRebootDetection 
						&& !isComponentServerReachableDetection && !isComponentServerResponseDetection) {
					try {
						List<DashboardAlerts> similarAlertsList = dashboardAlertsDao.loadSameAlerts(dashboardAlert);
						if (!similarAlertsList.isEmpty()) {
							long minimumInterval = 999999999;
							for (Iterator<?> iter = similarAlertsList.iterator(); iter.hasNext();) {
								DashboardAlerts element = (DashboardAlerts) iter.next();
								if (Utilities.getIntervalTimeUntilNow(element.getCreationTime()) < minimumInterval) {
									minimumInterval = Utilities.getIntervalTimeUntilNow(element.getCreationTime());
									existingCaseId = element.getNexusCaseId();
									existingNiAlertId = element.getNiAlertId();
								}
							}
							if ((!existingCaseId.trim().equals("")) && (minimumInterval <= Constants.DEFAULT_8H_ALERT_INTERVAL)) {
								try {
									nexusCaseObject = nexusCommunicator.getNexusCase(new BigDecimal(existingCaseId));
									if (nexusCaseObject != null) {
										String caseStatus = nexusCaseObject.getCaseStatus();
										if (caseStatus.equals(Constants.CASE_STATUS_CLOSE) || 
												caseStatus.equals(Constants.CASE_STATUS_DUPLICATED) || 
												caseStatus.equals(Constants.CASE_STATUS_OUTOFSCOPE) || 
												caseStatus.equals(Constants.CASE_STATUS_SOLVED)) {
											CREATE_TICKET = true;				// Existing NEXUS Case NOT OPEN anymore
										} else {
											EXISTING_DASHBOARD_ALERT = true;	// Existing NEXUS Case STILL OPEN
											CREATE_TICKET = false;
										}
									} else {
										CREATE_TICKET = true;					// Can't Retrieve appropriate NEXUS Case
									}
								} catch (Exception e) {
									CREATE_TICKET = true;						// Can't Retrieve appropriate NEXUS Case
								}
							} else {
								CREATE_TICKET = true;							// No similar Alert found during Interval (8 Hours)
							}
						} else {
							CREATE_TICKET = true;								// No similar Alert found at all
						}
					} catch (SQLException e) {
						CREATE_TICKET = true;									// Issue getting similar Alerts
					}
				}
			}
		}
	}
	
	public DashboardAlerts getDashboardAlert() {
		return dashboardAlert;
	}

	public void setDashboardAlert(DashboardAlerts dashboardAlert) {
		this.dashboardAlert = dashboardAlert;
	}

	public DashboardAlertsDao getDashboardAlertsDao() {
		return dashboardAlertsDao;
	}

	public void setDashboardAlertsDao(DashboardAlertsDao dashboardAlertsDao) {
		this.dashboardAlertsDao = dashboardAlertsDao;
	}

	public String getExistingNiAlertId() {
		return existingNiAlertId;
	}

	public void setExistingNiAlertId(String existingNiAlertId) {
		this.existingNiAlertId = existingNiAlertId;
	}

	public String getExistingCaseId() {
		return existingCaseId;
	}

	public void setExistingCaseId(String existingCaseId) {
		this.existingCaseId = existingCaseId;
	}

	public NexusCases getNexusCaseObject() {
		return nexusCaseObject;
	}

	public void setNexusCaseObject(NexusCases nexusCaseObject) {
		this.nexusCaseObject = nexusCaseObject;
	}

	public NexusInterface getNexusInterfaceRecord() {
		return nexusInterfaceRecord;
	}

	public void setNexusInterfaceRecord(NexusInterface nexusInterfaceRecord) {
		this.nexusInterfaceRecord = nexusInterfaceRecord;
	}	
}
