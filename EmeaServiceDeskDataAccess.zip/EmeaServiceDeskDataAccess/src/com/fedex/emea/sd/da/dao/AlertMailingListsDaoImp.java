package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.AlertMailingListsRowMapper;
import com.fedex.emea.sd.da.objects.AlertMailingLists;

public class AlertMailingListsDaoImp implements AlertMailingListsDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int countAll() throws SQLException {
		String sql = "SELECT count(*) FROM AlertMailingLists";
        int allRows = 0;
        jdbcTemplate.queryForInt(sql);
        return allRows;
	}

	public void create(AlertMailingLists valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO AlertMailingLists ( ALERTSOURCE, USERPIN, USERMAIL) " +
		               "VALUES (?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertSource(), valueObject.getUserPin(), valueObject.getUserMail()});
	}

	public AlertMailingLists createValueObject() {
		return new AlertMailingLists();
	}

	public void deleteByPK(AlertMailingLists valueObject) {
		String sql = "DELETE FROM AlertMailingLists WHERE (ALERTSOURCE = ? AND USERMAIL = ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertSource(), valueObject.getUserMail()});
	}
	
	public void deleteByPin(String userPin) {
		String sql = "DELETE FROM AlertMailingLists WHERE (USERPIN = ?) ";
		jdbcTemplate.update(sql, new Object[] {userPin});
	}

	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM AlertMailingLists";
		jdbcTemplate.update(sql);
	}

	public AlertMailingLists getObject(String alertSource, String userMail) throws SQLException {
		AlertMailingLists valueObject = createValueObject();
		String sql = "SELECT * FROM AlertMailingLists WHERE (ALERTSOURCE = ? AND USERMAIL = ?) ";
		valueObject = (AlertMailingLists) jdbcTemplate.queryForObject(sql, new Object[] {alertSource, userMail}, new AlertMailingListsRowMapper());
		return valueObject;
	}
	
	public List<String> getMailsByAlertSource(String alertSource) throws SQLException {
		List<String> mails = new ArrayList<String>();
		for (AlertMailingLists aml:loadByAlertSource(alertSource)) {
			mails.add(aml.getUserMail());
		}
		return mails;
	}

	@SuppressWarnings("unchecked")
	public List<AlertMailingLists> loadAll() throws SQLException {
		String sql = "SELECT * FROM AlertMailingLists ORDER BY ALERTSOURCE ASC ";
		return jdbcTemplate.query(sql, new AlertMailingListsRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<AlertMailingLists> loadByAlertSource(String alertSource) throws SQLException {
		String sql = "SELECT * FROM AlertMailingLists WHERE ALERTSOURCE = ?";
		return jdbcTemplate.query(sql, new Object[] {alertSource}, new AlertMailingListsRowMapper());
	}
}
