<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<%@page import="com.fedex.emea.sabreReport.util.*"%>
<%@page import="com.fedex.emea.sabreReport.model.*"%>
<%@ page import="java.util.*,java.sql.*" %>
<%
List<SabreBean> modalData = new ArrayList<>();
List<SabreBean> data = new ArrayList<>();
try{
   	data = (List<SabreBean>) request.getSession().getAttribute("gssList");
	
   	String alertType = request.getParameter("alertType");
   	if(true)
   	{
   		System.out.println("alertType 1:"+alertType);   		
   		SabreBean bean = new SabreBean();
   		for(int i=0; i< data.size(); i++)
   		{
   			bean = data.get(i);
   			if(bean != null && bean.getAlertType() != null && bean.getAlertType().contains(alertType))
   			{
   				modalData.add(bean);
   			}
   		}
   		System.out.println("modalData 1:"+modalData);   		
   	}
}
catch(Exception e)
{
	e.printStackTrace();
}

%>

<html>
<head>
<meta charset="ISO-8859-1">
</head>
<body>

<table >
				<thead>
				<th >Incident ID</th>
				<th style="width: 150px;">Created Date</th>
				<th >Short Description</th>
				<th >Alert Type</th>
				<th>Location</th>
				</thead>
				<tbody>
				
				<% 
							    
				SabreBean bean = new SabreBean();
				for(int i=0; i< modalData.size(); i++)
				{
					bean = modalData.get(i);
					if(bean != null)
					{
					%>
					<tr>
			 		<td><%=bean.getIncedent() %></td>
				    <td ><%=bean.getCreated() %> </td>
					<td ><%=bean.getShortDescr() %></td>
					<td ><%=bean.getAlertType() %></td>
					<td ><%=bean.getLocation() %></td>
				</tr>
				<%} 
				}%>
				</tbody>
				</table>
</body>
</html>