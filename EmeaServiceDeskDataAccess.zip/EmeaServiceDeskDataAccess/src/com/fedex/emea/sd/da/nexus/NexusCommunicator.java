package com.fedex.emea.sd.da.nexus;

import java.math.BigDecimal;
import java.util.ArrayList;

import PeopleSoft.Generated.CompIntfc.FdxCaseJavaCi;
import PeopleSoft.Generated.CompIntfc.IFdxCaseJavaCi;
import PeopleSoft.Generated.CompIntfc.IFdxCaseJavaCiRcCaseNote;
import PeopleSoft.Generated.CompIntfc.IFdxCaseJavaCiRcCaseNoteCollection;

import com.fedex.emea.sd.da.helpers.Utilities;
import com.fedex.emea.sd.da.logger.ApplicationLogger;
import com.fedex.emea.sd.da.objects.NexusCases;
import com.fedex.emea.sd.da.objects.NexusCasesNotes;

import psft.pt8.joa.API;
import psft.pt8.joa.IPSMessage;
import psft.pt8.joa.IPSMessageCollection;
import psft.pt8.joa.ISession;
import psft.pt8.joa.JOAException;

public class NexusCommunicator {
	
	private static final String COMPONENT_INTERFACE_NAME = "FDX_CASE_JAVA_CI";
	private static final String DISP_TEMPLATE            = "RC_HELPDESK";
	
	private static IFdxCaseJavaCi oNexusCaseComponentInterface;
	private static ISession oSession;
	
	private String nexusServerName;
	private String nexusServerPort;
	private String nexusServerUrl;
	private String nexusUserId;
	private String nexusUserPassword;
	private String nexusCaseContactPIN;
	private String nexusCaseContactBoId;
	
	private ApplicationLogger logger;
	private String errorMsg;
	
	public NexusCommunicator() {
		
	}
	
	public NexusCommunicator(ApplicationLogger logger) {
		nexusServerName      = "snickers.emea.fedex.com";
		nexusServerPort      = "9060";
		nexusServerUrl       = nexusServerName + ":" + nexusServerPort;
		
		nexusUserId          = "AutoAlertO";	// NEXUS Login
		nexusUserPassword    = "crmdevalert";
		
		nexusCaseContactPIN  = "400894";		// Test Account for SD (Case Creator)
		nexusCaseContactBoId = "297347649696485494391335022286";
		
		this.logger = logger;
		
		oSession = API.createSession();
		
	}
	
	public NexusCommunicator(ApplicationLogger logger, String nexusServerName, String nexusServerPort, String nexusUserId, String nexusUserPassword, String nexusCaseContactPIN, String nexusCaseContactBoId) {
		this.nexusServerName      = nexusServerName;
		this.nexusServerPort      = nexusServerPort;
		this.nexusServerUrl       = nexusServerName + ":" + nexusServerPort;
		
		this.nexusUserId          = nexusUserId;
		this.nexusUserPassword    = nexusUserPassword;
		
		this.nexusCaseContactPIN  = nexusCaseContactPIN;
		this.nexusCaseContactBoId = nexusCaseContactBoId;
		
		this.logger = logger;
		
		oSession = API.createSession();
		
	}
	
	public void initComponentInterface() throws JOAException {
		oNexusCaseComponentInterface = (FdxCaseJavaCi) oSession.getCompIntfc(COMPONENT_INTERFACE_NAME);
		oNexusCaseComponentInterface.setInteractiveMode(false);
		oNexusCaseComponentInterface.setGetHistoryItems(false);
		oNexusCaseComponentInterface.setEditHistoryItems(false);
		oNexusCaseComponentInterface.setDispTmplFamCd(DISP_TEMPLATE);
	}
	
	public void cancelComponentInterface() throws Exception {
		if (oNexusCaseComponentInterface != null) {
			if (!oNexusCaseComponentInterface.cancel()) {
				errorMsg = "Unable to Cancel Component Interface";
				logError(errorMsg);
				throw new Exception(errorMsg);
			}
		}
	}
	
	public void closeNexusCase(BigDecimal nexusCaseId) throws Exception {
		
		oNexusCaseComponentInterface.setCaseId(nexusCaseId);
		
		if (!oNexusCaseComponentInterface.get()) {
			errorMsg = "Failed to retrieve NEXUS data for Case #" + nexusCaseId;
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		
		oNexusCaseComponentInterface.loadNotes();
		
		System.out.println(oNexusCaseComponentInterface.getPropertyByName("RC_STATUS"));
		
		oNexusCaseComponentInterface.setBoIdCust(new java.math.BigDecimal(nexusCaseContactBoId));
		oNexusCaseComponentInterface.setRoleTypeIdCust(new java.math.BigDecimal(4));

//		oNexusCaseComponentInterface.setFdxBusImpact("TEST BI Impact");
//		oNexusCaseComponentInterface.setFdxCause("TEST Cause");
//		oNexusCaseComponentInterface.setFdxImpact("TEST Impact");
//		oNexusCaseComponentInterface.setRcStatus("RESOL");
		oNexusCaseComponentInterface.setPropertyByName("RC_STATUS", "RESOL");
		
		if (!oNexusCaseComponentInterface.save()) {
			errorMsg = "Unable to Save closed NEXUS Case";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
	}
	
	public void changeProviderGroup(BigDecimal nexusCaseId, String newProviderGroup) throws Exception {

		oNexusCaseComponentInterface.setCaseId(nexusCaseId);
		
		if (!oNexusCaseComponentInterface.get()) {
			errorMsg = "Failed to change Provider Group for NEXUS Case #" + nexusCaseId;
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		
		oNexusCaseComponentInterface.setProviderGrpId(newProviderGroup);
		
		if (!oNexusCaseComponentInterface.save()) {
			errorMsg = "Unable to Save NEXUS Case with new Provider Group";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}

	}
	
	public void createNexusCaseNote(BigDecimal nexusCaseId, NexusCasesNotes nexusCaseNote) throws Exception {
		
		oNexusCaseComponentInterface.setCaseId(nexusCaseId);
		
		if (!oNexusCaseComponentInterface.get()) {
			errorMsg = "Failed to create Case Note for NEXUS Case #" + nexusCaseId;
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		
		IFdxCaseJavaCiRcCaseNoteCollection nexusCaseNoteCollection;
		IFdxCaseJavaCiRcCaseNote nexusNote;
		nexusCaseNoteCollection = oNexusCaseComponentInterface.getRcCaseNote();
		oNexusCaseComponentInterface.loadNotes();
				
		nexusNote = nexusCaseNoteCollection.insertItem(0);
		nexusNote.setNoteSummary(nexusCaseNote.getNexusCaseNoteSummary());
		nexusNote.setNoteDescrlong(nexusCaseNote.getNexusCaseNoteDescription());
		if (nexusCaseNote.getNexusCaseNoteContactType() != null) nexusNote.setNoteContactType(nexusCaseNote.getNexusCaseNoteContactType());
		if (nexusCaseNote.getNexusCaseNoteOrigin() != null) nexusNote.setNoteOrigin(nexusCaseNote.getNexusCaseNoteOrigin());
		if (nexusCaseNote.getNexusCaseNoteType() != null) nexusNote.setNoteType(nexusCaseNote.getNexusCaseNoteType());
		
		if (!oNexusCaseComponentInterface.save()) {
			errorMsg = "Unable to Save created NEXUS Case Note";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}

	}
		
	public NexusCases getNexusCase(BigDecimal nexusCaseId) throws Exception {
		NexusCases nexusCase = new NexusCases();
		
		oNexusCaseComponentInterface.setCaseId(nexusCaseId);
		
		if (!oNexusCaseComponentInterface.get()) {
			errorMsg = "Failed to get NEXUS Case #" + nexusCaseId;
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
				
		// =====================================================================
		
		oNexusCaseComponentInterface.loadNotes();
				
		ArrayList<NexusCasesNotes> nexusCaseNotesList = new ArrayList<NexusCasesNotes>();
		IFdxCaseJavaCiRcCaseNoteCollection nexusCaseNoteCollection;
		IFdxCaseJavaCiRcCaseNote nexusNote;
		nexusCaseNoteCollection = oNexusCaseComponentInterface.getRcCaseNote();
					
		for (int i = 0; i < nexusCaseNoteCollection.getCount(); i++) {
			nexusNote = nexusCaseNoteCollection.item(i);
			nexusCaseNotesList.add(new NexusCasesNotes(nexusNote.getNoteSummary(), nexusNote.getNoteDescrlong()));
		}
		
		nexusCase.setCaseId(oNexusCaseComponentInterface.getCaseId().intValue());
		
		// Commented since new NEXUS API (19-May-16)  => use getBusinessUnit0
		// ------------------------------------------------------------------
		//nexusCase.setCaseBusinessUnit(oNexusCaseComponentInterface.getBusinessUnit());
		nexusCase.setCaseBusinessUnit(oNexusCaseComponentInterface.getBusinessUnit0());
		nexusCase.setCaseType(oNexusCaseComponentInterface.getCaseType());
		nexusCase.setCaseOriginPin(oNexusCaseComponentInterface.getCaseContact());
		nexusCase.setCaseSource(oNexusCaseComponentInterface.getRcSource());
		nexusCase.setCaseProviderGroup(oNexusCaseComponentInterface.getProviderGrpId());
		nexusCase.setCaseStatus(oNexusCaseComponentInterface.getRcStatus());
		nexusCase.setCasePriority(oNexusCaseComponentInterface.getRcPriority());
		nexusCase.setCaseSeverity(oNexusCaseComponentInterface.getRcSeverity());
		nexusCase.setCaseCategory(oNexusCaseComponentInterface.getRcCategory());
		nexusCase.setCaseCallType(oNexusCaseComponentInterface.getRcType());
		nexusCase.setCaseProblemDetail(oNexusCaseComponentInterface.getRcDetail());
		nexusCase.setCaseProblemDescription(oNexusCaseComponentInterface.getFdxProblemDetail());
		nexusCase.setCaseSummary(oNexusCaseComponentInterface.getRcSummary());
		nexusCase.setCaseDescription(oNexusCaseComponentInterface.getRcDescrlong());
		nexusCase.setCaseFdxNode(oNexusCaseComponentInterface.getFdxNode());
		nexusCase.setCaseFdxVendor(oNexusCaseComponentInterface.getFdxVendor());
		nexusCase.setCaseFdxVendorId(oNexusCaseComponentInterface.getFdxVendId());
		nexusCase.setCaseFdxSystem(oNexusCaseComponentInterface.getFdxSystem());
		nexusCase.setCaseFdxApplication(oNexusCaseComponentInterface.getFdxApplication());
		nexusCase.setCaseAssignedTo(oNexusCaseComponentInterface.getAssignedTo());
		nexusCase.setCaseFdxBusImpact(oNexusCaseComponentInterface.getFdxBusImpact());
		nexusCase.setCaseFdxCause(oNexusCaseComponentInterface.getFdxCause());
		nexusCase.setCaseFdxImpact(oNexusCaseComponentInterface.getFdxImpact());
				
		nexusCase.setCaseNotes(nexusCaseNotesList);
		
		return nexusCase;
	}
	
	public BigDecimal createNexusCase(NexusCases nexusCase) throws Exception {
		
		BigDecimal nexusCaseId = null;
		
		if(!oNexusCaseComponentInterface.create()) {
			errorMsg = "Unable to Create NEXUS Component Interface";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		
		oNexusCaseComponentInterface.setBoIdCust(new java.math.BigDecimal(nexusCaseContactBoId));
		oNexusCaseComponentInterface.setRoleTypeIdCust(new java.math.BigDecimal(4));
		
		// Commented since new NEXUS API (19-May-16)  => use setBusinessUnit0
		// ------------------------------------------------------------------
		//oNexusCaseComponentInterface.setBusinessUnit(nexusCase.getCaseBusinessUnit());
		oNexusCaseComponentInterface.setBusinessUnit0(nexusCase.getCaseBusinessUnit());
		oNexusCaseComponentInterface.setCaseType(nexusCase.getCaseType());
		if ((nexusCase.getCaseOwnership() != null) && (!nexusCase.getCaseOwnership().trim().isEmpty())) {
			oNexusCaseComponentInterface.setCaseContact(nexusCase.getCaseOwnership().trim());
		} else {
			oNexusCaseComponentInterface.setCaseContact(nexusCaseContactPIN);
		}
		oNexusCaseComponentInterface.setRcSource(nexusCase.getCaseSource());
		oNexusCaseComponentInterface.setProviderGrpId(nexusCase.getCaseProviderGroup());
		oNexusCaseComponentInterface.setRcStatus(nexusCase.getCaseStatus());
		oNexusCaseComponentInterface.setRcPriority(nexusCase.getCasePriority());
		oNexusCaseComponentInterface.setRcSeverity(nexusCase.getCaseSeverity());
		oNexusCaseComponentInterface.setRcCategory(nexusCase.getCaseCategory());				// Field "Area"
		oNexusCaseComponentInterface.setRcType(nexusCase.getCaseCallType());					// Field "Service"
		oNexusCaseComponentInterface.setRcDetail(nexusCase.getCaseProblemType());  				// Field "Service Component"
		oNexusCaseComponentInterface.setFdxProblemDetail(nexusCase.getCaseProblemDetail());		// Field "Service Function"
		oNexusCaseComponentInterface.setRcSummary(nexusCase.getCaseSummary());
		oNexusCaseComponentInterface.setRcDescrlong(nexusCase.getCaseDescription());
		oNexusCaseComponentInterface.setFdxNode(nexusCase.getCaseFdxNode());
		oNexusCaseComponentInterface.setFdxVendor(nexusCase.getCaseFdxVendor());
		oNexusCaseComponentInterface.setFdxVendId(nexusCase.getCaseFdxVendorId());
		oNexusCaseComponentInterface.setFdxSystem(nexusCase.getCaseFdxSystem());
		oNexusCaseComponentInterface.setFdxApplication(nexusCase.getCaseFdxApplication());
		oNexusCaseComponentInterface.setAssignedTo(nexusCase.getCaseAssignedTo());
		
		IFdxCaseJavaCiRcCaseNoteCollection oRcCaseNoteCollection = null;;
		IFdxCaseJavaCiRcCaseNote oRcCaseNote;
		try {
			oRcCaseNoteCollection = oNexusCaseComponentInterface.getRcCaseNote();
		} catch (Exception ex) {
			logError("Error getting Case Notes collection");
			throw ex;
		}
		
		ArrayList<NexusCasesNotes> nexusCaseNotesList = nexusCase.getCaseNotes();
		
		for (NexusCasesNotes ncn: nexusCaseNotesList) {
			if (oRcCaseNoteCollection.getCount() == 0) {
				oRcCaseNote = oRcCaseNoteCollection.item(0);
			} else {
				oRcCaseNote = oRcCaseNoteCollection.insertItem(0);
			}
			oRcCaseNote.setNoteSummary(ncn.getNexusCaseNoteSummary());
			oRcCaseNote.setNoteDescrlong(ncn.getNexusCaseNoteDescription());
			if (ncn.getNexusCaseNoteContactType() != null) oRcCaseNote.setNoteContactType(ncn.getNexusCaseNoteContactType());
			if (ncn.getNexusCaseNoteOrigin() != null) oRcCaseNote.setNoteOrigin(ncn.getNexusCaseNoteOrigin());
			if (ncn.getNexusCaseNoteType() != null) oRcCaseNote.setNoteType(ncn.getNexusCaseNoteType());
		}
		
		if (!oNexusCaseComponentInterface.save()) {
			errorMsg = "Unable to Save NEXUS Case";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		
		nexusCaseId = oNexusCaseComponentInterface.getCaseId();
		
		return nexusCaseId;
	}
	
	public void connect() throws Exception {
		if (!oSession.connect(1, nexusServerUrl, nexusUserId, nexusUserPassword, null)) {
			errorMsg = "Unable to Connect to the NEXUS Server";
			logDebug(errorMsg);
			throw new Exception(errorMsg);
		}
	}
	
	public void disconnect() throws JOAException, Exception {
		if (!oNexusCaseComponentInterface.cancel()) {
			errorMsg = "Unable to Cancel Component Interface";
			logError(errorMsg);
			throw new Exception(errorMsg);
		}
		oSession.disconnect();
	}
	
	public boolean isValidNexusCase(NexusCases nexusCaseObject) {
		boolean isValidNexusCase = false;
		if (nexusCaseObject != null) {		// Check all mandatory Fields
			if (Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseBusinessUnit())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseCallType())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseCategory())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseDescription())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseOriginPin())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCasePriority())
					//&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseProblemDetail())
					//&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseProblemType())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseProviderGroup())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseSeverity())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseSource())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseStatus())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseSummary())
					&& Utilities.isNotNullOrEmpty(nexusCaseObject.getCaseType())) {
				isValidNexusCase = true;
			}
		}
		return isValidNexusCase;
	}
	
	public void logError(String errorMsg) {
		logger.logError(errorMsg);
		if (oSession.getErrorPending() || oSession.getWarningPending()) {
			IPSMessageCollection oPSMessageCollection;
			IPSMessage oPSMessage;

			oPSMessageCollection = oSession.getPSMessages();
			for (int i = 0; i < oPSMessageCollection.getCount(); i++) {
				oPSMessage = oPSMessageCollection.item(i);
				if (oPSMessage != null)
					logger.logError("(" + oPSMessage.getMessageSetNumber() + "," + oPSMessage.getMessageSetNumber() + ") : " + oPSMessage.getText());
			} 
			oPSMessageCollection.deleteAll();
		}
	}
	
	public void logDebug(String errorMsg) {
		logger.logDebug(errorMsg);
		if (oSession.getErrorPending() || oSession.getWarningPending()) {
			IPSMessageCollection oPSMessageCollection;
			IPSMessage oPSMessage;

			oPSMessageCollection = oSession.getPSMessages();
			for (int i = 0; i < oPSMessageCollection.getCount(); i++) {
				oPSMessage = oPSMessageCollection.item(i);
				if (oPSMessage != null)
					logger.logDebug("(" + oPSMessage.getMessageSetNumber() + "," + oPSMessage.getMessageSetNumber() + ") : " + oPSMessage.getText());
			} 
			oPSMessageCollection.deleteAll();
		}
	}

}