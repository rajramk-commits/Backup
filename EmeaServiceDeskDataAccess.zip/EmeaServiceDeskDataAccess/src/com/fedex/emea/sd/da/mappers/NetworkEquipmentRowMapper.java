package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.NetworkEquipments;

public final class NetworkEquipmentRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		NetworkEquipments networkEquipment = new NetworkEquipments();
		
		networkEquipment.setServiceName(rs.getString("SrvName"));
		networkEquipment.setApplicationName(rs.getString("AppName"));
		networkEquipment.setResponsibleManager(rs.getString("RespMgr"));
		networkEquipment.setBusinessCriticality(rs.getString("BusCrit"));
		networkEquipment.setApplicationStatus(rs.getString("AppStatus"));
		networkEquipment.setSupportGroup(rs.getString("SuppGroup"));
		networkEquipment.setServerName(rs.getString("ServerName"));
		networkEquipment.setServerDc(rs.getString("ServerDc"));
		networkEquipment.setServerStatus(rs.getString("ServerStatus"));
		networkEquipment.setServerType(rs.getString("ServerType"));
		networkEquipment.setServerDescription(rs.getString("ServerDescr"));
		networkEquipment.setEnvironmentType(rs.getString("EnvType"));
		
		return networkEquipment;	
	}
}
