package com.fedex.emea.dimm.alert;

public class PhysicalAlert extends AbstractAlert{

	private Long physicalKey;
	
	private String logicalKey;

	public String getLogicalKey() {
		return logicalKey;
	}

	public void setLogicalKey(String logicalKey) {
		this.logicalKey = logicalKey;
	}

	public Long getPhysicalKey() {
		return physicalKey;
	}

	public void setPhysicalKey(Long physicalKey) {
		this.physicalKey = physicalKey;
	}
	
	@Override
	public String toString() {
		return "PhysicalAlert [getLogicalKey()=" + getLogicalKey()
				+ ", getPhysicalKey()=" + getPhysicalKey() + ", getServer()="
				+ getServer() + ", getComponent()=" + getComponent()
				+ ", getApplication()=" + getApplication() + ", getModule()="
				+ getModule() + ", getMessage()=" + getMessage()
				+ ", getAction()=" + getAction() + ", getDashboardName()="
				+ getDashboardName() + "]";
	}

}
