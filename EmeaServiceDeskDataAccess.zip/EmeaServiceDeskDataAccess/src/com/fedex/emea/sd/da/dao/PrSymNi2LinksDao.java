package com.fedex.emea.sd.da.dao;

import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrSymNi2LinksDaoException;
import com.fedex.emea.sd.da.objects.PrSymNi2Links;
import com.fedex.emea.sd.da.objects.PrSymNi2LinksPk;

public interface PrSymNi2LinksDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrSymNi2LinksPk
	 */
	public PrSymNi2LinksPk insert(PrSymNi2Links dto);

	/** 
	 * Updates a single row in the PR_SYM_NI2_LINKS table.
	 */
	public void update(PrSymNi2LinksPk pk, PrSymNi2Links dto) throws PrSymNi2LinksDaoException;

	/** 
	 * Deletes a single row in the PR_SYM_NI2_LINKS table.
	 */
	public void delete(PrSymNi2LinksPk pk) throws PrSymNi2LinksDaoException;

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'SYM_EAI_ID = :symEaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	public PrSymNi2Links findByPrimaryKey(String symEaiId, String ni2AppId) throws PrSymNi2LinksDaoException;

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria ''.
	 */
	public List<PrSymNi2Links> findAll() throws PrSymNi2LinksDaoException;

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	public List<PrSymNi2Links> findWhereSymEaiIdEquals(String symEaiId) throws PrSymNi2LinksDaoException;

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	public List<PrSymNi2Links> findWhereNi2AppNameEquals(String ni2AppName) throws PrSymNi2LinksDaoException;

	/** 
	 * Returns all rows from the PR_SYM_NI2_LINKS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	public List<PrSymNi2Links> findWhereNi2AppIdEquals(String ni2AppId) throws PrSymNi2LinksDaoException;

	/** 
	 * Returns the rows from the PR_SYM_NI2_LINKS table that matches the specified primary-key value.
	 */
	public PrSymNi2Links findByPrimaryKey(PrSymNi2LinksPk pk) throws PrSymNi2LinksDaoException;

}
