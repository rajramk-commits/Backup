package com.fedex.emea.sd.da.dao.spring;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.OrganizationDao;
import com.fedex.emea.sd.da.exceptions.OrganizationDaoException;
import com.fedex.emea.sd.da.objects.Organization;
import com.fedex.emea.sd.da.objects.OrganizationPk;

public class OrganizationDaoImpl extends AbstractDAO implements ParameterizedRowMapper<Organization>, OrganizationDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return OrganizationPk
	 */
	@Transactional
	public OrganizationPk insert(Organization dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getId(),dto.getName(),dto.getLocationName(),dto.getComments(),dto.getWebSite(),dto.getResourceStatus(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getDefiningTypeKeyType(),dto.getDefiningTypeKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getSource(),dto.getSourceKey(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getEmail(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.isIsOverlayComponentNull()?null:dto.getIsOverlayComponent());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the ORGANIZATION table.
	 */
	@Transactional
	public void update(OrganizationPk pk, Organization dto) throws OrganizationDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET ID = ?, NAME = ?, LOCATION_NAME = ?, COMMENTS = ?, WEB_SITE = ?, RESOURCE_STATUS = ?, CUSTOM_1 = ?, CUSTOM_2 = ?, CUSTOM_3 = ?, CUSTOM_4 = ?, CUSTOM_5 = ?, DEFINING_TYPE_KEY_TYPE = ?, DEFINING_TYPE_KEY_PK = ?, DESCRIPTION = ?, LONG_DESCRIPTION = ?, LAST_MODIFICATION_USER_ID = ?, LAST_MODIFICATION_DATE = ?, LASTUPDATEVERSIONNUMBER = ?, CUSTOM_6 = ?, CUSTOM_7 = ?, CUSTOM_8 = ?, CUSTOM_9 = ?, CUSTOM_10 = ?, SOURCE = ?, SOURCE_KEY = ?, OBJECT_DEFAULT_KEY_TYPE = ?, OBJECT_DEFAULT_KEY_PK = ?, EMAIL = ?, ENVIRONMENT = ?, INVENTORY_KEY_TYPE = ?, INVENTORY_KEY_PK = ?, IS_OVERLAY_COMPONENT = ? WHERE ID = ?",dto.getId(),dto.getName(),dto.getLocationName(),dto.getComments(),dto.getWebSite(),dto.getResourceStatus(),dto.getCustom1(),dto.getCustom2(),dto.getCustom3(),dto.getCustom4(),dto.getCustom5(),dto.getDefiningTypeKeyType(),dto.getDefiningTypeKeyPk(),dto.getDescription(),dto.getLongDescription(),dto.getLastModificationUserId(),dto.getLastModificationDate(),dto.getLastupdateversionnumber(),dto.getCustom6(),dto.getCustom7(),dto.getCustom8(),dto.getCustom9(),dto.getCustom10(),dto.getSource(),dto.getSourceKey(),dto.getObjectDefaultKeyType(),dto.getObjectDefaultKeyPk(),dto.getEmail(),dto.getEnvironment(),dto.getInventoryKeyType(),dto.getInventoryKeyPk(),dto.getIsOverlayComponent(),pk.getId());
	}

	/** 
	 * Deletes a single row in the ORGANIZATION table.
	 */
	@Transactional
	public void delete(OrganizationPk pk) throws OrganizationDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE ID = ?",pk.getId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return Organization
	 */
	public Organization mapRow(ResultSet rs, int row) throws SQLException
	{
		Organization dto = new Organization();
		dto.setId( rs.getString( 1 ) );
		dto.setName( rs.getString( 2 ) );
		dto.setLocationName( rs.getString( 3 ) );
		dto.setComments( rs.getString( 4 ) );
		dto.setWebSite( rs.getString( 5 ) );
		dto.setResourceStatus( rs.getString( 6 ) );
		dto.setCustom1( rs.getString( 7 ) );
		dto.setCustom2( rs.getString( 8 ) );
		dto.setCustom3( rs.getString( 9 ) );
		dto.setCustom4( rs.getString( 10 ) );
		dto.setCustom5( rs.getString( 11 ) );
		dto.setDefiningTypeKeyType( rs.getString( 12 ) );
		dto.setDefiningTypeKeyPk( rs.getString( 13 ) );
		dto.setDescription( rs.getString( 14 ) );
		dto.setLongDescription( rs.getString( 15 ) );
		dto.setLastModificationUserId( rs.getString( 16 ) );
		dto.setLastModificationDate( rs.getTimestamp(17 ) );
		dto.setLastupdateversionnumber( rs.getBigDecimal(18));
		dto.setCustom6( rs.getString( 19 ) );
		dto.setCustom7( rs.getString( 20 ) );
		dto.setCustom8( rs.getString( 21 ) );
		dto.setCustom9( rs.getString( 22 ) );
		dto.setCustom10( rs.getString( 23 ) );
		dto.setSource( rs.getString( 24 ) );
		dto.setSourceKey( rs.getString( 25 ) );
		dto.setObjectDefaultKeyType( rs.getString( 26 ) );
		dto.setObjectDefaultKeyPk( rs.getString( 27 ) );
		dto.setEmail( rs.getString( 28 ) );
		dto.setEnvironment( rs.getString( 29 ) );
		dto.setInventoryKeyType( rs.getString( 30 ) );
		dto.setInventoryKeyPk( rs.getString( 31 ) );
		dto.setIsOverlayComponent( rs.getInt( 32 ) );
		if (rs.wasNull()) {
			dto.setIsOverlayComponentNull( true );
		}
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "FIT_SCHEMA.ORGANIZATION";
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public Organization findByPrimaryKey(String id) throws OrganizationDaoException
	{
		try {
			List<Organization> list = jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ?", this,id);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria ''.
	 */
	@Transactional
	public List<Organization> findAll() throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " ORDER BY ID", this);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ID = :id'.
	 */
	@Transactional
	public List<Organization> findWhereIdEquals(String id) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ID = ? ORDER BY ID", this,id);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'NAME = :name'.
	 */
	@Transactional
	public List<Organization> findWhereNameEquals(String name) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE NAME = ? ORDER BY NAME", this,name);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LOCATION_NAME = :locationName'.
	 */
	@Transactional
	public List<Organization> findWhereLocationNameEquals(String locationName) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LOCATION_NAME = ? ORDER BY LOCATION_NAME", this,locationName);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'COMMENTS = :comments'.
	 */
	@Transactional
	public List<Organization> findWhereCommentsEquals(String comments) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE COMMENTS = ? ORDER BY COMMENTS", this,comments);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'WEB_SITE = :webSite'.
	 */
	@Transactional
	public List<Organization> findWhereWebSiteEquals(String webSite) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE WEB_SITE = ? ORDER BY WEB_SITE", this,webSite);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'RESOURCE_STATUS = :resourceStatus'.
	 */
	@Transactional
	public List<Organization> findWhereResourceStatusEquals(String resourceStatus) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE RESOURCE_STATUS = ? ORDER BY RESOURCE_STATUS", this,resourceStatus);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	@Transactional
	public List<Organization> findWhereCustom1Equals(String custom1) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_1 = ? ORDER BY CUSTOM_1", this,custom1);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	@Transactional
	public List<Organization> findWhereCustom2Equals(String custom2) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_2 = ? ORDER BY CUSTOM_2", this,custom2);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	@Transactional
	public List<Organization> findWhereCustom3Equals(String custom3) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_3 = ? ORDER BY CUSTOM_3", this,custom3);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	@Transactional
	public List<Organization> findWhereCustom4Equals(String custom4) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_4 = ? ORDER BY CUSTOM_4", this,custom4);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	@Transactional
	public List<Organization> findWhereCustom5Equals(String custom5) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_5 = ? ORDER BY CUSTOM_5", this,custom5);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DEFINING_TYPE_KEY_TYPE = :definingTypeKeyType'.
	 */
	@Transactional
	public List<Organization> findWhereDefiningTypeKeyTypeEquals(String definingTypeKeyType) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DEFINING_TYPE_KEY_TYPE = ? ORDER BY DEFINING_TYPE_KEY_TYPE", this,definingTypeKeyType);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DEFINING_TYPE_KEY_PK = :definingTypeKeyPk'.
	 */
	@Transactional
	public List<Organization> findWhereDefiningTypeKeyPkEquals(String definingTypeKeyPk) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DEFINING_TYPE_KEY_PK = ? ORDER BY DEFINING_TYPE_KEY_PK", this,definingTypeKeyPk);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	@Transactional
	public List<Organization> findWhereDescriptionEquals(String description) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE DESCRIPTION = ? ORDER BY DESCRIPTION", this,description);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	@Transactional
	public List<Organization> findWhereLongDescriptionEquals(String longDescription) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LONG_DESCRIPTION = ? ORDER BY LONG_DESCRIPTION", this,longDescription);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	@Transactional
	public List<Organization> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_USER_ID = ? ORDER BY LAST_MODIFICATION_USER_ID", this,lastModificationUserId);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	@Transactional
	public List<Organization> findWhereLastModificationDateEquals(Date lastModificationDate) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LAST_MODIFICATION_DATE = ? ORDER BY LAST_MODIFICATION_DATE", this,lastModificationDate);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	@Transactional
	public List<Organization> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE LASTUPDATEVERSIONNUMBER = ? ORDER BY LASTUPDATEVERSIONNUMBER", this,lastupdateversionnumber);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	@Transactional
	public List<Organization> findWhereCustom6Equals(String custom6) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_6 = ? ORDER BY CUSTOM_6", this,custom6);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	@Transactional
	public List<Organization> findWhereCustom7Equals(String custom7) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_7 = ? ORDER BY CUSTOM_7", this,custom7);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	@Transactional
	public List<Organization> findWhereCustom8Equals(String custom8) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_8 = ? ORDER BY CUSTOM_8", this,custom8);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	@Transactional
	public List<Organization> findWhereCustom9Equals(String custom9) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_9 = ? ORDER BY CUSTOM_9", this,custom9);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	@Transactional
	public List<Organization> findWhereCustom10Equals(String custom10) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE CUSTOM_10 = ? ORDER BY CUSTOM_10", this,custom10);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'SOURCE = :source'.
	 */
	@Transactional
	public List<Organization> findWhereSourceEquals(String source) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SOURCE = ? ORDER BY SOURCE", this,source);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'SOURCE_KEY = :sourceKey'.
	 */
	@Transactional
	public List<Organization> findWhereSourceKeyEquals(String sourceKey) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE SOURCE_KEY = ? ORDER BY SOURCE_KEY", this,sourceKey);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	@Transactional
	public List<Organization> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_TYPE = ? ORDER BY OBJECT_DEFAULT_KEY_TYPE", this,objectDefaultKeyType);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	@Transactional
	public List<Organization> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE OBJECT_DEFAULT_KEY_PK = ? ORDER BY OBJECT_DEFAULT_KEY_PK", this,objectDefaultKeyPk);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'EMAIL = :email'.
	 */
	@Transactional
	public List<Organization> findWhereEmailEquals(String email) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE EMAIL = ? ORDER BY EMAIL", this,email);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	@Transactional
	public List<Organization> findWhereEnvironmentEquals(String environment) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE ENVIRONMENT = ? ORDER BY ENVIRONMENT", this,environment);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	@Transactional
	public List<Organization> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_TYPE = ? ORDER BY INVENTORY_KEY_TYPE", this,inventoryKeyType);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	@Transactional
	public List<Organization> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE INVENTORY_KEY_PK = ? ORDER BY INVENTORY_KEY_PK", this,inventoryKeyPk);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the ORGANIZATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	@Transactional
	public List<Organization> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws OrganizationDaoException
	{
		try {
			return jdbcTemplate.query("SELECT ID, NAME, LOCATION_NAME, COMMENTS, WEB_SITE, RESOURCE_STATUS, CUSTOM_1, CUSTOM_2, CUSTOM_3, CUSTOM_4, CUSTOM_5, DEFINING_TYPE_KEY_TYPE, DEFINING_TYPE_KEY_PK, DESCRIPTION, LONG_DESCRIPTION, LAST_MODIFICATION_USER_ID, LAST_MODIFICATION_DATE, LASTUPDATEVERSIONNUMBER, CUSTOM_6, CUSTOM_7, CUSTOM_8, CUSTOM_9, CUSTOM_10, SOURCE, SOURCE_KEY, OBJECT_DEFAULT_KEY_TYPE, OBJECT_DEFAULT_KEY_PK, EMAIL, ENVIRONMENT, INVENTORY_KEY_TYPE, INVENTORY_KEY_PK, IS_OVERLAY_COMPONENT FROM " + getTableName() + " WHERE IS_OVERLAY_COMPONENT = ? ORDER BY IS_OVERLAY_COMPONENT", this,isOverlayComponent);
		}
		catch (Exception e) {
			throw new OrganizationDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the ORGANIZATION table that matches the specified primary-key value.
	 */
	public Organization findByPrimaryKey(OrganizationPk pk) throws OrganizationDaoException
	{
		return findByPrimaryKey( pk.getId() );
	}

}
