package com.fedex.emea.sd.da.logger;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ApplicationLogger {

	public static final ApplicationLogger instance = new ApplicationLogger();

	private Logger LogDebug = LogManager.getLogger("DebugLogger");
	private Logger LogInfo = LogManager.getLogger("InfoLogger");
	private Logger LogWarn = LogManager.getLogger("WarnLogger");
	private Logger LogError = LogManager.getLogger("ErrorLogger");
	
	private ApplicationLogger(){
	}
		
	public static final ApplicationLogger getInstance(){
		return instance; 
	}
	
	public Logger getInstance(Level iLogLevel){
		if (iLogLevel == Level.DEBUG)
			return LogDebug;
		if (iLogLevel == Level.INFO)
			return LogInfo;
		if (iLogLevel == Level.WARN)
			return LogWarn;
		if (iLogLevel == Level.ERROR)
			return LogError;
		else return null;
	}
	
	public void log(Exception exception){
		LogError.error("", exception);
	}

	public void log(String msg, Exception exception){
		if(msg != null && msg.trim().length() > 0)
			LogError.error(msg, exception);
		else
			LogError.error("", exception);
	}

	public void log(Class<?> callerClass,String message,Exception exception){
		String className = callerClass==null?"":callerClass.getName();
		LogError.error(className+": "+ message, exception);
	}
	
	public void log(Level iLogLevel, String message){
		if (iLogLevel == Level.DEBUG)
			LogDebug.debug(message);
		if (iLogLevel == Level.INFO)
			LogInfo.info(message);
		if (iLogLevel == Level.WARN)
			LogWarn.warn(message);
		if (iLogLevel == Level.ERROR)
			LogError.error(message);
	}
	
	public void logError(String strMsg) {
		log(Level.ERROR, strMsg);
	}
	
	public void logWarn(String strMsg) {
		log(Level.WARN, strMsg);
	}
	
	public void logInfo(String strMsg) {
		log(Level.INFO, strMsg);
	}
	
	public void logDebug(String strMsg) {
		log(Level.DEBUG, strMsg);
	}
	
	public String getStackTrace(Throwable t)
    {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw, true);
        t.printStackTrace(pw);
        pw.flush();
        sw.flush();
        return sw.toString();
    }	
}
