
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%     	
        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
		
        %>
<html>
<head>
<meta charset="UTF-8">
<title>SD Evaluation</title>
<script >

   window.history.forward();
   function noBack() { window.history.forward(); 
   }
   function openLoginMenu() {
		window.close("AddQuestion.jsp");
		 window.open("Admin.jsp");
	}

   function add_sub(el)
   {
     var cbs = document.getElementById('CorrectAns').getElementsByTagName('input');
     var textareaValue = '';  
     for (var i = 0, len = cbs.length; i<len; i++) {
       if ( cbs[i].type === 'checkbox' && cbs[i].checked) {
             textareaValue += cbs[i].value;
       }
     }
     	alert("textareaValue :"+textareaValue);
       	document.getElementById("CorrectAnsHid").value = textareaValue;
       	alert(document.getElementById("CorrectAnsHid").value);
   }
   
   function ChangeFields(Obj)
   {
	   if(document.getElementById("qt").value !== "mcq")
	   {
	   		document.getElementById("OptionA").style.display = "none";
	   		document.getElementById("OptionB").style.display = "none";
	   		document.getElementById("OptionC").style.display = "none";
	   		document.getElementById("OptionD").style.display = "none";
	   		document.getElementById("CorrectAns").style.display = "none";
	   }
	   else
		{
		   	document.getElementById("OptionA").style.display = "block";
	  		document.getElementById("OptionB").style.display = "block";
	  		document.getElementById("OptionC").style.display = "block";
	  		document.getElementById("OptionD").style.display = "block";
	  		document.getElementById("CorrectAns").style.display = "block";
		}
   
   }
   
   function QuestionValidation(){
	   
	   /* if(document.getElementById("Question").value==null || document.getElementById("Question").value==""){
		   document.getElementById("OptionABlank").innerHTML="";
		   document.getElementById("OptionBBlank").innerHTML="";
		   document.getElementById("CorrectAnsBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "Please Enter the Question";
		   return false;
   		}
	   if(document.getElementById("OptionA").value==null || document.getElementById("OptionA").value===""){
		  
		   document.getElementById("OptionBBlank").innerHTML="";
		   document.getElementById("CorrectAnsBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("OptionABlank").innerHTML = "Please Enter the Option";
		   return false;
   		}
	    if(document.getElementById("OptionB").value==null || document.getElementById("OptionB").value==""){
	    	 	document.getElementById("OptionABlank").innerHTML="";
			 
			   document.getElementById("CorrectAnsBlank").innerHTML="";
			   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("OptionBBlank").innerHTML = "Please Enter the Option";
		   return false;
   		}
	   
	    if(document.getElementById("CorrectAns").value==null || document.getElementById("CorrectAns").value==""){
	    	 document.getElementById("OptionABlank").innerHTML="";
			   document.getElementById("OptionBBlank").innerHTML="";
			   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("CorrectAnsBlank").innerHTML = "Please Enter the Value";
		   return false;
   		} */
	    var team = 	document.getElementById("teams").value;
   		var teamName;
   		switch(team)
   		{
   			case "ccc"		: teamName = "Clearance CC"; break;
   			case "hscc"		: teamName = "Hubstack CC"; break;
   			case "AppSupp"	: teamName = "Application Support"; break;
   			case "OffSupp"	: teamName = "Office Support"; break;
   			case "VoSupp"	: teamName = "Voice Support"; break;
   			default : teamName ="";
   		}
   		
	    var qType = document.getElementById("qt").value;
	    return confirm("Are you sure to add qustions to team -"+teamName+", and question type -"+qType);
   }

</script>
<style type="text/css">
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
	height :50px;
	background-color: #7030a0;
	margin:0;
		
}
.logout{
	float:right;
	margin-right:5%;
	background-color:#FF8C00;
	color:white;
	padding:14px 20px;
	border:none;
	cursor:pointer;
}
.logout:hover{
	background-color:#4B0060;
}

input[type=submit]{
	background-color:#4B0082;
	color:white;
	padding:14px 20px;
	margin: 8px 0;
	border:none;
	cursor:pointer;
	width:20%;
}
input[type=submit]:hover{
	background-color:#7030a0;
}
input[name=Refresh]{
	background-color:#4B0082;
	color:white;
	padding:4px 2px;
	margin: 2px 0;
	border:none;
	cursor:pointer;
	width:20%;
}
input[name=Refresh]:hover{
	background-color:#7030a0;
}

textarea{
  width: 650px;
  height: 60px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-family:Calibri;
  
}

input[type=text]{
  width: 650px;
  height: 50px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  
}
.quest{
  width: 650px;
  height: 100px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
 font-family:Calibri;
}

.login{
	
	display:flex;
	justify-content:center;
}

td{
	font-size:16px;
	font-family:Calibri;
}
.home{
			
	background-color:#4B0082;
	color:white;
	padding:14px 20px;
	margin: 8px 0;
	border:none;
	cursor:pointer;
	width:20%;
}
</style>
	
</head>
<body>
		
     	<div class="main"> 
     	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Add Question</p></center>
   		</div>
   		
   		 <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div> 
        
        <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form>  
		<button class="home" onclick="openLoginMenu()">HOME</button>
     	
     	<br><br>
     	
    <form action="AddMCQ.jsp" method="post" onsubmit="return QuestionValidation()">
     	<label for="teams" >Choose Teams:</label>
		  <select id="teams" name="teams">
		    <option  value="ccc" selected>Clearance CC</option>
		    <option value="hscc">Hubstack CC</option>
		    <option value="AppSupp" >Application Support</option>
		     <option value="OffSupp" >Office Support</option>
		      <option value="VoSupp" >Voice Support</option>
		  </select>
		     <label for="qt">Question Type:</label>
		  <select id="qt" name="qt" onchange="ChangeFields(this)">
		    <option value="mcq" selected>Multiple Choice Questions</option>
		    <option value="1m">One Marks Question</option>
		    <option value="2m">Two Marks Question</option>
		    <option value="3m">Three Marks Question</option>    
		    <option value="5m">Five Marks Question</option>
		  </select>
		  <input type="submit" name="Refresh" value="Refresh">
		  <input type="hidden" id = "CorrectAnsHid" name="CorrectAnsHid" >
		<table>
			<tr><td><div style="color:red;font-family:Calibri;">${showMessage}</div></td></tr>
			<tr>
				<td>Question<br><textarea class="quest" id="Question" name="Question" maxlength="1000" ></textarea></td>
				<td><div id="QuestionBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td id="OptionA"><br>Option A<br><textarea id="OptionA" name="OptionA" maxlength="255"  ></textarea></td>
				<td><div id="OptionABlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td id="OptionB"><br>Option B<br><textarea id="OptionB" name="OptionB" maxlength="255" ></textarea></td>
				<td><div id="OptionBBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td id="OptionC"><br>Option C<br><textarea id="OptionC" name="OptionC" maxlength="255"></textarea></td>
				
			</tr>
			<tr>
				<td id="OptionD"><br>Option D<br><textarea id="OptionD" name="OptionD" maxlength="255"></textarea></td>
				
			</tr>
			<tr>
				<td>
				<div id="CorrectAns">
					<br>Correct Answer<br>
					<input type="checkbox" name="CorrectAns1" value="A" onclick="add_sub('A');"><label> A </label>
		            <input type="checkbox" name="CorrectAns2" value="B" onclick="add_sub('B');"><label> B </label>
		            <input type="checkbox" name="CorrectAns3" value="C" onclick="add_sub('C');"><label> C </label>
		            <input type="checkbox" name="CorrectAns4" value="D" onclick="add_sub('D');"><label> D </label>
				</div>
				</td>
				<td><div id="CorrectAnsBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
		</table>		
		<br>
		
		<input type="submit" name="Submit"  value="Submit" >
	</form>

        <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
		<%} %>
</body>
</html>