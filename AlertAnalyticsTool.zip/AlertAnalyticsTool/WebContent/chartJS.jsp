<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<script src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.1.4/Chart.bundle.min.js'></script>
<script type="text/javascript">



		$(document).ready(
		  function() {
		    var canvas = document.getElementById("myChart");
		    var ctx = canvas.getContext("3d");

		    var data = {
		  		  datasets: [{
		  		    data: [300, 50, 100],
		  		    backgroundColor: [
		  		      "#F7464A",
		  		      "#46BFBD",
		  		      "#FDB45C"
		  		    ]
		  		  }],
		  		  labels: [
		  		    "Red",
		  		    "Green",
		  		    "Yellow"
		  		  ]
		  		};
		    
		    var myNewChart = new Chart(ctx, {
		      type: 'pie',
		      data: data
		    });

		    canvas.onclick = function(evt) {
		      var activePoints = myNewChart.getElementsAtEvent(evt);
		      if (activePoints[0]) {
		        var chartData = activePoints[0]['_chart'].config.data;
		        var idx = activePoints[0]['_index'];

		        var label = chartData.labels[idx];
		        var value = chartData.datasets[0].data[idx];

		        var url = "http://example.com/?label=" + label + "&value=" + value;
		        console.log(url);
		        alert(url);
		      }
		    };
		  }
		);


</script>

</head>
<body>
<div style="width: 300px; height: 300px">
  <canvas id="myChart"></canvas>
</div>
</body>
</html>