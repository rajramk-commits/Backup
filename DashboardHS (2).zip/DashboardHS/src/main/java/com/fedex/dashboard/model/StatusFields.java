package com.fedex.dashboard.model;

import java.util.ArrayList;

public class StatusFields {

	private ArrayList<String> checkedServers;
	private String status;

	public ArrayList<String> getCheckedServers() {
		return checkedServers;
	}

	public void setCheckedServers(ArrayList<String> checkedServers) {
		this.checkedServers = checkedServers;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "StatusFields [checkedServers=" + checkedServers + ", status=" + status + "]";
	}

}
