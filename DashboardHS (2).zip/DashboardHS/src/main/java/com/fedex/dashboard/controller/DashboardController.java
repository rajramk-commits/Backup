package com.fedex.dashboard.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fedex.dashboard.model.RequestBean;
import com.fedex.dashboard.model.UserDataBean;
import com.fedex.dashboard.services.DashboardServices;

@RestController
@CrossOrigin
@EnableScheduling
public class DashboardController {

	private final static Logger logger = LogManager.getLogger(DashboardController.class);
	
	@Autowired
	private DashboardServices dashboardServices;

	@RequestMapping(value = "/HSAppServerAndLocationDetails/{hubLocation}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getServerWithLocation(@PathVariable String hubLocation) throws IOException {
		if(hubLocation.equals("undefined"))
			hubLocation = "ALL";
		logger.info("getServerWithLocation :"+hubLocation);
		return dashboardServices.ServerWithLocation(hubLocation);
	}
	
	@RequestMapping(value = "/HubLocationList", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getHubLocationList() throws IOException {
		logger.info("getHubLocationList called !!!");
		return dashboardServices.locationList();
	}
	
	@RequestMapping(value = "/UpdateLocStatus", method = RequestMethod.POST )
	public ResponseEntity<?> updateLocStatus(@RequestBody RequestBean bean) throws IOException {
		logger.info("updateLocStatus :"+bean);
		return dashboardServices.updateLocStatus(bean.getHubLocation(), bean.getAppNames(), bean.getServerStatus());
	}
	
	@RequestMapping(value = "/UpdateAllStatus", method = RequestMethod.POST)
	public ResponseEntity<?> updateAllStatus(@RequestBody RequestBean bean) throws IOException {
		logger.info("updateAllStatus :"+bean);
		return dashboardServices.updateAllStatus(bean.getAppNames(), bean.getServerStatus());
	}
	
	@RequestMapping(value = "/HubstackCCTickets", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getHubstackCCTickets() throws IOException {
		logger.info("getHubstackCCTickets called !!!");
		return dashboardServices.getHubstackCCPriorityTickets();
	}
	
	@RequestMapping(value = "/ClearanceCCTickets", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getClearanceCCTickets() throws IOException {
		logger.info("getClearanceCCTickets called !!!");
		return dashboardServices.getClearacnceCCPriorityTickets();
	}
	
	@RequestMapping(value = "/HubstackCCTicketsCount", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getHubstackCCTicketsCount() throws IOException {
		logger.info("getHubstackCCTicketsCount called !!!");
		return dashboardServices.getHubstackCCTicketsCounts();
	}
	
	@RequestMapping(value = "/ClearanceCCTicketsCount", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getClearanceCCTicketsCount() throws IOException {
		logger.info("getClearanceCCTicketsCount called !!!");
		return dashboardServices.getClearanceCCTicketsCounts();
	}
	
	@RequestMapping(value = "/DepAppDetails/{appName}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<?> getDepAppDetails(@PathVariable String appName) throws IOException {
		logger.info("getDepAppDetails :"+appName);
		return dashboardServices.getDepAppDetails(appName);
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> getDepAppDetails(@RequestBody UserDataBean userBean) throws IOException {
		logger.info("getDepAppDetails :"+userBean);
		return dashboardServices.getUserDetails(userBean);
	}
	
	@RequestMapping(value = "/DepServerDetails", method = RequestMethod.POST)
	public ResponseEntity<?> UpdateDepServerDetails(@RequestBody Object bean) throws IOException {
		logger.info("UpdateDepServerDetails :"+bean);		
		@SuppressWarnings("unchecked")
		LinkedHashMap<String,  List<Map<String, ?>>> mapSet = (LinkedHashMap<String, List<Map<String, ?>>>) bean;
		logger.info("mapSet :"+mapSet);
		return dashboardServices.updateDepServerDetails(mapSet);
	}
	
}
