
//*****************************************************************
//* 
//* FdxCaseJavaCiRcCaseNoteCollection.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public interface IFdxCaseJavaCiRcCaseNoteCollection 
  {
  public long getCount() throws JOAException;
  public IFdxCaseJavaCiRcCaseNote item(long Index) throws JOAException;
  public IFdxCaseJavaCiRcCaseNote insertItem(long Index) throws JOAException;
  public boolean deleteItem(long Index) throws JOAException;
  public IFdxCaseJavaCiRcCaseNote itemByKeys() throws JOAException;
  public IFdxCaseJavaCiRcCaseNote currentItem() throws JOAException;
  public long currentItemNum() throws JOAException;
  public IFdxCaseJavaCiRcCaseNote getEffectiveItem(String Date, long SeqNum) throws JOAException;
  public long getEffectiveItemNum(String Date, long SeqNum) throws JOAException;
  }
