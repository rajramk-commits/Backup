<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<%
String Username = "";
String role = "";
String retStat = request.getParameter("status");
%>
<head>
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
<script>
function goBack() 
{
	window.history.back();
}
function chkOnLoadStatus()
{
	<%
	if(retStat != null)
	{
	%>
		alert('<%=retStat%>');
	<%}%>
}
function validateUser()
{
	var username = document.getElementById("username").value;
	var role = document.getElementById("role").value;
	if(username==null || username==""){
	   alert("Please enter Fedex user Id");
	   return false;
	}
	if(role==null || role==""){
		   alert("Please enter valid Fedex role");
		   return false;
	}
	return true;
}
</script>

<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>

<style>
	.main{
	margin-left:10%;
	/* margin-right:12%; */
	}
	.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
	}
	.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:10%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:30%;
	}
	.toolbar {
    height: 75px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .toolbarFooter {
    height: 50px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: #ff6701;
    color: black;
    font-weight: 100;
  }
  purple
  {
    height: 10px;
    margin: 0 0 0 0;
    background-color: #4300fc;
  }
  .card {
    /* border-radius: 4px;
    border: 1px solid #eee;
    background-color: #fafafa; */
    height: 40px;
    /* width: 200px; */
    margin: 0 8px 16px;
    /* padding: 16px;
    display: flex; */
    flex-direction: row;
    justify-content: center;
    align-items: center;
    transition: all 0.2s ease-in-out;
    line-height: 24px;
  }





/* --------------original------------------- */
:host {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    font-size: 24px;
    color: #333;
    box-sizing: border-box;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

.divTag{
    
    font-size: 18px;
    color: black ;
    text-align: center;
}
.header{
    color: darkblue;
    font-size: xx-large;
}


.inputbox .card:not(.highlight-card) {
    cursor: pointer;
  }
  
  .inputbox .card:not(.highlight-card):hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 17px rgba(black, 0.35);
  }

  .inputbox .card:not(.highlight-card):hover .material-icons path {
    fill: rgb(0, 0, 0);
  }
.inputbox{
    align-items: center;
    color: mediumblue;
    height: 30px;
	width: 180px;
	margin: 10px;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: large;
}
.buttonBox{
  border-radius: 4px;
    border: 2px solid rgb(102, 102, 102);
    background-color: coral;
    height: 30px;
    width: 150px;
    margin: 0 8px 16px;
    /* padding: 16px;
    display: flex;  */
    flex-direction: row;
    justify-content: center;
    align-items: center;
    transition: all 0.2s ease-in-out;
    line-height: 24px;
    
}
.labelFont{
    color: brown
}
.selectBox{
    align-items: center;
    color :darkblue;
    height: 30px;
	width: 180px;
	margin: 5px;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: medium;
}
.errMessage{
    color: red;
    font-size: 15px;
    text-align: center;
}
.login{
	
	display:flex;
	justify-content:center;
}


form{	
	width:270px;
	padding : 20px;
	border:3px solid #f1f1f1;
	border-radius:8px;	
		
}

input[type=text],input[type=password]{
font-family:Calibri;
font-size:15px;
width:100%;
padding:12px 20px;
margin:8px 0;
display:inline-block;
border:1px solid #ccc;
box-sizing:border-box;
}

input[type=submit]{

background-color:#4B0082;
color:white;
padding:5px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:100%;
}

.container{
display:flex;
	justify-content:center;
padding:14px;
}
.out{
  float: right;
  font-size: 20px;
  color: white;
  margin: 300px;
  border-radius: 1px;
  border: 2px solid #eee;
  background-color: rgb(56, 33, 24); 
  width: 150px;
}
</style>
</head>
<body onload="chkOnLoadStatus()">


<div class="toolbar" role="banner">
    <img
      width="143"
      alt="Angular Logo"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR4h9OKkNpZrtc-Z6l80kuRFy9wn3DPFOHaIncREOOreXAWEKLG"
      title= "FedEx"
      />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <button class="out" style="margin-left: 30%" onclick="goBack()">Home</button>
</div>

<div class="login">
<br><br><br>
<h2 style ="text-align: center;">User Management </h2>
</div>
<div class="container">  
      <br> <br><br>
<form action="saveUserScreen.jsp" method="post" onsubmit="return validateUser()" >
			<div >
				<img alt="FedEx" src="image/logo.png">
			</div>
			<br>
  <label for="username" class="card"><b>FedEx Pin :</b> </label>
  <input class="inputbox" type="text" id="username" name = "username" value="<%=Username %>">
  <br><br>
  
  <label for="role" class="card"><b>Role : </b></label><br> 
  	<select name="role" id="role" class="inputbox">
  	<option value="">Select</option>
	  <option value="Admin">Admin</option>
	  <option value="User">User</option>
	</select>
	<br><br>
	<label for="appName" class="card"><b>Application Name : </b></label><br> 
  	<select name="appName" id="appName" class="inputbox">
  	  <option value="">Select</option>
	  <option value="Sabre">Sabre</option>
	  <option value="GSS">GSS</option>
	</select>
  <br><br>
  <div class="form-check">
  <input style="color: navy;" type="radio" id="add" name="actn" value="add">
  <label style="color: black;font-weight: bold;" for="add"> Add User </label> 
  &nbsp;&nbsp;&nbsp;&nbsp;
  <input style="color: navy;" type="radio" id="del" name="actn" value="del">
  <label style="color: black; font-weight: bold;" for="del"> Delete User </label>
  </div>
 
  <br><br>
  
  <input class="buttonBox" type="submit" name="Submit"  value="Save" >
  
  </form>
</div> 
<br><br><br><br><br><br><br><br><br><br><br><br>
<div class="toolbarFooter" > <!-- style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri" -->
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>

</body>
</html>