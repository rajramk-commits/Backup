package com.fedex.emea.dimm.adaptor;

import com.fedex.emea.dimm.alert.AbstractAlert;
import com.fedex.emea.dimm.alert.LogicalAlert;
import com.fedex.emea.dimm.alert.PhysicalAlert;
import com.fedex.emea.dimm.utils.DIMMConstants;
import com.fedex.emea.dimm.utils.Utilities;

public abstract class AbstractAlertDomainAdaptor {

	public AbstractAlertDomainAdaptor() throws Exception{
		
	}
	
	protected LogicalKeySeedEntry logicalSeedKeyEntry;
	
	public abstract AbstractAlertDomainAdaptorConfig getConfig();
	
	public abstract boolean isApplicable(AbstractAlert physicalAlert);
	
	public LogicalKeySeedEntry getLogicalSeedKeyEntry() {
		return logicalSeedKeyEntry;
	}

	public void setLogicalSeedKeyEntry(LogicalKeySeedEntry logicalSeedKeyEntry) {
		this.logicalSeedKeyEntry = logicalSeedKeyEntry;
	}

	public final LogicalAlert adaptPhysicalAlertToLogicalAlert(PhysicalAlert physicalAlert) {
		
		LogicalAlert la = adaptAlertData(physicalAlert);
		
		//if(physicalAlert.getDashboardName().equals("DE_PROD_DASHBOARD")) {
			la.setDashboardName("DIMM:" + physicalAlert.getDashboardName());
		//}
		
		populateLogicalKey(la);
		
		return la;
	}
	
	protected LogicalAlert adaptAlertData(PhysicalAlert physicalAlert){
		LogicalAlert la = new LogicalAlert();
		
		la.setServer(this.adaptServerValue(physicalAlert));
		la.setApplication(this.adaptApplicationValue(physicalAlert));
		la.setComponent(this.adaptComponentValue(physicalAlert));
		la.setModule(this.adaptModuleValue(physicalAlert));
		
		/*if(physicalAlert.getApplication() != null && (physicalAlert.getApplication().equals(DIMMConstants.NO_MSG_CONSUME) || physicalAlert.getApplication().equals(DIMMConstants.ABOVE_CRITICAL_LEVEL))) {
			la.setApplication(DIMMConstants.NO_MSG_CONSUME_OR_ABOVE_CRITICAL_LEVEL);
		}*/
		if(physicalAlert.getApplication() != null && (Utilities.getITOApplicationList().contains(physicalAlert.getApplication()))) {
			la.setApplication(DIMMConstants.ITO_APPLICATION_GNERICVALUE);
		} else if(physicalAlert.getApplication() != null && (Utilities.getDTRCApplicationList().contains(physicalAlert.getApplication())))
		{
			la.setApplication("genius.dtrc.upload");
		}
		else
		{
			la.setApplication(this.adaptApplicationValue(physicalAlert));
		}
		
		//For Component_3
		if(Utilities.getOvoServerComponents().contains(physicalAlert.getComponent())) {
			la.setComponent("OBMCOMPONENT");
			la.setApplication("OBMAPPLICATION");
			la.setModule("OBM MODULE");
		}
		
		//la.setComponent(this.adaptComponentValue(physicalAlert));
		//la.setModule(this.adaptModuleValue(physicalAlert));
		la.setAction(this.adaptActionValue(physicalAlert));
		la.setMessage(this.adaptMessageValue(physicalAlert));
		la.setDashboardName(this.adaptDashboardName(physicalAlert));
		
		la.setRecordSourceId(physicalAlert.getRecordSourceId());
		la.setCaseSummary(physicalAlert.getCaseSummary());
		la.setCaseDescription1(physicalAlert.getCaseDescription1());
		la.setCaseDescription2(physicalAlert.getCaseDescription2());
		la.setCaseDescription3(physicalAlert.getCaseDescription3());
		la.setCaseDescription4(physicalAlert.getCaseDescription4());
		la.setCaseDescription5(physicalAlert.getCaseDescription5());
		la.setCaseDescription6(physicalAlert.getCaseDescription6());
		la.setCaseDescription7(physicalAlert.getCaseDescription7());
		la.setCaseDescription8(physicalAlert.getCaseDescription8());
		la.setCaseDescription9(physicalAlert.getCaseDescription9());
		
		return la;
	}
	
	private final void populateLogicalKey(LogicalAlert la){
		String logicalKey = "";
		String logicalKeySeed = logicalSeedKeyEntry!=null?logicalSeedKeyEntry.getLogicalKeySeed():"";
		/*if(la.getApplication() != null && la.getApplication().equals(DIMMConstants.NO_MSG_CONSUME_OR_ABOVE_CRITICAL_LEVEL)) {
			logicalKey = "" + (la.getServer()+":"+la.getApplication()+":"+la.getComponent()+":"+la.getModule()).hashCode();
		}*/
		if(la.getApplication() != null && la.getApplication().equals(DIMMConstants.ITO_APPLICATION_GNERICVALUE)) {
			logicalKey = "" + (la.getServer()+":"+la.getApplication()+":"+la.getComponent()+":"+la.getModule()).hashCode();
		} else {
			logicalKey = logicalKeySeed+(la.getDashboardName()+":"+la.getServer()+":"+la.getApplication()+":"+la.getComponent()+":"+la.getModule()).hashCode();
		}
		
		la.setLogicalKey(logicalKey);
	}
	
	//default adaptation is strait forward, no modification
	protected String adaptServerValue(PhysicalAlert physicalAlert){
		return physicalAlert.getServer();
	}
	
	protected String adaptApplicationValue(PhysicalAlert physicalAlert){
		return physicalAlert.getApplication();
	}
	
	protected String adaptComponentValue(PhysicalAlert physicalAlert){
		return physicalAlert.getComponent();
	}
	
	protected String adaptModuleValue(PhysicalAlert physicalAlert){
		return physicalAlert.getModule();
	}
	
	protected String adaptMessageValue(PhysicalAlert physicalAlert){
		return physicalAlert.getMessage();
	}
	
	protected String adaptActionValue(PhysicalAlert physicalAlert){
		return physicalAlert.getAction();
	}
	
	protected String adaptDashboardName(PhysicalAlert physicalAlert){
		return physicalAlert.getDashboardName();
	}
}
