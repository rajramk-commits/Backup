package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.PrValidationsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrValidations;
import com.fedex.emea.sd.da.objects.PrValidationsPk;

public interface PrValidationsDao
{
	
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrValidationsDaoException;
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrValidationsDaoException;
	
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrValidationsPk
	 */
	public PrValidationsPk insert(PrValidations dto);

	/** 
	 * Updates a single row in the PR_VALIDATIONS table.
	 */
	public void update(PrValidationsPk pk, PrValidations dto) throws PrValidationsDaoException;

	/** 
	 * Deletes a single row in the PR_VALIDATIONS table.
	 */
	public void delete(PrValidationsPk pk) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'CY = :cy AND EAI_ID = :eaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	public PrValidations findByPrimaryKey(String cy, String eaiId, String ni2AppId) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria ''.
	 */
	public List<PrValidations> findAll() throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'CY = :cy'.
	 */
	public List<PrValidations> findWhereCyEquals(String cy) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'EAI_ID = :eaiId'.
	 */
	public List<PrValidations> findWhereEaiIdEquals(String eaiId) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'SYM_APP_NAME = :symAppName'.
	 */
	public List<PrValidations> findWhereSymAppNameEquals(String symAppName) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	public List<PrValidations> findWhereNi2AppIdEquals(String ni2AppId) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	public List<PrValidations> findWhereNi2AppNameEquals(String ni2AppName) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	public List<PrValidations> findWhereRespMdPinEquals(String respMdPin) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	public List<PrValidations> findWhereRespMgrPinEquals(String respMgrPin) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'DR_DOC_RECVD = :drDocRecvd'.
	 */
	public List<PrValidations> findWhereDrDocRecvdEquals(String drDocRecvd) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_TYPE = :valType'.
	 */
	public List<PrValidations> findWhereValTypeEquals(String valType) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_COMPONENT = :valComponent'.
	 */
	public List<PrValidations> findWhereValComponentEquals(String valComponent) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_SCENARIO = :valScenario'.
	 */
	public List<PrValidations> findWhereValScenarioEquals(String valScenario) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_JUSTIF = :valJustif'.
	 */
	public List<PrValidations> findWhereValJustifEquals(String valJustif) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_ESTMATED_TEST_DTTM = :valEstmatedTestDttm'.
	 */
	public List<PrValidations> findWhereValEstmatedTestDttmEquals(Date valEstmatedTestDttm) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_CONFIRMED_TEST_DTTM = :valConfirmedTestDttm'.
	 */
	public List<PrValidations> findWhereValConfirmedTestDttmEquals(Date valConfirmedTestDttm) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_STATUS = :valStatus'.
	 */
	public List<PrValidations> findWhereValStatusEquals(String valStatus) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_REMARKS = :valRemarks'.
	 */
	public List<PrValidations> findWhereValRemarksEquals(String valRemarks) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_RESULT = :valResult'.
	 */
	public List<PrValidations> findWhereValResultEquals(String valResult) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_GAPS = :valGaps'.
	 */
	public List<PrValidations> findWhereValGapsEquals(String valGaps) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_PROP_ACTIONS = :valPropActions'.
	 */
	public List<PrValidations> findWhereValPropActionsEquals(String valPropActions) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	public List<PrValidations> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'SYM_PROF_NAME = :symProfName'.
	 */
	public List<PrValidations> findWhereSymProfNameEquals(String symProfName) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'NI2_BUS_CRIT = :ni2BusCrit'.
	 */
	public List<PrValidations> findWhereNi2BusCritEquals(String ni2BusCrit) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	public List<PrValidations> findWhereAuditIdEquals(int auditId) throws PrValidationsDaoException;

	/** 
	 * Returns all rows from the PR_VALIDATIONS table that match the criteria 'VAL_RTA = :valRta'.
	 */
	public List<PrValidations> findWhereValRtaEquals(int valRta) throws PrValidationsDaoException;

	/** 
	 * Returns the rows from the PR_VALIDATIONS table that matches the specified primary-key value.
	 */
	public PrValidations findByPrimaryKey(PrValidationsPk pk) throws PrValidationsDaoException;

}
