<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>SD Evaluation</title>
<script >

</script>
<style type="text/css">
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
		height :50px;
		background-color: #7030a0;
		margin:0;
		
	}
.logout{
float:right;
margin-right:5%;
background-color:#FF8C00;
color:white;
padding:14px 20px;
border:none;
cursor:pointer;
}
.logout:hover{
background-color:#4B0060;
}

input[type=submit]{

background-color:#4B0082;
color:white;
padding:14px 20px;
margin: 8px 0;
border:none;
cursor:pointer;
width:20%;
}

input[type=submit]:hover{
background-color:#7030a0;

}
.login{
	
	display:flex;
	justify-content:center;
}


</style>
	
</head>
<body>
		<%     	
	        if(session.getAttribute("sessionName")==null)
	        {
	            response.sendRedirect("Login.jsp");
			}
			session.setAttribute("min",30);
			session.setAttribute("sec",00);
			String userID = (String) session.getAttribute("sessionName");
			//out.println("Welcome : "+userID);
     	%>
     	<div class="main"> 
     	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Instructions - Program 1 Test</p></center>
   		</div>
   		
   		 <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div> 
        <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form>  <br><br>
     	 
     
     	<div style="font-family:Calibri;font-size:16px;">
		<b style="font-size:20px;">Instructions :</b><br><br>

		
		1.Please read the instructions carefully. Once you "Start Test"", you cannot come back to this page. <br>
		2.Timer will start when you click "Start Test".<br>
		3.Questions are with multiple choice answers. Mark the correct answer. If a question has multiple correct answers, it will be indicated as part of the question.<br>
		4.While on the test page, do not click "F5" or "Refresh" the page. This will terminate your test.<br>
		5.Once you complete the test, please press "Submit".<br>
		6.You will be able to see the score at the bottom of the page.<br>
		7.You will also receive an email with the score.<br>
		8.Before you start the test, ensure you have a good network and power connection to your machine.<br><br>
		Good Luck!
		
		
		</div>
		<form action="Controller.jsp">
            <input type="hidden" name="page" value="exams">
            <input type="hidden" name="TestName" value="Program1">
            <input type="submit" value="Start Test">
        </form>
            
        <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;© 2020 FedEx Express EMEA		
		</div>
</body>
</html>