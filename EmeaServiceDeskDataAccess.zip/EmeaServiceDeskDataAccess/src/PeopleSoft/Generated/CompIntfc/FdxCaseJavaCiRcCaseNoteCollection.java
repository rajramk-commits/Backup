
//*****************************************************************
//* 
//* FdxCaseJavaCiRcCaseNoteCollection.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import psft.pt8.joa.*;

public class FdxCaseJavaCiRcCaseNoteCollection implements IFdxCaseJavaCiRcCaseNoteCollection 
  {
  public FdxCaseJavaCiRcCaseNoteCollection(IObject oThis) { m_oThis = oThis; }

  public long getCount() throws JOAException {
    return ((Long)m_oThis.getProperty("Count")).longValue();
 }

  public IFdxCaseJavaCiRcCaseNote item(long Index) throws JOAException {
    Object[] args = new Object[1];
    args[0] = new Long(Index);
    return (IFdxCaseJavaCiRcCaseNote)m_oThis.invokeMethod("Item", args);
    }

  public IFdxCaseJavaCiRcCaseNote insertItem(long Index) throws JOAException {
    Object[] args = new Object[1];
    args[0] = new Long(Index);
    return (IFdxCaseJavaCiRcCaseNote)m_oThis.invokeMethod("InsertItem", args);
    }

  public boolean deleteItem(long Index) throws JOAException {
    Object[] args = new Object[1];
    args[0] = new Long(Index);
    return ((Boolean)(m_oThis.invokeMethod("DeleteItem", args))).booleanValue();
    }

  public IFdxCaseJavaCiRcCaseNote itemByKeys() throws JOAException {
    Object[] args = new Object[0];
    return (IFdxCaseJavaCiRcCaseNote)m_oThis.invokeMethod("ItemByKeys", args);
    }

  public IFdxCaseJavaCiRcCaseNote currentItem() throws JOAException {
    Object[] args = new Object[0];
    return (IFdxCaseJavaCiRcCaseNote)m_oThis.invokeMethod("CurrentItem", args);
    }

  public long currentItemNum() throws JOAException {
    Object[] args = new Object[0];
    return ((Long)(m_oThis.invokeMethod("CurrentItemNum", args))).longValue();
    }

  public IFdxCaseJavaCiRcCaseNote getEffectiveItem(String Date, long SeqNum) throws JOAException {
    Object[] args = new Object[2];
    args[0] = Date;
    args[1] = new Long(SeqNum);
    return (IFdxCaseJavaCiRcCaseNote)m_oThis.invokeMethod("GetEffectiveItem", args);
    }

  public long getEffectiveItemNum(String Date, long SeqNum) throws JOAException {
    Object[] args = new Object[2];
    args[0] = Date;
    args[1] = new Long(SeqNum);
    return ((Long)(m_oThis.invokeMethod("GetEffectiveItemNum", args))).longValue();
    }

  IObject m_oThis;
  }
