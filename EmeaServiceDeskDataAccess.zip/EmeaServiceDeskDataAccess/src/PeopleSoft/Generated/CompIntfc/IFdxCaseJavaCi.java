
//*****************************************************************
//* 
//* FdxCaseJavaCi.java (generated)
//* 
//* Automatically generated at Thu May 19 10:36:51 2016
//* 
//* Copyright (c) 2000, 2011, Oracle and/or its affiliates. All rights reserved.
//****************************************************************


package PeopleSoft.Generated.CompIntfc;

import java.math.*;
import psft.pt8.joa.*;

public interface IFdxCaseJavaCi 
  {
  public String getBusinessUnit0() throws JOAException;
  public void setBusinessUnit0(String inBusinessUnit0) throws JOAException;
  public BigDecimal getCaseId() throws JOAException;
  public void setCaseId(BigDecimal inCaseId) throws JOAException;
  public String getDispTmplFamCd() throws JOAException;
  public void setDispTmplFamCd(String inDispTmplFamCd) throws JOAException;
  public String getCaseType() throws JOAException;
  public void setCaseType(String inCaseType) throws JOAException;
  public String getCaseContact() throws JOAException;
  public void setCaseContact(String inCaseContact) throws JOAException;
  public BigDecimal getBoIdCust() throws JOAException;
  public void setBoIdCust(BigDecimal inBoIdCust) throws JOAException;
  public BigDecimal getRoleTypeIdCust() throws JOAException;
  public void setRoleTypeIdCust(BigDecimal inRoleTypeIdCust) throws JOAException;
  public BigDecimal getBoIdReportedBy() throws JOAException;
  public void setBoIdReportedBy(BigDecimal inBoIdReportedBy) throws JOAException;
  public String getRcSource() throws JOAException;
  public void setRcSource(String inRcSource) throws JOAException;
  public String getProviderGrpId() throws JOAException;
  public void setProviderGrpId(String inProviderGrpId) throws JOAException;
  public String getAssignedTo() throws JOAException;
  public void setAssignedTo(String inAssignedTo) throws JOAException;
  public String getRcStatus() throws JOAException;
  public void setRcStatus(String inRcStatus) throws JOAException;
  public String getRcPriority() throws JOAException;
  public void setRcPriority(String inRcPriority) throws JOAException;
  public String getRcSeverity() throws JOAException;
  public void setRcSeverity(String inRcSeverity) throws JOAException;
  public String getRcCategory() throws JOAException;
  public void setRcCategory(String inRcCategory) throws JOAException;
  public String getRcType() throws JOAException;
  public void setRcType(String inRcType) throws JOAException;
  public String getRcDetail() throws JOAException;
  public void setRcDetail(String inRcDetail) throws JOAException;
  public String getRcSummary() throws JOAException;
  public void setRcSummary(String inRcSummary) throws JOAException;
  public String getRcCloseReasonCd() throws JOAException;
  public void setRcCloseReasonCd(String inRcCloseReasonCd) throws JOAException;
  public String getFdxActionTaken() throws JOAException;
  public void setFdxActionTaken(String inFdxActionTaken) throws JOAException;
  public String getFdxApplication() throws JOAException;
  public void setFdxApplication(String inFdxApplication) throws JOAException;
  public String getFdxBusImpact() throws JOAException;
  public void setFdxBusImpact(String inFdxBusImpact) throws JOAException;
  public String getFdxCause() throws JOAException;
  public void setFdxCause(String inFdxCause) throws JOAException;
  public String getFdxDocAvailable() throws JOAException;
  public void setFdxDocAvailable(String inFdxDocAvailable) throws JOAException;
  public String getFdxDocUseful() throws JOAException;
  public void setFdxDocUseful(String inFdxDocUseful) throws JOAException;
  public String getFdxEffEndDt() throws JOAException;
  public void setFdxEffEndDt(String inFdxEffEndDt) throws JOAException;
  public String getFdxEffEndTime() throws JOAException;
  public void setFdxEffEndTime(String inFdxEffEndTime) throws JOAException;
  public String getFdxEffStartDt() throws JOAException;
  public void setFdxEffStartDt(String inFdxEffStartDt) throws JOAException;
  public String getFdxEffStartTime() throws JOAException;
  public void setFdxEffStartTime(String inFdxEffStartTime) throws JOAException;
  public String getFdxFollowAction() throws JOAException;
  public void setFdxFollowAction(String inFdxFollowAction) throws JOAException;
  public String getFdxImpact() throws JOAException;
  public void setFdxImpact(String inFdxImpact) throws JOAException;
  public String getFdxKiReference() throws JOAException;
  public void setFdxKiReference(String inFdxKiReference) throws JOAException;
  public String getFdxNode() throws JOAException;
  public void setFdxNode(String inFdxNode) throws JOAException;
  public String getFdxGrouping() throws JOAException;
  public void setFdxGrouping(String inFdxGrouping) throws JOAException;
  public String getFdxProblemDetail() throws JOAException;
  public void setFdxProblemDetail(String inFdxProblemDetail) throws JOAException;
  public String getFdxSystem() throws JOAException;
  public void setFdxSystem(String inFdxSystem) throws JOAException;
  public String getFdxVendor() throws JOAException;
  public void setFdxVendor(String inFdxVendor) throws JOAException;
  public String getFdxVendId() throws JOAException;
  public void setFdxVendId(String inFdxVendId) throws JOAException;
  public String getRcDescrlong() throws JOAException;
  public void setRcDescrlong(String inRcDescrlong) throws JOAException;
  public IFdxCaseJavaCiRcCaseNoteCollection getRcCaseNote() throws JOAException;
  public String getBusinessUnit() throws JOAException;
  public void setBusinessUnit(String inBusinessUnit) throws JOAException;
  public boolean getInteractiveMode() throws JOAException;
  public void setInteractiveMode(boolean inInteractiveMode) throws JOAException;
  public boolean getGetHistoryItems() throws JOAException;
  public void setGetHistoryItems(boolean inGetHistoryItems) throws JOAException;
  public boolean getEditHistoryItems() throws JOAException;
  public void setEditHistoryItems(boolean inEditHistoryItems) throws JOAException;
  public String getComponentName() throws JOAException;
  public String getCompIntfcName() throws JOAException;
  public String getMarket() throws JOAException;
  public String getDescription() throws JOAException;
  public boolean getGetDummyRows() throws JOAException;
  public void setGetDummyRows(boolean inGetDummyRows) throws JOAException;
  public boolean getStopOnFirstError() throws JOAException;
  public void setStopOnFirstError(boolean inStopOnFirstError) throws JOAException;
  public ICompIntfcPropertyInfoCollection getPropertyInfoCollection() throws JOAException;
  public ICompIntfcPropertyInfoCollection getCreateKeyInfoCollection() throws JOAException;
  public ICompIntfcPropertyInfoCollection getGetKeyInfoCollection() throws JOAException;
  public ICompIntfcPropertyInfoCollection getFindKeyInfoCollection() throws JOAException;
  public boolean get() throws JOAException;
  public boolean create() throws JOAException;
  public boolean save() throws JOAException;
  public boolean cancel() throws JOAException;
  public IFdxCaseJavaCiCollection find() throws JOAException;
  public Object getPropertyByName(String Name) throws JOAException;
  public long setPropertyByName(String Name, Object Value) throws JOAException;
  public ICompIntfcPropertyInfo getPropertyInfoByName(String Name) throws JOAException;
  public long loadNotes() throws JOAException;
  }
