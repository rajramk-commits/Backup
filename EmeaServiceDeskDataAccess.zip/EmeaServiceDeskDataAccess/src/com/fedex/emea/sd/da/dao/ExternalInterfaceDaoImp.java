package com.fedex.emea.sd.da.dao;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.ExternalInterfaceRowMapper;
import com.fedex.emea.sd.da.objects.ExternalInterface;

public class ExternalInterfaceDaoImp implements ExternalInterfaceDao {
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public int countAll() throws SQLException {
		String sql = "SELECT count(*) FROM External_Interface";
        int allRows = 0;
        jdbcTemplate.queryForInt(sql);
        return allRows;
	}
	
	// ************************************************************************************
	//                                      CREATE
	// ************************************************************************************

	public void createFromDashboard(ExternalInterface valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO External_Interface ( ALERTID, RECORDSOURCE, RECORDSOURCEID, CASESUMMARY, CASEDESCRIPTION1, CASEDESCRIPTION2, CASEDESCRIPTION3, CASEDESCRIPTION4, CASEDESCRIPTION5, CASEDESCRIPTION6, CASEDESCRIPTION7, CASEDESCRIPTION8, CASEDESCRIPTION9) " +
		               "VALUES (SEQ_ALERTID.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getRecordSource(), valueObject.getRecordSourceId(), valueObject.getCaseSummary(), valueObject.getCaseDescription1(), valueObject.getCaseDescription2(), valueObject.getCaseDescription3(), valueObject.getCaseDescription4(), valueObject.getCaseDescription5(), valueObject.getCaseDescription6(), valueObject.getCaseDescription7(), valueObject.getCaseDescription8(), valueObject.getCaseDescription9()});
	}
	
	public void create(ExternalInterface valueObject) throws SQLException, DataAccessException, IOException {
		String sql = "INSERT INTO External_Interface ( ALERTID, RECORDSOURCE, RECORDSOURCEID, NEXUSCASEOBJECT, CASEBUSINESSUNIT, CASELOCATION, CASEORIGINPIN, CASESUMMARY, CASEDESCRIPTION1, CASEDESCRIPTION2, CASEDESCRIPTION3, CASEDESCRIPTION4, CASEDESCRIPTION5, CASEDESCRIPTION6, CASEDESCRIPTION7, CASEDESCRIPTION8, CASEDESCRIPTION9, CASETYPE, CASEPRIORITY, CASESTATUS, CASESEVERITY, CASESOURCE, CASEPROVIDERGROUP, CASEOWNERSHIP, CASECATEGORY, CASECALLTYPE, CASEPROBLEMTYPE, CASEPROBLEMDETAIL, CASEPROBLEMDESCRIPTION, CASEFDXNODE, CASEFDXVENDOR, CASEFDXVENDORID, CASEFDXSYSTEM, CASEFDXAPPLICATION, CASEASSIGNEDTO, CASESOLUTION, ALERTPROCESSED, PROCESSEDTIME, CREATIONTIME, CASEID, CASESYSID) " +
		               "VALUES (SEQ_ALERTID.NEXTVAL ,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getRecordSource(), valueObject.getRecordSourceId(), valueObject.getNexusCase(), valueObject.getCaseBusinessUnit(), valueObject.getCaseLocation(), valueObject.getCaseOriginPin(), valueObject.getCaseSummary(), valueObject.getCaseDescription1(), valueObject.getCaseDescription2(), valueObject.getCaseDescription3(), valueObject.getCaseDescription4(), valueObject.getCaseDescription5(), valueObject.getCaseDescription6(), valueObject.getCaseDescription7(), valueObject.getCaseDescription8(), valueObject.getCaseDescription9(), valueObject.getCaseType(), valueObject.getCasePriority(), valueObject.getCaseStatus(), valueObject.getCaseSeverity(), valueObject.getCaseSource(), valueObject.getCaseProviderGroup(), valueObject.getCaseOwnership(), valueObject.getCaseCategory(), valueObject.getCaseCallType(), valueObject.getCaseProblemType(), valueObject.getCaseProblemDetail(), valueObject.getCaseProblemDescription(), valueObject.getCaseFdxNode(), valueObject.getCaseFdxVendor(), valueObject.getCaseFdxVendorId(), valueObject.getCaseFdxSystem(), valueObject.getCaseFdxApplication(), valueObject.getCaseAssignedTo(), valueObject.getCaseSolution(), valueObject.getAlertProcessed(), valueObject.getProcessedTime(), valueObject.getCreationTime(), valueObject.getCaseId(), valueObject.getCaseSysId()});
	}

	public ExternalInterface createValueObject() {
		return new ExternalInterface();
	}
	
	// ************************************************************************************
	//                                      DELETE
	// ************************************************************************************
	
	public void deleteOlderThan(Timestamp limitDate) throws SQLException {
		String sql = "DELETE FROM External_Interface EI where EI.CREATIONTIME < ?";
		jdbcTemplate.update(sql, new Object[] {limitDate});
	}

	public void delete(ExternalInterface valueObject) throws SQLException {
		String sql = "DELETE FROM External_Interface WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertId()});
	}

	public void deleteAll() throws SQLException {
		String sql = "DELETE FROM External_Interface";
		jdbcTemplate.update(sql);
	}
	
	// ************************************************************************************
	//                                      GET / LOAD
	// ************************************************************************************
	
	public ExternalInterface getObjectByRecordSourceId(String recordSourceId) throws SQLException {
		ExternalInterface valueObject = createValueObject();
		String sql = "SELECT * FROM External_Interface WHERE (RECORDSOURCEID = ? AND ALERTPROCESSED = '1') ";
		valueObject = (ExternalInterface) jdbcTemplate.queryForObject(sql, new Object[] {recordSourceId}, new ExternalInterfaceRowMapper());
		return valueObject;
	}

	public ExternalInterface getObject(int alertId) throws SQLException {
		ExternalInterface valueObject = createValueObject();
		String sql = "SELECT * FROM External_Interface WHERE (ALERTID = ? ) ";
		valueObject = (ExternalInterface) jdbcTemplate.queryForObject(sql, new Object[] {alertId}, new ExternalInterfaceRowMapper());
		return valueObject;
	}

	@SuppressWarnings("unchecked")
	public List<ExternalInterface> loadAll() throws SQLException {
		String sql = "SELECT * FROM External_Interface ORDER BY ALERTID ASC ";
		return jdbcTemplate.query(sql, new ExternalInterfaceRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<ExternalInterface> loadNotProcessed() throws SQLException {
//		String sql = "SELECT * FROM External_Interface WHERE ALERTPROCESSED='0' ORDER BY ALERTID ASC ";
		// To re-process errors (9) created less than 20 minutes ago.
		 String sql = "SELECT * FROM External_Interface WHERE ALERTPROCESSED='0' OR (ALERTPROCESSED='9' AND CURRENT_TIMESTAMP - CREATIONTIME < interval '20' minute) ORDER BY ALERTID ASC ";

		return jdbcTemplate.query(sql, new ExternalInterfaceRowMapper());
	}
	
	@SuppressWarnings("unchecked")
	public List<ExternalInterface> loadOnlyDashboard() throws SQLException {
		String sql = "SELECT * FROM External_Interface WHERE ALERTPROCESSED='3' ORDER BY ALERTID ASC ";
		return jdbcTemplate.query(sql, new ExternalInterfaceRowMapper());
	}
	
	// ************************************************************************************
	//                                      UPDATE
	// ************************************************************************************
	
	public void updateRecordStatus(ExternalInterface valueObject) throws SQLException {
		String sql = "UPDATE External_Interface SET ALERTPROCESSED = ?, PROCESSEDTIME = ? WHERE ALERTID = ?";
		jdbcTemplate.update(sql, new Object[] {valueObject.getAlertProcessed(), new Timestamp(Calendar.getInstance().getTimeInMillis()), valueObject.getAlertId()});
	}
	
	public void updateCaseId(ExternalInterface valueObject) throws SQLException {
		String sql = "UPDATE External_Interface SET CASEID = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getCaseId(), valueObject.getAlertId()});
	}
	
	public void updateSysIdAndIncidentNumber(ExternalInterface valueObject) throws SQLException {
		String sql = "UPDATE External_Interface SET CASEID = ?, CASESYSID = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getCaseId(), valueObject.getCaseSysId(), valueObject.getAlertId()});
	}
	
	public void updatePriorityStatusGroup(ExternalInterface valueObject) throws SQLException {
		String sql = "UPDATE External_Interface SET CASEPRIORITY = ?, CASESTATUS = ?, CASEPROVIDERGROUP = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getCasePriority(), valueObject.getCaseStatus(), valueObject.getCaseProviderGroup(), valueObject.getAlertId()});
	}
	
	public void updateAddNoteToNew(ExternalInterface valueObject) throws SQLException {
		String sql = "UPDATE External_Interface SET RECORDSOURCE = ?, CASESUMMARY = ?, CASEID = ?, CASESYSID = ?, PROCESSEDTIME = ? WHERE (ALERTID = ? ) ";
		jdbcTemplate.update(sql, new Object[] {valueObject.getRecordSource(), valueObject.getCaseSummary(), valueObject.getCaseId(), valueObject.getCaseSysId(), valueObject.getProcessedTime(), valueObject.getAlertId()});
	}
}
