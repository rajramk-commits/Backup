package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.fedex.emea.sd.da.objects.DashboardAlerts;

public class DashboardAlertsRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		DashboardAlerts dashboardAlert = new DashboardAlerts();

		dashboardAlert.setAlertId(rs.getString("ID"));
		dashboardAlert.setImpactedServer(rs.getString("SERVER"));
		dashboardAlert.setImpactedComponent(rs.getString("COMPONENT"));
		dashboardAlert.setImpactedApplication(rs.getString("APPLICATION"));
		dashboardAlert.setImpactedModule(rs.getString("MODULE"));
		dashboardAlert.setCreationTime(rs.getTimestamp("CREATIONTIME"));
		dashboardAlert.setNexusCaseId(rs.getString("NEXUSCASEID"));
		dashboardAlert.setNiAlertId(rs.getString("ALERTID"));
		
		return dashboardAlert;
	}

}
