package com.fedex.emea.sabreReport.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fedex.emea.sabreReport.model.SabreBean;

public class ProcessGSSUtil {
	public static Map<String, Integer> getAllTypeData(List<SabreBean> gssData)
	{
		Map<String, Integer> alltypeAlertData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			// All type alerts Graphs
			for(int i=0; i< gssData.size();i++)
			{
				String alert = gssData.get(i).getAlertType();
				if(alltypeAlertData.containsKey(alert))
				{
					alltypeAlertData.put(alert, alltypeAlertData.get(alert)+1);
				}
				else
				{
					alltypeAlertData.put(alert, 1);
				}
			}
			alltypeAlertData = GraphUtil.sortByValue(alltypeAlertData);
			System.out.println("alltypeAlertData Save:"+alltypeAlertData);
		}
		return alltypeAlertData;
	  }
	public static Map<String, Integer> getCGNData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeCGNData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			//Alerts on CGN
					for(int i=0; i< gssData.size();i++)
					{
						String loc = gssData.get(i).getLocation();
						if(loc.equalsIgnoreCase("DE-CGN"))
						{
							String alert = gssData.get(i).getAlertType();
							if(alertTypeCGNData.containsKey(alert))
							{
								alertTypeCGNData.put(alert, alertTypeCGNData.get(alert)+1);
							}
							else
							{
								alertTypeCGNData.put(alert, 1);
							}
						}
					}
					alertTypeCGNData = GraphUtil.sortByValue(alertTypeCGNData);
					System.out.println("alertTypeCGNData save:"+alertTypeCGNData);
		}
		return alertTypeCGNData;
	  }
	public static Map<String, Integer> getCPHData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeCPHData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			///Alerts on CPH
			for(int i=0; i< gssData.size();i++)
			{
				String loc = gssData.get(i).getLocation();
				if(loc.equalsIgnoreCase("DK-CPH"))
				{
					String alert = gssData.get(i).getAlertType();
					if(alertTypeCPHData.containsKey(alert))
					{
						alertTypeCPHData.put(alert, alertTypeCPHData.get(alert)+1);
					}
					else
					{
						alertTypeCPHData.put(alert, 1);
					}
				}
			}
			alertTypeCPHData = GraphUtil.sortByValue(alertTypeCPHData);
			System.out.println("alertTypeCPHData save:"+alertTypeCPHData);
		}
		return alertTypeCPHData;
	  }
	public static Map<String, Integer> getCDGData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeCDGData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			//Alerts on CDG
					for(int i=0; i< gssData.size();i++)
					{
						String loc = gssData.get(i).getLocation();
						if(loc.equalsIgnoreCase("FR-CDG"))
						{
							String alert = gssData.get(i).getAlertType();
							if(alertTypeCDGData.containsKey(alert))
							{
								alertTypeCDGData.put(alert, alertTypeCDGData.get(alert)+1);
							}
							else
							{
								alertTypeCDGData.put(alert, 1);
							}
						}
					}
					alertTypeCDGData = GraphUtil.sortByValue(alertTypeCDGData);
					System.out.println("alertTypeCDGData save:"+alertTypeCDGData);
		}
		return alertTypeCDGData;
	  }
	public static Map<String, Integer> getMXPData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeMXPData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			for(int i=0; i< gssData.size();i++)
			{
				String loc = gssData.get(i).getLocation();
				if(loc.equalsIgnoreCase("IT-MXP"))
				{
					String alert = gssData.get(i).getAlertType();
					if(alertTypeMXPData.containsKey(alert))
					{
						alertTypeMXPData.put(alert, alertTypeMXPData.get(alert)+1);
					}
					else
					{
						alertTypeMXPData.put(alert, 1);
					}
				}
			}
			alertTypeMXPData = GraphUtil.sortByValue(alertTypeMXPData);
			System.out.println("alertTypeMXPData save:"+alertTypeMXPData);
		}
		return alertTypeMXPData;
	  }
	public static Map<String, Integer> getDXBData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeDXBData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			///Alerts on DXB
			for(int i=0; i< gssData.size();i++)
			{
				String loc = gssData.get(i).getLocation();
				if(loc.equalsIgnoreCase("AE-DXB"))
				{
					String alert = gssData.get(i).getAlertType();
					if(alertTypeDXBData.containsKey(alert))
					{
						alertTypeDXBData.put(alert, alertTypeDXBData.get(alert)+1);
					}
					else
					{
						alertTypeDXBData.put(alert, 1);
					}
				}
			}
			alertTypeDXBData = GraphUtil.sortByValue(alertTypeDXBData);
			System.out.println("alertTypeDXBData save:"+alertTypeDXBData);
		}
		return alertTypeDXBData;
	  }
	public static Map<String, Integer> getSTNData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeSTNData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			//Alerts on STN
					for(int i=0; i< gssData.size();i++)
					{
						String loc = gssData.get(i).getLocation();
						if(loc.equalsIgnoreCase("GB-STN"))
						{
							String alert = gssData.get(i).getAlertType();
							if(alertTypeSTNData.containsKey(alert))
							{
								alertTypeSTNData.put(alert, alertTypeSTNData.get(alert)+1);
							}
							else
							{
								alertTypeSTNData.put(alert, 1);
							}
						}
					}
					alertTypeSTNData = GraphUtil.sortByValue(alertTypeSTNData);
					System.out.println("alertTypeSTNData jsp:"+alertTypeSTNData);
		}
		return alertTypeSTNData;
	  }
	public static Map<String, Integer> getERRORData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeERRORData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			// ERROR_LOG Alerts
					for(int i=0; i< gssData.size();i++)
					{
						String comments = gssData.get(i).getComments();
						if(comments.equalsIgnoreCase("ERROR_LOG"))
						{
							String loc = gssData.get(i).getLocation();
							if(alertTypeERRORData.containsKey(loc))
							{
								alertTypeERRORData.put(loc, alertTypeERRORData.get(loc)+1);
							}
							else
							{
								alertTypeERRORData.put(loc, 1);
							}
						}
					}
					alertTypeERRORData = GraphUtil.sortByValue(alertTypeERRORData);
					System.out.println("alertTypeERRORData jsp:"+alertTypeERRORData);
		}
		return alertTypeERRORData;
	  }
	public static Map<String, Integer> getJMSData(List<SabreBean> gssData)
	{
		Map<String, Integer> alertTypeJMSData = new HashMap<>();
		if(gssData != null && gssData.size() != 0)
		{
			// JMS TRENDS Alerts
			for(int i=0; i< gssData.size();i++)
			{
				String alert = gssData.get(i).getAlertType();
				if(alert.equalsIgnoreCase("JMS_Queue"))
				{
					String desc = gssData.get(i).getShortDescr();
					int sInd = desc.indexOf("Module[")+24;
					int eInd = desc.indexOf("]", sInd);
					String module= desc.substring(sInd, eInd);
					if(alertTypeJMSData.containsKey(module))
					{
						alertTypeJMSData.put(module, alertTypeJMSData.get(module)+1);
					}
					else
					{
						alertTypeJMSData.put(module, 1);
					}
				}
			}
			alertTypeJMSData = GraphUtil.sortByValue(alertTypeJMSData);
			System.out.println("alertTypeJMSData jsp:"+alertTypeJMSData);
		}
		return alertTypeJMSData;
	  }
}
