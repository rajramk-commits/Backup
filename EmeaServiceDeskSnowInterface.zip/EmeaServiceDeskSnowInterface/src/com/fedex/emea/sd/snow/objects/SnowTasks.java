package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowTasks implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowActive;
	private String snowActivityDue;
	private String snowAdditionalAssigneeList;
	private String snowApproval;
	private String snowApprovalHistory;
	private String snowApprovalSet;
	private String snowAssignedTo;
	private String snowAssignmentGroup;
	private String snowBusinessDuration;
	private String snowBusinessService;
	private String snowCalendarDuration;
	private String snowCallerId;
	private String snowCategory;
	private String snowCloseCode;
	private String snowCloseNotes;
	private String snowClosedAt;
	private String snowClosedBy;
	private String snowCmdbCi;
	private String snowComments;
	private String snowCompany;
	private String snowContactType;
	private String snowContract;
	private String snowCorrelationDisplay;
	private String snowCorrelationId;
	private String snowDeliveryPlan;
	private String snowDescription;
	private String snowDueDate;
	private String snowEffort;
	private String snowEndDate;
	private String snowEscalation;
	private String snowExpectedStart;
	private String snowFollowUp;
	private String snowGroupList;
	private String snowImpact;
	private String snowKnowledge;
	private String snowLocation;
	private String snowMadeSla;
	private String snowNotify;
	private String snowNumber;
	private String snowOpenedAt;
	private String snowOpenedBy;
	private String snowOrder;
	private String snowParent;
	private String snowPriority;
	private String snowReassignmentCount;
	private String snowRfc;
	private String snowShortDescription;
	private String snowSkills;
	private String snowSlaDue;
	private String snowStartDate;
	private String snowState;
	private String snowStatus;
	private String snowSubcategory;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysDomain;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowTimeWorked;
	private String snowU_3RdLineSrt;
	private String snowU_AcknowldgeFeedback;
	private String snowU_Acknowledged;
	private String snowU_ActiveProbInc;
	private String snowU_ActualEffort;
	private String snowU_ActualStart;
	private String snowU_AffectedAsset;
	private String snowU_AffectedUser;
	private String snowU_AofDateTime;
	private String snowU_AofState;
	private String snowU_AofWorkgroup;
	private String snowU_AosDateTime;
	private String snowU_AosState;
	private String snowU_AosWorkgroup;
	private String snowU_AssetCode;
	private String snowU_AssetString;
	private String snowU_AssignedToBladelogic;
	private String snowU_AssignmentStatus;
	private String snowU_AttachmentsAdded;
	private String snowU_AuditCode;
	private String snowU_AutoClose;
	private String snowU_AutoCloseTicket;
	private String snowU_AutoParm1;
	private String snowU_AutoParm2;
	private String snowU_AutoParm3;
	private String snowU_AutoParm4;
	private String snowU_AutoParm5;
	private String snowU_AutoTarget;
	private String snowU_AutoType;
	private String snowU_AvailAddComments;
	private String snowU_AvailTechSvc;
	private String snowU_AvailabilityReport;
	private String snowU_BsdResolutionBy;
	private String snowU_BusinessService;
	private String snowU_CallCaptureComments;
	private String snowU_CallHandlingComments;
	private String snowU_CauseItem;
	private String snowU_CausedBy;
	private String snowU_ChangeManager;
	private String snowU_Classification;
	private String snowU_ClosedPeriod;
	private String snowU_ClosureCategory;
	private String snowU_CommentType;
	private String snowU_CommentTypeHandling;
	private String snowU_CommentsAndWorkNotes;
	private String snowU_DesktopAssetNumber;
	private String snowU_DesktopMake;
	private String snowU_DesktopModel;
	private String snowU_DesktopSN;
	private String snowU_Escalated;
	private String snowU_ExpertHelp;
	private String snowU_ExternalRef;
	private String snowU_FeedbackCode;
	private String snowU_FeedbackCodeHandling;
	private String snowU_FirstDeadline;
	private String snowU_Folder;
	private String snowU_ImpBreakdown;
	private String snowU_InitialAssignment;
	private String snowU_Instructions;
	private String snowU_InternalRef;
	private String snowU_ItilWatchList;
	private String snowU_KnowledgeArticle;
	private String snowU_KnowledgeAvailable;
	private String snowU_KnowledgeCode;
	private String snowU_KnowledgeComments;
	private String snowU_KnowledgeFound;
	private String snowU_KnowledgeUser;
	private String snowU_LastOccurrence;
	private String snowU_LateImpReason;
	private String snowU_LocalResp;
	private String snowU_ManagementAuditComments;
	private String snowU_ManagementComments;
	private String snowU_ModifiedPeriod;
	private String snowU_OpenedPeriod;
	private String snowU_OutageDuration;
	private String snowU_OutsourceAssignedOut;
	private String snowU_OutsourceAssignee;
	private String snowU_OutsourceId;
	private String snowU_OutsourceIntegration;
	private String snowU_OutsourceModule;
	private String snowU_OutsourceResponse;
	private String snowU_OutsourceResult;
	private String snowU_OutsourceStatus;
	private String snowU_OutsourceTeam;
	private String snowU_Override1;
	private String snowU_Person;
	private String snowU_PersonAudited;
	private String snowU_PersonAuditing;
	private String snowU_Phone;
	private String snowU_PickupDuration;
	private String snowU_PlannedEffort;
	private String snowU_PlannedImplementationWeek;
	private String snowU_PreviousGroup;
	private String snowU_QueryCount;
	private String snowU_RegionImpacted;
	private String snowU_RelatedIncidents;
	private String snowU_ReopenCount;
	private String snowU_ReopenedDate;
	private String snowU_ResolutionOverride;
	private String snowU_ResolvedBy;
	private String snowU_ResolvedByWorkgroup;
	private String snowU_Resolver;
	private String snowU_ResponseFlag;
	private String snowU_ResponseOverride;
	private String snowU_SavedCount;
	private String snowU_SecondDeadline;
	private String snowU_SelectApplication;
	private String snowU_SelectEuc;
	private String snowU_SelectInfrastructure;
	private String snowU_SelectNetwork;
	private String snowU_SlaFailureWorkgroup;
	private String snowU_SlaState;
	private String snowU_SlfApprover;
	private String snowU_SlfComponent;
	private String snowU_SlfReason;
	private String snowU_SlfReviewDate;
	private String snowU_SrtState;
	private String snowU_SspForm;
	private String snowU_Subject;
	private String snowU_SupportStructure;
	private String snowU_TaskType;
	private String snowU_Template;
	private String snowU_ThirdLineComments;
	private String snowU_ThirdLineDate;
	private String snowU_TimeToAuth;
	private String snowU_TimeToClose;
	private String snowU_UsersAffected;
	private String snowU_WebUpdate;
	private String snowUponApproval;
	private String snowUponReject;
	private String snowUrgency;
	private String snowUserInput;
	private String snowWatchList;
	private String snowWfActivity;
	private String snowWorkEffort;
	private String snowWorkEnd;
	private String snowWorkNotes;
	private String snowWorkStart;
	
	private Date dtSnowU_PickupDuration;
	private Date dtSnowBusinessDuration;
	private Date dtSnowCalendarDuration;
	private Date dtSnowU_TimeToClose;
	private Date dtSnowSysCreatedOn;
	private Date dtSnowOpenedAt;
	private Date dtSnowSlaDue;
	private Date dtSnowU_ActualStart;
	private Date dtSnowClosedAt;
	private Date dtSnowU_AofDateTime;
	private Date dtSnowU_AosDateTime;
	
	public SnowTasks() {
	}
	
	public SnowTasks(HashMap<String, Object> jsonValues) {
		snowActive = SnowUtilities.getStringValueFromObject(jsonValues.get("active"));
		snowActivityDue = SnowUtilities.getStringValueFromObject(jsonValues.get("activity_due"));
		snowAdditionalAssigneeList = SnowUtilities.getStringValueFromObject(jsonValues.get("additional_assignee_list"));
		snowApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("approval"));
		snowApprovalHistory = SnowUtilities.getStringValueFromObject(jsonValues.get("approval_history"));
		snowApprovalSet = SnowUtilities.getStringValueFromObject(jsonValues.get("approval_set"));
		snowAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("assigned_to"));
		snowAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("assignment_group"));
		snowBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("business_duration"));
		snowBusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("business_service"));
		snowCalendarDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("calendar_duration"));
		snowCallerId = SnowUtilities.getStringValueFromObject(jsonValues.get("caller_id"));
		snowCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("category"));
		snowCloseCode = SnowUtilities.getStringValueFromObject(jsonValues.get("close_code"));
		snowCloseNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("close_notes"));
		snowClosedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("closed_at"));
		snowClosedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("closed_by"));
		snowCmdbCi = SnowUtilities.getStringValueFromObject(jsonValues.get("cmdb_ci"));
		snowComments = SnowUtilities.getStringValueFromObject(jsonValues.get("comments"));
		snowCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("company"));
		snowContactType = SnowUtilities.getStringValueFromObject(jsonValues.get("contact_type"));
		snowContract = SnowUtilities.getStringValueFromObject(jsonValues.get("contract"));
		snowCorrelationDisplay = SnowUtilities.getStringValueFromObject(jsonValues.get("correlation_display"));
		snowCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("correlation_id"));
		snowDeliveryPlan = SnowUtilities.getStringValueFromObject(jsonValues.get("delivery_plan"));
		snowDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("description"));
		snowDueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("due_date"));
		snowEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("effort"));
		snowEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("end_date"));
		snowEscalation = SnowUtilities.getStringValueFromObject(jsonValues.get("escalation"));
		snowExpectedStart = SnowUtilities.getStringValueFromObject(jsonValues.get("expected_start"));
		snowFollowUp = SnowUtilities.getStringValueFromObject(jsonValues.get("follow_up"));
		snowGroupList = SnowUtilities.getStringValueFromObject(jsonValues.get("group_list"));
		snowImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("impact"));
		snowKnowledge = SnowUtilities.getStringValueFromObject(jsonValues.get("knowledge"));
		snowLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("location"));
		snowMadeSla = SnowUtilities.getStringValueFromObject(jsonValues.get("made_sla"));
		snowNotify = SnowUtilities.getStringValueFromObject(jsonValues.get("notify"));
		snowNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("number"));
		snowOpenedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("opened_at"));
		snowOpenedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("opened_by"));
		snowOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("order"));
		snowParent = SnowUtilities.getStringValueFromObject(jsonValues.get("parent"));
		snowPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("priority"));
		snowReassignmentCount = SnowUtilities.getStringValueFromObject(jsonValues.get("reassignment_count"));
		snowRfc = SnowUtilities.getStringValueFromObject(jsonValues.get("rfc"));
		snowShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("short_description"));
		snowSkills = SnowUtilities.getStringValueFromObject(jsonValues.get("skills"));
		snowSlaDue = SnowUtilities.getStringValueFromObject(jsonValues.get("sla_due"));
		snowStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("start_date"));
		snowState = SnowUtilities.getStringValueFromObject(jsonValues.get("state"));
		snowStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("status"));
		snowSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("subcategory"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_domain"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowTimeWorked = SnowUtilities.getStringValueFromObject(jsonValues.get("time_worked"));
		snowU_3RdLineSrt = SnowUtilities.getStringValueFromObject(jsonValues.get("u_3rd_line_srt"));
		snowU_AcknowldgeFeedback = SnowUtilities.getStringValueFromObject(jsonValues.get("u_acknowldge_feedback"));
		snowU_Acknowledged = SnowUtilities.getStringValueFromObject(jsonValues.get("u_acknowledged"));
		snowU_ActiveProbInc = SnowUtilities.getStringValueFromObject(jsonValues.get("u_active_prob_inc"));
		snowU_ActualEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("u_actual_effort"));
		snowU_ActualStart = SnowUtilities.getStringValueFromObject(jsonValues.get("u_actual_start"));
		snowU_AffectedAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("u_affected_asset"));
		snowU_AffectedUser = SnowUtilities.getStringValueFromObject(jsonValues.get("u_affected_user"));
		snowU_AofDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aof_date__time"));
		snowU_AofState = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aof_state"));
		snowU_AofWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aof_workgroup"));
		snowU_AosDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aos_date__time"));
		snowU_AosState = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aos_state"));
		snowU_AosWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_aos_workgroup"));
		snowU_AssetCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_asset_code"));
		snowU_AssetString = SnowUtilities.getStringValueFromObject(jsonValues.get("u_asset_string"));
		snowU_AssignedToBladelogic = SnowUtilities.getStringValueFromObject(jsonValues.get("u_assigned_to_bladelogic"));
		snowU_AssignmentStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_assignment_status"));
		snowU_AttachmentsAdded = SnowUtilities.getStringValueFromObject(jsonValues.get("u_attachments_added"));
		snowU_AuditCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_audit__code"));
		snowU_AutoClose = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_close"));
		snowU_AutoCloseTicket = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_close_ticket"));
		snowU_AutoParm1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_parm1"));
		snowU_AutoParm2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_parm2"));
		snowU_AutoParm3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_parm3"));
		snowU_AutoParm4 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_parm4"));
		snowU_AutoParm5 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_parm5"));
		snowU_AutoTarget = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_target"));
		snowU_AutoType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_auto_type"));
		snowU_AvailAddComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_avail_add_comments"));
		snowU_AvailTechSvc = SnowUtilities.getStringValueFromObject(jsonValues.get("u_avail_tech_svc"));
		snowU_AvailabilityReport = SnowUtilities.getStringValueFromObject(jsonValues.get("u_availability_report"));
		snowU_BsdResolutionBy = SnowUtilities.getStringValueFromObject(jsonValues.get("u_bsd_resolution_by"));
		snowU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_service"));
		snowU_CallCaptureComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_call_capture_comments"));
		snowU_CallHandlingComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_call_handling_comments"));
		snowU_CauseItem = SnowUtilities.getStringValueFromObject(jsonValues.get("u_cause_item"));
		snowU_CausedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("u_caused_by"));
		snowU_ChangeManager = SnowUtilities.getStringValueFromObject(jsonValues.get("u_change_manager"));
		snowU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("u_classification"));
		snowU_ClosedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("u_closed_period"));
		snowU_ClosureCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_closure_category"));
		snowU_CommentType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_comment_type"));
		snowU_CommentTypeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("u_comment_type_handling"));
		snowU_CommentsAndWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("u_comments_and_work_notes"));
		snowU_DesktopAssetNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("u_desktop_asset_number"));
		snowU_DesktopMake = SnowUtilities.getStringValueFromObject(jsonValues.get("u_desktop_make"));
		snowU_DesktopModel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_desktop_model"));
		snowU_DesktopSN = SnowUtilities.getStringValueFromObject(jsonValues.get("u_desktop_s_n"));
		snowU_Escalated = SnowUtilities.getStringValueFromObject(jsonValues.get("u_escalated"));
		snowU_ExpertHelp = SnowUtilities.getStringValueFromObject(jsonValues.get("u_expert_help"));
		snowU_ExternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("u_external_ref"));
		snowU_FeedbackCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_feedback_code"));
		snowU_FeedbackCodeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("u_feedback_code_handling"));
		snowU_FirstDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("u_first_deadline"));
		snowU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("u_folder"));
		snowU_ImpBreakdown = SnowUtilities.getStringValueFromObject(jsonValues.get("u_imp_breakdown"));
		snowU_InitialAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("u_initial_assignment"));
		snowU_Instructions = SnowUtilities.getStringValueFromObject(jsonValues.get("u_instructions"));
		snowU_InternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("u_internal_ref"));
		snowU_ItilWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("u_itil_watch_list"));
		snowU_KnowledgeArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_article"));
		snowU_KnowledgeAvailable = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_available"));
		snowU_KnowledgeCode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_code"));
		snowU_KnowledgeComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_comments"));
		snowU_KnowledgeFound = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_found"));
		snowU_KnowledgeUser = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_user"));
		snowU_LastOccurrence = SnowUtilities.getStringValueFromObject(jsonValues.get("u_last_occurrence"));
		snowU_LateImpReason = SnowUtilities.getStringValueFromObject(jsonValues.get("u_late_imp_reason"));
		snowU_LocalResp = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_resp"));
		snowU_ManagementAuditComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_management_audit_comments"));
		snowU_ManagementComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_management_comments"));
		snowU_ModifiedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("u_modified_period"));
		snowU_OpenedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("u_opened_period"));
		snowU_OutageDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outage_duration"));
		snowU_OutsourceAssignedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_assigned_out"));
		snowU_OutsourceAssignee = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_assignee"));
		snowU_OutsourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_id"));
		snowU_OutsourceIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_integration"));
		snowU_OutsourceModule = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_module"));
		snowU_OutsourceResponse = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_response"));
		snowU_OutsourceResult = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_result"));
		snowU_OutsourceStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_status"));
		snowU_OutsourceTeam = SnowUtilities.getStringValueFromObject(jsonValues.get("u_outsource_team"));
		snowU_Override1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_override1"));
		snowU_Person = SnowUtilities.getStringValueFromObject(jsonValues.get("u_person"));
		snowU_PersonAudited = SnowUtilities.getStringValueFromObject(jsonValues.get("u_person_audited"));
		snowU_PersonAuditing = SnowUtilities.getStringValueFromObject(jsonValues.get("u_person_auditing"));
		snowU_Phone = SnowUtilities.getStringValueFromObject(jsonValues.get("u_phone"));
		snowU_PickupDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("u_pickup_duration"));
		snowU_PlannedEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("u_planned_effort"));
		snowU_PlannedImplementationWeek = SnowUtilities.getStringValueFromObject(jsonValues.get("u_planned_implementation_week"));
		snowU_PreviousGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_previous_group"));
		snowU_QueryCount = SnowUtilities.getStringValueFromObject(jsonValues.get("u_query_count"));
		snowU_RegionImpacted = SnowUtilities.getStringValueFromObject(jsonValues.get("u_region_impacted"));
		snowU_RelatedIncidents = SnowUtilities.getStringValueFromObject(jsonValues.get("u_related_incidents"));
		snowU_ReopenCount = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reopen_count"));
		snowU_ReopenedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reopened_date"));
		snowU_ResolutionOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("u_resolution_override"));
		snowU_ResolvedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("u_resolved_by"));
		snowU_ResolvedByWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_resolved_by_workgroup"));
		snowU_Resolver = SnowUtilities.getStringValueFromObject(jsonValues.get("u_resolver"));
		snowU_ResponseFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("u_response_flag"));
		snowU_ResponseOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("u_response_override"));
		snowU_SavedCount = SnowUtilities.getStringValueFromObject(jsonValues.get("u_saved_count"));
		snowU_SecondDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("u_second_deadline"));
		snowU_SelectApplication = SnowUtilities.getStringValueFromObject(jsonValues.get("u_select_application"));
		snowU_SelectEuc = SnowUtilities.getStringValueFromObject(jsonValues.get("u_select_euc"));
		snowU_SelectInfrastructure = SnowUtilities.getStringValueFromObject(jsonValues.get("u_select_infrastructure"));
		snowU_SelectNetwork = SnowUtilities.getStringValueFromObject(jsonValues.get("u_select_network"));
		snowU_SlaFailureWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sla_failure_workgroup"));
		snowU_SlaState = SnowUtilities.getStringValueFromObject(jsonValues.get("u_sla_state"));
		snowU_SlfApprover = SnowUtilities.getStringValueFromObject(jsonValues.get("u_slf_approver"));
		snowU_SlfComponent = SnowUtilities.getStringValueFromObject(jsonValues.get("u_slf_component"));
		snowU_SlfReason = SnowUtilities.getStringValueFromObject(jsonValues.get("u_slf_reason"));
		snowU_SlfReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_slf_review_date"));
		snowU_SrtState = SnowUtilities.getStringValueFromObject(jsonValues.get("u_srt_state"));
		snowU_SspForm = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ssp_form"));
		snowU_Subject = SnowUtilities.getStringValueFromObject(jsonValues.get("u_subject"));
		snowU_SupportStructure = SnowUtilities.getStringValueFromObject(jsonValues.get("u_support_structure"));
		snowU_TaskType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_task_type"));
		snowU_Template = SnowUtilities.getStringValueFromObject(jsonValues.get("u_template"));
		snowU_ThirdLineComments = SnowUtilities.getStringValueFromObject(jsonValues.get("u_third_line_comments"));
		snowU_ThirdLineDate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_third_line_date"));
		snowU_TimeToAuth = SnowUtilities.getStringValueFromObject(jsonValues.get("u_time_to_auth"));
		snowU_TimeToClose = SnowUtilities.getStringValueFromObject(jsonValues.get("u_time_to_close"));
		snowU_UsersAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("u_users_affected"));
		snowU_WebUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("u_web_update"));
		snowUponApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("upon_approval"));
		snowUponReject = SnowUtilities.getStringValueFromObject(jsonValues.get("upon_reject"));
		snowUrgency = SnowUtilities.getStringValueFromObject(jsonValues.get("urgency"));
		snowUserInput = SnowUtilities.getStringValueFromObject(jsonValues.get("user_input"));
		snowWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("watch_list"));
		snowWfActivity = SnowUtilities.getStringValueFromObject(jsonValues.get("wf_activity"));
		snowWorkEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("work_effort"));
		snowWorkEnd = SnowUtilities.getStringValueFromObject(jsonValues.get("work_end"));
		snowWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("work_notes"));
		snowWorkStart = SnowUtilities.getStringValueFromObject(jsonValues.get("work_start"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowActive != null && !snowActive.toString().isEmpty()) jsonObject.put("active", snowActive);
		if (snowActivityDue != null && !snowActivityDue.toString().isEmpty()) jsonObject.put("activity_due", snowActivityDue);
		if (snowAdditionalAssigneeList != null && !snowAdditionalAssigneeList.toString().isEmpty()) jsonObject.put("additional_assignee_list", snowAdditionalAssigneeList);
		if (snowApproval != null && !snowApproval.toString().isEmpty()) jsonObject.put("approval", snowApproval);
		if (snowApprovalHistory != null && !snowApprovalHistory.toString().isEmpty()) jsonObject.put("approval_history", snowApprovalHistory);
		if (snowApprovalSet != null && !snowApprovalSet.toString().isEmpty()) jsonObject.put("approval_set", snowApprovalSet);
		if (snowAssignedTo != null && !snowAssignedTo.toString().isEmpty()) jsonObject.put("assigned_to", snowAssignedTo);
		if (snowAssignmentGroup != null && !snowAssignmentGroup.toString().isEmpty()) jsonObject.put("assignment_group", snowAssignmentGroup);
		if (snowBusinessDuration != null && !snowBusinessDuration.toString().isEmpty()) jsonObject.put("business_duration", snowBusinessDuration);
		if (snowBusinessService != null && !snowBusinessService.toString().isEmpty()) jsonObject.put("business_service", snowBusinessService);
		if (snowCalendarDuration != null && !snowCalendarDuration.toString().isEmpty()) jsonObject.put("calendar_duration", snowCalendarDuration);
		if (snowCallerId != null && !snowCallerId.toString().isEmpty()) jsonObject.put("caller_id", snowCallerId);
		if (snowCategory != null && !snowCategory.toString().isEmpty()) jsonObject.put("category", snowCategory);
		if (snowCloseCode != null && !snowCloseCode.toString().isEmpty()) jsonObject.put("close_code", snowCloseCode);
		if (snowCloseNotes != null && !snowCloseNotes.toString().isEmpty()) jsonObject.put("close_notes", snowCloseNotes);
		if (snowClosedAt != null && !snowClosedAt.toString().isEmpty()) jsonObject.put("closed_at", snowClosedAt);
		if (snowClosedBy != null && !snowClosedBy.toString().isEmpty()) jsonObject.put("closed_by", snowClosedBy);
		if (snowCmdbCi != null && !snowCmdbCi.toString().isEmpty()) jsonObject.put("cmdb_ci", snowCmdbCi);
		if (snowComments != null && !snowComments.toString().isEmpty()) jsonObject.put("comments", snowComments);
		if (snowCompany != null && !snowCompany.toString().isEmpty()) jsonObject.put("company", snowCompany);
		if (snowContactType != null && !snowContactType.toString().isEmpty()) jsonObject.put("contact_type", snowContactType);
		if (snowContract != null && !snowContract.toString().isEmpty()) jsonObject.put("contract", snowContract);
		if (snowCorrelationDisplay != null && !snowCorrelationDisplay.toString().isEmpty()) jsonObject.put("correlation_display", snowCorrelationDisplay);
		if (snowCorrelationId != null && !snowCorrelationId.toString().isEmpty()) jsonObject.put("correlation_id", snowCorrelationId);
		if (snowDeliveryPlan != null && !snowDeliveryPlan.toString().isEmpty()) jsonObject.put("delivery_plan", snowDeliveryPlan);
		if (snowDescription != null && !snowDescription.toString().isEmpty()) jsonObject.put("description", snowDescription);
		if (snowDueDate != null && !snowDueDate.toString().isEmpty()) jsonObject.put("due_date", snowDueDate);
		if (snowEffort != null && !snowEffort.toString().isEmpty()) jsonObject.put("effort", snowEffort);
		if (snowEndDate != null && !snowEndDate.toString().isEmpty()) jsonObject.put("end_date", snowEndDate);
		if (snowEscalation != null && !snowEscalation.toString().isEmpty()) jsonObject.put("escalation", snowEscalation);
		if (snowExpectedStart != null && !snowExpectedStart.toString().isEmpty()) jsonObject.put("expected_start", snowExpectedStart);
		if (snowFollowUp != null && !snowFollowUp.toString().isEmpty()) jsonObject.put("follow_up", snowFollowUp);
		if (snowGroupList != null && !snowGroupList.toString().isEmpty()) jsonObject.put("group_list", snowGroupList);
		if (snowImpact != null && !snowImpact.toString().isEmpty()) jsonObject.put("impact", snowImpact);
		if (snowKnowledge != null && !snowKnowledge.toString().isEmpty()) jsonObject.put("knowledge", snowKnowledge);
		if (snowLocation != null && !snowLocation.toString().isEmpty()) jsonObject.put("location", snowLocation);
		if (snowMadeSla != null && !snowMadeSla.toString().isEmpty()) jsonObject.put("made_sla", snowMadeSla);
		if (snowNotify != null && !snowNotify.toString().isEmpty()) jsonObject.put("notify", snowNotify);
		if (snowNumber != null && !snowNumber.toString().isEmpty()) jsonObject.put("number", snowNumber);
		if (snowOpenedAt != null && !snowOpenedAt.toString().isEmpty()) jsonObject.put("opened_at", snowOpenedAt);
		if (snowOpenedBy != null && !snowOpenedBy.toString().isEmpty()) jsonObject.put("opened_by", snowOpenedBy);
		if (snowOrder != null && !snowOrder.toString().isEmpty()) jsonObject.put("order", snowOrder);
		if (snowParent != null && !snowParent.toString().isEmpty()) jsonObject.put("parent", snowParent);
		if (snowPriority != null && !snowPriority.toString().isEmpty()) jsonObject.put("priority", snowPriority);
		if (snowReassignmentCount != null && !snowReassignmentCount.toString().isEmpty()) jsonObject.put("reassignment_count", snowReassignmentCount);
		if (snowRfc != null && !snowRfc.toString().isEmpty()) jsonObject.put("rfc", snowRfc);
		if (snowShortDescription != null && !snowShortDescription.toString().isEmpty()) jsonObject.put("short_description", snowShortDescription);
		if (snowSkills != null && !snowSkills.toString().isEmpty()) jsonObject.put("skills", snowSkills);
		if (snowSlaDue != null && !snowSlaDue.toString().isEmpty()) jsonObject.put("sla_due", snowSlaDue);
		if (snowStartDate != null && !snowStartDate.toString().isEmpty()) jsonObject.put("start_date", snowStartDate);
		if (snowState != null && !snowState.toString().isEmpty()) jsonObject.put("state", snowState);
		if (snowStatus != null && !snowStatus.toString().isEmpty()) jsonObject.put("status", snowStatus);
		if (snowSubcategory != null && !snowSubcategory.toString().isEmpty()) jsonObject.put("subcategory", snowSubcategory);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysDomain != null && !snowSysDomain.toString().isEmpty()) jsonObject.put("sys_domain", snowSysDomain);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowTimeWorked != null && !snowTimeWorked.toString().isEmpty()) jsonObject.put("time_worked", snowTimeWorked);
		if (snowU_3RdLineSrt != null && !snowU_3RdLineSrt.toString().isEmpty()) jsonObject.put("u_3rd_line_srt", snowU_3RdLineSrt);
		if (snowU_AcknowldgeFeedback != null && !snowU_AcknowldgeFeedback.toString().isEmpty()) jsonObject.put("u_acknowldge_feedback", snowU_AcknowldgeFeedback);
		if (snowU_Acknowledged != null && !snowU_Acknowledged.toString().isEmpty()) jsonObject.put("u_acknowledged", snowU_Acknowledged);
		if (snowU_ActiveProbInc != null && !snowU_ActiveProbInc.toString().isEmpty()) jsonObject.put("u_active_prob_inc", snowU_ActiveProbInc);
		if (snowU_ActualEffort != null && !snowU_ActualEffort.toString().isEmpty()) jsonObject.put("u_actual_effort", snowU_ActualEffort);
		if (snowU_ActualStart != null && !snowU_ActualStart.toString().isEmpty()) jsonObject.put("u_actual_start", snowU_ActualStart);
		if (snowU_AffectedAsset != null && !snowU_AffectedAsset.toString().isEmpty()) jsonObject.put("u_affected_asset", snowU_AffectedAsset);
		if (snowU_AffectedUser != null && !snowU_AffectedUser.toString().isEmpty()) jsonObject.put("u_affected_user", snowU_AffectedUser);
		if (snowU_AofDateTime != null && !snowU_AofDateTime.toString().isEmpty()) jsonObject.put("u_aof_date__time", snowU_AofDateTime);
		if (snowU_AofState != null && !snowU_AofState.toString().isEmpty()) jsonObject.put("u_aof_state", snowU_AofState);
		if (snowU_AofWorkgroup != null && !snowU_AofWorkgroup.toString().isEmpty()) jsonObject.put("u_aof_workgroup", snowU_AofWorkgroup);
		if (snowU_AosDateTime != null && !snowU_AosDateTime.toString().isEmpty()) jsonObject.put("u_aos_date__time", snowU_AosDateTime);
		if (snowU_AosState != null && !snowU_AosState.toString().isEmpty()) jsonObject.put("u_aos_state", snowU_AosState);
		if (snowU_AosWorkgroup != null && !snowU_AosWorkgroup.toString().isEmpty()) jsonObject.put("u_aos_workgroup", snowU_AosWorkgroup);
		if (snowU_AssetCode != null && !snowU_AssetCode.toString().isEmpty()) jsonObject.put("u_asset_code", snowU_AssetCode);
		if (snowU_AssetString != null && !snowU_AssetString.toString().isEmpty()) jsonObject.put("u_asset_string", snowU_AssetString);
		if (snowU_AssignedToBladelogic != null && !snowU_AssignedToBladelogic.toString().isEmpty()) jsonObject.put("u_assigned_to_bladelogic", snowU_AssignedToBladelogic);
		if (snowU_AssignmentStatus != null && !snowU_AssignmentStatus.toString().isEmpty()) jsonObject.put("u_assignment_status", snowU_AssignmentStatus);
		if (snowU_AttachmentsAdded != null && !snowU_AttachmentsAdded.toString().isEmpty()) jsonObject.put("u_attachments_added", snowU_AttachmentsAdded);
		if (snowU_AuditCode != null && !snowU_AuditCode.toString().isEmpty()) jsonObject.put("u_audit__code", snowU_AuditCode);
		if (snowU_AutoClose != null && !snowU_AutoClose.toString().isEmpty()) jsonObject.put("u_auto_close", snowU_AutoClose);
		if (snowU_AutoCloseTicket != null && !snowU_AutoCloseTicket.toString().isEmpty()) jsonObject.put("u_auto_close_ticket", snowU_AutoCloseTicket);
		if (snowU_AutoParm1 != null && !snowU_AutoParm1.toString().isEmpty()) jsonObject.put("u_auto_parm1", snowU_AutoParm1);
		if (snowU_AutoParm2 != null && !snowU_AutoParm2.toString().isEmpty()) jsonObject.put("u_auto_parm2", snowU_AutoParm2);
		if (snowU_AutoParm3 != null && !snowU_AutoParm3.toString().isEmpty()) jsonObject.put("u_auto_parm3", snowU_AutoParm3);
		if (snowU_AutoParm4 != null && !snowU_AutoParm4.toString().isEmpty()) jsonObject.put("u_auto_parm4", snowU_AutoParm4);
		if (snowU_AutoParm5 != null && !snowU_AutoParm5.toString().isEmpty()) jsonObject.put("u_auto_parm5", snowU_AutoParm5);
		if (snowU_AutoTarget != null && !snowU_AutoTarget.toString().isEmpty()) jsonObject.put("u_auto_target", snowU_AutoTarget);
		if (snowU_AutoType != null && !snowU_AutoType.toString().isEmpty()) jsonObject.put("u_auto_type", snowU_AutoType);
		if (snowU_AvailAddComments != null && !snowU_AvailAddComments.toString().isEmpty()) jsonObject.put("u_avail_add_comments", snowU_AvailAddComments);
		if (snowU_AvailTechSvc != null && !snowU_AvailTechSvc.toString().isEmpty()) jsonObject.put("u_avail_tech_svc", snowU_AvailTechSvc);
		if (snowU_AvailabilityReport != null && !snowU_AvailabilityReport.toString().isEmpty()) jsonObject.put("u_availability_report", snowU_AvailabilityReport);
		if (snowU_BsdResolutionBy != null && !snowU_BsdResolutionBy.toString().isEmpty()) jsonObject.put("u_bsd_resolution_by", snowU_BsdResolutionBy);
		if (snowU_BusinessService != null && !snowU_BusinessService.toString().isEmpty()) jsonObject.put("u_business_service", snowU_BusinessService);
		if (snowU_CallCaptureComments != null && !snowU_CallCaptureComments.toString().isEmpty()) jsonObject.put("u_call_capture_comments", snowU_CallCaptureComments);
		if (snowU_CallHandlingComments != null && !snowU_CallHandlingComments.toString().isEmpty()) jsonObject.put("u_call_handling_comments", snowU_CallHandlingComments);
		if (snowU_CauseItem != null && !snowU_CauseItem.toString().isEmpty()) jsonObject.put("u_cause_item", snowU_CauseItem);
		if (snowU_CausedBy != null && !snowU_CausedBy.toString().isEmpty()) jsonObject.put("u_caused_by", snowU_CausedBy);
		if (snowU_ChangeManager != null && !snowU_ChangeManager.toString().isEmpty()) jsonObject.put("u_change_manager", snowU_ChangeManager);
		if (snowU_Classification != null && !snowU_Classification.toString().isEmpty()) jsonObject.put("u_classification", snowU_Classification);
		if (snowU_ClosedPeriod != null && !snowU_ClosedPeriod.toString().isEmpty()) jsonObject.put("u_closed_period", snowU_ClosedPeriod);
		if (snowU_ClosureCategory != null && !snowU_ClosureCategory.toString().isEmpty()) jsonObject.put("u_closure_category", snowU_ClosureCategory);
		if (snowU_CommentType != null && !snowU_CommentType.toString().isEmpty()) jsonObject.put("u_comment_type", snowU_CommentType);
		if (snowU_CommentTypeHandling != null && !snowU_CommentTypeHandling.toString().isEmpty()) jsonObject.put("u_comment_type_handling", snowU_CommentTypeHandling);
		if (snowU_CommentsAndWorkNotes != null && !snowU_CommentsAndWorkNotes.toString().isEmpty()) jsonObject.put("u_comments_and_work_notes", snowU_CommentsAndWorkNotes);
		if (snowU_DesktopAssetNumber != null && !snowU_DesktopAssetNumber.toString().isEmpty()) jsonObject.put("u_desktop_asset_number", snowU_DesktopAssetNumber);
		if (snowU_DesktopMake != null && !snowU_DesktopMake.toString().isEmpty()) jsonObject.put("u_desktop_make", snowU_DesktopMake);
		if (snowU_DesktopModel != null && !snowU_DesktopModel.toString().isEmpty()) jsonObject.put("u_desktop_model", snowU_DesktopModel);
		if (snowU_DesktopSN != null && !snowU_DesktopSN.toString().isEmpty()) jsonObject.put("u_desktop_s_n", snowU_DesktopSN);
		if (snowU_Escalated != null && !snowU_Escalated.toString().isEmpty()) jsonObject.put("u_escalated", snowU_Escalated);
		if (snowU_ExpertHelp != null && !snowU_ExpertHelp.toString().isEmpty()) jsonObject.put("u_expert_help", snowU_ExpertHelp);
		if (snowU_ExternalRef != null && !snowU_ExternalRef.toString().isEmpty()) jsonObject.put("u_external_ref", snowU_ExternalRef);
		if (snowU_FeedbackCode != null && !snowU_FeedbackCode.toString().isEmpty()) jsonObject.put("u_feedback_code", snowU_FeedbackCode);
		if (snowU_FeedbackCodeHandling != null && !snowU_FeedbackCodeHandling.toString().isEmpty()) jsonObject.put("u_feedback_code_handling", snowU_FeedbackCodeHandling);
		if (snowU_FirstDeadline != null && !snowU_FirstDeadline.toString().isEmpty()) jsonObject.put("u_first_deadline", snowU_FirstDeadline);
		if (snowU_Folder != null && !snowU_Folder.toString().isEmpty()) jsonObject.put("u_folder", snowU_Folder);
		if (snowU_ImpBreakdown != null && !snowU_ImpBreakdown.toString().isEmpty()) jsonObject.put("u_imp_breakdown", snowU_ImpBreakdown);
		if (snowU_InitialAssignment != null && !snowU_InitialAssignment.toString().isEmpty()) jsonObject.put("u_initial_assignment", snowU_InitialAssignment);
		if (snowU_Instructions != null && !snowU_Instructions.toString().isEmpty()) jsonObject.put("u_instructions", snowU_Instructions);
		if (snowU_InternalRef != null && !snowU_InternalRef.toString().isEmpty()) jsonObject.put("u_internal_ref", snowU_InternalRef);
		if (snowU_ItilWatchList != null && !snowU_ItilWatchList.toString().isEmpty()) jsonObject.put("u_itil_watch_list", snowU_ItilWatchList);
		if (snowU_KnowledgeArticle != null && !snowU_KnowledgeArticle.toString().isEmpty()) jsonObject.put("u_knowledge_article", snowU_KnowledgeArticle);
		if (snowU_KnowledgeAvailable != null && !snowU_KnowledgeAvailable.toString().isEmpty()) jsonObject.put("u_knowledge_available", snowU_KnowledgeAvailable);
		if (snowU_KnowledgeCode != null && !snowU_KnowledgeCode.toString().isEmpty()) jsonObject.put("u_knowledge_code", snowU_KnowledgeCode);
		if (snowU_KnowledgeComments != null && !snowU_KnowledgeComments.toString().isEmpty()) jsonObject.put("u_knowledge_comments", snowU_KnowledgeComments);
		if (snowU_KnowledgeFound != null && !snowU_KnowledgeFound.toString().isEmpty()) jsonObject.put("u_knowledge_found", snowU_KnowledgeFound);
		if (snowU_KnowledgeUser != null && !snowU_KnowledgeUser.toString().isEmpty()) jsonObject.put("u_knowledge_user", snowU_KnowledgeUser);
		if (snowU_LastOccurrence != null && !snowU_LastOccurrence.toString().isEmpty()) jsonObject.put("u_last_occurrence", snowU_LastOccurrence);
		if (snowU_LateImpReason != null && !snowU_LateImpReason.toString().isEmpty()) jsonObject.put("u_late_imp_reason", snowU_LateImpReason);
		if (snowU_LocalResp != null && !snowU_LocalResp.toString().isEmpty()) jsonObject.put("u_local_resp", snowU_LocalResp);
		if (snowU_ManagementAuditComments != null && !snowU_ManagementAuditComments.toString().isEmpty()) jsonObject.put("u_management_audit_comments", snowU_ManagementAuditComments);
		if (snowU_ManagementComments != null && !snowU_ManagementComments.toString().isEmpty()) jsonObject.put("u_management_comments", snowU_ManagementComments);
		if (snowU_ModifiedPeriod != null && !snowU_ModifiedPeriod.toString().isEmpty()) jsonObject.put("u_modified_period", snowU_ModifiedPeriod);
		if (snowU_OpenedPeriod != null && !snowU_OpenedPeriod.toString().isEmpty()) jsonObject.put("u_opened_period", snowU_OpenedPeriod);
		if (snowU_OutageDuration != null && !snowU_OutageDuration.toString().isEmpty()) jsonObject.put("u_outage_duration", snowU_OutageDuration);
		if (snowU_OutsourceAssignedOut != null && !snowU_OutsourceAssignedOut.toString().isEmpty()) jsonObject.put("u_outsource_assigned_out", snowU_OutsourceAssignedOut);
		if (snowU_OutsourceAssignee != null && !snowU_OutsourceAssignee.toString().isEmpty()) jsonObject.put("u_outsource_assignee", snowU_OutsourceAssignee);
		if (snowU_OutsourceId != null && !snowU_OutsourceId.toString().isEmpty()) jsonObject.put("u_outsource_id", snowU_OutsourceId);
		if (snowU_OutsourceIntegration != null && !snowU_OutsourceIntegration.toString().isEmpty()) jsonObject.put("u_outsource_integration", snowU_OutsourceIntegration);
		if (snowU_OutsourceModule != null && !snowU_OutsourceModule.toString().isEmpty()) jsonObject.put("u_outsource_module", snowU_OutsourceModule);
		if (snowU_OutsourceResponse != null && !snowU_OutsourceResponse.toString().isEmpty()) jsonObject.put("u_outsource_response", snowU_OutsourceResponse);
		if (snowU_OutsourceResult != null && !snowU_OutsourceResult.toString().isEmpty()) jsonObject.put("u_outsource_result", snowU_OutsourceResult);
		if (snowU_OutsourceStatus != null && !snowU_OutsourceStatus.toString().isEmpty()) jsonObject.put("u_outsource_status", snowU_OutsourceStatus);
		if (snowU_OutsourceTeam != null && !snowU_OutsourceTeam.toString().isEmpty()) jsonObject.put("u_outsource_team", snowU_OutsourceTeam);
		if (snowU_Override1 != null && !snowU_Override1.toString().isEmpty()) jsonObject.put("u_override1", snowU_Override1);
		if (snowU_Person != null && !snowU_Person.toString().isEmpty()) jsonObject.put("u_person", snowU_Person);
		if (snowU_PersonAudited != null && !snowU_PersonAudited.toString().isEmpty()) jsonObject.put("u_person_audited", snowU_PersonAudited);
		if (snowU_PersonAuditing != null && !snowU_PersonAuditing.toString().isEmpty()) jsonObject.put("u_person_auditing", snowU_PersonAuditing);
		if (snowU_Phone != null && !snowU_Phone.toString().isEmpty()) jsonObject.put("u_phone", snowU_Phone);
		if (snowU_PickupDuration != null && !snowU_PickupDuration.toString().isEmpty()) jsonObject.put("u_pickup_duration", snowU_PickupDuration);
		if (snowU_PlannedEffort != null && !snowU_PlannedEffort.toString().isEmpty()) jsonObject.put("u_planned_effort", snowU_PlannedEffort);
		if (snowU_PlannedImplementationWeek != null && !snowU_PlannedImplementationWeek.toString().isEmpty()) jsonObject.put("u_planned_implementation_week", snowU_PlannedImplementationWeek);
		if (snowU_PreviousGroup != null && !snowU_PreviousGroup.toString().isEmpty()) jsonObject.put("u_previous_group", snowU_PreviousGroup);
		if (snowU_QueryCount != null && !snowU_QueryCount.toString().isEmpty()) jsonObject.put("u_query_count", snowU_QueryCount);
		if (snowU_RegionImpacted != null && !snowU_RegionImpacted.toString().isEmpty()) jsonObject.put("u_region_impacted", snowU_RegionImpacted);
		if (snowU_RelatedIncidents != null && !snowU_RelatedIncidents.toString().isEmpty()) jsonObject.put("u_related_incidents", snowU_RelatedIncidents);
		if (snowU_ReopenCount != null && !snowU_ReopenCount.toString().isEmpty()) jsonObject.put("u_reopen_count", snowU_ReopenCount);
		if (snowU_ReopenedDate != null && !snowU_ReopenedDate.toString().isEmpty()) jsonObject.put("u_reopened_date", snowU_ReopenedDate);
		if (snowU_ResolutionOverride != null && !snowU_ResolutionOverride.toString().isEmpty()) jsonObject.put("u_resolution_override", snowU_ResolutionOverride);
		if (snowU_ResolvedBy != null && !snowU_ResolvedBy.toString().isEmpty()) jsonObject.put("u_resolved_by", snowU_ResolvedBy);
		if (snowU_ResolvedByWorkgroup != null && !snowU_ResolvedByWorkgroup.toString().isEmpty()) jsonObject.put("u_resolved_by_workgroup", snowU_ResolvedByWorkgroup);
		if (snowU_Resolver != null && !snowU_Resolver.toString().isEmpty()) jsonObject.put("u_resolver", snowU_Resolver);
		if (snowU_ResponseFlag != null && !snowU_ResponseFlag.toString().isEmpty()) jsonObject.put("u_response_flag", snowU_ResponseFlag);
		if (snowU_ResponseOverride != null && !snowU_ResponseOverride.toString().isEmpty()) jsonObject.put("u_response_override", snowU_ResponseOverride);
		if (snowU_SavedCount != null && !snowU_SavedCount.toString().isEmpty()) jsonObject.put("u_saved_count", snowU_SavedCount);
		if (snowU_SecondDeadline != null && !snowU_SecondDeadline.toString().isEmpty()) jsonObject.put("u_second_deadline", snowU_SecondDeadline);
		if (snowU_SelectApplication != null && !snowU_SelectApplication.toString().isEmpty()) jsonObject.put("u_select_application", snowU_SelectApplication);
		if (snowU_SelectEuc != null && !snowU_SelectEuc.toString().isEmpty()) jsonObject.put("u_select_euc", snowU_SelectEuc);
		if (snowU_SelectInfrastructure != null && !snowU_SelectInfrastructure.toString().isEmpty()) jsonObject.put("u_select_infrastructure", snowU_SelectInfrastructure);
		if (snowU_SelectNetwork != null && !snowU_SelectNetwork.toString().isEmpty()) jsonObject.put("u_select_network", snowU_SelectNetwork);
		if (snowU_SlaFailureWorkgroup != null && !snowU_SlaFailureWorkgroup.toString().isEmpty()) jsonObject.put("u_sla_failure_workgroup", snowU_SlaFailureWorkgroup);
		if (snowU_SlaState != null && !snowU_SlaState.toString().isEmpty()) jsonObject.put("u_sla_state", snowU_SlaState);
		if (snowU_SlfApprover != null && !snowU_SlfApprover.toString().isEmpty()) jsonObject.put("u_slf_approver", snowU_SlfApprover);
		if (snowU_SlfComponent != null && !snowU_SlfComponent.toString().isEmpty()) jsonObject.put("u_slf_component", snowU_SlfComponent);
		if (snowU_SlfReason != null && !snowU_SlfReason.toString().isEmpty()) jsonObject.put("u_slf_reason", snowU_SlfReason);
		if (snowU_SlfReviewDate != null && !snowU_SlfReviewDate.toString().isEmpty()) jsonObject.put("u_slf_review_date", snowU_SlfReviewDate);
		if (snowU_SrtState != null && !snowU_SrtState.toString().isEmpty()) jsonObject.put("u_srt_state", snowU_SrtState);
		if (snowU_SspForm != null && !snowU_SspForm.toString().isEmpty()) jsonObject.put("u_ssp_form", snowU_SspForm);
		if (snowU_Subject != null && !snowU_Subject.toString().isEmpty()) jsonObject.put("u_subject", snowU_Subject);
		if (snowU_SupportStructure != null && !snowU_SupportStructure.toString().isEmpty()) jsonObject.put("u_support_structure", snowU_SupportStructure);
		if (snowU_TaskType != null && !snowU_TaskType.toString().isEmpty()) jsonObject.put("u_task_type", snowU_TaskType);
		if (snowU_Template != null && !snowU_Template.toString().isEmpty()) jsonObject.put("u_template", snowU_Template);
		if (snowU_ThirdLineComments != null && !snowU_ThirdLineComments.toString().isEmpty()) jsonObject.put("u_third_line_comments", snowU_ThirdLineComments);
		if (snowU_ThirdLineDate != null && !snowU_ThirdLineDate.toString().isEmpty()) jsonObject.put("u_third_line_date", snowU_ThirdLineDate);
		if (snowU_TimeToAuth != null && !snowU_TimeToAuth.toString().isEmpty()) jsonObject.put("u_time_to_auth", snowU_TimeToAuth);
		if (snowU_TimeToClose != null && !snowU_TimeToClose.toString().isEmpty()) jsonObject.put("u_time_to_close", snowU_TimeToClose);
		if (snowU_UsersAffected != null && !snowU_UsersAffected.toString().isEmpty()) jsonObject.put("u_users_affected", snowU_UsersAffected);
		if (snowU_WebUpdate != null && !snowU_WebUpdate.toString().isEmpty()) jsonObject.put("u_web_update", snowU_WebUpdate);
		if (snowUponApproval != null && !snowUponApproval.toString().isEmpty()) jsonObject.put("upon_approval", snowUponApproval);
		if (snowUponReject != null && !snowUponReject.toString().isEmpty()) jsonObject.put("upon_reject", snowUponReject);
		if (snowUrgency != null && !snowUrgency.toString().isEmpty()) jsonObject.put("urgency", snowUrgency);
		if (snowUserInput != null && !snowUserInput.toString().isEmpty()) jsonObject.put("user_input", snowUserInput);
		if (snowWatchList != null && !snowWatchList.toString().isEmpty()) jsonObject.put("watch_list", snowWatchList);
		if (snowWfActivity != null && !snowWfActivity.toString().isEmpty()) jsonObject.put("wf_activity", snowWfActivity);
		if (snowWorkEffort != null && !snowWorkEffort.toString().isEmpty()) jsonObject.put("work_effort", snowWorkEffort);
		if (snowWorkEnd != null && !snowWorkEnd.toString().isEmpty()) jsonObject.put("work_end", snowWorkEnd);
		if (snowWorkNotes != null && !snowWorkNotes.toString().isEmpty()) jsonObject.put("work_notes", snowWorkNotes);
		if (snowWorkStart != null && !snowWorkStart.toString().isEmpty()) jsonObject.put("work_start", snowWorkStart);
		
		return jsonObject;
	}

	public String getSnowActive() {
		return snowActive;
	}

	public void setSnowActive(String snowActive) {
		this.snowActive = snowActive;
	}

	public String getSnowActivityDue() {
		return snowActivityDue;
	}

	public void setSnowActivityDue(String snowActivityDue) {
		this.snowActivityDue = snowActivityDue;
	}

	public String getSnowAdditionalAssigneeList() {
		return snowAdditionalAssigneeList;
	}

	public void setSnowAdditionalAssigneeList(String snowAdditionalAssigneeList) {
		this.snowAdditionalAssigneeList = snowAdditionalAssigneeList;
	}

	public String getSnowApproval() {
		return snowApproval;
	}

	public void setSnowApproval(String snowApproval) {
		this.snowApproval = snowApproval;
	}

	public String getSnowApprovalHistory() {
		return snowApprovalHistory;
	}

	public void setSnowApprovalHistory(String snowApprovalHistory) {
		this.snowApprovalHistory = snowApprovalHistory;
	}

	public String getSnowApprovalSet() {
		return snowApprovalSet;
	}

	public void setSnowApprovalSet(String snowApprovalSet) {
		this.snowApprovalSet = snowApprovalSet;
	}

	public String getSnowAssignedTo() {
		return snowAssignedTo;
	}

	public void setSnowAssignedTo(String snowAssignedTo) {
		this.snowAssignedTo = snowAssignedTo;
	}

	public String getSnowAssignmentGroup() {
		return snowAssignmentGroup;
	}

	public void setSnowAssignmentGroup(String snowAssignmentGroup) {
		this.snowAssignmentGroup = snowAssignmentGroup;
	}

	public String getSnowBusinessDuration() {
		return snowBusinessDuration;
	}

	public void setSnowBusinessDuration(String snowBusinessDuration) {
		this.snowBusinessDuration = snowBusinessDuration;
	}

	public String getSnowBusinessService() {
		return snowBusinessService;
	}

	public void setSnowBusinessService(String snowBusinessService) {
		this.snowBusinessService = snowBusinessService;
	}

	public String getSnowCalendarDuration() {
		return snowCalendarDuration;
	}

	public void setSnowCalendarDuration(String snowCalendarDuration) {
		this.snowCalendarDuration = snowCalendarDuration;
	}

	public String getSnowCallerId() {
		return snowCallerId;
	}

	public void setSnowCallerId(String snowCallerId) {
		this.snowCallerId = snowCallerId;
	}

	public String getSnowCategory() {
		return snowCategory;
	}

	public void setSnowCategory(String snowCategory) {
		this.snowCategory = snowCategory;
	}

	public String getSnowCloseCode() {
		return snowCloseCode;
	}

	public void setSnowCloseCode(String snowCloseCode) {
		this.snowCloseCode = snowCloseCode;
	}

	public String getSnowCloseNotes() {
		return snowCloseNotes;
	}

	public void setSnowCloseNotes(String snowCloseNotes) {
		this.snowCloseNotes = snowCloseNotes;
	}

	public String getSnowClosedAt() {
		return snowClosedAt;
	}

	public void setSnowClosedAt(String snowClosedAt) {
		this.snowClosedAt = snowClosedAt;
	}

	public String getSnowClosedBy() {
		return snowClosedBy;
	}

	public void setSnowClosedBy(String snowClosedBy) {
		this.snowClosedBy = snowClosedBy;
	}

	public String getSnowCmdbCi() {
		return snowCmdbCi;
	}

	public void setSnowCmdbCi(String snowCmdbCi) {
		this.snowCmdbCi = snowCmdbCi;
	}

	public String getSnowComments() {
		return snowComments;
	}

	public void setSnowComments(String snowComments) {
		this.snowComments = snowComments;
	}

	public String getSnowCompany() {
		return snowCompany;
	}

	public void setSnowCompany(String snowCompany) {
		this.snowCompany = snowCompany;
	}

	public String getSnowContactType() {
		return snowContactType;
	}

	public void setSnowContactType(String snowContactType) {
		this.snowContactType = snowContactType;
	}

	public String getSnowContract() {
		return snowContract;
	}

	public void setSnowContract(String snowContract) {
		this.snowContract = snowContract;
	}

	public String getSnowCorrelationDisplay() {
		return snowCorrelationDisplay;
	}

	public void setSnowCorrelationDisplay(String snowCorrelationDisplay) {
		this.snowCorrelationDisplay = snowCorrelationDisplay;
	}

	public String getSnowCorrelationId() {
		return snowCorrelationId;
	}

	public void setSnowCorrelationId(String snowCorrelationId) {
		this.snowCorrelationId = snowCorrelationId;
	}

	public String getSnowDeliveryPlan() {
		return snowDeliveryPlan;
	}

	public void setSnowDeliveryPlan(String snowDeliveryPlan) {
		this.snowDeliveryPlan = snowDeliveryPlan;
	}

	public String getSnowDescription() {
		return snowDescription;
	}

	public void setSnowDescription(String snowDescription) {
		this.snowDescription = snowDescription;
	}

	public String getSnowDueDate() {
		return snowDueDate;
	}

	public void setSnowDueDate(String snowDueDate) {
		this.snowDueDate = snowDueDate;
	}

	public String getSnowEffort() {
		return snowEffort;
	}

	public void setSnowEffort(String snowEffort) {
		this.snowEffort = snowEffort;
	}

	public String getSnowEndDate() {
		return snowEndDate;
	}

	public void setSnowEndDate(String snowEndDate) {
		this.snowEndDate = snowEndDate;
	}

	public String getSnowEscalation() {
		return snowEscalation;
	}

	public void setSnowEscalation(String snowEscalation) {
		this.snowEscalation = snowEscalation;
	}

	public String getSnowExpectedStart() {
		return snowExpectedStart;
	}

	public void setSnowExpectedStart(String snowExpectedStart) {
		this.snowExpectedStart = snowExpectedStart;
	}

	public String getSnowFollowUp() {
		return snowFollowUp;
	}

	public void setSnowFollowUp(String snowFollowUp) {
		this.snowFollowUp = snowFollowUp;
	}

	public String getSnowGroupList() {
		return snowGroupList;
	}

	public void setSnowGroupList(String snowGroupList) {
		this.snowGroupList = snowGroupList;
	}

	public String getSnowImpact() {
		return snowImpact;
	}

	public void setSnowImpact(String snowImpact) {
		this.snowImpact = snowImpact;
	}

	public String getSnowKnowledge() {
		return snowKnowledge;
	}

	public void setSnowKnowledge(String snowKnowledge) {
		this.snowKnowledge = snowKnowledge;
	}

	public String getSnowLocation() {
		return snowLocation;
	}

	public void setSnowLocation(String snowLocation) {
		this.snowLocation = snowLocation;
	}

	public String getSnowMadeSla() {
		return snowMadeSla;
	}

	public void setSnowMadeSla(String snowMadeSla) {
		this.snowMadeSla = snowMadeSla;
	}

	public String getSnowNotify() {
		return snowNotify;
	}

	public void setSnowNotify(String snowNotify) {
		this.snowNotify = snowNotify;
	}

	public String getSnowNumber() {
		return snowNumber;
	}

	public void setSnowNumber(String snowNumber) {
		this.snowNumber = snowNumber;
	}

	public String getSnowOpenedAt() {
		return snowOpenedAt;
	}

	public void setSnowOpenedAt(String snowOpenedAt) {
		this.snowOpenedAt = snowOpenedAt;
	}

	public String getSnowOpenedBy() {
		return snowOpenedBy;
	}

	public void setSnowOpenedBy(String snowOpenedBy) {
		this.snowOpenedBy = snowOpenedBy;
	}

	public String getSnowOrder() {
		return snowOrder;
	}

	public void setSnowOrder(String snowOrder) {
		this.snowOrder = snowOrder;
	}

	public String getSnowParent() {
		return snowParent;
	}

	public void setSnowParent(String snowParent) {
		this.snowParent = snowParent;
	}

	public String getSnowPriority() {
		return snowPriority;
	}

	public void setSnowPriority(String snowPriority) {
		this.snowPriority = snowPriority;
	}

	public String getSnowReassignmentCount() {
		return snowReassignmentCount;
	}

	public void setSnowReassignmentCount(String snowReassignmentCount) {
		this.snowReassignmentCount = snowReassignmentCount;
	}

	public String getSnowRfc() {
		return snowRfc;
	}

	public void setSnowRfc(String snowRfc) {
		this.snowRfc = snowRfc;
	}

	public String getSnowShortDescription() {
		return snowShortDescription;
	}

	public void setSnowShortDescription(String snowShortDescription) {
		this.snowShortDescription = snowShortDescription;
	}

	public String getSnowSkills() {
		return snowSkills;
	}

	public void setSnowSkills(String snowSkills) {
		this.snowSkills = snowSkills;
	}

	public String getSnowSlaDue() {
		return snowSlaDue;
	}

	public void setSnowSlaDue(String snowSlaDue) {
		this.snowSlaDue = snowSlaDue;
	}

	public String getSnowStartDate() {
		return snowStartDate;
	}

	public void setSnowStartDate(String snowStartDate) {
		this.snowStartDate = snowStartDate;
	}

	public String getSnowState() {
		return snowState;
	}

	public void setSnowState(String snowState) {
		this.snowState = snowState;
	}

	public String getSnowStatus() {
		return snowStatus;
	}

	public void setSnowStatus(String snowStatus) {
		this.snowStatus = snowStatus;
	}

	public String getSnowSubcategory() {
		return snowSubcategory;
	}

	public void setSnowSubcategory(String snowSubcategory) {
		this.snowSubcategory = snowSubcategory;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysDomain() {
		return snowSysDomain;
	}

	public void setSnowSysDomain(String snowSysDomain) {
		this.snowSysDomain = snowSysDomain;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowTimeWorked() {
		return snowTimeWorked;
	}

	public void setSnowTimeWorked(String snowTimeWorked) {
		this.snowTimeWorked = snowTimeWorked;
	}

	public String getSnowU_3RdLineSrt() {
		return snowU_3RdLineSrt;
	}

	public void setSnowU_3RdLineSrt(String snowU_3RdLineSrt) {
		this.snowU_3RdLineSrt = snowU_3RdLineSrt;
	}

	public String getSnowU_AcknowldgeFeedback() {
		return snowU_AcknowldgeFeedback;
	}

	public void setSnowU_AcknowldgeFeedback(String snowU_AcknowldgeFeedback) {
		this.snowU_AcknowldgeFeedback = snowU_AcknowldgeFeedback;
	}

	public String getSnowU_Acknowledged() {
		return snowU_Acknowledged;
	}

	public void setSnowU_Acknowledged(String snowU_Acknowledged) {
		this.snowU_Acknowledged = snowU_Acknowledged;
	}

	public String getSnowU_ActiveProbInc() {
		return snowU_ActiveProbInc;
	}

	public void setSnowU_ActiveProbInc(String snowU_ActiveProbInc) {
		this.snowU_ActiveProbInc = snowU_ActiveProbInc;
	}

	public String getSnowU_ActualEffort() {
		return snowU_ActualEffort;
	}

	public void setSnowU_ActualEffort(String snowU_ActualEffort) {
		this.snowU_ActualEffort = snowU_ActualEffort;
	}

	public String getSnowU_ActualStart() {
		return snowU_ActualStart;
	}

	public void setSnowU_ActualStart(String snowU_ActualStart) {
		this.snowU_ActualStart = snowU_ActualStart;
	}

	public String getSnowU_AffectedAsset() {
		return snowU_AffectedAsset;
	}

	public void setSnowU_AffectedAsset(String snowU_AffectedAsset) {
		this.snowU_AffectedAsset = snowU_AffectedAsset;
	}

	public String getSnowU_AffectedUser() {
		return snowU_AffectedUser;
	}

	public void setSnowU_AffectedUser(String snowU_AffectedUser) {
		this.snowU_AffectedUser = snowU_AffectedUser;
	}

	public String getSnowU_AofDateTime() {
		return snowU_AofDateTime;
	}

	public void setSnowU_AofDateTime(String snowU_AofDateTime) {
		this.snowU_AofDateTime = snowU_AofDateTime;
	}

	public String getSnowU_AofState() {
		return snowU_AofState;
	}

	public void setSnowU_AofState(String snowU_AofState) {
		this.snowU_AofState = snowU_AofState;
	}

	public String getSnowU_AofWorkgroup() {
		return snowU_AofWorkgroup;
	}

	public void setSnowU_AofWorkgroup(String snowU_AofWorkgroup) {
		this.snowU_AofWorkgroup = snowU_AofWorkgroup;
	}

	public String getSnowU_AosDateTime() {
		return snowU_AosDateTime;
	}

	public void setSnowU_AosDateTime(String snowU_AosDateTime) {
		this.snowU_AosDateTime = snowU_AosDateTime;
	}

	public String getSnowU_AosState() {
		return snowU_AosState;
	}

	public void setSnowU_AosState(String snowU_AosState) {
		this.snowU_AosState = snowU_AosState;
	}

	public String getSnowU_AosWorkgroup() {
		return snowU_AosWorkgroup;
	}

	public void setSnowU_AosWorkgroup(String snowU_AosWorkgroup) {
		this.snowU_AosWorkgroup = snowU_AosWorkgroup;
	}

	public String getSnowU_AssetCode() {
		return snowU_AssetCode;
	}

	public void setSnowU_AssetCode(String snowU_AssetCode) {
		this.snowU_AssetCode = snowU_AssetCode;
	}

	public String getSnowU_AssetString() {
		return snowU_AssetString;
	}

	public void setSnowU_AssetString(String snowU_AssetString) {
		this.snowU_AssetString = snowU_AssetString;
	}

	public String getSnowU_AssignedToBladelogic() {
		return snowU_AssignedToBladelogic;
	}

	public void setSnowU_AssignedToBladelogic(String snowU_AssignedToBladelogic) {
		this.snowU_AssignedToBladelogic = snowU_AssignedToBladelogic;
	}

	public String getSnowU_AssignmentStatus() {
		return snowU_AssignmentStatus;
	}

	public void setSnowU_AssignmentStatus(String snowU_AssignmentStatus) {
		this.snowU_AssignmentStatus = snowU_AssignmentStatus;
	}

	public String getSnowU_AttachmentsAdded() {
		return snowU_AttachmentsAdded;
	}

	public void setSnowU_AttachmentsAdded(String snowU_AttachmentsAdded) {
		this.snowU_AttachmentsAdded = snowU_AttachmentsAdded;
	}

	public String getSnowU_AuditCode() {
		return snowU_AuditCode;
	}

	public void setSnowU_AuditCode(String snowU_AuditCode) {
		this.snowU_AuditCode = snowU_AuditCode;
	}

	public String getSnowU_AutoClose() {
		return snowU_AutoClose;
	}

	public void setSnowU_AutoClose(String snowU_AutoClose) {
		this.snowU_AutoClose = snowU_AutoClose;
	}

	public String getSnowU_AutoCloseTicket() {
		return snowU_AutoCloseTicket;
	}

	public void setSnowU_AutoCloseTicket(String snowU_AutoCloseTicket) {
		this.snowU_AutoCloseTicket = snowU_AutoCloseTicket;
	}

	public String getSnowU_AutoParm1() {
		return snowU_AutoParm1;
	}

	public void setSnowU_AutoParm1(String snowU_AutoParm1) {
		this.snowU_AutoParm1 = snowU_AutoParm1;
	}

	public String getSnowU_AutoParm2() {
		return snowU_AutoParm2;
	}

	public void setSnowU_AutoParm2(String snowU_AutoParm2) {
		this.snowU_AutoParm2 = snowU_AutoParm2;
	}

	public String getSnowU_AutoParm3() {
		return snowU_AutoParm3;
	}

	public void setSnowU_AutoParm3(String snowU_AutoParm3) {
		this.snowU_AutoParm3 = snowU_AutoParm3;
	}

	public String getSnowU_AutoParm4() {
		return snowU_AutoParm4;
	}

	public void setSnowU_AutoParm4(String snowU_AutoParm4) {
		this.snowU_AutoParm4 = snowU_AutoParm4;
	}

	public String getSnowU_AutoParm5() {
		return snowU_AutoParm5;
	}

	public void setSnowU_AutoParm5(String snowU_AutoParm5) {
		this.snowU_AutoParm5 = snowU_AutoParm5;
	}

	public String getSnowU_AutoTarget() {
		return snowU_AutoTarget;
	}

	public void setSnowU_AutoTarget(String snowU_AutoTarget) {
		this.snowU_AutoTarget = snowU_AutoTarget;
	}

	public String getSnowU_AutoType() {
		return snowU_AutoType;
	}

	public void setSnowU_AutoType(String snowU_AutoType) {
		this.snowU_AutoType = snowU_AutoType;
	}

	public String getSnowU_AvailAddComments() {
		return snowU_AvailAddComments;
	}

	public void setSnowU_AvailAddComments(String snowU_AvailAddComments) {
		this.snowU_AvailAddComments = snowU_AvailAddComments;
	}

	public String getSnowU_AvailTechSvc() {
		return snowU_AvailTechSvc;
	}

	public void setSnowU_AvailTechSvc(String snowU_AvailTechSvc) {
		this.snowU_AvailTechSvc = snowU_AvailTechSvc;
	}

	public String getSnowU_AvailabilityReport() {
		return snowU_AvailabilityReport;
	}

	public void setSnowU_AvailabilityReport(String snowU_AvailabilityReport) {
		this.snowU_AvailabilityReport = snowU_AvailabilityReport;
	}

	public String getSnowU_BsdResolutionBy() {
		return snowU_BsdResolutionBy;
	}

	public void setSnowU_BsdResolutionBy(String snowU_BsdResolutionBy) {
		this.snowU_BsdResolutionBy = snowU_BsdResolutionBy;
	}

	public String getSnowU_BusinessService() {
		return snowU_BusinessService;
	}

	public void setSnowU_BusinessService(String snowU_BusinessService) {
		this.snowU_BusinessService = snowU_BusinessService;
	}

	public String getSnowU_CallCaptureComments() {
		return snowU_CallCaptureComments;
	}

	public void setSnowU_CallCaptureComments(String snowU_CallCaptureComments) {
		this.snowU_CallCaptureComments = snowU_CallCaptureComments;
	}

	public String getSnowU_CallHandlingComments() {
		return snowU_CallHandlingComments;
	}

	public void setSnowU_CallHandlingComments(String snowU_CallHandlingComments) {
		this.snowU_CallHandlingComments = snowU_CallHandlingComments;
	}

	public String getSnowU_CauseItem() {
		return snowU_CauseItem;
	}

	public void setSnowU_CauseItem(String snowU_CauseItem) {
		this.snowU_CauseItem = snowU_CauseItem;
	}

	public String getSnowU_CausedBy() {
		return snowU_CausedBy;
	}

	public void setSnowU_CausedBy(String snowU_CausedBy) {
		this.snowU_CausedBy = snowU_CausedBy;
	}

	public String getSnowU_ChangeManager() {
		return snowU_ChangeManager;
	}

	public void setSnowU_ChangeManager(String snowU_ChangeManager) {
		this.snowU_ChangeManager = snowU_ChangeManager;
	}

	public String getSnowU_Classification() {
		return snowU_Classification;
	}

	public void setSnowU_Classification(String snowU_Classification) {
		this.snowU_Classification = snowU_Classification;
	}

	public String getSnowU_ClosedPeriod() {
		return snowU_ClosedPeriod;
	}

	public void setSnowU_ClosedPeriod(String snowU_ClosedPeriod) {
		this.snowU_ClosedPeriod = snowU_ClosedPeriod;
	}

	public String getSnowU_ClosureCategory() {
		return snowU_ClosureCategory;
	}

	public void setSnowU_ClosureCategory(String snowU_ClosureCategory) {
		this.snowU_ClosureCategory = snowU_ClosureCategory;
	}

	public String getSnowU_CommentType() {
		return snowU_CommentType;
	}

	public void setSnowU_CommentType(String snowU_CommentType) {
		this.snowU_CommentType = snowU_CommentType;
	}

	public String getSnowU_CommentTypeHandling() {
		return snowU_CommentTypeHandling;
	}

	public void setSnowU_CommentTypeHandling(String snowU_CommentTypeHandling) {
		this.snowU_CommentTypeHandling = snowU_CommentTypeHandling;
	}

	public String getSnowU_CommentsAndWorkNotes() {
		return snowU_CommentsAndWorkNotes;
	}

	public void setSnowU_CommentsAndWorkNotes(String snowU_CommentsAndWorkNotes) {
		this.snowU_CommentsAndWorkNotes = snowU_CommentsAndWorkNotes;
	}

	public String getSnowU_DesktopAssetNumber() {
		return snowU_DesktopAssetNumber;
	}

	public void setSnowU_DesktopAssetNumber(String snowU_DesktopAssetNumber) {
		this.snowU_DesktopAssetNumber = snowU_DesktopAssetNumber;
	}

	public String getSnowU_DesktopMake() {
		return snowU_DesktopMake;
	}

	public void setSnowU_DesktopMake(String snowU_DesktopMake) {
		this.snowU_DesktopMake = snowU_DesktopMake;
	}

	public String getSnowU_DesktopModel() {
		return snowU_DesktopModel;
	}

	public void setSnowU_DesktopModel(String snowU_DesktopModel) {
		this.snowU_DesktopModel = snowU_DesktopModel;
	}

	public String getSnowU_DesktopSN() {
		return snowU_DesktopSN;
	}

	public void setSnowU_DesktopSN(String snowU_DesktopSN) {
		this.snowU_DesktopSN = snowU_DesktopSN;
	}

	public String getSnowU_Escalated() {
		return snowU_Escalated;
	}

	public void setSnowU_Escalated(String snowU_Escalated) {
		this.snowU_Escalated = snowU_Escalated;
	}

	public String getSnowU_ExpertHelp() {
		return snowU_ExpertHelp;
	}

	public void setSnowU_ExpertHelp(String snowU_ExpertHelp) {
		this.snowU_ExpertHelp = snowU_ExpertHelp;
	}

	public String getSnowU_ExternalRef() {
		return snowU_ExternalRef;
	}

	public void setSnowU_ExternalRef(String snowU_ExternalRef) {
		this.snowU_ExternalRef = snowU_ExternalRef;
	}

	public String getSnowU_FeedbackCode() {
		return snowU_FeedbackCode;
	}

	public void setSnowU_FeedbackCode(String snowU_FeedbackCode) {
		this.snowU_FeedbackCode = snowU_FeedbackCode;
	}

	public String getSnowU_FeedbackCodeHandling() {
		return snowU_FeedbackCodeHandling;
	}

	public void setSnowU_FeedbackCodeHandling(String snowU_FeedbackCodeHandling) {
		this.snowU_FeedbackCodeHandling = snowU_FeedbackCodeHandling;
	}

	public String getSnowU_FirstDeadline() {
		return snowU_FirstDeadline;
	}

	public void setSnowU_FirstDeadline(String snowU_FirstDeadline) {
		this.snowU_FirstDeadline = snowU_FirstDeadline;
	}

	public String getSnowU_Folder() {
		return snowU_Folder;
	}

	public void setSnowU_Folder(String snowU_Folder) {
		this.snowU_Folder = snowU_Folder;
	}

	public String getSnowU_ImpBreakdown() {
		return snowU_ImpBreakdown;
	}

	public void setSnowU_ImpBreakdown(String snowU_ImpBreakdown) {
		this.snowU_ImpBreakdown = snowU_ImpBreakdown;
	}

	public String getSnowU_InitialAssignment() {
		return snowU_InitialAssignment;
	}

	public void setSnowU_InitialAssignment(String snowU_InitialAssignment) {
		this.snowU_InitialAssignment = snowU_InitialAssignment;
	}

	public String getSnowU_Instructions() {
		return snowU_Instructions;
	}

	public void setSnowU_Instructions(String snowU_Instructions) {
		this.snowU_Instructions = snowU_Instructions;
	}

	public String getSnowU_InternalRef() {
		return snowU_InternalRef;
	}

	public void setSnowU_InternalRef(String snowU_InternalRef) {
		this.snowU_InternalRef = snowU_InternalRef;
	}

	public String getSnowU_ItilWatchList() {
		return snowU_ItilWatchList;
	}

	public void setSnowU_ItilWatchList(String snowU_ItilWatchList) {
		this.snowU_ItilWatchList = snowU_ItilWatchList;
	}

	public String getSnowU_KnowledgeArticle() {
		return snowU_KnowledgeArticle;
	}

	public void setSnowU_KnowledgeArticle(String snowU_KnowledgeArticle) {
		this.snowU_KnowledgeArticle = snowU_KnowledgeArticle;
	}

	public String getSnowU_KnowledgeAvailable() {
		return snowU_KnowledgeAvailable;
	}

	public void setSnowU_KnowledgeAvailable(String snowU_KnowledgeAvailable) {
		this.snowU_KnowledgeAvailable = snowU_KnowledgeAvailable;
	}

	public String getSnowU_KnowledgeCode() {
		return snowU_KnowledgeCode;
	}

	public void setSnowU_KnowledgeCode(String snowU_KnowledgeCode) {
		this.snowU_KnowledgeCode = snowU_KnowledgeCode;
	}

	public String getSnowU_KnowledgeComments() {
		return snowU_KnowledgeComments;
	}

	public void setSnowU_KnowledgeComments(String snowU_KnowledgeComments) {
		this.snowU_KnowledgeComments = snowU_KnowledgeComments;
	}

	public String getSnowU_KnowledgeFound() {
		return snowU_KnowledgeFound;
	}

	public void setSnowU_KnowledgeFound(String snowU_KnowledgeFound) {
		this.snowU_KnowledgeFound = snowU_KnowledgeFound;
	}

	public String getSnowU_KnowledgeUser() {
		return snowU_KnowledgeUser;
	}

	public void setSnowU_KnowledgeUser(String snowU_KnowledgeUser) {
		this.snowU_KnowledgeUser = snowU_KnowledgeUser;
	}

	public String getSnowU_LastOccurrence() {
		return snowU_LastOccurrence;
	}

	public void setSnowU_LastOccurrence(String snowU_LastOccurrence) {
		this.snowU_LastOccurrence = snowU_LastOccurrence;
	}

	public String getSnowU_LateImpReason() {
		return snowU_LateImpReason;
	}

	public void setSnowU_LateImpReason(String snowU_LateImpReason) {
		this.snowU_LateImpReason = snowU_LateImpReason;
	}

	public String getSnowU_LocalResp() {
		return snowU_LocalResp;
	}

	public void setSnowU_LocalResp(String snowU_LocalResp) {
		this.snowU_LocalResp = snowU_LocalResp;
	}

	public String getSnowU_ManagementAuditComments() {
		return snowU_ManagementAuditComments;
	}

	public void setSnowU_ManagementAuditComments(String snowU_ManagementAuditComments) {
		this.snowU_ManagementAuditComments = snowU_ManagementAuditComments;
	}

	public String getSnowU_ManagementComments() {
		return snowU_ManagementComments;
	}

	public void setSnowU_ManagementComments(String snowU_ManagementComments) {
		this.snowU_ManagementComments = snowU_ManagementComments;
	}

	public String getSnowU_ModifiedPeriod() {
		return snowU_ModifiedPeriod;
	}

	public void setSnowU_ModifiedPeriod(String snowU_ModifiedPeriod) {
		this.snowU_ModifiedPeriod = snowU_ModifiedPeriod;
	}

	public String getSnowU_OpenedPeriod() {
		return snowU_OpenedPeriod;
	}

	public void setSnowU_OpenedPeriod(String snowU_OpenedPeriod) {
		this.snowU_OpenedPeriod = snowU_OpenedPeriod;
	}

	public String getSnowU_OutageDuration() {
		return snowU_OutageDuration;
	}

	public void setSnowU_OutageDuration(String snowU_OutageDuration) {
		this.snowU_OutageDuration = snowU_OutageDuration;
	}

	public String getSnowU_OutsourceAssignedOut() {
		return snowU_OutsourceAssignedOut;
	}

	public void setSnowU_OutsourceAssignedOut(String snowU_OutsourceAssignedOut) {
		this.snowU_OutsourceAssignedOut = snowU_OutsourceAssignedOut;
	}

	public String getSnowU_OutsourceAssignee() {
		return snowU_OutsourceAssignee;
	}

	public void setSnowU_OutsourceAssignee(String snowU_OutsourceAssignee) {
		this.snowU_OutsourceAssignee = snowU_OutsourceAssignee;
	}

	public String getSnowU_OutsourceId() {
		return snowU_OutsourceId;
	}

	public void setSnowU_OutsourceId(String snowU_OutsourceId) {
		this.snowU_OutsourceId = snowU_OutsourceId;
	}

	public String getSnowU_OutsourceIntegration() {
		return snowU_OutsourceIntegration;
	}

	public void setSnowU_OutsourceIntegration(String snowU_OutsourceIntegration) {
		this.snowU_OutsourceIntegration = snowU_OutsourceIntegration;
	}

	public String getSnowU_OutsourceModule() {
		return snowU_OutsourceModule;
	}

	public void setSnowU_OutsourceModule(String snowU_OutsourceModule) {
		this.snowU_OutsourceModule = snowU_OutsourceModule;
	}

	public String getSnowU_OutsourceResponse() {
		return snowU_OutsourceResponse;
	}

	public void setSnowU_OutsourceResponse(String snowU_OutsourceResponse) {
		this.snowU_OutsourceResponse = snowU_OutsourceResponse;
	}

	public String getSnowU_OutsourceResult() {
		return snowU_OutsourceResult;
	}

	public void setSnowU_OutsourceResult(String snowU_OutsourceResult) {
		this.snowU_OutsourceResult = snowU_OutsourceResult;
	}

	public String getSnowU_OutsourceStatus() {
		return snowU_OutsourceStatus;
	}

	public void setSnowU_OutsourceStatus(String snowU_OutsourceStatus) {
		this.snowU_OutsourceStatus = snowU_OutsourceStatus;
	}

	public String getSnowU_OutsourceTeam() {
		return snowU_OutsourceTeam;
	}

	public void setSnowU_OutsourceTeam(String snowU_OutsourceTeam) {
		this.snowU_OutsourceTeam = snowU_OutsourceTeam;
	}

	public String getSnowU_Override1() {
		return snowU_Override1;
	}

	public void setSnowU_Override1(String snowU_Override1) {
		this.snowU_Override1 = snowU_Override1;
	}

	public String getSnowU_Person() {
		return snowU_Person;
	}

	public void setSnowU_Person(String snowU_Person) {
		this.snowU_Person = snowU_Person;
	}

	public String getSnowU_PersonAudited() {
		return snowU_PersonAudited;
	}

	public void setSnowU_PersonAudited(String snowU_PersonAudited) {
		this.snowU_PersonAudited = snowU_PersonAudited;
	}

	public String getSnowU_PersonAuditing() {
		return snowU_PersonAuditing;
	}

	public void setSnowU_PersonAuditing(String snowU_PersonAuditing) {
		this.snowU_PersonAuditing = snowU_PersonAuditing;
	}

	public String getSnowU_Phone() {
		return snowU_Phone;
	}

	public void setSnowU_Phone(String snowU_Phone) {
		this.snowU_Phone = snowU_Phone;
	}

	public String getSnowU_PickupDuration() {
		return snowU_PickupDuration;
	}

	public void setSnowU_PickupDuration(String snowU_PickupDuration) {
		this.snowU_PickupDuration = snowU_PickupDuration;
	}

	public String getSnowU_PlannedEffort() {
		return snowU_PlannedEffort;
	}

	public void setSnowU_PlannedEffort(String snowU_PlannedEffort) {
		this.snowU_PlannedEffort = snowU_PlannedEffort;
	}

	public String getSnowU_PlannedImplementationWeek() {
		return snowU_PlannedImplementationWeek;
	}

	public void setSnowU_PlannedImplementationWeek(String snowU_PlannedImplementationWeek) {
		this.snowU_PlannedImplementationWeek = snowU_PlannedImplementationWeek;
	}

	public String getSnowU_PreviousGroup() {
		return snowU_PreviousGroup;
	}

	public void setSnowU_PreviousGroup(String snowU_PreviousGroup) {
		this.snowU_PreviousGroup = snowU_PreviousGroup;
	}

	public String getSnowU_QueryCount() {
		return snowU_QueryCount;
	}

	public void setSnowU_QueryCount(String snowU_QueryCount) {
		this.snowU_QueryCount = snowU_QueryCount;
	}

	public String getSnowU_RegionImpacted() {
		return snowU_RegionImpacted;
	}

	public void setSnowU_RegionImpacted(String snowU_RegionImpacted) {
		this.snowU_RegionImpacted = snowU_RegionImpacted;
	}

	public String getSnowU_RelatedIncidents() {
		return snowU_RelatedIncidents;
	}

	public void setSnowU_RelatedIncidents(String snowU_RelatedIncidents) {
		this.snowU_RelatedIncidents = snowU_RelatedIncidents;
	}

	public String getSnowU_ReopenCount() {
		return snowU_ReopenCount;
	}

	public void setSnowU_ReopenCount(String snowU_ReopenCount) {
		this.snowU_ReopenCount = snowU_ReopenCount;
	}

	public String getSnowU_ReopenedDate() {
		return snowU_ReopenedDate;
	}

	public void setSnowU_ReopenedDate(String snowU_ReopenedDate) {
		this.snowU_ReopenedDate = snowU_ReopenedDate;
	}

	public String getSnowU_ResolutionOverride() {
		return snowU_ResolutionOverride;
	}

	public void setSnowU_ResolutionOverride(String snowU_ResolutionOverride) {
		this.snowU_ResolutionOverride = snowU_ResolutionOverride;
	}

	public String getSnowU_ResolvedBy() {
		return snowU_ResolvedBy;
	}

	public void setSnowU_ResolvedBy(String snowU_ResolvedBy) {
		this.snowU_ResolvedBy = snowU_ResolvedBy;
	}

	public String getSnowU_ResolvedByWorkgroup() {
		return snowU_ResolvedByWorkgroup;
	}

	public void setSnowU_ResolvedByWorkgroup(String snowU_ResolvedByWorkgroup) {
		this.snowU_ResolvedByWorkgroup = snowU_ResolvedByWorkgroup;
	}

	public String getSnowU_Resolver() {
		return snowU_Resolver;
	}

	public void setSnowU_Resolver(String snowU_Resolver) {
		this.snowU_Resolver = snowU_Resolver;
	}

	public String getSnowU_ResponseFlag() {
		return snowU_ResponseFlag;
	}

	public void setSnowU_ResponseFlag(String snowU_ResponseFlag) {
		this.snowU_ResponseFlag = snowU_ResponseFlag;
	}

	public String getSnowU_ResponseOverride() {
		return snowU_ResponseOverride;
	}

	public void setSnowU_ResponseOverride(String snowU_ResponseOverride) {
		this.snowU_ResponseOverride = snowU_ResponseOverride;
	}

	public String getSnowU_SavedCount() {
		return snowU_SavedCount;
	}

	public void setSnowU_SavedCount(String snowU_SavedCount) {
		this.snowU_SavedCount = snowU_SavedCount;
	}

	public String getSnowU_SecondDeadline() {
		return snowU_SecondDeadline;
	}

	public void setSnowU_SecondDeadline(String snowU_SecondDeadline) {
		this.snowU_SecondDeadline = snowU_SecondDeadline;
	}

	public String getSnowU_SelectApplication() {
		return snowU_SelectApplication;
	}

	public void setSnowU_SelectApplication(String snowU_SelectApplication) {
		this.snowU_SelectApplication = snowU_SelectApplication;
	}

	public String getSnowU_SelectEuc() {
		return snowU_SelectEuc;
	}

	public void setSnowU_SelectEuc(String snowU_SelectEuc) {
		this.snowU_SelectEuc = snowU_SelectEuc;
	}

	public String getSnowU_SelectInfrastructure() {
		return snowU_SelectInfrastructure;
	}

	public void setSnowU_SelectInfrastructure(String snowU_SelectInfrastructure) {
		this.snowU_SelectInfrastructure = snowU_SelectInfrastructure;
	}

	public String getSnowU_SelectNetwork() {
		return snowU_SelectNetwork;
	}

	public void setSnowU_SelectNetwork(String snowU_SelectNetwork) {
		this.snowU_SelectNetwork = snowU_SelectNetwork;
	}

	public String getSnowU_SlaFailureWorkgroup() {
		return snowU_SlaFailureWorkgroup;
	}

	public void setSnowU_SlaFailureWorkgroup(String snowU_SlaFailureWorkgroup) {
		this.snowU_SlaFailureWorkgroup = snowU_SlaFailureWorkgroup;
	}

	public String getSnowU_SlaState() {
		return snowU_SlaState;
	}

	public void setSnowU_SlaState(String snowU_SlaState) {
		this.snowU_SlaState = snowU_SlaState;
	}

	public String getSnowU_SlfApprover() {
		return snowU_SlfApprover;
	}

	public void setSnowU_SlfApprover(String snowU_SlfApprover) {
		this.snowU_SlfApprover = snowU_SlfApprover;
	}

	public String getSnowU_SlfComponent() {
		return snowU_SlfComponent;
	}

	public void setSnowU_SlfComponent(String snowU_SlfComponent) {
		this.snowU_SlfComponent = snowU_SlfComponent;
	}

	public String getSnowU_SlfReason() {
		return snowU_SlfReason;
	}

	public void setSnowU_SlfReason(String snowU_SlfReason) {
		this.snowU_SlfReason = snowU_SlfReason;
	}

	public String getSnowU_SlfReviewDate() {
		return snowU_SlfReviewDate;
	}

	public void setSnowU_SlfReviewDate(String snowU_SlfReviewDate) {
		this.snowU_SlfReviewDate = snowU_SlfReviewDate;
	}

	public String getSnowU_SrtState() {
		return snowU_SrtState;
	}

	public void setSnowU_SrtState(String snowU_SrtState) {
		this.snowU_SrtState = snowU_SrtState;
	}

	public String getSnowU_SspForm() {
		return snowU_SspForm;
	}

	public void setSnowU_SspForm(String snowU_SspForm) {
		this.snowU_SspForm = snowU_SspForm;
	}

	public String getSnowU_Subject() {
		return snowU_Subject;
	}

	public void setSnowU_Subject(String snowU_Subject) {
		this.snowU_Subject = snowU_Subject;
	}

	public String getSnowU_SupportStructure() {
		return snowU_SupportStructure;
	}

	public void setSnowU_SupportStructure(String snowU_SupportStructure) {
		this.snowU_SupportStructure = snowU_SupportStructure;
	}

	public String getSnowU_TaskType() {
		return snowU_TaskType;
	}

	public void setSnowU_TaskType(String snowU_TaskType) {
		this.snowU_TaskType = snowU_TaskType;
	}

	public String getSnowU_Template() {
		return snowU_Template;
	}

	public void setSnowU_Template(String snowU_Template) {
		this.snowU_Template = snowU_Template;
	}

	public String getSnowU_ThirdLineComments() {
		return snowU_ThirdLineComments;
	}

	public void setSnowU_ThirdLineComments(String snowU_ThirdLineComments) {
		this.snowU_ThirdLineComments = snowU_ThirdLineComments;
	}

	public String getSnowU_ThirdLineDate() {
		return snowU_ThirdLineDate;
	}

	public void setSnowU_ThirdLineDate(String snowU_ThirdLineDate) {
		this.snowU_ThirdLineDate = snowU_ThirdLineDate;
	}

	public String getSnowU_TimeToAuth() {
		return snowU_TimeToAuth;
	}

	public void setSnowU_TimeToAuth(String snowU_TimeToAuth) {
		this.snowU_TimeToAuth = snowU_TimeToAuth;
	}

	public String getSnowU_TimeToClose() {
		return snowU_TimeToClose;
	}

	public void setSnowU_TimeToClose(String snowU_TimeToClose) {
		this.snowU_TimeToClose = snowU_TimeToClose;
	}

	public String getSnowU_UsersAffected() {
		return snowU_UsersAffected;
	}

	public void setSnowU_UsersAffected(String snowU_UsersAffected) {
		this.snowU_UsersAffected = snowU_UsersAffected;
	}

	public String getSnowU_WebUpdate() {
		return snowU_WebUpdate;
	}

	public void setSnowU_WebUpdate(String snowU_WebUpdate) {
		this.snowU_WebUpdate = snowU_WebUpdate;
	}

	public String getSnowUponApproval() {
		return snowUponApproval;
	}

	public void setSnowUponApproval(String snowUponApproval) {
		this.snowUponApproval = snowUponApproval;
	}

	public String getSnowUponReject() {
		return snowUponReject;
	}

	public void setSnowUponReject(String snowUponReject) {
		this.snowUponReject = snowUponReject;
	}

	public String getSnowUrgency() {
		return snowUrgency;
	}

	public void setSnowUrgency(String snowUrgency) {
		this.snowUrgency = snowUrgency;
	}

	public String getSnowUserInput() {
		return snowUserInput;
	}

	public void setSnowUserInput(String snowUserInput) {
		this.snowUserInput = snowUserInput;
	}

	public String getSnowWatchList() {
		return snowWatchList;
	}

	public void setSnowWatchList(String snowWatchList) {
		this.snowWatchList = snowWatchList;
	}

	public String getSnowWfActivity() {
		return snowWfActivity;
	}

	public void setSnowWfActivity(String snowWfActivity) {
		this.snowWfActivity = snowWfActivity;
	}

	public String getSnowWorkEffort() {
		return snowWorkEffort;
	}

	public void setSnowWorkEffort(String snowWorkEffort) {
		this.snowWorkEffort = snowWorkEffort;
	}

	public String getSnowWorkEnd() {
		return snowWorkEnd;
	}

	public void setSnowWorkEnd(String snowWorkEnd) {
		this.snowWorkEnd = snowWorkEnd;
	}

	public String getSnowWorkNotes() {
		return snowWorkNotes;
	}

	public void setSnowWorkNotes(String snowWorkNotes) {
		this.snowWorkNotes = snowWorkNotes;
	}

	public String getSnowWorkStart() {
		return snowWorkStart;
	}

	public void setSnowWorkStart(String snowWorkStart) {
		this.snowWorkStart = snowWorkStart;
	}
	
	// ===================================================================================
	// Calculated FIELDS
	// ===================================================================================

	public Date getDtSnowU_PickupDuration() {
		dtSnowU_PickupDuration = SnowUtilities.formatToDateFromSNOW(snowU_PickupDuration);
		return dtSnowU_PickupDuration;
	}

	public void setDtSnowU_PickupDuration(Date dtSnowU_PickupDuration) {
		this.dtSnowU_PickupDuration = dtSnowU_PickupDuration;
	}

	public Date getDtSnowBusinessDuration() {
		dtSnowBusinessDuration = SnowUtilities.formatToDateFromSNOW(snowBusinessDuration);
		return dtSnowBusinessDuration;
	}

	public void setDtSnowBusinessDuration(Date dtSnowBusinessDuration) {
		this.dtSnowBusinessDuration = dtSnowBusinessDuration;
	}

	public Date getDtSnowCalendarDuration() {
		dtSnowCalendarDuration = SnowUtilities.formatToDateFromSNOW(snowCalendarDuration);
		return dtSnowCalendarDuration;
	}

	public void setDtSnowCalendarDuration(Date dtSnowCalendarDuration) {
		this.dtSnowCalendarDuration = dtSnowCalendarDuration;
	}

	public Date getDtSnowU_TimeToClose() {
		dtSnowU_TimeToClose = SnowUtilities.formatToDateFromSNOW(snowU_TimeToClose);
		return dtSnowU_TimeToClose;
	}

	public void setDtSnowU_TimeToClose(Date dtSnowU_TimeToClose) {
		this.dtSnowU_TimeToClose = dtSnowU_TimeToClose;
	}

	public Date getDtSnowSysCreatedOn() {
		dtSnowSysCreatedOn = SnowUtilities.formatToDateFromSNOW(snowSysCreatedOn);
		return dtSnowSysCreatedOn;
	}

	public void setDtSnowSysCreatedOn(Date dtSnowSysCreatedOn) {
		this.dtSnowSysCreatedOn = dtSnowSysCreatedOn;
	}

	public Date getDtSnowOpenedAt() {
		dtSnowOpenedAt = SnowUtilities.formatToDateFromSNOW(snowOpenedAt);
		return dtSnowOpenedAt;
	}

	public void setDtSnowOpenedAt(Date dtSnowOpenedAt) {
		this.dtSnowOpenedAt = dtSnowOpenedAt;
	}

	public Date getDtSnowSlaDue() {
		dtSnowSlaDue = SnowUtilities.formatToDateFromSNOW(snowSlaDue);
		return dtSnowSlaDue;
	}

	public void setDtSnowSlaDue(Date dtSnowSlaDue) {
		this.dtSnowSlaDue = dtSnowSlaDue;
	}

	public Date getDtSnowU_ActualStart() {
		dtSnowU_ActualStart = SnowUtilities.formatToDateFromSNOW(snowU_ActualStart);
		return dtSnowU_ActualStart;
	}

	public void setDtSnowU_ActualStart(Date dtSnowU_ActualStart) {
		this.dtSnowU_ActualStart = dtSnowU_ActualStart;
	}

	public Date getDtSnowClosedAt() {
		dtSnowClosedAt = SnowUtilities.formatToDateFromSNOW(snowClosedAt);
		return dtSnowClosedAt;
	}

	public void setDtSnowClosedAt(Date dtSnowClosedAt) {
		this.dtSnowClosedAt = dtSnowClosedAt;
	}

	public Date getDtSnowU_AofDateTime() {
		dtSnowU_AofDateTime = SnowUtilities.formatToDateFromSNOW(snowU_AofDateTime);
		return dtSnowU_AofDateTime;
	}

	public void setDtSnowU_AofDateTime(Date dtSnowU_AofDateTime) {
		this.dtSnowU_AofDateTime = dtSnowU_AofDateTime;
	}

	public Date getDtSnowU_AosDateTime() {
		dtSnowU_AosDateTime = SnowUtilities.formatToDateFromSNOW(snowU_AosDateTime);
		return dtSnowU_AosDateTime;
	}

	public void setDtSnowU_AosDateTime(Date dtSnowU_AosDateTime) {
		this.dtSnowU_AosDateTime = dtSnowU_AosDateTime;
	}
	
}
