package com.fedex.dashboard.model;

public class HubAppBean {
	private String hubLocation;
	private String appName;
	private String serverStatus;
	
	public String getHubLocation() {
		return hubLocation;
	}
	public void setHubLocation(String hubLocation) {
		this.hubLocation = hubLocation;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getServerStatus() {
		return serverStatus;
	}
	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}
	@Override
	public String toString() {
		return "DashboardBean [hubLocation=" + hubLocation + ", appName=" + appName + ", serverStatus=" + serverStatus + "]\n";
	}
}
