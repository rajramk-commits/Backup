<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
    <%@page import="java.util.*"%> 
    <%@page import="com.fedex.emea.sabreReport.model.*"%>
  <jsp:useBean id="ReportDataService" class="com.fedex.emea.sabreReport.service.ReportDataService" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
String startDate = request.getParameter("startDate");
String endDate = request.getParameter("endDate");
String appTeam = request.getParameter("appTeam");
System.out.println("startDate :"+startDate);
System.out.println("endDate :"+endDate);
System.out.println("appTeam :"+appTeam);
request.getSession().setAttribute("SDate", startDate);
request.getSession().setAttribute("EDate", endDate);

if(appTeam.equalsIgnoreCase("Sabre"))
{
	List<SabreBean> sabreList  = ReportDataService.generateReport(startDate, endDate);
	if(sabreList == null || sabreList.size() == 0)
	{
		response.sendRedirect("SabreHomePage.jsp");
	}
	else
	{
		System.out.println("Result Data1:"+sabreList);
		request.getSession().setAttribute("sabreList", sabreList);
		response.sendRedirect("BarChart.jsp");
	}
}

else if(appTeam.equalsIgnoreCase("Gss"))
{
	List<SabreBean> gssList  = ReportDataService.generateGSSReport(startDate, endDate);	
	if(gssList == null || gssList.size() == 0)
	{
		response.sendRedirect("GssHomePage.jsp");
	}
	else
	{
		System.out.println("Result Data:"+gssList);
		request.getSession().setAttribute("gssList", gssList);
		response.sendRedirect("BarChartGss.jsp");
	}
}

%>
</body>
</html>