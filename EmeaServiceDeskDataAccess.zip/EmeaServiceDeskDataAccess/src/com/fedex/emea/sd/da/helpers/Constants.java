package com.fedex.emea.sd.da.helpers;

public class Constants {
	// Processing Status
	public static final int PROCESSING  = 2;
	public static final int COMPLETED   = 1;
	public static final int ERROR       = 9;
	public static final int UNPROCESSED = 0;
	
	public static final int FAILURE    = 5;
	public static final int REMINDER   = 6;
	public static final int REOPEN     = 7;
	
	// Used in OVO => Alert Criticality
	public static final String ALERT_CRITICAL           = "CRITICAL";
	public static final String ALERT_MAJOR              = "MAJOR";
	public static final String ALERT_MINOR              = "MINOR";;
	public static final String ALERT_WARNING            = "WARNING";
	// Used in OVO => Alert App Group
	public static final String APP_GROUP_SYSTEM         = "SYSTEM";
	public static final String APP_GROUP_EISTC          = "EISTC_SUPPORT";
	public static final String APP_GROUP_HA             = "HA";
	public static final String APP_GROUP_APPLICATION    = "APPLICATION";
	public static final String APP_GROUP_DATABASE       = "DATABASE";
	public static final String APP_GROUP_UNIV           = "UNIV_SCHEDULER";
	public static final String APP_GROUP_SSA            = "SSA";
	public static final String APP_GROUP_IMDS           = "IMDS";
	public static final String APP_GROUP_JOB            = "JOB";
	public static final String APP_GROUP_OS             = "OS";
	public static final String APP_GROUP_HARDWARE       = "HARDWARE";
	public static final String APP_GROUP_SAN            = "SAN";
	public static final String APP_GROUP_STORAGE        = "STORAGE";
	public static final String APP_GROUP_NETWORK        = "NETWORK";
	// Used in OVO => Alert App Name
	public static final String APP_NAME_PING            = "PING";
	public static final String APP_NAME_OBM             = "OBM";
	public static final String APP_NAME_FS              = "FS";
	public static final String APP_NAME_MONITOR         = "MONITOR";
	public static final String APP_NAME_EVENTLOG        = "EVENTLOG";
	public static final String APP_NAME_OS              = "OS";
	public static final String APP_NAME_SRV_CTRL_MGR    = "SERVICE CONTROL MANAGER";
	public static final String APP_NAME_VCS             = "VCS";
	public static final String APP_NAME_DEVICE          = "DEVICE";
	public static final String APP_NAME_LINUX           = "LINUX";
	public static final String APP_NAME_MCE             = "MCE";
	public static final String APP_NAME_SYSLOGD         = "SYSLOGD";
	public static final String APP_NAME_VXVM            = "VXVM";
	public static final String APP_NAME_WINDOWS         = "WINDOWS";
	public static final String APP_NAME_EISTC           = "EISTC";
	public static final String APP_NAME_ORACLE          = "ORACLE";
	public static final String APP_NAME_UNIV            = "UNIV_SCHEDULER";
	public static final String APP_NAME_GCM             = "GCM";
	public static final String APP_NAME_MITOOLS         = "MITOOLS";
	public static final String APP_NAME_ITOQMON         = "ITOQMON";
	public static final String APP_NAME_CITRIX          = "CITRIX";
	
	// Used in OVO => Alert Object
	public static final String OBJ_PING                 = "PING";
	public static final String OBJ_REBOOT               = "REBOOT";
	public static final String OBJ_BU_MEDIA             = "BACKUP EXEC DEVICE & MEDIA SERVICE SERVICE";
	public static final String OBJ_CITRIX_XENAPP        = "CITRIX XENAPP COMMANDS REMOTING SERVICE";
	public static final String OBJ_CITRIX_WMI           = "CITRIX WMI SERVICE";
	public static final String OBJ_PALDRV               = "PALDRV SERVICE";
	public static final String OBJ_LINUX                = "LINUX";
	public static final String OBJ_MULTIPATHD           = "MULTIPATHD";
	public static final String OBJ_CLUSTER              = "CLUSTER";
	public static final String OBJ_SERVICE              = "SERVICE";
	public static final String OBJ_JOBSTATUS            = "JOBSTATUS";
	// Used in OVO
	public static final String _LINE = "___________________________________________________________________________________";
	
	// Used in OVO/ANTC
	public static final long PRODUCTION_ALERT_INTERVAL     = 8 * 60 * 60;       // 8 Hours for Production Servers
	public static final long NON_PRODUCTION_ALERT_INTERVAL = 72 * 60 * 60;  // 72 Hours for Non-Production Servers
	public static final long DEFAULT_8H_ALERT_INTERVAL     = 8 * 60 * 60;       // 8 Hours
	
	// Used in OVO/ANTC => Record Source
	public static final String WEBSSD                   = "WEB-SSD";
	public static final String ADDNOTE                  = "ADD-NOTE";
	public static final String OBM                      = "OBM";
	public static final String SELF_SERVICE_TICKET		= "SELF-SRV";
	public static final String SELF_SERVICE_NPF			= "SELF-NPF";
	
	public static final String ANY_DASHBOARD            = "_DASHBOARD";
	public static final String DASHBOARD_ALERT          = "DASHBOARD_ALERT";
	public static final String GENIUS_PREPROD_DASHBOARD = "GENIUS_PREPROD_DASHBOARD";
	public static final String RIH_PROD_DASHBOARD       = "RIH_PROD_DASHBOARD";
	public static final String BIS_PROD_DASHBOARD       = "BIS_PROD_DASHBOARD";
	public static final String GENIUS_PROD_DASHBOARD    = "GENIUS_PROD_DASHBOARD";
	public static final String GEMINI_PROD_DASHBOARD 	= "GEMINI_PROD_DASHBOARD";
	public static final String EISTC_PROD_DASHBOARD     = "EISTC_PROD_DASHBOARD";
	public static final String CDG_PROD_DASHBOARD       = "CDG_PROD_DASHBOARD";
	public static final String CGN_PROD_DASHBOARD       = "CGN_PROD_DASHBOARD";
	public static final String DE_PROD_DASHBOARD        = "DE_PROD_DASHBOARD";
	public static final String SCM_PROD_DASHBOARD       = "SCM_PROD_DASHBOARD";
	public static final String UK_PROD_DASHBOARD        = "UK_PROD_DASHBOARD";
	public static final String MISC_PROD_DASHBOARD      = "MISC_PROD_DASHBOARD";
	public static final String POLAND_PROD_DASHBOARD    = "POLAND_PROD_DASHBOARD";
	public static final String ITIH_PROD_DASHBOARD      = "ITIH_PROD_DASHBOARD";
	public static final String HUBSTACK_PROD_DASHBOARD  = "HUBSTACK_PROD_DASHBOARD";
	public static final String DIMM                     = "DIMM";
	public static final String CT_PROD_DASHBOARD      	= "CT_PROD_DASHBOARD";
	public static final String EDGE_PROD_DASHBOARD      = "EDGE_PROD_DASHBOARD";
	public static final String XSORT_PROD_DASHBOARD     = "XSORT_PROD_DASHBOARD";//adding for XSORT
	public static final String PRICING_PROD_DASHBOARD   = "PRICING_PROD_DASHBOARD"; // adding for Intl pricing and Rating
	
	//MAILING
	public static final String MAIL_CLEARANCE            = "MAIL_CLEARANCE";
	
	
	public static final String DEV_DASHBOARD            = "DEV_DASHBOARD";
	
	public static final String COMPONENT_FILESYSTEM      = "FILE_SYSTEM";
	public static final String COMPONENT_SERVERREBOOT    = "ServerRebootDetection";
	public static final String COMPONENT_SERVERREACHABLE = "ServerReachableDetection";
	public static final String COMPONENT_SERVERRESPONSE  = "ServerResponseDetection";
	public static final String PRODUCTION                = "Production";
	// Used in OVO/ANTC => Case Status
	public static final String CASE_STATUS_NEW_CASE      = "OPEN";		// Open Category
	public static final String CASE_STATUS_WIP_TIER3     = "PENT3";		// Open Category
	public static final String CASE_STATUS_WIP_SD        = "WORK";		// Open Category
	public static final String CASE_STATUS_PENDING_TIER3 = "PEND3";		// Open Category
	public static final String CASE_STATUS_PENDING_CLT   = "RWCC";		// Open Category
	
	public static final String CASE_STATUS_CLOSE         = "CLOS";		// Close Category
	public static final String CASE_STATUS_DUPLICATED    = "DUP";		// Close Category
	public static final String CASE_STATUS_OUTOFSCOPE    = "OOS";		// Close Category
	public static final String CASE_STATUS_SOLVED        = "RESOL";		// Close Category
	// Used in OVO/ANTC => Case Priority
	public static final String CASE_PRIORITY_CRITICAL   = "CRIT";
	public static final String CASE_PRIORITY_TOOHIGH    = "TOOHIGH";
	public static final String CASE_PRIORITY_HIGH       = "HIGH";
	public static final String CASE_PRIORITY_MEDIUM     = "MED";
	public static final String CASE_PRIORITY_LOW        = "LOW";
	// Used in OVO/ANTC => Case Type
	public static final String CASE_TYPE_INCIDENT       = "INCID";
	public static final String CASE_TYPE_PROBLEM        = "PRBL";
	public static final String CASE_TYPE_SRV_REQ        = "SREQ";
	// Used in OVO/ANTC => Provider Group Id's
	public static final String PROVIDER_HELPDESK        = "Helpdesk";
	public static final String PROVIDER_SD_APP_SUPPORT  = "SD_APP_SUP";
	public static final String PROVIDER_SSA_NT          = "SSA_NT";
	public static final String PROVIDER_SSA_UNIX        = "SSA_UNIX";
	public static final String FXE_SA_EU_LINUX        = "FXE_SA_EU_LINUX";
	public static final String PROVIDER_SSA_SAN         = "SSA_SAN";
	public static final String PROVIDER_DBA             = "DB_SUP";
	public static final String PROVIDER_NE_LAN          = "NE_LAN/WAN";
	public static final String PROVIDER_NE_VOICE        = "NE_VOICE";
	public static final String PROVIDER_HUBSTACK        = "HUBSTACK";
	public static final String PROVIDER_CLEARANCE       = "CLEARANCE";
	public static final String PROVIDER_ATLAS           = "ATLAS";      //new
	
	// Used in OVO/ANTC => OS Type & Version
	public static final String OS_WINDOWS               = "Windows";
	public static final String OS_MSWINDOWS             = "MS Windows";
	public static final String OS_LINUX                 = "Linux";
	public static final String OS_VMESX                 = "VmWare ESX";
	public static final String OS_LINUX_REDHAT          = "RH";
	
	public static final String OS_LINUX_WINDOWS         = "1";
	public static final String OS_UNIX                  = "2";
	public static final String OS_OTHER                 = "3";
	public static final String OS_NA                    = "0";
	
	// Used in OVO/ANTC => Business Unit
	public static final String BU_SDESK                 = "SDESK";
	public static final String BU_ATLAS                 = "ATLAS";
	public static final String BU_SSA                   = "SSA";
	
	
	
	// Dashboard Alert fields
	public static final String ALERT_TYPE           = "Type";
	public static final String IMPACTED_SERVER      = "Server";
	public static final String IMPACTED_COMPONENT   = "Component";
	public static final String IMPACTED_APPLICATION = "Application";
	public static final String IMPACTED_MODULE      = "Module";
	public static final String ALERT_MESSAGE        = "Message";
	public static final String ALERT_ACTION         = "Action";
	
	// Parameter Names for NEXUS Interface Listener
	public static final String LISTENER_INTERVAL       = "listener.interval.seconds";
	public static final String MAIL_SERVER_DNS         = "mail.server.dns";
	public static final String MAIL_SERVER_PORT        = "mail.server.port";
	public static final String MAIL_NOTIFICATION_FROM  = "mail.notification.from";
	public static final String LAST_PURGE              = "last.purge";
		
	// Parameter Names for NEXUS Communicator
	public static final String NEXUS_SERVER_NAME       = "nexus.server.name";
	public static final String NEXUS_SERVER_PORT       = "nexus.server.port";
	public static final String NEXUS_USER_ID           = "nexus.user.id";
	public static final String NEXUS_PASSWORD          = "nexus.password";
	public static final String NEXUS_CASE_CONTACT_PIN  = "nexus.case.contact.pin";
	public static final String NEXUS_CASE_CONTACT_BOID = "nexus.case.contact.boid";
	
	// Parameter Names for OVO acknowledgment
	public static final String OVO_SERVER              = "obm.server";
	public static final String OVO_ANNOT_COMMAND       = "obm.annot.cmd";
	public static final String OVO_ACK_COMMAND         = "obm.ack.cmd";
	
}
