package com.fedex.emea.dimm.adaptor;

import java.util.Map;

import com.fedex.emea.dimm.config.AbstractPropertyFileBasedConfig;

public abstract class AbstractAlertDomainAdaptorConfig extends AbstractPropertyFileBasedConfig{
	
	private static final String ADAPTOR_NAME = "adaptor.name";
	
	private static final String ADAPTOR_PRIORITY = "adaptor.priority";
	
	private static final String ADAPTOR_ACTIVE = "adaptor.active";
	
	private static final String ADAPTOR_LOGICAL_KEY_TTL = "adaptor.logicalkey.ttl";
	
	private String adaptorName;
	
	private int adaptorPriority;
	
	private boolean adaptorActive;
	
	private int adaptorLogicalKeyTtlMinute;
	
	public AbstractAlertDomainAdaptorConfig() throws Exception {
		super();
	}

	@Override
	protected boolean isAutoReloadConfig() {//for alert domain adaptor configuration, it supports the hot configuration changes
		return true;
	}

	@Override
	protected void loadConfigFromProperties(Map<String, String> propertyMap)
			throws Exception {
		//first load the common properties
		String value;
		
		value = propertyMap.get(ADAPTOR_NAME);
		if(value==null || value.trim().length()==0){
			throw new Exception("Adatport Name is not configured for the file "+getPropertyFileName());
		}else{
			adaptorName = value;
		}
		
		value = propertyMap.get(ADAPTOR_PRIORITY);
		if(value==null || value.trim().length()==0){
			throw new Exception("Adaptor priority is not configured for the file "+getPropertyFileName());
		}else{
			try{
				adaptorPriority = Integer.parseInt(value.trim());
			}catch(NumberFormatException exception){
				throw new Exception("Adaptor priority configured from the file "+getPropertyFileName()+ " is not valid integer number ");
			}
		}
		
		
		value = propertyMap.get(ADAPTOR_ACTIVE);
		if(value==null || value.trim().length()==0){
			throw new Exception("Adaptor active flag is not configured for the file "+getPropertyFileName());
		}else{
			if(value.trim().equalsIgnoreCase("TRUE") || value.trim().equalsIgnoreCase("YES"))
				adaptorActive = true;
			else if(value.trim().equalsIgnoreCase("FALSE") || value.trim().equalsIgnoreCase("NO"))
				adaptorActive = false;
			else{
				throw new Exception("Adaptor active configured from the file "+getPropertyFileName()+" is not valie value [TRUE/YES/FALSE/NO]");
			}
		}
		
		value = propertyMap.get(ADAPTOR_LOGICAL_KEY_TTL);
		if(value==null || value.trim().length()==0){
			throw new Exception("Adaptor logical key time to live (minute) is not configured for the file "+getPropertyFileName());
		}else{
			try{
				adaptorLogicalKeyTtlMinute = Integer.parseInt(value.trim());
			}catch(NumberFormatException exception){
				throw new Exception("Adaptor logical key time to live (minute) configured from the file "+getPropertyFileName()+ " is not valid integer number ");
			}
		}
		
		loadAdatorSpecificConfigFromProperties(propertyMap);
	}

	public String getAdaptorName() {
		return adaptorName;
	}

	public int getAdaptorPriority() {
		return adaptorPriority;
	}
	
	public boolean isAdaptorActive() {
		return adaptorActive;
	}
	
	public int getAdaptorLogicalKeyTtlMinute() {
		return adaptorLogicalKeyTtlMinute;
	}

	protected abstract void loadAdatorSpecificConfigFromProperties(Map<String, String> propertyMap);
}
