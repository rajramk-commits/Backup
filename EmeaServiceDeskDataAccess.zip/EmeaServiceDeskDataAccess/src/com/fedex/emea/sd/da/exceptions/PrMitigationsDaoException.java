package com.fedex.emea.sd.da.exceptions;

public class PrMitigationsDaoException extends DaoException
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8374249377518763546L;

	/**
	 * Method 'PrMitigationsDaoException'
	 * 
	 * @param message
	 */
	public PrMitigationsDaoException(String message)
	{
		super(message);
	}

	/**
	 * Method 'PrMitigationsDaoException'
	 * 
	 * @param message
	 * @param cause
	 */
	public PrMitigationsDaoException(String message, Throwable cause)
	{
		super(message, cause);
	}

}
