package com.fedex.emea.sd.da.dao;

import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.fedex.emea.sd.da.mappers.DcServersRowMapper;
import com.fedex.emea.sd.da.objects.DcServers;

public class DcServersDaoImp implements DcServersDao {
	
	private JdbcTemplate jdbcTemplate;
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DcServers> loadAllServersByDataCenter(String dc) throws SQLException {
		String sql = "select NE.ID, NE.NAME, NET.TYPE, NET.DESCRIPTION, NE.LOCAL_DOMAIN_NAME, NE.STATUS, NE.SOFTWARE_VERSION" +
	                 "  from FIT_SCHEMA.NETWORKEQUIPMENT NE" + 
				     "  inner join FIT_SCHEMA.NETWORKEQUIPMENTTYPE NET on NE.DEFINING_TYPE_KEY_PK = NET.ID and upper(NET.TYPE) in ('SERVER', 'VIRTUALSERVER')" + 
				     "  where NE.LOCAL_DOMAIN_NAME = ?" +
	                 "    and NE.STATUS in ('Production', 'Pre-Production', 'Test', 'Development', 'Installed')" + 
	                 "  order by upper(NE.NAME)";
		
		return jdbcTemplate.query(sql, new Object[] {dc}, new DcServersRowMapper());
	}

	@Override
	public DcServers createValueObject() {
		return new DcServers();
	}

}
