
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%     	
        if(session.getAttribute("sessionName")==null)
        {
            response.sendRedirect("Login.jsp");
		}
		if(session.getAttribute("Sessionid").equals("User")){
			 response.sendRedirect("LoginMenu.jsp");
		}
        else{
		String userID = (String) session.getAttribute("sessionName");
		
        %>
<html>
<head>
<meta charset="UTF-8">
<title>SD Evaluation</title>
<script >

   window.history.forward();
   function noBack() { window.history.forward(); 
   }
   function openLoginMenu() {
		window.close("AddQuestion.jsp");
		 window.open("Admin.jsp");
	}
   
   function QuestionValidation(){
	   
	   if(document.getElementById("Question").value==null || document.getElementById("Question").value==""){
		   document.getElementById("OptionABlank").innerHTML="";
		   document.getElementById("OptionBBlank").innerHTML="";
		   document.getElementById("CorrectAnsBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "Please Enter the Question";
		   return false;
   		}
	   if(document.getElementById("OptionA").value==null || document.getElementById("OptionA").value==""){
		  
		   document.getElementById("OptionBBlank").innerHTML="";
		   document.getElementById("CorrectAnsBlank").innerHTML="";
		   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("OptionABlank").innerHTML = "Please Enter the Option";
		   return false;
   		}
	    if(document.getElementById("OptionB").value==null || document.getElementById("OptionB").value==""){
	    	 	document.getElementById("OptionABlank").innerHTML="";
			 
			   document.getElementById("CorrectAnsBlank").innerHTML="";
			   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("OptionBBlank").innerHTML = "Please Enter the Option";
		   return false;
   		}
	   
	    if(document.getElementById("CorrectAns").value==null || document.getElementById("CorrectAns").value==""){
	    	 document.getElementById("OptionABlank").innerHTML="";
			   document.getElementById("OptionBBlank").innerHTML="";
			   document.getElementById("QuestionBlank").innerHTML = "";
		   document.getElementById("CorrectAnsBlank").innerHTML = "Please Enter the Value";
		   return false;
   		}
	   
	    return true;
   }

</script>
<style type="text/css">
.main{
	margin-left:10%;
	margin-right:12%;
}
.head{
	height :50px;
	background-color: #7030a0;
	margin:0;
		
}
.logout{
	float:right;
	margin-right:5%;
	background-color:#FF8C00;
	color:white;
	padding:14px 20px;
	border:none;
	cursor:pointer;
}
.logout:hover{
	background-color:#4B0060;
}

input[type=submit]{
	background-color:#4B0082;
	color:white;
	padding:14px 20px;
	margin: 8px 0;
	border:none;
	cursor:pointer;
	width:20%;
}
input[type=submit]:hover{
	background-color:#7030a0;
}

textarea{
  width: 650px;
  height: 60px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  font-family:Calibri;
  
}

input[type=text]{
  width: 650px;
  height: 50px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
  
}
.quest{
  width: 650px;
  height: 100px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: #f8f8f8;
 font-family:Calibri;
}

.login{
	
	display:flex;
	justify-content:center;
}

td{
	font-size:16px;
	font-family:Calibri;
}
.home{
			
	background-color:#4B0082;
	color:white;
	padding:14px 20px;
	margin: 8px 0;
	border:none;
	cursor:pointer;
	width:20%;
}
</style>
	
</head>
<body>
		
     	<div class="main"> 
     	 <div class="head">
        	<center><p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:12px 0 0 0">Add Question</p></center>
   		</div>
   		
   		 <div style="margin:15px 0 0px 40px ;font-family:Calibri;font-size:16px">
        	<b>Welcome :</b> <%=userID %>
        </div> 
        
        <form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class ="logout" style="margin-top:6px;font-family:Calibri;font-size:16px">Logout</button>  					
		</form>  
		<button class="home" onclick="openLoginMenu()">HOME</button>
     	
     	<br><br>
     	 
    
    <form action="AddQ.jsp" method="post" onsubmit="return QuestionValidation()">
     	
		<table>
			<tr><td><div style="color:red;font-family:Calibri;">${showMessage}</div></td></tr>
			<tr>
				<td>Question<br><textarea class="quest" id="Question" name="Question" maxlength="1000" ></textarea></td>
				<td><div id="QuestionBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td><br>Option A<br><textarea id="OptionA" name="OptionA" maxlength="255"  ></textarea></td>
				<td><div id="OptionABlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td><br>Option B<br><textarea id="OptionB" name="OptionB" maxlength="255" ></textarea></td>
				<td><div id="OptionBBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
			<tr>
				<td><br>Option C<br><textarea id="OptionC" name="OptionB" maxlength="255"></textarea></td>
				
			</tr>
			<tr>
				<td><br>Option D<br><textarea id="OptionD" name="OptionB" maxlength="255"></textarea></td>
				
			</tr>
			<tr>
				<td><br>Correct Answer<br><input type="text" id="CorrectAns" name="CorrectAns" maxlength="3" ></td>
				<td><div id="CorrectAnsBlank" style="color:red;font-family:Calibri;"></div></td>
			</tr>
		</table>		
		<br>
		
		<input type="submit" name="Submit"  value="Submit" >
	</form>

        <img style="width: 100%;border:0" alt="FedExSD" src="image/menu1.PNG">
		</div>
		<div style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri">
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;© 2020 FedEx Express EMEA		
		</div>
		<%} %>
</body>
</html>