<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
    <%@page import="java.util.*"%> 
    <%@page import="com.fedex.emea.sabreReport.model.*"%>
<!DOCTYPE html>
<html>
<%
String Username = "";
String Password = "";
String userID = "";
String userRole = "";
if(session.getAttribute("sessionName")==null)
{
	userID = (String)request.getSession().getAttribute("sessionName");
	userRole = (String)request.getSession().getAttribute("Sessionid");
	System.out.println("userID request:"+userID);
	System.out.println("userRole request:"+userRole);
	 if(userID == null && userRole == null)
    	{
		System.out.println("userID userRole are null");
    	} 
}
else
{
	userID = (String) session.getAttribute("sessionName");
	System.out.println("userID:"+userID);
	userRole = (String) session.getAttribute("Sessionid");
	System.out.println("userRole:"+userRole);
}

request.getSession().setAttribute("sessionName", userID);
request.getSession().setAttribute("Sessionid", userRole);
String retStat = request.getParameter("status");

%>
<head>
<script>
function chkOnLoadStatus()
{
	<%
	if(retStat != null)
	{
	%>
		alert('<%=retStat%>');
	<%}%>
}
function validate()
{
	var value = document.getElementById("ddl2").value;
	if(value == "Select")
	{
		alert('Please select Application and Team to proceed...!!!');
		return false;
	}
	
	else if(value === "SABRE" || value === "GSS" || value === "ITIH")
	{
		var startDate = document.getElementById("startDate").value;	
		var endDate = document.getElementById("endDate").value;	
		if(!startDate)
		{
			alert("Please Enter Start Date");
			return false;
		}
		if(!endDate)
		{
			alert("Please Enter End Date");
			return false;
		}
		
		var d1 = new Date(startDate);
		var d2 = new Date(endDate);
		
		if(d1>d2)
		{
			alert("Please enter Start Date less than End Date");
			return false;
		}
		window.location = "FetchGSSData.jsp?startDate="+d1+"&endDate="+d2+"&appTeam="+value;
		return false;
	}
	else
	{
		alert('No implementations found...!!!');
		return false;
	}
}

function goTo(val)
{
	if(val == "SABRE")
	{
		window.location = "SabreHomePage.jsp";
	}
	else if(val == "GSS")
	{
		window.location = "GssHomePage.jsp";
	}
}
function logout()
{
	<%-- <% session.invalidate();%> --%>
	window.location = "Login.jsp";
}
function addUser()
{
	window.location = "addUserScreen.jsp";
	//window.close("SabreHomePage.jsp");
	//window.open("saveExcel.jsp");
	return false;
}
function configureDropDownLists(ddl1, ddl2)
{
	var div = document.getElementById("dateSel"); 
	div.style.display = "block";
	/* var div = document.getElementById("repTypeSel"); 
	div.style.display = "block"; */
	var HubstackCC  = ['SABRE', 'GSS', 'CRISP','PHASAR', 'S3.SCU', 'HORUS','HIS', 'METRIKS', 'ULDPT', 'LSRE'];
	var ClearanceCC = ['GENIUS', 'EIStC', 'DE.Blu', 'DeltaX', 'Deltapass'];
	var MISCCP = ['ITIH', 'RIH'];
	var SDApplicationSupport = ['CREDO', 'ITAPP', 'ECCP','MISC Systems', 'PL Systems', 'Supply Chain','Armada', 'Stratus', 'CED Spain','EU Paris', 'Quote Platform'];

	switch (ddl1.value) {
    case 'HubstackCC':
      ddl2.options.length = 0;
      for (i = 0; i < HubstackCC.length; i++) {
        createOption(ddl2, HubstackCC[i], HubstackCC[i]);
      }
      break;
    case 'ClearanceCC':
      ddl2.options.length = 0;
      for (i = 0; i < ClearanceCC.length; i++) {
        createOption(ddl2, ClearanceCC[i], ClearanceCC[i]);
      }
      break;
    case 'MISCCP':
      ddl2.options.length = 0;
      for (i = 0; i < MISCCP.length; i++) {
        createOption(ddl2, MISCCP[i], MISCCP[i]);
      }
      break;
    case 'SDApplicationSupport':
        ddl2.options.length = 0;
        for (i = 0; i < SDApplicationSupport.length; i++) {
          createOption(ddl2, SDApplicationSupport[i], SDApplicationSupport[i]);
        }
        break;
    default:
      ddl2.options.length = 0;
      createOption(ddl2, 'Select', 'Select');
      div.style.display = "none";
      break;
  }
	  
}
function createOption(ddl, text, value) {
	  var opt = document.createElement('option');
	  opt.value = value;
	  opt.text = text;
	  ddl.options.add(opt);
}
function initData()
{
	var ddl2 = document.getElementById('ddl2');
	ddl2.options.length = 0;
	createOption(ddl2, 'Select', 'Select');
	chkOnLoadStatus();
}
function getReport()
{
	var value = document.getElementById("ddl2").value;
	if(value == "Select")
	{
		alert('Please select Application and Team to proceed...!!!');
		return false;
	}
	
	else if(value === "SABRE" || value === "GSS")
	{
		var startDate = document.getElementById("startDate").value;	
		var endDate = document.getElementById("endDate").value;	
		if(!startDate)
		{
			alert("Please Enter Start Date");
			return false;
		}
		if(!endDate)
		{
			alert("Please Enter End Date");
			return false;
		}
		
		var d1 = new Date(startDate);
		var d2 = new Date(endDate);
		
		if(d1>d2)
		{
			alert("Please enter Start Date less than End Date");
			return false;
		}
		window.location = "FetchForGSSGraph.jsp?startDate="+d1+"&endDate="+d2+"&appTeam="+value;;
		return false;
	}
}
</script>

<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>

<style>
body {
  margin: 0;
}
button.active {
 display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
  background-color: #4CAF50;
  color: white;
  width: -webkit-fill-available;
  font-size: medium;
}

ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 20%;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
   width: -webkit-fill-available;
}

li a.active {
  background-color: #4CAF50;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}

li a:checked
{
  background: white;
  border-bottom: 1px solid white;
  z-index: 2;
}
	.main{
	margin-left:10%;
	/* margin-right:12%; */
	}
	.head{
		height :50px;
		background-color: #7030a0;
		margin:0;	
	}
	.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:10%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:30%;
	}
	.toolbar {
    height: 75px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .toolbarFooter {
    height: 50px;
    width: 90%;
    display: flex;
    align-items: center;
    background-color: #ff6701;
    color: black;
    font-weight: 100;
    margin-left:5%
  }
  purple
  {
    height: 10px;
    margin: 0 0 0 0;
    background-color: #4300fc;
  }
  .card {
    /* border-radius: 4px;
    border: 1px solid #eee;
    background-color: #fafafa; */
    height: 40px;
    /* width: 200px; */
    margin: 0 8px 16px;
    /* padding: 16px;
    display: flex; */
    flex-direction: row;
    justify-content: center;
    align-items: center;
    transition: all 0.2s ease-in-out;
    line-height: 24px;
    font-size: large;
    font-weight: bold;
  }





/* --------------original------------------- */
:host {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
    font-size: 24px;
    color: #333;
    box-sizing: border-box;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }

.divTag{
    
    font-size: 18px;
    color: black ;
    margin-left:25%;
    padding:1px 16px;
}
.header{
    color: darkblue;
    font-size: xx-large;
}


.inputbox .card:not(.highlight-card) {
    cursor: pointer;
  }
  
  .inputbox .card:not(.highlight-card):hover {
    transform: translateY(-3px);
    box-shadow: 0 4px 17px rgba(black, 0.35);
  }

  .inputbox .card:not(.highlight-card):hover .material-icons path {
    fill: rgb(0, 0, 0);
  }
.inputbox{
    align-items: center;
    color: mediumblue;
    height: 30px;
	width: 180px;
	margin: 10px;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: large;
}
.buttonBox{
  border-radius: 4px;
    border: 2px solid rgb(102, 102, 102);
    background-color: coral;
    height: 30px;
    width: 150px;
    margin: 0 8px 16px;
    /* padding: 16px;
    display: flex;  */
    flex-direction: row;
    justify-content: center;
    align-items: center;
    transition: all 0.2s ease-in-out;
    line-height: 24px;
    font-size: large;
    margin-left: 12%;
}
.labelFont{
    color: brown
}
.selectBox{
    align-items: center;
    color :darkblue;
    height: 30px;
	width: 180px;
	margin: 5px;
	font-family: Verdana, Geneva, Tahoma, sans-serif;
	font-size: medium;
}
.errMessage{
    color: red;
    font-size: 15px;
    text-align: center;
}
.login{
  float: right;
  font-size: 20px;
  color: white;
  margin: 10px;
  border-radius: 1px;
  border: 2px solid #eee;
  background-color: rgb(154 81 150); 
  width: 200px;
}
</style>
</head>
<body onload="initData()">


<div class="toolbar" role="banner">
    <img alt="FedEx" src="image/logo.png">
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
    <%if(userRole.equalsIgnoreCase("Admin")){ %>
    <button class="login" style="margin-left: 12%" onclick="addUser()" >User Management</button>
    <%} %>
    <button class="login" style="margin-left: 20%" onclick="logout()" >Logout</button>
</div>


<div class="purple"></div>
<div class="divTag">
<form action="FetchGSSData.jsp" method="post">
      <br> 
      <p style="font-size: medium;font-weight: bold;color: green; margin-left: 75%">Welcome : <%=userID%></p>
      <br><br><br><br><br>

    <label style = "color: navy;" for=ddl class="card">Support Team </label>
  <select id="ddl" style="font-size: large; width: 200px; margin-left: 12.8%;border-bottom-width: thick; max-width:90%;" onchange="configureDropDownLists(this,document.getElementById('ddl2'))">
  <option>    Select    </option>
  <option>    HubstackCC    </option>
  <option>    ClearanceCC    </option>
  <option>    MISCCP    </option>
  <option>    SDApplicationSupport    </option>
  </select>
  <br><br><br>
  
  <label style = "color: navy;" for="ddl2" class="card">Select Application  </label>
  <select id="ddl2" style="font-size: large; width: 200px; margin-left: 10%;border-bottom-width: thick; max-width:90%;">
  
  </select>
  <br> <br><br>
  <div id="dateSel" style="display: none;">
  		<label style = "color: navy;" for="gss"><b>Start date </b></label>
		<input  style = "color: navy;"  type="date" id="startDate" name="startDate" > <b style="color: red"> *</b>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
  		<label  style = "color: navy;"  for="gss"><b>End date </b></label>
		<input  style = "color: navy;"  type="date" id="endDate" name="endDate"  ><b style="color: red"> *</b>
  </div>
   <br><br>

  <br><br>
  <button type="submit" class="buttonBox" onclick = "return validate()"> <b>Fetch Data</b></button>
  <button type="submit" class="buttonBox" style=" margin-left: 5%;" onclick = "return getReport()"> <b>Show Report</b></button>
		 <!--  <hr>
		<code>button</code><br>
		<button class="fdx-c-button fdx-c-button--primary">
		    primary button
		</button>
		<hr> -->
  </form>
</div> 
<br><br><br><br><br><br><br><br><br>
<div class="toolbarFooter" > 
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>

</body>
</html>