package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class NexusCasesNotes implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String nexusCaseNoteSummary;
	private String nexusCaseNoteDescription;
	private String nexusCaseNoteType;
	private String nexusCaseNoteOrigin;
	private String nexusCaseNoteContactType;
	
	public NexusCasesNotes() {
	}
	
	public NexusCasesNotes(String noteSummary) {
		this.setNexusCaseNoteSummary(noteSummary);
	}
	
	public NexusCasesNotes(String noteSummary, String noteDescription) {
		this.setNexusCaseNoteSummary(noteSummary);
		this.setNexusCaseNoteDescription(noteDescription);
	}

	public String getNexusCaseNoteSummary() {
		return nexusCaseNoteSummary;
	}

	public void setNexusCaseNoteSummary(String nexusCaseNoteSummary) {
		this.nexusCaseNoteSummary = nexusCaseNoteSummary;
	}

	public String getNexusCaseNoteDescription() {
		return nexusCaseNoteDescription;
	}

	public void setNexusCaseNoteDescription(String nexusCaseNoteDescription) {
		this.nexusCaseNoteDescription = nexusCaseNoteDescription;
	}

	public String getNexusCaseNoteType() {
		return nexusCaseNoteType;
	}

	public void setNexusCaseNoteType(String nexusCaseNoteType) {
		this.nexusCaseNoteType = nexusCaseNoteType;
	}

	public String getNexusCaseNoteOrigin() {
		return nexusCaseNoteOrigin;
	}

	public void setNexusCaseNoteOrigin(String nexusCaseNoteOrigin) {
		this.nexusCaseNoteOrigin = nexusCaseNoteOrigin;
	}

	public String getNexusCaseNoteContactType() {
		return nexusCaseNoteContactType;
	}

	public void setNexusCaseNoteContactType(String nexusCaseNoteContactType) {
		this.nexusCaseNoteContactType = nexusCaseNoteContactType;
	}
}
