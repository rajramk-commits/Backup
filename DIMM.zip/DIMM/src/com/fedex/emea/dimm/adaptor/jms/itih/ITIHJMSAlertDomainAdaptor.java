package com.fedex.emea.dimm.adaptor.jms.itih;

import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptor;
import com.fedex.emea.dimm.adaptor.AbstractAlertDomainAdaptorConfig;
import com.fedex.emea.dimm.alert.AbstractAlert;
import com.fedex.emea.dimm.alert.PhysicalAlert;
import com.fedex.emea.dimm.utils.DIMMConstants;

public class ITIHJMSAlertDomainAdaptor extends AbstractAlertDomainAdaptor{

	private ITIHJMSAlertDomainAdaptorConfig config;
	
	public ITIHJMSAlertDomainAdaptor() throws Exception {
		super();
		config = new ITIHJMSAlertDomainAdaptorConfig();
	}

	@Override
	public AbstractAlertDomainAdaptorConfig getConfig() {
		return config;
	}

	@Override
	public boolean isApplicable(AbstractAlert physicalAlert) {
		if(physicalAlert.getDashboardName().equalsIgnoreCase(config.getDashboardName()))
			return true;
		else
			return false;
	}
	
	@Override
	protected String adaptServerValue(PhysicalAlert physicalAlert) {
		return DIMMConstants.ITIH_SERVER;
	}
	
}
