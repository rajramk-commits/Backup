package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class NetworkEquipments implements Serializable {

	private static final long serialVersionUID = 1L;

	private String serviceName;
	private String applicationName;
	private String responsibleManager;
	private String businessCriticality;
	private String applicationStatus;
	private String supportGroup;
	private String serverName;
	private String serverType;
	private String serverDescription;
	private String serverDc;
	private String serverStatus;
	private String serverOs;
	private String serverOsVersion;
	private String serverOsRevision;
	private String applicationHosted;
	private String serverFunction;
	private String environmentType;
	
	public NetworkEquipments() {
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getBusinessCriticality() {
		return businessCriticality;
	}

	public void setBusinessCriticality(String businessCriticality) {
		this.businessCriticality = businessCriticality;
	}

	public String getServerName() {
		return serverName;
	}

	public void setServerName(String serverName) {
		this.serverName = serverName;
	}

	public String getServerType() {
		return serverType;
	}

	public void setServerType(String serverType) {
		this.serverType = serverType;
	}

	public String getServerDescription() {
		return serverDescription;
	}

	public void setServerDescription(String serverDescription) {
		this.serverDescription = serverDescription;
	}

	public String getServerDc() {
		return serverDc;
	}

	public void setServerDc(String serverDc) {
		this.serverDc = serverDc;
	}

	public String getServerStatus() {
		return serverStatus;
	}

	public void setServerStatus(String serverStatus) {
		this.serverStatus = serverStatus;
	}

	public String getResponsibleManager() {
		return responsibleManager;
	}

	public void setResponsibleManager(String responsibleManager) {
		this.responsibleManager = responsibleManager;
	}

	public String getServerOs() {
		return serverOs;
	}

	public void setServerOs(String serverOs) {
		this.serverOs = serverOs;
	}

	public String getServerOsVersion() {
		return serverOsVersion;
	}

	public void setServerOsVersion(String serverOsVersion) {
		this.serverOsVersion = serverOsVersion;
	}

	public String getApplicationStatus() {
		return applicationStatus;
	}

	public void setApplicationStatus(String applicationStatus) {
		this.applicationStatus = applicationStatus;
	}

	public String getSupportGroup() {
		return supportGroup;
	}

	public void setSupportGroup(String supportGroup) {
		this.supportGroup = supportGroup;
	}

	public String getApplicationHosted() {
		return applicationHosted;
	}

	public void setApplicationHosted(String applicationHosted) {
		this.applicationHosted = applicationHosted;
	}

	public String getServerFunction() {
		return serverFunction;
	}

	public void setServerFunction(String serverFunction) {
		this.serverFunction = serverFunction;
	}

	public String getEnvironmentType() {
		return environmentType;
	}

	public void setEnvironmentType(String environmentType) {
		this.environmentType = environmentType;
	}

	public String getServerOsRevision() {
		return serverOsRevision;
	}

	public void setServerOsRevision(String serverOsRevision) {
		this.serverOsRevision = serverOsRevision;
	}
	
}
