package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class MailBoxRules implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String  searchCriteria;
	private String  searchText;
	private boolean searchCaseSensitive;
	private boolean searchStartWith;
	private String  action;
	private String  actionParameter1;
	private String  actionParameter2;
	private String  actionParameter3;
	private String  actionParameter4;
	private String  actionParameter5;
	
	public MailBoxRules() {
	}
	
	public MailBoxRules(String searchCriteria, String searchText, boolean searchCaseSensitive, boolean searchStartWith, String action, String actionParameter1, String actionParameter2, String actionParameter3, String actionParameter4, String actionParameter5) {
		this.setSearchCriteria(searchCriteria);
		this.setSearchText(searchText);
		this.setSearchCaseSensitive(searchCaseSensitive);
		this.setSearchStartWith(searchStartWith);
		this.setAction(action);
		this.setActionParameter1(actionParameter1);
		this.setActionParameter2(actionParameter2);
		this.setActionParameter3(actionParameter3);
		this.setActionParameter4(actionParameter4);
		this.setActionParameter5(actionParameter5);
	}

	public String getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(String searchCriteria) {
		this.searchCriteria = searchCriteria;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getActionParameter1() {
		return actionParameter1;
	}

	public void setActionParameter1(String actionParameter1) {
		this.actionParameter1 = actionParameter1;
	}

	public String getActionParameter2() {
		return actionParameter2;
	}

	public void setActionParameter2(String actionParameter2) {
		this.actionParameter2 = actionParameter2;
	}

	public String getActionParameter3() {
		return actionParameter3;
	}

	public void setActionParameter3(String actionParameter3) {
		this.actionParameter3 = actionParameter3;
	}

	public String getActionParameter4() {
		return actionParameter4;
	}

	public void setActionParameter4(String actionParameter4) {
		this.actionParameter4 = actionParameter4;
	}

	public String getActionParameter5() {
		return actionParameter5;
	}

	public void setActionParameter5(String actionParameter5) {
		this.actionParameter5 = actionParameter5;
	}

	public boolean isSearchCaseSensitive() {
		return searchCaseSensitive;
	}

	public void setSearchCaseSensitive(boolean searchCaseSensitive) {
		this.searchCaseSensitive = searchCaseSensitive;
	}

	public boolean isSearchStartWith() {
		return searchStartWith;
	}

	public void setSearchStartWith(boolean searchStartWith) {
		this.searchStartWith = searchStartWith;
	}

}
