package com.fedex.emea.sd.snow.utilities;

import java.util.HashMap;
import com.fedex.emea.sd.snow.objects.SnowIncident;
import com.fedex.emea.sd.snow.objects.SnowIncidentWorkNote;

public class DebugUtilities {
	
	public static void listCriticalityInfo(SnowIncident incident, SnowIncident testIncident) {
		System.out.println("ID: " + incident.getSnowSysId() 
				+ " - NBR: "	  + incident.getSnowNumber()
				+ " - Priority:"  + incident.getSnowPriority() + " (in SN) /" + testIncident.getSnowPriority() + " (set)"
				+ " - Impact:"	  + incident.getSnowImpact()   + " (in SN) /" + testIncident.getSnowImpact() + " (set)"
				+ " - Urgency:"	  + incident.getSnowUrgency()  + " (in SN) /" + testIncident.getSnowUrgency() + " (set)"
				+ " - Severity:"  + incident.getSnowSeverity() + " (in SN) /" + testIncident.getSnowSeverity() + " (set)");
	}

	public static void listAllFields(HashMap<String, Object> fieldsMap) {
		System.out.println("===================================================================");
		for (String str: fieldsMap.keySet()) {
			System.out.println(str + " = " + fieldsMap.get(str));
		}
		System.out.println("===================================================================");
	}
	
	public static void listWorkNoteKeyFields(SnowIncidentWorkNote workNote) {
		System.out.println("SysId: " + workNote.getWorkNoteSysId()
				+ ", " + workNote.getWorkNoteSysCreatedOn()
				+ ", " + workNote.getWorkNoteElement()
				+ ", " + workNote.getWorkNoteElementId()
				+ ", " + workNote.getWorkNoteName()
				+ ", " + workNote.getWorkNoteSubject()
				+ ", " + workNote.getWorkNoteText());
		
	}
	
	public static void listIncidentMainfieldsInRow(SnowIncident incident) {
		System.out.println(incident.getSnowSysId() + "," 
		+ incident.getSnowNumber() + ","
		+ incident.getSnowSysCreatedOn() + ","
		+ incident.getSnowOpenedAt() + ","
		+ incident.getSnowState() + ","
		+ incident.getSnowU_BusinessService() + ","
		+ incident.getSnowPriority()
		);
	}
	
	public static void listIncidentKeyFields(SnowIncident incident) {
		System.out.println("===================================================================");
		System.out.println("SysId: " + incident.getSnowSysId());
		System.out.println("Total Saved: " + incident.getSnowU_SavedCount());
		System.out.println("Number: " + incident.getSnowNumber());
		System.out.println("Status: " + incident.getSnowState());
		System.out.println("Medium: " + incident.getSnowContactType());
		System.out.println("Location: " + incident.getSnowLocation());
		System.out.println("Short Description: " + incident.getSnowShortDescription());
		System.out.println("Description: " + System.lineSeparator()
				+ "-----------------------------------------------------------" + System.lineSeparator()
				+ incident.getSnowDescription() + System.lineSeparator() 
				+ "-----------------------------------------------------------");
		System.out.println("Priority: " + incident.getSnowPriority());
		System.out.println("Impact: " + incident.getSnowImpact());
		System.out.println("Urgency: " + incident.getSnowUrgency());
		System.out.println("Severity: " + incident.getSnowSeverity());
		System.out.println("Category: " + incident.getSnowSubcategory());
		System.out.println("Sub-Category: " + incident.getSnowU_Classification());
		System.out.println("Service State: " + incident.getSnowU_ServiceState());
		System.out.println("Business Service: " + incident.getSnowU_BusinessService());
		System.out.println("Sites affected: " + incident.getSnowU_SitesAffected());
		System.out.println("Assignment Group: " + incident.getSnowAssignmentGroup());
		System.out.println("Assigned To: " + incident.getSnowAssignedTo());
		System.out.println("Instructions: " + incident.getSnowU_Instructions());
		System.out.println("Opened At: " + incident.getSnowOpenedAt());
		System.out.println("Closed At: " + incident.getSnowClosedAt());
		System.out.println("Resolved At: " + incident.getSnowResolvedAt());
		System.out.println("Escalated: " + incident.getSnowU_Escalated());
		System.out.println("Repeat Incdient: " + incident.getSnowU_RepeatIncident());
		System.out.println("Application Code: " + incident.getSnowU_ApplicationCode());
		System.out.println("Batch Step: " + incident.getSnowU_BatchStep());
		System.out.println("Job Number: " + incident.getSnowU_JobNumber());
		System.out.println("Third Party Reference: " + incident.getSnowU_ThirdPartyReference());
		System.out.println("Work Notes: " + incident.getSnowWorkNotes());
		System.out.println("");
		System.out.println("===================================================================");
	}
	
	public static void listFieldsFromFieldsMap(HashMap<String, Object> fieldsMap, String[] fieldsList) {
		StringBuilder fieldsLine = new StringBuilder();
		for (String fieldName: fieldsList) {
			if (fieldsLine.toString().isEmpty()) {
				fieldsLine.append(fieldsMap.get(fieldName));
			} else {
				fieldsLine.append(", " + fieldsMap.get(fieldName));
			}
		}
		System.out.println(fieldsLine.toString());
	}
	
}
