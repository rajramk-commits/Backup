package com.fedex.emea.sd.astc.testers;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

import com.fedex.emea.sd.da.objects.ExternalInterface;

public class TestObjects implements Serializable {
	
	private static final long serialVersionUID = -1839874325898055261L;
	private static SimpleDateFormat fmtDateOnly = new SimpleDateFormat("MM/dd/yyyy");
	private static SimpleDateFormat fmtTimeOnly = new SimpleDateFormat("HH:mm:ss");

	public static ExternalInterface getExternalInterfaceRecordToAddNoteForOVO(String caseId, String caseSysId) {
		ExternalInterface externalInterfaceRecord = new ExternalInterface();
		externalInterfaceRecord = getExternalInterfaceRecordForOVO();
		externalInterfaceRecord.setRecordSource("ADD-NOTE");
		externalInterfaceRecord.setCaseSummary("Similar Alert received");
		externalInterfaceRecord.setCaseId(caseId);
		externalInterfaceRecord.setCaseSysId(caseSysId);
		
		return externalInterfaceRecord;
	}
	
	public static ExternalInterface getExternalInterfaceRecordToAddNoteForDashboard(String caseId, String caseSysId) {
		ExternalInterface externalInterfaceRecord = new ExternalInterface();
		externalInterfaceRecord = getExternalInterfaceRecordForDashboard();
		externalInterfaceRecord.setRecordSource("ADD-NOTE");
		externalInterfaceRecord.setCaseSummary("Similar Alert received");
		externalInterfaceRecord.setCaseId(caseId);
		externalInterfaceRecord.setCaseSysId(caseSysId);
		
		return externalInterfaceRecord;
	}
	
	public static ExternalInterface getExternalInterfaceRecordForOVO() {
		ExternalInterface externalInterfaceRecord = new ExternalInterface();
		
		externalInterfaceRecord.setRecordSource("OBM");
		externalInterfaceRecord.setRecordSourceId(String.valueOf(UUID.randomUUID()));
		externalInterfaceRecord.setNexusCase(null);
		externalInterfaceRecord.setCaseBusinessUnit("SDESK");
		externalInterfaceRecord.setCaseLocation(null);
		externalInterfaceRecord.setCaseOriginPin("");
		externalInterfaceRecord.setCaseSummary("GA/OBM Alert on " + fmtDateOnly.format(Calendar.getInstance().getTime()) + " at " + fmtTimeOnly.format(Calendar.getInstance().getTime()));
		externalInterfaceRecord.setCaseDescription1("CRITICAL Alert received from OBM on " + fmtDateOnly.format(Calendar.getInstance().getTime()) + " at " + fmtTimeOnly.format(Calendar.getInstance().getTime()) + "\n___________________________________________________________________________________\nImpacted Node  : nemrul.corp.ds.fedex.com (Intel/AMD x64(HTTPS))\nAlert Object   : Windows Installer service\nAler");
		externalInterfaceRecord.setCaseDescription2("t Message  : Failure of service Windows Installer service startup because: The service did not respond to the start or control request in a timely fashion.\nInstructions   : Inform the system administrator, create a nexus case.\n____________________________");
		externalInterfaceRecord.setCaseDescription3("_______________________________________________________\nServer Status in Ni2 : PRODUCTION\nServer Function : null\nApplications hosted : BPO-Finance\n___________________________________________________________________________________\nApplications running on");
		externalInterfaceRecord.setCaseDescription4(" Impacted Node :\n*** GRID\n----- Environment: Prod environment SLO\n----- Status: In production\n----- Criticality: 3 - Medium\n----- Resp. Manager: Yves Claes\n----- Role: 8b IT Systems & tools\n________________________________________________________________");
		externalInterfaceRecord.setCaseDescription5("___________________\n");
		externalInterfaceRecord.setCaseDescription6(null);
		externalInterfaceRecord.setCaseDescription7(null);
		externalInterfaceRecord.setCaseDescription8(null);
		externalInterfaceRecord.setCaseDescription9(null);
		externalInterfaceRecord.setCaseType("INCID");
		externalInterfaceRecord.setCasePriority("HIGH");
		externalInterfaceRecord.setCaseStatus("OPEN");
		externalInterfaceRecord.setCaseSeverity("USCH");
		externalInterfaceRecord.setCaseSource("AUTO");
		externalInterfaceRecord.setCaseProviderGroup("Helpdesk");
		externalInterfaceRecord.setCaseOwnership(null);
		externalInterfaceRecord.setCaseCategory("ITD");
		externalInterfaceRecord.setCaseCallType("UNDEF");
		externalInterfaceRecord.setCaseProblemType("UNDEF");
		externalInterfaceRecord.setCaseProblemDetail("UNDEF");
		externalInterfaceRecord.setCaseProblemDescription(null);
		externalInterfaceRecord.setCaseFdxNode(null);
		externalInterfaceRecord.setCaseFdxVendor(null);
		externalInterfaceRecord.setCaseFdxVendorId(null);
		externalInterfaceRecord.setCaseFdxSystem(null);
		externalInterfaceRecord.setCaseFdxApplication(null);
		externalInterfaceRecord.setCaseAssignedTo(null);
		externalInterfaceRecord.setCaseSolution("0");
		externalInterfaceRecord.setAlertProcessed(0);
		externalInterfaceRecord.setCreationTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		
		return externalInterfaceRecord;
	}
	
	public static ExternalInterface getExternalInterfaceRecordForDashboard() {
		ExternalInterface externalInterfaceRecord = new ExternalInterface();
		
		externalInterfaceRecord.setRecordSource("DIMM:GENIUS_PROD_DASHBOARD");
		externalInterfaceRecord.setRecordSourceId("47613");
		externalInterfaceRecord.setNexusCase(null);
		externalInterfaceRecord.setCaseBusinessUnit("SDESK");
		externalInterfaceRecord.setCaseLocation(null);
		externalInterfaceRecord.setCaseOriginPin("");
		externalInterfaceRecord.setCaseSummary("GA/Dashboard Alert on on " + fmtDateOnly.format(Calendar.getInstance().getTime()) + " at " + fmtTimeOnly.format(Calendar.getInstance().getTime()));
		externalInterfaceRecord.setCaseDescription1("Type[ERROR] Server[jmspd2.emea.fedex.com:55212] Component[JMS_QUEUE] Application[NO_MSG_CONSUME] Module[FDSVIPC.GENIUS.ERR.AT.ALL.ERROR.SRV4] Message[The messages in this interface are not being consu");
		externalInterfaceRecord.setCaseDescription2("med.] Action[Check whether the process reading from this JMS QUEUE is running.]");
		externalInterfaceRecord.setCaseDescription3(null);
		externalInterfaceRecord.setCaseDescription4(null);
		externalInterfaceRecord.setCaseDescription5(null);
		externalInterfaceRecord.setCaseDescription6(null);
		externalInterfaceRecord.setCaseDescription7(null);
		externalInterfaceRecord.setCaseDescription8(null);
		externalInterfaceRecord.setCaseDescription9(null);
		externalInterfaceRecord.setCaseType("INCID");
		externalInterfaceRecord.setCasePriority("HIGH");
		externalInterfaceRecord.setCaseStatus("OPEN");
		externalInterfaceRecord.setCaseSeverity("USCH");
		externalInterfaceRecord.setCaseSource("AUTO");
		externalInterfaceRecord.setCaseProviderGroup("Helpdesk");
		externalInterfaceRecord.setCaseOwnership(null);
		externalInterfaceRecord.setCaseCategory("ITD");
		externalInterfaceRecord.setCaseCallType("UNDEF");
		externalInterfaceRecord.setCaseProblemType("UNDEF");
		externalInterfaceRecord.setCaseProblemDetail("UNDEF");
		externalInterfaceRecord.setCaseProblemDescription(null);
		externalInterfaceRecord.setCaseFdxNode(null);
		externalInterfaceRecord.setCaseFdxVendor(null);
		externalInterfaceRecord.setCaseFdxVendorId(null);
		externalInterfaceRecord.setCaseFdxSystem(null);
		externalInterfaceRecord.setCaseFdxApplication(null);
		externalInterfaceRecord.setCaseAssignedTo(null);
		externalInterfaceRecord.setCaseSolution("0");
		externalInterfaceRecord.setAlertProcessed(0);
		externalInterfaceRecord.setCreationTime(new Timestamp(Calendar.getInstance().getTimeInMillis()));
		
		return externalInterfaceRecord;
	}
}
