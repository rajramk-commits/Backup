package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowAstcIncident implements Serializable {

	private static final long serialVersionUID = 987026929484610356L;
	
	private String snowImportSetRun;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysId;
	private String snowSysImportRow;
	private String snowSysImportSet;
	private String snowSysImportState;
	private String snowSysImportStateComment;
	private String snowSysModCount;
	private String snowSysRowError;
	private String snowSysTags;
	private String snowSysTargetSysId;
	private String snowSysTargetTable;
	private String snowSysTransformMap;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowTemplateImportLog;
	private String snowU_AssignmentGroup;
	private String snowU_BusinessService;
	private String snowU_Caller;
	private String snowU_Category;
	private String snowU_Classification;
	private String snowU_ContactType;
	private String snowU_Description;
	private String snowU_Folder;
	private String snowU_Impact;
	private String snowU_Instructions;
	private String snowU_Number;
	private String snowU_Priority;
	private String snowU_Service;
	private String snowU_Severity;
	private String snowU_ShortDescription;
	private String snowU_State;
	private String snowU_Subcategory;
	private String snowU_Urgency;
	private String snowU_WorkNotes;
	
	public SnowAstcIncident() {
	}
	
	public SnowAstcIncident(HashMap<String, Object> jsonValues) {
		snowImportSetRun = SnowUtilities.getStringValueFromObject(jsonValues.get("import_set_run"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysImportRow = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_import_row"));
		snowSysImportSet = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_import_set"));
		snowSysImportState = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_import_state"));
		snowSysImportStateComment = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_import_state_comment"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysRowError = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_row_error"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysTargetSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_target_sys_id"));
		snowSysTargetTable = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_target_table"));
		snowSysTransformMap = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_transform_map"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowTemplateImportLog = SnowUtilities.getStringValueFromObject(jsonValues.get("template_import_log"));
		snowU_AssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_assignment_group"));
		snowU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_service"));
		snowU_Caller = SnowUtilities.getStringValueFromObject(jsonValues.get("u_caller"));
		snowU_Category = SnowUtilities.getStringValueFromObject(jsonValues.get("u_category"));
		snowU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("u_classification"));
		snowU_ContactType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_contact_type"));
		snowU_Description = SnowUtilities.getStringValueFromObject(jsonValues.get("u_description"));
		snowU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("u_folder"));
		snowU_Impact = SnowUtilities.getStringValueFromObject(jsonValues.get("u_impact"));
		snowU_Instructions = SnowUtilities.getStringValueFromObject(jsonValues.get("u_instructions"));
		snowU_Number = SnowUtilities.getStringValueFromObject(jsonValues.get("u_number"));
		snowU_Priority = SnowUtilities.getStringValueFromObject(jsonValues.get("u_priority"));
		snowU_Service = SnowUtilities.getStringValueFromObject(jsonValues.get("u_service"));
		snowU_Severity = SnowUtilities.getStringValueFromObject(jsonValues.get("u_severity"));
		snowU_ShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("u_short_description"));
		snowU_State = SnowUtilities.getStringValueFromObject(jsonValues.get("u_state"));
		snowU_Subcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_subcategory"));
		snowU_Urgency = SnowUtilities.getStringValueFromObject(jsonValues.get("u_urgency"));
		snowU_WorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("u_work_notes"));
	}
	
	public boolean isValid() {
		boolean isValid = true;
		
		if (this.getSnowU_Category()         == null || this.getSnowU_Category().trim().isEmpty())         isValid = false;
		if (this.getSnowU_State()            == null || this.getSnowU_State().trim().isEmpty())            isValid = false;
		if (this.getSnowU_ContactType()      == null || this.getSnowU_ContactType().trim().isEmpty())      isValid = false;
		if (this.getSnowU_AssignmentGroup()  == null || this.getSnowU_AssignmentGroup().trim().isEmpty())  isValid = false;
		if (this.getSnowU_ShortDescription() == null || this.getSnowU_ShortDescription().trim().isEmpty()) isValid = false;
		if (this.getSnowU_Description()      == null || this.getSnowU_Description().trim().isEmpty())      isValid = false;

		return isValid;
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();
		
		if (snowImportSetRun != null && !snowImportSetRun.toString().isEmpty()) jsonObject.put("import_set_run", snowImportSetRun);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysImportRow != null && !snowSysImportRow.toString().isEmpty()) jsonObject.put("sys_import_row", snowSysImportRow);
		if (snowSysImportSet != null && !snowSysImportSet.toString().isEmpty()) jsonObject.put("sys_import_set", snowSysImportSet);
		if (snowSysImportState != null && !snowSysImportState.toString().isEmpty()) jsonObject.put("sys_import_state", snowSysImportState);
		if (snowSysImportStateComment != null && !snowSysImportStateComment.toString().isEmpty()) jsonObject.put("sys_import_state_comment", snowSysImportStateComment);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysRowError != null && !snowSysRowError.toString().isEmpty()) jsonObject.put("sys_row_error", snowSysRowError);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysTargetSysId != null && !snowSysTargetSysId.toString().isEmpty()) jsonObject.put("sys_target_sys_id", snowSysTargetSysId);
		if (snowSysTargetTable != null && !snowSysTargetTable.toString().isEmpty()) jsonObject.put("sys_target_table", snowSysTargetTable);
		if (snowSysTransformMap != null && !snowSysTransformMap.toString().isEmpty()) jsonObject.put("sys_transform_map", snowSysTransformMap);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowTemplateImportLog != null && !snowTemplateImportLog.toString().isEmpty()) jsonObject.put("template_import_log", snowTemplateImportLog);
		if (snowU_AssignmentGroup != null && !snowU_AssignmentGroup.toString().isEmpty()) jsonObject.put("u_assignment_group", snowU_AssignmentGroup);
		if (snowU_BusinessService != null && !snowU_BusinessService.toString().isEmpty()) jsonObject.put("u_business_service", snowU_BusinessService);
		if (snowU_Caller != null && !snowU_Caller.toString().isEmpty()) jsonObject.put("u_caller", snowU_Caller);
		if (snowU_Category != null && !snowU_Category.toString().isEmpty()) jsonObject.put("u_category", snowU_Category);
		if (snowU_Classification != null && !snowU_Classification.toString().isEmpty()) jsonObject.put("u_classification", snowU_Classification);
		if (snowU_ContactType != null && !snowU_ContactType.toString().isEmpty()) jsonObject.put("u_contact_type", snowU_ContactType);
		if (snowU_Description != null && !snowU_Description.toString().isEmpty()) jsonObject.put("u_description", snowU_Description);
		if (snowU_Folder != null && !snowU_Folder.toString().isEmpty()) jsonObject.put("u_folder", snowU_Folder);
		if (snowU_Impact != null && !snowU_Impact.toString().isEmpty()) jsonObject.put("u_impact", snowU_Impact);
		if (snowU_Instructions != null && !snowU_Instructions.toString().isEmpty()) jsonObject.put("u_instructions", snowU_Instructions);
		if (snowU_Number != null && !snowU_Number.toString().isEmpty()) jsonObject.put("u_number", snowU_Number);
		if (snowU_Priority != null && !snowU_Priority.toString().isEmpty()) jsonObject.put("u_priority", snowU_Priority);
		if (snowU_Service != null && !snowU_Service.toString().isEmpty()) jsonObject.put("u_service", snowU_Service);
		if (snowU_Severity != null && !snowU_Severity.toString().isEmpty()) jsonObject.put("u_severity", snowU_Severity);
		if (snowU_ShortDescription != null && !snowU_ShortDescription.toString().isEmpty()) jsonObject.put("u_short_description", snowU_ShortDescription);
		if (snowU_State != null && !snowU_State.toString().isEmpty()) jsonObject.put("u_state", snowU_State);
		if (snowU_Subcategory != null && !snowU_Subcategory.toString().isEmpty()) jsonObject.put("u_subcategory", snowU_Subcategory);
		if (snowU_Urgency != null && !snowU_Urgency.toString().isEmpty()) jsonObject.put("u_urgency", snowU_Urgency);
		if (snowU_WorkNotes != null && !snowU_WorkNotes.toString().isEmpty()) jsonObject.put("u_work_notes", snowU_WorkNotes);
		
		return jsonObject;
	}
	
	public void setPrioritySetters(String priority, String impact, String urgency, String severity) {
		this.snowU_Impact = impact;
		this.snowU_Urgency  = urgency;
		this.snowU_Severity = severity;
		this.snowU_Priority = priority;
	}

	public String getSnowImportSetRun() {
		return snowImportSetRun;
	}

	public void setSnowImportSetRun(String snowImportSetRun) {
		this.snowImportSetRun = snowImportSetRun;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysImportRow() {
		return snowSysImportRow;
	}

	public void setSnowSysImportRow(String snowSysImportRow) {
		this.snowSysImportRow = snowSysImportRow;
	}

	public String getSnowSysImportSet() {
		return snowSysImportSet;
	}

	public void setSnowSysImportSet(String snowSysImportSet) {
		this.snowSysImportSet = snowSysImportSet;
	}

	public String getSnowSysImportState() {
		return snowSysImportState;
	}

	public void setSnowSysImportState(String snowSysImportState) {
		this.snowSysImportState = snowSysImportState;
	}

	public String getSnowSysImportStateComment() {
		return snowSysImportStateComment;
	}

	public void setSnowSysImportStateComment(String snowSysImportStateComment) {
		this.snowSysImportStateComment = snowSysImportStateComment;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysRowError() {
		return snowSysRowError;
	}

	public void setSnowSysRowError(String snowSysRowError) {
		this.snowSysRowError = snowSysRowError;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysTargetSysId() {
		return snowSysTargetSysId;
	}

	public void setSnowSysTargetSysId(String snowSysTargetSysId) {
		this.snowSysTargetSysId = snowSysTargetSysId;
	}

	public String getSnowSysTargetTable() {
		return snowSysTargetTable;
	}

	public void setSnowSysTargetTable(String snowSysTargetTable) {
		this.snowSysTargetTable = snowSysTargetTable;
	}

	public String getSnowSysTransformMap() {
		return snowSysTransformMap;
	}

	public void setSnowSysTransformMap(String snowSysTransformMap) {
		this.snowSysTransformMap = snowSysTransformMap;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowTemplateImportLog() {
		return snowTemplateImportLog;
	}

	public void setSnowTemplateImportLog(String snowTemplateImportLog) {
		this.snowTemplateImportLog = snowTemplateImportLog;
	}

	public String getSnowU_AssignmentGroup() {
		return snowU_AssignmentGroup;
	}

	public void setSnowU_AssignmentGroup(String snowU_AssignmentGroup) {
		this.snowU_AssignmentGroup = snowU_AssignmentGroup;
	}

	public String getSnowU_BusinessService() {
		return snowU_BusinessService;
	}

	public void setSnowU_BusinessService(String snowU_BusinessService) {
		this.snowU_BusinessService = snowU_BusinessService;
	}

	public String getSnowU_Caller() {
		return snowU_Caller;
	}

	public void setSnowU_Caller(String snowU_Caller) {
		this.snowU_Caller = snowU_Caller;
	}

	public String getSnowU_Category() {
		return snowU_Category;
	}

	public void setSnowU_Category(String snowU_Category) {
		this.snowU_Category = snowU_Category;
	}

	public String getSnowU_Classification() {
		return snowU_Classification;
	}

	public void setSnowU_Classification(String snowU_Classification) {
		this.snowU_Classification = snowU_Classification;
	}

	public String getSnowU_ContactType() {
		return snowU_ContactType;
	}

	public void setSnowU_ContactType(String snowU_ContactType) {
		this.snowU_ContactType = snowU_ContactType;
	}

	public String getSnowU_Description() {
		return snowU_Description;
	}

	public void setSnowU_Description(String snowU_Description) {
		this.snowU_Description = snowU_Description;
	}

	public String getSnowU_Folder() {
		return snowU_Folder;
	}

	public void setSnowU_Folder(String snowU_Folder) {
		this.snowU_Folder = snowU_Folder;
	}

	public String getSnowU_Impact() {
		return snowU_Impact;
	}

	public void setSnowU_Impact(String snowU_Impact) {
		this.snowU_Impact = snowU_Impact;
	}

	public String getSnowU_Instructions() {
		return snowU_Instructions;
	}

	public void setSnowU_Instructions(String snowU_Instructions) {
		this.snowU_Instructions = snowU_Instructions;
	}

	public String getSnowU_Number() {
		return snowU_Number;
	}

	public void setSnowU_Number(String snowU_Number) {
		this.snowU_Number = snowU_Number;
	}

	public String getSnowU_Priority() {
		return snowU_Priority;
	}

	public void setSnowU_Priority(String snowU_Priority) {
		this.snowU_Priority = snowU_Priority;
	}

	public String getSnowU_Service() {
		return snowU_Service;
	}

	public void setSnowU_Service(String snowU_Service) {
		this.snowU_Service = snowU_Service;
	}

	public String getSnowU_Severity() {
		return snowU_Severity;
	}

	public void setSnowU_Severity(String snowU_Severity) {
		this.snowU_Severity = snowU_Severity;
	}

	public String getSnowU_ShortDescription() {
		return snowU_ShortDescription;
	}

	public void setSnowU_ShortDescription(String snowU_ShortDescription) {
		this.snowU_ShortDescription = snowU_ShortDescription;
	}

	public String getSnowU_State() {
		return snowU_State;
	}

	public void setSnowU_State(String snowU_State) {
		this.snowU_State = snowU_State;
	}

	public String getSnowU_Subcategory() {
		return snowU_Subcategory;
	}

	public void setSnowU_Subcategory(String snowU_Subcategory) {
		this.snowU_Subcategory = snowU_Subcategory;
	}

	public String getSnowU_Urgency() {
		return snowU_Urgency;
	}

	public void setSnowU_Urgency(String snowU_Urgency) {
		this.snowU_Urgency = snowU_Urgency;
	}

	public String getSnowU_WorkNotes() {
		return snowU_WorkNotes;
	}

	public void setSnowU_WorkNotes(String snowU_WorkNotes) {
		this.snowU_WorkNotes = snowU_WorkNotes;
	}

}
