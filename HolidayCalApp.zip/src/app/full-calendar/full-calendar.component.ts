import { Component, OnInit } from '@angular/core';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import { EventService } from './eventservice';
import { Calendar } from '@fullcalendar/core';
import { ActivatedRoute, Router, NavigationStart } from '@angular/router';
import { FullCalendar } from 'primeng/fullcalendar';
import '@angular/compiler';

@Component({
  selector: 'app-full-calendar',
  templateUrl: './full-calendar.component.html',
  styleUrls: ['./full-calendar.component.css']
})
export class FullCalendarComponent implements OnInit {

  events: any[];
  options: any;
  header: any;
  constructor(private eventService: EventService, private route: Router) {
    this.route.events.subscribe(params => {
      if (params instanceof NavigationStart) {
        //const country = "CalendarApp"; //params.url.split('/').pop();
        this.eventService.getEvents().subscribe((events: []) => {
          this.events = events;
          this.header = events.filter((value: any) => value.reminder !== null);
        });
      }
    });
  }

  ngOnInit() {
    this.options = {
      plugins: [dayGridPlugin, timeGridPlugin, interactionPlugin],
      defaultDate: Date.now(), //'2019-01-01',
      header: {
        left: 'prev,next',
        center: 'title',
        right: 'today',
      },
      // aspectRatio: 2.5,
     //  height:'10',
      contentHeight: 650,
      editable: false
    };
  }
}
