package com.fedex.emea.sd.da.objects;

import java.io.Serializable;

public class Parameters implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String parameterEntity;
	private String parameterName;
	private String parameterValue1;
	private String parameterValue2;
	private String parameterValue3;
	
	public Parameters() {
	}
	
	public Parameters(String parameterEntity, String parameterName, String parameterValue1, String parameterValue2, String parameterValue3) {
		this.setParameterEntity(parameterEntity);
		this.setParameterName(parameterName);
		this.setParameterValue1(parameterValue1);
		this.setParameterValue2(parameterValue2);
		this.setParameterValue3(parameterValue3);
	}

	public String getParameterEntity() {
		return parameterEntity;
	}

	public void setParameterEntity(String parameterEntity) {
		this.parameterEntity = parameterEntity;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public String getParameterValue1() {
		return parameterValue1;
	}

	public void setParameterValue1(String parameterValue1) {
		this.parameterValue1 = parameterValue1;
	}

	public String getParameterValue2() {
		return parameterValue2;
	}

	public void setParameterValue2(String parameterValue2) {
		this.parameterValue2 = parameterValue2;
	}

	public String getParameterValue3() {
		return parameterValue3;
	}

	public void setParameterValue3(String parameterValue3) {
		this.parameterValue3 = parameterValue3;
	}
	
}
