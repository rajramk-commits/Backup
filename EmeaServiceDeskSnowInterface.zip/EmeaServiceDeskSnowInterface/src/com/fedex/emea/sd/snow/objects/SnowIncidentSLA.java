package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowIncidentSLA implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowIncActive;
	private String snowIncActivityDue;
	private String snowIncAdditionalAssigneeList;
	private String snowIncApproval;
	private String snowIncApprovalHistory;
	private String snowIncApprovalSet;
	private String snowIncAssignedTo;
	private String snowIncAssignmentGroup;
	private String snowIncBusinessDuration;
	private String snowIncBusinessService;
	private String snowIncBusinessStc;
	private String snowIncCalendarDuration;
	private String snowIncCalendarStc;
	private String snowIncCallerId;
	private String snowIncCategory;
	private String snowIncCausedBy;
	private String snowIncCloseCode;
	private String snowIncCloseNotes;
	private String snowIncClosedAt;
	private String snowIncClosedBy;
	private String snowIncCmdbCi;
	private String snowIncComments;
	private String snowIncCompany;
	private String snowIncContactType;
	private String snowIncContract;
	private String snowIncCorrelationDisplay;
	private String snowIncCorrelationId;
	private String snowIncDeliveryPlan;
	private String snowIncDescription;
	private String snowIncDueDate;
	private String snowIncEffort;
	private String snowIncEndDate;
	private String snowIncEscalation;
	private String snowIncExpectedStart;
	private String snowIncFollowUp;
	private String snowIncGroupList;
	private String snowIncImpact;
	private String snowIncKnowledge;
	private String snowIncLocation;
	private String snowIncMadeSla;
	private String snowIncNotify;
	private String snowIncNumber;
	private String snowIncOpenedAt;
	private String snowIncOpenedBy;
	private String snowIncOrder;
	private String snowIncParent;
	private String snowIncPriority;
	private String snowIncProblemId;
	private String snowIncReassignmentCount;
	private String snowIncResolvedAt;
	private String snowIncResolvedBy;
	private String snowIncRfc;
	private String snowIncSeverity;
	private String snowIncShortDescription;
	private String snowIncSkills;
	private String snowIncSlaDue;
	private String snowIncStartDate;
	private String snowIncState;
	private String snowIncStatus;
	private String snowIncSubcategory;
	private String snowIncSysClassName;
	private String snowIncSysCreatedBy;
	private String snowIncSysCreatedOn;
	private String snowIncSysDomain;
	private String snowIncSysId;
	private String snowIncSysModCount;
	private String snowIncSysTags;
	private String snowIncSysUpdatedBy;
	private String snowIncSysUpdatedOn;
	private String snowIncTimeWorked;
	private String snowIncU_3RdLineComments;
	private String snowIncU_3RdLineSrt;
	private String snowIncU_AcknowldgeFeedback;
	private String snowIncU_Acknowledged;
	private String snowIncU_ActiveProbInc;
	private String snowIncU_ActualEffort;
	private String snowIncU_ActualStart;
	private String snowIncU_AffectedAsset;
	private String snowIncU_AffectedUser;
	private String snowIncU_AlertingCi;
	private String snowIncU_AlertingFollowUp;
	private String snowIncU_AlertingRepeatCount;
	private String snowIncU_AlertingReview;
	private String snowIncU_AofDateTime;
	private String snowIncU_AofPass;
	private String snowIncU_AofState;
	private String snowIncU_AofWorkgroup;
	private String snowIncU_AosDateTime;
	private String snowIncU_AosPass;
	private String snowIncU_AosState;
	private String snowIncU_AosWorkgroup;
	private String snowIncU_ApplicationCode;
	private String snowIncU_AssetCode;
	private String snowIncU_AssetString;
	private String snowIncU_AssignedToBladelogic;
	private String snowIncU_AssignmentStatus;
	private String snowIncU_AttachmentsAdded;
	private String snowIncU_AuditCode;
	private String snowIncU_AutoClose;
	private String snowIncU_AutoCloseTicket;
	private String snowIncU_AutoParm1;
	private String snowIncU_AutoParm2;
	private String snowIncU_AutoParm3;
	private String snowIncU_AutoParm4;
	private String snowIncU_AutoParm5;
	private String snowIncU_AutoTarget;
	private String snowIncU_AutoType;
	private String snowIncU_AvailAddComments;
	private String snowIncU_AvailTechSvc;
	private String snowIncU_AvailabilityIncludeOutage;
	private String snowIncU_AvailabilityReport;
	private String snowIncU_BatchStep;
	private String snowIncU_BemUpdates;
	private String snowIncU_BounceCount;
	private String snowIncU_BsdCall;
	private String snowIncU_BsdResolutionBy;
	private String snowIncU_BusinessCritical;
	private String snowIncU_BusinessImpact;
	private String snowIncU_BusinessService;
	private String snowIncU_CallCaptureComments;
	private String snowIncU_CallHandlingComments;
	private String snowIncU_CallOut;
	private String snowIncU_CallOutInvoked;
	private String snowIncU_CauseItem;
	private String snowIncU_CausedBy;
	private String snowIncU_ChangeManager;
	private String snowIncU_CiCategory;
	private String snowIncU_CiClassification;
	private String snowIncU_CiSubcategory;
	private String snowIncU_CiSubclassification;
	private String snowIncU_Classification;
	private String snowIncU_ClosedCentrally;
	private String snowIncU_ClosedPeriod;
	private String snowIncU_ClosureCategory;
	private String snowIncU_ClosureCi;
	private String snowIncU_ClosureRejected;
	private String snowIncU_ClosureSubcategory;
	private String snowIncU_CommentType;
	private String snowIncU_CommentTypeHandling;
	private String snowIncU_CommentsAndWorkNotes;
	private String snowIncU_Communication;
	private String snowIncU_CommunicationEmail;
	private String snowIncU_CommunicationType;
	private String snowIncU_CopyComments;
	private String snowIncU_CopySubject;
	private String snowIncU_CreatedByWorkgroup;
	private String snowIncU_DailyServiceSummary;
	private String snowIncU_DesktopAssetNumber;
	private String snowIncU_DesktopCustomerUnavailable;
	private String snowIncU_DesktopMake;
	private String snowIncU_DesktopModel;
	private String snowIncU_DesktopSN;
	private String snowIncU_DsrImpactComments;
	private String snowIncU_DsrOrganisation;
	private String snowIncU_DsrOutageFinish;
	private String snowIncU_DsrOutageStart;
	private String snowIncU_DsrReportDate;
	private String snowIncU_DsrServiceSAffectedList;
	private String snowIncU_DsrSynopsis;
	private String snowIncU_DsrTimeline;
	private String snowIncU_DssFollowUpActions;
	private String snowIncU_DssOutstandingActions;
	private String snowIncU_DssRootCauseAnalysis;
	private String snowIncU_DssWeighting;
	private String snowIncU_EbondingFailed;
	private String snowIncU_Email;
	private String snowIncU_EmailTemplate;
	private String snowIncU_Escalated;
	private String snowIncU_EscalationType;
	private String snowIncU_EventUrl;
	private String snowIncU_ExpertHelp;
	private String snowIncU_ExternalRef;
	private String snowIncU_FailingObject;
	private String snowIncU_FeedbackCode;
	private String snowIncU_FeedbackCodeHandling;
	private String snowIncU_FirstDeadline;
	private String snowIncU_FirstTimeFix;
	private String snowIncU_Folder;
	private String snowIncU_GlobalSspDashboard;
	private String snowIncU_HighSeverity;
	private String snowIncU_HpCauseCode;
	private String snowIncU_HpClosureCode;
	private String snowIncU_ImpBreakdown;
	private String snowIncU_IncidentManager;
	private String snowIncU_IncidentSummary;
	private String snowIncU_IncidentUpdate;
	private String snowIncU_InitialAssignment;
	private String snowIncU_Instructions;
	private String snowIncU_InternalRef;
	private String snowIncU_IsHpPendingCustomer;
	private String snowIncU_IssueTitle;
	private String snowIncU_ItilWatchList;
	private String snowIncU_JobNumber;
	private String snowIncU_KnowledgeArticle;
	private String snowIncU_KnowledgeAvailable;
	private String snowIncU_KnowledgeCode;
	private String snowIncU_KnowledgeComments;
	private String snowIncU_KnowledgeDirectory;
	private String snowIncU_KnowledgeFound;
	private String snowIncU_KnowledgeUser;
	private String snowIncU_LastOccurrence;
	private String snowIncU_LateImpReason;
	private String snowIncU_LeadTime;
	private String snowIncU_LiveFeedGroup;
	private String snowIncU_LiveFeedGroupDuplicate;
	private String snowIncU_LocalResp;
	private String snowIncU_MajorIncident;
	private String snowIncU_ManagementAuditComments;
	private String snowIncU_ManagementComments;
	private String snowIncU_MissingCi;
	private String snowIncU_MissingCiFlag;
	private String snowIncU_ModifiedPeriod;
	private String snowIncU_MultipleCountrySspDashboa;
	private String snowIncU_Name;
	private String snowIncU_NewDate;
	private String snowIncU_NextAssignment;
	private String snowIncU_Now92Sites;
	private String snowIncU_OlaTaskName;
	private String snowIncU_OpenedPeriod;
	private String snowIncU_OperatingUnit;
	private String snowIncU_OutageDuration;
	private String snowIncU_OutsourceAssignedOut;
	private String snowIncU_OutsourceAssignee;
	private String snowIncU_OutsourceId;
	private String snowIncU_OutsourceIntegration;
	private String snowIncU_OutsourceModule;
	private String snowIncU_OutsourceResponse;
	private String snowIncU_OutsourceResult;
	private String snowIncU_OutsourceStatus;
	private String snowIncU_OutsourceTeam;
	private String snowIncU_Override1;
	private String snowIncU_ParentIncident;
	private String snowIncU_PendingReason;
	private String snowIncU_Person;
	private String snowIncU_PersonAudited;
	private String snowIncU_PersonAuditing;
	private String snowIncU_Phone;
	private String snowIncU_PickupDuration;
	private String snowIncU_PlannedEffort;
	private String snowIncU_PlannedImplementationWeek;
	private String snowIncU_PnetHpEbond;
	private String snowIncU_PreviousGroup;
	private String snowIncU_PreviousHpWorkgroup;
	private String snowIncU_PreviousStatus;
	private String snowIncU_QueryCount;
	private String snowIncU_RegionImpacted;
	private String snowIncU_RejectionCount;
	private String snowIncU_RelatedIncidents;
	private String snowIncU_RelatedRequest;
	private String snowIncU_ReopenCount;
	private String snowIncU_ReopenedDate;
	private String snowIncU_RepeatIncident;
	private String snowIncU_ResolutionOverride;
	private String snowIncU_ResolutionReason;
	private String snowIncU_ResolutionType;
	private String snowIncU_ResolvedBy;
	private String snowIncU_ResolvedByWorkgroup;
	private String snowIncU_Resolver;
	private String snowIncU_ResponseFlag;
	private String snowIncU_ResponseOverride;
	private String snowIncU_ResponseReason;
	private String snowIncU_SavedCount;
	private String snowIncU_SdOlaPause;
	private String snowIncU_SecondDeadline;
	private String snowIncU_SelectApplication;
	private String snowIncU_SelectEuc;
	private String snowIncU_SelectInfrastructure;
	private String snowIncU_SelectNetwork;
	private String snowIncU_ServiceImpactPct;
	private String snowIncU_ServiceState;
	private String snowIncU_SitesAffected;
	private String snowIncU_SlaFailureWorkgroup;
	private String snowIncU_SlaState;
	private String snowIncU_SlfApprover;
	private String snowIncU_SlfComponent;
	private String snowIncU_SlfReason;
	private String snowIncU_SlfReviewDate;
	private String snowIncU_SmsGroup;
	private String snowIncU_SmsMessage;
	private String snowIncU_SmsTemplate;
	private String snowIncU_SourceId;
	private String snowIncU_SrtFail;
	private String snowIncU_SrtPass;
	private String snowIncU_SrtState;
	private String snowIncU_SspAffected;
	private String snowIncU_SspDashboard;
	private String snowIncU_SspDashboardLocalIs;
	private String snowIncU_SspDashboardLocal;
	private String snowIncU_SspForm;
	private String snowIncU_Subject;
	private String snowIncU_SupportStructure;
	private String snowIncU_SupportType;
	private String snowIncU_SuspendOffTime;
	private String snowIncU_TaskType;
	private String snowIncU_Template;
	private String snowIncU_ThirdLineComments;
	private String snowIncU_ThirdLineDate;
	private String snowIncU_ThirdPartyReference;
	private String snowIncU_TimeToAuth;
	private String snowIncU_TimeToClose;
	private String snowIncU_TntSiteType;
	private String snowIncU_Triaged;
	private String snowIncU_UnderOla;
	private String snowIncU_UsersAffected;
	private String snowIncU_VerrizonOutage;
	private String snowIncU_VzCorrelationId;
	private String snowIncU_VzSequenceNumber;
	private String snowIncU_WebId;
	private String snowIncU_WebUpdate;
	private String snowIncU_WiproId;
	private String snowIncU_WorkgroupsCalledOut;
	private String snowIncUponApproval;
	private String snowIncUponReject;
	private String snowIncUrgency;
	private String snowIncUserInput;
	private String snowIncVzReleaseForTest;
	private String snowIncVzReleaseForTestDatetime;
	private String snowIncWatchList;
	private String snowIncWfActivity;
	private String snowIncWorkEffort;
	private String snowIncWorkEnd;
	private String snowIncWorkNotes;
	private String snowIncWorkStart;
	private String snowTaskslatableActive;
	private String snowTaskslatableBusinessDuration;
	private String snowTaskslatableBusinessPauseDuration;
	private String snowTaskslatableBusinessPercentage;
	private String snowTaskslatableBusinessTimeLeft;
	private String snowTaskslatableDuration;
	private String snowTaskslatableEndTime;
	private String snowTaskslatableHasBreached;
	private String snowTaskslatableOriginalBreachTime;
	private String snowTaskslatablePauseDuration;
	private String snowTaskslatablePauseTime;
	private String snowTaskslatablePercentage;
	private String snowTaskslatablePlannedEndTime;
	private String snowTaskslatableSchedule;
	private String snowTaskslatableSla;
	private String snowTaskslatableStage;
	private String snowTaskslatableStartTime;
	private String snowTaskslatableSysCreatedBy;
	private String snowTaskslatableSysCreatedOn;
	private String snowTaskslatableSysId;
	private String snowTaskslatableSysModCount;
	private String snowTaskslatableSysTags;
	private String snowTaskslatableSysUpdatedBy;
	private String snowTaskslatableSysUpdatedOn;
	private String snowTaskslatableTask;
	private String snowTaskslatableTimeLeft;
	private String snowTaskslatableTimezone;
	private String snowTaskslatableU_InScope;
	private String snowTaskslatableU_KbArticle;

	public SnowIncidentSLA() {
	}
	
	public SnowIncidentSLA(HashMap<String, Object> jsonValues) {
		snowIncActive = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_active"));
		snowIncActivityDue = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_activity_due"));
		snowIncAdditionalAssigneeList = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_additional_assignee_list"));
		snowIncApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_approval"));
		snowIncApprovalHistory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_approval_history"));
		snowIncApprovalSet = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_approval_set"));
		snowIncAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_assigned_to"));
		snowIncAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_assignment_group"));
		snowIncBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_business_duration"));
		snowIncBusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_business_service"));
		snowIncBusinessStc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_business_stc"));
		snowIncCalendarDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_calendar_duration"));
		snowIncCalendarStc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_calendar_stc"));
		snowIncCallerId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_caller_id"));
		snowIncCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_category"));
		snowIncCausedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_caused_by"));
		snowIncCloseCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_close_code"));
		snowIncCloseNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_close_notes"));
		snowIncClosedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_closed_at"));
		snowIncClosedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_closed_by"));
		snowIncCmdbCi = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_cmdb_ci"));
		snowIncComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_comments"));
		snowIncCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_company"));
		snowIncContactType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_contact_type"));
		snowIncContract = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_contract"));
		snowIncCorrelationDisplay = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_correlation_display"));
		snowIncCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_correlation_id"));
		snowIncDeliveryPlan = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_delivery_plan"));
		snowIncDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_description"));
		snowIncDueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_due_date"));
		snowIncEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_effort"));
		snowIncEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_end_date"));
		snowIncEscalation = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_escalation"));
		snowIncExpectedStart = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_expected_start"));
		snowIncFollowUp = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_follow_up"));
		snowIncGroupList = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_group_list"));
		snowIncImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_impact"));
		snowIncKnowledge = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_knowledge"));
		snowIncLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_location"));
		snowIncMadeSla = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_made_sla"));
		snowIncNotify = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_notify"));
		snowIncNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_number"));
		snowIncOpenedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_opened_at"));
		snowIncOpenedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_opened_by"));
		snowIncOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_order"));
		snowIncParent = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_parent"));
		snowIncPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_priority"));
		snowIncProblemId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_problem_id"));
		snowIncReassignmentCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_reassignment_count"));
		snowIncResolvedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_resolved_at"));
		snowIncResolvedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_resolved_by"));
		snowIncRfc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_rfc"));
		snowIncSeverity = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_severity"));
		snowIncShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_short_description"));
		snowIncSkills = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_skills"));
		snowIncSlaDue = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sla_due"));
		snowIncStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_start_date"));
		snowIncState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_state"));
		snowIncStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_status"));
		snowIncSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_subcategory"));
		snowIncSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_class_name"));
		snowIncSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_created_by"));
		snowIncSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_created_on"));
		snowIncSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_domain"));
		snowIncSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_id"));
		snowIncSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_mod_count"));
		snowIncSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_tags"));
		snowIncSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_updated_by"));
		snowIncSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_sys_updated_on"));
		snowIncTimeWorked = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_time_worked"));
		snowIncU_3RdLineComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_3rd_line_comments"));
		snowIncU_3RdLineSrt = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_3rd_line_srt"));
		snowIncU_AcknowldgeFeedback = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_acknowldge_feedback"));
		snowIncU_Acknowledged = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_acknowledged"));
		snowIncU_ActiveProbInc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_active_prob_inc"));
		snowIncU_ActualEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_actual_effort"));
		snowIncU_ActualStart = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_actual_start"));
		snowIncU_AffectedAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_affected_asset"));
		snowIncU_AffectedUser = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_affected_user"));
		snowIncU_AlertingCi = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_alerting_ci"));
		snowIncU_AlertingFollowUp = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_alerting_follow_up"));
		snowIncU_AlertingRepeatCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_alerting_repeat_count"));
		snowIncU_AlertingReview = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_alerting_review"));
		snowIncU_AofDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aof_date__time"));
		snowIncU_AofPass = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aof_pass"));
		snowIncU_AofState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aof_state"));
		snowIncU_AofWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aof_workgroup"));
		snowIncU_AosDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aos_date__time"));
		snowIncU_AosPass = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aos_pass"));
		snowIncU_AosState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aos_state"));
		snowIncU_AosWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_aos_workgroup"));
		snowIncU_ApplicationCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_application_code"));
		snowIncU_AssetCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_asset_code"));
		snowIncU_AssetString = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_asset_string"));
		snowIncU_AssignedToBladelogic = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_assigned_to_bladelogic"));
		snowIncU_AssignmentStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_assignment_status"));
		snowIncU_AttachmentsAdded = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_attachments_added"));
		snowIncU_AuditCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_audit__code"));
		snowIncU_AutoClose = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_close"));
		snowIncU_AutoCloseTicket = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_close_ticket"));
		snowIncU_AutoParm1 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_parm1"));
		snowIncU_AutoParm2 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_parm2"));
		snowIncU_AutoParm3 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_parm3"));
		snowIncU_AutoParm4 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_parm4"));
		snowIncU_AutoParm5 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_parm5"));
		snowIncU_AutoTarget = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_target"));
		snowIncU_AutoType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_auto_type"));
		snowIncU_AvailAddComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_avail_add_comments"));
		snowIncU_AvailTechSvc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_avail_tech_svc"));
		snowIncU_AvailabilityIncludeOutage = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_availability_include_outage_"));
		snowIncU_AvailabilityReport = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_availability_report"));
		snowIncU_BatchStep = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_batch_step"));
		snowIncU_BemUpdates = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_bem_updates"));
		snowIncU_BounceCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_bounce_count"));
		snowIncU_BsdCall = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_bsd_call"));
		snowIncU_BsdResolutionBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_bsd_resolution_by"));
		snowIncU_BusinessCritical = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_business_critical"));
		snowIncU_BusinessImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_business_impact"));
		snowIncU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_business_service"));
		snowIncU_CallCaptureComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_call_capture_comments"));
		snowIncU_CallHandlingComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_call_handling_comments"));
		snowIncU_CallOut = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_call_out"));
		snowIncU_CallOutInvoked = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_call_out_invoked"));
		snowIncU_CauseItem = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_cause_item"));
		snowIncU_CausedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_caused_by"));
		snowIncU_ChangeManager = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_change_manager"));
		snowIncU_CiCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ci_category"));
		snowIncU_CiClassification = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ci_classification"));
		snowIncU_CiSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ci_subcategory"));
		snowIncU_CiSubclassification = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ci_subclassification"));
		snowIncU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_classification"));
		snowIncU_ClosedCentrally = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closed_centrally"));
		snowIncU_ClosedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closed_period"));
		snowIncU_ClosureCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closure_category"));
		snowIncU_ClosureCi = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closure_ci"));
		snowIncU_ClosureRejected = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closure_rejected"));
		snowIncU_ClosureSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_closure_subcategory"));
		snowIncU_CommentType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_comment_type"));
		snowIncU_CommentTypeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_comment_type_handling"));
		snowIncU_CommentsAndWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_comments_and_work_notes"));
		snowIncU_Communication = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_communication"));
		snowIncU_CommunicationEmail = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_communication_email"));
		snowIncU_CommunicationType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_communication_type"));
		snowIncU_CopyComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_copy_comments"));
		snowIncU_CopySubject = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_copy_subject"));
		snowIncU_CreatedByWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_created_by_workgroup"));
		snowIncU_DailyServiceSummary = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_daily_service_summary"));
		snowIncU_DesktopAssetNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_desktop_asset_number"));
		snowIncU_DesktopCustomerUnavailable = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_desktop_customer_unavailable"));
		snowIncU_DesktopMake = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_desktop_make"));
		snowIncU_DesktopModel = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_desktop_model"));
		snowIncU_DesktopSN = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_desktop_s_n"));
		snowIncU_DsrImpactComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_impact_comments"));
		snowIncU_DsrOrganisation = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_organisation"));
		snowIncU_DsrOutageFinish = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_outage_finish"));
		snowIncU_DsrOutageStart = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_outage_start"));
		snowIncU_DsrReportDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_report_date"));
		snowIncU_DsrServiceSAffectedList = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_service_s_affected_list"));
		snowIncU_DsrSynopsis = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_synopsis"));
		snowIncU_DsrTimeline = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dsr_timeline"));
		snowIncU_DssFollowUpActions = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dss_follow_up_actions"));
		snowIncU_DssOutstandingActions = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dss_outstanding_actions"));
		snowIncU_DssRootCauseAnalysis = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dss_root_cause_analysis"));
		snowIncU_DssWeighting = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_dss_weighting"));
		snowIncU_EbondingFailed = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ebonding_failed"));
		snowIncU_Email = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_email"));
		snowIncU_EmailTemplate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_email_template"));
		snowIncU_Escalated = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_escalated"));
		snowIncU_EscalationType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_escalation_type"));
		snowIncU_EventUrl = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_event_url"));
		snowIncU_ExpertHelp = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_expert_help"));
		snowIncU_ExternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_external_ref"));
		snowIncU_FailingObject = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_failing_object"));
		snowIncU_FeedbackCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_feedback_code"));
		snowIncU_FeedbackCodeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_feedback_code_handling"));
		snowIncU_FirstDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_first_deadline"));
		snowIncU_FirstTimeFix = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_first_time_fix"));
		snowIncU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_folder"));
		snowIncU_GlobalSspDashboard = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_global_ssp_dashboard"));
		snowIncU_HighSeverity = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_high_severity"));
		snowIncU_HpCauseCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_hp_cause_code"));
		snowIncU_HpClosureCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_hp_closure_code"));
		snowIncU_ImpBreakdown = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_imp_breakdown"));
		snowIncU_IncidentManager = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_incident_manager"));
		snowIncU_IncidentSummary = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_incident_summary"));
		snowIncU_IncidentUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_incident_update"));
		snowIncU_InitialAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_initial_assignment"));
		snowIncU_Instructions = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_instructions"));
		snowIncU_InternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_internal_ref"));
		snowIncU_IsHpPendingCustomer = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_is_hp_pending_customer"));
		snowIncU_IssueTitle = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_issue_title"));
		snowIncU_ItilWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_itil_watch_list"));
		snowIncU_JobNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_job_number"));
		snowIncU_KnowledgeArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_article"));
		snowIncU_KnowledgeAvailable = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_available"));
		snowIncU_KnowledgeCode = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_code"));
		snowIncU_KnowledgeComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_comments"));
		snowIncU_KnowledgeDirectory = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_directory"));
		snowIncU_KnowledgeFound = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_found"));
		snowIncU_KnowledgeUser = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_knowledge_user"));
		snowIncU_LastOccurrence = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_last_occurrence"));
		snowIncU_LateImpReason = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_late_imp_reason"));
		snowIncU_LeadTime = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_lead_time"));
		snowIncU_LiveFeedGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_live_feed_group"));
		snowIncU_LiveFeedGroupDuplicate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_live_feed_group_duplicate"));
		snowIncU_LocalResp = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_local_resp"));
		snowIncU_MajorIncident = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_major_incident"));
		snowIncU_ManagementAuditComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_management_audit_comments"));
		snowIncU_ManagementComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_management_comments"));
		snowIncU_MissingCi = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_missing_ci"));
		snowIncU_MissingCiFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_missing_ci_flag"));
		snowIncU_ModifiedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_modified_period"));
		snowIncU_MultipleCountrySspDashboa = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_multiple_country_ssp_dashboa"));
		snowIncU_Name = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_name"));
		snowIncU_NewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_new_date"));
		snowIncU_NextAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_next_assignment"));
		snowIncU_Now92Sites = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_now92_sites"));
		snowIncU_OlaTaskName = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ola_task_name"));
		snowIncU_OpenedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_opened_period"));
		snowIncU_OperatingUnit = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_operating_unit"));
		snowIncU_OutageDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outage_duration"));
		snowIncU_OutsourceAssignedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_assigned_out"));
		snowIncU_OutsourceAssignee = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_assignee"));
		snowIncU_OutsourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_id"));
		snowIncU_OutsourceIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_integration"));
		snowIncU_OutsourceModule = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_module"));
		snowIncU_OutsourceResponse = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_response"));
		snowIncU_OutsourceResult = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_result"));
		snowIncU_OutsourceStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_status"));
		snowIncU_OutsourceTeam = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_outsource_team"));
		snowIncU_Override1 = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_override1"));
		snowIncU_ParentIncident = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_parent_incident"));
		snowIncU_PendingReason = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_pending_reason"));
		snowIncU_Person = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_person"));
		snowIncU_PersonAudited = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_person_audited"));
		snowIncU_PersonAuditing = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_person_auditing"));
		snowIncU_Phone = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_phone"));
		snowIncU_PickupDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_pickup_duration"));
		snowIncU_PlannedEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_planned_effort"));
		snowIncU_PlannedImplementationWeek = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_planned_implementation_week"));
		snowIncU_PnetHpEbond = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_pnet_hp_ebond"));
		snowIncU_PreviousGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_previous_group"));
		snowIncU_PreviousHpWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_previous_hp_workgroup"));
		snowIncU_PreviousStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_previous_status"));
		snowIncU_QueryCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_query_count"));
		snowIncU_RegionImpacted = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_region_impacted"));
		snowIncU_RejectionCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_rejection_count"));
		snowIncU_RelatedIncidents = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_related_incidents"));
		snowIncU_RelatedRequest = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_related_request"));
		snowIncU_ReopenCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_reopen_count"));
		snowIncU_ReopenedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_reopened_date"));
		snowIncU_RepeatIncident = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_repeat_incident"));
		snowIncU_ResolutionOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolution_override"));
		snowIncU_ResolutionReason = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolution_reason"));
		snowIncU_ResolutionType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolution_type"));
		snowIncU_ResolvedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolved_by"));
		snowIncU_ResolvedByWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolved_by_workgroup"));
		snowIncU_Resolver = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_resolver"));
		snowIncU_ResponseFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_response_flag"));
		snowIncU_ResponseOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_response_override"));
		snowIncU_ResponseReason = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_response_reason"));
		snowIncU_SavedCount = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_saved_count"));
		snowIncU_SdOlaPause = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sd_ola_pause"));
		snowIncU_SecondDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_second_deadline"));
		snowIncU_SelectApplication = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_select_application"));
		snowIncU_SelectEuc = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_select_euc"));
		snowIncU_SelectInfrastructure = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_select_infrastructure"));
		snowIncU_SelectNetwork = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_select_network"));
		snowIncU_ServiceImpactPct = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_service_impact_pct"));
		snowIncU_ServiceState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_service_state"));
		snowIncU_SitesAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sites_affected"));
		snowIncU_SlaFailureWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sla_failure_workgroup"));
		snowIncU_SlaState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sla_state"));
		snowIncU_SlfApprover = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_slf_approver"));
		snowIncU_SlfComponent = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_slf_component"));
		snowIncU_SlfReason = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_slf_reason"));
		snowIncU_SlfReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_slf_review_date"));
		snowIncU_SmsGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sms_group"));
		snowIncU_SmsMessage = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sms_message"));
		snowIncU_SmsTemplate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_sms_template"));
		snowIncU_SourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_source_id"));
		snowIncU_SrtFail = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_srt_fail"));
		snowIncU_SrtPass = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_srt_pass"));
		snowIncU_SrtState = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_srt_state"));
		snowIncU_SspAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ssp_affected"));
		snowIncU_SspDashboard = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ssp_dashboard"));
		snowIncU_SspDashboardLocalIs = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ssp_dashboard__local_is_"));
		snowIncU_SspDashboardLocal = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ssp_dashboard_local"));
		snowIncU_SspForm = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_ssp_form"));
		snowIncU_Subject = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_subject"));
		snowIncU_SupportStructure = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_support_structure"));
		snowIncU_SupportType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_support_type"));
		snowIncU_SuspendOffTime = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_suspend_off_time"));
		snowIncU_TaskType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_task_type"));
		snowIncU_Template = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_template"));
		snowIncU_ThirdLineComments = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_third_line_comments"));
		snowIncU_ThirdLineDate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_third_line_date"));
		snowIncU_ThirdPartyReference = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_third_party_reference"));
		snowIncU_TimeToAuth = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_time_to_auth"));
		snowIncU_TimeToClose = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_time_to_close"));
		snowIncU_TntSiteType = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_tnt_site_type"));
		snowIncU_Triaged = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_triaged"));
		snowIncU_UnderOla = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_under_ola"));
		snowIncU_UsersAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_users_affected"));
		snowIncU_VerrizonOutage = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_verrizon_outage"));
		snowIncU_VzCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_vz_correlation_id"));
		snowIncU_VzSequenceNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_vz_sequence_number"));
		snowIncU_WebId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_web_id"));
		snowIncU_WebUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_web_update"));
		snowIncU_WiproId = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_wipro_id"));
		snowIncU_WorkgroupsCalledOut = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_u_workgroups_called_out"));
		snowIncUponApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_upon_approval"));
		snowIncUponReject = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_upon_reject"));
		snowIncUrgency = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_urgency"));
		snowIncUserInput = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_user_input"));
		snowIncVzReleaseForTest = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_vz_release_for_test"));
		snowIncVzReleaseForTestDatetime = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_vz_release_for_test_datetime"));
		snowIncWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_watch_list"));
		snowIncWfActivity = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_wf_activity"));
		snowIncWorkEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_work_effort"));
		snowIncWorkEnd = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_work_end"));
		snowIncWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_work_notes"));
		snowIncWorkStart = SnowUtilities.getStringValueFromObject(jsonValues.get("inc_work_start"));
		snowTaskslatableActive = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_active"));
		snowTaskslatableBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_duration"));
		snowTaskslatableBusinessPauseDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_pause_duration"));
		snowTaskslatableBusinessPercentage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_percentage"));
		snowTaskslatableBusinessTimeLeft = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_time_left"));
		snowTaskslatableDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_duration"));
		snowTaskslatableEndTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_end_time"));
		snowTaskslatableHasBreached = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_has_breached"));
		snowTaskslatableOriginalBreachTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_original_breach_time"));
		snowTaskslatablePauseDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_pause_duration"));
		snowTaskslatablePauseTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_pause_time"));
		snowTaskslatablePercentage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_percentage"));
		snowTaskslatablePlannedEndTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_planned_end_time"));
		snowTaskslatableSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_schedule"));
		snowTaskslatableSla = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sla"));
		snowTaskslatableStage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_stage"));
		snowTaskslatableStartTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_start_time"));
		snowTaskslatableSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_created_by"));
		snowTaskslatableSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_created_on"));
		snowTaskslatableSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_id"));
		snowTaskslatableSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_mod_count"));
		snowTaskslatableSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_tags"));
		snowTaskslatableSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_updated_by"));
		snowTaskslatableSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_updated_on"));
		snowTaskslatableTask = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_task"));
		snowTaskslatableTimeLeft = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_time_left"));
		snowTaskslatableTimezone = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_timezone"));
		snowTaskslatableU_InScope = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_u_in_scope"));
		snowTaskslatableU_KbArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_u_kb_article"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowIncActive != null && !snowIncActive.toString().isEmpty()) jsonObject.put("inc_active", snowIncActive);
		if (snowIncActivityDue != null && !snowIncActivityDue.toString().isEmpty()) jsonObject.put("inc_activity_due", snowIncActivityDue);
		if (snowIncAdditionalAssigneeList != null && !snowIncAdditionalAssigneeList.toString().isEmpty()) jsonObject.put("inc_additional_assignee_list", snowIncAdditionalAssigneeList);
		if (snowIncApproval != null && !snowIncApproval.toString().isEmpty()) jsonObject.put("inc_approval", snowIncApproval);
		if (snowIncApprovalHistory != null && !snowIncApprovalHistory.toString().isEmpty()) jsonObject.put("inc_approval_history", snowIncApprovalHistory);
		if (snowIncApprovalSet != null && !snowIncApprovalSet.toString().isEmpty()) jsonObject.put("inc_approval_set", snowIncApprovalSet);
		if (snowIncAssignedTo != null && !snowIncAssignedTo.toString().isEmpty()) jsonObject.put("inc_assigned_to", snowIncAssignedTo);
		if (snowIncAssignmentGroup != null && !snowIncAssignmentGroup.toString().isEmpty()) jsonObject.put("inc_assignment_group", snowIncAssignmentGroup);
		if (snowIncBusinessDuration != null && !snowIncBusinessDuration.toString().isEmpty()) jsonObject.put("inc_business_duration", snowIncBusinessDuration);
		if (snowIncBusinessService != null && !snowIncBusinessService.toString().isEmpty()) jsonObject.put("inc_business_service", snowIncBusinessService);
		if (snowIncBusinessStc != null && !snowIncBusinessStc.toString().isEmpty()) jsonObject.put("inc_business_stc", snowIncBusinessStc);
		if (snowIncCalendarDuration != null && !snowIncCalendarDuration.toString().isEmpty()) jsonObject.put("inc_calendar_duration", snowIncCalendarDuration);
		if (snowIncCalendarStc != null && !snowIncCalendarStc.toString().isEmpty()) jsonObject.put("inc_calendar_stc", snowIncCalendarStc);
		if (snowIncCallerId != null && !snowIncCallerId.toString().isEmpty()) jsonObject.put("inc_caller_id", snowIncCallerId);
		if (snowIncCategory != null && !snowIncCategory.toString().isEmpty()) jsonObject.put("inc_category", snowIncCategory);
		if (snowIncCausedBy != null && !snowIncCausedBy.toString().isEmpty()) jsonObject.put("inc_caused_by", snowIncCausedBy);
		if (snowIncCloseCode != null && !snowIncCloseCode.toString().isEmpty()) jsonObject.put("inc_close_code", snowIncCloseCode);
		if (snowIncCloseNotes != null && !snowIncCloseNotes.toString().isEmpty()) jsonObject.put("inc_close_notes", snowIncCloseNotes);
		if (snowIncClosedAt != null && !snowIncClosedAt.toString().isEmpty()) jsonObject.put("inc_closed_at", snowIncClosedAt);
		if (snowIncClosedBy != null && !snowIncClosedBy.toString().isEmpty()) jsonObject.put("inc_closed_by", snowIncClosedBy);
		if (snowIncCmdbCi != null && !snowIncCmdbCi.toString().isEmpty()) jsonObject.put("inc_cmdb_ci", snowIncCmdbCi);
		if (snowIncComments != null && !snowIncComments.toString().isEmpty()) jsonObject.put("inc_comments", snowIncComments);
		if (snowIncCompany != null && !snowIncCompany.toString().isEmpty()) jsonObject.put("inc_company", snowIncCompany);
		if (snowIncContactType != null && !snowIncContactType.toString().isEmpty()) jsonObject.put("inc_contact_type", snowIncContactType);
		if (snowIncContract != null && !snowIncContract.toString().isEmpty()) jsonObject.put("inc_contract", snowIncContract);
		if (snowIncCorrelationDisplay != null && !snowIncCorrelationDisplay.toString().isEmpty()) jsonObject.put("inc_correlation_display", snowIncCorrelationDisplay);
		if (snowIncCorrelationId != null && !snowIncCorrelationId.toString().isEmpty()) jsonObject.put("inc_correlation_id", snowIncCorrelationId);
		if (snowIncDeliveryPlan != null && !snowIncDeliveryPlan.toString().isEmpty()) jsonObject.put("inc_delivery_plan", snowIncDeliveryPlan);
		if (snowIncDescription != null && !snowIncDescription.toString().isEmpty()) jsonObject.put("inc_description", snowIncDescription);
		if (snowIncDueDate != null && !snowIncDueDate.toString().isEmpty()) jsonObject.put("inc_due_date", snowIncDueDate);
		if (snowIncEffort != null && !snowIncEffort.toString().isEmpty()) jsonObject.put("inc_effort", snowIncEffort);
		if (snowIncEndDate != null && !snowIncEndDate.toString().isEmpty()) jsonObject.put("inc_end_date", snowIncEndDate);
		if (snowIncEscalation != null && !snowIncEscalation.toString().isEmpty()) jsonObject.put("inc_escalation", snowIncEscalation);
		if (snowIncExpectedStart != null && !snowIncExpectedStart.toString().isEmpty()) jsonObject.put("inc_expected_start", snowIncExpectedStart);
		if (snowIncFollowUp != null && !snowIncFollowUp.toString().isEmpty()) jsonObject.put("inc_follow_up", snowIncFollowUp);
		if (snowIncGroupList != null && !snowIncGroupList.toString().isEmpty()) jsonObject.put("inc_group_list", snowIncGroupList);
		if (snowIncImpact != null && !snowIncImpact.toString().isEmpty()) jsonObject.put("inc_impact", snowIncImpact);
		if (snowIncKnowledge != null && !snowIncKnowledge.toString().isEmpty()) jsonObject.put("inc_knowledge", snowIncKnowledge);
		if (snowIncLocation != null && !snowIncLocation.toString().isEmpty()) jsonObject.put("inc_location", snowIncLocation);
		if (snowIncMadeSla != null && !snowIncMadeSla.toString().isEmpty()) jsonObject.put("inc_made_sla", snowIncMadeSla);
		if (snowIncNotify != null && !snowIncNotify.toString().isEmpty()) jsonObject.put("inc_notify", snowIncNotify);
		if (snowIncNumber != null && !snowIncNumber.toString().isEmpty()) jsonObject.put("inc_number", snowIncNumber);
		if (snowIncOpenedAt != null && !snowIncOpenedAt.toString().isEmpty()) jsonObject.put("inc_opened_at", snowIncOpenedAt);
		if (snowIncOpenedBy != null && !snowIncOpenedBy.toString().isEmpty()) jsonObject.put("inc_opened_by", snowIncOpenedBy);
		if (snowIncOrder != null && !snowIncOrder.toString().isEmpty()) jsonObject.put("inc_order", snowIncOrder);
		if (snowIncParent != null && !snowIncParent.toString().isEmpty()) jsonObject.put("inc_parent", snowIncParent);
		if (snowIncPriority != null && !snowIncPriority.toString().isEmpty()) jsonObject.put("inc_priority", snowIncPriority);
		if (snowIncProblemId != null && !snowIncProblemId.toString().isEmpty()) jsonObject.put("inc_problem_id", snowIncProblemId);
		if (snowIncReassignmentCount != null && !snowIncReassignmentCount.toString().isEmpty()) jsonObject.put("inc_reassignment_count", snowIncReassignmentCount);
		if (snowIncResolvedAt != null && !snowIncResolvedAt.toString().isEmpty()) jsonObject.put("inc_resolved_at", snowIncResolvedAt);
		if (snowIncResolvedBy != null && !snowIncResolvedBy.toString().isEmpty()) jsonObject.put("inc_resolved_by", snowIncResolvedBy);
		if (snowIncRfc != null && !snowIncRfc.toString().isEmpty()) jsonObject.put("inc_rfc", snowIncRfc);
		if (snowIncSeverity != null && !snowIncSeverity.toString().isEmpty()) jsonObject.put("inc_severity", snowIncSeverity);
		if (snowIncShortDescription != null && !snowIncShortDescription.toString().isEmpty()) jsonObject.put("inc_short_description", snowIncShortDescription);
		if (snowIncSkills != null && !snowIncSkills.toString().isEmpty()) jsonObject.put("inc_skills", snowIncSkills);
		if (snowIncSlaDue != null && !snowIncSlaDue.toString().isEmpty()) jsonObject.put("inc_sla_due", snowIncSlaDue);
		if (snowIncStartDate != null && !snowIncStartDate.toString().isEmpty()) jsonObject.put("inc_start_date", snowIncStartDate);
		if (snowIncState != null && !snowIncState.toString().isEmpty()) jsonObject.put("inc_state", snowIncState);
		if (snowIncStatus != null && !snowIncStatus.toString().isEmpty()) jsonObject.put("inc_status", snowIncStatus);
		if (snowIncSubcategory != null && !snowIncSubcategory.toString().isEmpty()) jsonObject.put("inc_subcategory", snowIncSubcategory);
		if (snowIncSysClassName != null && !snowIncSysClassName.toString().isEmpty()) jsonObject.put("inc_sys_class_name", snowIncSysClassName);
		if (snowIncSysCreatedBy != null && !snowIncSysCreatedBy.toString().isEmpty()) jsonObject.put("inc_sys_created_by", snowIncSysCreatedBy);
		if (snowIncSysCreatedOn != null && !snowIncSysCreatedOn.toString().isEmpty()) jsonObject.put("inc_sys_created_on", snowIncSysCreatedOn);
		if (snowIncSysDomain != null && !snowIncSysDomain.toString().isEmpty()) jsonObject.put("inc_sys_domain", snowIncSysDomain);
		if (snowIncSysId != null && !snowIncSysId.toString().isEmpty()) jsonObject.put("inc_sys_id", snowIncSysId);
		if (snowIncSysModCount != null && !snowIncSysModCount.toString().isEmpty()) jsonObject.put("inc_sys_mod_count", snowIncSysModCount);
		if (snowIncSysTags != null && !snowIncSysTags.toString().isEmpty()) jsonObject.put("inc_sys_tags", snowIncSysTags);
		if (snowIncSysUpdatedBy != null && !snowIncSysUpdatedBy.toString().isEmpty()) jsonObject.put("inc_sys_updated_by", snowIncSysUpdatedBy);
		if (snowIncSysUpdatedOn != null && !snowIncSysUpdatedOn.toString().isEmpty()) jsonObject.put("inc_sys_updated_on", snowIncSysUpdatedOn);
		if (snowIncTimeWorked != null && !snowIncTimeWorked.toString().isEmpty()) jsonObject.put("inc_time_worked", snowIncTimeWorked);
		if (snowIncU_3RdLineComments != null && !snowIncU_3RdLineComments.toString().isEmpty()) jsonObject.put("inc_u_3rd_line_comments", snowIncU_3RdLineComments);
		if (snowIncU_3RdLineSrt != null && !snowIncU_3RdLineSrt.toString().isEmpty()) jsonObject.put("inc_u_3rd_line_srt", snowIncU_3RdLineSrt);
		if (snowIncU_AcknowldgeFeedback != null && !snowIncU_AcknowldgeFeedback.toString().isEmpty()) jsonObject.put("inc_u_acknowldge_feedback", snowIncU_AcknowldgeFeedback);
		if (snowIncU_Acknowledged != null && !snowIncU_Acknowledged.toString().isEmpty()) jsonObject.put("inc_u_acknowledged", snowIncU_Acknowledged);
		if (snowIncU_ActiveProbInc != null && !snowIncU_ActiveProbInc.toString().isEmpty()) jsonObject.put("inc_u_active_prob_inc", snowIncU_ActiveProbInc);
		if (snowIncU_ActualEffort != null && !snowIncU_ActualEffort.toString().isEmpty()) jsonObject.put("inc_u_actual_effort", snowIncU_ActualEffort);
		if (snowIncU_ActualStart != null && !snowIncU_ActualStart.toString().isEmpty()) jsonObject.put("inc_u_actual_start", snowIncU_ActualStart);
		if (snowIncU_AffectedAsset != null && !snowIncU_AffectedAsset.toString().isEmpty()) jsonObject.put("inc_u_affected_asset", snowIncU_AffectedAsset);
		if (snowIncU_AffectedUser != null && !snowIncU_AffectedUser.toString().isEmpty()) jsonObject.put("inc_u_affected_user", snowIncU_AffectedUser);
		if (snowIncU_AlertingCi != null && !snowIncU_AlertingCi.toString().isEmpty()) jsonObject.put("inc_u_alerting_ci", snowIncU_AlertingCi);
		if (snowIncU_AlertingFollowUp != null && !snowIncU_AlertingFollowUp.toString().isEmpty()) jsonObject.put("inc_u_alerting_follow_up", snowIncU_AlertingFollowUp);
		if (snowIncU_AlertingRepeatCount != null && !snowIncU_AlertingRepeatCount.toString().isEmpty()) jsonObject.put("inc_u_alerting_repeat_count", snowIncU_AlertingRepeatCount);
		if (snowIncU_AlertingReview != null && !snowIncU_AlertingReview.toString().isEmpty()) jsonObject.put("inc_u_alerting_review", snowIncU_AlertingReview);
		if (snowIncU_AofDateTime != null && !snowIncU_AofDateTime.toString().isEmpty()) jsonObject.put("inc_u_aof_date__time", snowIncU_AofDateTime);
		if (snowIncU_AofPass != null && !snowIncU_AofPass.toString().isEmpty()) jsonObject.put("inc_u_aof_pass", snowIncU_AofPass);
		if (snowIncU_AofState != null && !snowIncU_AofState.toString().isEmpty()) jsonObject.put("inc_u_aof_state", snowIncU_AofState);
		if (snowIncU_AofWorkgroup != null && !snowIncU_AofWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_aof_workgroup", snowIncU_AofWorkgroup);
		if (snowIncU_AosDateTime != null && !snowIncU_AosDateTime.toString().isEmpty()) jsonObject.put("inc_u_aos_date__time", snowIncU_AosDateTime);
		if (snowIncU_AosPass != null && !snowIncU_AosPass.toString().isEmpty()) jsonObject.put("inc_u_aos_pass", snowIncU_AosPass);
		if (snowIncU_AosState != null && !snowIncU_AosState.toString().isEmpty()) jsonObject.put("inc_u_aos_state", snowIncU_AosState);
		if (snowIncU_AosWorkgroup != null && !snowIncU_AosWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_aos_workgroup", snowIncU_AosWorkgroup);
		if (snowIncU_ApplicationCode != null && !snowIncU_ApplicationCode.toString().isEmpty()) jsonObject.put("inc_u_application_code", snowIncU_ApplicationCode);
		if (snowIncU_AssetCode != null && !snowIncU_AssetCode.toString().isEmpty()) jsonObject.put("inc_u_asset_code", snowIncU_AssetCode);
		if (snowIncU_AssetString != null && !snowIncU_AssetString.toString().isEmpty()) jsonObject.put("inc_u_asset_string", snowIncU_AssetString);
		if (snowIncU_AssignedToBladelogic != null && !snowIncU_AssignedToBladelogic.toString().isEmpty()) jsonObject.put("inc_u_assigned_to_bladelogic", snowIncU_AssignedToBladelogic);
		if (snowIncU_AssignmentStatus != null && !snowIncU_AssignmentStatus.toString().isEmpty()) jsonObject.put("inc_u_assignment_status", snowIncU_AssignmentStatus);
		if (snowIncU_AttachmentsAdded != null && !snowIncU_AttachmentsAdded.toString().isEmpty()) jsonObject.put("inc_u_attachments_added", snowIncU_AttachmentsAdded);
		if (snowIncU_AuditCode != null && !snowIncU_AuditCode.toString().isEmpty()) jsonObject.put("inc_u_audit__code", snowIncU_AuditCode);
		if (snowIncU_AutoClose != null && !snowIncU_AutoClose.toString().isEmpty()) jsonObject.put("inc_u_auto_close", snowIncU_AutoClose);
		if (snowIncU_AutoCloseTicket != null && !snowIncU_AutoCloseTicket.toString().isEmpty()) jsonObject.put("inc_u_auto_close_ticket", snowIncU_AutoCloseTicket);
		if (snowIncU_AutoParm1 != null && !snowIncU_AutoParm1.toString().isEmpty()) jsonObject.put("inc_u_auto_parm1", snowIncU_AutoParm1);
		if (snowIncU_AutoParm2 != null && !snowIncU_AutoParm2.toString().isEmpty()) jsonObject.put("inc_u_auto_parm2", snowIncU_AutoParm2);
		if (snowIncU_AutoParm3 != null && !snowIncU_AutoParm3.toString().isEmpty()) jsonObject.put("inc_u_auto_parm3", snowIncU_AutoParm3);
		if (snowIncU_AutoParm4 != null && !snowIncU_AutoParm4.toString().isEmpty()) jsonObject.put("inc_u_auto_parm4", snowIncU_AutoParm4);
		if (snowIncU_AutoParm5 != null && !snowIncU_AutoParm5.toString().isEmpty()) jsonObject.put("inc_u_auto_parm5", snowIncU_AutoParm5);
		if (snowIncU_AutoTarget != null && !snowIncU_AutoTarget.toString().isEmpty()) jsonObject.put("inc_u_auto_target", snowIncU_AutoTarget);
		if (snowIncU_AutoType != null && !snowIncU_AutoType.toString().isEmpty()) jsonObject.put("inc_u_auto_type", snowIncU_AutoType);
		if (snowIncU_AvailAddComments != null && !snowIncU_AvailAddComments.toString().isEmpty()) jsonObject.put("inc_u_avail_add_comments", snowIncU_AvailAddComments);
		if (snowIncU_AvailTechSvc != null && !snowIncU_AvailTechSvc.toString().isEmpty()) jsonObject.put("inc_u_avail_tech_svc", snowIncU_AvailTechSvc);
		if (snowIncU_AvailabilityIncludeOutage != null && !snowIncU_AvailabilityIncludeOutage.toString().isEmpty()) jsonObject.put("inc_u_availability_include_outage_", snowIncU_AvailabilityIncludeOutage);
		if (snowIncU_AvailabilityReport != null && !snowIncU_AvailabilityReport.toString().isEmpty()) jsonObject.put("inc_u_availability_report", snowIncU_AvailabilityReport);
		if (snowIncU_BatchStep != null && !snowIncU_BatchStep.toString().isEmpty()) jsonObject.put("inc_u_batch_step", snowIncU_BatchStep);
		if (snowIncU_BemUpdates != null && !snowIncU_BemUpdates.toString().isEmpty()) jsonObject.put("inc_u_bem_updates", snowIncU_BemUpdates);
		if (snowIncU_BounceCount != null && !snowIncU_BounceCount.toString().isEmpty()) jsonObject.put("inc_u_bounce_count", snowIncU_BounceCount);
		if (snowIncU_BsdCall != null && !snowIncU_BsdCall.toString().isEmpty()) jsonObject.put("inc_u_bsd_call", snowIncU_BsdCall);
		if (snowIncU_BsdResolutionBy != null && !snowIncU_BsdResolutionBy.toString().isEmpty()) jsonObject.put("inc_u_bsd_resolution_by", snowIncU_BsdResolutionBy);
		if (snowIncU_BusinessCritical != null && !snowIncU_BusinessCritical.toString().isEmpty()) jsonObject.put("inc_u_business_critical", snowIncU_BusinessCritical);
		if (snowIncU_BusinessImpact != null && !snowIncU_BusinessImpact.toString().isEmpty()) jsonObject.put("inc_u_business_impact", snowIncU_BusinessImpact);
		if (snowIncU_BusinessService != null && !snowIncU_BusinessService.toString().isEmpty()) jsonObject.put("inc_u_business_service", snowIncU_BusinessService);
		if (snowIncU_CallCaptureComments != null && !snowIncU_CallCaptureComments.toString().isEmpty()) jsonObject.put("inc_u_call_capture_comments", snowIncU_CallCaptureComments);
		if (snowIncU_CallHandlingComments != null && !snowIncU_CallHandlingComments.toString().isEmpty()) jsonObject.put("inc_u_call_handling_comments", snowIncU_CallHandlingComments);
		if (snowIncU_CallOut != null && !snowIncU_CallOut.toString().isEmpty()) jsonObject.put("inc_u_call_out", snowIncU_CallOut);
		if (snowIncU_CallOutInvoked != null && !snowIncU_CallOutInvoked.toString().isEmpty()) jsonObject.put("inc_u_call_out_invoked", snowIncU_CallOutInvoked);
		if (snowIncU_CauseItem != null && !snowIncU_CauseItem.toString().isEmpty()) jsonObject.put("inc_u_cause_item", snowIncU_CauseItem);
		if (snowIncU_CausedBy != null && !snowIncU_CausedBy.toString().isEmpty()) jsonObject.put("inc_u_caused_by", snowIncU_CausedBy);
		if (snowIncU_ChangeManager != null && !snowIncU_ChangeManager.toString().isEmpty()) jsonObject.put("inc_u_change_manager", snowIncU_ChangeManager);
		if (snowIncU_CiCategory != null && !snowIncU_CiCategory.toString().isEmpty()) jsonObject.put("inc_u_ci_category", snowIncU_CiCategory);
		if (snowIncU_CiClassification != null && !snowIncU_CiClassification.toString().isEmpty()) jsonObject.put("inc_u_ci_classification", snowIncU_CiClassification);
		if (snowIncU_CiSubcategory != null && !snowIncU_CiSubcategory.toString().isEmpty()) jsonObject.put("inc_u_ci_subcategory", snowIncU_CiSubcategory);
		if (snowIncU_CiSubclassification != null && !snowIncU_CiSubclassification.toString().isEmpty()) jsonObject.put("inc_u_ci_subclassification", snowIncU_CiSubclassification);
		if (snowIncU_Classification != null && !snowIncU_Classification.toString().isEmpty()) jsonObject.put("inc_u_classification", snowIncU_Classification);
		if (snowIncU_ClosedCentrally != null && !snowIncU_ClosedCentrally.toString().isEmpty()) jsonObject.put("inc_u_closed_centrally", snowIncU_ClosedCentrally);
		if (snowIncU_ClosedPeriod != null && !snowIncU_ClosedPeriod.toString().isEmpty()) jsonObject.put("inc_u_closed_period", snowIncU_ClosedPeriod);
		if (snowIncU_ClosureCategory != null && !snowIncU_ClosureCategory.toString().isEmpty()) jsonObject.put("inc_u_closure_category", snowIncU_ClosureCategory);
		if (snowIncU_ClosureCi != null && !snowIncU_ClosureCi.toString().isEmpty()) jsonObject.put("inc_u_closure_ci", snowIncU_ClosureCi);
		if (snowIncU_ClosureRejected != null && !snowIncU_ClosureRejected.toString().isEmpty()) jsonObject.put("inc_u_closure_rejected", snowIncU_ClosureRejected);
		if (snowIncU_ClosureSubcategory != null && !snowIncU_ClosureSubcategory.toString().isEmpty()) jsonObject.put("inc_u_closure_subcategory", snowIncU_ClosureSubcategory);
		if (snowIncU_CommentType != null && !snowIncU_CommentType.toString().isEmpty()) jsonObject.put("inc_u_comment_type", snowIncU_CommentType);
		if (snowIncU_CommentTypeHandling != null && !snowIncU_CommentTypeHandling.toString().isEmpty()) jsonObject.put("inc_u_comment_type_handling", snowIncU_CommentTypeHandling);
		if (snowIncU_CommentsAndWorkNotes != null && !snowIncU_CommentsAndWorkNotes.toString().isEmpty()) jsonObject.put("inc_u_comments_and_work_notes", snowIncU_CommentsAndWorkNotes);
		if (snowIncU_Communication != null && !snowIncU_Communication.toString().isEmpty()) jsonObject.put("inc_u_communication", snowIncU_Communication);
		if (snowIncU_CommunicationEmail != null && !snowIncU_CommunicationEmail.toString().isEmpty()) jsonObject.put("inc_u_communication_email", snowIncU_CommunicationEmail);
		if (snowIncU_CommunicationType != null && !snowIncU_CommunicationType.toString().isEmpty()) jsonObject.put("inc_u_communication_type", snowIncU_CommunicationType);
		if (snowIncU_CopyComments != null && !snowIncU_CopyComments.toString().isEmpty()) jsonObject.put("inc_u_copy_comments", snowIncU_CopyComments);
		if (snowIncU_CopySubject != null && !snowIncU_CopySubject.toString().isEmpty()) jsonObject.put("inc_u_copy_subject", snowIncU_CopySubject);
		if (snowIncU_CreatedByWorkgroup != null && !snowIncU_CreatedByWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_created_by_workgroup", snowIncU_CreatedByWorkgroup);
		if (snowIncU_DailyServiceSummary != null && !snowIncU_DailyServiceSummary.toString().isEmpty()) jsonObject.put("inc_u_daily_service_summary", snowIncU_DailyServiceSummary);
		if (snowIncU_DesktopAssetNumber != null && !snowIncU_DesktopAssetNumber.toString().isEmpty()) jsonObject.put("inc_u_desktop_asset_number", snowIncU_DesktopAssetNumber);
		if (snowIncU_DesktopCustomerUnavailable != null && !snowIncU_DesktopCustomerUnavailable.toString().isEmpty()) jsonObject.put("inc_u_desktop_customer_unavailable", snowIncU_DesktopCustomerUnavailable);
		if (snowIncU_DesktopMake != null && !snowIncU_DesktopMake.toString().isEmpty()) jsonObject.put("inc_u_desktop_make", snowIncU_DesktopMake);
		if (snowIncU_DesktopModel != null && !snowIncU_DesktopModel.toString().isEmpty()) jsonObject.put("inc_u_desktop_model", snowIncU_DesktopModel);
		if (snowIncU_DesktopSN != null && !snowIncU_DesktopSN.toString().isEmpty()) jsonObject.put("inc_u_desktop_s_n", snowIncU_DesktopSN);
		if (snowIncU_DsrImpactComments != null && !snowIncU_DsrImpactComments.toString().isEmpty()) jsonObject.put("inc_u_dsr_impact_comments", snowIncU_DsrImpactComments);
		if (snowIncU_DsrOrganisation != null && !snowIncU_DsrOrganisation.toString().isEmpty()) jsonObject.put("inc_u_dsr_organisation", snowIncU_DsrOrganisation);
		if (snowIncU_DsrOutageFinish != null && !snowIncU_DsrOutageFinish.toString().isEmpty()) jsonObject.put("inc_u_dsr_outage_finish", snowIncU_DsrOutageFinish);
		if (snowIncU_DsrOutageStart != null && !snowIncU_DsrOutageStart.toString().isEmpty()) jsonObject.put("inc_u_dsr_outage_start", snowIncU_DsrOutageStart);
		if (snowIncU_DsrReportDate != null && !snowIncU_DsrReportDate.toString().isEmpty()) jsonObject.put("inc_u_dsr_report_date", snowIncU_DsrReportDate);
		if (snowIncU_DsrServiceSAffectedList != null && !snowIncU_DsrServiceSAffectedList.toString().isEmpty()) jsonObject.put("inc_u_dsr_service_s_affected_list", snowIncU_DsrServiceSAffectedList);
		if (snowIncU_DsrSynopsis != null && !snowIncU_DsrSynopsis.toString().isEmpty()) jsonObject.put("inc_u_dsr_synopsis", snowIncU_DsrSynopsis);
		if (snowIncU_DsrTimeline != null && !snowIncU_DsrTimeline.toString().isEmpty()) jsonObject.put("inc_u_dsr_timeline", snowIncU_DsrTimeline);
		if (snowIncU_DssFollowUpActions != null && !snowIncU_DssFollowUpActions.toString().isEmpty()) jsonObject.put("inc_u_dss_follow_up_actions", snowIncU_DssFollowUpActions);
		if (snowIncU_DssOutstandingActions != null && !snowIncU_DssOutstandingActions.toString().isEmpty()) jsonObject.put("inc_u_dss_outstanding_actions", snowIncU_DssOutstandingActions);
		if (snowIncU_DssRootCauseAnalysis != null && !snowIncU_DssRootCauseAnalysis.toString().isEmpty()) jsonObject.put("inc_u_dss_root_cause_analysis", snowIncU_DssRootCauseAnalysis);
		if (snowIncU_DssWeighting != null && !snowIncU_DssWeighting.toString().isEmpty()) jsonObject.put("inc_u_dss_weighting", snowIncU_DssWeighting);
		if (snowIncU_EbondingFailed != null && !snowIncU_EbondingFailed.toString().isEmpty()) jsonObject.put("inc_u_ebonding_failed", snowIncU_EbondingFailed);
		if (snowIncU_Email != null && !snowIncU_Email.toString().isEmpty()) jsonObject.put("inc_u_email", snowIncU_Email);
		if (snowIncU_EmailTemplate != null && !snowIncU_EmailTemplate.toString().isEmpty()) jsonObject.put("inc_u_email_template", snowIncU_EmailTemplate);
		if (snowIncU_Escalated != null && !snowIncU_Escalated.toString().isEmpty()) jsonObject.put("inc_u_escalated", snowIncU_Escalated);
		if (snowIncU_EscalationType != null && !snowIncU_EscalationType.toString().isEmpty()) jsonObject.put("inc_u_escalation_type", snowIncU_EscalationType);
		if (snowIncU_EventUrl != null && !snowIncU_EventUrl.toString().isEmpty()) jsonObject.put("inc_u_event_url", snowIncU_EventUrl);
		if (snowIncU_ExpertHelp != null && !snowIncU_ExpertHelp.toString().isEmpty()) jsonObject.put("inc_u_expert_help", snowIncU_ExpertHelp);
		if (snowIncU_ExternalRef != null && !snowIncU_ExternalRef.toString().isEmpty()) jsonObject.put("inc_u_external_ref", snowIncU_ExternalRef);
		if (snowIncU_FailingObject != null && !snowIncU_FailingObject.toString().isEmpty()) jsonObject.put("inc_u_failing_object", snowIncU_FailingObject);
		if (snowIncU_FeedbackCode != null && !snowIncU_FeedbackCode.toString().isEmpty()) jsonObject.put("inc_u_feedback_code", snowIncU_FeedbackCode);
		if (snowIncU_FeedbackCodeHandling != null && !snowIncU_FeedbackCodeHandling.toString().isEmpty()) jsonObject.put("inc_u_feedback_code_handling", snowIncU_FeedbackCodeHandling);
		if (snowIncU_FirstDeadline != null && !snowIncU_FirstDeadline.toString().isEmpty()) jsonObject.put("inc_u_first_deadline", snowIncU_FirstDeadline);
		if (snowIncU_FirstTimeFix != null && !snowIncU_FirstTimeFix.toString().isEmpty()) jsonObject.put("inc_u_first_time_fix", snowIncU_FirstTimeFix);
		if (snowIncU_Folder != null && !snowIncU_Folder.toString().isEmpty()) jsonObject.put("inc_u_folder", snowIncU_Folder);
		if (snowIncU_GlobalSspDashboard != null && !snowIncU_GlobalSspDashboard.toString().isEmpty()) jsonObject.put("inc_u_global_ssp_dashboard", snowIncU_GlobalSspDashboard);
		if (snowIncU_HighSeverity != null && !snowIncU_HighSeverity.toString().isEmpty()) jsonObject.put("inc_u_high_severity", snowIncU_HighSeverity);
		if (snowIncU_HpCauseCode != null && !snowIncU_HpCauseCode.toString().isEmpty()) jsonObject.put("inc_u_hp_cause_code", snowIncU_HpCauseCode);
		if (snowIncU_HpClosureCode != null && !snowIncU_HpClosureCode.toString().isEmpty()) jsonObject.put("inc_u_hp_closure_code", snowIncU_HpClosureCode);
		if (snowIncU_ImpBreakdown != null && !snowIncU_ImpBreakdown.toString().isEmpty()) jsonObject.put("inc_u_imp_breakdown", snowIncU_ImpBreakdown);
		if (snowIncU_IncidentManager != null && !snowIncU_IncidentManager.toString().isEmpty()) jsonObject.put("inc_u_incident_manager", snowIncU_IncidentManager);
		if (snowIncU_IncidentSummary != null && !snowIncU_IncidentSummary.toString().isEmpty()) jsonObject.put("inc_u_incident_summary", snowIncU_IncidentSummary);
		if (snowIncU_IncidentUpdate != null && !snowIncU_IncidentUpdate.toString().isEmpty()) jsonObject.put("inc_u_incident_update", snowIncU_IncidentUpdate);
		if (snowIncU_InitialAssignment != null && !snowIncU_InitialAssignment.toString().isEmpty()) jsonObject.put("inc_u_initial_assignment", snowIncU_InitialAssignment);
		if (snowIncU_Instructions != null && !snowIncU_Instructions.toString().isEmpty()) jsonObject.put("inc_u_instructions", snowIncU_Instructions);
		if (snowIncU_InternalRef != null && !snowIncU_InternalRef.toString().isEmpty()) jsonObject.put("inc_u_internal_ref", snowIncU_InternalRef);
		if (snowIncU_IsHpPendingCustomer != null && !snowIncU_IsHpPendingCustomer.toString().isEmpty()) jsonObject.put("inc_u_is_hp_pending_customer", snowIncU_IsHpPendingCustomer);
		if (snowIncU_IssueTitle != null && !snowIncU_IssueTitle.toString().isEmpty()) jsonObject.put("inc_u_issue_title", snowIncU_IssueTitle);
		if (snowIncU_ItilWatchList != null && !snowIncU_ItilWatchList.toString().isEmpty()) jsonObject.put("inc_u_itil_watch_list", snowIncU_ItilWatchList);
		if (snowIncU_JobNumber != null && !snowIncU_JobNumber.toString().isEmpty()) jsonObject.put("inc_u_job_number", snowIncU_JobNumber);
		if (snowIncU_KnowledgeArticle != null && !snowIncU_KnowledgeArticle.toString().isEmpty()) jsonObject.put("inc_u_knowledge_article", snowIncU_KnowledgeArticle);
		if (snowIncU_KnowledgeAvailable != null && !snowIncU_KnowledgeAvailable.toString().isEmpty()) jsonObject.put("inc_u_knowledge_available", snowIncU_KnowledgeAvailable);
		if (snowIncU_KnowledgeCode != null && !snowIncU_KnowledgeCode.toString().isEmpty()) jsonObject.put("inc_u_knowledge_code", snowIncU_KnowledgeCode);
		if (snowIncU_KnowledgeComments != null && !snowIncU_KnowledgeComments.toString().isEmpty()) jsonObject.put("inc_u_knowledge_comments", snowIncU_KnowledgeComments);
		if (snowIncU_KnowledgeDirectory != null && !snowIncU_KnowledgeDirectory.toString().isEmpty()) jsonObject.put("inc_u_knowledge_directory", snowIncU_KnowledgeDirectory);
		if (snowIncU_KnowledgeFound != null && !snowIncU_KnowledgeFound.toString().isEmpty()) jsonObject.put("inc_u_knowledge_found", snowIncU_KnowledgeFound);
		if (snowIncU_KnowledgeUser != null && !snowIncU_KnowledgeUser.toString().isEmpty()) jsonObject.put("inc_u_knowledge_user", snowIncU_KnowledgeUser);
		if (snowIncU_LastOccurrence != null && !snowIncU_LastOccurrence.toString().isEmpty()) jsonObject.put("inc_u_last_occurrence", snowIncU_LastOccurrence);
		if (snowIncU_LateImpReason != null && !snowIncU_LateImpReason.toString().isEmpty()) jsonObject.put("inc_u_late_imp_reason", snowIncU_LateImpReason);
		if (snowIncU_LeadTime != null && !snowIncU_LeadTime.toString().isEmpty()) jsonObject.put("inc_u_lead_time", snowIncU_LeadTime);
		if (snowIncU_LiveFeedGroup != null && !snowIncU_LiveFeedGroup.toString().isEmpty()) jsonObject.put("inc_u_live_feed_group", snowIncU_LiveFeedGroup);
		if (snowIncU_LiveFeedGroupDuplicate != null && !snowIncU_LiveFeedGroupDuplicate.toString().isEmpty()) jsonObject.put("inc_u_live_feed_group_duplicate", snowIncU_LiveFeedGroupDuplicate);
		if (snowIncU_LocalResp != null && !snowIncU_LocalResp.toString().isEmpty()) jsonObject.put("inc_u_local_resp", snowIncU_LocalResp);
		if (snowIncU_MajorIncident != null && !snowIncU_MajorIncident.toString().isEmpty()) jsonObject.put("inc_u_major_incident", snowIncU_MajorIncident);
		if (snowIncU_ManagementAuditComments != null && !snowIncU_ManagementAuditComments.toString().isEmpty()) jsonObject.put("inc_u_management_audit_comments", snowIncU_ManagementAuditComments);
		if (snowIncU_ManagementComments != null && !snowIncU_ManagementComments.toString().isEmpty()) jsonObject.put("inc_u_management_comments", snowIncU_ManagementComments);
		if (snowIncU_MissingCi != null && !snowIncU_MissingCi.toString().isEmpty()) jsonObject.put("inc_u_missing_ci", snowIncU_MissingCi);
		if (snowIncU_MissingCiFlag != null && !snowIncU_MissingCiFlag.toString().isEmpty()) jsonObject.put("inc_u_missing_ci_flag", snowIncU_MissingCiFlag);
		if (snowIncU_ModifiedPeriod != null && !snowIncU_ModifiedPeriod.toString().isEmpty()) jsonObject.put("inc_u_modified_period", snowIncU_ModifiedPeriod);
		if (snowIncU_MultipleCountrySspDashboa != null && !snowIncU_MultipleCountrySspDashboa.toString().isEmpty()) jsonObject.put("inc_u_multiple_country_ssp_dashboa", snowIncU_MultipleCountrySspDashboa);
		if (snowIncU_Name != null && !snowIncU_Name.toString().isEmpty()) jsonObject.put("inc_u_name", snowIncU_Name);
		if (snowIncU_NewDate != null && !snowIncU_NewDate.toString().isEmpty()) jsonObject.put("inc_u_new_date", snowIncU_NewDate);
		if (snowIncU_NextAssignment != null && !snowIncU_NextAssignment.toString().isEmpty()) jsonObject.put("inc_u_next_assignment", snowIncU_NextAssignment);
		if (snowIncU_Now92Sites != null && !snowIncU_Now92Sites.toString().isEmpty()) jsonObject.put("inc_u_now92_sites", snowIncU_Now92Sites);
		if (snowIncU_OlaTaskName != null && !snowIncU_OlaTaskName.toString().isEmpty()) jsonObject.put("inc_u_ola_task_name", snowIncU_OlaTaskName);
		if (snowIncU_OpenedPeriod != null && !snowIncU_OpenedPeriod.toString().isEmpty()) jsonObject.put("inc_u_opened_period", snowIncU_OpenedPeriod);
		if (snowIncU_OperatingUnit != null && !snowIncU_OperatingUnit.toString().isEmpty()) jsonObject.put("inc_u_operating_unit", snowIncU_OperatingUnit);
		if (snowIncU_OutageDuration != null && !snowIncU_OutageDuration.toString().isEmpty()) jsonObject.put("inc_u_outage_duration", snowIncU_OutageDuration);
		if (snowIncU_OutsourceAssignedOut != null && !snowIncU_OutsourceAssignedOut.toString().isEmpty()) jsonObject.put("inc_u_outsource_assigned_out", snowIncU_OutsourceAssignedOut);
		if (snowIncU_OutsourceAssignee != null && !snowIncU_OutsourceAssignee.toString().isEmpty()) jsonObject.put("inc_u_outsource_assignee", snowIncU_OutsourceAssignee);
		if (snowIncU_OutsourceId != null && !snowIncU_OutsourceId.toString().isEmpty()) jsonObject.put("inc_u_outsource_id", snowIncU_OutsourceId);
		if (snowIncU_OutsourceIntegration != null && !snowIncU_OutsourceIntegration.toString().isEmpty()) jsonObject.put("inc_u_outsource_integration", snowIncU_OutsourceIntegration);
		if (snowIncU_OutsourceModule != null && !snowIncU_OutsourceModule.toString().isEmpty()) jsonObject.put("inc_u_outsource_module", snowIncU_OutsourceModule);
		if (snowIncU_OutsourceResponse != null && !snowIncU_OutsourceResponse.toString().isEmpty()) jsonObject.put("inc_u_outsource_response", snowIncU_OutsourceResponse);
		if (snowIncU_OutsourceResult != null && !snowIncU_OutsourceResult.toString().isEmpty()) jsonObject.put("inc_u_outsource_result", snowIncU_OutsourceResult);
		if (snowIncU_OutsourceStatus != null && !snowIncU_OutsourceStatus.toString().isEmpty()) jsonObject.put("inc_u_outsource_status", snowIncU_OutsourceStatus);
		if (snowIncU_OutsourceTeam != null && !snowIncU_OutsourceTeam.toString().isEmpty()) jsonObject.put("inc_u_outsource_team", snowIncU_OutsourceTeam);
		if (snowIncU_Override1 != null && !snowIncU_Override1.toString().isEmpty()) jsonObject.put("inc_u_override1", snowIncU_Override1);
		if (snowIncU_ParentIncident != null && !snowIncU_ParentIncident.toString().isEmpty()) jsonObject.put("inc_u_parent_incident", snowIncU_ParentIncident);
		if (snowIncU_PendingReason != null && !snowIncU_PendingReason.toString().isEmpty()) jsonObject.put("inc_u_pending_reason", snowIncU_PendingReason);
		if (snowIncU_Person != null && !snowIncU_Person.toString().isEmpty()) jsonObject.put("inc_u_person", snowIncU_Person);
		if (snowIncU_PersonAudited != null && !snowIncU_PersonAudited.toString().isEmpty()) jsonObject.put("inc_u_person_audited", snowIncU_PersonAudited);
		if (snowIncU_PersonAuditing != null && !snowIncU_PersonAuditing.toString().isEmpty()) jsonObject.put("inc_u_person_auditing", snowIncU_PersonAuditing);
		if (snowIncU_Phone != null && !snowIncU_Phone.toString().isEmpty()) jsonObject.put("inc_u_phone", snowIncU_Phone);
		if (snowIncU_PickupDuration != null && !snowIncU_PickupDuration.toString().isEmpty()) jsonObject.put("inc_u_pickup_duration", snowIncU_PickupDuration);
		if (snowIncU_PlannedEffort != null && !snowIncU_PlannedEffort.toString().isEmpty()) jsonObject.put("inc_u_planned_effort", snowIncU_PlannedEffort);
		if (snowIncU_PlannedImplementationWeek != null && !snowIncU_PlannedImplementationWeek.toString().isEmpty()) jsonObject.put("inc_u_planned_implementation_week", snowIncU_PlannedImplementationWeek);
		if (snowIncU_PnetHpEbond != null && !snowIncU_PnetHpEbond.toString().isEmpty()) jsonObject.put("inc_u_pnet_hp_ebond", snowIncU_PnetHpEbond);
		if (snowIncU_PreviousGroup != null && !snowIncU_PreviousGroup.toString().isEmpty()) jsonObject.put("inc_u_previous_group", snowIncU_PreviousGroup);
		if (snowIncU_PreviousHpWorkgroup != null && !snowIncU_PreviousHpWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_previous_hp_workgroup", snowIncU_PreviousHpWorkgroup);
		if (snowIncU_PreviousStatus != null && !snowIncU_PreviousStatus.toString().isEmpty()) jsonObject.put("inc_u_previous_status", snowIncU_PreviousStatus);
		if (snowIncU_QueryCount != null && !snowIncU_QueryCount.toString().isEmpty()) jsonObject.put("inc_u_query_count", snowIncU_QueryCount);
		if (snowIncU_RegionImpacted != null && !snowIncU_RegionImpacted.toString().isEmpty()) jsonObject.put("inc_u_region_impacted", snowIncU_RegionImpacted);
		if (snowIncU_RejectionCount != null && !snowIncU_RejectionCount.toString().isEmpty()) jsonObject.put("inc_u_rejection_count", snowIncU_RejectionCount);
		if (snowIncU_RelatedIncidents != null && !snowIncU_RelatedIncidents.toString().isEmpty()) jsonObject.put("inc_u_related_incidents", snowIncU_RelatedIncidents);
		if (snowIncU_RelatedRequest != null && !snowIncU_RelatedRequest.toString().isEmpty()) jsonObject.put("inc_u_related_request", snowIncU_RelatedRequest);
		if (snowIncU_ReopenCount != null && !snowIncU_ReopenCount.toString().isEmpty()) jsonObject.put("inc_u_reopen_count", snowIncU_ReopenCount);
		if (snowIncU_ReopenedDate != null && !snowIncU_ReopenedDate.toString().isEmpty()) jsonObject.put("inc_u_reopened_date", snowIncU_ReopenedDate);
		if (snowIncU_RepeatIncident != null && !snowIncU_RepeatIncident.toString().isEmpty()) jsonObject.put("inc_u_repeat_incident", snowIncU_RepeatIncident);
		if (snowIncU_ResolutionOverride != null && !snowIncU_ResolutionOverride.toString().isEmpty()) jsonObject.put("inc_u_resolution_override", snowIncU_ResolutionOverride);
		if (snowIncU_ResolutionReason != null && !snowIncU_ResolutionReason.toString().isEmpty()) jsonObject.put("inc_u_resolution_reason", snowIncU_ResolutionReason);
		if (snowIncU_ResolutionType != null && !snowIncU_ResolutionType.toString().isEmpty()) jsonObject.put("inc_u_resolution_type", snowIncU_ResolutionType);
		if (snowIncU_ResolvedBy != null && !snowIncU_ResolvedBy.toString().isEmpty()) jsonObject.put("inc_u_resolved_by", snowIncU_ResolvedBy);
		if (snowIncU_ResolvedByWorkgroup != null && !snowIncU_ResolvedByWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_resolved_by_workgroup", snowIncU_ResolvedByWorkgroup);
		if (snowIncU_Resolver != null && !snowIncU_Resolver.toString().isEmpty()) jsonObject.put("inc_u_resolver", snowIncU_Resolver);
		if (snowIncU_ResponseFlag != null && !snowIncU_ResponseFlag.toString().isEmpty()) jsonObject.put("inc_u_response_flag", snowIncU_ResponseFlag);
		if (snowIncU_ResponseOverride != null && !snowIncU_ResponseOverride.toString().isEmpty()) jsonObject.put("inc_u_response_override", snowIncU_ResponseOverride);
		if (snowIncU_ResponseReason != null && !snowIncU_ResponseReason.toString().isEmpty()) jsonObject.put("inc_u_response_reason", snowIncU_ResponseReason);
		if (snowIncU_SavedCount != null && !snowIncU_SavedCount.toString().isEmpty()) jsonObject.put("inc_u_saved_count", snowIncU_SavedCount);
		if (snowIncU_SdOlaPause != null && !snowIncU_SdOlaPause.toString().isEmpty()) jsonObject.put("inc_u_sd_ola_pause", snowIncU_SdOlaPause);
		if (snowIncU_SecondDeadline != null && !snowIncU_SecondDeadline.toString().isEmpty()) jsonObject.put("inc_u_second_deadline", snowIncU_SecondDeadline);
		if (snowIncU_SelectApplication != null && !snowIncU_SelectApplication.toString().isEmpty()) jsonObject.put("inc_u_select_application", snowIncU_SelectApplication);
		if (snowIncU_SelectEuc != null && !snowIncU_SelectEuc.toString().isEmpty()) jsonObject.put("inc_u_select_euc", snowIncU_SelectEuc);
		if (snowIncU_SelectInfrastructure != null && !snowIncU_SelectInfrastructure.toString().isEmpty()) jsonObject.put("inc_u_select_infrastructure", snowIncU_SelectInfrastructure);
		if (snowIncU_SelectNetwork != null && !snowIncU_SelectNetwork.toString().isEmpty()) jsonObject.put("inc_u_select_network", snowIncU_SelectNetwork);
		if (snowIncU_ServiceImpactPct != null && !snowIncU_ServiceImpactPct.toString().isEmpty()) jsonObject.put("inc_u_service_impact_pct", snowIncU_ServiceImpactPct);
		if (snowIncU_ServiceState != null && !snowIncU_ServiceState.toString().isEmpty()) jsonObject.put("inc_u_service_state", snowIncU_ServiceState);
		if (snowIncU_SitesAffected != null && !snowIncU_SitesAffected.toString().isEmpty()) jsonObject.put("inc_u_sites_affected", snowIncU_SitesAffected);
		if (snowIncU_SlaFailureWorkgroup != null && !snowIncU_SlaFailureWorkgroup.toString().isEmpty()) jsonObject.put("inc_u_sla_failure_workgroup", snowIncU_SlaFailureWorkgroup);
		if (snowIncU_SlaState != null && !snowIncU_SlaState.toString().isEmpty()) jsonObject.put("inc_u_sla_state", snowIncU_SlaState);
		if (snowIncU_SlfApprover != null && !snowIncU_SlfApprover.toString().isEmpty()) jsonObject.put("inc_u_slf_approver", snowIncU_SlfApprover);
		if (snowIncU_SlfComponent != null && !snowIncU_SlfComponent.toString().isEmpty()) jsonObject.put("inc_u_slf_component", snowIncU_SlfComponent);
		if (snowIncU_SlfReason != null && !snowIncU_SlfReason.toString().isEmpty()) jsonObject.put("inc_u_slf_reason", snowIncU_SlfReason);
		if (snowIncU_SlfReviewDate != null && !snowIncU_SlfReviewDate.toString().isEmpty()) jsonObject.put("inc_u_slf_review_date", snowIncU_SlfReviewDate);
		if (snowIncU_SmsGroup != null && !snowIncU_SmsGroup.toString().isEmpty()) jsonObject.put("inc_u_sms_group", snowIncU_SmsGroup);
		if (snowIncU_SmsMessage != null && !snowIncU_SmsMessage.toString().isEmpty()) jsonObject.put("inc_u_sms_message", snowIncU_SmsMessage);
		if (snowIncU_SmsTemplate != null && !snowIncU_SmsTemplate.toString().isEmpty()) jsonObject.put("inc_u_sms_template", snowIncU_SmsTemplate);
		if (snowIncU_SourceId != null && !snowIncU_SourceId.toString().isEmpty()) jsonObject.put("inc_u_source_id", snowIncU_SourceId);
		if (snowIncU_SrtFail != null && !snowIncU_SrtFail.toString().isEmpty()) jsonObject.put("inc_u_srt_fail", snowIncU_SrtFail);
		if (snowIncU_SrtPass != null && !snowIncU_SrtPass.toString().isEmpty()) jsonObject.put("inc_u_srt_pass", snowIncU_SrtPass);
		if (snowIncU_SrtState != null && !snowIncU_SrtState.toString().isEmpty()) jsonObject.put("inc_u_srt_state", snowIncU_SrtState);
		if (snowIncU_SspAffected != null && !snowIncU_SspAffected.toString().isEmpty()) jsonObject.put("inc_u_ssp_affected", snowIncU_SspAffected);
		if (snowIncU_SspDashboard != null && !snowIncU_SspDashboard.toString().isEmpty()) jsonObject.put("inc_u_ssp_dashboard", snowIncU_SspDashboard);
		if (snowIncU_SspDashboardLocalIs != null && !snowIncU_SspDashboardLocalIs.toString().isEmpty()) jsonObject.put("inc_u_ssp_dashboard__local_is_", snowIncU_SspDashboardLocalIs);
		if (snowIncU_SspDashboardLocal != null && !snowIncU_SspDashboardLocal.toString().isEmpty()) jsonObject.put("inc_u_ssp_dashboard_local", snowIncU_SspDashboardLocal);
		if (snowIncU_SspForm != null && !snowIncU_SspForm.toString().isEmpty()) jsonObject.put("inc_u_ssp_form", snowIncU_SspForm);
		if (snowIncU_Subject != null && !snowIncU_Subject.toString().isEmpty()) jsonObject.put("inc_u_subject", snowIncU_Subject);
		if (snowIncU_SupportStructure != null && !snowIncU_SupportStructure.toString().isEmpty()) jsonObject.put("inc_u_support_structure", snowIncU_SupportStructure);
		if (snowIncU_SupportType != null && !snowIncU_SupportType.toString().isEmpty()) jsonObject.put("inc_u_support_type", snowIncU_SupportType);
		if (snowIncU_SuspendOffTime != null && !snowIncU_SuspendOffTime.toString().isEmpty()) jsonObject.put("inc_u_suspend_off_time", snowIncU_SuspendOffTime);
		if (snowIncU_TaskType != null && !snowIncU_TaskType.toString().isEmpty()) jsonObject.put("inc_u_task_type", snowIncU_TaskType);
		if (snowIncU_Template != null && !snowIncU_Template.toString().isEmpty()) jsonObject.put("inc_u_template", snowIncU_Template);
		if (snowIncU_ThirdLineComments != null && !snowIncU_ThirdLineComments.toString().isEmpty()) jsonObject.put("inc_u_third_line_comments", snowIncU_ThirdLineComments);
		if (snowIncU_ThirdLineDate != null && !snowIncU_ThirdLineDate.toString().isEmpty()) jsonObject.put("inc_u_third_line_date", snowIncU_ThirdLineDate);
		if (snowIncU_ThirdPartyReference != null && !snowIncU_ThirdPartyReference.toString().isEmpty()) jsonObject.put("inc_u_third_party_reference", snowIncU_ThirdPartyReference);
		if (snowIncU_TimeToAuth != null && !snowIncU_TimeToAuth.toString().isEmpty()) jsonObject.put("inc_u_time_to_auth", snowIncU_TimeToAuth);
		if (snowIncU_TimeToClose != null && !snowIncU_TimeToClose.toString().isEmpty()) jsonObject.put("inc_u_time_to_close", snowIncU_TimeToClose);
		if (snowIncU_TntSiteType != null && !snowIncU_TntSiteType.toString().isEmpty()) jsonObject.put("inc_u_tnt_site_type", snowIncU_TntSiteType);
		if (snowIncU_Triaged != null && !snowIncU_Triaged.toString().isEmpty()) jsonObject.put("inc_u_triaged", snowIncU_Triaged);
		if (snowIncU_UnderOla != null && !snowIncU_UnderOla.toString().isEmpty()) jsonObject.put("inc_u_under_ola", snowIncU_UnderOla);
		if (snowIncU_UsersAffected != null && !snowIncU_UsersAffected.toString().isEmpty()) jsonObject.put("inc_u_users_affected", snowIncU_UsersAffected);
		if (snowIncU_VerrizonOutage != null && !snowIncU_VerrizonOutage.toString().isEmpty()) jsonObject.put("inc_u_verrizon_outage", snowIncU_VerrizonOutage);
		if (snowIncU_VzCorrelationId != null && !snowIncU_VzCorrelationId.toString().isEmpty()) jsonObject.put("inc_u_vz_correlation_id", snowIncU_VzCorrelationId);
		if (snowIncU_VzSequenceNumber != null && !snowIncU_VzSequenceNumber.toString().isEmpty()) jsonObject.put("inc_u_vz_sequence_number", snowIncU_VzSequenceNumber);
		if (snowIncU_WebId != null && !snowIncU_WebId.toString().isEmpty()) jsonObject.put("inc_u_web_id", snowIncU_WebId);
		if (snowIncU_WebUpdate != null && !snowIncU_WebUpdate.toString().isEmpty()) jsonObject.put("inc_u_web_update", snowIncU_WebUpdate);
		if (snowIncU_WiproId != null && !snowIncU_WiproId.toString().isEmpty()) jsonObject.put("inc_u_wipro_id", snowIncU_WiproId);
		if (snowIncU_WorkgroupsCalledOut != null && !snowIncU_WorkgroupsCalledOut.toString().isEmpty()) jsonObject.put("inc_u_workgroups_called_out", snowIncU_WorkgroupsCalledOut);
		if (snowIncUponApproval != null && !snowIncUponApproval.toString().isEmpty()) jsonObject.put("inc_upon_approval", snowIncUponApproval);
		if (snowIncUponReject != null && !snowIncUponReject.toString().isEmpty()) jsonObject.put("inc_upon_reject", snowIncUponReject);
		if (snowIncUrgency != null && !snowIncUrgency.toString().isEmpty()) jsonObject.put("inc_urgency", snowIncUrgency);
		if (snowIncUserInput != null && !snowIncUserInput.toString().isEmpty()) jsonObject.put("inc_user_input", snowIncUserInput);
		if (snowIncVzReleaseForTest != null && !snowIncVzReleaseForTest.toString().isEmpty()) jsonObject.put("inc_vz_release_for_test", snowIncVzReleaseForTest);
		if (snowIncVzReleaseForTestDatetime != null && !snowIncVzReleaseForTestDatetime.toString().isEmpty()) jsonObject.put("inc_vz_release_for_test_datetime", snowIncVzReleaseForTestDatetime);
		if (snowIncWatchList != null && !snowIncWatchList.toString().isEmpty()) jsonObject.put("inc_watch_list", snowIncWatchList);
		if (snowIncWfActivity != null && !snowIncWfActivity.toString().isEmpty()) jsonObject.put("inc_wf_activity", snowIncWfActivity);
		if (snowIncWorkEffort != null && !snowIncWorkEffort.toString().isEmpty()) jsonObject.put("inc_work_effort", snowIncWorkEffort);
		if (snowIncWorkEnd != null && !snowIncWorkEnd.toString().isEmpty()) jsonObject.put("inc_work_end", snowIncWorkEnd);
		if (snowIncWorkNotes != null && !snowIncWorkNotes.toString().isEmpty()) jsonObject.put("inc_work_notes", snowIncWorkNotes);
		if (snowIncWorkStart != null && !snowIncWorkStart.toString().isEmpty()) jsonObject.put("inc_work_start", snowIncWorkStart);
		if (snowTaskslatableActive != null && !snowTaskslatableActive.toString().isEmpty()) jsonObject.put("taskslatable_active", snowTaskslatableActive);
		if (snowTaskslatableBusinessDuration != null && !snowTaskslatableBusinessDuration.toString().isEmpty()) jsonObject.put("taskslatable_business_duration", snowTaskslatableBusinessDuration);
		if (snowTaskslatableBusinessPauseDuration != null && !snowTaskslatableBusinessPauseDuration.toString().isEmpty()) jsonObject.put("taskslatable_business_pause_duration", snowTaskslatableBusinessPauseDuration);
		if (snowTaskslatableBusinessPercentage != null && !snowTaskslatableBusinessPercentage.toString().isEmpty()) jsonObject.put("taskslatable_business_percentage", snowTaskslatableBusinessPercentage);
		if (snowTaskslatableBusinessTimeLeft != null && !snowTaskslatableBusinessTimeLeft.toString().isEmpty()) jsonObject.put("taskslatable_business_time_left", snowTaskslatableBusinessTimeLeft);
		if (snowTaskslatableDuration != null && !snowTaskslatableDuration.toString().isEmpty()) jsonObject.put("taskslatable_duration", snowTaskslatableDuration);
		if (snowTaskslatableEndTime != null && !snowTaskslatableEndTime.toString().isEmpty()) jsonObject.put("taskslatable_end_time", snowTaskslatableEndTime);
		if (snowTaskslatableHasBreached != null && !snowTaskslatableHasBreached.toString().isEmpty()) jsonObject.put("taskslatable_has_breached", snowTaskslatableHasBreached);
		if (snowTaskslatableOriginalBreachTime != null && !snowTaskslatableOriginalBreachTime.toString().isEmpty()) jsonObject.put("taskslatable_original_breach_time", snowTaskslatableOriginalBreachTime);
		if (snowTaskslatablePauseDuration != null && !snowTaskslatablePauseDuration.toString().isEmpty()) jsonObject.put("taskslatable_pause_duration", snowTaskslatablePauseDuration);
		if (snowTaskslatablePauseTime != null && !snowTaskslatablePauseTime.toString().isEmpty()) jsonObject.put("taskslatable_pause_time", snowTaskslatablePauseTime);
		if (snowTaskslatablePercentage != null && !snowTaskslatablePercentage.toString().isEmpty()) jsonObject.put("taskslatable_percentage", snowTaskslatablePercentage);
		if (snowTaskslatablePlannedEndTime != null && !snowTaskslatablePlannedEndTime.toString().isEmpty()) jsonObject.put("taskslatable_planned_end_time", snowTaskslatablePlannedEndTime);
		if (snowTaskslatableSchedule != null && !snowTaskslatableSchedule.toString().isEmpty()) jsonObject.put("taskslatable_schedule", snowTaskslatableSchedule);
		if (snowTaskslatableSla != null && !snowTaskslatableSla.toString().isEmpty()) jsonObject.put("taskslatable_sla", snowTaskslatableSla);
		if (snowTaskslatableStage != null && !snowTaskslatableStage.toString().isEmpty()) jsonObject.put("taskslatable_stage", snowTaskslatableStage);
		if (snowTaskslatableStartTime != null && !snowTaskslatableStartTime.toString().isEmpty()) jsonObject.put("taskslatable_start_time", snowTaskslatableStartTime);
		if (snowTaskslatableSysCreatedBy != null && !snowTaskslatableSysCreatedBy.toString().isEmpty()) jsonObject.put("taskslatable_sys_created_by", snowTaskslatableSysCreatedBy);
		if (snowTaskslatableSysCreatedOn != null && !snowTaskslatableSysCreatedOn.toString().isEmpty()) jsonObject.put("taskslatable_sys_created_on", snowTaskslatableSysCreatedOn);
		if (snowTaskslatableSysId != null && !snowTaskslatableSysId.toString().isEmpty()) jsonObject.put("taskslatable_sys_id", snowTaskslatableSysId);
		if (snowTaskslatableSysModCount != null && !snowTaskslatableSysModCount.toString().isEmpty()) jsonObject.put("taskslatable_sys_mod_count", snowTaskslatableSysModCount);
		if (snowTaskslatableSysTags != null && !snowTaskslatableSysTags.toString().isEmpty()) jsonObject.put("taskslatable_sys_tags", snowTaskslatableSysTags);
		if (snowTaskslatableSysUpdatedBy != null && !snowTaskslatableSysUpdatedBy.toString().isEmpty()) jsonObject.put("taskslatable_sys_updated_by", snowTaskslatableSysUpdatedBy);
		if (snowTaskslatableSysUpdatedOn != null && !snowTaskslatableSysUpdatedOn.toString().isEmpty()) jsonObject.put("taskslatable_sys_updated_on", snowTaskslatableSysUpdatedOn);
		if (snowTaskslatableTask != null && !snowTaskslatableTask.toString().isEmpty()) jsonObject.put("taskslatable_task", snowTaskslatableTask);
		if (snowTaskslatableTimeLeft != null && !snowTaskslatableTimeLeft.toString().isEmpty()) jsonObject.put("taskslatable_time_left", snowTaskslatableTimeLeft);
		if (snowTaskslatableTimezone != null && !snowTaskslatableTimezone.toString().isEmpty()) jsonObject.put("taskslatable_timezone", snowTaskslatableTimezone);
		if (snowTaskslatableU_InScope != null && !snowTaskslatableU_InScope.toString().isEmpty()) jsonObject.put("taskslatable_u_in_scope", snowTaskslatableU_InScope);
		if (snowTaskslatableU_KbArticle != null && !snowTaskslatableU_KbArticle.toString().isEmpty()) jsonObject.put("taskslatable_u_kb_article", snowTaskslatableU_KbArticle);
		
		return jsonObject;
	}

	public String getSnowIncActive() {
		return snowIncActive;
	}

	public void setSnowIncActive(String snowIncActive) {
		this.snowIncActive = snowIncActive;
	}

	public String getSnowIncActivityDue() {
		return snowIncActivityDue;
	}

	public void setSnowIncActivityDue(String snowIncActivityDue) {
		this.snowIncActivityDue = snowIncActivityDue;
	}

	public String getSnowIncAdditionalAssigneeList() {
		return snowIncAdditionalAssigneeList;
	}

	public void setSnowIncAdditionalAssigneeList(String snowIncAdditionalAssigneeList) {
		this.snowIncAdditionalAssigneeList = snowIncAdditionalAssigneeList;
	}

	public String getSnowIncApproval() {
		return snowIncApproval;
	}

	public void setSnowIncApproval(String snowIncApproval) {
		this.snowIncApproval = snowIncApproval;
	}

	public String getSnowIncApprovalHistory() {
		return snowIncApprovalHistory;
	}

	public void setSnowIncApprovalHistory(String snowIncApprovalHistory) {
		this.snowIncApprovalHistory = snowIncApprovalHistory;
	}

	public String getSnowIncApprovalSet() {
		return snowIncApprovalSet;
	}

	public void setSnowIncApprovalSet(String snowIncApprovalSet) {
		this.snowIncApprovalSet = snowIncApprovalSet;
	}

	public String getSnowIncAssignedTo() {
		return snowIncAssignedTo;
	}

	public void setSnowIncAssignedTo(String snowIncAssignedTo) {
		this.snowIncAssignedTo = snowIncAssignedTo;
	}

	public String getSnowIncAssignmentGroup() {
		return snowIncAssignmentGroup;
	}

	public void setSnowIncAssignmentGroup(String snowIncAssignmentGroup) {
		this.snowIncAssignmentGroup = snowIncAssignmentGroup;
	}

	public String getSnowIncBusinessDuration() {
		return snowIncBusinessDuration;
	}

	public void setSnowIncBusinessDuration(String snowIncBusinessDuration) {
		this.snowIncBusinessDuration = snowIncBusinessDuration;
	}

	public String getSnowIncBusinessService() {
		return snowIncBusinessService;
	}

	public void setSnowIncBusinessService(String snowIncBusinessService) {
		this.snowIncBusinessService = snowIncBusinessService;
	}

	public String getSnowIncBusinessStc() {
		return snowIncBusinessStc;
	}

	public void setSnowIncBusinessStc(String snowIncBusinessStc) {
		this.snowIncBusinessStc = snowIncBusinessStc;
	}

	public String getSnowIncCalendarDuration() {
		return snowIncCalendarDuration;
	}

	public void setSnowIncCalendarDuration(String snowIncCalendarDuration) {
		this.snowIncCalendarDuration = snowIncCalendarDuration;
	}

	public String getSnowIncCalendarStc() {
		return snowIncCalendarStc;
	}

	public void setSnowIncCalendarStc(String snowIncCalendarStc) {
		this.snowIncCalendarStc = snowIncCalendarStc;
	}

	public String getSnowIncCallerId() {
		return snowIncCallerId;
	}

	public void setSnowIncCallerId(String snowIncCallerId) {
		this.snowIncCallerId = snowIncCallerId;
	}

	public String getSnowIncCategory() {
		return snowIncCategory;
	}

	public void setSnowIncCategory(String snowIncCategory) {
		this.snowIncCategory = snowIncCategory;
	}

	public String getSnowIncCausedBy() {
		return snowIncCausedBy;
	}

	public void setSnowIncCausedBy(String snowIncCausedBy) {
		this.snowIncCausedBy = snowIncCausedBy;
	}

	public String getSnowIncCloseCode() {
		return snowIncCloseCode;
	}

	public void setSnowIncCloseCode(String snowIncCloseCode) {
		this.snowIncCloseCode = snowIncCloseCode;
	}

	public String getSnowIncCloseNotes() {
		return snowIncCloseNotes;
	}

	public void setSnowIncCloseNotes(String snowIncCloseNotes) {
		this.snowIncCloseNotes = snowIncCloseNotes;
	}

	public String getSnowIncClosedAt() {
		return snowIncClosedAt;
	}

	public void setSnowIncClosedAt(String snowIncClosedAt) {
		this.snowIncClosedAt = snowIncClosedAt;
	}

	public String getSnowIncClosedBy() {
		return snowIncClosedBy;
	}

	public void setSnowIncClosedBy(String snowIncClosedBy) {
		this.snowIncClosedBy = snowIncClosedBy;
	}

	public String getSnowIncCmdbCi() {
		return snowIncCmdbCi;
	}

	public void setSnowIncCmdbCi(String snowIncCmdbCi) {
		this.snowIncCmdbCi = snowIncCmdbCi;
	}

	public String getSnowIncComments() {
		return snowIncComments;
	}

	public void setSnowIncComments(String snowIncComments) {
		this.snowIncComments = snowIncComments;
	}

	public String getSnowIncCompany() {
		return snowIncCompany;
	}

	public void setSnowIncCompany(String snowIncCompany) {
		this.snowIncCompany = snowIncCompany;
	}

	public String getSnowIncContactType() {
		return snowIncContactType;
	}

	public void setSnowIncContactType(String snowIncContactType) {
		this.snowIncContactType = snowIncContactType;
	}

	public String getSnowIncContract() {
		return snowIncContract;
	}

	public void setSnowIncContract(String snowIncContract) {
		this.snowIncContract = snowIncContract;
	}

	public String getSnowIncCorrelationDisplay() {
		return snowIncCorrelationDisplay;
	}

	public void setSnowIncCorrelationDisplay(String snowIncCorrelationDisplay) {
		this.snowIncCorrelationDisplay = snowIncCorrelationDisplay;
	}

	public String getSnowIncCorrelationId() {
		return snowIncCorrelationId;
	}

	public void setSnowIncCorrelationId(String snowIncCorrelationId) {
		this.snowIncCorrelationId = snowIncCorrelationId;
	}

	public String getSnowIncDeliveryPlan() {
		return snowIncDeliveryPlan;
	}

	public void setSnowIncDeliveryPlan(String snowIncDeliveryPlan) {
		this.snowIncDeliveryPlan = snowIncDeliveryPlan;
	}

	public String getSnowIncDescription() {
		return snowIncDescription;
	}

	public void setSnowIncDescription(String snowIncDescription) {
		this.snowIncDescription = snowIncDescription;
	}

	public String getSnowIncDueDate() {
		return snowIncDueDate;
	}

	public void setSnowIncDueDate(String snowIncDueDate) {
		this.snowIncDueDate = snowIncDueDate;
	}

	public String getSnowIncEffort() {
		return snowIncEffort;
	}

	public void setSnowIncEffort(String snowIncEffort) {
		this.snowIncEffort = snowIncEffort;
	}

	public String getSnowIncEndDate() {
		return snowIncEndDate;
	}

	public void setSnowIncEndDate(String snowIncEndDate) {
		this.snowIncEndDate = snowIncEndDate;
	}

	public String getSnowIncEscalation() {
		return snowIncEscalation;
	}

	public void setSnowIncEscalation(String snowIncEscalation) {
		this.snowIncEscalation = snowIncEscalation;
	}

	public String getSnowIncExpectedStart() {
		return snowIncExpectedStart;
	}

	public void setSnowIncExpectedStart(String snowIncExpectedStart) {
		this.snowIncExpectedStart = snowIncExpectedStart;
	}

	public String getSnowIncFollowUp() {
		return snowIncFollowUp;
	}

	public void setSnowIncFollowUp(String snowIncFollowUp) {
		this.snowIncFollowUp = snowIncFollowUp;
	}

	public String getSnowIncGroupList() {
		return snowIncGroupList;
	}

	public void setSnowIncGroupList(String snowIncGroupList) {
		this.snowIncGroupList = snowIncGroupList;
	}

	public String getSnowIncImpact() {
		return snowIncImpact;
	}

	public void setSnowIncImpact(String snowIncImpact) {
		this.snowIncImpact = snowIncImpact;
	}

	public String getSnowIncKnowledge() {
		return snowIncKnowledge;
	}

	public void setSnowIncKnowledge(String snowIncKnowledge) {
		this.snowIncKnowledge = snowIncKnowledge;
	}

	public String getSnowIncLocation() {
		return snowIncLocation;
	}

	public void setSnowIncLocation(String snowIncLocation) {
		this.snowIncLocation = snowIncLocation;
	}

	public String getSnowIncMadeSla() {
		return snowIncMadeSla;
	}

	public void setSnowIncMadeSla(String snowIncMadeSla) {
		this.snowIncMadeSla = snowIncMadeSla;
	}

	public String getSnowIncNotify() {
		return snowIncNotify;
	}

	public void setSnowIncNotify(String snowIncNotify) {
		this.snowIncNotify = snowIncNotify;
	}

	public String getSnowIncNumber() {
		return snowIncNumber;
	}

	public void setSnowIncNumber(String snowIncNumber) {
		this.snowIncNumber = snowIncNumber;
	}

	public String getSnowIncOpenedAt() {
		return snowIncOpenedAt;
	}

	public void setSnowIncOpenedAt(String snowIncOpenedAt) {
		this.snowIncOpenedAt = snowIncOpenedAt;
	}

	public String getSnowIncOpenedBy() {
		return snowIncOpenedBy;
	}

	public void setSnowIncOpenedBy(String snowIncOpenedBy) {
		this.snowIncOpenedBy = snowIncOpenedBy;
	}

	public String getSnowIncOrder() {
		return snowIncOrder;
	}

	public void setSnowIncOrder(String snowIncOrder) {
		this.snowIncOrder = snowIncOrder;
	}

	public String getSnowIncParent() {
		return snowIncParent;
	}

	public void setSnowIncParent(String snowIncParent) {
		this.snowIncParent = snowIncParent;
	}

	public String getSnowIncPriority() {
		return snowIncPriority;
	}

	public void setSnowIncPriority(String snowIncPriority) {
		this.snowIncPriority = snowIncPriority;
	}

	public String getSnowIncProblemId() {
		return snowIncProblemId;
	}

	public void setSnowIncProblemId(String snowIncProblemId) {
		this.snowIncProblemId = snowIncProblemId;
	}

	public String getSnowIncReassignmentCount() {
		return snowIncReassignmentCount;
	}

	public void setSnowIncReassignmentCount(String snowIncReassignmentCount) {
		this.snowIncReassignmentCount = snowIncReassignmentCount;
	}

	public String getSnowIncResolvedAt() {
		return snowIncResolvedAt;
	}

	public void setSnowIncResolvedAt(String snowIncResolvedAt) {
		this.snowIncResolvedAt = snowIncResolvedAt;
	}

	public String getSnowIncResolvedBy() {
		return snowIncResolvedBy;
	}

	public void setSnowIncResolvedBy(String snowIncResolvedBy) {
		this.snowIncResolvedBy = snowIncResolvedBy;
	}

	public String getSnowIncRfc() {
		return snowIncRfc;
	}

	public void setSnowIncRfc(String snowIncRfc) {
		this.snowIncRfc = snowIncRfc;
	}

	public String getSnowIncSeverity() {
		return snowIncSeverity;
	}

	public void setSnowIncSeverity(String snowIncSeverity) {
		this.snowIncSeverity = snowIncSeverity;
	}

	public String getSnowIncShortDescription() {
		return snowIncShortDescription;
	}

	public void setSnowIncShortDescription(String snowIncShortDescription) {
		this.snowIncShortDescription = snowIncShortDescription;
	}

	public String getSnowIncSkills() {
		return snowIncSkills;
	}

	public void setSnowIncSkills(String snowIncSkills) {
		this.snowIncSkills = snowIncSkills;
	}

	public String getSnowIncSlaDue() {
		return snowIncSlaDue;
	}

	public void setSnowIncSlaDue(String snowIncSlaDue) {
		this.snowIncSlaDue = snowIncSlaDue;
	}

	public String getSnowIncStartDate() {
		return snowIncStartDate;
	}

	public void setSnowIncStartDate(String snowIncStartDate) {
		this.snowIncStartDate = snowIncStartDate;
	}

	public String getSnowIncState() {
		return snowIncState;
	}

	public void setSnowIncState(String snowIncState) {
		this.snowIncState = snowIncState;
	}

	public String getSnowIncStatus() {
		return snowIncStatus;
	}

	public void setSnowIncStatus(String snowIncStatus) {
		this.snowIncStatus = snowIncStatus;
	}

	public String getSnowIncSubcategory() {
		return snowIncSubcategory;
	}

	public void setSnowIncSubcategory(String snowIncSubcategory) {
		this.snowIncSubcategory = snowIncSubcategory;
	}

	public String getSnowIncSysClassName() {
		return snowIncSysClassName;
	}

	public void setSnowIncSysClassName(String snowIncSysClassName) {
		this.snowIncSysClassName = snowIncSysClassName;
	}

	public String getSnowIncSysCreatedBy() {
		return snowIncSysCreatedBy;
	}

	public void setSnowIncSysCreatedBy(String snowIncSysCreatedBy) {
		this.snowIncSysCreatedBy = snowIncSysCreatedBy;
	}

	public String getSnowIncSysCreatedOn() {
		return snowIncSysCreatedOn;
	}

	public void setSnowIncSysCreatedOn(String snowIncSysCreatedOn) {
		this.snowIncSysCreatedOn = snowIncSysCreatedOn;
	}

	public String getSnowIncSysDomain() {
		return snowIncSysDomain;
	}

	public void setSnowIncSysDomain(String snowIncSysDomain) {
		this.snowIncSysDomain = snowIncSysDomain;
	}

	public String getSnowIncSysId() {
		return snowIncSysId;
	}

	public void setSnowIncSysId(String snowIncSysId) {
		this.snowIncSysId = snowIncSysId;
	}

	public String getSnowIncSysModCount() {
		return snowIncSysModCount;
	}

	public void setSnowIncSysModCount(String snowIncSysModCount) {
		this.snowIncSysModCount = snowIncSysModCount;
	}

	public String getSnowIncSysTags() {
		return snowIncSysTags;
	}

	public void setSnowIncSysTags(String snowIncSysTags) {
		this.snowIncSysTags = snowIncSysTags;
	}

	public String getSnowIncSysUpdatedBy() {
		return snowIncSysUpdatedBy;
	}

	public void setSnowIncSysUpdatedBy(String snowIncSysUpdatedBy) {
		this.snowIncSysUpdatedBy = snowIncSysUpdatedBy;
	}

	public String getSnowIncSysUpdatedOn() {
		return snowIncSysUpdatedOn;
	}

	public void setSnowIncSysUpdatedOn(String snowIncSysUpdatedOn) {
		this.snowIncSysUpdatedOn = snowIncSysUpdatedOn;
	}

	public String getSnowIncTimeWorked() {
		return snowIncTimeWorked;
	}

	public void setSnowIncTimeWorked(String snowIncTimeWorked) {
		this.snowIncTimeWorked = snowIncTimeWorked;
	}

	public String getSnowIncU_3RdLineComments() {
		return snowIncU_3RdLineComments;
	}

	public void setSnowIncU_3RdLineComments(String snowIncU_3RdLineComments) {
		this.snowIncU_3RdLineComments = snowIncU_3RdLineComments;
	}

	public String getSnowIncU_3RdLineSrt() {
		return snowIncU_3RdLineSrt;
	}

	public void setSnowIncU_3RdLineSrt(String snowIncU_3RdLineSrt) {
		this.snowIncU_3RdLineSrt = snowIncU_3RdLineSrt;
	}

	public String getSnowIncU_AcknowldgeFeedback() {
		return snowIncU_AcknowldgeFeedback;
	}

	public void setSnowIncU_AcknowldgeFeedback(String snowIncU_AcknowldgeFeedback) {
		this.snowIncU_AcknowldgeFeedback = snowIncU_AcknowldgeFeedback;
	}

	public String getSnowIncU_Acknowledged() {
		return snowIncU_Acknowledged;
	}

	public void setSnowIncU_Acknowledged(String snowIncU_Acknowledged) {
		this.snowIncU_Acknowledged = snowIncU_Acknowledged;
	}

	public String getSnowIncU_ActiveProbInc() {
		return snowIncU_ActiveProbInc;
	}

	public void setSnowIncU_ActiveProbInc(String snowIncU_ActiveProbInc) {
		this.snowIncU_ActiveProbInc = snowIncU_ActiveProbInc;
	}

	public String getSnowIncU_ActualEffort() {
		return snowIncU_ActualEffort;
	}

	public void setSnowIncU_ActualEffort(String snowIncU_ActualEffort) {
		this.snowIncU_ActualEffort = snowIncU_ActualEffort;
	}

	public String getSnowIncU_ActualStart() {
		return snowIncU_ActualStart;
	}

	public void setSnowIncU_ActualStart(String snowIncU_ActualStart) {
		this.snowIncU_ActualStart = snowIncU_ActualStart;
	}

	public String getSnowIncU_AffectedAsset() {
		return snowIncU_AffectedAsset;
	}

	public void setSnowIncU_AffectedAsset(String snowIncU_AffectedAsset) {
		this.snowIncU_AffectedAsset = snowIncU_AffectedAsset;
	}

	public String getSnowIncU_AffectedUser() {
		return snowIncU_AffectedUser;
	}

	public void setSnowIncU_AffectedUser(String snowIncU_AffectedUser) {
		this.snowIncU_AffectedUser = snowIncU_AffectedUser;
	}

	public String getSnowIncU_AlertingCi() {
		return snowIncU_AlertingCi;
	}

	public void setSnowIncU_AlertingCi(String snowIncU_AlertingCi) {
		this.snowIncU_AlertingCi = snowIncU_AlertingCi;
	}

	public String getSnowIncU_AlertingFollowUp() {
		return snowIncU_AlertingFollowUp;
	}

	public void setSnowIncU_AlertingFollowUp(String snowIncU_AlertingFollowUp) {
		this.snowIncU_AlertingFollowUp = snowIncU_AlertingFollowUp;
	}

	public String getSnowIncU_AlertingRepeatCount() {
		return snowIncU_AlertingRepeatCount;
	}

	public void setSnowIncU_AlertingRepeatCount(String snowIncU_AlertingRepeatCount) {
		this.snowIncU_AlertingRepeatCount = snowIncU_AlertingRepeatCount;
	}

	public String getSnowIncU_AlertingReview() {
		return snowIncU_AlertingReview;
	}

	public void setSnowIncU_AlertingReview(String snowIncU_AlertingReview) {
		this.snowIncU_AlertingReview = snowIncU_AlertingReview;
	}

	public String getSnowIncU_AofDateTime() {
		return snowIncU_AofDateTime;
	}

	public void setSnowIncU_AofDateTime(String snowIncU_AofDateTime) {
		this.snowIncU_AofDateTime = snowIncU_AofDateTime;
	}

	public String getSnowIncU_AofPass() {
		return snowIncU_AofPass;
	}

	public void setSnowIncU_AofPass(String snowIncU_AofPass) {
		this.snowIncU_AofPass = snowIncU_AofPass;
	}

	public String getSnowIncU_AofState() {
		return snowIncU_AofState;
	}

	public void setSnowIncU_AofState(String snowIncU_AofState) {
		this.snowIncU_AofState = snowIncU_AofState;
	}

	public String getSnowIncU_AofWorkgroup() {
		return snowIncU_AofWorkgroup;
	}

	public void setSnowIncU_AofWorkgroup(String snowIncU_AofWorkgroup) {
		this.snowIncU_AofWorkgroup = snowIncU_AofWorkgroup;
	}

	public String getSnowIncU_AosDateTime() {
		return snowIncU_AosDateTime;
	}

	public void setSnowIncU_AosDateTime(String snowIncU_AosDateTime) {
		this.snowIncU_AosDateTime = snowIncU_AosDateTime;
	}

	public String getSnowIncU_AosPass() {
		return snowIncU_AosPass;
	}

	public void setSnowIncU_AosPass(String snowIncU_AosPass) {
		this.snowIncU_AosPass = snowIncU_AosPass;
	}

	public String getSnowIncU_AosState() {
		return snowIncU_AosState;
	}

	public void setSnowIncU_AosState(String snowIncU_AosState) {
		this.snowIncU_AosState = snowIncU_AosState;
	}

	public String getSnowIncU_AosWorkgroup() {
		return snowIncU_AosWorkgroup;
	}

	public void setSnowIncU_AosWorkgroup(String snowIncU_AosWorkgroup) {
		this.snowIncU_AosWorkgroup = snowIncU_AosWorkgroup;
	}

	public String getSnowIncU_ApplicationCode() {
		return snowIncU_ApplicationCode;
	}

	public void setSnowIncU_ApplicationCode(String snowIncU_ApplicationCode) {
		this.snowIncU_ApplicationCode = snowIncU_ApplicationCode;
	}

	public String getSnowIncU_AssetCode() {
		return snowIncU_AssetCode;
	}

	public void setSnowIncU_AssetCode(String snowIncU_AssetCode) {
		this.snowIncU_AssetCode = snowIncU_AssetCode;
	}

	public String getSnowIncU_AssetString() {
		return snowIncU_AssetString;
	}

	public void setSnowIncU_AssetString(String snowIncU_AssetString) {
		this.snowIncU_AssetString = snowIncU_AssetString;
	}

	public String getSnowIncU_AssignedToBladelogic() {
		return snowIncU_AssignedToBladelogic;
	}

	public void setSnowIncU_AssignedToBladelogic(String snowIncU_AssignedToBladelogic) {
		this.snowIncU_AssignedToBladelogic = snowIncU_AssignedToBladelogic;
	}

	public String getSnowIncU_AssignmentStatus() {
		return snowIncU_AssignmentStatus;
	}

	public void setSnowIncU_AssignmentStatus(String snowIncU_AssignmentStatus) {
		this.snowIncU_AssignmentStatus = snowIncU_AssignmentStatus;
	}

	public String getSnowIncU_AttachmentsAdded() {
		return snowIncU_AttachmentsAdded;
	}

	public void setSnowIncU_AttachmentsAdded(String snowIncU_AttachmentsAdded) {
		this.snowIncU_AttachmentsAdded = snowIncU_AttachmentsAdded;
	}

	public String getSnowIncU_AuditCode() {
		return snowIncU_AuditCode;
	}

	public void setSnowIncU_AuditCode(String snowIncU_AuditCode) {
		this.snowIncU_AuditCode = snowIncU_AuditCode;
	}

	public String getSnowIncU_AutoClose() {
		return snowIncU_AutoClose;
	}

	public void setSnowIncU_AutoClose(String snowIncU_AutoClose) {
		this.snowIncU_AutoClose = snowIncU_AutoClose;
	}

	public String getSnowIncU_AutoCloseTicket() {
		return snowIncU_AutoCloseTicket;
	}

	public void setSnowIncU_AutoCloseTicket(String snowIncU_AutoCloseTicket) {
		this.snowIncU_AutoCloseTicket = snowIncU_AutoCloseTicket;
	}

	public String getSnowIncU_AutoParm1() {
		return snowIncU_AutoParm1;
	}

	public void setSnowIncU_AutoParm1(String snowIncU_AutoParm1) {
		this.snowIncU_AutoParm1 = snowIncU_AutoParm1;
	}

	public String getSnowIncU_AutoParm2() {
		return snowIncU_AutoParm2;
	}

	public void setSnowIncU_AutoParm2(String snowIncU_AutoParm2) {
		this.snowIncU_AutoParm2 = snowIncU_AutoParm2;
	}

	public String getSnowIncU_AutoParm3() {
		return snowIncU_AutoParm3;
	}

	public void setSnowIncU_AutoParm3(String snowIncU_AutoParm3) {
		this.snowIncU_AutoParm3 = snowIncU_AutoParm3;
	}

	public String getSnowIncU_AutoParm4() {
		return snowIncU_AutoParm4;
	}

	public void setSnowIncU_AutoParm4(String snowIncU_AutoParm4) {
		this.snowIncU_AutoParm4 = snowIncU_AutoParm4;
	}

	public String getSnowIncU_AutoParm5() {
		return snowIncU_AutoParm5;
	}

	public void setSnowIncU_AutoParm5(String snowIncU_AutoParm5) {
		this.snowIncU_AutoParm5 = snowIncU_AutoParm5;
	}

	public String getSnowIncU_AutoTarget() {
		return snowIncU_AutoTarget;
	}

	public void setSnowIncU_AutoTarget(String snowIncU_AutoTarget) {
		this.snowIncU_AutoTarget = snowIncU_AutoTarget;
	}

	public String getSnowIncU_AutoType() {
		return snowIncU_AutoType;
	}

	public void setSnowIncU_AutoType(String snowIncU_AutoType) {
		this.snowIncU_AutoType = snowIncU_AutoType;
	}

	public String getSnowIncU_AvailAddComments() {
		return snowIncU_AvailAddComments;
	}

	public void setSnowIncU_AvailAddComments(String snowIncU_AvailAddComments) {
		this.snowIncU_AvailAddComments = snowIncU_AvailAddComments;
	}

	public String getSnowIncU_AvailTechSvc() {
		return snowIncU_AvailTechSvc;
	}

	public void setSnowIncU_AvailTechSvc(String snowIncU_AvailTechSvc) {
		this.snowIncU_AvailTechSvc = snowIncU_AvailTechSvc;
	}

	public String getSnowIncU_AvailabilityIncludeOutage() {
		return snowIncU_AvailabilityIncludeOutage;
	}

	public void setSnowIncU_AvailabilityIncludeOutage(String snowIncU_AvailabilityIncludeOutage) {
		this.snowIncU_AvailabilityIncludeOutage = snowIncU_AvailabilityIncludeOutage;
	}

	public String getSnowIncU_AvailabilityReport() {
		return snowIncU_AvailabilityReport;
	}

	public void setSnowIncU_AvailabilityReport(String snowIncU_AvailabilityReport) {
		this.snowIncU_AvailabilityReport = snowIncU_AvailabilityReport;
	}

	public String getSnowIncU_BatchStep() {
		return snowIncU_BatchStep;
	}

	public void setSnowIncU_BatchStep(String snowIncU_BatchStep) {
		this.snowIncU_BatchStep = snowIncU_BatchStep;
	}

	public String getSnowIncU_BemUpdates() {
		return snowIncU_BemUpdates;
	}

	public void setSnowIncU_BemUpdates(String snowIncU_BemUpdates) {
		this.snowIncU_BemUpdates = snowIncU_BemUpdates;
	}

	public String getSnowIncU_BounceCount() {
		return snowIncU_BounceCount;
	}

	public void setSnowIncU_BounceCount(String snowIncU_BounceCount) {
		this.snowIncU_BounceCount = snowIncU_BounceCount;
	}

	public String getSnowIncU_BsdCall() {
		return snowIncU_BsdCall;
	}

	public void setSnowIncU_BsdCall(String snowIncU_BsdCall) {
		this.snowIncU_BsdCall = snowIncU_BsdCall;
	}

	public String getSnowIncU_BsdResolutionBy() {
		return snowIncU_BsdResolutionBy;
	}

	public void setSnowIncU_BsdResolutionBy(String snowIncU_BsdResolutionBy) {
		this.snowIncU_BsdResolutionBy = snowIncU_BsdResolutionBy;
	}

	public String getSnowIncU_BusinessCritical() {
		return snowIncU_BusinessCritical;
	}

	public void setSnowIncU_BusinessCritical(String snowIncU_BusinessCritical) {
		this.snowIncU_BusinessCritical = snowIncU_BusinessCritical;
	}

	public String getSnowIncU_BusinessImpact() {
		return snowIncU_BusinessImpact;
	}

	public void setSnowIncU_BusinessImpact(String snowIncU_BusinessImpact) {
		this.snowIncU_BusinessImpact = snowIncU_BusinessImpact;
	}

	public String getSnowIncU_BusinessService() {
		return snowIncU_BusinessService;
	}

	public void setSnowIncU_BusinessService(String snowIncU_BusinessService) {
		this.snowIncU_BusinessService = snowIncU_BusinessService;
	}

	public String getSnowIncU_CallCaptureComments() {
		return snowIncU_CallCaptureComments;
	}

	public void setSnowIncU_CallCaptureComments(String snowIncU_CallCaptureComments) {
		this.snowIncU_CallCaptureComments = snowIncU_CallCaptureComments;
	}

	public String getSnowIncU_CallHandlingComments() {
		return snowIncU_CallHandlingComments;
	}

	public void setSnowIncU_CallHandlingComments(String snowIncU_CallHandlingComments) {
		this.snowIncU_CallHandlingComments = snowIncU_CallHandlingComments;
	}

	public String getSnowIncU_CallOut() {
		return snowIncU_CallOut;
	}

	public void setSnowIncU_CallOut(String snowIncU_CallOut) {
		this.snowIncU_CallOut = snowIncU_CallOut;
	}

	public String getSnowIncU_CallOutInvoked() {
		return snowIncU_CallOutInvoked;
	}

	public void setSnowIncU_CallOutInvoked(String snowIncU_CallOutInvoked) {
		this.snowIncU_CallOutInvoked = snowIncU_CallOutInvoked;
	}

	public String getSnowIncU_CauseItem() {
		return snowIncU_CauseItem;
	}

	public void setSnowIncU_CauseItem(String snowIncU_CauseItem) {
		this.snowIncU_CauseItem = snowIncU_CauseItem;
	}

	public String getSnowIncU_CausedBy() {
		return snowIncU_CausedBy;
	}

	public void setSnowIncU_CausedBy(String snowIncU_CausedBy) {
		this.snowIncU_CausedBy = snowIncU_CausedBy;
	}

	public String getSnowIncU_ChangeManager() {
		return snowIncU_ChangeManager;
	}

	public void setSnowIncU_ChangeManager(String snowIncU_ChangeManager) {
		this.snowIncU_ChangeManager = snowIncU_ChangeManager;
	}

	public String getSnowIncU_CiCategory() {
		return snowIncU_CiCategory;
	}

	public void setSnowIncU_CiCategory(String snowIncU_CiCategory) {
		this.snowIncU_CiCategory = snowIncU_CiCategory;
	}

	public String getSnowIncU_CiClassification() {
		return snowIncU_CiClassification;
	}

	public void setSnowIncU_CiClassification(String snowIncU_CiClassification) {
		this.snowIncU_CiClassification = snowIncU_CiClassification;
	}

	public String getSnowIncU_CiSubcategory() {
		return snowIncU_CiSubcategory;
	}

	public void setSnowIncU_CiSubcategory(String snowIncU_CiSubcategory) {
		this.snowIncU_CiSubcategory = snowIncU_CiSubcategory;
	}

	public String getSnowIncU_CiSubclassification() {
		return snowIncU_CiSubclassification;
	}

	public void setSnowIncU_CiSubclassification(String snowIncU_CiSubclassification) {
		this.snowIncU_CiSubclassification = snowIncU_CiSubclassification;
	}

	public String getSnowIncU_Classification() {
		return snowIncU_Classification;
	}

	public void setSnowIncU_Classification(String snowIncU_Classification) {
		this.snowIncU_Classification = snowIncU_Classification;
	}

	public String getSnowIncU_ClosedCentrally() {
		return snowIncU_ClosedCentrally;
	}

	public void setSnowIncU_ClosedCentrally(String snowIncU_ClosedCentrally) {
		this.snowIncU_ClosedCentrally = snowIncU_ClosedCentrally;
	}

	public String getSnowIncU_ClosedPeriod() {
		return snowIncU_ClosedPeriod;
	}

	public void setSnowIncU_ClosedPeriod(String snowIncU_ClosedPeriod) {
		this.snowIncU_ClosedPeriod = snowIncU_ClosedPeriod;
	}

	public String getSnowIncU_ClosureCategory() {
		return snowIncU_ClosureCategory;
	}

	public void setSnowIncU_ClosureCategory(String snowIncU_ClosureCategory) {
		this.snowIncU_ClosureCategory = snowIncU_ClosureCategory;
	}

	public String getSnowIncU_ClosureCi() {
		return snowIncU_ClosureCi;
	}

	public void setSnowIncU_ClosureCi(String snowIncU_ClosureCi) {
		this.snowIncU_ClosureCi = snowIncU_ClosureCi;
	}

	public String getSnowIncU_ClosureRejected() {
		return snowIncU_ClosureRejected;
	}

	public void setSnowIncU_ClosureRejected(String snowIncU_ClosureRejected) {
		this.snowIncU_ClosureRejected = snowIncU_ClosureRejected;
	}

	public String getSnowIncU_ClosureSubcategory() {
		return snowIncU_ClosureSubcategory;
	}

	public void setSnowIncU_ClosureSubcategory(String snowIncU_ClosureSubcategory) {
		this.snowIncU_ClosureSubcategory = snowIncU_ClosureSubcategory;
	}

	public String getSnowIncU_CommentType() {
		return snowIncU_CommentType;
	}

	public void setSnowIncU_CommentType(String snowIncU_CommentType) {
		this.snowIncU_CommentType = snowIncU_CommentType;
	}

	public String getSnowIncU_CommentTypeHandling() {
		return snowIncU_CommentTypeHandling;
	}

	public void setSnowIncU_CommentTypeHandling(String snowIncU_CommentTypeHandling) {
		this.snowIncU_CommentTypeHandling = snowIncU_CommentTypeHandling;
	}

	public String getSnowIncU_CommentsAndWorkNotes() {
		return snowIncU_CommentsAndWorkNotes;
	}

	public void setSnowIncU_CommentsAndWorkNotes(String snowIncU_CommentsAndWorkNotes) {
		this.snowIncU_CommentsAndWorkNotes = snowIncU_CommentsAndWorkNotes;
	}

	public String getSnowIncU_Communication() {
		return snowIncU_Communication;
	}

	public void setSnowIncU_Communication(String snowIncU_Communication) {
		this.snowIncU_Communication = snowIncU_Communication;
	}

	public String getSnowIncU_CommunicationEmail() {
		return snowIncU_CommunicationEmail;
	}

	public void setSnowIncU_CommunicationEmail(String snowIncU_CommunicationEmail) {
		this.snowIncU_CommunicationEmail = snowIncU_CommunicationEmail;
	}

	public String getSnowIncU_CommunicationType() {
		return snowIncU_CommunicationType;
	}

	public void setSnowIncU_CommunicationType(String snowIncU_CommunicationType) {
		this.snowIncU_CommunicationType = snowIncU_CommunicationType;
	}

	public String getSnowIncU_CopyComments() {
		return snowIncU_CopyComments;
	}

	public void setSnowIncU_CopyComments(String snowIncU_CopyComments) {
		this.snowIncU_CopyComments = snowIncU_CopyComments;
	}

	public String getSnowIncU_CopySubject() {
		return snowIncU_CopySubject;
	}

	public void setSnowIncU_CopySubject(String snowIncU_CopySubject) {
		this.snowIncU_CopySubject = snowIncU_CopySubject;
	}

	public String getSnowIncU_CreatedByWorkgroup() {
		return snowIncU_CreatedByWorkgroup;
	}

	public void setSnowIncU_CreatedByWorkgroup(String snowIncU_CreatedByWorkgroup) {
		this.snowIncU_CreatedByWorkgroup = snowIncU_CreatedByWorkgroup;
	}

	public String getSnowIncU_DailyServiceSummary() {
		return snowIncU_DailyServiceSummary;
	}

	public void setSnowIncU_DailyServiceSummary(String snowIncU_DailyServiceSummary) {
		this.snowIncU_DailyServiceSummary = snowIncU_DailyServiceSummary;
	}

	public String getSnowIncU_DesktopAssetNumber() {
		return snowIncU_DesktopAssetNumber;
	}

	public void setSnowIncU_DesktopAssetNumber(String snowIncU_DesktopAssetNumber) {
		this.snowIncU_DesktopAssetNumber = snowIncU_DesktopAssetNumber;
	}

	public String getSnowIncU_DesktopCustomerUnavailable() {
		return snowIncU_DesktopCustomerUnavailable;
	}

	public void setSnowIncU_DesktopCustomerUnavailable(String snowIncU_DesktopCustomerUnavailable) {
		this.snowIncU_DesktopCustomerUnavailable = snowIncU_DesktopCustomerUnavailable;
	}

	public String getSnowIncU_DesktopMake() {
		return snowIncU_DesktopMake;
	}

	public void setSnowIncU_DesktopMake(String snowIncU_DesktopMake) {
		this.snowIncU_DesktopMake = snowIncU_DesktopMake;
	}

	public String getSnowIncU_DesktopModel() {
		return snowIncU_DesktopModel;
	}

	public void setSnowIncU_DesktopModel(String snowIncU_DesktopModel) {
		this.snowIncU_DesktopModel = snowIncU_DesktopModel;
	}

	public String getSnowIncU_DesktopSN() {
		return snowIncU_DesktopSN;
	}

	public void setSnowIncU_DesktopSN(String snowIncU_DesktopSN) {
		this.snowIncU_DesktopSN = snowIncU_DesktopSN;
	}

	public String getSnowIncU_DsrImpactComments() {
		return snowIncU_DsrImpactComments;
	}

	public void setSnowIncU_DsrImpactComments(String snowIncU_DsrImpactComments) {
		this.snowIncU_DsrImpactComments = snowIncU_DsrImpactComments;
	}

	public String getSnowIncU_DsrOrganisation() {
		return snowIncU_DsrOrganisation;
	}

	public void setSnowIncU_DsrOrganisation(String snowIncU_DsrOrganisation) {
		this.snowIncU_DsrOrganisation = snowIncU_DsrOrganisation;
	}

	public String getSnowIncU_DsrOutageFinish() {
		return snowIncU_DsrOutageFinish;
	}

	public void setSnowIncU_DsrOutageFinish(String snowIncU_DsrOutageFinish) {
		this.snowIncU_DsrOutageFinish = snowIncU_DsrOutageFinish;
	}

	public String getSnowIncU_DsrOutageStart() {
		return snowIncU_DsrOutageStart;
	}

	public void setSnowIncU_DsrOutageStart(String snowIncU_DsrOutageStart) {
		this.snowIncU_DsrOutageStart = snowIncU_DsrOutageStart;
	}

	public String getSnowIncU_DsrReportDate() {
		return snowIncU_DsrReportDate;
	}

	public void setSnowIncU_DsrReportDate(String snowIncU_DsrReportDate) {
		this.snowIncU_DsrReportDate = snowIncU_DsrReportDate;
	}

	public String getSnowIncU_DsrServiceSAffectedList() {
		return snowIncU_DsrServiceSAffectedList;
	}

	public void setSnowIncU_DsrServiceSAffectedList(String snowIncU_DsrServiceSAffectedList) {
		this.snowIncU_DsrServiceSAffectedList = snowIncU_DsrServiceSAffectedList;
	}

	public String getSnowIncU_DsrSynopsis() {
		return snowIncU_DsrSynopsis;
	}

	public void setSnowIncU_DsrSynopsis(String snowIncU_DsrSynopsis) {
		this.snowIncU_DsrSynopsis = snowIncU_DsrSynopsis;
	}

	public String getSnowIncU_DsrTimeline() {
		return snowIncU_DsrTimeline;
	}

	public void setSnowIncU_DsrTimeline(String snowIncU_DsrTimeline) {
		this.snowIncU_DsrTimeline = snowIncU_DsrTimeline;
	}

	public String getSnowIncU_DssFollowUpActions() {
		return snowIncU_DssFollowUpActions;
	}

	public void setSnowIncU_DssFollowUpActions(String snowIncU_DssFollowUpActions) {
		this.snowIncU_DssFollowUpActions = snowIncU_DssFollowUpActions;
	}

	public String getSnowIncU_DssOutstandingActions() {
		return snowIncU_DssOutstandingActions;
	}

	public void setSnowIncU_DssOutstandingActions(String snowIncU_DssOutstandingActions) {
		this.snowIncU_DssOutstandingActions = snowIncU_DssOutstandingActions;
	}

	public String getSnowIncU_DssRootCauseAnalysis() {
		return snowIncU_DssRootCauseAnalysis;
	}

	public void setSnowIncU_DssRootCauseAnalysis(String snowIncU_DssRootCauseAnalysis) {
		this.snowIncU_DssRootCauseAnalysis = snowIncU_DssRootCauseAnalysis;
	}

	public String getSnowIncU_DssWeighting() {
		return snowIncU_DssWeighting;
	}

	public void setSnowIncU_DssWeighting(String snowIncU_DssWeighting) {
		this.snowIncU_DssWeighting = snowIncU_DssWeighting;
	}

	public String getSnowIncU_EbondingFailed() {
		return snowIncU_EbondingFailed;
	}

	public void setSnowIncU_EbondingFailed(String snowIncU_EbondingFailed) {
		this.snowIncU_EbondingFailed = snowIncU_EbondingFailed;
	}

	public String getSnowIncU_Email() {
		return snowIncU_Email;
	}

	public void setSnowIncU_Email(String snowIncU_Email) {
		this.snowIncU_Email = snowIncU_Email;
	}

	public String getSnowIncU_EmailTemplate() {
		return snowIncU_EmailTemplate;
	}

	public void setSnowIncU_EmailTemplate(String snowIncU_EmailTemplate) {
		this.snowIncU_EmailTemplate = snowIncU_EmailTemplate;
	}

	public String getSnowIncU_Escalated() {
		return snowIncU_Escalated;
	}

	public void setSnowIncU_Escalated(String snowIncU_Escalated) {
		this.snowIncU_Escalated = snowIncU_Escalated;
	}

	public String getSnowIncU_EscalationType() {
		return snowIncU_EscalationType;
	}

	public void setSnowIncU_EscalationType(String snowIncU_EscalationType) {
		this.snowIncU_EscalationType = snowIncU_EscalationType;
	}

	public String getSnowIncU_EventUrl() {
		return snowIncU_EventUrl;
	}

	public void setSnowIncU_EventUrl(String snowIncU_EventUrl) {
		this.snowIncU_EventUrl = snowIncU_EventUrl;
	}

	public String getSnowIncU_ExpertHelp() {
		return snowIncU_ExpertHelp;
	}

	public void setSnowIncU_ExpertHelp(String snowIncU_ExpertHelp) {
		this.snowIncU_ExpertHelp = snowIncU_ExpertHelp;
	}

	public String getSnowIncU_ExternalRef() {
		return snowIncU_ExternalRef;
	}

	public void setSnowIncU_ExternalRef(String snowIncU_ExternalRef) {
		this.snowIncU_ExternalRef = snowIncU_ExternalRef;
	}

	public String getSnowIncU_FailingObject() {
		return snowIncU_FailingObject;
	}

	public void setSnowIncU_FailingObject(String snowIncU_FailingObject) {
		this.snowIncU_FailingObject = snowIncU_FailingObject;
	}

	public String getSnowIncU_FeedbackCode() {
		return snowIncU_FeedbackCode;
	}

	public void setSnowIncU_FeedbackCode(String snowIncU_FeedbackCode) {
		this.snowIncU_FeedbackCode = snowIncU_FeedbackCode;
	}

	public String getSnowIncU_FeedbackCodeHandling() {
		return snowIncU_FeedbackCodeHandling;
	}

	public void setSnowIncU_FeedbackCodeHandling(String snowIncU_FeedbackCodeHandling) {
		this.snowIncU_FeedbackCodeHandling = snowIncU_FeedbackCodeHandling;
	}

	public String getSnowIncU_FirstDeadline() {
		return snowIncU_FirstDeadline;
	}

	public void setSnowIncU_FirstDeadline(String snowIncU_FirstDeadline) {
		this.snowIncU_FirstDeadline = snowIncU_FirstDeadline;
	}

	public String getSnowIncU_FirstTimeFix() {
		return snowIncU_FirstTimeFix;
	}

	public void setSnowIncU_FirstTimeFix(String snowIncU_FirstTimeFix) {
		this.snowIncU_FirstTimeFix = snowIncU_FirstTimeFix;
	}

	public String getSnowIncU_Folder() {
		return snowIncU_Folder;
	}

	public void setSnowIncU_Folder(String snowIncU_Folder) {
		this.snowIncU_Folder = snowIncU_Folder;
	}

	public String getSnowIncU_GlobalSspDashboard() {
		return snowIncU_GlobalSspDashboard;
	}

	public void setSnowIncU_GlobalSspDashboard(String snowIncU_GlobalSspDashboard) {
		this.snowIncU_GlobalSspDashboard = snowIncU_GlobalSspDashboard;
	}

	public String getSnowIncU_HighSeverity() {
		return snowIncU_HighSeverity;
	}

	public void setSnowIncU_HighSeverity(String snowIncU_HighSeverity) {
		this.snowIncU_HighSeverity = snowIncU_HighSeverity;
	}

	public String getSnowIncU_HpCauseCode() {
		return snowIncU_HpCauseCode;
	}

	public void setSnowIncU_HpCauseCode(String snowIncU_HpCauseCode) {
		this.snowIncU_HpCauseCode = snowIncU_HpCauseCode;
	}

	public String getSnowIncU_HpClosureCode() {
		return snowIncU_HpClosureCode;
	}

	public void setSnowIncU_HpClosureCode(String snowIncU_HpClosureCode) {
		this.snowIncU_HpClosureCode = snowIncU_HpClosureCode;
	}

	public String getSnowIncU_ImpBreakdown() {
		return snowIncU_ImpBreakdown;
	}

	public void setSnowIncU_ImpBreakdown(String snowIncU_ImpBreakdown) {
		this.snowIncU_ImpBreakdown = snowIncU_ImpBreakdown;
	}

	public String getSnowIncU_IncidentManager() {
		return snowIncU_IncidentManager;
	}

	public void setSnowIncU_IncidentManager(String snowIncU_IncidentManager) {
		this.snowIncU_IncidentManager = snowIncU_IncidentManager;
	}

	public String getSnowIncU_IncidentSummary() {
		return snowIncU_IncidentSummary;
	}

	public void setSnowIncU_IncidentSummary(String snowIncU_IncidentSummary) {
		this.snowIncU_IncidentSummary = snowIncU_IncidentSummary;
	}

	public String getSnowIncU_IncidentUpdate() {
		return snowIncU_IncidentUpdate;
	}

	public void setSnowIncU_IncidentUpdate(String snowIncU_IncidentUpdate) {
		this.snowIncU_IncidentUpdate = snowIncU_IncidentUpdate;
	}

	public String getSnowIncU_InitialAssignment() {
		return snowIncU_InitialAssignment;
	}

	public void setSnowIncU_InitialAssignment(String snowIncU_InitialAssignment) {
		this.snowIncU_InitialAssignment = snowIncU_InitialAssignment;
	}

	public String getSnowIncU_Instructions() {
		return snowIncU_Instructions;
	}

	public void setSnowIncU_Instructions(String snowIncU_Instructions) {
		this.snowIncU_Instructions = snowIncU_Instructions;
	}

	public String getSnowIncU_InternalRef() {
		return snowIncU_InternalRef;
	}

	public void setSnowIncU_InternalRef(String snowIncU_InternalRef) {
		this.snowIncU_InternalRef = snowIncU_InternalRef;
	}

	public String getSnowIncU_IsHpPendingCustomer() {
		return snowIncU_IsHpPendingCustomer;
	}

	public void setSnowIncU_IsHpPendingCustomer(String snowIncU_IsHpPendingCustomer) {
		this.snowIncU_IsHpPendingCustomer = snowIncU_IsHpPendingCustomer;
	}

	public String getSnowIncU_IssueTitle() {
		return snowIncU_IssueTitle;
	}

	public void setSnowIncU_IssueTitle(String snowIncU_IssueTitle) {
		this.snowIncU_IssueTitle = snowIncU_IssueTitle;
	}

	public String getSnowIncU_ItilWatchList() {
		return snowIncU_ItilWatchList;
	}

	public void setSnowIncU_ItilWatchList(String snowIncU_ItilWatchList) {
		this.snowIncU_ItilWatchList = snowIncU_ItilWatchList;
	}

	public String getSnowIncU_JobNumber() {
		return snowIncU_JobNumber;
	}

	public void setSnowIncU_JobNumber(String snowIncU_JobNumber) {
		this.snowIncU_JobNumber = snowIncU_JobNumber;
	}

	public String getSnowIncU_KnowledgeArticle() {
		return snowIncU_KnowledgeArticle;
	}

	public void setSnowIncU_KnowledgeArticle(String snowIncU_KnowledgeArticle) {
		this.snowIncU_KnowledgeArticle = snowIncU_KnowledgeArticle;
	}

	public String getSnowIncU_KnowledgeAvailable() {
		return snowIncU_KnowledgeAvailable;
	}

	public void setSnowIncU_KnowledgeAvailable(String snowIncU_KnowledgeAvailable) {
		this.snowIncU_KnowledgeAvailable = snowIncU_KnowledgeAvailable;
	}

	public String getSnowIncU_KnowledgeCode() {
		return snowIncU_KnowledgeCode;
	}

	public void setSnowIncU_KnowledgeCode(String snowIncU_KnowledgeCode) {
		this.snowIncU_KnowledgeCode = snowIncU_KnowledgeCode;
	}

	public String getSnowIncU_KnowledgeComments() {
		return snowIncU_KnowledgeComments;
	}

	public void setSnowIncU_KnowledgeComments(String snowIncU_KnowledgeComments) {
		this.snowIncU_KnowledgeComments = snowIncU_KnowledgeComments;
	}

	public String getSnowIncU_KnowledgeDirectory() {
		return snowIncU_KnowledgeDirectory;
	}

	public void setSnowIncU_KnowledgeDirectory(String snowIncU_KnowledgeDirectory) {
		this.snowIncU_KnowledgeDirectory = snowIncU_KnowledgeDirectory;
	}

	public String getSnowIncU_KnowledgeFound() {
		return snowIncU_KnowledgeFound;
	}

	public void setSnowIncU_KnowledgeFound(String snowIncU_KnowledgeFound) {
		this.snowIncU_KnowledgeFound = snowIncU_KnowledgeFound;
	}

	public String getSnowIncU_KnowledgeUser() {
		return snowIncU_KnowledgeUser;
	}

	public void setSnowIncU_KnowledgeUser(String snowIncU_KnowledgeUser) {
		this.snowIncU_KnowledgeUser = snowIncU_KnowledgeUser;
	}

	public String getSnowIncU_LastOccurrence() {
		return snowIncU_LastOccurrence;
	}

	public void setSnowIncU_LastOccurrence(String snowIncU_LastOccurrence) {
		this.snowIncU_LastOccurrence = snowIncU_LastOccurrence;
	}

	public String getSnowIncU_LateImpReason() {
		return snowIncU_LateImpReason;
	}

	public void setSnowIncU_LateImpReason(String snowIncU_LateImpReason) {
		this.snowIncU_LateImpReason = snowIncU_LateImpReason;
	}

	public String getSnowIncU_LeadTime() {
		return snowIncU_LeadTime;
	}

	public void setSnowIncU_LeadTime(String snowIncU_LeadTime) {
		this.snowIncU_LeadTime = snowIncU_LeadTime;
	}

	public String getSnowIncU_LiveFeedGroup() {
		return snowIncU_LiveFeedGroup;
	}

	public void setSnowIncU_LiveFeedGroup(String snowIncU_LiveFeedGroup) {
		this.snowIncU_LiveFeedGroup = snowIncU_LiveFeedGroup;
	}

	public String getSnowIncU_LiveFeedGroupDuplicate() {
		return snowIncU_LiveFeedGroupDuplicate;
	}

	public void setSnowIncU_LiveFeedGroupDuplicate(String snowIncU_LiveFeedGroupDuplicate) {
		this.snowIncU_LiveFeedGroupDuplicate = snowIncU_LiveFeedGroupDuplicate;
	}

	public String getSnowIncU_LocalResp() {
		return snowIncU_LocalResp;
	}

	public void setSnowIncU_LocalResp(String snowIncU_LocalResp) {
		this.snowIncU_LocalResp = snowIncU_LocalResp;
	}

	public String getSnowIncU_MajorIncident() {
		return snowIncU_MajorIncident;
	}

	public void setSnowIncU_MajorIncident(String snowIncU_MajorIncident) {
		this.snowIncU_MajorIncident = snowIncU_MajorIncident;
	}

	public String getSnowIncU_ManagementAuditComments() {
		return snowIncU_ManagementAuditComments;
	}

	public void setSnowIncU_ManagementAuditComments(String snowIncU_ManagementAuditComments) {
		this.snowIncU_ManagementAuditComments = snowIncU_ManagementAuditComments;
	}

	public String getSnowIncU_ManagementComments() {
		return snowIncU_ManagementComments;
	}

	public void setSnowIncU_ManagementComments(String snowIncU_ManagementComments) {
		this.snowIncU_ManagementComments = snowIncU_ManagementComments;
	}

	public String getSnowIncU_MissingCi() {
		return snowIncU_MissingCi;
	}

	public void setSnowIncU_MissingCi(String snowIncU_MissingCi) {
		this.snowIncU_MissingCi = snowIncU_MissingCi;
	}

	public String getSnowIncU_MissingCiFlag() {
		return snowIncU_MissingCiFlag;
	}

	public void setSnowIncU_MissingCiFlag(String snowIncU_MissingCiFlag) {
		this.snowIncU_MissingCiFlag = snowIncU_MissingCiFlag;
	}

	public String getSnowIncU_ModifiedPeriod() {
		return snowIncU_ModifiedPeriod;
	}

	public void setSnowIncU_ModifiedPeriod(String snowIncU_ModifiedPeriod) {
		this.snowIncU_ModifiedPeriod = snowIncU_ModifiedPeriod;
	}

	public String getSnowIncU_MultipleCountrySspDashboa() {
		return snowIncU_MultipleCountrySspDashboa;
	}

	public void setSnowIncU_MultipleCountrySspDashboa(String snowIncU_MultipleCountrySspDashboa) {
		this.snowIncU_MultipleCountrySspDashboa = snowIncU_MultipleCountrySspDashboa;
	}

	public String getSnowIncU_Name() {
		return snowIncU_Name;
	}

	public void setSnowIncU_Name(String snowIncU_Name) {
		this.snowIncU_Name = snowIncU_Name;
	}

	public String getSnowIncU_NewDate() {
		return snowIncU_NewDate;
	}

	public void setSnowIncU_NewDate(String snowIncU_NewDate) {
		this.snowIncU_NewDate = snowIncU_NewDate;
	}

	public String getSnowIncU_NextAssignment() {
		return snowIncU_NextAssignment;
	}

	public void setSnowIncU_NextAssignment(String snowIncU_NextAssignment) {
		this.snowIncU_NextAssignment = snowIncU_NextAssignment;
	}

	public String getSnowIncU_Now92Sites() {
		return snowIncU_Now92Sites;
	}

	public void setSnowIncU_Now92Sites(String snowIncU_Now92Sites) {
		this.snowIncU_Now92Sites = snowIncU_Now92Sites;
	}

	public String getSnowIncU_OlaTaskName() {
		return snowIncU_OlaTaskName;
	}

	public void setSnowIncU_OlaTaskName(String snowIncU_OlaTaskName) {
		this.snowIncU_OlaTaskName = snowIncU_OlaTaskName;
	}

	public String getSnowIncU_OpenedPeriod() {
		return snowIncU_OpenedPeriod;
	}

	public void setSnowIncU_OpenedPeriod(String snowIncU_OpenedPeriod) {
		this.snowIncU_OpenedPeriod = snowIncU_OpenedPeriod;
	}

	public String getSnowIncU_OperatingUnit() {
		return snowIncU_OperatingUnit;
	}

	public void setSnowIncU_OperatingUnit(String snowIncU_OperatingUnit) {
		this.snowIncU_OperatingUnit = snowIncU_OperatingUnit;
	}

	public String getSnowIncU_OutageDuration() {
		return snowIncU_OutageDuration;
	}

	public void setSnowIncU_OutageDuration(String snowIncU_OutageDuration) {
		this.snowIncU_OutageDuration = snowIncU_OutageDuration;
	}

	public String getSnowIncU_OutsourceAssignedOut() {
		return snowIncU_OutsourceAssignedOut;
	}

	public void setSnowIncU_OutsourceAssignedOut(String snowIncU_OutsourceAssignedOut) {
		this.snowIncU_OutsourceAssignedOut = snowIncU_OutsourceAssignedOut;
	}

	public String getSnowIncU_OutsourceAssignee() {
		return snowIncU_OutsourceAssignee;
	}

	public void setSnowIncU_OutsourceAssignee(String snowIncU_OutsourceAssignee) {
		this.snowIncU_OutsourceAssignee = snowIncU_OutsourceAssignee;
	}

	public String getSnowIncU_OutsourceId() {
		return snowIncU_OutsourceId;
	}

	public void setSnowIncU_OutsourceId(String snowIncU_OutsourceId) {
		this.snowIncU_OutsourceId = snowIncU_OutsourceId;
	}

	public String getSnowIncU_OutsourceIntegration() {
		return snowIncU_OutsourceIntegration;
	}

	public void setSnowIncU_OutsourceIntegration(String snowIncU_OutsourceIntegration) {
		this.snowIncU_OutsourceIntegration = snowIncU_OutsourceIntegration;
	}

	public String getSnowIncU_OutsourceModule() {
		return snowIncU_OutsourceModule;
	}

	public void setSnowIncU_OutsourceModule(String snowIncU_OutsourceModule) {
		this.snowIncU_OutsourceModule = snowIncU_OutsourceModule;
	}

	public String getSnowIncU_OutsourceResponse() {
		return snowIncU_OutsourceResponse;
	}

	public void setSnowIncU_OutsourceResponse(String snowIncU_OutsourceResponse) {
		this.snowIncU_OutsourceResponse = snowIncU_OutsourceResponse;
	}

	public String getSnowIncU_OutsourceResult() {
		return snowIncU_OutsourceResult;
	}

	public void setSnowIncU_OutsourceResult(String snowIncU_OutsourceResult) {
		this.snowIncU_OutsourceResult = snowIncU_OutsourceResult;
	}

	public String getSnowIncU_OutsourceStatus() {
		return snowIncU_OutsourceStatus;
	}

	public void setSnowIncU_OutsourceStatus(String snowIncU_OutsourceStatus) {
		this.snowIncU_OutsourceStatus = snowIncU_OutsourceStatus;
	}

	public String getSnowIncU_OutsourceTeam() {
		return snowIncU_OutsourceTeam;
	}

	public void setSnowIncU_OutsourceTeam(String snowIncU_OutsourceTeam) {
		this.snowIncU_OutsourceTeam = snowIncU_OutsourceTeam;
	}

	public String getSnowIncU_Override1() {
		return snowIncU_Override1;
	}

	public void setSnowIncU_Override1(String snowIncU_Override1) {
		this.snowIncU_Override1 = snowIncU_Override1;
	}

	public String getSnowIncU_ParentIncident() {
		return snowIncU_ParentIncident;
	}

	public void setSnowIncU_ParentIncident(String snowIncU_ParentIncident) {
		this.snowIncU_ParentIncident = snowIncU_ParentIncident;
	}

	public String getSnowIncU_PendingReason() {
		return snowIncU_PendingReason;
	}

	public void setSnowIncU_PendingReason(String snowIncU_PendingReason) {
		this.snowIncU_PendingReason = snowIncU_PendingReason;
	}

	public String getSnowIncU_Person() {
		return snowIncU_Person;
	}

	public void setSnowIncU_Person(String snowIncU_Person) {
		this.snowIncU_Person = snowIncU_Person;
	}

	public String getSnowIncU_PersonAudited() {
		return snowIncU_PersonAudited;
	}

	public void setSnowIncU_PersonAudited(String snowIncU_PersonAudited) {
		this.snowIncU_PersonAudited = snowIncU_PersonAudited;
	}

	public String getSnowIncU_PersonAuditing() {
		return snowIncU_PersonAuditing;
	}

	public void setSnowIncU_PersonAuditing(String snowIncU_PersonAuditing) {
		this.snowIncU_PersonAuditing = snowIncU_PersonAuditing;
	}

	public String getSnowIncU_Phone() {
		return snowIncU_Phone;
	}

	public void setSnowIncU_Phone(String snowIncU_Phone) {
		this.snowIncU_Phone = snowIncU_Phone;
	}

	public String getSnowIncU_PickupDuration() {
		return snowIncU_PickupDuration;
	}

	public void setSnowIncU_PickupDuration(String snowIncU_PickupDuration) {
		this.snowIncU_PickupDuration = snowIncU_PickupDuration;
	}

	public String getSnowIncU_PlannedEffort() {
		return snowIncU_PlannedEffort;
	}

	public void setSnowIncU_PlannedEffort(String snowIncU_PlannedEffort) {
		this.snowIncU_PlannedEffort = snowIncU_PlannedEffort;
	}

	public String getSnowIncU_PlannedImplementationWeek() {
		return snowIncU_PlannedImplementationWeek;
	}

	public void setSnowIncU_PlannedImplementationWeek(String snowIncU_PlannedImplementationWeek) {
		this.snowIncU_PlannedImplementationWeek = snowIncU_PlannedImplementationWeek;
	}

	public String getSnowIncU_PnetHpEbond() {
		return snowIncU_PnetHpEbond;
	}

	public void setSnowIncU_PnetHpEbond(String snowIncU_PnetHpEbond) {
		this.snowIncU_PnetHpEbond = snowIncU_PnetHpEbond;
	}

	public String getSnowIncU_PreviousGroup() {
		return snowIncU_PreviousGroup;
	}

	public void setSnowIncU_PreviousGroup(String snowIncU_PreviousGroup) {
		this.snowIncU_PreviousGroup = snowIncU_PreviousGroup;
	}

	public String getSnowIncU_PreviousHpWorkgroup() {
		return snowIncU_PreviousHpWorkgroup;
	}

	public void setSnowIncU_PreviousHpWorkgroup(String snowIncU_PreviousHpWorkgroup) {
		this.snowIncU_PreviousHpWorkgroup = snowIncU_PreviousHpWorkgroup;
	}

	public String getSnowIncU_PreviousStatus() {
		return snowIncU_PreviousStatus;
	}

	public void setSnowIncU_PreviousStatus(String snowIncU_PreviousStatus) {
		this.snowIncU_PreviousStatus = snowIncU_PreviousStatus;
	}

	public String getSnowIncU_QueryCount() {
		return snowIncU_QueryCount;
	}

	public void setSnowIncU_QueryCount(String snowIncU_QueryCount) {
		this.snowIncU_QueryCount = snowIncU_QueryCount;
	}

	public String getSnowIncU_RegionImpacted() {
		return snowIncU_RegionImpacted;
	}

	public void setSnowIncU_RegionImpacted(String snowIncU_RegionImpacted) {
		this.snowIncU_RegionImpacted = snowIncU_RegionImpacted;
	}

	public String getSnowIncU_RejectionCount() {
		return snowIncU_RejectionCount;
	}

	public void setSnowIncU_RejectionCount(String snowIncU_RejectionCount) {
		this.snowIncU_RejectionCount = snowIncU_RejectionCount;
	}

	public String getSnowIncU_RelatedIncidents() {
		return snowIncU_RelatedIncidents;
	}

	public void setSnowIncU_RelatedIncidents(String snowIncU_RelatedIncidents) {
		this.snowIncU_RelatedIncidents = snowIncU_RelatedIncidents;
	}

	public String getSnowIncU_RelatedRequest() {
		return snowIncU_RelatedRequest;
	}

	public void setSnowIncU_RelatedRequest(String snowIncU_RelatedRequest) {
		this.snowIncU_RelatedRequest = snowIncU_RelatedRequest;
	}

	public String getSnowIncU_ReopenCount() {
		return snowIncU_ReopenCount;
	}

	public void setSnowIncU_ReopenCount(String snowIncU_ReopenCount) {
		this.snowIncU_ReopenCount = snowIncU_ReopenCount;
	}

	public String getSnowIncU_ReopenedDate() {
		return snowIncU_ReopenedDate;
	}

	public void setSnowIncU_ReopenedDate(String snowIncU_ReopenedDate) {
		this.snowIncU_ReopenedDate = snowIncU_ReopenedDate;
	}

	public String getSnowIncU_RepeatIncident() {
		return snowIncU_RepeatIncident;
	}

	public void setSnowIncU_RepeatIncident(String snowIncU_RepeatIncident) {
		this.snowIncU_RepeatIncident = snowIncU_RepeatIncident;
	}

	public String getSnowIncU_ResolutionOverride() {
		return snowIncU_ResolutionOverride;
	}

	public void setSnowIncU_ResolutionOverride(String snowIncU_ResolutionOverride) {
		this.snowIncU_ResolutionOverride = snowIncU_ResolutionOverride;
	}

	public String getSnowIncU_ResolutionReason() {
		return snowIncU_ResolutionReason;
	}

	public void setSnowIncU_ResolutionReason(String snowIncU_ResolutionReason) {
		this.snowIncU_ResolutionReason = snowIncU_ResolutionReason;
	}

	public String getSnowIncU_ResolutionType() {
		return snowIncU_ResolutionType;
	}

	public void setSnowIncU_ResolutionType(String snowIncU_ResolutionType) {
		this.snowIncU_ResolutionType = snowIncU_ResolutionType;
	}

	public String getSnowIncU_ResolvedBy() {
		return snowIncU_ResolvedBy;
	}

	public void setSnowIncU_ResolvedBy(String snowIncU_ResolvedBy) {
		this.snowIncU_ResolvedBy = snowIncU_ResolvedBy;
	}

	public String getSnowIncU_ResolvedByWorkgroup() {
		return snowIncU_ResolvedByWorkgroup;
	}

	public void setSnowIncU_ResolvedByWorkgroup(String snowIncU_ResolvedByWorkgroup) {
		this.snowIncU_ResolvedByWorkgroup = snowIncU_ResolvedByWorkgroup;
	}

	public String getSnowIncU_Resolver() {
		return snowIncU_Resolver;
	}

	public void setSnowIncU_Resolver(String snowIncU_Resolver) {
		this.snowIncU_Resolver = snowIncU_Resolver;
	}

	public String getSnowIncU_ResponseFlag() {
		return snowIncU_ResponseFlag;
	}

	public void setSnowIncU_ResponseFlag(String snowIncU_ResponseFlag) {
		this.snowIncU_ResponseFlag = snowIncU_ResponseFlag;
	}

	public String getSnowIncU_ResponseOverride() {
		return snowIncU_ResponseOverride;
	}

	public void setSnowIncU_ResponseOverride(String snowIncU_ResponseOverride) {
		this.snowIncU_ResponseOverride = snowIncU_ResponseOverride;
	}

	public String getSnowIncU_ResponseReason() {
		return snowIncU_ResponseReason;
	}

	public void setSnowIncU_ResponseReason(String snowIncU_ResponseReason) {
		this.snowIncU_ResponseReason = snowIncU_ResponseReason;
	}

	public String getSnowIncU_SavedCount() {
		return snowIncU_SavedCount;
	}

	public void setSnowIncU_SavedCount(String snowIncU_SavedCount) {
		this.snowIncU_SavedCount = snowIncU_SavedCount;
	}

	public String getSnowIncU_SdOlaPause() {
		return snowIncU_SdOlaPause;
	}

	public void setSnowIncU_SdOlaPause(String snowIncU_SdOlaPause) {
		this.snowIncU_SdOlaPause = snowIncU_SdOlaPause;
	}

	public String getSnowIncU_SecondDeadline() {
		return snowIncU_SecondDeadline;
	}

	public void setSnowIncU_SecondDeadline(String snowIncU_SecondDeadline) {
		this.snowIncU_SecondDeadline = snowIncU_SecondDeadline;
	}

	public String getSnowIncU_SelectApplication() {
		return snowIncU_SelectApplication;
	}

	public void setSnowIncU_SelectApplication(String snowIncU_SelectApplication) {
		this.snowIncU_SelectApplication = snowIncU_SelectApplication;
	}

	public String getSnowIncU_SelectEuc() {
		return snowIncU_SelectEuc;
	}

	public void setSnowIncU_SelectEuc(String snowIncU_SelectEuc) {
		this.snowIncU_SelectEuc = snowIncU_SelectEuc;
	}

	public String getSnowIncU_SelectInfrastructure() {
		return snowIncU_SelectInfrastructure;
	}

	public void setSnowIncU_SelectInfrastructure(String snowIncU_SelectInfrastructure) {
		this.snowIncU_SelectInfrastructure = snowIncU_SelectInfrastructure;
	}

	public String getSnowIncU_SelectNetwork() {
		return snowIncU_SelectNetwork;
	}

	public void setSnowIncU_SelectNetwork(String snowIncU_SelectNetwork) {
		this.snowIncU_SelectNetwork = snowIncU_SelectNetwork;
	}

	public String getSnowIncU_ServiceImpactPct() {
		return snowIncU_ServiceImpactPct;
	}

	public void setSnowIncU_ServiceImpactPct(String snowIncU_ServiceImpactPct) {
		this.snowIncU_ServiceImpactPct = snowIncU_ServiceImpactPct;
	}

	public String getSnowIncU_ServiceState() {
		return snowIncU_ServiceState;
	}

	public void setSnowIncU_ServiceState(String snowIncU_ServiceState) {
		this.snowIncU_ServiceState = snowIncU_ServiceState;
	}

	public String getSnowIncU_SitesAffected() {
		return snowIncU_SitesAffected;
	}

	public void setSnowIncU_SitesAffected(String snowIncU_SitesAffected) {
		this.snowIncU_SitesAffected = snowIncU_SitesAffected;
	}

	public String getSnowIncU_SlaFailureWorkgroup() {
		return snowIncU_SlaFailureWorkgroup;
	}

	public void setSnowIncU_SlaFailureWorkgroup(String snowIncU_SlaFailureWorkgroup) {
		this.snowIncU_SlaFailureWorkgroup = snowIncU_SlaFailureWorkgroup;
	}

	public String getSnowIncU_SlaState() {
		return snowIncU_SlaState;
	}

	public void setSnowIncU_SlaState(String snowIncU_SlaState) {
		this.snowIncU_SlaState = snowIncU_SlaState;
	}

	public String getSnowIncU_SlfApprover() {
		return snowIncU_SlfApprover;
	}

	public void setSnowIncU_SlfApprover(String snowIncU_SlfApprover) {
		this.snowIncU_SlfApprover = snowIncU_SlfApprover;
	}

	public String getSnowIncU_SlfComponent() {
		return snowIncU_SlfComponent;
	}

	public void setSnowIncU_SlfComponent(String snowIncU_SlfComponent) {
		this.snowIncU_SlfComponent = snowIncU_SlfComponent;
	}

	public String getSnowIncU_SlfReason() {
		return snowIncU_SlfReason;
	}

	public void setSnowIncU_SlfReason(String snowIncU_SlfReason) {
		this.snowIncU_SlfReason = snowIncU_SlfReason;
	}

	public String getSnowIncU_SlfReviewDate() {
		return snowIncU_SlfReviewDate;
	}

	public void setSnowIncU_SlfReviewDate(String snowIncU_SlfReviewDate) {
		this.snowIncU_SlfReviewDate = snowIncU_SlfReviewDate;
	}

	public String getSnowIncU_SmsGroup() {
		return snowIncU_SmsGroup;
	}

	public void setSnowIncU_SmsGroup(String snowIncU_SmsGroup) {
		this.snowIncU_SmsGroup = snowIncU_SmsGroup;
	}

	public String getSnowIncU_SmsMessage() {
		return snowIncU_SmsMessage;
	}

	public void setSnowIncU_SmsMessage(String snowIncU_SmsMessage) {
		this.snowIncU_SmsMessage = snowIncU_SmsMessage;
	}

	public String getSnowIncU_SmsTemplate() {
		return snowIncU_SmsTemplate;
	}

	public void setSnowIncU_SmsTemplate(String snowIncU_SmsTemplate) {
		this.snowIncU_SmsTemplate = snowIncU_SmsTemplate;
	}

	public String getSnowIncU_SourceId() {
		return snowIncU_SourceId;
	}

	public void setSnowIncU_SourceId(String snowIncU_SourceId) {
		this.snowIncU_SourceId = snowIncU_SourceId;
	}

	public String getSnowIncU_SrtFail() {
		return snowIncU_SrtFail;
	}

	public void setSnowIncU_SrtFail(String snowIncU_SrtFail) {
		this.snowIncU_SrtFail = snowIncU_SrtFail;
	}

	public String getSnowIncU_SrtPass() {
		return snowIncU_SrtPass;
	}

	public void setSnowIncU_SrtPass(String snowIncU_SrtPass) {
		this.snowIncU_SrtPass = snowIncU_SrtPass;
	}

	public String getSnowIncU_SrtState() {
		return snowIncU_SrtState;
	}

	public void setSnowIncU_SrtState(String snowIncU_SrtState) {
		this.snowIncU_SrtState = snowIncU_SrtState;
	}

	public String getSnowIncU_SspAffected() {
		return snowIncU_SspAffected;
	}

	public void setSnowIncU_SspAffected(String snowIncU_SspAffected) {
		this.snowIncU_SspAffected = snowIncU_SspAffected;
	}

	public String getSnowIncU_SspDashboard() {
		return snowIncU_SspDashboard;
	}

	public void setSnowIncU_SspDashboard(String snowIncU_SspDashboard) {
		this.snowIncU_SspDashboard = snowIncU_SspDashboard;
	}

	public String getSnowIncU_SspDashboardLocalIs() {
		return snowIncU_SspDashboardLocalIs;
	}

	public void setSnowIncU_SspDashboardLocalIs(String snowIncU_SspDashboardLocalIs) {
		this.snowIncU_SspDashboardLocalIs = snowIncU_SspDashboardLocalIs;
	}

	public String getSnowIncU_SspDashboardLocal() {
		return snowIncU_SspDashboardLocal;
	}

	public void setSnowIncU_SspDashboardLocal(String snowIncU_SspDashboardLocal) {
		this.snowIncU_SspDashboardLocal = snowIncU_SspDashboardLocal;
	}

	public String getSnowIncU_SspForm() {
		return snowIncU_SspForm;
	}

	public void setSnowIncU_SspForm(String snowIncU_SspForm) {
		this.snowIncU_SspForm = snowIncU_SspForm;
	}

	public String getSnowIncU_Subject() {
		return snowIncU_Subject;
	}

	public void setSnowIncU_Subject(String snowIncU_Subject) {
		this.snowIncU_Subject = snowIncU_Subject;
	}

	public String getSnowIncU_SupportStructure() {
		return snowIncU_SupportStructure;
	}

	public void setSnowIncU_SupportStructure(String snowIncU_SupportStructure) {
		this.snowIncU_SupportStructure = snowIncU_SupportStructure;
	}

	public String getSnowIncU_SupportType() {
		return snowIncU_SupportType;
	}

	public void setSnowIncU_SupportType(String snowIncU_SupportType) {
		this.snowIncU_SupportType = snowIncU_SupportType;
	}

	public String getSnowIncU_SuspendOffTime() {
		return snowIncU_SuspendOffTime;
	}

	public void setSnowIncU_SuspendOffTime(String snowIncU_SuspendOffTime) {
		this.snowIncU_SuspendOffTime = snowIncU_SuspendOffTime;
	}

	public String getSnowIncU_TaskType() {
		return snowIncU_TaskType;
	}

	public void setSnowIncU_TaskType(String snowIncU_TaskType) {
		this.snowIncU_TaskType = snowIncU_TaskType;
	}

	public String getSnowIncU_Template() {
		return snowIncU_Template;
	}

	public void setSnowIncU_Template(String snowIncU_Template) {
		this.snowIncU_Template = snowIncU_Template;
	}

	public String getSnowIncU_ThirdLineComments() {
		return snowIncU_ThirdLineComments;
	}

	public void setSnowIncU_ThirdLineComments(String snowIncU_ThirdLineComments) {
		this.snowIncU_ThirdLineComments = snowIncU_ThirdLineComments;
	}

	public String getSnowIncU_ThirdLineDate() {
		return snowIncU_ThirdLineDate;
	}

	public void setSnowIncU_ThirdLineDate(String snowIncU_ThirdLineDate) {
		this.snowIncU_ThirdLineDate = snowIncU_ThirdLineDate;
	}

	public String getSnowIncU_ThirdPartyReference() {
		return snowIncU_ThirdPartyReference;
	}

	public void setSnowIncU_ThirdPartyReference(String snowIncU_ThirdPartyReference) {
		this.snowIncU_ThirdPartyReference = snowIncU_ThirdPartyReference;
	}

	public String getSnowIncU_TimeToAuth() {
		return snowIncU_TimeToAuth;
	}

	public void setSnowIncU_TimeToAuth(String snowIncU_TimeToAuth) {
		this.snowIncU_TimeToAuth = snowIncU_TimeToAuth;
	}

	public String getSnowIncU_TimeToClose() {
		return snowIncU_TimeToClose;
	}

	public void setSnowIncU_TimeToClose(String snowIncU_TimeToClose) {
		this.snowIncU_TimeToClose = snowIncU_TimeToClose;
	}

	public String getSnowIncU_TntSiteType() {
		return snowIncU_TntSiteType;
	}

	public void setSnowIncU_TntSiteType(String snowIncU_TntSiteType) {
		this.snowIncU_TntSiteType = snowIncU_TntSiteType;
	}

	public String getSnowIncU_Triaged() {
		return snowIncU_Triaged;
	}

	public void setSnowIncU_Triaged(String snowIncU_Triaged) {
		this.snowIncU_Triaged = snowIncU_Triaged;
	}

	public String getSnowIncU_UnderOla() {
		return snowIncU_UnderOla;
	}

	public void setSnowIncU_UnderOla(String snowIncU_UnderOla) {
		this.snowIncU_UnderOla = snowIncU_UnderOla;
	}

	public String getSnowIncU_UsersAffected() {
		return snowIncU_UsersAffected;
	}

	public void setSnowIncU_UsersAffected(String snowIncU_UsersAffected) {
		this.snowIncU_UsersAffected = snowIncU_UsersAffected;
	}

	public String getSnowIncU_VerrizonOutage() {
		return snowIncU_VerrizonOutage;
	}

	public void setSnowIncU_VerrizonOutage(String snowIncU_VerrizonOutage) {
		this.snowIncU_VerrizonOutage = snowIncU_VerrizonOutage;
	}

	public String getSnowIncU_VzCorrelationId() {
		return snowIncU_VzCorrelationId;
	}

	public void setSnowIncU_VzCorrelationId(String snowIncU_VzCorrelationId) {
		this.snowIncU_VzCorrelationId = snowIncU_VzCorrelationId;
	}

	public String getSnowIncU_VzSequenceNumber() {
		return snowIncU_VzSequenceNumber;
	}

	public void setSnowIncU_VzSequenceNumber(String snowIncU_VzSequenceNumber) {
		this.snowIncU_VzSequenceNumber = snowIncU_VzSequenceNumber;
	}

	public String getSnowIncU_WebId() {
		return snowIncU_WebId;
	}

	public void setSnowIncU_WebId(String snowIncU_WebId) {
		this.snowIncU_WebId = snowIncU_WebId;
	}

	public String getSnowIncU_WebUpdate() {
		return snowIncU_WebUpdate;
	}

	public void setSnowIncU_WebUpdate(String snowIncU_WebUpdate) {
		this.snowIncU_WebUpdate = snowIncU_WebUpdate;
	}

	public String getSnowIncU_WiproId() {
		return snowIncU_WiproId;
	}

	public void setSnowIncU_WiproId(String snowIncU_WiproId) {
		this.snowIncU_WiproId = snowIncU_WiproId;
	}

	public String getSnowIncU_WorkgroupsCalledOut() {
		return snowIncU_WorkgroupsCalledOut;
	}

	public void setSnowIncU_WorkgroupsCalledOut(String snowIncU_WorkgroupsCalledOut) {
		this.snowIncU_WorkgroupsCalledOut = snowIncU_WorkgroupsCalledOut;
	}

	public String getSnowIncUponApproval() {
		return snowIncUponApproval;
	}

	public void setSnowIncUponApproval(String snowIncUponApproval) {
		this.snowIncUponApproval = snowIncUponApproval;
	}

	public String getSnowIncUponReject() {
		return snowIncUponReject;
	}

	public void setSnowIncUponReject(String snowIncUponReject) {
		this.snowIncUponReject = snowIncUponReject;
	}

	public String getSnowIncUrgency() {
		return snowIncUrgency;
	}

	public void setSnowIncUrgency(String snowIncUrgency) {
		this.snowIncUrgency = snowIncUrgency;
	}

	public String getSnowIncUserInput() {
		return snowIncUserInput;
	}

	public void setSnowIncUserInput(String snowIncUserInput) {
		this.snowIncUserInput = snowIncUserInput;
	}

	public String getSnowIncVzReleaseForTest() {
		return snowIncVzReleaseForTest;
	}

	public void setSnowIncVzReleaseForTest(String snowIncVzReleaseForTest) {
		this.snowIncVzReleaseForTest = snowIncVzReleaseForTest;
	}

	public String getSnowIncVzReleaseForTestDatetime() {
		return snowIncVzReleaseForTestDatetime;
	}

	public void setSnowIncVzReleaseForTestDatetime(String snowIncVzReleaseForTestDatetime) {
		this.snowIncVzReleaseForTestDatetime = snowIncVzReleaseForTestDatetime;
	}

	public String getSnowIncWatchList() {
		return snowIncWatchList;
	}

	public void setSnowIncWatchList(String snowIncWatchList) {
		this.snowIncWatchList = snowIncWatchList;
	}

	public String getSnowIncWfActivity() {
		return snowIncWfActivity;
	}

	public void setSnowIncWfActivity(String snowIncWfActivity) {
		this.snowIncWfActivity = snowIncWfActivity;
	}

	public String getSnowIncWorkEffort() {
		return snowIncWorkEffort;
	}

	public void setSnowIncWorkEffort(String snowIncWorkEffort) {
		this.snowIncWorkEffort = snowIncWorkEffort;
	}

	public String getSnowIncWorkEnd() {
		return snowIncWorkEnd;
	}

	public void setSnowIncWorkEnd(String snowIncWorkEnd) {
		this.snowIncWorkEnd = snowIncWorkEnd;
	}

	public String getSnowIncWorkNotes() {
		return snowIncWorkNotes;
	}

	public void setSnowIncWorkNotes(String snowIncWorkNotes) {
		this.snowIncWorkNotes = snowIncWorkNotes;
	}

	public String getSnowIncWorkStart() {
		return snowIncWorkStart;
	}

	public void setSnowIncWorkStart(String snowIncWorkStart) {
		this.snowIncWorkStart = snowIncWorkStart;
	}

	public String getSnowTaskslatableActive() {
		return snowTaskslatableActive;
	}

	public void setSnowTaskslatableActive(String snowTaskslatableActive) {
		this.snowTaskslatableActive = snowTaskslatableActive;
	}

	public String getSnowTaskslatableBusinessDuration() {
		return snowTaskslatableBusinessDuration;
	}

	public void setSnowTaskslatableBusinessDuration(String snowTaskslatableBusinessDuration) {
		this.snowTaskslatableBusinessDuration = snowTaskslatableBusinessDuration;
	}

	public String getSnowTaskslatableBusinessPauseDuration() {
		return snowTaskslatableBusinessPauseDuration;
	}

	public void setSnowTaskslatableBusinessPauseDuration(String snowTaskslatableBusinessPauseDuration) {
		this.snowTaskslatableBusinessPauseDuration = snowTaskslatableBusinessPauseDuration;
	}

	public String getSnowTaskslatableBusinessPercentage() {
		return snowTaskslatableBusinessPercentage;
	}

	public void setSnowTaskslatableBusinessPercentage(String snowTaskslatableBusinessPercentage) {
		this.snowTaskslatableBusinessPercentage = snowTaskslatableBusinessPercentage;
	}

	public String getSnowTaskslatableBusinessTimeLeft() {
		return snowTaskslatableBusinessTimeLeft;
	}

	public void setSnowTaskslatableBusinessTimeLeft(String snowTaskslatableBusinessTimeLeft) {
		this.snowTaskslatableBusinessTimeLeft = snowTaskslatableBusinessTimeLeft;
	}

	public String getSnowTaskslatableDuration() {
		return snowTaskslatableDuration;
	}

	public void setSnowTaskslatableDuration(String snowTaskslatableDuration) {
		this.snowTaskslatableDuration = snowTaskslatableDuration;
	}

	public String getSnowTaskslatableEndTime() {
		return snowTaskslatableEndTime;
	}

	public void setSnowTaskslatableEndTime(String snowTaskslatableEndTime) {
		this.snowTaskslatableEndTime = snowTaskslatableEndTime;
	}

	public String getSnowTaskslatableHasBreached() {
		return snowTaskslatableHasBreached;
	}

	public void setSnowTaskslatableHasBreached(String snowTaskslatableHasBreached) {
		this.snowTaskslatableHasBreached = snowTaskslatableHasBreached;
	}

	public String getSnowTaskslatableOriginalBreachTime() {
		return snowTaskslatableOriginalBreachTime;
	}

	public void setSnowTaskslatableOriginalBreachTime(String snowTaskslatableOriginalBreachTime) {
		this.snowTaskslatableOriginalBreachTime = snowTaskslatableOriginalBreachTime;
	}

	public String getSnowTaskslatablePauseDuration() {
		return snowTaskslatablePauseDuration;
	}

	public void setSnowTaskslatablePauseDuration(String snowTaskslatablePauseDuration) {
		this.snowTaskslatablePauseDuration = snowTaskslatablePauseDuration;
	}

	public String getSnowTaskslatablePauseTime() {
		return snowTaskslatablePauseTime;
	}

	public void setSnowTaskslatablePauseTime(String snowTaskslatablePauseTime) {
		this.snowTaskslatablePauseTime = snowTaskslatablePauseTime;
	}

	public String getSnowTaskslatablePercentage() {
		return snowTaskslatablePercentage;
	}

	public void setSnowTaskslatablePercentage(String snowTaskslatablePercentage) {
		this.snowTaskslatablePercentage = snowTaskslatablePercentage;
	}

	public String getSnowTaskslatablePlannedEndTime() {
		return snowTaskslatablePlannedEndTime;
	}

	public void setSnowTaskslatablePlannedEndTime(String snowTaskslatablePlannedEndTime) {
		this.snowTaskslatablePlannedEndTime = snowTaskslatablePlannedEndTime;
	}

	public String getSnowTaskslatableSchedule() {
		return snowTaskslatableSchedule;
	}

	public void setSnowTaskslatableSchedule(String snowTaskslatableSchedule) {
		this.snowTaskslatableSchedule = snowTaskslatableSchedule;
	}

	public String getSnowTaskslatableSla() {
		return snowTaskslatableSla;
	}

	public void setSnowTaskslatableSla(String snowTaskslatableSla) {
		this.snowTaskslatableSla = snowTaskslatableSla;
	}

	public String getSnowTaskslatableStage() {
		return snowTaskslatableStage;
	}

	public void setSnowTaskslatableStage(String snowTaskslatableStage) {
		this.snowTaskslatableStage = snowTaskslatableStage;
	}

	public String getSnowTaskslatableStartTime() {
		return snowTaskslatableStartTime;
	}

	public void setSnowTaskslatableStartTime(String snowTaskslatableStartTime) {
		this.snowTaskslatableStartTime = snowTaskslatableStartTime;
	}

	public String getSnowTaskslatableSysCreatedBy() {
		return snowTaskslatableSysCreatedBy;
	}

	public void setSnowTaskslatableSysCreatedBy(String snowTaskslatableSysCreatedBy) {
		this.snowTaskslatableSysCreatedBy = snowTaskslatableSysCreatedBy;
	}

	public String getSnowTaskslatableSysCreatedOn() {
		return snowTaskslatableSysCreatedOn;
	}

	public void setSnowTaskslatableSysCreatedOn(String snowTaskslatableSysCreatedOn) {
		this.snowTaskslatableSysCreatedOn = snowTaskslatableSysCreatedOn;
	}

	public String getSnowTaskslatableSysId() {
		return snowTaskslatableSysId;
	}

	public void setSnowTaskslatableSysId(String snowTaskslatableSysId) {
		this.snowTaskslatableSysId = snowTaskslatableSysId;
	}

	public String getSnowTaskslatableSysModCount() {
		return snowTaskslatableSysModCount;
	}

	public void setSnowTaskslatableSysModCount(String snowTaskslatableSysModCount) {
		this.snowTaskslatableSysModCount = snowTaskslatableSysModCount;
	}

	public String getSnowTaskslatableSysTags() {
		return snowTaskslatableSysTags;
	}

	public void setSnowTaskslatableSysTags(String snowTaskslatableSysTags) {
		this.snowTaskslatableSysTags = snowTaskslatableSysTags;
	}

	public String getSnowTaskslatableSysUpdatedBy() {
		return snowTaskslatableSysUpdatedBy;
	}

	public void setSnowTaskslatableSysUpdatedBy(String snowTaskslatableSysUpdatedBy) {
		this.snowTaskslatableSysUpdatedBy = snowTaskslatableSysUpdatedBy;
	}

	public String getSnowTaskslatableSysUpdatedOn() {
		return snowTaskslatableSysUpdatedOn;
	}

	public void setSnowTaskslatableSysUpdatedOn(String snowTaskslatableSysUpdatedOn) {
		this.snowTaskslatableSysUpdatedOn = snowTaskslatableSysUpdatedOn;
	}

	public String getSnowTaskslatableTask() {
		return snowTaskslatableTask;
	}

	public void setSnowTaskslatableTask(String snowTaskslatableTask) {
		this.snowTaskslatableTask = snowTaskslatableTask;
	}

	public String getSnowTaskslatableTimeLeft() {
		return snowTaskslatableTimeLeft;
	}

	public void setSnowTaskslatableTimeLeft(String snowTaskslatableTimeLeft) {
		this.snowTaskslatableTimeLeft = snowTaskslatableTimeLeft;
	}

	public String getSnowTaskslatableTimezone() {
		return snowTaskslatableTimezone;
	}

	public void setSnowTaskslatableTimezone(String snowTaskslatableTimezone) {
		this.snowTaskslatableTimezone = snowTaskslatableTimezone;
	}

	public String getSnowTaskslatableU_InScope() {
		return snowTaskslatableU_InScope;
	}

	public void setSnowTaskslatableU_InScope(String snowTaskslatableU_InScope) {
		this.snowTaskslatableU_InScope = snowTaskslatableU_InScope;
	}

	public String getSnowTaskslatableU_KbArticle() {
		return snowTaskslatableU_KbArticle;
	}

	public void setSnowTaskslatableU_KbArticle(String snowTaskslatableU_KbArticle) {
		this.snowTaskslatableU_KbArticle = snowTaskslatableU_KbArticle;
	}

}
