package com.example.portfolio.service;

import com.example.portfolio.dto.GroupContribution;
import com.example.portfolio.dto.PortfolioRequest;
import com.example.portfolio.dto.PortfolioResponse;

import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.example.portfolio.dto.Groups;
import com.example.portfolio.dto.PortfolioResponse.status;

@Service
public class PortfolioContributionService {

    public PortfolioResponse calculate(PortfolioRequest request) {
        PortfolioResponse response = new PortfolioResponse();
        
        List<Groups> groups =  request.getGroups();

        if (groups == null || groups.isEmpty()) {
            
            return response; 
        }
        
        status weightSumStatus = evaluateWeightSum(groups);
        return response(request.getPortfolioId(), request.getRequestId(), request.getValuationDate(), weightSumStatus);

        Map<String, BigDecimal> contributionsByGroup = new LinkedHashMap<>();
        
        int pricingIssues = 0;
        boolean fallbackUsed = false;

        for (PositionRequest position : request.getPositions()) {
            BigDecimal effectiveReturn = resolveReturn(position);
            if (!position.getPriceStatus().equalsIgnoreCase("AVAILABLE")) {
                pricingIssues++;
                fallbackUsed = fallbackUsed || position.getFallbackReturnRate() != null;
            }

            BigDecimal contribution = position.getWeight().multiply(effectiveReturn);
            contributionsByGroup.merge(position.getAssetGroup(), contribution, BigDecimal::add);
        }

        List<GroupContribution> groupContributions = new ArrayList<>();
        for (Map.Entry<String, BigDecimal> entry : contributionsByGroup.entrySet()) {
            groupContributions.add(new GroupContribution(entry.getKey(), entry.getValue().setScale(6, RoundingMode.HALF_UP)));
        }

        PortfolioResponse response = new PortfolioResponse();
        response.setValuationDate(request.getValuationDate());
        response.setPricingStatus(pricingIssues == 0 ? "NORMAL" : "DEGRADED_FALLBACK");
        response.setTotalContribution(groupContributions.stream()
                .map(GroupContribution::getContribution)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(6, RoundingMode.HALF_UP));
        response.setGroupContributions(groupContributions);

        ResiliencyMetadata resiliency = new ResiliencyMetadata();
        resiliency.setFallbackPricingUsed(fallbackUsed);
        resiliency.setDegradedProcessing(pricingIssues > 0);
        resiliency.setPositionsWithPricingIssues(pricingIssues);
        response.setResiliency(resiliency);
        return response;
    }

    private BigDecimal resolveReturn(PositionRequest position) {
        if ("AVAILABLE".equalsIgnoreCase(position.getPriceStatus())) {
            return position.getReturnRate();
        }
        if (position.getFallbackReturnRate() != null) {
            return position.getFallbackReturnRate();
        }
        return position.getReturnRate();
    }
    public status evaluateWeightSum(List<Groups> groups) {
        BigDecimal totalWeight = BigDecimal.ZERO;
        for (Groups group : groups) {
            if (group.getWeightPct() != null) {
                totalWeight = totalWeight.add(group.getWeightPct());
            }
        }
        if (totalWeight.compareTo(BigDecimal.valueOf(100)) == 0) {
            return PortfolioResponse.status.VALID;
        } else {
            return PortfolioResponse.status.INVALID_INPUT;
        }
    }
}
