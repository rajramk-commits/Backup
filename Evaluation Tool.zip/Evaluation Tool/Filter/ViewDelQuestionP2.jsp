<%@page import="com.fedex.emea.onlinequiz.objects.Role"%>
<%@page import="java.util.*"%>
<%@page import="javax.mail.Session"%>
<%@page import="java.io.*"%>
<%@page import="java.nio.file.*"%>
<%@page import="java.nio.charset.*"%>
<%@page import="com.fedex.emea.onlinequiz.objects.QuestionCCC"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>

<jsp:useBean id="dao" class="com.fedex.emea.onlinequiz.dao.QuizDao" scope="page"/>
    
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%     	
	String useridddd = (String) session.getAttribute("Userid");
    if(session.getAttribute("sessionName")==null)
    {
   		response.sendRedirect("Login.jsp");
	}
	if(session.getAttribute("Sessionid").equals("User")){
		response.sendRedirect("LoginMenu.jsp");
	}
    else{
		String userID = (String) session.getAttribute("sessionName");
		String retStat = request.getParameter("status");
		System.out.println("retStat :"+retStat);
      %>
	<html>
	<head>
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
	<link rel="stylesheet" href="https://cdn.datatables.net/fixedheader/3.1.7/css/fixedHeader.dataTables.min.css">
	
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" language="javascript" src="TableFilter/tablefilter.js"></script>
	<script type="text/javascript" language="javascript">	
	function delEvent(id)
	{
		var conf = confirm("confirm to delete question with Id "+id);
		if(conf)
		{
			window.location = "DeleteP2.jsp?id="+id;
		}
	}
	
	function editEvent(team, qnType, qId, qn, opt1,opt2,opt3,opt4,crctAns)
	{
		window.close("ViewDelQuestionP2.jsp");
		window.open("EditP2.jsp?team="+team+"&qnType="+qnType+"&qId="+qId+"&qn="+qn+"&opt1="+opt1+"&opt2="+opt2+"&opt3="+opt3+"&opt4="+opt4+"&crctAns="+crctAns)		
	}
	function chkOnLoadStatus()
	{
		<%
		if(retStat != null)
		{
		%>
			alert('<%=retStat%>');
		<%}%>
	}
	function openLoginMenu() {
		window.close("ViewDelQuestionP2.jsp");
		window.open("Admin.jsp");
	}
	</script>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>View/Delete Question</title>

<style>
.main {
	margin-left: 10%;
	margin-right: 12%;
}

.head {
	height: 50px;
	background-color: #7030a0;
	margin: 0;
}

.logout {
	float: right;
	margin-right: 5%;
	background-color: #FF8C00;
	color: white;
	padding: 14px 20px;
	border: none;
	cursor: pointer;
}

.logout:hover {
	background-color: #4B0060;
}

.home {
	background-color: #4B0082;
	color: white;
	padding: 14px 20px;
	margin: 8px 0;
	border: none;
	cursor: pointer;
	width: 20%;
}

table.steelBlueCols {
  font-family: Tahoma, Geneva, sans-serif;
  border: 4px solid #555555;
  background-color: #555555;
  width: 1040px;
  text-align: left;
  border-collapse: collapse;
}
table.steelBlueCols td, table.steelBlueCols th {
  border: 1px solid #555555;
  padding: 1px 10px;
}
table.steelBlueCols tbody td {
  font-size: 12px;
  color: #FFFFFF;
}
table.steelBlueCols thead {
  background: #398AA4;
}
table.steelBlueCols thead th {
  font-size: 15px;
  font-weight: bold;
  color: #FFFFFF;
  text-align: center;
  border-left: 2px solid #398AA4;
}
table.steelBlueCols thead th:first-child {
  border-left: none;
}

table.steelBlueCols tfoot {
  font-size: 13px;
  font-weight: bold;
  color: #FFFFFF;
  background: #398AA4;
}
table.steelBlueCols tfoot td {
  font-size: 13px;
}
table.steelBlueCols tfoot .links {
  text-align: right;
}
table.steelBlueCols tfoot .links a{
  display: inline-block;
  background: #FFFFFF;
  color: #398AA4;
  padding: 2px 8px;
  border-radius: 5px;
}
.dropdown {
  position: relative;
  display: inline-block;
  background-color: #4CAF50;
  color: white;
  padding: 1px;
  font-size: 20px;
  border: none;
  cursor: pointer;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  /* box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); */
  z-index: 1;
}
</style>
</head>
<body onload="chkOnLoadStatus()">
<div class="main">
		<div class="head">
			<center>
				<p
					style="font-family: Calibri; font-weight: 700; color: white; font-size: 20px; padding: 12px 0 0 0">View/Delete questions for P2</p>
			</center>
		</div>

		<form action=" ${pageContext.request.contextPath}/Logout" method="post">
			<button value="Logout" type="submit" class="logout"
				style="margin-top: 6px; font-family: Calibri; font-size: 16px">Logout</button>
		</form>
		<div
			style="margin: 15px 0 0px 40px; font-family: Calibri; font-size: 16px">
			<b>Welcome :</b><%=userID %>
		</div> 
		<button class="home" onclick="openLoginMenu()">HOME</button>
		<br> <br>
		<!-- <form name="editDelForm"  action="Action.jsp" method="post" > -->
				<table id ="qnDataTable" class="steelBlueCols">
				<thead> <tr style="background-color: #343a40; color: red;">
					<th>Team Name</th>
					<th>Question Type</th>
					<th>Questions</th>
					<th>Option A</th>
					<th>Option B</th>
					<th>Option C</th>
					<th>Option D</th>
					<th>Correct Answer</th>
					<th>Action</th>
				</tr>
				</thead>
				<tfoot>
				<tr> <td colspan="9">
				<!-- <div class="links"><a href="#">&laquo;</a> <a class="active" href="#">1</a> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a> <a href="#">&raquo;</a></div>-->				</td>
				</tr> </tfoot>
				<tbody>				
				<%
				ArrayList<QuestionCCC> list = dao.viewQuestionsP2();
				QuestionCCC question;
				for(int i=0; i< list.size(); i++)
				{
					question = list.get(i);
					%>
					<tr>
					    <td><%=question.getTeam() %></td>
					    <td><%=question.getQuestionType() %>
						<td><%=question.getQuestion() %></td>
						<td><%=question.getOpt1() %></td>
						<td><%=question.getOpt2() %></td>
						<td><%=question.getOpt3() %></td>
						<td><%=question.getOpt4() %></td>
						<td><%=question.getCorrect() %></td>
						<td>
							<button type="button" onclick="editEvent(
							'<%=question.getTeam() %>',
							'<%=question.getQuestionType() %>',
							'<%=question.getQuestionId() %>',
							'<%=question.getQuestion() %>',
							'<%=question.getOpt1() %>',
							'<%=question.getOpt2() %>',
							'<%=question.getOpt3() %>',
							'<%=question.getOpt4() %>',
							'<%=question.getCorrect() %>')" data-toggle="modal" data-target="#edit" data-uid="1" class="update btn btn-warning btn-sm"><span class="glyphicon glyphicon-pencil"></span></button>
							<button type="button" onclick="delEvent('<%=question.getQuestionId() %>')" data-toggle="modal" data-target="#delete" data-uid="1" class="delete btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></button></td>
					</tr>
					<% } %>
				</tbody>
				</table>
		<!-- </form> -->
		<script language="javascript" type="text/javascript">
		     var filtersConfig = {
		        base_path: 'TableFilter/',
		        col_0: 'select',
		        col_1: 'select',
		        col_8: 'none',
		        col_widths: [
		            '115px', '135px', '275px',
		            '115px', '115px', '115px',
		            '115px', '145px', '70px'
		        ]
		    };
		    var tf = new TableFilter('qnDataTable', filtersConfig);
		    tf.init();
		</script>
</body>
</html>
<%}%>