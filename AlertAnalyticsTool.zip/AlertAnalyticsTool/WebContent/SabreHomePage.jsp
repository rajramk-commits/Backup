<%@page import="javax.mail.*"%>
<%@page import="java.util.List"%> 
<%@page import="com.fedex.emea.sabreReport.model.SabreBean"%>
<%
String retStat = request.getParameter("status");
String filePath = null;
String Username = (String) request.getSession().getAttribute("Userid");
System.out.println("Username :"+Username);
String SDate = (String)request.getSession().getAttribute("SDate");
String EDate = (String)request.getSession().getAttribute("EDate");
System.out.println("SDate:"+SDate+", EDate :"+EDate);

if(SDate.length()>15 && EDate.length()>15)
{
	SDate = SDate.substring(0, 15);
	EDate = EDate.substring(0, 15);
}


String userID = "";
String userRole = "";
if(session.getAttribute("sessionName")==null)
{
	userID = (String)request.getSession().getAttribute("sessionName");
	userRole = (String)request.getSession().getAttribute("Sessionid");
	System.out.println("userID request GSS Home:"+userID);
	 if(userID == null && userRole == null)
    	{
		System.out.println("userID userRole are null");
    	} 
}
else
{
	userID = (String) session.getAttribute("sessionName");
	System.out.println("userID GSS Home:"+userID);
	userRole = (String) session.getAttribute("Sessionid");
}

%>

<html>
<head>
<title>Alert Analytics Tool</title>
<script>
function chkOnLoadStatus()
{
	<%
	if(retStat != null)
	{
	%>
		alert('<%=retStat%>');
	<%}%>
}
function goBack() 
{
	<%-- <% session.invalidate();%> --%>
	window.location = "reportType.jsp";
}
function getReport()
{
	window.location = "BarChart.jsp";
	//window.close("SabreHomePage.jsp");
	//window.open("BarChart.jsp?");
	return false;
}

function inProgress(id)
{
	alert("Not implemented yet...!!!");
	//window.location = "DeleteP2.jsp?id="+filePath;
	return false;
}
function logout()
{
	<%-- <% session.invalidate();%> --%>
	window.location = "Login.jsp";
}

function getData()
{
	var startDate = document.getElementById("startDate").value;	
	var endDate = document.getElementById("endDate").value;	
	if(!startDate)
	{
		alert("Please Enter Start Date");
		return false;
	}
	if(!endDate)
	{
		alert("Please Enter End Date");
		return false;
	}
	
	var d1 = new Date(startDate);
	var d2 = new Date(endDate);
	
	if(d1>d2)
	{
		alert("Please enter Start Date less than End Date");
		return false;
	}
	window.location = "FetchData.jsp?startDate="+d1+"&endDate="+d2;
	//window.close("SabreHomePage.jsp");
	//window.open("FetchData.jsp?startDate="+d1+"&endDate="+d2);
	return false;
}


function addUser()
{
	window.location = "addUserScreen.jsp";
	//window.close("SabreHomePage.jsp");
	//window.open("saveExcel.jsp");
	return false;
}
</script>
<style>
	.main{
	margin-left: 5%;
	/* margin-right:12%; */
	}
	.head{
		height :40px;
		background-color: #7030a0;
		margin:0;
	}
	.buttonFont{
	font-family:Calibri;
	font-size:18px;
	background-color:#2C3539;
	color:white;
	padding:14px 20px;
	margin-top:1%;
	margin-left:30%;
	 border-radius: 10px;
	border:none;
	cursor:pointer;
	width:25%;
	}
	.toolbar {
    height: 75px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: purple;
    color: white;
    font-weight: 1000;
  }
  .toolbarFooter {
    height: 50px;
    /* margin: -8px; */
    display: flex;
    align-items: center;
    background-color: #ff6701;
    color: black;
    font-weight: 100;
  }
  .out{
  float: right;
  font-size: 20px;
  color: white;
  margin: 10px;
  border-radius: 1px;
  border: 2px solid #eee;
  background-color: rgb(154 81 150);
  width: 150px;
}

table.steelBlueCols {
  font-family: Tahoma, Geneva, sans-serif;
  border: 2px solid #555555;
  background-color: white;
  width: 93%;
  text-align: center;
  border-collapse: collapse;
}

thead, tbody { display: block; }

table.steelBlueCols thead th {
  font-size: 15px;
  font-weight: bold;
  background-color: #ADFF2F;
  text-align: center;
  border-left: 2px solid #398AA4;
}
tbody {
    height: 450px;       /* Just for the demo          */
    overflow-y: auto;    /* Trigger vertical scroll    */
    overflow-x: hidden;  /* Hide the horizontal scroll */
}

table.steelBlueCols tbody td {
  font-size: 15px;
  background-color: #0143ff47;
  border : 2px solid #555555;
}
</style>

</head>
<body onload="chkOnLoadStatus()">
<div class="toolbar" role="banner">
<button class="out" onclick="goBack()" >Home </button>
    <img
      width="143"
      alt="Angular Logo"
      src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcR4h9OKkNpZrtc-Z6l80kuRFy9wn3DPFOHaIncREOOreXAWEKLG"
      title= "FedEx"
      />
    <span style="font-size: xx-large;">Alert Analytics Tool</span>
     
    <div style="margin-left: 40%">&nbsp;&nbsp;
     <label style = "color: white;" for="uID"><b> <%=userID %></b></label>
    <br>
     <button class="out" onclick="logout()" >Logout</button>
     </div>
</div>

<div class="main">
        <div class="head">
        	<p style="font-family:Calibri;font-weight:700;color:white;font-size:20px;padding:5px 0 0 0;margin-left: 5%;">
        	Sabre Alert Analytics  	 </p>
   		
   		</div>
		<div >
		
		<form action="FetchReport.jsp" onsubmit="return true;" >
		<!-- <label style = "color: navy;" for="birthday"><b>Start date: </b></label>
		<input  style = "color: navy;"  type="date" id="startDate" name="startDate">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		<label  style = "color: navy;"  for="birthday"><b>End date: </b></label>
		<input  style = "color: navy;"  type="date" id="endDate" name="endDate"> -->
		<br>
		<div id="DateRangeLabel"> <span style="font-size: large; font-weight: bold; color: red; text-align: center;">For the date range : <%=SDate %>  to  <%=EDate %> (CEST)</span> </div>
		<br>
		<%
		@SuppressWarnings("unchecked")
	   	List<SabreBean> data = (List<SabreBean>) request.getSession().getAttribute("sabreList");
		if(data != null && data.size() != 0)
		{
			%>
			<table class="steelBlueCols">
				<thead>
				<th style="width:100px">Incident ID</th>
				<th style="width: 143px;">Created Date</th>
				<th style="width: 750px">Short Description</th>
				<th style="width: 105px">Alert Type</th>
				<th style="width: 100px">Location</th>
				</thead>
				<tbody>
				
				<% 
				SabreBean bean = new SabreBean();
				for(int i=0; i< data.size(); i++)
				{
					bean = data.get(i);
					%>
					<tr>
			 		<td><%=bean.getIncedent() %></td>
				    <td style="width: 145px;"><%=bean.getCreated() %> </td>
					<td style="width: 750px"><%=bean.getShortDescr() %></td>
					<td style="width: 100px"><%=bean.getAlertType() %></td>
					<td style="width: 100px"><%=bean.getLocation() %></td>
				</tr>
				<%} %>
				</tbody>
				</table>
				
				
		<%} %>
			<!-- <button class="buttonFont" onclick="return getData()"> Fetch Data </button>
			 &nbsp;&nbsp;&nbsp;&nbsp; -->
			 <%if(data != null && data.size() != 0)
				{ %>
			<button class="buttonFont" onclick="return getReport()"> Show Report </button>
				<%} 
				else
				{
					%>
					<div id="EmptyLabel"> <span style="font-size:xx-large; font-weight: bold; color: blue;; text-align: center;">No Data Found</span> </div>
					<%
				}%>
		</form>
		</div>
</div>

<div class="toolbarFooter" > <!-- style="margin:1% 0% 0% 129px;font-size:13px;color:#9daca1;font-family:Calibri" -->
		This application is protected by copyright and trade mark laws under U.S. and International law.
		All rights reserved.&nbsp;� 2020 FedEx Express EMEA		
		</div>
</body>
</html>