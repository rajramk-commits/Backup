package com.fedex.emea.sd.ovo.processor;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.dao.DataAccessException;

import com.fedex.emea.sd.da.dao.ExternalInterfaceDao;
import com.fedex.emea.sd.da.dao.NetworkEquipmentDao;
import com.fedex.emea.sd.da.dao.OvoMessagesDao;
import com.fedex.emea.sd.da.helpers.Constants;
import com.fedex.emea.sd.da.helpers.Utilities;
import com.fedex.emea.sd.da.logger.ApplicationLogger;
import com.fedex.emea.sd.da.objects.AppsOnServer;
import com.fedex.emea.sd.da.objects.ExternalInterface;
import com.fedex.emea.sd.da.objects.NetworkEquipments;
import com.fedex.emea.sd.da.objects.SupportTicketClassification;
import com.fedex.emea.sd.da.objects.OvoMessages;
import com.fedex.emea.sd.da.objects.OvoObject;

public class InterfaceRecordCreator {
	
	private static final boolean IN_PRODUCTION = true;
	
	private static ApplicationLogger    logger = ApplicationLogger.getInstance();
	
	private static ExternalInterfaceDao externalInterfaceDao;	
	private static OvoMessagesDao       ovoMessagesDao;
	private static NetworkEquipmentDao  networkEquipmentDao;
	
	private static SupportTicketClassification supportTicketClassificatorForExternalInterface;
	
	private static long MAX_ALERT_INTERVAL            = Constants.DEFAULT_8H_ALERT_INTERVAL; // Default = 8 hours (in seconds)
	private static long PRODUCTION_ALERT_INTERVAL     = Constants.PRODUCTION_ALERT_INTERVAL;
	private static long NON_PRODUCTION_ALERT_INTERVAL = Constants.NON_PRODUCTION_ALERT_INTERVAL;
	
	public static void main(String[] args) {
		
		logger.logInfo("OVO Side Agent started...");
		
//		if (!IN_PRODUCTION && args.length == 0) {
//			// Node, msgGroup, appName, severity, msgObj
//			args = getTestArguments("kyak.corp.ds.fedex.com", "System", "fs", "critical", "directory");
//		} 
		
		String completeOVO = getCompleteOVO(args);
		
		OvoObject ovoObject = new OvoObject(completeOVO);
		
		// To decide if Alert must be processed or not
		//
		try {
			if (alertToProcess(ovoObject)) {
				logger.logInfo("Processing OVO Alert: " + completeOVO);
				
				if (processAlert(ovoObject)) {
					logger.logInfo("External Interface Record successfully created for OVO Alert ID=" + ovoObject.getMessageID());
				} else {
					logger.logDebug("Skipped OVO Alert: " + completeOVO);
				}
			} else {
				logger.logDebug("Skipped OVO Alert: " + completeOVO);
			}
		} catch (DataAccessException e) {
			logger.logInfo("External Interface Record NOT created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("External Interface Record NOT created (Data Access): " + e.getMessage());
		} catch (SQLException e) {
			logger.logInfo("External Interface Record NOT created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("External Interface Record NOT created (SQL): " + e.getMessage());
		} catch (IOException e) {
			logger.logInfo("External Interface Record NOT created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("External Interface Record NOT created (I/O): " + e.getMessage());
		} catch (Exception e) {
			logger.logInfo("External Interface Record NOT created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("External Interface Record NOT created (Other): " + e.getMessage());
		} finally {
			logger.logInfo("OVO Side Agent completed.");
		}
	}
	
	// Get complete OVO message based on parameters provided at command prompt
	//
	private static String getCompleteOVO(String[] args) {
		String OvoString = "";
		
		for (int i = 0; i < args.length; i++) {
			if (i > 0) OvoString+=" ";
			OvoString += args[i];
		}
		
		return OvoString;
	}
	
	// Check if OVO Alert should be processed
	//
	private static boolean alertToProcess(OvoObject ovoObject) {
		boolean alertToBeProcessed = false;
		String ovoMsgSeverity = ovoObject.getMessageSeverity().toUpperCase();
		alertToBeProcessed = ovoMsgSeverity.equals(Constants.ALERT_CRITICAL); 
		return alertToBeProcessed;
	}
	
	// Process OVO Alert
	//
	private static boolean processAlert(OvoObject ovoObject) throws DataAccessException, SQLException, IOException, Exception {
		
		boolean alertProcessed = false;
		
		ClassPathResource classPathResource = new ClassPathResource("spring-config.xml");
		XmlBeanFactory beanFactory = new XmlBeanFactory(classPathResource);
		
		networkEquipmentDao  = (NetworkEquipmentDao) beanFactory.getBean("networkEquipmentDao");
		
		if (IN_PRODUCTION) {
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesDao");
		} else {
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceTestDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesTestDao");
		}
		
		supportTicketClassificatorForExternalInterface = assignTicketClassificationForExternalInterface(ovoObject);
		
		ExternalInterface externalInterfaceRecord = new ExternalInterface(ovoObject, supportTicketClassificatorForExternalInterface);
		OvoMessages       ovoMessagesRecord   = new OvoMessages(ovoObject, supportTicketClassificatorForExternalInterface.getCaseId());
		
		ovoMessagesDao.create(ovoMessagesRecord);		
		externalInterfaceDao.create(externalInterfaceRecord);
		
		alertProcessed = true;
		
		if (!IN_PRODUCTION) debugRecords(externalInterfaceRecord, ovoMessagesRecord);
		
		return alertProcessed;
	}
			
	// ==========================================================================================
	// Logic to assign Classifications for EXTERNAL_INTERFACE
	//
	// - IF OVO Object contains 4 elements (length <=10 for DB), split into Classifications
	//		Area				: 0
	//		Service				: 1
	//		Service Component	: 2
	//		Service Function	: 3
	//   ELSE defaults
	// ------------------------------------------------------------------------------------------
	// - IF server is Production and Alert is Critical
	//		Create a  HIGH Case (Incident) with BU=SDESK
	// 		Assign to Helpdesk
	// 		Status is NEW
	// - IF server is Production and Alert is Major/Minor
	//		Create a  MEDIUM/LOW Case (Incident) with BU=SDESK
	// 		Assign to Group depending of OVO MsgGroup or to SD if none
	//        - See Dirk's classification
	// 		Status is NEW
	// - IF server is Non-Production and Alert is Critical/Major/Minor
	//		Create a  MEDIUM/LOW Case (Incident) with BU=SSA
	// 		Assign to Group depending of OVO MsgGroup or to SD if none
	//        - See Dirk's classification
	// 		Status is NEW
	//
	// - Classification Rules
	//  If the 'message_group' property of the OVO alert is 'System', 'OS', 'SSA' or 'Hardware' 
	//    => Nexus ticket should be assigned to the SSA team (depending on the OS of the system the alert originated from, it should go to the SSA unix or intel team).
	//  If the 'message_group' property of the OVO alert is 'Application' 
	//    => Nexus ticket should be assigned to the Application team as noted in CMBD.
	//  If the 'message_group' property of the OVO alert is 'Database' 
	//    => Nexus ticket should be assigned to the DBA team.
	//  If the 'message_group' property of the OVO alert is 'SAN' or 'Storage' 
	//    => Nexus ticket should be assigned to the SSA Storage team.
	//  If the 'message_group' property of the OVO alert is 'Network' 
	//    => Nexus ticket should be assigned to the NE team.
	//
	// ------------------------------------------------------------------------------------------
	// - IF same Case exists within Maximum Interval, ONLY create a Case Note
	//
	private static SupportTicketClassification assignTicketClassificationForExternalInterface(OvoObject ovoObject) {
		
		StringBuffer newCaseDescription = new StringBuffer();
		StringBuffer appsOnImpactedServerDescription = new StringBuffer();
		StringBuffer productionStatusDescription = new StringBuffer();
		
		boolean isProductionServer = false;
		boolean isRegisteredInCMDB  = false;
		
		NetworkEquipments impactedServer = null;
		
		String  serverOStype       = "";
		String  nexusProviderGroup = "";
		
		supportTicketClassificatorForExternalInterface = new SupportTicketClassification();
		
		// Check OVO Msg Object if contains AREA + SERVICE + COMPONENT + FUNCTION
		//
		String elements[] = ovoObject.getObjectName().split(" \\+ ");
		
		if (validOvoObject(elements)) {
			supportTicketClassificatorForExternalInterface.setCaseASCF(elements[0], elements[1], elements[2], elements[3]);
		} else {
			supportTicketClassificatorForExternalInterface.setCaseASCF("ITD", "UNDEF", "UNDEF", "UNDEF"); 
		}
		
		// Check Impacted Server (Node) information from CMDB
		//
		String serverName = ovoObject.getMessageNodeName().substring(0, ovoObject.getMessageNodeName().indexOf(".")).toUpperCase();
		
		try {
			List<AppsOnServer> appsOnServerList = networkEquipmentDao.getApplicationsOnServer(serverName + "%");
			appsOnImpactedServerDescription = getAppsOnServerParagraph(appsOnServerList);
			
			List<NetworkEquipments>    serversList = networkEquipmentDao.getActiveServerDetails(serverName);
			if (serversList.isEmpty()) serversList = networkEquipmentDao.getActiveServerDetails(serverName + ".%");
			if (serversList.isEmpty()) serversList = networkEquipmentDao.getActiveServerDetails(serverName + "%");
			
			if (!serversList.isEmpty()) {
				isRegisteredInCMDB  = true;		// Server found in CMDB
				impactedServer      = serversList.get(0);
				isProductionServer  = getProductionStatus(impactedServer);
				serverOStype        = getServerOS(impactedServer); // 1 = Linux or Windows, 2 = Unix, 3 = Other, 0 = N/A, 4 = LINUX
			} else {
				isRegisteredInCMDB  = false;	// Server NOT found in CMDB
				isProductionServer  = false;
				serverOStype        = "0"; 		// OS = Not Available
			}
			
			nexusProviderGroup = getProviderGroup(ovoObject.getMessageGroup(), serverOStype);
			
			if (isProductionServer) {
				MAX_ALERT_INTERVAL = PRODUCTION_ALERT_INTERVAL;
				productionStatusDescription.append("Server Status in CMDB : PRODUCTION\n");
				productionStatusDescription.append("Server Function : " + impactedServer.getServerFunction() + "\n");
				productionStatusDescription.append("Applications hosted : " + impactedServer.getApplicationHosted() + "\n");
				productionStatusDescription.append(Constants._LINE +  System.getProperty("line.separator"));
				
				supportTicketClassificatorForExternalInterface.setCaseBusinessUnit(Constants.BU_SDESK); 
				
				supportTicketClassificatorForExternalInterface.setCaseStatus(Constants.CASE_STATUS_NEW_CASE);
				supportTicketClassificatorForExternalInterface.setCaseType(Constants.CASE_TYPE_INCIDENT);
				
				if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_CRITICAL)) {
					supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_TOOHIGH); //P3
					//supportTicketClassificatorForExternalInterface.setCaseProviderGroup(Constants.PROVIDER_HELPDESK);  ////for EU_First
					
					supportTicketClassificatorForExternalInterface.setCaseProviderGroup(Constants.PROVIDER_ATLAS); // to assign OVO to EU_FIRST
				} 
				if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_MAJOR)) {
					supportTicketClassificatorForExternalInterface.setCaseBusinessUnit(Constants.BU_SSA);
					supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_TOOHIGH);
					supportTicketClassificatorForExternalInterface.setCaseProviderGroup(nexusProviderGroup);
				}
				if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_MINOR)) {
					supportTicketClassificatorForExternalInterface.setCaseBusinessUnit(Constants.BU_SSA);
					supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_TOOHIGH);
					supportTicketClassificatorForExternalInterface.setCaseProviderGroup(nexusProviderGroup);
				}
			} else {
				MAX_ALERT_INTERVAL = NON_PRODUCTION_ALERT_INTERVAL;
				if (isRegisteredInCMDB) {
					productionStatusDescription.append("Server Status in CMDB : NON-PRODUCTION\n");
					productionStatusDescription.append("Server Function : " + impactedServer.getServerFunction() + "\n");
					productionStatusDescription.append("Applications hosted : " + impactedServer.getApplicationHosted() + "\n");
					supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_MEDIUM);
				} else {
					productionStatusDescription.append("Server Status in CMDB : UNKNOWN (Not in CMDB)\n");
					supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_LOW);
				}
				productionStatusDescription.append(Constants._LINE +  System.getProperty("line.separator"));
				
				supportTicketClassificatorForExternalInterface.setCaseBusinessUnit(Constants.BU_SSA);
				supportTicketClassificatorForExternalInterface.setCaseStatus(Constants.CASE_STATUS_NEW_CASE);
				supportTicketClassificatorForExternalInterface.setCaseType(Constants.CASE_TYPE_INCIDENT);
				supportTicketClassificatorForExternalInterface.setCaseProviderGroup(nexusProviderGroup);
			}
			
			newCaseDescription.append(productionStatusDescription.toString());
			newCaseDescription.append(appsOnImpactedServerDescription.toString());
			supportTicketClassificatorForExternalInterface.setCaseDescription(newCaseDescription.toString());
			
		} catch (SQLException e) {
			logger.logInfo("Unable to query CMDB for Server information. Default Support Ticket will be created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("Unable to query CMDB for Server information. " + e.getMessage());
			supportTicketClassificatorForExternalInterface.setCaseBusinessUnit(Constants.BU_SDESK);
			supportTicketClassificatorForExternalInterface.setCaseStatus(Constants.CASE_STATUS_NEW_CASE);
			supportTicketClassificatorForExternalInterface.setCaseType(Constants.CASE_TYPE_INCIDENT);
			if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_CRITICAL)) supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_TOOHIGH);
			if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_MAJOR))    supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_MEDIUM);
			if (ovoObject.getMessageSeverity().toUpperCase().equals(Constants.ALERT_MINOR))    supportTicketClassificatorForExternalInterface.setCasePriority(Constants.CASE_PRIORITY_LOW);
			supportTicketClassificatorForExternalInterface.setCaseProviderGroup(Constants.PROVIDER_ATLAS);
			supportTicketClassificatorForExternalInterface.setCaseDescription("\nNo data available from CMDB.\n");
		}
			
		supportTicketClassificatorForExternalInterface.setCaseSource("OVO");
		supportTicketClassificatorForExternalInterface.setCaseSummary("GA/OVO Alert on " + ovoObject.getMessageReceiveDate_ManagementServer() + " at " + ovoObject.getMessageReceiveTime_ManagementServer());
		supportTicketClassificatorForExternalInterface.setCaseId(null);
		supportTicketClassificatorForExternalInterface.setCaseSysId(null);
		supportTicketClassificatorForExternalInterface.setCaseNumber(null);
		supportTicketClassificatorForExternalInterface.setIntervalForSimilar(0);
		
		// Check for other Support Ticket created for same Alert => Get Case ID & Interval if found
		// 
		try {
			
			ExternalInterface supportTicket = getSupportTicketForSameAlert(ovoObject);

			if (supportTicket != null) {
				supportTicketClassificatorForExternalInterface.setCaseSource("ADD-NOTE");
				supportTicketClassificatorForExternalInterface.setCaseSummary("Similar Alert received");
				supportTicketClassificatorForExternalInterface.setCaseId(supportTicket.getCaseId());
				supportTicketClassificatorForExternalInterface.setIntervalForSimilar(supportTicket.getSameCaseInterval());
				supportTicketClassificatorForExternalInterface.setCaseNumber(supportTicket.getCaseId());
				supportTicketClassificatorForExternalInterface.setCaseSysId(supportTicket.getCaseSysId());
				logger.logInfo("Similar Support Ticket found in External_Interface NOT older enough. Incident " + supportTicket.getCaseId() + " (" + supportTicket.getSameCaseInterval() + " seconds ago) => Note added.");
			}
		} catch (SQLException e) {
			logger.logInfo("Unable to check for existing Alert. New Support Ticket will be created (OVO Alert ID=" + ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("Unable to check for existing Alert. " + e.getMessage());
		}
		
		return supportTicketClassificatorForExternalInterface;
	}
	
	// ==========================================================================================
	// Get Support Ticket for Same OVO Alert if in MAX_ALERT_INTERVAL
	//
	private static ExternalInterface getSupportTicketForSameAlert(OvoObject ovoObject) throws SQLException {
		
		ExternalInterface supportTicket = null;
		long minimumInterval = 999999999;
		String selectedMessageId = "";
		
		List<OvoMessages> ovoMessagesList = ovoMessagesDao.loadSimilarObjectFromExternalInterface(ovoObject.getMessageNodeName(), ovoObject.getMessageGroup(), ovoObject.getApplicationName(), ovoObject.getObjectName());
		for (Iterator<?> iter = ovoMessagesList.iterator(); iter.hasNext();) {
			OvoMessages element = (OvoMessages) iter.next();
			if (Utilities.getIntervalTimeUntilNow(element.getCreationTime()) < minimumInterval) {
				minimumInterval = Utilities.getIntervalTimeUntilNow(element.getCreationTime());
				selectedMessageId = element.getOvoMessageId();
			}
		}
		
		// If a similar Alert has been found AND Interval <= MAX_ALERT_INTERVAL
		//   => Get corresponding NEXUS Case
		//
		if ((!selectedMessageId.trim().equals("")) && (minimumInterval <= MAX_ALERT_INTERVAL)) {
			supportTicket = externalInterfaceDao.getObjectByRecordSourceId(selectedMessageId);
			supportTicket.setSameCaseInterval(minimumInterval);
		}
		
		return supportTicket;
	}

	// ==========================================================================================
	// Get Provider Group depending of OVO Msg Group (Default = SD) and Server OS
	// - If Msg Group = System or OS or SSA or Hardware => SSA (OS dependent)
	// - If Msg Group = Database                        => DBA
	// - If Msg Group = SAN                             => Storage
	// - If Msg Group = Network                         => LAN
	//
	private static String getProviderGroup(String ovoMsgGroup, String osType) {
		String providerGroup = Constants.PROVIDER_ATLAS;  //EU_FIRST
		
		if (ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_SYSTEM) 
				|| ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_OS)
				|| ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_SSA)
				|| ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_HARDWARE)) {
			
			if (osType.equals(Constants.OS_LINUX_WINDOWS)) {
				providerGroup = Constants.PROVIDER_SSA_NT;
			} /*else if(osType.equals(Constants.OS_LINUX)){
				providerGroup = Constants.PROVIDER_SSA_LINUX;
			}*/else {
				if (osType.equals(Constants.OS_UNIX)) {
					providerGroup = Constants.PROVIDER_SSA_UNIX;
				}
			}
		}
		
		if (ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_DATABASE)) {
			providerGroup = Constants.PROVIDER_DBA;
		}
		
		if (ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_SAN) 
				|| ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_STORAGE)) {
			providerGroup = Constants.PROVIDER_SSA_SAN;
		}
		
		if (ovoMsgGroup.toUpperCase().equals(Constants.APP_GROUP_NETWORK)) {
			providerGroup = Constants.PROVIDER_NE_LAN;
		}
		
		return providerGroup;
	}
	
	// ==========================================================================================
	// Get Server OS 
	// - 1 = Linux or Windows, 2 = Unix, 3 = Other, 0 = N/A
	//
	private static String getServerOS(NetworkEquipments impactedServer) {
		String serverOS = "0";
		
		String OSstring = impactedServer.getServerOsVersion();
		
		if (OSstring != null && !OSstring.isEmpty()) {
			if (OSstring.contains("Win") || OSstring.contains("NT") 
					|| OSstring.contains("2000") || OSstring.contains("ESX") 
					|| OSstring.contains("RH")) {
				serverOS = Constants.OS_LINUX_WINDOWS;
			} /*else if(OSstring.contains("RH")){
				serverOS = Constants.OS_LINUX;
			}*/else {
				if (OSstring.contains("Solaris") || OSstring.contains("AIX") 
						|| OSstring.contains("HP")) {
					serverOS = Constants.OS_UNIX;
				} else {
					serverOS = Constants.OS_OTHER;
				}
			}
		} else { 
			serverOS = Constants.OS_NA;
		}
		
		return serverOS;
	}
	
	// ==========================================================================================
	// Get Impacted Server (Node) Production Status
	//
	private static boolean getProductionStatus(NetworkEquipments impactedServer) {
		boolean productionServer = false;
		
		if (impactedServer.getServerStatus() != null) {
			if (impactedServer.getServerStatus().equals(Constants.PRODUCTION)) productionServer = true;
		}
		
		return productionServer;
	}
	
	// ==========================================================================================
	// Get Applications running on Impacted Server (Node)
	//
	private static StringBuffer getAppsOnServerParagraph(List<AppsOnServer> appsOnServerList) {
		StringBuffer sbAppsOnServer = new StringBuffer();
		
		if (!appsOnServerList.isEmpty()) {
			sbAppsOnServer.append("Applications running on Impacted Node :" + System.getProperty("line.separator") + System.getProperty("line.separator"));
			for (AppsOnServer application: appsOnServerList) {
				if (application.getAppName() != null) {
					sbAppsOnServer.append("*** " + application.getAppName() + System.getProperty("line.separator"));
					sbAppsOnServer.append("----- Environment: " + application.getAppEnviron()  + System.getProperty("line.separator"));
					sbAppsOnServer.append("----- Status: " + application.getAppStatus()  + System.getProperty("line.separator"));
					sbAppsOnServer.append("----- Criticality: " + application.getAppBc()  + System.getProperty("line.separator"));
					sbAppsOnServer.append("----- Resp. Manager: " + application.getAppRespMgr()  + System.getProperty("line.separator"));
					sbAppsOnServer.append("----- Role: " + application.getAppRole()  + System.getProperty("line.separator"));
				}
			}
			sbAppsOnServer.append(Constants._LINE +  System.getProperty("line.separator"));
		} else {
			sbAppsOnServer.append("No Application associated with Impacted Node in CMBD\n");
			sbAppsOnServer.append(Constants._LINE +  System.getProperty("line.separator"));
		}
		
		return sbAppsOnServer;
	}
	
	// ==========================================================================================
	// Logic to validate OVO Alert Msg Object
	// - If 4 elements separated by "+" and not longer than 10 characters
	//
	private static boolean validOvoObject(String alertObjectElements[]) {
		boolean isValid = true;
		
		if (alertObjectElements == null) {				// Incorrect format (" + ")
			isValid = false;
		} else {
			if (alertObjectElements.length != 4) {		// Not enough elements (4)
				isValid = false;
			} else {									// Elements too long for DB (10)
				if ((alertObjectElements[0].length() > 10) || (alertObjectElements[1].length() > 10)
	                || (alertObjectElements[2].length() > 10) || (alertObjectElements[3].length() > 10)) {
					isValid = false;
				}
			}
		}
		return isValid;
	}
	
	// ==========================================================================================
	// TEST Methods
	// ==========================================================================================
	//
//	private static String[] getTestArguments(String nodeName, String msgGroup, String appName, String criticality, String objStr) {
//		
//		SimpleDateFormat sdfDate = new SimpleDateFormat("MM/dd/yyyy");
//		SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss");
//		String msgDate = sdfDate.format(Calendar.getInstance().getTime());
//		String msgTime = sdfTime.format(Calendar.getInstance().getTime());
//		
//		String[] testArgs = {"1[" + String.valueOf(UUID.randomUUID())+ "]", "2[" + nodeName + "]", 
//				"3[Itanium 64/32(HTTPS)]", "4[" + msgDate + "]", "5[" + msgTime + "]", 
//				"6[" + msgDate + "]", "7[" + msgTime + "]", 
//				"8[" + appName + "]", "9[" + msgGroup + "]", "10[" + objStr + "]", "11[" + criticality + "]", 
//				"12[EMEA_BE_SDMonW ab942157 ab943769 ad884231 ap874650 ar848064 as466086 ]", 
//				"13[" + nodeName + " is down, contacting it with ping packages failed.]", 
//				"14[The OVO server probed this system and it did not return a ping request. This means the server is probably down. An operator action will try to ping the server again, results are displayed in the annotations. Inform the system administrator.]", 
//				"15[condition_name=OpC40-436 - Node is probably down]", "16[SeM_SPI:Server@@bryher.emea.fedex.com]"};
//		return testArgs;
//	}
	
	private static void debugRecords(ExternalInterface externalInterfaceRecord, OvoMessages ovoMessagesRecord) {
		logger.logDebug("________________________________________________________________");
		logger.logDebug("NEXUSINTERFACE Record");
		logger.logDebug("---------------------");
		logger.logDebug("Business Unit: "     + externalInterfaceRecord.getCaseBusinessUnit());
		logger.logDebug("Source: "            + externalInterfaceRecord.getRecordSource());
		logger.logDebug("Summary: "           + externalInterfaceRecord.getCaseSummary());
		logger.logDebug("Area: "              + externalInterfaceRecord.getCaseCategory());
		logger.logDebug("Service: "           + externalInterfaceRecord.getCaseCallType());
		logger.logDebug("Service Component: " + externalInterfaceRecord.getCaseProblemType());
		logger.logDebug("Service Function: "  + externalInterfaceRecord.getCaseProblemDetail());
		logger.logDebug("Provider Group: "    + externalInterfaceRecord.getCaseProviderGroup());
		logger.logDebug("Priority: "          + externalInterfaceRecord.getCasePriority());
		logger.logDebug("Status: "            + externalInterfaceRecord.getCaseStatus());
		logger.logDebug("Case Id: "           + externalInterfaceRecord.getCaseId());
		logger.logDebug("Description:");
		logger.logDebug(externalInterfaceRecord.getCaseDescription().toString());
		logger.logDebug("");
		logger.logDebug("OVOMESSAGES Record");
		logger.logDebug("------------------");
		logger.logDebug("Case Id: " + ovoMessagesRecord.getNexusCaseId());
	}
}
