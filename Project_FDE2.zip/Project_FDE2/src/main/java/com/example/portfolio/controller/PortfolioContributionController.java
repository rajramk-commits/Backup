package com.example.portfolio.controller;

import com.example.portfolio.dto.PortfolioRequest;
import com.example.portfolio.dto.PortfolioResponse;
import com.example.portfolio.service.PortfolioContributionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/performance")
public class PortfolioContributionController {

    private final PortfolioContributionService portfolioContributionService;

    public PortfolioContributionController(PortfolioContributionService portfolioContributionService) {
        this.portfolioContributionService = portfolioContributionService;
    }

    @PostMapping("/attribution")
    public PortfolioResponse calculateContribution(@Valid @RequestBody PortfolioRequest request) {
        return portfolioContributionService.calculate(request);
    }
}
