package com.fedex.emea.sd.da.dao.spring;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.transaction.annotation.Transactional;

import com.fedex.emea.sd.da.dao.PrAuditsDao;
import com.fedex.emea.sd.da.exceptions.PrAuditsDaoException;
import com.fedex.emea.sd.da.objects.PeakReadinessAppKeys;
import com.fedex.emea.sd.da.objects.PrAudits;
import com.fedex.emea.sd.da.objects.PrAuditsPk;

public class PrAuditsDaoImpl extends AbstractDAO implements ParameterizedRowMapper<PrAudits>, PrAuditsDao
{
	protected SimpleJdbcTemplate jdbcTemplate;

	protected DataSource dataSource;

	/**
	 * Method 'setDataSource'
	 * 
	 * @param dataSource
	 */
	public void setDataSource(DataSource dataSource)
	{
		this.dataSource = dataSource;
		jdbcTemplate = new SimpleJdbcTemplate(dataSource);
	}

	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return PrAuditsPk
	 */
	@Transactional
	public PrAuditsPk insert(PrAudits dto)
	{
		jdbcTemplate.update("INSERT INTO " + getTableName() + " ( CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )",dto.getCy(),dto.getSymEaiId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getNi2Bi(),dto.getEaiTier(),dto.getMainDc(),dto.getBcRac(),dto.isBcRacWgtNull()?null:dto.getBcRacWgt(),dto.getBcRacRisk(),dto.getBcLocal(),dto.isBcLocalWgtNull()?null:dto.getBcLocalWgt(),dto.getBcLocalRisk(),dto.getBcRemote(),dto.isBcRemoteWgtNull()?null:dto.getBcRemoteWgt(),dto.getBcRemoteRisk(),dto.getCntgncyPlan(),dto.isCntgncyPlanWgtNull()?null:dto.getCntgncyPlanWgt(),dto.getCntgncyPlanRisk(),dto.getDrDoc(),dto.isDrDocWgtNull()?null:dto.getDrDocWgt(),dto.getDrDocRisk(),dto.getDrArcher(),dto.isDrArcherWgtNull()?null:dto.getDrArcherWgt(),dto.getDrArcherRisk(),dto.getDrLastTestDt(),dto.isDrLastTestDtWgtNull()?null:dto.getDrLastTestDtWgt(),dto.getDrLastTestDtRisk(),dto.getSuppOc(),dto.isSuppOcWgtNull()?null:dto.getSuppOcWgt(),dto.getSuppOcRisk(),dto.getSuppStaff(),dto.isSuppStaffWgtNull()?null:dto.getSuppStaffWgt(),dto.getSuppStaffRisk(),dto.getSuppTrain(),dto.isSuppTrainWgtNull()?null:dto.getSuppTrainWgt(),dto.getSuppTrainRisk(),dto.getSuppTecbu(),dto.isSuppTecbuWgtNull()?null:dto.getSuppTecbuWgt(),dto.getSuppTecbuRisk(),dto.getSuppNi2(),dto.isSuppNi2WgtNull()?null:dto.getSuppNi2Wgt(),dto.getSuppNi2Risk(),dto.getComments(),dto.isRiskFactorNull()?null:dto.getRiskFactor(),dto.getNi2AppId(),dto.getAuditStatus(),dto.getLastUpdateDttm(),dto.isAuditIdNull()?null:dto.getAuditId(),dto.getOrg());
		return dto.createPk();
	}

	/** 
	 * Updates a single row in the PR_AUDITS table.
	 */
	@Transactional
	public void update(PrAuditsPk pk, PrAudits dto) throws PrAuditsDaoException
	{
		jdbcTemplate.update("UPDATE " + getTableName() + " SET CY = ?, SYM_EAI_ID = ?, NI2_APP_NAME = ?, RESP_MD_PIN = ?, RESP_MGR_PIN = ?, NI2_BI = ?, EAI_TIER = ?, MAIN_DC = ?, BC_RAC = ?, BC_RAC_WGT = ?, BC_RAC_RISK = ?, BC_LOCAL = ?, BC_LOCAL_WGT = ?, BC_LOCAL_RISK = ?, BC_REMOTE = ?, BC_REMOTE_WGT = ?, BC_REMOTE_RISK = ?, CNTGNCY_PLAN = ?, CNTGNCY_PLAN_WGT = ?, CNTGNCY_PLAN_RISK = ?, DR_DOC = ?, DR_DOC_WGT = ?, DR_DOC_RISK = ?, DR_ARCHER = ?, DR_ARCHER_WGT = ?, DR_ARCHER_RISK = ?, DR_LAST_TEST_DT = ?, DR_LAST_TEST_DT_WGT = ?, DR_LAST_TEST_DT_RISK = ?, SUPP_OC = ?, SUPP_OC_WGT = ?, SUPP_OC_RISK = ?, SUPP_STAFF = ?, SUPP_STAFF_WGT = ?, SUPP_STAFF_RISK = ?, SUPP_TRAIN = ?, SUPP_TRAIN_WGT = ?, SUPP_TRAIN_RISK = ?, SUPP_TECBU = ?, SUPP_TECBU_WGT = ?, SUPP_TECBU_RISK = ?, SUPP_NI2 = ?, SUPP_NI2_WGT = ?, SUPP_NI2_RISK = ?, COMMENTS = ?, RISK_FACTOR = ?, NI2_APP_ID = ?, AUDIT_STATUS = ?, LAST_UPDATE_DTTM = ?, AUDIT_ID = ?, ORG = ? WHERE CY = ? AND SYM_EAI_ID = ? AND NI2_APP_ID = ?",dto.getCy(),dto.getSymEaiId(),dto.getNi2AppName(),dto.getRespMdPin(),dto.getRespMgrPin(),dto.getNi2Bi(),dto.getEaiTier(),dto.getMainDc(),dto.getBcRac(),dto.getBcRacWgt(),dto.getBcRacRisk(),dto.getBcLocal(),dto.getBcLocalWgt(),dto.getBcLocalRisk(),dto.getBcRemote(),dto.getBcRemoteWgt(),dto.getBcRemoteRisk(),dto.getCntgncyPlan(),dto.getCntgncyPlanWgt(),dto.getCntgncyPlanRisk(),dto.getDrDoc(),dto.getDrDocWgt(),dto.getDrDocRisk(),dto.getDrArcher(),dto.getDrArcherWgt(),dto.getDrArcherRisk(),dto.getDrLastTestDt(),dto.getDrLastTestDtWgt(),dto.getDrLastTestDtRisk(),dto.getSuppOc(),dto.getSuppOcWgt(),dto.getSuppOcRisk(),dto.getSuppStaff(),dto.getSuppStaffWgt(),dto.getSuppStaffRisk(),dto.getSuppTrain(),dto.getSuppTrainWgt(),dto.getSuppTrainRisk(),dto.getSuppTecbu(),dto.getSuppTecbuWgt(),dto.getSuppTecbuRisk(),dto.getSuppNi2(),dto.getSuppNi2Wgt(),dto.getSuppNi2Risk(),dto.getComments(),dto.getRiskFactor(),dto.getNi2AppId(),dto.getAuditStatus(),dto.getLastUpdateDttm(),dto.getAuditId(),dto.getOrg(),pk.getCy(),pk.getSymEaiId(),pk.getNi2AppId());
	}

	/** 
	 * Deletes a single row in the PR_AUDITS table.
	 */
	@Transactional
	public void delete(PrAuditsPk pk) throws PrAuditsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND SYM_EAI_ID = ? AND NI2_APP_ID = ?",pk.getCy(),pk.getSymEaiId(),pk.getNi2AppId());
	}

	/** 
	 * Deletes rows per Application Key + CY.
	 */
	@Transactional
	public void deleteByAppKey(PeakReadinessAppKeys appKey) throws PrAuditsDaoException
	{
		jdbcTemplate.update("DELETE FROM " + getTableName() + " WHERE CY = ? AND SYM_EAI_ID = ? AND NI2_APP_ID = ?",appKey.getCy(),appKey.getSymEaiId(),appKey.getNi2AppId());
	}

	/**
	 * Method 'mapRow'
	 * 
	 * @param rs
	 * @param row
	 * @throws SQLException
	 * @return PrAudits
	 */
	public PrAudits mapRow(ResultSet rs, int row) throws SQLException
	{
		PrAudits dto = new PrAudits();
		dto.setCy( rs.getString( 1 ) );
		dto.setSymEaiId( rs.getString( 2 ) );
		dto.setNi2AppName( rs.getString( 3 ) );
		dto.setRespMdPin( rs.getString( 4 ) );
		dto.setRespMgrPin( rs.getString( 5 ) );
		dto.setNi2Bi( rs.getString( 6 ) );
		dto.setEaiTier( rs.getString( 7 ) );
		dto.setMainDc( rs.getString( 8 ) );
		dto.setBcRac( rs.getString( 9 ) );
		dto.setBcRacWgt( rs.getInt( 10 ) );
		if (rs.wasNull()) {
			dto.setBcRacWgtNull( true );
		}
		
		dto.setBcRacRisk( rs.getString( 11 ) );
		dto.setBcLocal( rs.getString( 12 ) );
		dto.setBcLocalWgt( rs.getInt( 13 ) );
		if (rs.wasNull()) {
			dto.setBcLocalWgtNull( true );
		}
		
		dto.setBcLocalRisk( rs.getString( 14 ) );
		dto.setBcRemote( rs.getString( 15 ) );
		dto.setBcRemoteWgt( rs.getInt( 16 ) );
		if (rs.wasNull()) {
			dto.setBcRemoteWgtNull( true );
		}
		
		dto.setBcRemoteRisk( rs.getString( 17 ) );
		dto.setCntgncyPlan( rs.getString( 18 ) );
		dto.setCntgncyPlanWgt( rs.getInt( 19 ) );
		if (rs.wasNull()) {
			dto.setCntgncyPlanWgtNull( true );
		}
		
		dto.setCntgncyPlanRisk( rs.getString( 20 ) );
		dto.setDrDoc( rs.getString( 21 ) );
		dto.setDrDocWgt( rs.getInt( 22 ) );
		if (rs.wasNull()) {
			dto.setDrDocWgtNull( true );
		}
		
		dto.setDrDocRisk( rs.getString( 23 ) );
		dto.setDrArcher( rs.getString( 24 ) );
		dto.setDrArcherWgt( rs.getInt( 25 ) );
		if (rs.wasNull()) {
			dto.setDrArcherWgtNull( true );
		}
		
		dto.setDrArcherRisk( rs.getString( 26 ) );
		dto.setDrLastTestDt( rs.getTimestamp(27 ) );
		dto.setDrLastTestDtWgt( rs.getInt( 28 ) );
		if (rs.wasNull()) {
			dto.setDrLastTestDtWgtNull( true );
		}
		
		dto.setDrLastTestDtRisk( rs.getString( 29 ) );
		dto.setSuppOc( rs.getString( 30 ) );
		dto.setSuppOcWgt( rs.getInt( 31 ) );
		if (rs.wasNull()) {
			dto.setSuppOcWgtNull( true );
		}
		
		dto.setSuppOcRisk( rs.getString( 32 ) );
		dto.setSuppStaff( rs.getString( 33 ) );
		dto.setSuppStaffWgt( rs.getInt( 34 ) );
		if (rs.wasNull()) {
			dto.setSuppStaffWgtNull( true );
		}
		
		dto.setSuppStaffRisk( rs.getString( 35 ) );
		dto.setSuppTrain( rs.getString( 36 ) );
		dto.setSuppTrainWgt( rs.getInt( 37 ) );
		if (rs.wasNull()) {
			dto.setSuppTrainWgtNull( true );
		}
		
		dto.setSuppTrainRisk( rs.getString( 38 ) );
		dto.setSuppTecbu( rs.getString( 39 ) );
		dto.setSuppTecbuWgt( rs.getInt( 40 ) );
		if (rs.wasNull()) {
			dto.setSuppTecbuWgtNull( true );
		}
		
		dto.setSuppTecbuRisk( rs.getString( 41 ) );
		dto.setSuppNi2( rs.getString( 42 ) );
		dto.setSuppNi2Wgt( rs.getInt( 43 ) );
		if (rs.wasNull()) {
			dto.setSuppNi2WgtNull( true );
		}
		
		dto.setSuppNi2Risk( rs.getString( 44 ) );
		dto.setComments( rs.getString( 45 ) );
		dto.setRiskFactor( rs.getInt( 46 ) );
		if (rs.wasNull()) {
			dto.setRiskFactorNull( true );
		}
		
		dto.setNi2AppId( rs.getString( 47 ) );
		dto.setAuditStatus( rs.getString( 48 ) );
		dto.setLastUpdateDttm( rs.getTimestamp(49 ) );
		dto.setAuditId( rs.getInt( 50 ) );
		if (rs.wasNull()) {
			dto.setAuditIdNull( true );
		}
		dto.setOrg( rs.getString( 51 ) );
		
		return dto;
	}

	/**
	 * Method 'getTableName'
	 * 
	 * @return String
	 */
	public String getTableName()
	{
		return "SDTOOL_SCHEMA.PR_AUDITS";
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CY = :cy AND SYM_EAI_ID = :symEaiId AND NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public PrAudits findByPrimaryKey(String cy, String symEaiId, String ni2AppId) throws PrAuditsDaoException
	{
		try {
			List<PrAudits> list = jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? AND SYM_EAI_ID = ? AND NI2_APP_ID = ?", this,cy,symEaiId,ni2AppId);
			return list.size() == 0 ? null : list.get(0);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria ''.
	 */
	@Transactional
	public List<PrAudits> findAll() throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " ORDER BY CY, SYM_EAI_ID, NI2_APP_ID", this);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CY = :cy'.
	 */
	@Transactional
	public List<PrAudits> findWhereCyEquals(String cy) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}
	
	/** 
	 * Returns all keys (CMDB ID, EID ID) from the PR_AUDITS table per CY.
	 */
	@Transactional
	public List<PeakReadinessAppKeys> getKeysPerCy(String cy) throws PrAuditsDaoException {
		List<PeakReadinessAppKeys> returnedList = new ArrayList<PeakReadinessAppKeys>();
		
		try {
			List<PrAudits> eltList = jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CY = ? ORDER BY CY", this,cy);
			for (PrAudits elt: eltList) {
				returnedList.add(new PeakReadinessAppKeys(cy, elt.getNi2AppId(), elt.getSymEaiId()));
			}
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
		return returnedList;
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SYM_EAI_ID = :symEaiId'.
	 */
	@Transactional
	public List<PrAudits> findWhereSymEaiIdEquals(String symEaiId) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SYM_EAI_ID = ? ORDER BY SYM_EAI_ID", this,symEaiId);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_APP_NAME = :ni2AppName'.
	 */
	@Transactional
	public List<PrAudits> findWhereNi2AppNameEquals(String ni2AppName) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_NAME = ? ORDER BY NI2_APP_NAME", this,ni2AppName);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RESP_MD_PIN = :respMdPin'.
	 */
	@Transactional
	public List<PrAudits> findWhereRespMdPinEquals(String respMdPin) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MD_PIN = ? ORDER BY RESP_MD_PIN", this,respMdPin);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RESP_MGR_PIN = :respMgrPin'.
	 */
	@Transactional
	public List<PrAudits> findWhereRespMgrPinEquals(String respMgrPin) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RESP_MGR_PIN = ? ORDER BY RESP_MGR_PIN", this,respMgrPin);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_BI = :ni2Bi'.
	 */
	@Transactional
	public List<PrAudits> findWhereNi2BiEquals(String ni2Bi) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_BI = ? ORDER BY NI2_BI", this,ni2Bi);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'EAI_TIER = :eaiTier'.
	 */
	@Transactional
	public List<PrAudits> findWhereEaiTierEquals(String eaiTier) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE EAI_TIER = ? ORDER BY EAI_TIER", this,eaiTier);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'MAIN_DC = :mainDc'.
	 */
	@Transactional
	public List<PrAudits> findWhereMainDcEquals(String mainDc) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE MAIN_DC = ? ORDER BY MAIN_DC", this,mainDc);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC = :bcRac'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRacEquals(String bcRac) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_RAC = ? ORDER BY BC_RAC", this,bcRac);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC_WGT = :bcRacWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRacWgtEquals(int bcRacWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_RAC_WGT = ? ORDER BY BC_RAC_WGT", this,bcRacWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_RAC_RISK = :bcRacRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRacRiskEquals(String bcRacRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_RAC_RISK = ? ORDER BY BC_RAC_RISK", this,bcRacRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL = :bcLocal'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcLocalEquals(String bcLocal) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_LOCAL = ? ORDER BY BC_LOCAL", this,bcLocal);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL_WGT = :bcLocalWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcLocalWgtEquals(int bcLocalWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_LOCAL_WGT = ? ORDER BY BC_LOCAL_WGT", this,bcLocalWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_LOCAL_RISK = :bcLocalRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcLocalRiskEquals(String bcLocalRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_LOCAL_RISK = ? ORDER BY BC_LOCAL_RISK", this,bcLocalRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE = :bcRemote'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRemoteEquals(String bcRemote) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_REMOTE = ? ORDER BY BC_REMOTE", this,bcRemote);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE_WGT = :bcRemoteWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRemoteWgtEquals(int bcRemoteWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_REMOTE_WGT = ? ORDER BY BC_REMOTE_WGT", this,bcRemoteWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'BC_REMOTE_RISK = :bcRemoteRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereBcRemoteRiskEquals(String bcRemoteRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE BC_REMOTE_RISK = ? ORDER BY BC_REMOTE_RISK", this,bcRemoteRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN = :cntgncyPlan'.
	 */
	@Transactional
	public List<PrAudits> findWhereCntgncyPlanEquals(String cntgncyPlan) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CNTGNCY_PLAN = ? ORDER BY CNTGNCY_PLAN", this,cntgncyPlan);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN_WGT = :cntgncyPlanWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereCntgncyPlanWgtEquals(int cntgncyPlanWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CNTGNCY_PLAN_WGT = ? ORDER BY CNTGNCY_PLAN_WGT", this,cntgncyPlanWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'CNTGNCY_PLAN_RISK = :cntgncyPlanRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereCntgncyPlanRiskEquals(String cntgncyPlanRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE CNTGNCY_PLAN_RISK = ? ORDER BY CNTGNCY_PLAN_RISK", this,cntgncyPlanRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC = :drDoc'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrDocEquals(String drDoc) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_DOC = ? ORDER BY DR_DOC", this,drDoc);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC_WGT = :drDocWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrDocWgtEquals(int drDocWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_DOC_WGT = ? ORDER BY DR_DOC_WGT", this,drDocWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_DOC_RISK = :drDocRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrDocRiskEquals(String drDocRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_DOC_RISK = ? ORDER BY DR_DOC_RISK", this,drDocRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER = :drArcher'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrArcherEquals(String drArcher) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_ARCHER = ? ORDER BY DR_ARCHER", this,drArcher);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER_WGT = :drArcherWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrArcherWgtEquals(int drArcherWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_ARCHER_WGT = ? ORDER BY DR_ARCHER_WGT", this,drArcherWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_ARCHER_RISK = :drArcherRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrArcherRiskEquals(String drArcherRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_ARCHER_RISK = ? ORDER BY DR_ARCHER_RISK", this,drArcherRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT = :drLastTestDt'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrLastTestDtEquals(Date drLastTestDt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_LAST_TEST_DT = ? ORDER BY DR_LAST_TEST_DT", this,drLastTestDt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT_WGT = :drLastTestDtWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrLastTestDtWgtEquals(int drLastTestDtWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_LAST_TEST_DT_WGT = ? ORDER BY DR_LAST_TEST_DT_WGT", this,drLastTestDtWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'DR_LAST_TEST_DT_RISK = :drLastTestDtRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereDrLastTestDtRiskEquals(String drLastTestDtRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE DR_LAST_TEST_DT_RISK = ? ORDER BY DR_LAST_TEST_DT_RISK", this,drLastTestDtRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC = :suppOc'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppOcEquals(String suppOc) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_OC = ? ORDER BY SUPP_OC", this,suppOc);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC_WGT = :suppOcWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppOcWgtEquals(int suppOcWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_OC_WGT = ? ORDER BY SUPP_OC_WGT", this,suppOcWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_OC_RISK = :suppOcRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppOcRiskEquals(String suppOcRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_OC_RISK = ? ORDER BY SUPP_OC_RISK", this,suppOcRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF = :suppStaff'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppStaffEquals(String suppStaff) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_STAFF = ? ORDER BY SUPP_STAFF", this,suppStaff);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF_WGT = :suppStaffWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppStaffWgtEquals(int suppStaffWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_STAFF_WGT = ? ORDER BY SUPP_STAFF_WGT", this,suppStaffWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_STAFF_RISK = :suppStaffRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppStaffRiskEquals(String suppStaffRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_STAFF_RISK = ? ORDER BY SUPP_STAFF_RISK", this,suppStaffRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN = :suppTrain'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTrainEquals(String suppTrain) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TRAIN = ? ORDER BY SUPP_TRAIN", this,suppTrain);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN_WGT = :suppTrainWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTrainWgtEquals(int suppTrainWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TRAIN_WGT = ? ORDER BY SUPP_TRAIN_WGT", this,suppTrainWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TRAIN_RISK = :suppTrainRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTrainRiskEquals(String suppTrainRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TRAIN_RISK = ? ORDER BY SUPP_TRAIN_RISK", this,suppTrainRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU = :suppTecbu'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTecbuEquals(String suppTecbu) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TECBU = ? ORDER BY SUPP_TECBU", this,suppTecbu);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU_WGT = :suppTecbuWgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTecbuWgtEquals(int suppTecbuWgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TECBU_WGT = ? ORDER BY SUPP_TECBU_WGT", this,suppTecbuWgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_TECBU_RISK = :suppTecbuRisk'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppTecbuRiskEquals(String suppTecbuRisk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_TECBU_RISK = ? ORDER BY SUPP_TECBU_RISK", this,suppTecbuRisk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2 = :suppNi2'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppNi2Equals(String suppNi2) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_NI2 = ? ORDER BY SUPP_NI2", this,suppNi2);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2_WGT = :suppNi2Wgt'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppNi2WgtEquals(int suppNi2Wgt) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_NI2_WGT = ? ORDER BY SUPP_NI2_WGT", this,suppNi2Wgt);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'SUPP_NI2_RISK = :suppNi2Risk'.
	 */
	@Transactional
	public List<PrAudits> findWhereSuppNi2RiskEquals(String suppNi2Risk) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE SUPP_NI2_RISK = ? ORDER BY SUPP_NI2_RISK", this,suppNi2Risk);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'COMMENTS = :comments'.
	 */
	@Transactional
	public List<PrAudits> findWhereCommentsEquals(String comments) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE COMMENTS = ? ORDER BY COMMENTS", this,comments);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'RISK_FACTOR = :riskFactor'.
	 */
	@Transactional
	public List<PrAudits> findWhereRiskFactorEquals(int riskFactor) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE RISK_FACTOR = ? ORDER BY RISK_FACTOR", this,riskFactor);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'NI2_APP_ID = :ni2AppId'.
	 */
	@Transactional
	public List<PrAudits> findWhereNi2AppIdEquals(String ni2AppId) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE NI2_APP_ID = ? ORDER BY NI2_APP_ID", this,ni2AppId);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'AUDIT_STATUS = :auditStatus'.
	 */
	@Transactional
	public List<PrAudits> findWhereAuditStatusEquals(String auditStatus) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE AUDIT_STATUS = ? ORDER BY AUDIT_STATUS", this,auditStatus);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'LAST_UPDATE_DTTM = :lastUpdateDttm'.
	 */
	@Transactional
	public List<PrAudits> findWhereLastUpdateDttmEquals(Date lastUpdateDttm) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE LAST_UPDATE_DTTM = ? ORDER BY LAST_UPDATE_DTTM", this,lastUpdateDttm);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns all rows from the PR_AUDITS table that match the criteria 'AUDIT_ID = :auditId'.
	 */
	@Transactional
	public List<PrAudits> findWhereAuditIdEquals(int auditId) throws PrAuditsDaoException
	{
		try {
			return jdbcTemplate.query("SELECT CY, SYM_EAI_ID, NI2_APP_NAME, RESP_MD_PIN, RESP_MGR_PIN, NI2_BI, EAI_TIER, MAIN_DC, BC_RAC, BC_RAC_WGT, BC_RAC_RISK, BC_LOCAL, BC_LOCAL_WGT, BC_LOCAL_RISK, BC_REMOTE, BC_REMOTE_WGT, BC_REMOTE_RISK, CNTGNCY_PLAN, CNTGNCY_PLAN_WGT, CNTGNCY_PLAN_RISK, DR_DOC, DR_DOC_WGT, DR_DOC_RISK, DR_ARCHER, DR_ARCHER_WGT, DR_ARCHER_RISK, DR_LAST_TEST_DT, DR_LAST_TEST_DT_WGT, DR_LAST_TEST_DT_RISK, SUPP_OC, SUPP_OC_WGT, SUPP_OC_RISK, SUPP_STAFF, SUPP_STAFF_WGT, SUPP_STAFF_RISK, SUPP_TRAIN, SUPP_TRAIN_WGT, SUPP_TRAIN_RISK, SUPP_TECBU, SUPP_TECBU_WGT, SUPP_TECBU_RISK, SUPP_NI2, SUPP_NI2_WGT, SUPP_NI2_RISK, COMMENTS, RISK_FACTOR, NI2_APP_ID, AUDIT_STATUS, LAST_UPDATE_DTTM, AUDIT_ID, ORG FROM " + getTableName() + " WHERE AUDIT_ID = ? ORDER BY AUDIT_ID", this,auditId);
		}
		catch (Exception e) {
			throw new PrAuditsDaoException("Query failed", e);
		}
		
	}

	/** 
	 * Returns the rows from the PR_AUDITS table that matches the specified primary-key value.
	 */
	public PrAudits findByPrimaryKey(PrAuditsPk pk) throws PrAuditsDaoException
	{
		return findByPrimaryKey( pk.getCy(), pk.getSymEaiId(), pk.getNi2AppId() );
	}

}
