package com.fedex.emea.sd.da.dao;

import java.util.Date;
import java.math.BigDecimal;
import java.util.List;

import com.fedex.emea.sd.da.exceptions.ApplicationDaoException;
import com.fedex.emea.sd.da.objects.Application;
import com.fedex.emea.sd.da.objects.ApplicationPk;

public interface ApplicationDao
{
	/**
	 * Method 'insert'
	 * 
	 * @param dto
	 * @return ApplicationPk
	 */
	public ApplicationPk insert(Application dto);

	/** 
	 * Updates a single row in the APPLICATION table.
	 */
	public void update(ApplicationPk pk, Application dto) throws ApplicationDaoException;

	/** 
	 * Deletes a single row in the APPLICATION table.
	 */
	public void delete(ApplicationPk pk) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ID = :id'.
	 */
	public Application findByPrimaryKey(String id) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria ''.
	 */
	public List<Application> findAll() throws ApplicationDaoException;
	
	/** 
	 * Returns all rows from the APPLICATION table that are In the Scope of Peak Readiness
	 */
	public List<Application> findInPrScope() throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ID = :id'.
	 */
	public List<Application> findWhereIdEquals(String id) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'NAME = :name'.
	 */
	public List<Application> findWhereNameEquals(String name) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LOCATION_NAME = :locationName'.
	 */
	public List<Application> findWhereLocationNameEquals(String locationName) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'APPLICATION_REVISION = :applicationRevision'.
	 */
	public List<Application> findWhereApplicationRevisionEquals(String applicationRevision) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'APPLICATION_VERSION = :applicationVersion'.
	 */
	public List<Application> findWhereApplicationVersionEquals(String applicationVersion) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'STATUS = :status'.
	 */
	public List<Application> findWhereStatusEquals(String status) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'STATUS_DATE = :statusDate'.
	 */
	public List<Application> findWhereStatusDateEquals(Date statusDate) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'MANUFACTURER_ISSUE_NUMBER = :manufacturerIssueNumber'.
	 */
	public List<Application> findWhereManufacturerIssueNumberEquals(String manufacturerIssueNumber) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'VENDOR = :vendor'.
	 */
	public List<Application> findWhereVendorEquals(String vendor) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INSTALLED_IN = :installedIn'.
	 */
	public List<Application> findWhereInstalledInEquals(String installedIn) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNED_BY_LEASED_FROM = :ownedByLeasedFrom'.
	 */
	public List<Application> findWhereOwnedByLeasedFromEquals(String ownedByLeasedFrom) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNED_OR_LEASED = :ownedOrLeased'.
	 */
	public List<Application> findWhereOwnedOrLeasedEquals(String ownedOrLeased) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OWNERSHIP_LEASE_DATE = :ownershipLeaseDate'.
	 */
	public List<Application> findWhereOwnershipLeaseDateEquals(Date ownershipLeaseDate) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LEASING_PAYMENT = :leasingPayment'.
	 */
	public List<Application> findWhereLeasingPaymentEquals(float leasingPayment) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'COMMENTS = :comments'.
	 */
	public List<Application> findWhereCommentsEquals(String comments) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'RESOURCE_STATUS = :resourceStatus'.
	 */
	public List<Application> findWhereResourceStatusEquals(String resourceStatus) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_1 = :custom1'.
	 */
	public List<Application> findWhereCustom1Equals(String custom1) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_2 = :custom2'.
	 */
	public List<Application> findWhereCustom2Equals(String custom2) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_3 = :custom3'.
	 */
	public List<Application> findWhereCustom3Equals(String custom3) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_4 = :custom4'.
	 */
	public List<Application> findWhereCustom4Equals(String custom4) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_5 = :custom5'.
	 */
	public List<Application> findWhereCustom5Equals(String custom5) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DEFINING_TYPE_KEY_TYPE = :definingTypeKeyType'.
	 */
	public List<Application> findWhereDefiningTypeKeyTypeEquals(String definingTypeKeyType) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DEFINING_TYPE_KEY_PK = :definingTypeKeyPk'.
	 */
	public List<Application> findWhereDefiningTypeKeyPkEquals(String definingTypeKeyPk) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'DESCRIPTION = :description'.
	 */
	public List<Application> findWhereDescriptionEquals(String description) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LONG_DESCRIPTION = :longDescription'.
	 */
	public List<Application> findWhereLongDescriptionEquals(String longDescription) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LAST_MODIFICATION_USER_ID = :lastModificationUserId'.
	 */
	public List<Application> findWhereLastModificationUserIdEquals(String lastModificationUserId) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LAST_MODIFICATION_DATE = :lastModificationDate'.
	 */
	public List<Application> findWhereLastModificationDateEquals(Date lastModificationDate) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'LASTUPDATEVERSIONNUMBER = :lastupdateversionnumber'.
	 */
	public List<Application> findWhereLastupdateversionnumberEquals(BigDecimal lastupdateversionnumber) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_6 = :custom6'.
	 */
	public List<Application> findWhereCustom6Equals(String custom6) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_7 = :custom7'.
	 */
	public List<Application> findWhereCustom7Equals(String custom7) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_8 = :custom8'.
	 */
	public List<Application> findWhereCustom8Equals(String custom8) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_9 = :custom9'.
	 */
	public List<Application> findWhereCustom9Equals(String custom9) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'CUSTOM_10 = :custom10'.
	 */
	public List<Application> findWhereCustom10Equals(String custom10) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'BUSINESS_CRITICALITY = :businessCriticality'.
	 */
	public List<Application> findWhereBusinessCriticalityEquals(String businessCriticality) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'SOURCE = :source'.
	 */
	public List<Application> findWhereSourceEquals(String source) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'SOURCE_KEY = :sourceKey'.
	 */
	public List<Application> findWhereSourceKeyEquals(String sourceKey) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OBJECT_DEFAULT_KEY_TYPE = :objectDefaultKeyType'.
	 */
	public List<Application> findWhereObjectDefaultKeyTypeEquals(String objectDefaultKeyType) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'OBJECT_DEFAULT_KEY_PK = :objectDefaultKeyPk'.
	 */
	public List<Application> findWhereObjectDefaultKeyPkEquals(String objectDefaultKeyPk) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'ENVIRONMENT = :environment'.
	 */
	public List<Application> findWhereEnvironmentEquals(String environment) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INVENTORY_KEY_TYPE = :inventoryKeyType'.
	 */
	public List<Application> findWhereInventoryKeyTypeEquals(String inventoryKeyType) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'INVENTORY_KEY_PK = :inventoryKeyPk'.
	 */
	public List<Application> findWhereInventoryKeyPkEquals(String inventoryKeyPk) throws ApplicationDaoException;

	/** 
	 * Returns all rows from the APPLICATION table that match the criteria 'IS_OVERLAY_COMPONENT = :isOverlayComponent'.
	 */
	public List<Application> findWhereIsOverlayComponentEquals(int isOverlayComponent) throws ApplicationDaoException;

	/** 
	 * Returns the rows from the APPLICATION table that matches the specified primary-key value.
	 */
	public Application findByPrimaryKey(ApplicationPk pk) throws ApplicationDaoException;

}
