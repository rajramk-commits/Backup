package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowRequestSLA implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowScrActive;
	private String snowScrActivityDue;
	private String snowScrAdditionalAssigneeList;
	private String snowScrApproval;
	private String snowScrApprovalHistory;
	private String snowScrApprovalSet;
	private String snowScrAssignedTo;
	private String snowScrAssignmentGroup;
	private String snowScrBusinessDuration;
	private String snowScrBusinessService;
	private String snowScrCalendarDuration;
	private String snowScrCalendarStc;
	private String snowScrCallerId;
	private String snowScrCategory;
	private String snowScrCloseCode;
	private String snowScrCloseNotes;
	private String snowScrClosedAt;
	private String snowScrClosedBy;
	private String snowScrCmdbCi;
	private String snowScrComments;
	private String snowScrCompany;
	private String snowScrContactType;
	private String snowScrContract;
	private String snowScrCorrelationDisplay;
	private String snowScrCorrelationId;
	private String snowScrDeliveryAddress;
	private String snowScrDeliveryPlan;
	private String snowScrDescription;
	private String snowScrDueDate;
	private String snowScrEffort;
	private String snowScrEndDate;
	private String snowScrEscalation;
	private String snowScrExpectedStart;
	private String snowScrFollowUp;
	private String snowScrGroupList;
	private String snowScrImpact;
	private String snowScrKnowledge;
	private String snowScrLocation;
	private String snowScrMadeSla;
	private String snowScrNotify;
	private String snowScrNumber;
	private String snowScrOpenedAt;
	private String snowScrOpenedBy;
	private String snowScrOrder;
	private String snowScrParent;
	private String snowScrPrice;
	private String snowScrPriority;
	private String snowScrReassignmentCount;
	private String snowScrRequestState;
	private String snowScrRequestedDate;
	private String snowScrRequestedFor;
	private String snowScrRfc;
	private String snowScrShortDescription;
	private String snowScrSkills;
	private String snowScrSlaDue;
	private String snowScrSpecialInstructions;
	private String snowScrStage;
	private String snowScrStartDate;
	private String snowScrState;
	private String snowScrStatus;
	private String snowScrSubcategory;
	private String snowScrSysClassName;
	private String snowScrSysCreatedBy;
	private String snowScrSysCreatedOn;
	private String snowScrSysDomain;
	private String snowScrSysId;
	private String snowScrSysModCount;
	private String snowScrSysTags;
	private String snowScrSysUpdatedBy;
	private String snowScrSysUpdatedOn;
	private String snowScrTimeWorked;
	private String snowScrU_3RdLineSrt;
	private String snowScrU_ACCosts;
	private String snowScrU_ADueDate;
	private String snowScrU_AECosts;
	private String snowScrU_ALiveDate;
	private String snowScrU_ARCDate;
	private String snowScrU_AU_MDate;
	private String snowScrU_AcknowldgeFeedback;
	private String snowScrU_Acknowledged;
	private String snowScrU_ActiveProbInc;
	private String snowScrU_ActualEffort;
	private String snowScrU_ActualStart;
	private String snowScrU_ActualUatDate;
	private String snowScrU_AffectedAsset;
	private String snowScrU_AffectedUser;
	private String snowScrU_AofDateTime;
	private String snowScrU_AofPass;
	private String snowScrU_AofState;
	private String snowScrU_AofWorkgroup;
	private String snowScrU_AosDateTime;
	private String snowScrU_AosPass;
	private String snowScrU_AosState;
	private String snowScrU_AosWorkgroup;
	private String snowScrU_AssetCode;
	private String snowScrU_AssetString;
	private String snowScrU_AssignedToBladelogic;
	private String snowScrU_AssignmentStatus;
	private String snowScrU_AttachmentsAdded;
	private String snowScrU_AuditCode;
	private String snowScrU_AutoClose;
	private String snowScrU_AutoCloseTicket;
	private String snowScrU_AutoParm1;
	private String snowScrU_AutoParm2;
	private String snowScrU_AutoParm3;
	private String snowScrU_AutoParm4;
	private String snowScrU_AutoParm5;
	private String snowScrU_AutoTarget;
	private String snowScrU_AutoType;
	private String snowScrU_AvailAddComments;
	private String snowScrU_AvailTechSvc;
	private String snowScrU_AvailabilityReport;
	private String snowScrU_BSManager;
	private String snowScrU_BenefitCategory;
	private String snowScrU_BenefitsCat;
	private String snowScrU_BnlApproval;
	private String snowScrU_BsdResolutionBy;
	private String snowScrU_BudgetCode;
	private String snowScrU_BudgetHolder;
	private String snowScrU_BusinessBenefit;
	private String snowScrU_BusinessObjective;
	private String snowScrU_BusinessService;
	private String snowScrU_CRefNumber;
	private String snowScrU_CallCaptureComments;
	private String snowScrU_CallHandlingComments;
	private String snowScrU_CauseItem;
	private String snowScrU_CausedBy;
	private String snowScrU_ChangeManager;
	private String snowScrU_CiCategory;
	private String snowScrU_CiClassification;
	private String snowScrU_CiSubcategory;
	private String snowScrU_CiSubclassification;
	private String snowScrU_ClarityCode;
	private String snowScrU_Classification;
	private String snowScrU_ClosedCentrally;
	private String snowScrU_ClosedPeriod;
	private String snowScrU_ClosureCategory;
	private String snowScrU_CommentType;
	private String snowScrU_CommentTypeHandling;
	private String snowScrU_CommentsAndWorkNotes;
	private String snowScrU_CopyComments;
	private String snowScrU_CopySubject;
	private String snowScrU_Country;
	private String snowScrU_Csr;
	private String snowScrU_CurrencyInEuro;
	private String snowScrU_CurrencyInGbp;
	private String snowScrU_DesktopAssetNumber;
	private String snowScrU_DesktopMake;
	private String snowScrU_DesktopModel;
	private String snowScrU_DesktopSN;
	private String snowScrU_EAgreedDate;
	private String snowScrU_EDueDate;
	private String snowScrU_EIssuedDate;
	private String snowScrU_EProjectCosts;
	private String snowScrU_EReadyDate;
	private String snowScrU_EffortDays;
	private String snowScrU_Escalated;
	private String snowScrU_ExpertHelp;
	private String snowScrU_ExternalRef;
	private String snowScrU_FLiveDate;
	private String snowScrU_FRCDate;
	private String snowScrU_FeedbackCode;
	private String snowScrU_FeedbackCodeHandling;
	private String snowScrU_FirstDeadline;
	private String snowScrU_FirstTimeFix;
	private String snowScrU_Folder;
	private String snowScrU_ForecastU_MDate;
	private String snowScrU_ForecastUatDate;
	private String snowScrU_FunctionTeam;
	private String snowScrU_HpException;
	private String snowScrU_ImpBreakdown;
	private String snowScrU_ImsRef;
	private String snowScrU_InfosysException;
	private String snowScrU_InitialAssignment;
	private String snowScrU_Instructions;
	private String snowScrU_InternalRef;
	private String snowScrU_ItilWatchList;
	private String snowScrU_KnowledgeArticle;
	private String snowScrU_KnowledgeAvailable;
	private String snowScrU_KnowledgeCode;
	private String snowScrU_KnowledgeComments;
	private String snowScrU_KnowledgeFound;
	private String snowScrU_KnowledgeUser;
	private String snowScrU_LastOccurrence;
	private String snowScrU_LateImpReason;
	private String snowScrU_LeavingDate;
	private String snowScrU_Legal;
	private String snowScrU_LiveDateBusiness;
	private String snowScrU_LocalResp;
	private String snowScrU_ManagementAuditComments;
	private String snowScrU_ManagementComments;
	private String snowScrU_MissingCi;
	private String snowScrU_MissingCiFlag;
	private String snowScrU_ModifiedPeriod;
	private String snowScrU_Name;
	private String snowScrU_NotCorrect1StTime;
	private String snowScrU_OpenedPeriod;
	private String snowScrU_OutageDuration;
	private String snowScrU_OutsourceAssignedOut;
	private String snowScrU_OutsourceAssignee;
	private String snowScrU_OutsourceId;
	private String snowScrU_OutsourceIntegration;
	private String snowScrU_OutsourceModule;
	private String snowScrU_OutsourceResponse;
	private String snowScrU_OutsourceResult;
	private String snowScrU_OutsourceStatus;
	private String snowScrU_OutsourceTeam;
	private String snowScrU_Override1;
	private String snowScrU_Participants;
	private String snowScrU_Person;
	private String snowScrU_PersonAudited;
	private String snowScrU_PersonAuditing;
	private String snowScrU_Phone;
	private String snowScrU_PickupDuration;
	private String snowScrU_PlannedEffort;
	private String snowScrU_PlannedImplementationWeek;
	private String snowScrU_PreviousGroup;
	private String snowScrU_PreviousStatus;
	private String snowScrU_Programme;
	private String snowScrU_QueryCount;
	private String snowScrU_RatesInEuro;
	private String snowScrU_RatesInGbp;
	private String snowScrU_RcdState;
	private String snowScrU_RctFail;
	private String snowScrU_RctPass;
	private String snowScrU_RctState;
	private String snowScrU_RegionImpacted;
	private String snowScrU_Regions;
	private String snowScrU_RelatedIncidents;
	private String snowScrU_ReopenCount;
	private String snowScrU_ReopenedDate;
	private String snowScrU_ResolutionOverride;
	private String snowScrU_ResolvedBy;
	private String snowScrU_ResolvedByWorkgroup;
	private String snowScrU_Resolver;
	private String snowScrU_ResponseFlag;
	private String snowScrU_ResponseOverride;
	private String snowScrU_RolloutSlfInformation;
	private String snowScrU_RolloutSlfReason;
	private String snowScrU_SavedCount;
	private String snowScrU_SecondDeadline;
	private String snowScrU_SelectApplication;
	private String snowScrU_SelectEuc;
	private String snowScrU_SelectInfrastructure;
	private String snowScrU_SelectNetwork;
	private String snowScrU_SlaFailureWorkgroup;
	private String snowScrU_SlaState;
	private String snowScrU_SlfApprover;
	private String snowScrU_SlfComponent;
	private String snowScrU_SlfReason;
	private String snowScrU_SlfReviewDate;
	private String snowScrU_SponsorFunction;
	private String snowScrU_SrtState;
	private String snowScrU_SspForm;
	private String snowScrU_Subject;
	private String snowScrU_SupportStructure;
	private String snowScrU_SystemCode;
	private String snowScrU_TACosts;
	private String snowScrU_TForecastsCosts;
	private String snowScrU_TaskType;
	private String snowScrU_Template;
	private String snowScrU_ThirdLineComments;
	private String snowScrU_ThirdLineDate;
	private String snowScrU_ThirdPartyReference;
	private String snowScrU_TimeToAuth;
	private String snowScrU_TimeToClose;
	private String snowScrU_TotalAgreedChangeCostsFo;
	private String snowScrU_UatSignedDate;
	private String snowScrU_UsersAffected;
	private String snowScrU_VerizonException;
	private String snowScrU_WebId;
	private String snowScrU_WebUpdate;
	private String snowScrUponApproval;
	private String snowScrUponReject;
	private String snowScrUrgency;
	private String snowScrUserInput;
	private String snowScrWatchList;
	private String snowScrWfActivity;
	private String snowScrWorkEffort;
	private String snowScrWorkEnd;
	private String snowScrWorkNotes;
	private String snowScrWorkStart;
	private String snowTaskslatableActive;
	private String snowTaskslatableBusinessDuration;
	private String snowTaskslatableBusinessPauseDuration;
	private String snowTaskslatableBusinessPercentage;
	private String snowTaskslatableBusinessTimeLeft;
	private String snowTaskslatableDuration;
	private String snowTaskslatableEndTime;
	private String snowTaskslatableHasBreached;
	private String snowTaskslatableOriginalBreachTime;
	private String snowTaskslatablePauseDuration;
	private String snowTaskslatablePauseTime;
	private String snowTaskslatablePercentage;
	private String snowTaskslatablePlannedEndTime;
	private String snowTaskslatableSchedule;
	private String snowTaskslatableSla;
	private String snowTaskslatableStage;
	private String snowTaskslatableStartTime;
	private String snowTaskslatableSysCreatedBy;
	private String snowTaskslatableSysCreatedOn;
	private String snowTaskslatableSysId;
	private String snowTaskslatableSysModCount;
	private String snowTaskslatableSysTags;
	private String snowTaskslatableSysUpdatedBy;
	private String snowTaskslatableSysUpdatedOn;
	private String snowTaskslatableTask;
	private String snowTaskslatableTimeLeft;
	private String snowTaskslatableTimezone;
	private String snowTaskslatableU_InScope;
	private String snowTaskslatableU_KbArticle;
	
	public SnowRequestSLA() {
	}
	
	public SnowRequestSLA(HashMap<String, Object> jsonValues) {
		snowScrActive = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_active"));
		snowScrActivityDue = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_activity_due"));
		snowScrAdditionalAssigneeList = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_additional_assignee_list"));
		snowScrApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_approval"));
		snowScrApprovalHistory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_approval_history"));
		snowScrApprovalSet = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_approval_set"));
		snowScrAssignedTo = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_assigned_to"));
		snowScrAssignmentGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_assignment_group"));
		snowScrBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_business_duration"));
		snowScrBusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_business_service"));
		snowScrCalendarDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_calendar_duration"));
		snowScrCalendarStc = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_calendar_stc"));
		snowScrCallerId = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_caller_id"));
		snowScrCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_category"));
		snowScrCloseCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_close_code"));
		snowScrCloseNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_close_notes"));
		snowScrClosedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_closed_at"));
		snowScrClosedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_closed_by"));
		snowScrCmdbCi = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_cmdb_ci"));
		snowScrComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_comments"));
		snowScrCompany = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_company"));
		snowScrContactType = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_contact_type"));
		snowScrContract = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_contract"));
		snowScrCorrelationDisplay = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_correlation_display"));
		snowScrCorrelationId = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_correlation_id"));
		snowScrDeliveryAddress = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_delivery_address"));
		snowScrDeliveryPlan = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_delivery_plan"));
		snowScrDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_description"));
		snowScrDueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_due_date"));
		snowScrEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_effort"));
		snowScrEndDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_end_date"));
		snowScrEscalation = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_escalation"));
		snowScrExpectedStart = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_expected_start"));
		snowScrFollowUp = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_follow_up"));
		snowScrGroupList = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_group_list"));
		snowScrImpact = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_impact"));
		snowScrKnowledge = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_knowledge"));
		snowScrLocation = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_location"));
		snowScrMadeSla = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_made_sla"));
		snowScrNotify = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_notify"));
		snowScrNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_number"));
		snowScrOpenedAt = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_opened_at"));
		snowScrOpenedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_opened_by"));
		snowScrOrder = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_order"));
		snowScrParent = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_parent"));
		snowScrPrice = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_price"));
		snowScrPriority = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_priority"));
		snowScrReassignmentCount = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_reassignment_count"));
		snowScrRequestState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_request_state"));
		snowScrRequestedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_requested_date"));
		snowScrRequestedFor = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_requested_for"));
		snowScrRfc = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_rfc"));
		snowScrShortDescription = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_short_description"));
		snowScrSkills = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_skills"));
		snowScrSlaDue = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sla_due"));
		snowScrSpecialInstructions = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_special_instructions"));
		snowScrStage = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_stage"));
		snowScrStartDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_start_date"));
		snowScrState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_state"));
		snowScrStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_status"));
		snowScrSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_subcategory"));
		snowScrSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_class_name"));
		snowScrSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_created_by"));
		snowScrSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_created_on"));
		snowScrSysDomain = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_domain"));
		snowScrSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_id"));
		snowScrSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_mod_count"));
		snowScrSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_tags"));
		snowScrSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_updated_by"));
		snowScrSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_sys_updated_on"));
		snowScrTimeWorked = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_time_worked"));
		snowScrU_3RdLineSrt = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_3rd_line_srt"));
		snowScrU_ACCosts = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_c_costs"));
		snowScrU_ADueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_due_date"));
		snowScrU_AECosts = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_e_costs"));
		snowScrU_ALiveDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_live_date"));
		snowScrU_ARCDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_r_c_date"));
		snowScrU_AU_MDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_a_u_m_date"));
		snowScrU_AcknowldgeFeedback = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_acknowldge_feedback"));
		snowScrU_Acknowledged = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_acknowledged"));
		snowScrU_ActiveProbInc = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_active_prob_inc"));
		snowScrU_ActualEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_actual_effort"));
		snowScrU_ActualStart = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_actual_start"));
		snowScrU_ActualUatDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_actual_uat_date"));
		snowScrU_AffectedAsset = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_affected_asset"));
		snowScrU_AffectedUser = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_affected_user"));
		snowScrU_AofDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aof_date__time"));
		snowScrU_AofPass = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aof_pass"));
		snowScrU_AofState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aof_state"));
		snowScrU_AofWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aof_workgroup"));
		snowScrU_AosDateTime = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aos_date__time"));
		snowScrU_AosPass = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aos_pass"));
		snowScrU_AosState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aos_state"));
		snowScrU_AosWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_aos_workgroup"));
		snowScrU_AssetCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_asset_code"));
		snowScrU_AssetString = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_asset_string"));
		snowScrU_AssignedToBladelogic = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_assigned_to_bladelogic"));
		snowScrU_AssignmentStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_assignment_status"));
		snowScrU_AttachmentsAdded = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_attachments_added"));
		snowScrU_AuditCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_audit__code"));
		snowScrU_AutoClose = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_close"));
		snowScrU_AutoCloseTicket = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_close_ticket"));
		snowScrU_AutoParm1 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_parm1"));
		snowScrU_AutoParm2 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_parm2"));
		snowScrU_AutoParm3 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_parm3"));
		snowScrU_AutoParm4 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_parm4"));
		snowScrU_AutoParm5 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_parm5"));
		snowScrU_AutoTarget = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_target"));
		snowScrU_AutoType = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_auto_type"));
		snowScrU_AvailAddComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_avail_add_comments"));
		snowScrU_AvailTechSvc = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_avail_tech_svc"));
		snowScrU_AvailabilityReport = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_availability_report"));
		snowScrU_BSManager = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_b_s_manager"));
		snowScrU_BenefitCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_benefit_category"));
		snowScrU_BenefitsCat = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_benefits_cat"));
		snowScrU_BnlApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_bnl_approval"));
		snowScrU_BsdResolutionBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_bsd_resolution_by"));
		snowScrU_BudgetCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_budget_code"));
		snowScrU_BudgetHolder = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_budget_holder"));
		snowScrU_BusinessBenefit = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_business_benefit"));
		snowScrU_BusinessObjective = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_business_objective"));
		snowScrU_BusinessService = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_business_service"));
		snowScrU_CRefNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_c_ref_number"));
		snowScrU_CallCaptureComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_call_capture_comments"));
		snowScrU_CallHandlingComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_call_handling_comments"));
		snowScrU_CauseItem = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_cause_item"));
		snowScrU_CausedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_caused_by"));
		snowScrU_ChangeManager = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_change_manager"));
		snowScrU_CiCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ci_category"));
		snowScrU_CiClassification = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ci_classification"));
		snowScrU_CiSubcategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ci_subcategory"));
		snowScrU_CiSubclassification = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ci_subclassification"));
		snowScrU_ClarityCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_clarity_code"));
		snowScrU_Classification = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_classification"));
		snowScrU_ClosedCentrally = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_closed_centrally"));
		snowScrU_ClosedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_closed_period"));
		snowScrU_ClosureCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_closure_category"));
		snowScrU_CommentType = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_comment_type"));
		snowScrU_CommentTypeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_comment_type_handling"));
		snowScrU_CommentsAndWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_comments_and_work_notes"));
		snowScrU_CopyComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_copy_comments"));
		snowScrU_CopySubject = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_copy_subject"));
		snowScrU_Country = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_country"));
		snowScrU_Csr = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_csr"));
		snowScrU_CurrencyInEuro = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_currency_in_euro"));
		snowScrU_CurrencyInGbp = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_currency_in_gbp"));
		snowScrU_DesktopAssetNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_desktop_asset_number"));
		snowScrU_DesktopMake = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_desktop_make"));
		snowScrU_DesktopModel = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_desktop_model"));
		snowScrU_DesktopSN = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_desktop_s_n"));
		snowScrU_EAgreedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_e_agreed_date"));
		snowScrU_EDueDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_e_due_date"));
		snowScrU_EIssuedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_e_issued_date"));
		snowScrU_EProjectCosts = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_e_project_costs"));
		snowScrU_EReadyDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_e_ready_date"));
		snowScrU_EffortDays = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_effort_days"));
		snowScrU_Escalated = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_escalated"));
		snowScrU_ExpertHelp = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_expert_help"));
		snowScrU_ExternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_external_ref"));
		snowScrU_FLiveDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_f_live_date"));
		snowScrU_FRCDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_f_r_c_date"));
		snowScrU_FeedbackCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_feedback_code"));
		snowScrU_FeedbackCodeHandling = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_feedback_code_handling"));
		snowScrU_FirstDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_first_deadline"));
		snowScrU_FirstTimeFix = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_first_time_fix"));
		snowScrU_Folder = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_folder"));
		snowScrU_ForecastU_MDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_forecast_u_m_date"));
		snowScrU_ForecastUatDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_forecast_uat_date"));
		snowScrU_FunctionTeam = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_function_team"));
		snowScrU_HpException = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_hp_exception"));
		snowScrU_ImpBreakdown = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_imp_breakdown"));
		snowScrU_ImsRef = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ims_ref"));
		snowScrU_InfosysException = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_infosys_exception"));
		snowScrU_InitialAssignment = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_initial_assignment"));
		snowScrU_Instructions = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_instructions"));
		snowScrU_InternalRef = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_internal_ref"));
		snowScrU_ItilWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_itil_watch_list"));
		snowScrU_KnowledgeArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_article"));
		snowScrU_KnowledgeAvailable = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_available"));
		snowScrU_KnowledgeCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_code"));
		snowScrU_KnowledgeComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_comments"));
		snowScrU_KnowledgeFound = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_found"));
		snowScrU_KnowledgeUser = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_knowledge_user"));
		snowScrU_LastOccurrence = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_last_occurrence"));
		snowScrU_LateImpReason = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_late_imp_reason"));
		snowScrU_LeavingDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_leaving_date"));
		snowScrU_Legal = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_legal"));
		snowScrU_LiveDateBusiness = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_live_date_business"));
		snowScrU_LocalResp = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_local_resp"));
		snowScrU_ManagementAuditComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_management_audit_comments"));
		snowScrU_ManagementComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_management_comments"));
		snowScrU_MissingCi = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_missing_ci"));
		snowScrU_MissingCiFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_missing_ci_flag"));
		snowScrU_ModifiedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_modified_period"));
		snowScrU_Name = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_name"));
		snowScrU_NotCorrect1StTime = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_not_correct_1st_time"));
		snowScrU_OpenedPeriod = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_opened_period"));
		snowScrU_OutageDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outage_duration"));
		snowScrU_OutsourceAssignedOut = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_assigned_out"));
		snowScrU_OutsourceAssignee = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_assignee"));
		snowScrU_OutsourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_id"));
		snowScrU_OutsourceIntegration = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_integration"));
		snowScrU_OutsourceModule = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_module"));
		snowScrU_OutsourceResponse = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_response"));
		snowScrU_OutsourceResult = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_result"));
		snowScrU_OutsourceStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_status"));
		snowScrU_OutsourceTeam = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_outsource_team"));
		snowScrU_Override1 = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_override1"));
		snowScrU_Participants = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_participants"));
		snowScrU_Person = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_person"));
		snowScrU_PersonAudited = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_person_audited"));
		snowScrU_PersonAuditing = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_person_auditing"));
		snowScrU_Phone = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_phone"));
		snowScrU_PickupDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_pickup_duration"));
		snowScrU_PlannedEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_planned_effort"));
		snowScrU_PlannedImplementationWeek = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_planned_implementation_week"));
		snowScrU_PreviousGroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_previous_group"));
		snowScrU_PreviousStatus = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_previous_status"));
		snowScrU_Programme = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_programme"));
		snowScrU_QueryCount = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_query_count"));
		snowScrU_RatesInEuro = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rates_in_euro"));
		snowScrU_RatesInGbp = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rates_in_gbp"));
		snowScrU_RcdState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rcd_state"));
		snowScrU_RctFail = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rct_fail"));
		snowScrU_RctPass = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rct_pass"));
		snowScrU_RctState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rct_state"));
		snowScrU_RegionImpacted = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_region_impacted"));
		snowScrU_Regions = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_regions"));
		snowScrU_RelatedIncidents = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_related_incidents"));
		snowScrU_ReopenCount = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_reopen_count"));
		snowScrU_ReopenedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_reopened_date"));
		snowScrU_ResolutionOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_resolution_override"));
		snowScrU_ResolvedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_resolved_by"));
		snowScrU_ResolvedByWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_resolved_by_workgroup"));
		snowScrU_Resolver = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_resolver"));
		snowScrU_ResponseFlag = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_response_flag"));
		snowScrU_ResponseOverride = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_response_override"));
		snowScrU_RolloutSlfInformation = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rollout_slf_information"));
		snowScrU_RolloutSlfReason = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_rollout_slf_reason"));
		snowScrU_SavedCount = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_saved_count"));
		snowScrU_SecondDeadline = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_second_deadline"));
		snowScrU_SelectApplication = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_select_application"));
		snowScrU_SelectEuc = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_select_euc"));
		snowScrU_SelectInfrastructure = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_select_infrastructure"));
		snowScrU_SelectNetwork = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_select_network"));
		snowScrU_SlaFailureWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_sla_failure_workgroup"));
		snowScrU_SlaState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_sla_state"));
		snowScrU_SlfApprover = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_slf_approver"));
		snowScrU_SlfComponent = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_slf_component"));
		snowScrU_SlfReason = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_slf_reason"));
		snowScrU_SlfReviewDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_slf_review_date"));
		snowScrU_SponsorFunction = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_sponsor_function"));
		snowScrU_SrtState = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_srt_state"));
		snowScrU_SspForm = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_ssp_form"));
		snowScrU_Subject = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_subject"));
		snowScrU_SupportStructure = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_support_structure"));
		snowScrU_SystemCode = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_system_code"));
		snowScrU_TACosts = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_t_a_costs"));
		snowScrU_TForecastsCosts = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_t_forecasts_costs"));
		snowScrU_TaskType = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_task_type"));
		snowScrU_Template = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_template"));
		snowScrU_ThirdLineComments = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_third_line_comments"));
		snowScrU_ThirdLineDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_third_line_date"));
		snowScrU_ThirdPartyReference = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_third_party_reference"));
		snowScrU_TimeToAuth = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_time_to_auth"));
		snowScrU_TimeToClose = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_time_to_close"));
		snowScrU_TotalAgreedChangeCostsFo = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_total_agreed_change_costs_fo"));
		snowScrU_UatSignedDate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_uat_signed_date"));
		snowScrU_UsersAffected = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_users_affected"));
		snowScrU_VerizonException = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_verizon_exception"));
		snowScrU_WebId = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_web_id"));
		snowScrU_WebUpdate = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_u_web_update"));
		snowScrUponApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_upon_approval"));
		snowScrUponReject = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_upon_reject"));
		snowScrUrgency = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_urgency"));
		snowScrUserInput = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_user_input"));
		snowScrWatchList = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_watch_list"));
		snowScrWfActivity = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_wf_activity"));
		snowScrWorkEffort = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_work_effort"));
		snowScrWorkEnd = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_work_end"));
		snowScrWorkNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_work_notes"));
		snowScrWorkStart = SnowUtilities.getStringValueFromObject(jsonValues.get("scr_work_start"));
		snowTaskslatableActive = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_active"));
		snowTaskslatableBusinessDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_duration"));
		snowTaskslatableBusinessPauseDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_pause_duration"));
		snowTaskslatableBusinessPercentage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_percentage"));
		snowTaskslatableBusinessTimeLeft = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_business_time_left"));
		snowTaskslatableDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_duration"));
		snowTaskslatableEndTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_end_time"));
		snowTaskslatableHasBreached = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_has_breached"));
		snowTaskslatableOriginalBreachTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_original_breach_time"));
		snowTaskslatablePauseDuration = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_pause_duration"));
		snowTaskslatablePauseTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_pause_time"));
		snowTaskslatablePercentage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_percentage"));
		snowTaskslatablePlannedEndTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_planned_end_time"));
		snowTaskslatableSchedule = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_schedule"));
		snowTaskslatableSla = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sla"));
		snowTaskslatableStage = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_stage"));
		snowTaskslatableStartTime = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_start_time"));
		snowTaskslatableSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_created_by"));
		snowTaskslatableSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_created_on"));
		snowTaskslatableSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_id"));
		snowTaskslatableSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_mod_count"));
		snowTaskslatableSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_tags"));
		snowTaskslatableSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_updated_by"));
		snowTaskslatableSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_sys_updated_on"));
		snowTaskslatableTask = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_task"));
		snowTaskslatableTimeLeft = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_time_left"));
		snowTaskslatableTimezone = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_timezone"));
		snowTaskslatableU_InScope = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_u_in_scope"));
		snowTaskslatableU_KbArticle = SnowUtilities.getStringValueFromObject(jsonValues.get("taskslatable_u_kb_article"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowScrActive != null && !snowScrActive.toString().isEmpty()) jsonObject.put("scr_active", snowScrActive);
		if (snowScrActivityDue != null && !snowScrActivityDue.toString().isEmpty()) jsonObject.put("scr_activity_due", snowScrActivityDue);
		if (snowScrAdditionalAssigneeList != null && !snowScrAdditionalAssigneeList.toString().isEmpty()) jsonObject.put("scr_additional_assignee_list", snowScrAdditionalAssigneeList);
		if (snowScrApproval != null && !snowScrApproval.toString().isEmpty()) jsonObject.put("scr_approval", snowScrApproval);
		if (snowScrApprovalHistory != null && !snowScrApprovalHistory.toString().isEmpty()) jsonObject.put("scr_approval_history", snowScrApprovalHistory);
		if (snowScrApprovalSet != null && !snowScrApprovalSet.toString().isEmpty()) jsonObject.put("scr_approval_set", snowScrApprovalSet);
		if (snowScrAssignedTo != null && !snowScrAssignedTo.toString().isEmpty()) jsonObject.put("scr_assigned_to", snowScrAssignedTo);
		if (snowScrAssignmentGroup != null && !snowScrAssignmentGroup.toString().isEmpty()) jsonObject.put("scr_assignment_group", snowScrAssignmentGroup);
		if (snowScrBusinessDuration != null && !snowScrBusinessDuration.toString().isEmpty()) jsonObject.put("scr_business_duration", snowScrBusinessDuration);
		if (snowScrBusinessService != null && !snowScrBusinessService.toString().isEmpty()) jsonObject.put("scr_business_service", snowScrBusinessService);
		if (snowScrCalendarDuration != null && !snowScrCalendarDuration.toString().isEmpty()) jsonObject.put("scr_calendar_duration", snowScrCalendarDuration);
		if (snowScrCalendarStc != null && !snowScrCalendarStc.toString().isEmpty()) jsonObject.put("scr_calendar_stc", snowScrCalendarStc);
		if (snowScrCallerId != null && !snowScrCallerId.toString().isEmpty()) jsonObject.put("scr_caller_id", snowScrCallerId);
		if (snowScrCategory != null && !snowScrCategory.toString().isEmpty()) jsonObject.put("scr_category", snowScrCategory);
		if (snowScrCloseCode != null && !snowScrCloseCode.toString().isEmpty()) jsonObject.put("scr_close_code", snowScrCloseCode);
		if (snowScrCloseNotes != null && !snowScrCloseNotes.toString().isEmpty()) jsonObject.put("scr_close_notes", snowScrCloseNotes);
		if (snowScrClosedAt != null && !snowScrClosedAt.toString().isEmpty()) jsonObject.put("scr_closed_at", snowScrClosedAt);
		if (snowScrClosedBy != null && !snowScrClosedBy.toString().isEmpty()) jsonObject.put("scr_closed_by", snowScrClosedBy);
		if (snowScrCmdbCi != null && !snowScrCmdbCi.toString().isEmpty()) jsonObject.put("scr_cmdb_ci", snowScrCmdbCi);
		if (snowScrComments != null && !snowScrComments.toString().isEmpty()) jsonObject.put("scr_comments", snowScrComments);
		if (snowScrCompany != null && !snowScrCompany.toString().isEmpty()) jsonObject.put("scr_company", snowScrCompany);
		if (snowScrContactType != null && !snowScrContactType.toString().isEmpty()) jsonObject.put("scr_contact_type", snowScrContactType);
		if (snowScrContract != null && !snowScrContract.toString().isEmpty()) jsonObject.put("scr_contract", snowScrContract);
		if (snowScrCorrelationDisplay != null && !snowScrCorrelationDisplay.toString().isEmpty()) jsonObject.put("scr_correlation_display", snowScrCorrelationDisplay);
		if (snowScrCorrelationId != null && !snowScrCorrelationId.toString().isEmpty()) jsonObject.put("scr_correlation_id", snowScrCorrelationId);
		if (snowScrDeliveryAddress != null && !snowScrDeliveryAddress.toString().isEmpty()) jsonObject.put("scr_delivery_address", snowScrDeliveryAddress);
		if (snowScrDeliveryPlan != null && !snowScrDeliveryPlan.toString().isEmpty()) jsonObject.put("scr_delivery_plan", snowScrDeliveryPlan);
		if (snowScrDescription != null && !snowScrDescription.toString().isEmpty()) jsonObject.put("scr_description", snowScrDescription);
		if (snowScrDueDate != null && !snowScrDueDate.toString().isEmpty()) jsonObject.put("scr_due_date", snowScrDueDate);
		if (snowScrEffort != null && !snowScrEffort.toString().isEmpty()) jsonObject.put("scr_effort", snowScrEffort);
		if (snowScrEndDate != null && !snowScrEndDate.toString().isEmpty()) jsonObject.put("scr_end_date", snowScrEndDate);
		if (snowScrEscalation != null && !snowScrEscalation.toString().isEmpty()) jsonObject.put("scr_escalation", snowScrEscalation);
		if (snowScrExpectedStart != null && !snowScrExpectedStart.toString().isEmpty()) jsonObject.put("scr_expected_start", snowScrExpectedStart);
		if (snowScrFollowUp != null && !snowScrFollowUp.toString().isEmpty()) jsonObject.put("scr_follow_up", snowScrFollowUp);
		if (snowScrGroupList != null && !snowScrGroupList.toString().isEmpty()) jsonObject.put("scr_group_list", snowScrGroupList);
		if (snowScrImpact != null && !snowScrImpact.toString().isEmpty()) jsonObject.put("scr_impact", snowScrImpact);
		if (snowScrKnowledge != null && !snowScrKnowledge.toString().isEmpty()) jsonObject.put("scr_knowledge", snowScrKnowledge);
		if (snowScrLocation != null && !snowScrLocation.toString().isEmpty()) jsonObject.put("scr_location", snowScrLocation);
		if (snowScrMadeSla != null && !snowScrMadeSla.toString().isEmpty()) jsonObject.put("scr_made_sla", snowScrMadeSla);
		if (snowScrNotify != null && !snowScrNotify.toString().isEmpty()) jsonObject.put("scr_notify", snowScrNotify);
		if (snowScrNumber != null && !snowScrNumber.toString().isEmpty()) jsonObject.put("scr_number", snowScrNumber);
		if (snowScrOpenedAt != null && !snowScrOpenedAt.toString().isEmpty()) jsonObject.put("scr_opened_at", snowScrOpenedAt);
		if (snowScrOpenedBy != null && !snowScrOpenedBy.toString().isEmpty()) jsonObject.put("scr_opened_by", snowScrOpenedBy);
		if (snowScrOrder != null && !snowScrOrder.toString().isEmpty()) jsonObject.put("scr_order", snowScrOrder);
		if (snowScrParent != null && !snowScrParent.toString().isEmpty()) jsonObject.put("scr_parent", snowScrParent);
		if (snowScrPrice != null && !snowScrPrice.toString().isEmpty()) jsonObject.put("scr_price", snowScrPrice);
		if (snowScrPriority != null && !snowScrPriority.toString().isEmpty()) jsonObject.put("scr_priority", snowScrPriority);
		if (snowScrReassignmentCount != null && !snowScrReassignmentCount.toString().isEmpty()) jsonObject.put("scr_reassignment_count", snowScrReassignmentCount);
		if (snowScrRequestState != null && !snowScrRequestState.toString().isEmpty()) jsonObject.put("scr_request_state", snowScrRequestState);
		if (snowScrRequestedDate != null && !snowScrRequestedDate.toString().isEmpty()) jsonObject.put("scr_requested_date", snowScrRequestedDate);
		if (snowScrRequestedFor != null && !snowScrRequestedFor.toString().isEmpty()) jsonObject.put("scr_requested_for", snowScrRequestedFor);
		if (snowScrRfc != null && !snowScrRfc.toString().isEmpty()) jsonObject.put("scr_rfc", snowScrRfc);
		if (snowScrShortDescription != null && !snowScrShortDescription.toString().isEmpty()) jsonObject.put("scr_short_description", snowScrShortDescription);
		if (snowScrSkills != null && !snowScrSkills.toString().isEmpty()) jsonObject.put("scr_skills", snowScrSkills);
		if (snowScrSlaDue != null && !snowScrSlaDue.toString().isEmpty()) jsonObject.put("scr_sla_due", snowScrSlaDue);
		if (snowScrSpecialInstructions != null && !snowScrSpecialInstructions.toString().isEmpty()) jsonObject.put("scr_special_instructions", snowScrSpecialInstructions);
		if (snowScrStage != null && !snowScrStage.toString().isEmpty()) jsonObject.put("scr_stage", snowScrStage);
		if (snowScrStartDate != null && !snowScrStartDate.toString().isEmpty()) jsonObject.put("scr_start_date", snowScrStartDate);
		if (snowScrState != null && !snowScrState.toString().isEmpty()) jsonObject.put("scr_state", snowScrState);
		if (snowScrStatus != null && !snowScrStatus.toString().isEmpty()) jsonObject.put("scr_status", snowScrStatus);
		if (snowScrSubcategory != null && !snowScrSubcategory.toString().isEmpty()) jsonObject.put("scr_subcategory", snowScrSubcategory);
		if (snowScrSysClassName != null && !snowScrSysClassName.toString().isEmpty()) jsonObject.put("scr_sys_class_name", snowScrSysClassName);
		if (snowScrSysCreatedBy != null && !snowScrSysCreatedBy.toString().isEmpty()) jsonObject.put("scr_sys_created_by", snowScrSysCreatedBy);
		if (snowScrSysCreatedOn != null && !snowScrSysCreatedOn.toString().isEmpty()) jsonObject.put("scr_sys_created_on", snowScrSysCreatedOn);
		if (snowScrSysDomain != null && !snowScrSysDomain.toString().isEmpty()) jsonObject.put("scr_sys_domain", snowScrSysDomain);
		if (snowScrSysId != null && !snowScrSysId.toString().isEmpty()) jsonObject.put("scr_sys_id", snowScrSysId);
		if (snowScrSysModCount != null && !snowScrSysModCount.toString().isEmpty()) jsonObject.put("scr_sys_mod_count", snowScrSysModCount);
		if (snowScrSysTags != null && !snowScrSysTags.toString().isEmpty()) jsonObject.put("scr_sys_tags", snowScrSysTags);
		if (snowScrSysUpdatedBy != null && !snowScrSysUpdatedBy.toString().isEmpty()) jsonObject.put("scr_sys_updated_by", snowScrSysUpdatedBy);
		if (snowScrSysUpdatedOn != null && !snowScrSysUpdatedOn.toString().isEmpty()) jsonObject.put("scr_sys_updated_on", snowScrSysUpdatedOn);
		if (snowScrTimeWorked != null && !snowScrTimeWorked.toString().isEmpty()) jsonObject.put("scr_time_worked", snowScrTimeWorked);
		if (snowScrU_3RdLineSrt != null && !snowScrU_3RdLineSrt.toString().isEmpty()) jsonObject.put("scr_u_3rd_line_srt", snowScrU_3RdLineSrt);
		if (snowScrU_ACCosts != null && !snowScrU_ACCosts.toString().isEmpty()) jsonObject.put("scr_u_a_c_costs", snowScrU_ACCosts);
		if (snowScrU_ADueDate != null && !snowScrU_ADueDate.toString().isEmpty()) jsonObject.put("scr_u_a_due_date", snowScrU_ADueDate);
		if (snowScrU_AECosts != null && !snowScrU_AECosts.toString().isEmpty()) jsonObject.put("scr_u_a_e_costs", snowScrU_AECosts);
		if (snowScrU_ALiveDate != null && !snowScrU_ALiveDate.toString().isEmpty()) jsonObject.put("scr_u_a_live_date", snowScrU_ALiveDate);
		if (snowScrU_ARCDate != null && !snowScrU_ARCDate.toString().isEmpty()) jsonObject.put("scr_u_a_r_c_date", snowScrU_ARCDate);
		if (snowScrU_AU_MDate != null && !snowScrU_AU_MDate.toString().isEmpty()) jsonObject.put("scr_u_a_u_m_date", snowScrU_AU_MDate);
		if (snowScrU_AcknowldgeFeedback != null && !snowScrU_AcknowldgeFeedback.toString().isEmpty()) jsonObject.put("scr_u_acknowldge_feedback", snowScrU_AcknowldgeFeedback);
		if (snowScrU_Acknowledged != null && !snowScrU_Acknowledged.toString().isEmpty()) jsonObject.put("scr_u_acknowledged", snowScrU_Acknowledged);
		if (snowScrU_ActiveProbInc != null && !snowScrU_ActiveProbInc.toString().isEmpty()) jsonObject.put("scr_u_active_prob_inc", snowScrU_ActiveProbInc);
		if (snowScrU_ActualEffort != null && !snowScrU_ActualEffort.toString().isEmpty()) jsonObject.put("scr_u_actual_effort", snowScrU_ActualEffort);
		if (snowScrU_ActualStart != null && !snowScrU_ActualStart.toString().isEmpty()) jsonObject.put("scr_u_actual_start", snowScrU_ActualStart);
		if (snowScrU_ActualUatDate != null && !snowScrU_ActualUatDate.toString().isEmpty()) jsonObject.put("scr_u_actual_uat_date", snowScrU_ActualUatDate);
		if (snowScrU_AffectedAsset != null && !snowScrU_AffectedAsset.toString().isEmpty()) jsonObject.put("scr_u_affected_asset", snowScrU_AffectedAsset);
		if (snowScrU_AffectedUser != null && !snowScrU_AffectedUser.toString().isEmpty()) jsonObject.put("scr_u_affected_user", snowScrU_AffectedUser);
		if (snowScrU_AofDateTime != null && !snowScrU_AofDateTime.toString().isEmpty()) jsonObject.put("scr_u_aof_date__time", snowScrU_AofDateTime);
		if (snowScrU_AofPass != null && !snowScrU_AofPass.toString().isEmpty()) jsonObject.put("scr_u_aof_pass", snowScrU_AofPass);
		if (snowScrU_AofState != null && !snowScrU_AofState.toString().isEmpty()) jsonObject.put("scr_u_aof_state", snowScrU_AofState);
		if (snowScrU_AofWorkgroup != null && !snowScrU_AofWorkgroup.toString().isEmpty()) jsonObject.put("scr_u_aof_workgroup", snowScrU_AofWorkgroup);
		if (snowScrU_AosDateTime != null && !snowScrU_AosDateTime.toString().isEmpty()) jsonObject.put("scr_u_aos_date__time", snowScrU_AosDateTime);
		if (snowScrU_AosPass != null && !snowScrU_AosPass.toString().isEmpty()) jsonObject.put("scr_u_aos_pass", snowScrU_AosPass);
		if (snowScrU_AosState != null && !snowScrU_AosState.toString().isEmpty()) jsonObject.put("scr_u_aos_state", snowScrU_AosState);
		if (snowScrU_AosWorkgroup != null && !snowScrU_AosWorkgroup.toString().isEmpty()) jsonObject.put("scr_u_aos_workgroup", snowScrU_AosWorkgroup);
		if (snowScrU_AssetCode != null && !snowScrU_AssetCode.toString().isEmpty()) jsonObject.put("scr_u_asset_code", snowScrU_AssetCode);
		if (snowScrU_AssetString != null && !snowScrU_AssetString.toString().isEmpty()) jsonObject.put("scr_u_asset_string", snowScrU_AssetString);
		if (snowScrU_AssignedToBladelogic != null && !snowScrU_AssignedToBladelogic.toString().isEmpty()) jsonObject.put("scr_u_assigned_to_bladelogic", snowScrU_AssignedToBladelogic);
		if (snowScrU_AssignmentStatus != null && !snowScrU_AssignmentStatus.toString().isEmpty()) jsonObject.put("scr_u_assignment_status", snowScrU_AssignmentStatus);
		if (snowScrU_AttachmentsAdded != null && !snowScrU_AttachmentsAdded.toString().isEmpty()) jsonObject.put("scr_u_attachments_added", snowScrU_AttachmentsAdded);
		if (snowScrU_AuditCode != null && !snowScrU_AuditCode.toString().isEmpty()) jsonObject.put("scr_u_audit__code", snowScrU_AuditCode);
		if (snowScrU_AutoClose != null && !snowScrU_AutoClose.toString().isEmpty()) jsonObject.put("scr_u_auto_close", snowScrU_AutoClose);
		if (snowScrU_AutoCloseTicket != null && !snowScrU_AutoCloseTicket.toString().isEmpty()) jsonObject.put("scr_u_auto_close_ticket", snowScrU_AutoCloseTicket);
		if (snowScrU_AutoParm1 != null && !snowScrU_AutoParm1.toString().isEmpty()) jsonObject.put("scr_u_auto_parm1", snowScrU_AutoParm1);
		if (snowScrU_AutoParm2 != null && !snowScrU_AutoParm2.toString().isEmpty()) jsonObject.put("scr_u_auto_parm2", snowScrU_AutoParm2);
		if (snowScrU_AutoParm3 != null && !snowScrU_AutoParm3.toString().isEmpty()) jsonObject.put("scr_u_auto_parm3", snowScrU_AutoParm3);
		if (snowScrU_AutoParm4 != null && !snowScrU_AutoParm4.toString().isEmpty()) jsonObject.put("scr_u_auto_parm4", snowScrU_AutoParm4);
		if (snowScrU_AutoParm5 != null && !snowScrU_AutoParm5.toString().isEmpty()) jsonObject.put("scr_u_auto_parm5", snowScrU_AutoParm5);
		if (snowScrU_AutoTarget != null && !snowScrU_AutoTarget.toString().isEmpty()) jsonObject.put("scr_u_auto_target", snowScrU_AutoTarget);
		if (snowScrU_AutoType != null && !snowScrU_AutoType.toString().isEmpty()) jsonObject.put("scr_u_auto_type", snowScrU_AutoType);
		if (snowScrU_AvailAddComments != null && !snowScrU_AvailAddComments.toString().isEmpty()) jsonObject.put("scr_u_avail_add_comments", snowScrU_AvailAddComments);
		if (snowScrU_AvailTechSvc != null && !snowScrU_AvailTechSvc.toString().isEmpty()) jsonObject.put("scr_u_avail_tech_svc", snowScrU_AvailTechSvc);
		if (snowScrU_AvailabilityReport != null && !snowScrU_AvailabilityReport.toString().isEmpty()) jsonObject.put("scr_u_availability_report", snowScrU_AvailabilityReport);
		if (snowScrU_BSManager != null && !snowScrU_BSManager.toString().isEmpty()) jsonObject.put("scr_u_b_s_manager", snowScrU_BSManager);
		if (snowScrU_BenefitCategory != null && !snowScrU_BenefitCategory.toString().isEmpty()) jsonObject.put("scr_u_benefit_category", snowScrU_BenefitCategory);
		if (snowScrU_BenefitsCat != null && !snowScrU_BenefitsCat.toString().isEmpty()) jsonObject.put("scr_u_benefits_cat", snowScrU_BenefitsCat);
		if (snowScrU_BnlApproval != null && !snowScrU_BnlApproval.toString().isEmpty()) jsonObject.put("scr_u_bnl_approval", snowScrU_BnlApproval);
		if (snowScrU_BsdResolutionBy != null && !snowScrU_BsdResolutionBy.toString().isEmpty()) jsonObject.put("scr_u_bsd_resolution_by", snowScrU_BsdResolutionBy);
		if (snowScrU_BudgetCode != null && !snowScrU_BudgetCode.toString().isEmpty()) jsonObject.put("scr_u_budget_code", snowScrU_BudgetCode);
		if (snowScrU_BudgetHolder != null && !snowScrU_BudgetHolder.toString().isEmpty()) jsonObject.put("scr_u_budget_holder", snowScrU_BudgetHolder);
		if (snowScrU_BusinessBenefit != null && !snowScrU_BusinessBenefit.toString().isEmpty()) jsonObject.put("scr_u_business_benefit", snowScrU_BusinessBenefit);
		if (snowScrU_BusinessObjective != null && !snowScrU_BusinessObjective.toString().isEmpty()) jsonObject.put("scr_u_business_objective", snowScrU_BusinessObjective);
		if (snowScrU_BusinessService != null && !snowScrU_BusinessService.toString().isEmpty()) jsonObject.put("scr_u_business_service", snowScrU_BusinessService);
		if (snowScrU_CRefNumber != null && !snowScrU_CRefNumber.toString().isEmpty()) jsonObject.put("scr_u_c_ref_number", snowScrU_CRefNumber);
		if (snowScrU_CallCaptureComments != null && !snowScrU_CallCaptureComments.toString().isEmpty()) jsonObject.put("scr_u_call_capture_comments", snowScrU_CallCaptureComments);
		if (snowScrU_CallHandlingComments != null && !snowScrU_CallHandlingComments.toString().isEmpty()) jsonObject.put("scr_u_call_handling_comments", snowScrU_CallHandlingComments);
		if (snowScrU_CauseItem != null && !snowScrU_CauseItem.toString().isEmpty()) jsonObject.put("scr_u_cause_item", snowScrU_CauseItem);
		if (snowScrU_CausedBy != null && !snowScrU_CausedBy.toString().isEmpty()) jsonObject.put("scr_u_caused_by", snowScrU_CausedBy);
		if (snowScrU_ChangeManager != null && !snowScrU_ChangeManager.toString().isEmpty()) jsonObject.put("scr_u_change_manager", snowScrU_ChangeManager);
		if (snowScrU_CiCategory != null && !snowScrU_CiCategory.toString().isEmpty()) jsonObject.put("scr_u_ci_category", snowScrU_CiCategory);
		if (snowScrU_CiClassification != null && !snowScrU_CiClassification.toString().isEmpty()) jsonObject.put("scr_u_ci_classification", snowScrU_CiClassification);
		if (snowScrU_CiSubcategory != null && !snowScrU_CiSubcategory.toString().isEmpty()) jsonObject.put("scr_u_ci_subcategory", snowScrU_CiSubcategory);
		if (snowScrU_CiSubclassification != null && !snowScrU_CiSubclassification.toString().isEmpty()) jsonObject.put("scr_u_ci_subclassification", snowScrU_CiSubclassification);
		if (snowScrU_ClarityCode != null && !snowScrU_ClarityCode.toString().isEmpty()) jsonObject.put("scr_u_clarity_code", snowScrU_ClarityCode);
		if (snowScrU_Classification != null && !snowScrU_Classification.toString().isEmpty()) jsonObject.put("scr_u_classification", snowScrU_Classification);
		if (snowScrU_ClosedCentrally != null && !snowScrU_ClosedCentrally.toString().isEmpty()) jsonObject.put("scr_u_closed_centrally", snowScrU_ClosedCentrally);
		if (snowScrU_ClosedPeriod != null && !snowScrU_ClosedPeriod.toString().isEmpty()) jsonObject.put("scr_u_closed_period", snowScrU_ClosedPeriod);
		if (snowScrU_ClosureCategory != null && !snowScrU_ClosureCategory.toString().isEmpty()) jsonObject.put("scr_u_closure_category", snowScrU_ClosureCategory);
		if (snowScrU_CommentType != null && !snowScrU_CommentType.toString().isEmpty()) jsonObject.put("scr_u_comment_type", snowScrU_CommentType);
		if (snowScrU_CommentTypeHandling != null && !snowScrU_CommentTypeHandling.toString().isEmpty()) jsonObject.put("scr_u_comment_type_handling", snowScrU_CommentTypeHandling);
		if (snowScrU_CommentsAndWorkNotes != null && !snowScrU_CommentsAndWorkNotes.toString().isEmpty()) jsonObject.put("scr_u_comments_and_work_notes", snowScrU_CommentsAndWorkNotes);
		if (snowScrU_CopyComments != null && !snowScrU_CopyComments.toString().isEmpty()) jsonObject.put("scr_u_copy_comments", snowScrU_CopyComments);
		if (snowScrU_CopySubject != null && !snowScrU_CopySubject.toString().isEmpty()) jsonObject.put("scr_u_copy_subject", snowScrU_CopySubject);
		if (snowScrU_Country != null && !snowScrU_Country.toString().isEmpty()) jsonObject.put("scr_u_country", snowScrU_Country);
		if (snowScrU_Csr != null && !snowScrU_Csr.toString().isEmpty()) jsonObject.put("scr_u_csr", snowScrU_Csr);
		if (snowScrU_CurrencyInEuro != null && !snowScrU_CurrencyInEuro.toString().isEmpty()) jsonObject.put("scr_u_currency_in_euro", snowScrU_CurrencyInEuro);
		if (snowScrU_CurrencyInGbp != null && !snowScrU_CurrencyInGbp.toString().isEmpty()) jsonObject.put("scr_u_currency_in_gbp", snowScrU_CurrencyInGbp);
		if (snowScrU_DesktopAssetNumber != null && !snowScrU_DesktopAssetNumber.toString().isEmpty()) jsonObject.put("scr_u_desktop_asset_number", snowScrU_DesktopAssetNumber);
		if (snowScrU_DesktopMake != null && !snowScrU_DesktopMake.toString().isEmpty()) jsonObject.put("scr_u_desktop_make", snowScrU_DesktopMake);
		if (snowScrU_DesktopModel != null && !snowScrU_DesktopModel.toString().isEmpty()) jsonObject.put("scr_u_desktop_model", snowScrU_DesktopModel);
		if (snowScrU_DesktopSN != null && !snowScrU_DesktopSN.toString().isEmpty()) jsonObject.put("scr_u_desktop_s_n", snowScrU_DesktopSN);
		if (snowScrU_EAgreedDate != null && !snowScrU_EAgreedDate.toString().isEmpty()) jsonObject.put("scr_u_e_agreed_date", snowScrU_EAgreedDate);
		if (snowScrU_EDueDate != null && !snowScrU_EDueDate.toString().isEmpty()) jsonObject.put("scr_u_e_due_date", snowScrU_EDueDate);
		if (snowScrU_EIssuedDate != null && !snowScrU_EIssuedDate.toString().isEmpty()) jsonObject.put("scr_u_e_issued_date", snowScrU_EIssuedDate);
		if (snowScrU_EProjectCosts != null && !snowScrU_EProjectCosts.toString().isEmpty()) jsonObject.put("scr_u_e_project_costs", snowScrU_EProjectCosts);
		if (snowScrU_EReadyDate != null && !snowScrU_EReadyDate.toString().isEmpty()) jsonObject.put("scr_u_e_ready_date", snowScrU_EReadyDate);
		if (snowScrU_EffortDays != null && !snowScrU_EffortDays.toString().isEmpty()) jsonObject.put("scr_u_effort_days", snowScrU_EffortDays);
		if (snowScrU_Escalated != null && !snowScrU_Escalated.toString().isEmpty()) jsonObject.put("scr_u_escalated", snowScrU_Escalated);
		if (snowScrU_ExpertHelp != null && !snowScrU_ExpertHelp.toString().isEmpty()) jsonObject.put("scr_u_expert_help", snowScrU_ExpertHelp);
		if (snowScrU_ExternalRef != null && !snowScrU_ExternalRef.toString().isEmpty()) jsonObject.put("scr_u_external_ref", snowScrU_ExternalRef);
		if (snowScrU_FLiveDate != null && !snowScrU_FLiveDate.toString().isEmpty()) jsonObject.put("scr_u_f_live_date", snowScrU_FLiveDate);
		if (snowScrU_FRCDate != null && !snowScrU_FRCDate.toString().isEmpty()) jsonObject.put("scr_u_f_r_c_date", snowScrU_FRCDate);
		if (snowScrU_FeedbackCode != null && !snowScrU_FeedbackCode.toString().isEmpty()) jsonObject.put("scr_u_feedback_code", snowScrU_FeedbackCode);
		if (snowScrU_FeedbackCodeHandling != null && !snowScrU_FeedbackCodeHandling.toString().isEmpty()) jsonObject.put("scr_u_feedback_code_handling", snowScrU_FeedbackCodeHandling);
		if (snowScrU_FirstDeadline != null && !snowScrU_FirstDeadline.toString().isEmpty()) jsonObject.put("scr_u_first_deadline", snowScrU_FirstDeadline);
		if (snowScrU_FirstTimeFix != null && !snowScrU_FirstTimeFix.toString().isEmpty()) jsonObject.put("scr_u_first_time_fix", snowScrU_FirstTimeFix);
		if (snowScrU_Folder != null && !snowScrU_Folder.toString().isEmpty()) jsonObject.put("scr_u_folder", snowScrU_Folder);
		if (snowScrU_ForecastU_MDate != null && !snowScrU_ForecastU_MDate.toString().isEmpty()) jsonObject.put("scr_u_forecast_u_m_date", snowScrU_ForecastU_MDate);
		if (snowScrU_ForecastUatDate != null && !snowScrU_ForecastUatDate.toString().isEmpty()) jsonObject.put("scr_u_forecast_uat_date", snowScrU_ForecastUatDate);
		if (snowScrU_FunctionTeam != null && !snowScrU_FunctionTeam.toString().isEmpty()) jsonObject.put("scr_u_function_team", snowScrU_FunctionTeam);
		if (snowScrU_HpException != null && !snowScrU_HpException.toString().isEmpty()) jsonObject.put("scr_u_hp_exception", snowScrU_HpException);
		if (snowScrU_ImpBreakdown != null && !snowScrU_ImpBreakdown.toString().isEmpty()) jsonObject.put("scr_u_imp_breakdown", snowScrU_ImpBreakdown);
		if (snowScrU_ImsRef != null && !snowScrU_ImsRef.toString().isEmpty()) jsonObject.put("scr_u_ims_ref", snowScrU_ImsRef);
		if (snowScrU_InfosysException != null && !snowScrU_InfosysException.toString().isEmpty()) jsonObject.put("scr_u_infosys_exception", snowScrU_InfosysException);
		if (snowScrU_InitialAssignment != null && !snowScrU_InitialAssignment.toString().isEmpty()) jsonObject.put("scr_u_initial_assignment", snowScrU_InitialAssignment);
		if (snowScrU_Instructions != null && !snowScrU_Instructions.toString().isEmpty()) jsonObject.put("scr_u_instructions", snowScrU_Instructions);
		if (snowScrU_InternalRef != null && !snowScrU_InternalRef.toString().isEmpty()) jsonObject.put("scr_u_internal_ref", snowScrU_InternalRef);
		if (snowScrU_ItilWatchList != null && !snowScrU_ItilWatchList.toString().isEmpty()) jsonObject.put("scr_u_itil_watch_list", snowScrU_ItilWatchList);
		if (snowScrU_KnowledgeArticle != null && !snowScrU_KnowledgeArticle.toString().isEmpty()) jsonObject.put("scr_u_knowledge_article", snowScrU_KnowledgeArticle);
		if (snowScrU_KnowledgeAvailable != null && !snowScrU_KnowledgeAvailable.toString().isEmpty()) jsonObject.put("scr_u_knowledge_available", snowScrU_KnowledgeAvailable);
		if (snowScrU_KnowledgeCode != null && !snowScrU_KnowledgeCode.toString().isEmpty()) jsonObject.put("scr_u_knowledge_code", snowScrU_KnowledgeCode);
		if (snowScrU_KnowledgeComments != null && !snowScrU_KnowledgeComments.toString().isEmpty()) jsonObject.put("scr_u_knowledge_comments", snowScrU_KnowledgeComments);
		if (snowScrU_KnowledgeFound != null && !snowScrU_KnowledgeFound.toString().isEmpty()) jsonObject.put("scr_u_knowledge_found", snowScrU_KnowledgeFound);
		if (snowScrU_KnowledgeUser != null && !snowScrU_KnowledgeUser.toString().isEmpty()) jsonObject.put("scr_u_knowledge_user", snowScrU_KnowledgeUser);
		if (snowScrU_LastOccurrence != null && !snowScrU_LastOccurrence.toString().isEmpty()) jsonObject.put("scr_u_last_occurrence", snowScrU_LastOccurrence);
		if (snowScrU_LateImpReason != null && !snowScrU_LateImpReason.toString().isEmpty()) jsonObject.put("scr_u_late_imp_reason", snowScrU_LateImpReason);
		if (snowScrU_LeavingDate != null && !snowScrU_LeavingDate.toString().isEmpty()) jsonObject.put("scr_u_leaving_date", snowScrU_LeavingDate);
		if (snowScrU_Legal != null && !snowScrU_Legal.toString().isEmpty()) jsonObject.put("scr_u_legal", snowScrU_Legal);
		if (snowScrU_LiveDateBusiness != null && !snowScrU_LiveDateBusiness.toString().isEmpty()) jsonObject.put("scr_u_live_date_business", snowScrU_LiveDateBusiness);
		if (snowScrU_LocalResp != null && !snowScrU_LocalResp.toString().isEmpty()) jsonObject.put("scr_u_local_resp", snowScrU_LocalResp);
		if (snowScrU_ManagementAuditComments != null && !snowScrU_ManagementAuditComments.toString().isEmpty()) jsonObject.put("scr_u_management_audit_comments", snowScrU_ManagementAuditComments);
		if (snowScrU_ManagementComments != null && !snowScrU_ManagementComments.toString().isEmpty()) jsonObject.put("scr_u_management_comments", snowScrU_ManagementComments);
		if (snowScrU_MissingCi != null && !snowScrU_MissingCi.toString().isEmpty()) jsonObject.put("scr_u_missing_ci", snowScrU_MissingCi);
		if (snowScrU_MissingCiFlag != null && !snowScrU_MissingCiFlag.toString().isEmpty()) jsonObject.put("scr_u_missing_ci_flag", snowScrU_MissingCiFlag);
		if (snowScrU_ModifiedPeriod != null && !snowScrU_ModifiedPeriod.toString().isEmpty()) jsonObject.put("scr_u_modified_period", snowScrU_ModifiedPeriod);
		if (snowScrU_Name != null && !snowScrU_Name.toString().isEmpty()) jsonObject.put("scr_u_name", snowScrU_Name);
		if (snowScrU_NotCorrect1StTime != null && !snowScrU_NotCorrect1StTime.toString().isEmpty()) jsonObject.put("scr_u_not_correct_1st_time", snowScrU_NotCorrect1StTime);
		if (snowScrU_OpenedPeriod != null && !snowScrU_OpenedPeriod.toString().isEmpty()) jsonObject.put("scr_u_opened_period", snowScrU_OpenedPeriod);
		if (snowScrU_OutageDuration != null && !snowScrU_OutageDuration.toString().isEmpty()) jsonObject.put("scr_u_outage_duration", snowScrU_OutageDuration);
		if (snowScrU_OutsourceAssignedOut != null && !snowScrU_OutsourceAssignedOut.toString().isEmpty()) jsonObject.put("scr_u_outsource_assigned_out", snowScrU_OutsourceAssignedOut);
		if (snowScrU_OutsourceAssignee != null && !snowScrU_OutsourceAssignee.toString().isEmpty()) jsonObject.put("scr_u_outsource_assignee", snowScrU_OutsourceAssignee);
		if (snowScrU_OutsourceId != null && !snowScrU_OutsourceId.toString().isEmpty()) jsonObject.put("scr_u_outsource_id", snowScrU_OutsourceId);
		if (snowScrU_OutsourceIntegration != null && !snowScrU_OutsourceIntegration.toString().isEmpty()) jsonObject.put("scr_u_outsource_integration", snowScrU_OutsourceIntegration);
		if (snowScrU_OutsourceModule != null && !snowScrU_OutsourceModule.toString().isEmpty()) jsonObject.put("scr_u_outsource_module", snowScrU_OutsourceModule);
		if (snowScrU_OutsourceResponse != null && !snowScrU_OutsourceResponse.toString().isEmpty()) jsonObject.put("scr_u_outsource_response", snowScrU_OutsourceResponse);
		if (snowScrU_OutsourceResult != null && !snowScrU_OutsourceResult.toString().isEmpty()) jsonObject.put("scr_u_outsource_result", snowScrU_OutsourceResult);
		if (snowScrU_OutsourceStatus != null && !snowScrU_OutsourceStatus.toString().isEmpty()) jsonObject.put("scr_u_outsource_status", snowScrU_OutsourceStatus);
		if (snowScrU_OutsourceTeam != null && !snowScrU_OutsourceTeam.toString().isEmpty()) jsonObject.put("scr_u_outsource_team", snowScrU_OutsourceTeam);
		if (snowScrU_Override1 != null && !snowScrU_Override1.toString().isEmpty()) jsonObject.put("scr_u_override1", snowScrU_Override1);
		if (snowScrU_Participants != null && !snowScrU_Participants.toString().isEmpty()) jsonObject.put("scr_u_participants", snowScrU_Participants);
		if (snowScrU_Person != null && !snowScrU_Person.toString().isEmpty()) jsonObject.put("scr_u_person", snowScrU_Person);
		if (snowScrU_PersonAudited != null && !snowScrU_PersonAudited.toString().isEmpty()) jsonObject.put("scr_u_person_audited", snowScrU_PersonAudited);
		if (snowScrU_PersonAuditing != null && !snowScrU_PersonAuditing.toString().isEmpty()) jsonObject.put("scr_u_person_auditing", snowScrU_PersonAuditing);
		if (snowScrU_Phone != null && !snowScrU_Phone.toString().isEmpty()) jsonObject.put("scr_u_phone", snowScrU_Phone);
		if (snowScrU_PickupDuration != null && !snowScrU_PickupDuration.toString().isEmpty()) jsonObject.put("scr_u_pickup_duration", snowScrU_PickupDuration);
		if (snowScrU_PlannedEffort != null && !snowScrU_PlannedEffort.toString().isEmpty()) jsonObject.put("scr_u_planned_effort", snowScrU_PlannedEffort);
		if (snowScrU_PlannedImplementationWeek != null && !snowScrU_PlannedImplementationWeek.toString().isEmpty()) jsonObject.put("scr_u_planned_implementation_week", snowScrU_PlannedImplementationWeek);
		if (snowScrU_PreviousGroup != null && !snowScrU_PreviousGroup.toString().isEmpty()) jsonObject.put("scr_u_previous_group", snowScrU_PreviousGroup);
		if (snowScrU_PreviousStatus != null && !snowScrU_PreviousStatus.toString().isEmpty()) jsonObject.put("scr_u_previous_status", snowScrU_PreviousStatus);
		if (snowScrU_Programme != null && !snowScrU_Programme.toString().isEmpty()) jsonObject.put("scr_u_programme", snowScrU_Programme);
		if (snowScrU_QueryCount != null && !snowScrU_QueryCount.toString().isEmpty()) jsonObject.put("scr_u_query_count", snowScrU_QueryCount);
		if (snowScrU_RatesInEuro != null && !snowScrU_RatesInEuro.toString().isEmpty()) jsonObject.put("scr_u_rates_in_euro", snowScrU_RatesInEuro);
		if (snowScrU_RatesInGbp != null && !snowScrU_RatesInGbp.toString().isEmpty()) jsonObject.put("scr_u_rates_in_gbp", snowScrU_RatesInGbp);
		if (snowScrU_RcdState != null && !snowScrU_RcdState.toString().isEmpty()) jsonObject.put("scr_u_rcd_state", snowScrU_RcdState);
		if (snowScrU_RctFail != null && !snowScrU_RctFail.toString().isEmpty()) jsonObject.put("scr_u_rct_fail", snowScrU_RctFail);
		if (snowScrU_RctPass != null && !snowScrU_RctPass.toString().isEmpty()) jsonObject.put("scr_u_rct_pass", snowScrU_RctPass);
		if (snowScrU_RctState != null && !snowScrU_RctState.toString().isEmpty()) jsonObject.put("scr_u_rct_state", snowScrU_RctState);
		if (snowScrU_RegionImpacted != null && !snowScrU_RegionImpacted.toString().isEmpty()) jsonObject.put("scr_u_region_impacted", snowScrU_RegionImpacted);
		if (snowScrU_Regions != null && !snowScrU_Regions.toString().isEmpty()) jsonObject.put("scr_u_regions", snowScrU_Regions);
		if (snowScrU_RelatedIncidents != null && !snowScrU_RelatedIncidents.toString().isEmpty()) jsonObject.put("scr_u_related_incidents", snowScrU_RelatedIncidents);
		if (snowScrU_ReopenCount != null && !snowScrU_ReopenCount.toString().isEmpty()) jsonObject.put("scr_u_reopen_count", snowScrU_ReopenCount);
		if (snowScrU_ReopenedDate != null && !snowScrU_ReopenedDate.toString().isEmpty()) jsonObject.put("scr_u_reopened_date", snowScrU_ReopenedDate);
		if (snowScrU_ResolutionOverride != null && !snowScrU_ResolutionOverride.toString().isEmpty()) jsonObject.put("scr_u_resolution_override", snowScrU_ResolutionOverride);
		if (snowScrU_ResolvedBy != null && !snowScrU_ResolvedBy.toString().isEmpty()) jsonObject.put("scr_u_resolved_by", snowScrU_ResolvedBy);
		if (snowScrU_ResolvedByWorkgroup != null && !snowScrU_ResolvedByWorkgroup.toString().isEmpty()) jsonObject.put("scr_u_resolved_by_workgroup", snowScrU_ResolvedByWorkgroup);
		if (snowScrU_Resolver != null && !snowScrU_Resolver.toString().isEmpty()) jsonObject.put("scr_u_resolver", snowScrU_Resolver);
		if (snowScrU_ResponseFlag != null && !snowScrU_ResponseFlag.toString().isEmpty()) jsonObject.put("scr_u_response_flag", snowScrU_ResponseFlag);
		if (snowScrU_ResponseOverride != null && !snowScrU_ResponseOverride.toString().isEmpty()) jsonObject.put("scr_u_response_override", snowScrU_ResponseOverride);
		if (snowScrU_RolloutSlfInformation != null && !snowScrU_RolloutSlfInformation.toString().isEmpty()) jsonObject.put("scr_u_rollout_slf_information", snowScrU_RolloutSlfInformation);
		if (snowScrU_RolloutSlfReason != null && !snowScrU_RolloutSlfReason.toString().isEmpty()) jsonObject.put("scr_u_rollout_slf_reason", snowScrU_RolloutSlfReason);
		if (snowScrU_SavedCount != null && !snowScrU_SavedCount.toString().isEmpty()) jsonObject.put("scr_u_saved_count", snowScrU_SavedCount);
		if (snowScrU_SecondDeadline != null && !snowScrU_SecondDeadline.toString().isEmpty()) jsonObject.put("scr_u_second_deadline", snowScrU_SecondDeadline);
		if (snowScrU_SelectApplication != null && !snowScrU_SelectApplication.toString().isEmpty()) jsonObject.put("scr_u_select_application", snowScrU_SelectApplication);
		if (snowScrU_SelectEuc != null && !snowScrU_SelectEuc.toString().isEmpty()) jsonObject.put("scr_u_select_euc", snowScrU_SelectEuc);
		if (snowScrU_SelectInfrastructure != null && !snowScrU_SelectInfrastructure.toString().isEmpty()) jsonObject.put("scr_u_select_infrastructure", snowScrU_SelectInfrastructure);
		if (snowScrU_SelectNetwork != null && !snowScrU_SelectNetwork.toString().isEmpty()) jsonObject.put("scr_u_select_network", snowScrU_SelectNetwork);
		if (snowScrU_SlaFailureWorkgroup != null && !snowScrU_SlaFailureWorkgroup.toString().isEmpty()) jsonObject.put("scr_u_sla_failure_workgroup", snowScrU_SlaFailureWorkgroup);
		if (snowScrU_SlaState != null && !snowScrU_SlaState.toString().isEmpty()) jsonObject.put("scr_u_sla_state", snowScrU_SlaState);
		if (snowScrU_SlfApprover != null && !snowScrU_SlfApprover.toString().isEmpty()) jsonObject.put("scr_u_slf_approver", snowScrU_SlfApprover);
		if (snowScrU_SlfComponent != null && !snowScrU_SlfComponent.toString().isEmpty()) jsonObject.put("scr_u_slf_component", snowScrU_SlfComponent);
		if (snowScrU_SlfReason != null && !snowScrU_SlfReason.toString().isEmpty()) jsonObject.put("scr_u_slf_reason", snowScrU_SlfReason);
		if (snowScrU_SlfReviewDate != null && !snowScrU_SlfReviewDate.toString().isEmpty()) jsonObject.put("scr_u_slf_review_date", snowScrU_SlfReviewDate);
		if (snowScrU_SponsorFunction != null && !snowScrU_SponsorFunction.toString().isEmpty()) jsonObject.put("scr_u_sponsor_function", snowScrU_SponsorFunction);
		if (snowScrU_SrtState != null && !snowScrU_SrtState.toString().isEmpty()) jsonObject.put("scr_u_srt_state", snowScrU_SrtState);
		if (snowScrU_SspForm != null && !snowScrU_SspForm.toString().isEmpty()) jsonObject.put("scr_u_ssp_form", snowScrU_SspForm);
		if (snowScrU_Subject != null && !snowScrU_Subject.toString().isEmpty()) jsonObject.put("scr_u_subject", snowScrU_Subject);
		if (snowScrU_SupportStructure != null && !snowScrU_SupportStructure.toString().isEmpty()) jsonObject.put("scr_u_support_structure", snowScrU_SupportStructure);
		if (snowScrU_SystemCode != null && !snowScrU_SystemCode.toString().isEmpty()) jsonObject.put("scr_u_system_code", snowScrU_SystemCode);
		if (snowScrU_TACosts != null && !snowScrU_TACosts.toString().isEmpty()) jsonObject.put("scr_u_t_a_costs", snowScrU_TACosts);
		if (snowScrU_TForecastsCosts != null && !snowScrU_TForecastsCosts.toString().isEmpty()) jsonObject.put("scr_u_t_forecasts_costs", snowScrU_TForecastsCosts);
		if (snowScrU_TaskType != null && !snowScrU_TaskType.toString().isEmpty()) jsonObject.put("scr_u_task_type", snowScrU_TaskType);
		if (snowScrU_Template != null && !snowScrU_Template.toString().isEmpty()) jsonObject.put("scr_u_template", snowScrU_Template);
		if (snowScrU_ThirdLineComments != null && !snowScrU_ThirdLineComments.toString().isEmpty()) jsonObject.put("scr_u_third_line_comments", snowScrU_ThirdLineComments);
		if (snowScrU_ThirdLineDate != null && !snowScrU_ThirdLineDate.toString().isEmpty()) jsonObject.put("scr_u_third_line_date", snowScrU_ThirdLineDate);
		if (snowScrU_ThirdPartyReference != null && !snowScrU_ThirdPartyReference.toString().isEmpty()) jsonObject.put("scr_u_third_party_reference", snowScrU_ThirdPartyReference);
		if (snowScrU_TimeToAuth != null && !snowScrU_TimeToAuth.toString().isEmpty()) jsonObject.put("scr_u_time_to_auth", snowScrU_TimeToAuth);
		if (snowScrU_TimeToClose != null && !snowScrU_TimeToClose.toString().isEmpty()) jsonObject.put("scr_u_time_to_close", snowScrU_TimeToClose);
		if (snowScrU_TotalAgreedChangeCostsFo != null && !snowScrU_TotalAgreedChangeCostsFo.toString().isEmpty()) jsonObject.put("scr_u_total_agreed_change_costs_fo", snowScrU_TotalAgreedChangeCostsFo);
		if (snowScrU_UatSignedDate != null && !snowScrU_UatSignedDate.toString().isEmpty()) jsonObject.put("scr_u_uat_signed_date", snowScrU_UatSignedDate);
		if (snowScrU_UsersAffected != null && !snowScrU_UsersAffected.toString().isEmpty()) jsonObject.put("scr_u_users_affected", snowScrU_UsersAffected);
		if (snowScrU_VerizonException != null && !snowScrU_VerizonException.toString().isEmpty()) jsonObject.put("scr_u_verizon_exception", snowScrU_VerizonException);
		if (snowScrU_WebId != null && !snowScrU_WebId.toString().isEmpty()) jsonObject.put("scr_u_web_id", snowScrU_WebId);
		if (snowScrU_WebUpdate != null && !snowScrU_WebUpdate.toString().isEmpty()) jsonObject.put("scr_u_web_update", snowScrU_WebUpdate);
		if (snowScrUponApproval != null && !snowScrUponApproval.toString().isEmpty()) jsonObject.put("scr_upon_approval", snowScrUponApproval);
		if (snowScrUponReject != null && !snowScrUponReject.toString().isEmpty()) jsonObject.put("scr_upon_reject", snowScrUponReject);
		if (snowScrUrgency != null && !snowScrUrgency.toString().isEmpty()) jsonObject.put("scr_urgency", snowScrUrgency);
		if (snowScrUserInput != null && !snowScrUserInput.toString().isEmpty()) jsonObject.put("scr_user_input", snowScrUserInput);
		if (snowScrWatchList != null && !snowScrWatchList.toString().isEmpty()) jsonObject.put("scr_watch_list", snowScrWatchList);
		if (snowScrWfActivity != null && !snowScrWfActivity.toString().isEmpty()) jsonObject.put("scr_wf_activity", snowScrWfActivity);
		if (snowScrWorkEffort != null && !snowScrWorkEffort.toString().isEmpty()) jsonObject.put("scr_work_effort", snowScrWorkEffort);
		if (snowScrWorkEnd != null && !snowScrWorkEnd.toString().isEmpty()) jsonObject.put("scr_work_end", snowScrWorkEnd);
		if (snowScrWorkNotes != null && !snowScrWorkNotes.toString().isEmpty()) jsonObject.put("scr_work_notes", snowScrWorkNotes);
		if (snowScrWorkStart != null && !snowScrWorkStart.toString().isEmpty()) jsonObject.put("scr_work_start", snowScrWorkStart);
		if (snowTaskslatableActive != null && !snowTaskslatableActive.toString().isEmpty()) jsonObject.put("taskslatable_active", snowTaskslatableActive);
		if (snowTaskslatableBusinessDuration != null && !snowTaskslatableBusinessDuration.toString().isEmpty()) jsonObject.put("taskslatable_business_duration", snowTaskslatableBusinessDuration);
		if (snowTaskslatableBusinessPauseDuration != null && !snowTaskslatableBusinessPauseDuration.toString().isEmpty()) jsonObject.put("taskslatable_business_pause_duration", snowTaskslatableBusinessPauseDuration);
		if (snowTaskslatableBusinessPercentage != null && !snowTaskslatableBusinessPercentage.toString().isEmpty()) jsonObject.put("taskslatable_business_percentage", snowTaskslatableBusinessPercentage);
		if (snowTaskslatableBusinessTimeLeft != null && !snowTaskslatableBusinessTimeLeft.toString().isEmpty()) jsonObject.put("taskslatable_business_time_left", snowTaskslatableBusinessTimeLeft);
		if (snowTaskslatableDuration != null && !snowTaskslatableDuration.toString().isEmpty()) jsonObject.put("taskslatable_duration", snowTaskslatableDuration);
		if (snowTaskslatableEndTime != null && !snowTaskslatableEndTime.toString().isEmpty()) jsonObject.put("taskslatable_end_time", snowTaskslatableEndTime);
		if (snowTaskslatableHasBreached != null && !snowTaskslatableHasBreached.toString().isEmpty()) jsonObject.put("taskslatable_has_breached", snowTaskslatableHasBreached);
		if (snowTaskslatableOriginalBreachTime != null && !snowTaskslatableOriginalBreachTime.toString().isEmpty()) jsonObject.put("taskslatable_original_breach_time", snowTaskslatableOriginalBreachTime);
		if (snowTaskslatablePauseDuration != null && !snowTaskslatablePauseDuration.toString().isEmpty()) jsonObject.put("taskslatable_pause_duration", snowTaskslatablePauseDuration);
		if (snowTaskslatablePauseTime != null && !snowTaskslatablePauseTime.toString().isEmpty()) jsonObject.put("taskslatable_pause_time", snowTaskslatablePauseTime);
		if (snowTaskslatablePercentage != null && !snowTaskslatablePercentage.toString().isEmpty()) jsonObject.put("taskslatable_percentage", snowTaskslatablePercentage);
		if (snowTaskslatablePlannedEndTime != null && !snowTaskslatablePlannedEndTime.toString().isEmpty()) jsonObject.put("taskslatable_planned_end_time", snowTaskslatablePlannedEndTime);
		if (snowTaskslatableSchedule != null && !snowTaskslatableSchedule.toString().isEmpty()) jsonObject.put("taskslatable_schedule", snowTaskslatableSchedule);
		if (snowTaskslatableSla != null && !snowTaskslatableSla.toString().isEmpty()) jsonObject.put("taskslatable_sla", snowTaskslatableSla);
		if (snowTaskslatableStage != null && !snowTaskslatableStage.toString().isEmpty()) jsonObject.put("taskslatable_stage", snowTaskslatableStage);
		if (snowTaskslatableStartTime != null && !snowTaskslatableStartTime.toString().isEmpty()) jsonObject.put("taskslatable_start_time", snowTaskslatableStartTime);
		if (snowTaskslatableSysCreatedBy != null && !snowTaskslatableSysCreatedBy.toString().isEmpty()) jsonObject.put("taskslatable_sys_created_by", snowTaskslatableSysCreatedBy);
		if (snowTaskslatableSysCreatedOn != null && !snowTaskslatableSysCreatedOn.toString().isEmpty()) jsonObject.put("taskslatable_sys_created_on", snowTaskslatableSysCreatedOn);
		if (snowTaskslatableSysId != null && !snowTaskslatableSysId.toString().isEmpty()) jsonObject.put("taskslatable_sys_id", snowTaskslatableSysId);
		if (snowTaskslatableSysModCount != null && !snowTaskslatableSysModCount.toString().isEmpty()) jsonObject.put("taskslatable_sys_mod_count", snowTaskslatableSysModCount);
		if (snowTaskslatableSysTags != null && !snowTaskslatableSysTags.toString().isEmpty()) jsonObject.put("taskslatable_sys_tags", snowTaskslatableSysTags);
		if (snowTaskslatableSysUpdatedBy != null && !snowTaskslatableSysUpdatedBy.toString().isEmpty()) jsonObject.put("taskslatable_sys_updated_by", snowTaskslatableSysUpdatedBy);
		if (snowTaskslatableSysUpdatedOn != null && !snowTaskslatableSysUpdatedOn.toString().isEmpty()) jsonObject.put("taskslatable_sys_updated_on", snowTaskslatableSysUpdatedOn);
		if (snowTaskslatableTask != null && !snowTaskslatableTask.toString().isEmpty()) jsonObject.put("taskslatable_task", snowTaskslatableTask);
		if (snowTaskslatableTimeLeft != null && !snowTaskslatableTimeLeft.toString().isEmpty()) jsonObject.put("taskslatable_time_left", snowTaskslatableTimeLeft);
		if (snowTaskslatableTimezone != null && !snowTaskslatableTimezone.toString().isEmpty()) jsonObject.put("taskslatable_timezone", snowTaskslatableTimezone);
		if (snowTaskslatableU_InScope != null && !snowTaskslatableU_InScope.toString().isEmpty()) jsonObject.put("taskslatable_u_in_scope", snowTaskslatableU_InScope);
		if (snowTaskslatableU_KbArticle != null && !snowTaskslatableU_KbArticle.toString().isEmpty()) jsonObject.put("taskslatable_u_kb_article", snowTaskslatableU_KbArticle);
		
		return jsonObject;
	}

	public String getSnowScrActive() {
		return snowScrActive;
	}

	public void setSnowScrActive(String snowScrActive) {
		this.snowScrActive = snowScrActive;
	}

	public String getSnowScrActivityDue() {
		return snowScrActivityDue;
	}

	public void setSnowScrActivityDue(String snowScrActivityDue) {
		this.snowScrActivityDue = snowScrActivityDue;
	}

	public String getSnowScrAdditionalAssigneeList() {
		return snowScrAdditionalAssigneeList;
	}

	public void setSnowScrAdditionalAssigneeList(String snowScrAdditionalAssigneeList) {
		this.snowScrAdditionalAssigneeList = snowScrAdditionalAssigneeList;
	}

	public String getSnowScrApproval() {
		return snowScrApproval;
	}

	public void setSnowScrApproval(String snowScrApproval) {
		this.snowScrApproval = snowScrApproval;
	}

	public String getSnowScrApprovalHistory() {
		return snowScrApprovalHistory;
	}

	public void setSnowScrApprovalHistory(String snowScrApprovalHistory) {
		this.snowScrApprovalHistory = snowScrApprovalHistory;
	}

	public String getSnowScrApprovalSet() {
		return snowScrApprovalSet;
	}

	public void setSnowScrApprovalSet(String snowScrApprovalSet) {
		this.snowScrApprovalSet = snowScrApprovalSet;
	}

	public String getSnowScrAssignedTo() {
		return snowScrAssignedTo;
	}

	public void setSnowScrAssignedTo(String snowScrAssignedTo) {
		this.snowScrAssignedTo = snowScrAssignedTo;
	}

	public String getSnowScrAssignmentGroup() {
		return snowScrAssignmentGroup;
	}

	public void setSnowScrAssignmentGroup(String snowScrAssignmentGroup) {
		this.snowScrAssignmentGroup = snowScrAssignmentGroup;
	}

	public String getSnowScrBusinessDuration() {
		return snowScrBusinessDuration;
	}

	public void setSnowScrBusinessDuration(String snowScrBusinessDuration) {
		this.snowScrBusinessDuration = snowScrBusinessDuration;
	}

	public String getSnowScrBusinessService() {
		return snowScrBusinessService;
	}

	public void setSnowScrBusinessService(String snowScrBusinessService) {
		this.snowScrBusinessService = snowScrBusinessService;
	}

	public String getSnowScrCalendarDuration() {
		return snowScrCalendarDuration;
	}

	public void setSnowScrCalendarDuration(String snowScrCalendarDuration) {
		this.snowScrCalendarDuration = snowScrCalendarDuration;
	}

	public String getSnowScrCalendarStc() {
		return snowScrCalendarStc;
	}

	public void setSnowScrCalendarStc(String snowScrCalendarStc) {
		this.snowScrCalendarStc = snowScrCalendarStc;
	}

	public String getSnowScrCallerId() {
		return snowScrCallerId;
	}

	public void setSnowScrCallerId(String snowScrCallerId) {
		this.snowScrCallerId = snowScrCallerId;
	}

	public String getSnowScrCategory() {
		return snowScrCategory;
	}

	public void setSnowScrCategory(String snowScrCategory) {
		this.snowScrCategory = snowScrCategory;
	}

	public String getSnowScrCloseCode() {
		return snowScrCloseCode;
	}

	public void setSnowScrCloseCode(String snowScrCloseCode) {
		this.snowScrCloseCode = snowScrCloseCode;
	}

	public String getSnowScrCloseNotes() {
		return snowScrCloseNotes;
	}

	public void setSnowScrCloseNotes(String snowScrCloseNotes) {
		this.snowScrCloseNotes = snowScrCloseNotes;
	}

	public String getSnowScrClosedAt() {
		return snowScrClosedAt;
	}

	public void setSnowScrClosedAt(String snowScrClosedAt) {
		this.snowScrClosedAt = snowScrClosedAt;
	}

	public String getSnowScrClosedBy() {
		return snowScrClosedBy;
	}

	public void setSnowScrClosedBy(String snowScrClosedBy) {
		this.snowScrClosedBy = snowScrClosedBy;
	}

	public String getSnowScrCmdbCi() {
		return snowScrCmdbCi;
	}

	public void setSnowScrCmdbCi(String snowScrCmdbCi) {
		this.snowScrCmdbCi = snowScrCmdbCi;
	}

	public String getSnowScrComments() {
		return snowScrComments;
	}

	public void setSnowScrComments(String snowScrComments) {
		this.snowScrComments = snowScrComments;
	}

	public String getSnowScrCompany() {
		return snowScrCompany;
	}

	public void setSnowScrCompany(String snowScrCompany) {
		this.snowScrCompany = snowScrCompany;
	}

	public String getSnowScrContactType() {
		return snowScrContactType;
	}

	public void setSnowScrContactType(String snowScrContactType) {
		this.snowScrContactType = snowScrContactType;
	}

	public String getSnowScrContract() {
		return snowScrContract;
	}

	public void setSnowScrContract(String snowScrContract) {
		this.snowScrContract = snowScrContract;
	}

	public String getSnowScrCorrelationDisplay() {
		return snowScrCorrelationDisplay;
	}

	public void setSnowScrCorrelationDisplay(String snowScrCorrelationDisplay) {
		this.snowScrCorrelationDisplay = snowScrCorrelationDisplay;
	}

	public String getSnowScrCorrelationId() {
		return snowScrCorrelationId;
	}

	public void setSnowScrCorrelationId(String snowScrCorrelationId) {
		this.snowScrCorrelationId = snowScrCorrelationId;
	}

	public String getSnowScrDeliveryAddress() {
		return snowScrDeliveryAddress;
	}

	public void setSnowScrDeliveryAddress(String snowScrDeliveryAddress) {
		this.snowScrDeliveryAddress = snowScrDeliveryAddress;
	}

	public String getSnowScrDeliveryPlan() {
		return snowScrDeliveryPlan;
	}

	public void setSnowScrDeliveryPlan(String snowScrDeliveryPlan) {
		this.snowScrDeliveryPlan = snowScrDeliveryPlan;
	}

	public String getSnowScrDescription() {
		return snowScrDescription;
	}

	public void setSnowScrDescription(String snowScrDescription) {
		this.snowScrDescription = snowScrDescription;
	}

	public String getSnowScrDueDate() {
		return snowScrDueDate;
	}

	public void setSnowScrDueDate(String snowScrDueDate) {
		this.snowScrDueDate = snowScrDueDate;
	}

	public String getSnowScrEffort() {
		return snowScrEffort;
	}

	public void setSnowScrEffort(String snowScrEffort) {
		this.snowScrEffort = snowScrEffort;
	}

	public String getSnowScrEndDate() {
		return snowScrEndDate;
	}

	public void setSnowScrEndDate(String snowScrEndDate) {
		this.snowScrEndDate = snowScrEndDate;
	}

	public String getSnowScrEscalation() {
		return snowScrEscalation;
	}

	public void setSnowScrEscalation(String snowScrEscalation) {
		this.snowScrEscalation = snowScrEscalation;
	}

	public String getSnowScrExpectedStart() {
		return snowScrExpectedStart;
	}

	public void setSnowScrExpectedStart(String snowScrExpectedStart) {
		this.snowScrExpectedStart = snowScrExpectedStart;
	}

	public String getSnowScrFollowUp() {
		return snowScrFollowUp;
	}

	public void setSnowScrFollowUp(String snowScrFollowUp) {
		this.snowScrFollowUp = snowScrFollowUp;
	}

	public String getSnowScrGroupList() {
		return snowScrGroupList;
	}

	public void setSnowScrGroupList(String snowScrGroupList) {
		this.snowScrGroupList = snowScrGroupList;
	}

	public String getSnowScrImpact() {
		return snowScrImpact;
	}

	public void setSnowScrImpact(String snowScrImpact) {
		this.snowScrImpact = snowScrImpact;
	}

	public String getSnowScrKnowledge() {
		return snowScrKnowledge;
	}

	public void setSnowScrKnowledge(String snowScrKnowledge) {
		this.snowScrKnowledge = snowScrKnowledge;
	}

	public String getSnowScrLocation() {
		return snowScrLocation;
	}

	public void setSnowScrLocation(String snowScrLocation) {
		this.snowScrLocation = snowScrLocation;
	}

	public String getSnowScrMadeSla() {
		return snowScrMadeSla;
	}

	public void setSnowScrMadeSla(String snowScrMadeSla) {
		this.snowScrMadeSla = snowScrMadeSla;
	}

	public String getSnowScrNotify() {
		return snowScrNotify;
	}

	public void setSnowScrNotify(String snowScrNotify) {
		this.snowScrNotify = snowScrNotify;
	}

	public String getSnowScrNumber() {
		return snowScrNumber;
	}

	public void setSnowScrNumber(String snowScrNumber) {
		this.snowScrNumber = snowScrNumber;
	}

	public String getSnowScrOpenedAt() {
		return snowScrOpenedAt;
	}

	public void setSnowScrOpenedAt(String snowScrOpenedAt) {
		this.snowScrOpenedAt = snowScrOpenedAt;
	}

	public String getSnowScrOpenedBy() {
		return snowScrOpenedBy;
	}

	public void setSnowScrOpenedBy(String snowScrOpenedBy) {
		this.snowScrOpenedBy = snowScrOpenedBy;
	}

	public String getSnowScrOrder() {
		return snowScrOrder;
	}

	public void setSnowScrOrder(String snowScrOrder) {
		this.snowScrOrder = snowScrOrder;
	}

	public String getSnowScrParent() {
		return snowScrParent;
	}

	public void setSnowScrParent(String snowScrParent) {
		this.snowScrParent = snowScrParent;
	}

	public String getSnowScrPrice() {
		return snowScrPrice;
	}

	public void setSnowScrPrice(String snowScrPrice) {
		this.snowScrPrice = snowScrPrice;
	}

	public String getSnowScrPriority() {
		return snowScrPriority;
	}

	public void setSnowScrPriority(String snowScrPriority) {
		this.snowScrPriority = snowScrPriority;
	}

	public String getSnowScrReassignmentCount() {
		return snowScrReassignmentCount;
	}

	public void setSnowScrReassignmentCount(String snowScrReassignmentCount) {
		this.snowScrReassignmentCount = snowScrReassignmentCount;
	}

	public String getSnowScrRequestState() {
		return snowScrRequestState;
	}

	public void setSnowScrRequestState(String snowScrRequestState) {
		this.snowScrRequestState = snowScrRequestState;
	}

	public String getSnowScrRequestedDate() {
		return snowScrRequestedDate;
	}

	public void setSnowScrRequestedDate(String snowScrRequestedDate) {
		this.snowScrRequestedDate = snowScrRequestedDate;
	}

	public String getSnowScrRequestedFor() {
		return snowScrRequestedFor;
	}

	public void setSnowScrRequestedFor(String snowScrRequestedFor) {
		this.snowScrRequestedFor = snowScrRequestedFor;
	}

	public String getSnowScrRfc() {
		return snowScrRfc;
	}

	public void setSnowScrRfc(String snowScrRfc) {
		this.snowScrRfc = snowScrRfc;
	}

	public String getSnowScrShortDescription() {
		return snowScrShortDescription;
	}

	public void setSnowScrShortDescription(String snowScrShortDescription) {
		this.snowScrShortDescription = snowScrShortDescription;
	}

	public String getSnowScrSkills() {
		return snowScrSkills;
	}

	public void setSnowScrSkills(String snowScrSkills) {
		this.snowScrSkills = snowScrSkills;
	}

	public String getSnowScrSlaDue() {
		return snowScrSlaDue;
	}

	public void setSnowScrSlaDue(String snowScrSlaDue) {
		this.snowScrSlaDue = snowScrSlaDue;
	}

	public String getSnowScrSpecialInstructions() {
		return snowScrSpecialInstructions;
	}

	public void setSnowScrSpecialInstructions(String snowScrSpecialInstructions) {
		this.snowScrSpecialInstructions = snowScrSpecialInstructions;
	}

	public String getSnowScrStage() {
		return snowScrStage;
	}

	public void setSnowScrStage(String snowScrStage) {
		this.snowScrStage = snowScrStage;
	}

	public String getSnowScrStartDate() {
		return snowScrStartDate;
	}

	public void setSnowScrStartDate(String snowScrStartDate) {
		this.snowScrStartDate = snowScrStartDate;
	}

	public String getSnowScrState() {
		return snowScrState;
	}

	public void setSnowScrState(String snowScrState) {
		this.snowScrState = snowScrState;
	}

	public String getSnowScrStatus() {
		return snowScrStatus;
	}

	public void setSnowScrStatus(String snowScrStatus) {
		this.snowScrStatus = snowScrStatus;
	}

	public String getSnowScrSubcategory() {
		return snowScrSubcategory;
	}

	public void setSnowScrSubcategory(String snowScrSubcategory) {
		this.snowScrSubcategory = snowScrSubcategory;
	}

	public String getSnowScrSysClassName() {
		return snowScrSysClassName;
	}

	public void setSnowScrSysClassName(String snowScrSysClassName) {
		this.snowScrSysClassName = snowScrSysClassName;
	}

	public String getSnowScrSysCreatedBy() {
		return snowScrSysCreatedBy;
	}

	public void setSnowScrSysCreatedBy(String snowScrSysCreatedBy) {
		this.snowScrSysCreatedBy = snowScrSysCreatedBy;
	}

	public String getSnowScrSysCreatedOn() {
		return snowScrSysCreatedOn;
	}

	public void setSnowScrSysCreatedOn(String snowScrSysCreatedOn) {
		this.snowScrSysCreatedOn = snowScrSysCreatedOn;
	}

	public String getSnowScrSysDomain() {
		return snowScrSysDomain;
	}

	public void setSnowScrSysDomain(String snowScrSysDomain) {
		this.snowScrSysDomain = snowScrSysDomain;
	}

	public String getSnowScrSysId() {
		return snowScrSysId;
	}

	public void setSnowScrSysId(String snowScrSysId) {
		this.snowScrSysId = snowScrSysId;
	}

	public String getSnowScrSysModCount() {
		return snowScrSysModCount;
	}

	public void setSnowScrSysModCount(String snowScrSysModCount) {
		this.snowScrSysModCount = snowScrSysModCount;
	}

	public String getSnowScrSysTags() {
		return snowScrSysTags;
	}

	public void setSnowScrSysTags(String snowScrSysTags) {
		this.snowScrSysTags = snowScrSysTags;
	}

	public String getSnowScrSysUpdatedBy() {
		return snowScrSysUpdatedBy;
	}

	public void setSnowScrSysUpdatedBy(String snowScrSysUpdatedBy) {
		this.snowScrSysUpdatedBy = snowScrSysUpdatedBy;
	}

	public String getSnowScrSysUpdatedOn() {
		return snowScrSysUpdatedOn;
	}

	public void setSnowScrSysUpdatedOn(String snowScrSysUpdatedOn) {
		this.snowScrSysUpdatedOn = snowScrSysUpdatedOn;
	}

	public String getSnowScrTimeWorked() {
		return snowScrTimeWorked;
	}

	public void setSnowScrTimeWorked(String snowScrTimeWorked) {
		this.snowScrTimeWorked = snowScrTimeWorked;
	}

	public String getSnowScrU_3RdLineSrt() {
		return snowScrU_3RdLineSrt;
	}

	public void setSnowScrU_3RdLineSrt(String snowScrU_3RdLineSrt) {
		this.snowScrU_3RdLineSrt = snowScrU_3RdLineSrt;
	}

	public String getSnowScrU_ACCosts() {
		return snowScrU_ACCosts;
	}

	public void setSnowScrU_ACCosts(String snowScrU_ACCosts) {
		this.snowScrU_ACCosts = snowScrU_ACCosts;
	}

	public String getSnowScrU_ADueDate() {
		return snowScrU_ADueDate;
	}

	public void setSnowScrU_ADueDate(String snowScrU_ADueDate) {
		this.snowScrU_ADueDate = snowScrU_ADueDate;
	}

	public String getSnowScrU_AECosts() {
		return snowScrU_AECosts;
	}

	public void setSnowScrU_AECosts(String snowScrU_AECosts) {
		this.snowScrU_AECosts = snowScrU_AECosts;
	}

	public String getSnowScrU_ALiveDate() {
		return snowScrU_ALiveDate;
	}

	public void setSnowScrU_ALiveDate(String snowScrU_ALiveDate) {
		this.snowScrU_ALiveDate = snowScrU_ALiveDate;
	}

	public String getSnowScrU_ARCDate() {
		return snowScrU_ARCDate;
	}

	public void setSnowScrU_ARCDate(String snowScrU_ARCDate) {
		this.snowScrU_ARCDate = snowScrU_ARCDate;
	}

	public String getSnowScrU_AU_MDate() {
		return snowScrU_AU_MDate;
	}

	public void setSnowScrU_AU_MDate(String snowScrU_AU_MDate) {
		this.snowScrU_AU_MDate = snowScrU_AU_MDate;
	}

	public String getSnowScrU_AcknowldgeFeedback() {
		return snowScrU_AcknowldgeFeedback;
	}

	public void setSnowScrU_AcknowldgeFeedback(String snowScrU_AcknowldgeFeedback) {
		this.snowScrU_AcknowldgeFeedback = snowScrU_AcknowldgeFeedback;
	}

	public String getSnowScrU_Acknowledged() {
		return snowScrU_Acknowledged;
	}

	public void setSnowScrU_Acknowledged(String snowScrU_Acknowledged) {
		this.snowScrU_Acknowledged = snowScrU_Acknowledged;
	}

	public String getSnowScrU_ActiveProbInc() {
		return snowScrU_ActiveProbInc;
	}

	public void setSnowScrU_ActiveProbInc(String snowScrU_ActiveProbInc) {
		this.snowScrU_ActiveProbInc = snowScrU_ActiveProbInc;
	}

	public String getSnowScrU_ActualEffort() {
		return snowScrU_ActualEffort;
	}

	public void setSnowScrU_ActualEffort(String snowScrU_ActualEffort) {
		this.snowScrU_ActualEffort = snowScrU_ActualEffort;
	}

	public String getSnowScrU_ActualStart() {
		return snowScrU_ActualStart;
	}

	public void setSnowScrU_ActualStart(String snowScrU_ActualStart) {
		this.snowScrU_ActualStart = snowScrU_ActualStart;
	}

	public String getSnowScrU_ActualUatDate() {
		return snowScrU_ActualUatDate;
	}

	public void setSnowScrU_ActualUatDate(String snowScrU_ActualUatDate) {
		this.snowScrU_ActualUatDate = snowScrU_ActualUatDate;
	}

	public String getSnowScrU_AffectedAsset() {
		return snowScrU_AffectedAsset;
	}

	public void setSnowScrU_AffectedAsset(String snowScrU_AffectedAsset) {
		this.snowScrU_AffectedAsset = snowScrU_AffectedAsset;
	}

	public String getSnowScrU_AffectedUser() {
		return snowScrU_AffectedUser;
	}

	public void setSnowScrU_AffectedUser(String snowScrU_AffectedUser) {
		this.snowScrU_AffectedUser = snowScrU_AffectedUser;
	}

	public String getSnowScrU_AofDateTime() {
		return snowScrU_AofDateTime;
	}

	public void setSnowScrU_AofDateTime(String snowScrU_AofDateTime) {
		this.snowScrU_AofDateTime = snowScrU_AofDateTime;
	}

	public String getSnowScrU_AofPass() {
		return snowScrU_AofPass;
	}

	public void setSnowScrU_AofPass(String snowScrU_AofPass) {
		this.snowScrU_AofPass = snowScrU_AofPass;
	}

	public String getSnowScrU_AofState() {
		return snowScrU_AofState;
	}

	public void setSnowScrU_AofState(String snowScrU_AofState) {
		this.snowScrU_AofState = snowScrU_AofState;
	}

	public String getSnowScrU_AofWorkgroup() {
		return snowScrU_AofWorkgroup;
	}

	public void setSnowScrU_AofWorkgroup(String snowScrU_AofWorkgroup) {
		this.snowScrU_AofWorkgroup = snowScrU_AofWorkgroup;
	}

	public String getSnowScrU_AosDateTime() {
		return snowScrU_AosDateTime;
	}

	public void setSnowScrU_AosDateTime(String snowScrU_AosDateTime) {
		this.snowScrU_AosDateTime = snowScrU_AosDateTime;
	}

	public String getSnowScrU_AosPass() {
		return snowScrU_AosPass;
	}

	public void setSnowScrU_AosPass(String snowScrU_AosPass) {
		this.snowScrU_AosPass = snowScrU_AosPass;
	}

	public String getSnowScrU_AosState() {
		return snowScrU_AosState;
	}

	public void setSnowScrU_AosState(String snowScrU_AosState) {
		this.snowScrU_AosState = snowScrU_AosState;
	}

	public String getSnowScrU_AosWorkgroup() {
		return snowScrU_AosWorkgroup;
	}

	public void setSnowScrU_AosWorkgroup(String snowScrU_AosWorkgroup) {
		this.snowScrU_AosWorkgroup = snowScrU_AosWorkgroup;
	}

	public String getSnowScrU_AssetCode() {
		return snowScrU_AssetCode;
	}

	public void setSnowScrU_AssetCode(String snowScrU_AssetCode) {
		this.snowScrU_AssetCode = snowScrU_AssetCode;
	}

	public String getSnowScrU_AssetString() {
		return snowScrU_AssetString;
	}

	public void setSnowScrU_AssetString(String snowScrU_AssetString) {
		this.snowScrU_AssetString = snowScrU_AssetString;
	}

	public String getSnowScrU_AssignedToBladelogic() {
		return snowScrU_AssignedToBladelogic;
	}

	public void setSnowScrU_AssignedToBladelogic(String snowScrU_AssignedToBladelogic) {
		this.snowScrU_AssignedToBladelogic = snowScrU_AssignedToBladelogic;
	}

	public String getSnowScrU_AssignmentStatus() {
		return snowScrU_AssignmentStatus;
	}

	public void setSnowScrU_AssignmentStatus(String snowScrU_AssignmentStatus) {
		this.snowScrU_AssignmentStatus = snowScrU_AssignmentStatus;
	}

	public String getSnowScrU_AttachmentsAdded() {
		return snowScrU_AttachmentsAdded;
	}

	public void setSnowScrU_AttachmentsAdded(String snowScrU_AttachmentsAdded) {
		this.snowScrU_AttachmentsAdded = snowScrU_AttachmentsAdded;
	}

	public String getSnowScrU_AuditCode() {
		return snowScrU_AuditCode;
	}

	public void setSnowScrU_AuditCode(String snowScrU_AuditCode) {
		this.snowScrU_AuditCode = snowScrU_AuditCode;
	}

	public String getSnowScrU_AutoClose() {
		return snowScrU_AutoClose;
	}

	public void setSnowScrU_AutoClose(String snowScrU_AutoClose) {
		this.snowScrU_AutoClose = snowScrU_AutoClose;
	}

	public String getSnowScrU_AutoCloseTicket() {
		return snowScrU_AutoCloseTicket;
	}

	public void setSnowScrU_AutoCloseTicket(String snowScrU_AutoCloseTicket) {
		this.snowScrU_AutoCloseTicket = snowScrU_AutoCloseTicket;
	}

	public String getSnowScrU_AutoParm1() {
		return snowScrU_AutoParm1;
	}

	public void setSnowScrU_AutoParm1(String snowScrU_AutoParm1) {
		this.snowScrU_AutoParm1 = snowScrU_AutoParm1;
	}

	public String getSnowScrU_AutoParm2() {
		return snowScrU_AutoParm2;
	}

	public void setSnowScrU_AutoParm2(String snowScrU_AutoParm2) {
		this.snowScrU_AutoParm2 = snowScrU_AutoParm2;
	}

	public String getSnowScrU_AutoParm3() {
		return snowScrU_AutoParm3;
	}

	public void setSnowScrU_AutoParm3(String snowScrU_AutoParm3) {
		this.snowScrU_AutoParm3 = snowScrU_AutoParm3;
	}

	public String getSnowScrU_AutoParm4() {
		return snowScrU_AutoParm4;
	}

	public void setSnowScrU_AutoParm4(String snowScrU_AutoParm4) {
		this.snowScrU_AutoParm4 = snowScrU_AutoParm4;
	}

	public String getSnowScrU_AutoParm5() {
		return snowScrU_AutoParm5;
	}

	public void setSnowScrU_AutoParm5(String snowScrU_AutoParm5) {
		this.snowScrU_AutoParm5 = snowScrU_AutoParm5;
	}

	public String getSnowScrU_AutoTarget() {
		return snowScrU_AutoTarget;
	}

	public void setSnowScrU_AutoTarget(String snowScrU_AutoTarget) {
		this.snowScrU_AutoTarget = snowScrU_AutoTarget;
	}

	public String getSnowScrU_AutoType() {
		return snowScrU_AutoType;
	}

	public void setSnowScrU_AutoType(String snowScrU_AutoType) {
		this.snowScrU_AutoType = snowScrU_AutoType;
	}

	public String getSnowScrU_AvailAddComments() {
		return snowScrU_AvailAddComments;
	}

	public void setSnowScrU_AvailAddComments(String snowScrU_AvailAddComments) {
		this.snowScrU_AvailAddComments = snowScrU_AvailAddComments;
	}

	public String getSnowScrU_AvailTechSvc() {
		return snowScrU_AvailTechSvc;
	}

	public void setSnowScrU_AvailTechSvc(String snowScrU_AvailTechSvc) {
		this.snowScrU_AvailTechSvc = snowScrU_AvailTechSvc;
	}

	public String getSnowScrU_AvailabilityReport() {
		return snowScrU_AvailabilityReport;
	}

	public void setSnowScrU_AvailabilityReport(String snowScrU_AvailabilityReport) {
		this.snowScrU_AvailabilityReport = snowScrU_AvailabilityReport;
	}

	public String getSnowScrU_BSManager() {
		return snowScrU_BSManager;
	}

	public void setSnowScrU_BSManager(String snowScrU_BSManager) {
		this.snowScrU_BSManager = snowScrU_BSManager;
	}

	public String getSnowScrU_BenefitCategory() {
		return snowScrU_BenefitCategory;
	}

	public void setSnowScrU_BenefitCategory(String snowScrU_BenefitCategory) {
		this.snowScrU_BenefitCategory = snowScrU_BenefitCategory;
	}

	public String getSnowScrU_BenefitsCat() {
		return snowScrU_BenefitsCat;
	}

	public void setSnowScrU_BenefitsCat(String snowScrU_BenefitsCat) {
		this.snowScrU_BenefitsCat = snowScrU_BenefitsCat;
	}

	public String getSnowScrU_BnlApproval() {
		return snowScrU_BnlApproval;
	}

	public void setSnowScrU_BnlApproval(String snowScrU_BnlApproval) {
		this.snowScrU_BnlApproval = snowScrU_BnlApproval;
	}

	public String getSnowScrU_BsdResolutionBy() {
		return snowScrU_BsdResolutionBy;
	}

	public void setSnowScrU_BsdResolutionBy(String snowScrU_BsdResolutionBy) {
		this.snowScrU_BsdResolutionBy = snowScrU_BsdResolutionBy;
	}

	public String getSnowScrU_BudgetCode() {
		return snowScrU_BudgetCode;
	}

	public void setSnowScrU_BudgetCode(String snowScrU_BudgetCode) {
		this.snowScrU_BudgetCode = snowScrU_BudgetCode;
	}

	public String getSnowScrU_BudgetHolder() {
		return snowScrU_BudgetHolder;
	}

	public void setSnowScrU_BudgetHolder(String snowScrU_BudgetHolder) {
		this.snowScrU_BudgetHolder = snowScrU_BudgetHolder;
	}

	public String getSnowScrU_BusinessBenefit() {
		return snowScrU_BusinessBenefit;
	}

	public void setSnowScrU_BusinessBenefit(String snowScrU_BusinessBenefit) {
		this.snowScrU_BusinessBenefit = snowScrU_BusinessBenefit;
	}

	public String getSnowScrU_BusinessObjective() {
		return snowScrU_BusinessObjective;
	}

	public void setSnowScrU_BusinessObjective(String snowScrU_BusinessObjective) {
		this.snowScrU_BusinessObjective = snowScrU_BusinessObjective;
	}

	public String getSnowScrU_BusinessService() {
		return snowScrU_BusinessService;
	}

	public void setSnowScrU_BusinessService(String snowScrU_BusinessService) {
		this.snowScrU_BusinessService = snowScrU_BusinessService;
	}

	public String getSnowScrU_CRefNumber() {
		return snowScrU_CRefNumber;
	}

	public void setSnowScrU_CRefNumber(String snowScrU_CRefNumber) {
		this.snowScrU_CRefNumber = snowScrU_CRefNumber;
	}

	public String getSnowScrU_CallCaptureComments() {
		return snowScrU_CallCaptureComments;
	}

	public void setSnowScrU_CallCaptureComments(String snowScrU_CallCaptureComments) {
		this.snowScrU_CallCaptureComments = snowScrU_CallCaptureComments;
	}

	public String getSnowScrU_CallHandlingComments() {
		return snowScrU_CallHandlingComments;
	}

	public void setSnowScrU_CallHandlingComments(String snowScrU_CallHandlingComments) {
		this.snowScrU_CallHandlingComments = snowScrU_CallHandlingComments;
	}

	public String getSnowScrU_CauseItem() {
		return snowScrU_CauseItem;
	}

	public void setSnowScrU_CauseItem(String snowScrU_CauseItem) {
		this.snowScrU_CauseItem = snowScrU_CauseItem;
	}

	public String getSnowScrU_CausedBy() {
		return snowScrU_CausedBy;
	}

	public void setSnowScrU_CausedBy(String snowScrU_CausedBy) {
		this.snowScrU_CausedBy = snowScrU_CausedBy;
	}

	public String getSnowScrU_ChangeManager() {
		return snowScrU_ChangeManager;
	}

	public void setSnowScrU_ChangeManager(String snowScrU_ChangeManager) {
		this.snowScrU_ChangeManager = snowScrU_ChangeManager;
	}

	public String getSnowScrU_CiCategory() {
		return snowScrU_CiCategory;
	}

	public void setSnowScrU_CiCategory(String snowScrU_CiCategory) {
		this.snowScrU_CiCategory = snowScrU_CiCategory;
	}

	public String getSnowScrU_CiClassification() {
		return snowScrU_CiClassification;
	}

	public void setSnowScrU_CiClassification(String snowScrU_CiClassification) {
		this.snowScrU_CiClassification = snowScrU_CiClassification;
	}

	public String getSnowScrU_CiSubcategory() {
		return snowScrU_CiSubcategory;
	}

	public void setSnowScrU_CiSubcategory(String snowScrU_CiSubcategory) {
		this.snowScrU_CiSubcategory = snowScrU_CiSubcategory;
	}

	public String getSnowScrU_CiSubclassification() {
		return snowScrU_CiSubclassification;
	}

	public void setSnowScrU_CiSubclassification(String snowScrU_CiSubclassification) {
		this.snowScrU_CiSubclassification = snowScrU_CiSubclassification;
	}

	public String getSnowScrU_ClarityCode() {
		return snowScrU_ClarityCode;
	}

	public void setSnowScrU_ClarityCode(String snowScrU_ClarityCode) {
		this.snowScrU_ClarityCode = snowScrU_ClarityCode;
	}

	public String getSnowScrU_Classification() {
		return snowScrU_Classification;
	}

	public void setSnowScrU_Classification(String snowScrU_Classification) {
		this.snowScrU_Classification = snowScrU_Classification;
	}

	public String getSnowScrU_ClosedCentrally() {
		return snowScrU_ClosedCentrally;
	}

	public void setSnowScrU_ClosedCentrally(String snowScrU_ClosedCentrally) {
		this.snowScrU_ClosedCentrally = snowScrU_ClosedCentrally;
	}

	public String getSnowScrU_ClosedPeriod() {
		return snowScrU_ClosedPeriod;
	}

	public void setSnowScrU_ClosedPeriod(String snowScrU_ClosedPeriod) {
		this.snowScrU_ClosedPeriod = snowScrU_ClosedPeriod;
	}

	public String getSnowScrU_ClosureCategory() {
		return snowScrU_ClosureCategory;
	}

	public void setSnowScrU_ClosureCategory(String snowScrU_ClosureCategory) {
		this.snowScrU_ClosureCategory = snowScrU_ClosureCategory;
	}

	public String getSnowScrU_CommentType() {
		return snowScrU_CommentType;
	}

	public void setSnowScrU_CommentType(String snowScrU_CommentType) {
		this.snowScrU_CommentType = snowScrU_CommentType;
	}

	public String getSnowScrU_CommentTypeHandling() {
		return snowScrU_CommentTypeHandling;
	}

	public void setSnowScrU_CommentTypeHandling(String snowScrU_CommentTypeHandling) {
		this.snowScrU_CommentTypeHandling = snowScrU_CommentTypeHandling;
	}

	public String getSnowScrU_CommentsAndWorkNotes() {
		return snowScrU_CommentsAndWorkNotes;
	}

	public void setSnowScrU_CommentsAndWorkNotes(String snowScrU_CommentsAndWorkNotes) {
		this.snowScrU_CommentsAndWorkNotes = snowScrU_CommentsAndWorkNotes;
	}

	public String getSnowScrU_CopyComments() {
		return snowScrU_CopyComments;
	}

	public void setSnowScrU_CopyComments(String snowScrU_CopyComments) {
		this.snowScrU_CopyComments = snowScrU_CopyComments;
	}

	public String getSnowScrU_CopySubject() {
		return snowScrU_CopySubject;
	}

	public void setSnowScrU_CopySubject(String snowScrU_CopySubject) {
		this.snowScrU_CopySubject = snowScrU_CopySubject;
	}

	public String getSnowScrU_Country() {
		return snowScrU_Country;
	}

	public void setSnowScrU_Country(String snowScrU_Country) {
		this.snowScrU_Country = snowScrU_Country;
	}

	public String getSnowScrU_Csr() {
		return snowScrU_Csr;
	}

	public void setSnowScrU_Csr(String snowScrU_Csr) {
		this.snowScrU_Csr = snowScrU_Csr;
	}

	public String getSnowScrU_CurrencyInEuro() {
		return snowScrU_CurrencyInEuro;
	}

	public void setSnowScrU_CurrencyInEuro(String snowScrU_CurrencyInEuro) {
		this.snowScrU_CurrencyInEuro = snowScrU_CurrencyInEuro;
	}

	public String getSnowScrU_CurrencyInGbp() {
		return snowScrU_CurrencyInGbp;
	}

	public void setSnowScrU_CurrencyInGbp(String snowScrU_CurrencyInGbp) {
		this.snowScrU_CurrencyInGbp = snowScrU_CurrencyInGbp;
	}

	public String getSnowScrU_DesktopAssetNumber() {
		return snowScrU_DesktopAssetNumber;
	}

	public void setSnowScrU_DesktopAssetNumber(String snowScrU_DesktopAssetNumber) {
		this.snowScrU_DesktopAssetNumber = snowScrU_DesktopAssetNumber;
	}

	public String getSnowScrU_DesktopMake() {
		return snowScrU_DesktopMake;
	}

	public void setSnowScrU_DesktopMake(String snowScrU_DesktopMake) {
		this.snowScrU_DesktopMake = snowScrU_DesktopMake;
	}

	public String getSnowScrU_DesktopModel() {
		return snowScrU_DesktopModel;
	}

	public void setSnowScrU_DesktopModel(String snowScrU_DesktopModel) {
		this.snowScrU_DesktopModel = snowScrU_DesktopModel;
	}

	public String getSnowScrU_DesktopSN() {
		return snowScrU_DesktopSN;
	}

	public void setSnowScrU_DesktopSN(String snowScrU_DesktopSN) {
		this.snowScrU_DesktopSN = snowScrU_DesktopSN;
	}

	public String getSnowScrU_EAgreedDate() {
		return snowScrU_EAgreedDate;
	}

	public void setSnowScrU_EAgreedDate(String snowScrU_EAgreedDate) {
		this.snowScrU_EAgreedDate = snowScrU_EAgreedDate;
	}

	public String getSnowScrU_EDueDate() {
		return snowScrU_EDueDate;
	}

	public void setSnowScrU_EDueDate(String snowScrU_EDueDate) {
		this.snowScrU_EDueDate = snowScrU_EDueDate;
	}

	public String getSnowScrU_EIssuedDate() {
		return snowScrU_EIssuedDate;
	}

	public void setSnowScrU_EIssuedDate(String snowScrU_EIssuedDate) {
		this.snowScrU_EIssuedDate = snowScrU_EIssuedDate;
	}

	public String getSnowScrU_EProjectCosts() {
		return snowScrU_EProjectCosts;
	}

	public void setSnowScrU_EProjectCosts(String snowScrU_EProjectCosts) {
		this.snowScrU_EProjectCosts = snowScrU_EProjectCosts;
	}

	public String getSnowScrU_EReadyDate() {
		return snowScrU_EReadyDate;
	}

	public void setSnowScrU_EReadyDate(String snowScrU_EReadyDate) {
		this.snowScrU_EReadyDate = snowScrU_EReadyDate;
	}

	public String getSnowScrU_EffortDays() {
		return snowScrU_EffortDays;
	}

	public void setSnowScrU_EffortDays(String snowScrU_EffortDays) {
		this.snowScrU_EffortDays = snowScrU_EffortDays;
	}

	public String getSnowScrU_Escalated() {
		return snowScrU_Escalated;
	}

	public void setSnowScrU_Escalated(String snowScrU_Escalated) {
		this.snowScrU_Escalated = snowScrU_Escalated;
	}

	public String getSnowScrU_ExpertHelp() {
		return snowScrU_ExpertHelp;
	}

	public void setSnowScrU_ExpertHelp(String snowScrU_ExpertHelp) {
		this.snowScrU_ExpertHelp = snowScrU_ExpertHelp;
	}

	public String getSnowScrU_ExternalRef() {
		return snowScrU_ExternalRef;
	}

	public void setSnowScrU_ExternalRef(String snowScrU_ExternalRef) {
		this.snowScrU_ExternalRef = snowScrU_ExternalRef;
	}

	public String getSnowScrU_FLiveDate() {
		return snowScrU_FLiveDate;
	}

	public void setSnowScrU_FLiveDate(String snowScrU_FLiveDate) {
		this.snowScrU_FLiveDate = snowScrU_FLiveDate;
	}

	public String getSnowScrU_FRCDate() {
		return snowScrU_FRCDate;
	}

	public void setSnowScrU_FRCDate(String snowScrU_FRCDate) {
		this.snowScrU_FRCDate = snowScrU_FRCDate;
	}

	public String getSnowScrU_FeedbackCode() {
		return snowScrU_FeedbackCode;
	}

	public void setSnowScrU_FeedbackCode(String snowScrU_FeedbackCode) {
		this.snowScrU_FeedbackCode = snowScrU_FeedbackCode;
	}

	public String getSnowScrU_FeedbackCodeHandling() {
		return snowScrU_FeedbackCodeHandling;
	}

	public void setSnowScrU_FeedbackCodeHandling(String snowScrU_FeedbackCodeHandling) {
		this.snowScrU_FeedbackCodeHandling = snowScrU_FeedbackCodeHandling;
	}

	public String getSnowScrU_FirstDeadline() {
		return snowScrU_FirstDeadline;
	}

	public void setSnowScrU_FirstDeadline(String snowScrU_FirstDeadline) {
		this.snowScrU_FirstDeadline = snowScrU_FirstDeadline;
	}

	public String getSnowScrU_FirstTimeFix() {
		return snowScrU_FirstTimeFix;
	}

	public void setSnowScrU_FirstTimeFix(String snowScrU_FirstTimeFix) {
		this.snowScrU_FirstTimeFix = snowScrU_FirstTimeFix;
	}

	public String getSnowScrU_Folder() {
		return snowScrU_Folder;
	}

	public void setSnowScrU_Folder(String snowScrU_Folder) {
		this.snowScrU_Folder = snowScrU_Folder;
	}

	public String getSnowScrU_ForecastU_MDate() {
		return snowScrU_ForecastU_MDate;
	}

	public void setSnowScrU_ForecastU_MDate(String snowScrU_ForecastU_MDate) {
		this.snowScrU_ForecastU_MDate = snowScrU_ForecastU_MDate;
	}

	public String getSnowScrU_ForecastUatDate() {
		return snowScrU_ForecastUatDate;
	}

	public void setSnowScrU_ForecastUatDate(String snowScrU_ForecastUatDate) {
		this.snowScrU_ForecastUatDate = snowScrU_ForecastUatDate;
	}

	public String getSnowScrU_FunctionTeam() {
		return snowScrU_FunctionTeam;
	}

	public void setSnowScrU_FunctionTeam(String snowScrU_FunctionTeam) {
		this.snowScrU_FunctionTeam = snowScrU_FunctionTeam;
	}

	public String getSnowScrU_HpException() {
		return snowScrU_HpException;
	}

	public void setSnowScrU_HpException(String snowScrU_HpException) {
		this.snowScrU_HpException = snowScrU_HpException;
	}

	public String getSnowScrU_ImpBreakdown() {
		return snowScrU_ImpBreakdown;
	}

	public void setSnowScrU_ImpBreakdown(String snowScrU_ImpBreakdown) {
		this.snowScrU_ImpBreakdown = snowScrU_ImpBreakdown;
	}

	public String getSnowScrU_ImsRef() {
		return snowScrU_ImsRef;
	}

	public void setSnowScrU_ImsRef(String snowScrU_ImsRef) {
		this.snowScrU_ImsRef = snowScrU_ImsRef;
	}

	public String getSnowScrU_InfosysException() {
		return snowScrU_InfosysException;
	}

	public void setSnowScrU_InfosysException(String snowScrU_InfosysException) {
		this.snowScrU_InfosysException = snowScrU_InfosysException;
	}

	public String getSnowScrU_InitialAssignment() {
		return snowScrU_InitialAssignment;
	}

	public void setSnowScrU_InitialAssignment(String snowScrU_InitialAssignment) {
		this.snowScrU_InitialAssignment = snowScrU_InitialAssignment;
	}

	public String getSnowScrU_Instructions() {
		return snowScrU_Instructions;
	}

	public void setSnowScrU_Instructions(String snowScrU_Instructions) {
		this.snowScrU_Instructions = snowScrU_Instructions;
	}

	public String getSnowScrU_InternalRef() {
		return snowScrU_InternalRef;
	}

	public void setSnowScrU_InternalRef(String snowScrU_InternalRef) {
		this.snowScrU_InternalRef = snowScrU_InternalRef;
	}

	public String getSnowScrU_ItilWatchList() {
		return snowScrU_ItilWatchList;
	}

	public void setSnowScrU_ItilWatchList(String snowScrU_ItilWatchList) {
		this.snowScrU_ItilWatchList = snowScrU_ItilWatchList;
	}

	public String getSnowScrU_KnowledgeArticle() {
		return snowScrU_KnowledgeArticle;
	}

	public void setSnowScrU_KnowledgeArticle(String snowScrU_KnowledgeArticle) {
		this.snowScrU_KnowledgeArticle = snowScrU_KnowledgeArticle;
	}

	public String getSnowScrU_KnowledgeAvailable() {
		return snowScrU_KnowledgeAvailable;
	}

	public void setSnowScrU_KnowledgeAvailable(String snowScrU_KnowledgeAvailable) {
		this.snowScrU_KnowledgeAvailable = snowScrU_KnowledgeAvailable;
	}

	public String getSnowScrU_KnowledgeCode() {
		return snowScrU_KnowledgeCode;
	}

	public void setSnowScrU_KnowledgeCode(String snowScrU_KnowledgeCode) {
		this.snowScrU_KnowledgeCode = snowScrU_KnowledgeCode;
	}

	public String getSnowScrU_KnowledgeComments() {
		return snowScrU_KnowledgeComments;
	}

	public void setSnowScrU_KnowledgeComments(String snowScrU_KnowledgeComments) {
		this.snowScrU_KnowledgeComments = snowScrU_KnowledgeComments;
	}

	public String getSnowScrU_KnowledgeFound() {
		return snowScrU_KnowledgeFound;
	}

	public void setSnowScrU_KnowledgeFound(String snowScrU_KnowledgeFound) {
		this.snowScrU_KnowledgeFound = snowScrU_KnowledgeFound;
	}

	public String getSnowScrU_KnowledgeUser() {
		return snowScrU_KnowledgeUser;
	}

	public void setSnowScrU_KnowledgeUser(String snowScrU_KnowledgeUser) {
		this.snowScrU_KnowledgeUser = snowScrU_KnowledgeUser;
	}

	public String getSnowScrU_LastOccurrence() {
		return snowScrU_LastOccurrence;
	}

	public void setSnowScrU_LastOccurrence(String snowScrU_LastOccurrence) {
		this.snowScrU_LastOccurrence = snowScrU_LastOccurrence;
	}

	public String getSnowScrU_LateImpReason() {
		return snowScrU_LateImpReason;
	}

	public void setSnowScrU_LateImpReason(String snowScrU_LateImpReason) {
		this.snowScrU_LateImpReason = snowScrU_LateImpReason;
	}

	public String getSnowScrU_LeavingDate() {
		return snowScrU_LeavingDate;
	}

	public void setSnowScrU_LeavingDate(String snowScrU_LeavingDate) {
		this.snowScrU_LeavingDate = snowScrU_LeavingDate;
	}

	public String getSnowScrU_Legal() {
		return snowScrU_Legal;
	}

	public void setSnowScrU_Legal(String snowScrU_Legal) {
		this.snowScrU_Legal = snowScrU_Legal;
	}

	public String getSnowScrU_LiveDateBusiness() {
		return snowScrU_LiveDateBusiness;
	}

	public void setSnowScrU_LiveDateBusiness(String snowScrU_LiveDateBusiness) {
		this.snowScrU_LiveDateBusiness = snowScrU_LiveDateBusiness;
	}

	public String getSnowScrU_LocalResp() {
		return snowScrU_LocalResp;
	}

	public void setSnowScrU_LocalResp(String snowScrU_LocalResp) {
		this.snowScrU_LocalResp = snowScrU_LocalResp;
	}

	public String getSnowScrU_ManagementAuditComments() {
		return snowScrU_ManagementAuditComments;
	}

	public void setSnowScrU_ManagementAuditComments(String snowScrU_ManagementAuditComments) {
		this.snowScrU_ManagementAuditComments = snowScrU_ManagementAuditComments;
	}

	public String getSnowScrU_ManagementComments() {
		return snowScrU_ManagementComments;
	}

	public void setSnowScrU_ManagementComments(String snowScrU_ManagementComments) {
		this.snowScrU_ManagementComments = snowScrU_ManagementComments;
	}

	public String getSnowScrU_MissingCi() {
		return snowScrU_MissingCi;
	}

	public void setSnowScrU_MissingCi(String snowScrU_MissingCi) {
		this.snowScrU_MissingCi = snowScrU_MissingCi;
	}

	public String getSnowScrU_MissingCiFlag() {
		return snowScrU_MissingCiFlag;
	}

	public void setSnowScrU_MissingCiFlag(String snowScrU_MissingCiFlag) {
		this.snowScrU_MissingCiFlag = snowScrU_MissingCiFlag;
	}

	public String getSnowScrU_ModifiedPeriod() {
		return snowScrU_ModifiedPeriod;
	}

	public void setSnowScrU_ModifiedPeriod(String snowScrU_ModifiedPeriod) {
		this.snowScrU_ModifiedPeriod = snowScrU_ModifiedPeriod;
	}

	public String getSnowScrU_Name() {
		return snowScrU_Name;
	}

	public void setSnowScrU_Name(String snowScrU_Name) {
		this.snowScrU_Name = snowScrU_Name;
	}

	public String getSnowScrU_NotCorrect1StTime() {
		return snowScrU_NotCorrect1StTime;
	}

	public void setSnowScrU_NotCorrect1StTime(String snowScrU_NotCorrect1StTime) {
		this.snowScrU_NotCorrect1StTime = snowScrU_NotCorrect1StTime;
	}

	public String getSnowScrU_OpenedPeriod() {
		return snowScrU_OpenedPeriod;
	}

	public void setSnowScrU_OpenedPeriod(String snowScrU_OpenedPeriod) {
		this.snowScrU_OpenedPeriod = snowScrU_OpenedPeriod;
	}

	public String getSnowScrU_OutageDuration() {
		return snowScrU_OutageDuration;
	}

	public void setSnowScrU_OutageDuration(String snowScrU_OutageDuration) {
		this.snowScrU_OutageDuration = snowScrU_OutageDuration;
	}

	public String getSnowScrU_OutsourceAssignedOut() {
		return snowScrU_OutsourceAssignedOut;
	}

	public void setSnowScrU_OutsourceAssignedOut(String snowScrU_OutsourceAssignedOut) {
		this.snowScrU_OutsourceAssignedOut = snowScrU_OutsourceAssignedOut;
	}

	public String getSnowScrU_OutsourceAssignee() {
		return snowScrU_OutsourceAssignee;
	}

	public void setSnowScrU_OutsourceAssignee(String snowScrU_OutsourceAssignee) {
		this.snowScrU_OutsourceAssignee = snowScrU_OutsourceAssignee;
	}

	public String getSnowScrU_OutsourceId() {
		return snowScrU_OutsourceId;
	}

	public void setSnowScrU_OutsourceId(String snowScrU_OutsourceId) {
		this.snowScrU_OutsourceId = snowScrU_OutsourceId;
	}

	public String getSnowScrU_OutsourceIntegration() {
		return snowScrU_OutsourceIntegration;
	}

	public void setSnowScrU_OutsourceIntegration(String snowScrU_OutsourceIntegration) {
		this.snowScrU_OutsourceIntegration = snowScrU_OutsourceIntegration;
	}

	public String getSnowScrU_OutsourceModule() {
		return snowScrU_OutsourceModule;
	}

	public void setSnowScrU_OutsourceModule(String snowScrU_OutsourceModule) {
		this.snowScrU_OutsourceModule = snowScrU_OutsourceModule;
	}

	public String getSnowScrU_OutsourceResponse() {
		return snowScrU_OutsourceResponse;
	}

	public void setSnowScrU_OutsourceResponse(String snowScrU_OutsourceResponse) {
		this.snowScrU_OutsourceResponse = snowScrU_OutsourceResponse;
	}

	public String getSnowScrU_OutsourceResult() {
		return snowScrU_OutsourceResult;
	}

	public void setSnowScrU_OutsourceResult(String snowScrU_OutsourceResult) {
		this.snowScrU_OutsourceResult = snowScrU_OutsourceResult;
	}

	public String getSnowScrU_OutsourceStatus() {
		return snowScrU_OutsourceStatus;
	}

	public void setSnowScrU_OutsourceStatus(String snowScrU_OutsourceStatus) {
		this.snowScrU_OutsourceStatus = snowScrU_OutsourceStatus;
	}

	public String getSnowScrU_OutsourceTeam() {
		return snowScrU_OutsourceTeam;
	}

	public void setSnowScrU_OutsourceTeam(String snowScrU_OutsourceTeam) {
		this.snowScrU_OutsourceTeam = snowScrU_OutsourceTeam;
	}

	public String getSnowScrU_Override1() {
		return snowScrU_Override1;
	}

	public void setSnowScrU_Override1(String snowScrU_Override1) {
		this.snowScrU_Override1 = snowScrU_Override1;
	}

	public String getSnowScrU_Participants() {
		return snowScrU_Participants;
	}

	public void setSnowScrU_Participants(String snowScrU_Participants) {
		this.snowScrU_Participants = snowScrU_Participants;
	}

	public String getSnowScrU_Person() {
		return snowScrU_Person;
	}

	public void setSnowScrU_Person(String snowScrU_Person) {
		this.snowScrU_Person = snowScrU_Person;
	}

	public String getSnowScrU_PersonAudited() {
		return snowScrU_PersonAudited;
	}

	public void setSnowScrU_PersonAudited(String snowScrU_PersonAudited) {
		this.snowScrU_PersonAudited = snowScrU_PersonAudited;
	}

	public String getSnowScrU_PersonAuditing() {
		return snowScrU_PersonAuditing;
	}

	public void setSnowScrU_PersonAuditing(String snowScrU_PersonAuditing) {
		this.snowScrU_PersonAuditing = snowScrU_PersonAuditing;
	}

	public String getSnowScrU_Phone() {
		return snowScrU_Phone;
	}

	public void setSnowScrU_Phone(String snowScrU_Phone) {
		this.snowScrU_Phone = snowScrU_Phone;
	}

	public String getSnowScrU_PickupDuration() {
		return snowScrU_PickupDuration;
	}

	public void setSnowScrU_PickupDuration(String snowScrU_PickupDuration) {
		this.snowScrU_PickupDuration = snowScrU_PickupDuration;
	}

	public String getSnowScrU_PlannedEffort() {
		return snowScrU_PlannedEffort;
	}

	public void setSnowScrU_PlannedEffort(String snowScrU_PlannedEffort) {
		this.snowScrU_PlannedEffort = snowScrU_PlannedEffort;
	}

	public String getSnowScrU_PlannedImplementationWeek() {
		return snowScrU_PlannedImplementationWeek;
	}

	public void setSnowScrU_PlannedImplementationWeek(String snowScrU_PlannedImplementationWeek) {
		this.snowScrU_PlannedImplementationWeek = snowScrU_PlannedImplementationWeek;
	}

	public String getSnowScrU_PreviousGroup() {
		return snowScrU_PreviousGroup;
	}

	public void setSnowScrU_PreviousGroup(String snowScrU_PreviousGroup) {
		this.snowScrU_PreviousGroup = snowScrU_PreviousGroup;
	}

	public String getSnowScrU_PreviousStatus() {
		return snowScrU_PreviousStatus;
	}

	public void setSnowScrU_PreviousStatus(String snowScrU_PreviousStatus) {
		this.snowScrU_PreviousStatus = snowScrU_PreviousStatus;
	}

	public String getSnowScrU_Programme() {
		return snowScrU_Programme;
	}

	public void setSnowScrU_Programme(String snowScrU_Programme) {
		this.snowScrU_Programme = snowScrU_Programme;
	}

	public String getSnowScrU_QueryCount() {
		return snowScrU_QueryCount;
	}

	public void setSnowScrU_QueryCount(String snowScrU_QueryCount) {
		this.snowScrU_QueryCount = snowScrU_QueryCount;
	}

	public String getSnowScrU_RatesInEuro() {
		return snowScrU_RatesInEuro;
	}

	public void setSnowScrU_RatesInEuro(String snowScrU_RatesInEuro) {
		this.snowScrU_RatesInEuro = snowScrU_RatesInEuro;
	}

	public String getSnowScrU_RatesInGbp() {
		return snowScrU_RatesInGbp;
	}

	public void setSnowScrU_RatesInGbp(String snowScrU_RatesInGbp) {
		this.snowScrU_RatesInGbp = snowScrU_RatesInGbp;
	}

	public String getSnowScrU_RcdState() {
		return snowScrU_RcdState;
	}

	public void setSnowScrU_RcdState(String snowScrU_RcdState) {
		this.snowScrU_RcdState = snowScrU_RcdState;
	}

	public String getSnowScrU_RctFail() {
		return snowScrU_RctFail;
	}

	public void setSnowScrU_RctFail(String snowScrU_RctFail) {
		this.snowScrU_RctFail = snowScrU_RctFail;
	}

	public String getSnowScrU_RctPass() {
		return snowScrU_RctPass;
	}

	public void setSnowScrU_RctPass(String snowScrU_RctPass) {
		this.snowScrU_RctPass = snowScrU_RctPass;
	}

	public String getSnowScrU_RctState() {
		return snowScrU_RctState;
	}

	public void setSnowScrU_RctState(String snowScrU_RctState) {
		this.snowScrU_RctState = snowScrU_RctState;
	}

	public String getSnowScrU_RegionImpacted() {
		return snowScrU_RegionImpacted;
	}

	public void setSnowScrU_RegionImpacted(String snowScrU_RegionImpacted) {
		this.snowScrU_RegionImpacted = snowScrU_RegionImpacted;
	}

	public String getSnowScrU_Regions() {
		return snowScrU_Regions;
	}

	public void setSnowScrU_Regions(String snowScrU_Regions) {
		this.snowScrU_Regions = snowScrU_Regions;
	}

	public String getSnowScrU_RelatedIncidents() {
		return snowScrU_RelatedIncidents;
	}

	public void setSnowScrU_RelatedIncidents(String snowScrU_RelatedIncidents) {
		this.snowScrU_RelatedIncidents = snowScrU_RelatedIncidents;
	}

	public String getSnowScrU_ReopenCount() {
		return snowScrU_ReopenCount;
	}

	public void setSnowScrU_ReopenCount(String snowScrU_ReopenCount) {
		this.snowScrU_ReopenCount = snowScrU_ReopenCount;
	}

	public String getSnowScrU_ReopenedDate() {
		return snowScrU_ReopenedDate;
	}

	public void setSnowScrU_ReopenedDate(String snowScrU_ReopenedDate) {
		this.snowScrU_ReopenedDate = snowScrU_ReopenedDate;
	}

	public String getSnowScrU_ResolutionOverride() {
		return snowScrU_ResolutionOverride;
	}

	public void setSnowScrU_ResolutionOverride(String snowScrU_ResolutionOverride) {
		this.snowScrU_ResolutionOverride = snowScrU_ResolutionOverride;
	}

	public String getSnowScrU_ResolvedBy() {
		return snowScrU_ResolvedBy;
	}

	public void setSnowScrU_ResolvedBy(String snowScrU_ResolvedBy) {
		this.snowScrU_ResolvedBy = snowScrU_ResolvedBy;
	}

	public String getSnowScrU_ResolvedByWorkgroup() {
		return snowScrU_ResolvedByWorkgroup;
	}

	public void setSnowScrU_ResolvedByWorkgroup(String snowScrU_ResolvedByWorkgroup) {
		this.snowScrU_ResolvedByWorkgroup = snowScrU_ResolvedByWorkgroup;
	}

	public String getSnowScrU_Resolver() {
		return snowScrU_Resolver;
	}

	public void setSnowScrU_Resolver(String snowScrU_Resolver) {
		this.snowScrU_Resolver = snowScrU_Resolver;
	}

	public String getSnowScrU_ResponseFlag() {
		return snowScrU_ResponseFlag;
	}

	public void setSnowScrU_ResponseFlag(String snowScrU_ResponseFlag) {
		this.snowScrU_ResponseFlag = snowScrU_ResponseFlag;
	}

	public String getSnowScrU_ResponseOverride() {
		return snowScrU_ResponseOverride;
	}

	public void setSnowScrU_ResponseOverride(String snowScrU_ResponseOverride) {
		this.snowScrU_ResponseOverride = snowScrU_ResponseOverride;
	}

	public String getSnowScrU_RolloutSlfInformation() {
		return snowScrU_RolloutSlfInformation;
	}

	public void setSnowScrU_RolloutSlfInformation(String snowScrU_RolloutSlfInformation) {
		this.snowScrU_RolloutSlfInformation = snowScrU_RolloutSlfInformation;
	}

	public String getSnowScrU_RolloutSlfReason() {
		return snowScrU_RolloutSlfReason;
	}

	public void setSnowScrU_RolloutSlfReason(String snowScrU_RolloutSlfReason) {
		this.snowScrU_RolloutSlfReason = snowScrU_RolloutSlfReason;
	}

	public String getSnowScrU_SavedCount() {
		return snowScrU_SavedCount;
	}

	public void setSnowScrU_SavedCount(String snowScrU_SavedCount) {
		this.snowScrU_SavedCount = snowScrU_SavedCount;
	}

	public String getSnowScrU_SecondDeadline() {
		return snowScrU_SecondDeadline;
	}

	public void setSnowScrU_SecondDeadline(String snowScrU_SecondDeadline) {
		this.snowScrU_SecondDeadline = snowScrU_SecondDeadline;
	}

	public String getSnowScrU_SelectApplication() {
		return snowScrU_SelectApplication;
	}

	public void setSnowScrU_SelectApplication(String snowScrU_SelectApplication) {
		this.snowScrU_SelectApplication = snowScrU_SelectApplication;
	}

	public String getSnowScrU_SelectEuc() {
		return snowScrU_SelectEuc;
	}

	public void setSnowScrU_SelectEuc(String snowScrU_SelectEuc) {
		this.snowScrU_SelectEuc = snowScrU_SelectEuc;
	}

	public String getSnowScrU_SelectInfrastructure() {
		return snowScrU_SelectInfrastructure;
	}

	public void setSnowScrU_SelectInfrastructure(String snowScrU_SelectInfrastructure) {
		this.snowScrU_SelectInfrastructure = snowScrU_SelectInfrastructure;
	}

	public String getSnowScrU_SelectNetwork() {
		return snowScrU_SelectNetwork;
	}

	public void setSnowScrU_SelectNetwork(String snowScrU_SelectNetwork) {
		this.snowScrU_SelectNetwork = snowScrU_SelectNetwork;
	}

	public String getSnowScrU_SlaFailureWorkgroup() {
		return snowScrU_SlaFailureWorkgroup;
	}

	public void setSnowScrU_SlaFailureWorkgroup(String snowScrU_SlaFailureWorkgroup) {
		this.snowScrU_SlaFailureWorkgroup = snowScrU_SlaFailureWorkgroup;
	}

	public String getSnowScrU_SlaState() {
		return snowScrU_SlaState;
	}

	public void setSnowScrU_SlaState(String snowScrU_SlaState) {
		this.snowScrU_SlaState = snowScrU_SlaState;
	}

	public String getSnowScrU_SlfApprover() {
		return snowScrU_SlfApprover;
	}

	public void setSnowScrU_SlfApprover(String snowScrU_SlfApprover) {
		this.snowScrU_SlfApprover = snowScrU_SlfApprover;
	}

	public String getSnowScrU_SlfComponent() {
		return snowScrU_SlfComponent;
	}

	public void setSnowScrU_SlfComponent(String snowScrU_SlfComponent) {
		this.snowScrU_SlfComponent = snowScrU_SlfComponent;
	}

	public String getSnowScrU_SlfReason() {
		return snowScrU_SlfReason;
	}

	public void setSnowScrU_SlfReason(String snowScrU_SlfReason) {
		this.snowScrU_SlfReason = snowScrU_SlfReason;
	}

	public String getSnowScrU_SlfReviewDate() {
		return snowScrU_SlfReviewDate;
	}

	public void setSnowScrU_SlfReviewDate(String snowScrU_SlfReviewDate) {
		this.snowScrU_SlfReviewDate = snowScrU_SlfReviewDate;
	}

	public String getSnowScrU_SponsorFunction() {
		return snowScrU_SponsorFunction;
	}

	public void setSnowScrU_SponsorFunction(String snowScrU_SponsorFunction) {
		this.snowScrU_SponsorFunction = snowScrU_SponsorFunction;
	}

	public String getSnowScrU_SrtState() {
		return snowScrU_SrtState;
	}

	public void setSnowScrU_SrtState(String snowScrU_SrtState) {
		this.snowScrU_SrtState = snowScrU_SrtState;
	}

	public String getSnowScrU_SspForm() {
		return snowScrU_SspForm;
	}

	public void setSnowScrU_SspForm(String snowScrU_SspForm) {
		this.snowScrU_SspForm = snowScrU_SspForm;
	}

	public String getSnowScrU_Subject() {
		return snowScrU_Subject;
	}

	public void setSnowScrU_Subject(String snowScrU_Subject) {
		this.snowScrU_Subject = snowScrU_Subject;
	}

	public String getSnowScrU_SupportStructure() {
		return snowScrU_SupportStructure;
	}

	public void setSnowScrU_SupportStructure(String snowScrU_SupportStructure) {
		this.snowScrU_SupportStructure = snowScrU_SupportStructure;
	}

	public String getSnowScrU_SystemCode() {
		return snowScrU_SystemCode;
	}

	public void setSnowScrU_SystemCode(String snowScrU_SystemCode) {
		this.snowScrU_SystemCode = snowScrU_SystemCode;
	}

	public String getSnowScrU_TACosts() {
		return snowScrU_TACosts;
	}

	public void setSnowScrU_TACosts(String snowScrU_TACosts) {
		this.snowScrU_TACosts = snowScrU_TACosts;
	}

	public String getSnowScrU_TForecastsCosts() {
		return snowScrU_TForecastsCosts;
	}

	public void setSnowScrU_TForecastsCosts(String snowScrU_TForecastsCosts) {
		this.snowScrU_TForecastsCosts = snowScrU_TForecastsCosts;
	}

	public String getSnowScrU_TaskType() {
		return snowScrU_TaskType;
	}

	public void setSnowScrU_TaskType(String snowScrU_TaskType) {
		this.snowScrU_TaskType = snowScrU_TaskType;
	}

	public String getSnowScrU_Template() {
		return snowScrU_Template;
	}

	public void setSnowScrU_Template(String snowScrU_Template) {
		this.snowScrU_Template = snowScrU_Template;
	}

	public String getSnowScrU_ThirdLineComments() {
		return snowScrU_ThirdLineComments;
	}

	public void setSnowScrU_ThirdLineComments(String snowScrU_ThirdLineComments) {
		this.snowScrU_ThirdLineComments = snowScrU_ThirdLineComments;
	}

	public String getSnowScrU_ThirdLineDate() {
		return snowScrU_ThirdLineDate;
	}

	public void setSnowScrU_ThirdLineDate(String snowScrU_ThirdLineDate) {
		this.snowScrU_ThirdLineDate = snowScrU_ThirdLineDate;
	}

	public String getSnowScrU_ThirdPartyReference() {
		return snowScrU_ThirdPartyReference;
	}

	public void setSnowScrU_ThirdPartyReference(String snowScrU_ThirdPartyReference) {
		this.snowScrU_ThirdPartyReference = snowScrU_ThirdPartyReference;
	}

	public String getSnowScrU_TimeToAuth() {
		return snowScrU_TimeToAuth;
	}

	public void setSnowScrU_TimeToAuth(String snowScrU_TimeToAuth) {
		this.snowScrU_TimeToAuth = snowScrU_TimeToAuth;
	}

	public String getSnowScrU_TimeToClose() {
		return snowScrU_TimeToClose;
	}

	public void setSnowScrU_TimeToClose(String snowScrU_TimeToClose) {
		this.snowScrU_TimeToClose = snowScrU_TimeToClose;
	}

	public String getSnowScrU_TotalAgreedChangeCostsFo() {
		return snowScrU_TotalAgreedChangeCostsFo;
	}

	public void setSnowScrU_TotalAgreedChangeCostsFo(String snowScrU_TotalAgreedChangeCostsFo) {
		this.snowScrU_TotalAgreedChangeCostsFo = snowScrU_TotalAgreedChangeCostsFo;
	}

	public String getSnowScrU_UatSignedDate() {
		return snowScrU_UatSignedDate;
	}

	public void setSnowScrU_UatSignedDate(String snowScrU_UatSignedDate) {
		this.snowScrU_UatSignedDate = snowScrU_UatSignedDate;
	}

	public String getSnowScrU_UsersAffected() {
		return snowScrU_UsersAffected;
	}

	public void setSnowScrU_UsersAffected(String snowScrU_UsersAffected) {
		this.snowScrU_UsersAffected = snowScrU_UsersAffected;
	}

	public String getSnowScrU_VerizonException() {
		return snowScrU_VerizonException;
	}

	public void setSnowScrU_VerizonException(String snowScrU_VerizonException) {
		this.snowScrU_VerizonException = snowScrU_VerizonException;
	}

	public String getSnowScrU_WebId() {
		return snowScrU_WebId;
	}

	public void setSnowScrU_WebId(String snowScrU_WebId) {
		this.snowScrU_WebId = snowScrU_WebId;
	}

	public String getSnowScrU_WebUpdate() {
		return snowScrU_WebUpdate;
	}

	public void setSnowScrU_WebUpdate(String snowScrU_WebUpdate) {
		this.snowScrU_WebUpdate = snowScrU_WebUpdate;
	}

	public String getSnowScrUponApproval() {
		return snowScrUponApproval;
	}

	public void setSnowScrUponApproval(String snowScrUponApproval) {
		this.snowScrUponApproval = snowScrUponApproval;
	}

	public String getSnowScrUponReject() {
		return snowScrUponReject;
	}

	public void setSnowScrUponReject(String snowScrUponReject) {
		this.snowScrUponReject = snowScrUponReject;
	}

	public String getSnowScrUrgency() {
		return snowScrUrgency;
	}

	public void setSnowScrUrgency(String snowScrUrgency) {
		this.snowScrUrgency = snowScrUrgency;
	}

	public String getSnowScrUserInput() {
		return snowScrUserInput;
	}

	public void setSnowScrUserInput(String snowScrUserInput) {
		this.snowScrUserInput = snowScrUserInput;
	}

	public String getSnowScrWatchList() {
		return snowScrWatchList;
	}

	public void setSnowScrWatchList(String snowScrWatchList) {
		this.snowScrWatchList = snowScrWatchList;
	}

	public String getSnowScrWfActivity() {
		return snowScrWfActivity;
	}

	public void setSnowScrWfActivity(String snowScrWfActivity) {
		this.snowScrWfActivity = snowScrWfActivity;
	}

	public String getSnowScrWorkEffort() {
		return snowScrWorkEffort;
	}

	public void setSnowScrWorkEffort(String snowScrWorkEffort) {
		this.snowScrWorkEffort = snowScrWorkEffort;
	}

	public String getSnowScrWorkEnd() {
		return snowScrWorkEnd;
	}

	public void setSnowScrWorkEnd(String snowScrWorkEnd) {
		this.snowScrWorkEnd = snowScrWorkEnd;
	}

	public String getSnowScrWorkNotes() {
		return snowScrWorkNotes;
	}

	public void setSnowScrWorkNotes(String snowScrWorkNotes) {
		this.snowScrWorkNotes = snowScrWorkNotes;
	}

	public String getSnowScrWorkStart() {
		return snowScrWorkStart;
	}

	public void setSnowScrWorkStart(String snowScrWorkStart) {
		this.snowScrWorkStart = snowScrWorkStart;
	}

	public String getSnowTaskslatableActive() {
		return snowTaskslatableActive;
	}

	public void setSnowTaskslatableActive(String snowTaskslatableActive) {
		this.snowTaskslatableActive = snowTaskslatableActive;
	}

	public String getSnowTaskslatableBusinessDuration() {
		return snowTaskslatableBusinessDuration;
	}

	public void setSnowTaskslatableBusinessDuration(String snowTaskslatableBusinessDuration) {
		this.snowTaskslatableBusinessDuration = snowTaskslatableBusinessDuration;
	}

	public String getSnowTaskslatableBusinessPauseDuration() {
		return snowTaskslatableBusinessPauseDuration;
	}

	public void setSnowTaskslatableBusinessPauseDuration(String snowTaskslatableBusinessPauseDuration) {
		this.snowTaskslatableBusinessPauseDuration = snowTaskslatableBusinessPauseDuration;
	}

	public String getSnowTaskslatableBusinessPercentage() {
		return snowTaskslatableBusinessPercentage;
	}

	public void setSnowTaskslatableBusinessPercentage(String snowTaskslatableBusinessPercentage) {
		this.snowTaskslatableBusinessPercentage = snowTaskslatableBusinessPercentage;
	}

	public String getSnowTaskslatableBusinessTimeLeft() {
		return snowTaskslatableBusinessTimeLeft;
	}

	public void setSnowTaskslatableBusinessTimeLeft(String snowTaskslatableBusinessTimeLeft) {
		this.snowTaskslatableBusinessTimeLeft = snowTaskslatableBusinessTimeLeft;
	}

	public String getSnowTaskslatableDuration() {
		return snowTaskslatableDuration;
	}

	public void setSnowTaskslatableDuration(String snowTaskslatableDuration) {
		this.snowTaskslatableDuration = snowTaskslatableDuration;
	}

	public String getSnowTaskslatableEndTime() {
		return snowTaskslatableEndTime;
	}

	public void setSnowTaskslatableEndTime(String snowTaskslatableEndTime) {
		this.snowTaskslatableEndTime = snowTaskslatableEndTime;
	}

	public String getSnowTaskslatableHasBreached() {
		return snowTaskslatableHasBreached;
	}

	public void setSnowTaskslatableHasBreached(String snowTaskslatableHasBreached) {
		this.snowTaskslatableHasBreached = snowTaskslatableHasBreached;
	}

	public String getSnowTaskslatableOriginalBreachTime() {
		return snowTaskslatableOriginalBreachTime;
	}

	public void setSnowTaskslatableOriginalBreachTime(String snowTaskslatableOriginalBreachTime) {
		this.snowTaskslatableOriginalBreachTime = snowTaskslatableOriginalBreachTime;
	}

	public String getSnowTaskslatablePauseDuration() {
		return snowTaskslatablePauseDuration;
	}

	public void setSnowTaskslatablePauseDuration(String snowTaskslatablePauseDuration) {
		this.snowTaskslatablePauseDuration = snowTaskslatablePauseDuration;
	}

	public String getSnowTaskslatablePauseTime() {
		return snowTaskslatablePauseTime;
	}

	public void setSnowTaskslatablePauseTime(String snowTaskslatablePauseTime) {
		this.snowTaskslatablePauseTime = snowTaskslatablePauseTime;
	}

	public String getSnowTaskslatablePercentage() {
		return snowTaskslatablePercentage;
	}

	public void setSnowTaskslatablePercentage(String snowTaskslatablePercentage) {
		this.snowTaskslatablePercentage = snowTaskslatablePercentage;
	}

	public String getSnowTaskslatablePlannedEndTime() {
		return snowTaskslatablePlannedEndTime;
	}

	public void setSnowTaskslatablePlannedEndTime(String snowTaskslatablePlannedEndTime) {
		this.snowTaskslatablePlannedEndTime = snowTaskslatablePlannedEndTime;
	}

	public String getSnowTaskslatableSchedule() {
		return snowTaskslatableSchedule;
	}

	public void setSnowTaskslatableSchedule(String snowTaskslatableSchedule) {
		this.snowTaskslatableSchedule = snowTaskslatableSchedule;
	}

	public String getSnowTaskslatableSla() {
		return snowTaskslatableSla;
	}

	public void setSnowTaskslatableSla(String snowTaskslatableSla) {
		this.snowTaskslatableSla = snowTaskslatableSla;
	}

	public String getSnowTaskslatableStage() {
		return snowTaskslatableStage;
	}

	public void setSnowTaskslatableStage(String snowTaskslatableStage) {
		this.snowTaskslatableStage = snowTaskslatableStage;
	}

	public String getSnowTaskslatableStartTime() {
		return snowTaskslatableStartTime;
	}

	public void setSnowTaskslatableStartTime(String snowTaskslatableStartTime) {
		this.snowTaskslatableStartTime = snowTaskslatableStartTime;
	}

	public String getSnowTaskslatableSysCreatedBy() {
		return snowTaskslatableSysCreatedBy;
	}

	public void setSnowTaskslatableSysCreatedBy(String snowTaskslatableSysCreatedBy) {
		this.snowTaskslatableSysCreatedBy = snowTaskslatableSysCreatedBy;
	}

	public String getSnowTaskslatableSysCreatedOn() {
		return snowTaskslatableSysCreatedOn;
	}

	public void setSnowTaskslatableSysCreatedOn(String snowTaskslatableSysCreatedOn) {
		this.snowTaskslatableSysCreatedOn = snowTaskslatableSysCreatedOn;
	}

	public String getSnowTaskslatableSysId() {
		return snowTaskslatableSysId;
	}

	public void setSnowTaskslatableSysId(String snowTaskslatableSysId) {
		this.snowTaskslatableSysId = snowTaskslatableSysId;
	}

	public String getSnowTaskslatableSysModCount() {
		return snowTaskslatableSysModCount;
	}

	public void setSnowTaskslatableSysModCount(String snowTaskslatableSysModCount) {
		this.snowTaskslatableSysModCount = snowTaskslatableSysModCount;
	}

	public String getSnowTaskslatableSysTags() {
		return snowTaskslatableSysTags;
	}

	public void setSnowTaskslatableSysTags(String snowTaskslatableSysTags) {
		this.snowTaskslatableSysTags = snowTaskslatableSysTags;
	}

	public String getSnowTaskslatableSysUpdatedBy() {
		return snowTaskslatableSysUpdatedBy;
	}

	public void setSnowTaskslatableSysUpdatedBy(String snowTaskslatableSysUpdatedBy) {
		this.snowTaskslatableSysUpdatedBy = snowTaskslatableSysUpdatedBy;
	}

	public String getSnowTaskslatableSysUpdatedOn() {
		return snowTaskslatableSysUpdatedOn;
	}

	public void setSnowTaskslatableSysUpdatedOn(String snowTaskslatableSysUpdatedOn) {
		this.snowTaskslatableSysUpdatedOn = snowTaskslatableSysUpdatedOn;
	}

	public String getSnowTaskslatableTask() {
		return snowTaskslatableTask;
	}

	public void setSnowTaskslatableTask(String snowTaskslatableTask) {
		this.snowTaskslatableTask = snowTaskslatableTask;
	}

	public String getSnowTaskslatableTimeLeft() {
		return snowTaskslatableTimeLeft;
	}

	public void setSnowTaskslatableTimeLeft(String snowTaskslatableTimeLeft) {
		this.snowTaskslatableTimeLeft = snowTaskslatableTimeLeft;
	}

	public String getSnowTaskslatableTimezone() {
		return snowTaskslatableTimezone;
	}

	public void setSnowTaskslatableTimezone(String snowTaskslatableTimezone) {
		this.snowTaskslatableTimezone = snowTaskslatableTimezone;
	}

	public String getSnowTaskslatableU_InScope() {
		return snowTaskslatableU_InScope;
	}

	public void setSnowTaskslatableU_InScope(String snowTaskslatableU_InScope) {
		this.snowTaskslatableU_InScope = snowTaskslatableU_InScope;
	}

	public String getSnowTaskslatableU_KbArticle() {
		return snowTaskslatableU_KbArticle;
	}

	public void setSnowTaskslatableU_KbArticle(String snowTaskslatableU_KbArticle) {
		this.snowTaskslatableU_KbArticle = snowTaskslatableU_KbArticle;
	}

}
