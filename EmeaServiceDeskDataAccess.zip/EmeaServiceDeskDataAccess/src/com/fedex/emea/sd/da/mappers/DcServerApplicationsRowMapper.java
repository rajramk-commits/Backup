package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.DcServerApplications;
import com.fedex.emea.sd.da.objects.DcServers;
import com.fedex.emea.sd.da.helpers.Utilities;

public class DcServerApplicationsRowMapper implements RowMapper {

	@Override
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
		DcServerApplications dcServerApplication = new DcServerApplications();
		DcServers dcServer = new DcServers();
		
		dcServerApplication.setBusinessCriticality(rs.getString("BusCrit"));
		dcServerApplication.setApplicationName(rs.getString("AppName"));
		dcServerApplication.setServiceName(rs.getString("SrvName"));
		dcServer.setServerName(Utilities.cleanServerName(rs.getString("ServerName")));
		dcServer.setServerDescription(rs.getString("ServerDescr"));
		dcServer.setServerDataCenter(rs.getString("ServerDc"));
		dcServer.setServerType(rs.getString("ServerType"));
		dcServer.setServerStatus(rs.getString("ServerStatus"));
		dcServerApplication.setHostingServer(dcServer);
		dcServerApplication.setResponsibleManager(rs.getString("RespMgr"));
		
		return dcServerApplication;
	}

}
