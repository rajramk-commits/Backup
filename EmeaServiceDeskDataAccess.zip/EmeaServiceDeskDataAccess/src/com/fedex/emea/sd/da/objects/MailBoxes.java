package com.fedex.emea.sd.da.objects;

import java.io.Serializable;
import java.util.ArrayList;

public class MailBoxes implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String userName;
	private String password;
	private String mailAddress;
	private int nbrOfRules;
	private ArrayList<MailBoxRules> mailBoxRules;
	
	public MailBoxes() {
	}
	
	public MailBoxes(String userName, String password, String mailAddress, int nbrOfRules, ArrayList<MailBoxRules> mailBoxRules) {
		this.setUserName(userName);
		this.setPassword(password);
		this.setMailAddress(mailAddress);
		this.setNbrOfRules(nbrOfRules);
		this.setMailBoxRules(mailBoxRules);
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMailAddress() {
		return mailAddress;
	}

	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	public int getNbrOfRules() {
		return nbrOfRules;
	}

	public void setNbrOfRules(int nbrOfRules) {
		this.nbrOfRules = nbrOfRules;
	}

	public ArrayList<MailBoxRules> getMailBoxRules() {
		return mailBoxRules;
	}

	public void setMailBoxRules(ArrayList<MailBoxRules> mailBoxRules) {
		this.mailBoxRules = mailBoxRules;
	}
	
}
