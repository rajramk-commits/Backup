package com.fedex.emea.sd.snow.utilities;

import java.util.HashMap;

import com.fedex.emea.sd.snow.objects.SnowConnectionParameters;

public class SnowConstants {
	
	private static final boolean DEV_USE_PROXY                            = false;
	private static final String  DEV_SNOW_DNS                             = "knight.emea.fedex.com";
	private static final int     DEV_SNOW_PORT                            = 8443;
	private static final String  DEV_SNOW_TYPE                            = "https";
	private static final String  DEV_SNOW_UID                             = "wsdl_hpom";
	private static final String  DEV_SNOW_PWD                             = "Df23dghdF@frec!fdsb2944fb";
	private static final String  DEV_SNOW_QUERY_TABLE_URL                 = "/snow/api/now/table/";
	private static final String  DEV_SNOW_QUERY_INCIDENT_URL              = "/snow/api/now/table/incident";
	private static final String  DEV_SNOW_QUERY_UPD_INCIDENT_URL          = "/snow/api/now/table/incident";
	private static final String  DEV_SNOW_QUERY_SYS_JOURNAL_FIELD_URL     = "/snow/api/now/table/sys_journal_field";
	private static final String  DEV_SNOW_QUERY_STATS_URL                 = "/snow/api/now/stats/";

	private static final boolean SAND_USE_PROXY                           = false;
	private static final String  SAND_SNOW_DNS                            = "knight.emea.fedex.com";
	private static final int     SAND_SNOW_PORT                           = 8443;
	private static final String  SAND_SNOW_TYPE                           = "https";
	private static final String  SAND_SNOW_UID                            = "wsdl_astc";
	private static final String  SAND_SNOW_PWD                            = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  SAND_SNOW_QUERY_TABLE_URL                = "/sand/snow/api/now/table/";
	private static final String  SAND_SNOW_QUERY_INCIDENT_URL             = "/sand/snow/api/now/table/incident";
	private static final String  SAND_SNOW_QUERY_UPD_INCIDENT_URL         = "/sand/snow/api/now/table/incident";
	private static final String  SAND_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/sand/snow/api/now/table/sys_journal_field";
	private static final String  SAND_SNOW_QUERY_STATS_URL                = "/sand/snow/api/now/stats/";

	private static final boolean UAT_USE_PROXY                            = false;
	private static final String  UAT_SNOW_DNS                             = "knight.emea.fedex.com";
	private static final int     UAT_SNOW_PORT                            = 8443;
	private static final String  UAT_SNOW_TYPE                            = "https";
	private static final String  UAT_SNOW_UID                             = "wsdl_astc";
	private static final String  UAT_SNOW_PWD                             = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  UAT_SNOW_QUERY_TABLE_URL                 = "/uat/snow/api/now/table/";
	private static final String  UAT_SNOW_QUERY_INCIDENT_URL              = "/uat/snow/api/now/table/incident";
	private static final String  UAT_SNOW_QUERY_UPD_INCIDENT_URL          = "/uat/snow/api/now/table/incident";
	private static final String  UAT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL     = "/uat/snow/api/now/table/sys_journal_field";
	private static final String  UAT_SNOW_QUERY_STATS_URL                 = "/uat/snow/api/now/stats/";
	
	private static final boolean PREPROD_USE_PROXY                        = false;
	private static final String  PREPROD_SNOW_DNS                         = "knight.emea.fedex.com";
	private static final int     PREPROD_SNOW_PORT                        = 8443;
	private static final String  PREPROD_SNOW_TYPE                        = "https";
	private static final String  PREPROD_SNOW_UID                         = "wsdl_astc";
	private static final String  PREPROD_SNOW_PWD                         = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  PREPROD_SNOW_QUERY_TABLE_URL             = "/preprod/snow/api/now/table/";
	private static final String  PREPROD_SNOW_QUERY_INCIDENT_URL          = "/preprod/snow/api/now/table/incident";
	private static final String  PREPROD_SNOW_QUERY_UPD_INCIDENT_URL      = "/preprod/snow/api/now/table/incident";
	private static final String  PREPROD_SNOW_QUERY_SYS_JOURNAL_FIELD_URL = "/preprod/snow/api/now/table/sys_journal_field";
	private static final String  PREPROD_SNOW_QUERY_STATS_URL             = "/preprod/snow/api/now/stats/";
	
	private static final boolean PREPROD_DIRECT_USE_PROXY                           = true;
	private static final String  PREPROD_DIRECT_SNOW_DNS                            = "tntpreprod.service-now.com";
	private static final int     PREPROD_DIRECT_SNOW_PORT                           = 443;
	private static final String  PREPROD_DIRECT_SNOW_TYPE                           = "https";
	private static final String  PREPROD_DIRECT_SNOW_UID                            = "wsdl_astc";
	private static final String  PREPROD_DIRECT_SNOW_PWD                            = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  PREPROD_DIRECT_SNOW_QUERY_TABLE_URL                = "/api/now/table/";
	private static final String  PREPROD_DIRECT_SNOW_QUERY_INCIDENT_URL             = "/api/now/table/incident";
	private static final String  PREPROD_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL         = "/api/now/table/incident";
	private static final String  PREPROD_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/api/now/table/sys_journal_field";
	private static final String  PREPROD_DIRECT_SNOW_QUERY_STATS_URL                = "/api/now/stats/";
	
	private static final boolean PROD_USE_PROXY                           = true;
	private static final String  PROD_SNOW_DNS                            = "api.emea.fedex.com";
	private static final int     PROD_SNOW_PORT                           = 8443;
	private static final String  PROD_SNOW_TYPE                           = "https";
	private static final String  PROD_SNOW_UID                            = "wsdl_astc";
	private static final String  PROD_SNOW_PWD                            = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  PROD_SNOW_QUERY_TABLE_URL                = "/snow/api/now/table/";
	private static final String  PROD_SNOW_QUERY_INCIDENT_URL             = "/snow/api/now/table/incident";
	private static final String  PROD_SNOW_QUERY_UPD_INCIDENT_URL         = "/snow/api/now/table/incident";
	private static final String  PROD_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/snow/api/now/table/sys_journal_field";
	private static final String  PROD_SNOW_QUERY_STATS_URL                = "/snow/api/now/stats/";
	
	private static final boolean PROD_DIRECT_USE_PROXY                           = true;
	private static final String  PROD_DIRECT_SNOW_DNS                            = "tnt.service-now.com";
	private static final int     PROD_DIRECT_SNOW_PORT                           = 443;
	private static final String  PROD_DIRECT_SNOW_TYPE                           = "https";
	private static final String  PROD_DIRECT_SNOW_UID                            = "wsdl_astc";
	private static final String  PROD_DIRECT_SNOW_PWD                            = "Hdcy673HcWoc823c!cdasdc4p";
	private static final String  PROD_DIRECT_SNOW_QUERY_TABLE_URL                = "/api/now/table/";
	private static final String  PROD_DIRECT_SNOW_QUERY_INCIDENT_URL             = "/api/now/table/incident";
	private static final String  PROD_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL         = "/api/now/table/incident";
	private static final String  PROD_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/api/now/table/sys_journal_field";
	private static final String  PROD_DIRECT_SNOW_QUERY_STATS_URL                = "/api/now/stats/";
	
	// =========================================================================
	// EPDSM
	
	private static final boolean DEV_EPDSM_DIRECT_USE_PROXY                           = true;
	private static final String  DEV_EPDSM_DIRECT_SNOW_DNS                            = "pdsmdev08.service-now.com";
	private static final int     DEV_EPDSM_DIRECT_SNOW_PORT                           = 443;
	private static final String  DEV_EPDSM_DIRECT_SNOW_TYPE                           = "https";
	private static final String  DEV_EPDSM_DIRECT_SNOW_UID                            = "fdx_tnt_astc";
	private static final String  DEV_EPDSM_DIRECT_SNOW_PWD                            = "QqappjGHAMC7TX0vBz5THKFO";
	private static final String  DEV_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL                = "/api/now/table/";
	private static final String  DEV_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL             = "/api/now/table/u_astc_incident";
	private static final String  DEV_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL         = "/api/now/table/u_astc_incident_update";
	private static final String  DEV_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/api/now/table/sys_journal_field";
	private static final String  DEV_EPDSM_DIRECT_SNOW_QUERY_STATS_URL                = "/api/now/stats/";

	private static final boolean UAT_EPDSM_DIRECT_USE_PROXY                           = true;
	private static final String  UAT_EPDSM_DIRECT_SNOW_DNS                            = "pdsmuat.service-now.com";
	private static final int     UAT_EPDSM_DIRECT_SNOW_PORT                           = 443;
	private static final String  UAT_EPDSM_DIRECT_SNOW_TYPE                           = "https";
	private static final String  UAT_EPDSM_DIRECT_SNOW_UID                            = "fdx_tnt_astc";
	private static final String  UAT_EPDSM_DIRECT_SNOW_PWD                            = "b72knDDCkmUKWDPVTya6r4AeW";
	private static final String  UAT_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL                = "/api/now/table/";
	private static final String  UAT_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL             = "/api/now/table/u_astc_incident";
	private static final String  UAT_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL         = "/api/now/table/u_astc_incident_update";
	private static final String  UAT_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/api/now/table/sys_journal_field";
	private static final String  UAT_EPDSM_DIRECT_SNOW_QUERY_STATS_URL                = "/api/now/stats/";

	private static final boolean PROD_EPDSM_DIRECT_USE_PROXY                           = true;
	private static final String  PROD_EPDSM_DIRECT_SNOW_DNS                            = "pdsm.service-now.com";
	private static final int     PROD_EPDSM_DIRECT_SNOW_PORT                           = 443;
	private static final String  PROD_EPDSM_DIRECT_SNOW_TYPE                           = "https";
	private static final String  PROD_EPDSM_DIRECT_SNOW_UID                            = "fdx_tnt_astc";
	private static final String  PROD_EPDSM_DIRECT_SNOW_PWD                            = "kNEqiVnNzZuHOK0dTmChZW3yx";
	private static final String  PROD_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL                = "/api/now/table/";
	private static final String  PROD_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL             = "/api/now/table/u_astc_incident";
	private static final String  PROD_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL         = "/api/now/table/u_astc_incident_update";
	private static final String  PROD_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL    = "/api/now/table/sys_journal_field";
	private static final String  PROD_EPDSM_DIRECT_SNOW_QUERY_STATS_URL                = "/api/now/stats/";

	public static final String   PROXY_DNS  = "internet.proxy.fedex.com";
	public static final int      PROXY_PORT = 3128;
	public static final String   PROXY_TYPE = "http";

	public static final SnowConnectionParameters SNOW_DEV            = new SnowConnectionParameters(DEV_SNOW_DNS,         DEV_SNOW_PORT,         DEV_SNOW_TYPE,         DEV_SNOW_UID ,         DEV_SNOW_PWD,         DEV_SNOW_QUERY_TABLE_URL,         DEV_SNOW_QUERY_INCIDENT_URL,         DEV_SNOW_QUERY_SYS_JOURNAL_FIELD_URL,         DEV_USE_PROXY,         DEV_SNOW_QUERY_STATS_URL,         DEV_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_SAND           = new SnowConnectionParameters(SAND_SNOW_DNS,        SAND_SNOW_PORT,        SAND_SNOW_TYPE,        SAND_SNOW_UID ,        SAND_SNOW_PWD,        SAND_SNOW_QUERY_TABLE_URL,        SAND_SNOW_QUERY_INCIDENT_URL,        SAND_SNOW_QUERY_SYS_JOURNAL_FIELD_URL,        SAND_USE_PROXY,        SAND_SNOW_QUERY_STATS_URL,        SAND_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_UAT            = new SnowConnectionParameters(UAT_SNOW_DNS,         UAT_SNOW_PORT,         UAT_SNOW_TYPE,         UAT_SNOW_UID ,         UAT_SNOW_PWD,         UAT_SNOW_QUERY_TABLE_URL,         UAT_SNOW_QUERY_INCIDENT_URL,         UAT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL,         UAT_USE_PROXY,         UAT_SNOW_QUERY_STATS_URL,         UAT_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_PREPROD        = new SnowConnectionParameters(PREPROD_SNOW_DNS,     PREPROD_SNOW_PORT,     PREPROD_SNOW_TYPE,     PREPROD_SNOW_UID ,     PREPROD_SNOW_PWD,     PREPROD_SNOW_QUERY_TABLE_URL,     PREPROD_SNOW_QUERY_INCIDENT_URL,     PREPROD_SNOW_QUERY_SYS_JOURNAL_FIELD_URL,     PREPROD_USE_PROXY,     PREPROD_SNOW_QUERY_STATS_URL,     PREPROD_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_PREPROD_DIRECT = new SnowConnectionParameters(PREPROD_DIRECT_SNOW_DNS, PREPROD_DIRECT_SNOW_PORT, PREPROD_DIRECT_SNOW_TYPE, PREPROD_DIRECT_SNOW_UID , PREPROD_DIRECT_SNOW_PWD, PREPROD_DIRECT_SNOW_QUERY_TABLE_URL, PREPROD_DIRECT_SNOW_QUERY_INCIDENT_URL, PREPROD_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL, PREPROD_DIRECT_USE_PROXY, PREPROD_DIRECT_SNOW_QUERY_STATS_URL, PREPROD_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_PROD           = new SnowConnectionParameters(PROD_SNOW_DNS,        PROD_SNOW_PORT,        PROD_SNOW_TYPE,        PROD_SNOW_UID ,        PROD_SNOW_PWD,        PROD_SNOW_QUERY_TABLE_URL,        PROD_SNOW_QUERY_INCIDENT_URL,        PROD_SNOW_QUERY_SYS_JOURNAL_FIELD_URL,        PROD_USE_PROXY,        PROD_SNOW_QUERY_STATS_URL,        PROD_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters SNOW_PROD_DIRECT    = new SnowConnectionParameters(PROD_DIRECT_SNOW_DNS, PROD_DIRECT_SNOW_PORT, PROD_DIRECT_SNOW_TYPE, PROD_DIRECT_SNOW_UID , PROD_DIRECT_SNOW_PWD, PROD_DIRECT_SNOW_QUERY_TABLE_URL, PROD_DIRECT_SNOW_QUERY_INCIDENT_URL, PROD_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL, PROD_DIRECT_USE_PROXY, PROD_DIRECT_SNOW_QUERY_STATS_URL, PROD_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL);
	
	public static final SnowConnectionParameters EPDSM_DEV_DIRECT    = new SnowConnectionParameters(DEV_EPDSM_DIRECT_SNOW_DNS, DEV_EPDSM_DIRECT_SNOW_PORT, DEV_EPDSM_DIRECT_SNOW_TYPE, DEV_EPDSM_DIRECT_SNOW_UID , DEV_EPDSM_DIRECT_SNOW_PWD, DEV_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL, DEV_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL, DEV_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL, DEV_EPDSM_DIRECT_USE_PROXY, DEV_EPDSM_DIRECT_SNOW_QUERY_STATS_URL, DEV_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters EPDSM_UAT_DIRECT    = new SnowConnectionParameters(UAT_EPDSM_DIRECT_SNOW_DNS, UAT_EPDSM_DIRECT_SNOW_PORT, UAT_EPDSM_DIRECT_SNOW_TYPE, UAT_EPDSM_DIRECT_SNOW_UID , UAT_EPDSM_DIRECT_SNOW_PWD, UAT_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL, UAT_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL, UAT_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL, UAT_EPDSM_DIRECT_USE_PROXY, UAT_EPDSM_DIRECT_SNOW_QUERY_STATS_URL, UAT_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL);
	public static final SnowConnectionParameters EPDSM_PROD_DIRECT   = new SnowConnectionParameters(PROD_EPDSM_DIRECT_SNOW_DNS, PROD_EPDSM_DIRECT_SNOW_PORT, PROD_EPDSM_DIRECT_SNOW_TYPE, PROD_EPDSM_DIRECT_SNOW_UID , PROD_EPDSM_DIRECT_SNOW_PWD, PROD_EPDSM_DIRECT_SNOW_QUERY_TABLE_URL, PROD_EPDSM_DIRECT_SNOW_QUERY_INCIDENT_URL, PROD_EPDSM_DIRECT_SNOW_QUERY_SYS_JOURNAL_FIELD_URL, PROD_EPDSM_DIRECT_USE_PROXY, PROD_EPDSM_DIRECT_SNOW_QUERY_STATS_URL, PROD_EPDSM_DIRECT_SNOW_QUERY_UPD_INCIDENT_URL);
	
	public static final String U_FOLDER_FEDEX     = "fedex";
	public static final String U_FOLDER_FEDEX_ID  = "1a0e8689dbe5fac0c9a7b14ffe9619a5";
	
	public static final String OFFICE_SUPPRT_PINS = "305770,5123522,5106000,5106003,5106004,136700";
	
	public static final String SYS_CLASS_INCIDENT = "incident";
	public static final String SYS_CLASS_SRVREQ   = "sc_request";
	public static final String SYS_CLASS_PROBLEM  = "problem";
	
	public static final String CATEGORY_INCIDENT    = "Incident";
	public static final String CATEGORY_PROBLEM     = "Problem";
	public static final String CATEGORY_REQUEST     = "rfs";
	public static final String CATEGORY_REQUEST_RFS = "rfs";
	public static final String CATEGORY_REQUEST_RFQ = "rfq";
	public static final String CATEGORY_REQUEST_RFI = "rfi";
	public static final String CATEGORY_REQUEST_RFC = "rfc";
	
	public static HashMap<String, String> CATEGORY_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(CATEGORY_INCIDENT,    "Incident");
	    put(CATEGORY_PROBLEM,     "Problem");
	    put(CATEGORY_REQUEST_RFC, "RFC");
	    put(CATEGORY_REQUEST_RFQ, "RFQ");
	    put(CATEGORY_REQUEST_RFI, "RFI");
	    put(CATEGORY_REQUEST_RFS, "RFS");
	}};
	
	public static final String STATE_REGISTERED              = "1";
	public static final String STATE_IN_PROGRESS             = "2";
	public static final String STATE_CLOSED_PENDING_PROBLEM  = "3";
	public static final String STATE_RESOLVED                = "5";
	public static final String STATE_PENDING                 = "-5";
	public static final String STATE_COMPLETED               = "6";
	public static final String STATE_CLOSED                  = "7";
	public static final String STATE_ABANDON                 = "8";
	public static final String STATE_OPEN                    = "9";
	public static final String STATE_PENDING_MASTER          = "12";
	public static final String STATE_RESOLVED_PENDING_MASTER = "14";
	
	public static HashMap<String, String> STATE_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(STATE_REGISTERED,              "Registered");
	    put(STATE_IN_PROGRESS,             "In Progress");
	    put(STATE_CLOSED_PENDING_PROBLEM,  "Closed Pending");
	    put(STATE_RESOLVED,                "Resolved");
	    put(STATE_PENDING,                 "Pending");
	    put(STATE_COMPLETED,               "Completed");
	    put(STATE_CLOSED,                  "Closed");
	    put(STATE_ABANDON,                 "Abandon");
	    put(STATE_OPEN,                    "Open");
	    put(STATE_PENDING_MASTER,          "Pending Master");
	    put(STATE_RESOLVED_PENDING_MASTER, "Resolved Pending");
	}};
	
	public static final String SUB_CATEGORY_MANUAL = "Manual Incident";
	public static final String SUB_CATEGORY_USER   = "User Incident";
	public static final String SUB_CATEGORY_CHILD  = "Child Incident";
	public static final String SUB_CATEGORY_EVENT  = "Event";
	
	public static final String CLASSIFICATION_ACCESS_PWD                  = "Access / Password Reset";
	public static final String CLASSIFICATION_APP_SOFT_OS                 = "Application / Software / Operating System";
	public static final String CLASSIFICATION_BATCH_JOB                   = "Batch / Scheduled Job";
	public static final String CLASSIFICATION_DATA                        = "Data";
	public static final String CLASSIFICATION_HARDW                       = "Hardware";
	public static final String CLASSIFICATION_HOUSEKEEP                   = "Housekeeping (Backups etc)";
	public static final String CLASSIFICATION_NET_COMM                    = "Network / Communications";
	public static final String CLASSIFICATION_PERF_CAPACITY               = "Performance / Capacity";
	public static final String CLASSIFICATION_PRINTING                    = "Printing";
	public static final String CLASSIFICATION_PROCEDURAL_PROCESS          = "Procedural / Process";
	public static final String CLASSIFICATION_SEC_ACTUAL_BREACH           = "Security - Actual Breach";
	public static final String CLASSIFICATION_SEC_WEAKNESS_ATTEMPT_BREACH = "Security - Weakness / Attempted Breach";
	public static final String CLASSIFICATION_WEB                         = "Web";
	public static final String CLASSIFICATION_INCORR_FILL                 = "Request Incorrectly Fulfilled";
	
	public static final String IMPACT_LOCAL          = "9";
	public static final String IMPACT_FOUR           = "7";
	public static final String IMPACT_THREE          = "6";
	public static final String IMPACT_TWO            = "5";
	public static final String IMPACT_ONE            = "4";
	public static final String IMPACT_REDUCE_PERF    = "3";
	public static final String IMPACT_PART_FAILURE   = "2";
	public static final String IMPACT_LOSS_KEY_FUNCT = "1";
	public static final String IMPACT_TOTAL_FAILURE  = "0";
	
	public static final String URGENCY_SINGLE_USER   = "2";
	public static final String URGENCY_MULTIPLE_USER = "1";
	public static final String URGENCY_ONE           = "4";
	public static final String URGENCY_TWO           = "5";
	public static final String URGENCY_THREE         = "6";
	public static final String URGENCY_FOUR          = "7";
	
	public static final String PRIORITY_MINOR    = "4";
	public static final String PRIORITY_MAJOR    = "3";
	public static final String PRIORITY_HIGH     = "2";
	public static final String PRIORITY_CRITICAL = "1";
	
	public static HashMap<String, String> PRIORITY_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(PRIORITY_CRITICAL, "P1");
		put(PRIORITY_HIGH,     "P2");
		put(PRIORITY_MAJOR,    "P3");
		put(PRIORITY_MINOR,    "P4");
	}};
	
	public static final String PRIORITY_REQ_1H   = "121";
	public static final String PRIORITY_REQ_2H   = "122";
	public static final String PRIORITY_REQ_4H   = "123";
	public static final String PRIORITY_REQ_9H   = "124";
	public static final String PRIORITY_REQ_10H  = "125";
	public static final String PRIORITY_REQ_12H  = "126";
	public static final String PRIORITY_REQ_24H  = "127";
	public static final String PRIORITY_REQ_36H  = "128";
	public static final String PRIORITY_REQ_40H  = "129";
	public static final String PRIORITY_REQ_48H  = "130";
	public static final String PRIORITY_REQ_60H  = "131";
	public static final String PRIORITY_REQ_108H = "132";
	public static final String PRIORITY_REQ_D4   = "133";
	public static final String PRIORITY_REQ_D5   = "134";
	public static final String PRIORITY_REQ_D8   = "135";
	public static final String PRIORITY_REQ_DNDF = "136";
	public static final String PRIORITY_REQ_1D   = "137";
	public static final String PRIORITY_REQ_2D   = "138";
	public static final String PRIORITY_REQ_3D   = "139";
	public static final String PRIORITY_REQ_5D   = "140";
	public static final String PRIORITY_REQ_6D   = "141";
	public static final String PRIORITY_REQ_7D   = "0";
	public static final String PRIORITY_REQ_10D  = "142";
	public static final String PRIORITY_REQ_14D  = "148";
	public static final String PRIORITY_REQ_15D  = "143";
	public static final String PRIORITY_REQ_20D  = "144";
	public static final String PRIORITY_REQ_23D  = "145";
	public static final String PRIORITY_REQ_30D  = "146";
	public static final String PRIORITY_REQ_40D  = "147";
	public static final String PRIORITY_REQ_70D  = "251";
	public static final String PRIORITY_REQ_ZAC  = "149";
	public static final String PRIORITY_REQ_16H  = "16";
	public static final String PRIORITY_REQ_120D = "1200";
	public static final String PRIORITY_REQ_NA   = "56";

	public static HashMap<String, String> PRIORITY_REQ_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(PRIORITY_REQ_1H,   "Outsource - 1 Hour");
		put(PRIORITY_REQ_2H,   "Outsource - 2 Hours");
		put(PRIORITY_REQ_4H,   "Outsource - 4 Hours");
		put(PRIORITY_REQ_9H,   "Outsource - 9 Hours");
		put(PRIORITY_REQ_10H,  "Outsource - 10 Hours");
		put(PRIORITY_REQ_12H,  "Outsource - 12 Hours");
		put(PRIORITY_REQ_24H,  "Outsource - 24 Hours");
		put(PRIORITY_REQ_36H,  "Outsource - 36 Hours");
		put(PRIORITY_REQ_40H,  "Outsource - 40 Hours");
		put(PRIORITY_REQ_48H,  "Outsource - 48 Hours");
		put(PRIORITY_REQ_60H,  "Outsource - 60 Hours");
		put(PRIORITY_REQ_108H, "Outsource - 108 Hours");
		put(PRIORITY_REQ_D4,   "D4");
		put(PRIORITY_REQ_D5,   "D5");
		put(PRIORITY_REQ_D8,   "D8");
		put(PRIORITY_REQ_DNDF, "DNDF");
		put(PRIORITY_REQ_1D,   "Request 1 Day");
		put(PRIORITY_REQ_2D,   "Request 2 Day");
		put(PRIORITY_REQ_3D,   "Request 3 Day");
		put(PRIORITY_REQ_5D,   "Request 5 Day");
		put(PRIORITY_REQ_6D,   "Request 6 Days");
		put(PRIORITY_REQ_7D,   "Request 7 Days");
		put(PRIORITY_REQ_10D,  "Request 10 Day");
		put(PRIORITY_REQ_14D,  "Request 14 Days");
		put(PRIORITY_REQ_15D,  "Request 15 Day");
		put(PRIORITY_REQ_20D,  "Request 20 Day");
		put(PRIORITY_REQ_23D,  "Request 23 Days");
		put(PRIORITY_REQ_30D,  "Request 30 Days");
		put(PRIORITY_REQ_40D,  "Request 40 Day");
		put(PRIORITY_REQ_70D,  "Request 70 Day");
		put(PRIORITY_REQ_ZAC,  "z-Access Control");
		put(PRIORITY_REQ_16H,  "Request 16 Hours");
		put(PRIORITY_REQ_120D, "Request 120 Day");
		put(PRIORITY_REQ_NA,   "Work Request N/A");
	}};
	
	public static final String CONTACT_MEDIUM_IM    = "Instant Messaging";
	public static final String CONTACT_MEDIUM_VISIT = "Visit";
	public static final String CONTACT_MEDIUM_EMAIL = "email";
	public static final String CONTACT_MEDIUM_PHONE = "phone";
	public static final String CONTACT_MEDIUM_OWN   = "Own";
	public static final String CONTACT_MEDIUM_EVENT = "Event";
	public static final String CONTACT_MEDIUM_WEB   = "Web";
	
	public static HashMap<String, String> CONTACT_MEDIUM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(CONTACT_MEDIUM_IM,    "IM");
	    put(CONTACT_MEDIUM_VISIT, "Visit");
	    put(CONTACT_MEDIUM_EMAIL, "Email");
	    put(CONTACT_MEDIUM_PHONE, "Phone");
	    put(CONTACT_MEDIUM_OWN,   "Own");
	    put(CONTACT_MEDIUM_EVENT, "Event");
	    put(CONTACT_MEDIUM_WEB,   "Web");
	}};
	
	public static final String SERVICE_STATE_NOT_AFFECTED = "Not Affected";
	public static final String SERVICE_STATE_DOWN         = "Down";
	public static final String SERVICE_STATE_AFFECTED     = "Affected";
	
	public static final String SITES_AFFECTED_NONE     = "";
	public static final String SITES_AFFECTED_SINGLE   = "One or more sites";
	public static final String SITES_AFFECTED_ONE_MORE = "Single site";
	public static final String SITES_AFFECTED_TWO_MORE = "Two or more sites";
	
	public static final String GROUP_1 = "Group 1";
	public static final String GROUP_2 = "Group 2";
	public static final String GROUP_3 = "Group 3";
	
	public static final String WORKGROUP_ROLE_1 = "1st Line";
	public static final String WORKGROUP_ROLE_2 = "2nd Line";
	public static final String WORKGROUP_ROLE_3 = "3rd Line";
		
	public static final String WORKNOTE_SUBJECT_ACTION                 = "Action";
	public static final String WORKNOTE_SUBJECT_ESCALATION             = "Escalation";
	public static final String WORKNOTE_SUBJECT_COMMUNICATION          = "Communication";
	public static final String WORKNOTE_SUBJECT_CHG_OWNER              = "Change of Ownership";
	public static final String WORKNOTE_SUBJECT_REASON_IMPACT_PRIO_CHG = "Reason for impact/ priority change";
	public static final String WORKNOTE_SUBJECT_REJECT_REASON          = "Rejection Reason";
	public static final String WORKNOTE_SUBJECT_CONFIRM_CLOSURE        = "Confirmation/ Closure";
	public static final String WORKNOTE_SUBJECT_SD_WARM_HANDSHK        = "Service Desk Warm Handshake";
	public static final String WORKNOTE_SUBJECT_VENDOR_WARM_HANDSH     = "Vendor Warm Handshake";
	
	// =--------------------------------------------------------------------=
	// =============================== E-PDSM ===============================
	// =--------------------------------------------------------------------=
	
	public static final String PRIORITY_EPDSM_CRITICAL = "1";
	public static final String PRIORITY_EPDSM_HIGH     = "2";
	public static final String PRIORITY_EPDSM_MODERATE = "3";
	public static final String PRIORITY_EPDSM_LOW      = "4";
	public static final String PRIORITY_EPDSM_PLANNING = "5";
	
	public static HashMap<String, String> PRIORITY_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(PRIORITY_EPDSM_CRITICAL, "1 - Critical");
		put(PRIORITY_EPDSM_HIGH,     "2 - High");
		put(PRIORITY_EPDSM_MODERATE, "3 - Moderate");
		put(PRIORITY_EPDSM_LOW,      "4 - Low");
		put(PRIORITY_EPDSM_PLANNING, "5 - Planning");
	}};
	
	public static final String IMPACT_EPDSM_1_GLOBAL  = "1";
	public static final String IMPACT_EPDSM_2_MULTI   = "2";
	public static final String IMPACT_EPDSM_3_SINGLE  = "3";
	
	public static HashMap<String, String> IMPACT_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(IMPACT_EPDSM_1_GLOBAL, "1 - Enterprise/Global");
		put(IMPACT_EPDSM_2_MULTI,  "2 - Multiple Users/Sites");
		put(IMPACT_EPDSM_3_SINGLE, "3 - Single User/Site");
	}};
	
	public static final String URGENCY_EPDSM_1_CRIT_NOWA = "1";
	public static final String URGENCY_EPDSM_2_CRIT_WA   = "2";
	public static final String URGENCY_EPDSM_3_NOCRIT    = "3";
	
	public static HashMap<String, String> URGENCY_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(URGENCY_EPDSM_1_CRIT_NOWA, "1 - Critical Work Stoppage/No Work around");
		put(URGENCY_EPDSM_2_CRIT_WA,   "2 - Critical Work Stoppage/Work Around Available");
		put(URGENCY_EPDSM_3_NOCRIT,    "3 - Non-Critical Work Stoppage");
	}};
	
	public static final String CONTACT_EPDSM_PHONE  = "phone";
	public static final String CONTACT_EPDSM_CHAT   = "chat";
	public static final String CONTACT_EPDSM_SELF   = "self-service";
	public static final String CONTACT_EPDSM_WALK   = "walk-in";
	public static final String CONTACT_EPDSM_EVENT  = "event_alert";
	public static final String CONTACT_EPDSM_INTEGR = "Integration";
	
	public static HashMap<String, String> CONTACT_EPDSM_MEDIUM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(CONTACT_EPDSM_PHONE,  "Phone");
	    put(CONTACT_EPDSM_CHAT,   "Chat");
	    put(CONTACT_EPDSM_SELF,   "Self-service");
	    put(CONTACT_EPDSM_WALK,   "Walk-in");
	    put(CONTACT_EPDSM_EVENT,  "Event/Alert");
	    put(CONTACT_EPDSM_INTEGR, "Integration");
	}};
	
	public static final String CATEGORY_EPDSM_APP  = "application";
	public static final String CATEGORY_EPDSM_INQ  = "inquiry";
	public static final String CATEGORY_EPDSM_SOFT = "software";
	public static final String CATEGORY_EPDSM_HARD = "hardware";
	public static final String CATEGORY_EPDSM_NET  = "network";
	public static final String CATEGORY_EPDSM_DB   = "database";
	
	public static HashMap<String, String> CATEGORY_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(CATEGORY_EPDSM_APP,  "Application");
	    put(CATEGORY_EPDSM_INQ,  "Inquiry / Help");
	    put(CATEGORY_EPDSM_SOFT, "Software");
	    put(CATEGORY_EPDSM_HARD, "Hardware");
	    put(CATEGORY_EPDSM_NET,  "Network");
	    put(CATEGORY_EPDSM_DB,   "Database");
	}};
	
	public static final String STATE_EPDSM_NEW         = "1";
	public static final String STATE_EPDSM_IN_PROGRESS = "2";
	public static final String STATE_EPDSM_ON_HOLD     = "3";
	public static final String STATE_EPDSM_RESOLVED    = "6";
	public static final String STATE_EPDSM_CLOSED      = "7";
	public static final String STATE_EPDSM_CANCELED    = "8";
	
	public static HashMap<String, String> STATE_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(STATE_EPDSM_NEW,         "New");
	    put(STATE_EPDSM_IN_PROGRESS, "In Progress");
	    put(STATE_EPDSM_ON_HOLD,     "On Hold");
	    put(STATE_EPDSM_RESOLVED,    "Resolved");
	    put(STATE_EPDSM_CLOSED,      "Closed");
	    put(STATE_EPDSM_CANCELED,    "Canceled");
	}};
	
	public static final String SERVICE_EPDSM_QUANTUM   = "quantum";
	public static final String SERVICE_EPDSM_SAPEBO    = "SAP_EBO";
	public static final String SERVICE_EPDSM_LOTUS     = "Lotus_Notes";
	public static final String SERVICE_EPDSM_OUTLOOK   = "Outlook";
	public static final String SERVICE_EPDSM_CITRIX    = "Citrix";
	public static final String SERVICE_EPDSM_VPN       = "VPN";
	public static final String SERVICE_EPDSM_ODE       = "ODE";
	public static final String SERVICE_EPDSM_OMA       = "OMA";
	public static final String SERVICE_EPDSM_EXPMGR    = "Express_Manager";
	public static final String SERVICE_EPDSM_UNIVERSE  = "Universe";
	public static final String SERVICE_EPDSM_MYTNT     = "MyTNT";
	public static final String SERVICE_EPDSM_TIMS      = "Tims";
	public static final String SERVICE_EPDSM_OTHER     = "Other";
	public static final String SERVICE_EPDSM_PHYS      = "Physical";
	public static final String SERVICE_EPDSM_AOG       = "AoG";
	public static final String SERVICE_EPDSM_DESKTOP   = "Desktop";
	public static final String SERVICE_EPDSM_LAPTOP    = "Laptop";
	public static final String SERVICE_EPDSM_SERVER    = "Server";
	public static final String SERVICE_EPDSM_SORTER    = "Sorter";
	public static final String SERVICE_EPDSM_SCANNER   = "Scanner";
	public static final String SERVICE_EPDSM_STORAGE   = "Storage";
	public static final String SERVICE_EPDSM_PERIPH    = "Peripheral";
	public static final String SERVICE_EPDSM_TAPE      = "Tape";
	public static final String SERVICE_EPDSM_AD        = "AD";
	public static final String SERVICE_EPDSM_DB        = "Database";
	public static final String SERVICE_EPDSM_MAINFR    = "Mainframe";
	public static final String SERVICE_EPDSM_IBIS      = "IBIS";
	public static final String SERVICE_EPDSM_MQ        = "MQ";
	public static final String SERVICE_EPDSM_ENGIN     = "Engin";
	public static final String SERVICE_EPDSM_SWITCH    = "Switch";
	public static final String SERVICE_EPDSM_ROUTER    = "Router";
	public static final String SERVICE_EPDSM_CABLING   = "Cabling";
	public static final String SERVICE_EPDSM_ACCESSP   = "Access_Point";
	public static final String SERVICE_EPDSM_CIRCUIT   = "Circuit";
	public static final String SERVICE_EPDSM_SITE      = "Site";
	public static final String SERVICE_EPDSM_MCAFEE    = "McAfee";
	public static final String SERVICE_EPDSM_TANIUM    = "Tanium";
	public static final String SERVICE_EPDSM_FIREW     = "Firewall";
	public static final String SERVICE_EPDSM_ALERT     = "Alert";
	public static final String SERVICE_EPDSM_AVAYA     = "Avaya";
	public static final String SERVICE_EPDSM_HANDSET   = "Handset";
	public static final String SERVICE_EPDSM_IVR       = "IVR";
	public static final String SERVICE_EPDSM_VOIP      = "VIOP";
	public static final String SERVICE_EPDSM_CALLPILOT = "Call_Pilot";
	
	public static HashMap<String, String> SERVICE_EPDSM_LIST = new HashMap<String, String>() {
		private static final long serialVersionUID = 1L;
	{
		put(SERVICE_EPDSM_QUANTUM,   "Quantum");
		put(SERVICE_EPDSM_SAPEBO,    "SAP EBO");
		put(SERVICE_EPDSM_LOTUS,     "Lotus Notes");
		put(SERVICE_EPDSM_OUTLOOK,   "Outlook");
		put(SERVICE_EPDSM_CITRIX,    "Citrix");
		put(SERVICE_EPDSM_VPN,       "VPN");
		put(SERVICE_EPDSM_ODE,       "ODE");
		put(SERVICE_EPDSM_OMA,       "OMA");
		put(SERVICE_EPDSM_EXPMGR,    "Express Manager");
		put(SERVICE_EPDSM_UNIVERSE,  "Universe");
		put(SERVICE_EPDSM_MYTNT,     "MyTNT");
		put(SERVICE_EPDSM_TIMS,      "TIMS (PACS / DUC / PODS)");
		put(SERVICE_EPDSM_OTHER,     "Other");
		put(SERVICE_EPDSM_PHYS,      "Physical");
		put(SERVICE_EPDSM_AOG,       "AoG");
		put(SERVICE_EPDSM_DESKTOP,   "Desktop");
		put(SERVICE_EPDSM_LAPTOP,    "Laptop");
		put(SERVICE_EPDSM_SERVER,    "Server");
		put(SERVICE_EPDSM_SORTER,    "Sorter");
		put(SERVICE_EPDSM_SCANNER,   "Scanner");
		put(SERVICE_EPDSM_STORAGE,   "Storage");
		put(SERVICE_EPDSM_PERIPH,    "Peripheral");
		put(SERVICE_EPDSM_TAPE,      "Tape/Tape Drive");
		put(SERVICE_EPDSM_AD,        "AD");
		put(SERVICE_EPDSM_DB,        "Database");
		put(SERVICE_EPDSM_MAINFR,    "Mainframe");
		put(SERVICE_EPDSM_IBIS,      "IBIS");
		put(SERVICE_EPDSM_MQ,        "MQ");
		put(SERVICE_EPDSM_ENGIN,     "Engin");
		put(SERVICE_EPDSM_SWITCH,    "Switch");
		put(SERVICE_EPDSM_ROUTER,    "Router");
		put(SERVICE_EPDSM_CABLING,   "Cabling");
		put(SERVICE_EPDSM_ACCESSP,   "Access Point");
		put(SERVICE_EPDSM_CIRCUIT,   "Circuit");
		put(SERVICE_EPDSM_SITE,      "Site");
		put(SERVICE_EPDSM_MCAFEE,    "McAfee");
		put(SERVICE_EPDSM_TANIUM,    "Tanium");
		put(SERVICE_EPDSM_FIREW,     "Firewall");
		put(SERVICE_EPDSM_ALERT,     "Alert");
		put(SERVICE_EPDSM_AVAYA,     "Avaya");
		put(SERVICE_EPDSM_HANDSET,   "Handset");
		put(SERVICE_EPDSM_IVR,       "IVR");
		put(SERVICE_EPDSM_VOIP,      "VIOP");
		put(SERVICE_EPDSM_CALLPILOT, "Call Pilot");
	}};
	
	// ======================================================================
	
	public static final String OPER_EQUAL         = "=";
	public static final String OPER_DIFF          = "!=";
	public static final String OPER_STARTW        = "STARTSWITH";
	public static final String OPER_ENDW          = "ENDSWITH";
	public static final String OPER_LIKE          = "LIKE";
	public static final String OPER_NOTLIKE       = "NOTLIKE";
	public static final String OPER_ISEMPTY       = "ISEMPTY";
	public static final String OPER_ISNOTEMPTY    = "ISNOTEMPTY";
	public static final String OPER_FLD_SAMEAS    = "SAMEAS";
	public static final String OPER_FLD_NOTSAMEAS = "NSAMEAS";
	public static final String OPER_IN            = "IN";
	public static final String OPER_NOT_IN        = "NOT IN";
	public static final String OPER_LT            = "<";
	public static final String OPER_GT            = ">";
	public static final String OPER_LE            = "<=";
	public static final String OPER_GE            = ">=";
	public static final String OPER_BETWEEN       = "BETWEEN";
	public static final String OPER_FLD_GT        = "GT_FIELD";
	public static final String OPER_FLD_LT        = "LT_FIELD";
	public static final String OPER_FLD_GE        = "GT_OR_EQUALS_FIELD";
	public static final String OPER_FLD_LE        = "LT_OR_EQUALS_FIELD";
	
	
	public static final String TBL_SYS_USER            = "sys_user";
	public static final String FIELDS_SYS_USER         = "active,company,country,email,first_name,last_name,manager,name,phone,sys_created_on,sys_id,u_fedex_ldap_id,u_pin,user_name";
	
	public static final String TBL_SYS_USER_GROUP      = "sys_user_group";
	public static final String FIELDS_SYS_USER_GROUP   = "description,sys_id,name,u_fedex_and_tnt_shared,u_reporting_level_1,u_reporting_level_2,u_workgroup_role";
	
	public static final String TBL_SYS_JOURNAL_FIELD   = "sys_journal_field";
	
	public static final String TBL_CMDB_CI_SERVICE     = "cmdb_ci_service";
	public static final String FIELDS_CMDB_CI_SERVICE  = "sys_id,name,u_business_criticality_fdx,u_service_category,u_support_structure";
	
	public static final String TBL_CMDB_CI             = "cmdb_ci";
	
	public static final String TBL_CORE_COMPANY        = "core_company";
	public static final String FIELDS_CORE_COMPANY     = "u_organisation_category,name,sys_id,u_organisation_level,u_top_layer";
	
	public static final String TBL_CMN_LOCATION        = "cmn_location";
	public static final String FIELDS_CMN_LOCATION     = "country,u_loc_category,city,sys_id,state,name,u_locid";
	
	public static final String TBL_CORE_COUNTRY        = "core_country";
	public static final String FIELDS_CORE_COUNTRY     = "active,sys_id,name,iso3166_2,iso3166_3";
	
	public static final String TBL_INCIDENT            = "incident";
	public static final String FIELDS_INCIDENT         = "assigned_to,assignment_group,category,close_notes,closed_at,closed_by,cmdb_ci,company,contact_type,description,impact,location,made_sla,"
			+ "number,opened_at,opened_by,priority,resolved_at,resolved_by,severity,short_description,sla_due,state,subcategory,sys_class_name,sys_created_by,"
			+ "sys_created_on,sys_id,sys_updated_by,sys_updated_on,u_affected_user,u_business_service,u_caused_by,u_classification,u_created_by_workgroup,"
			+ "u_escalated,u_initial_assignment,u_knowledge_available,u_resolved_by,u_resolved_by_workgroup,u_sites_affected,u_support_structure,u_users_affected,urgency,work_notes,"
			+ "u_application_code,u_batch_step,u_job_number,u_instructions,u_third_party_reference";
	
	public static final String TBL_REQUEST             = "sc_request";
	public static final String FIELDS_REQUEST          = "assigned_to,assignment_group,category,close_code,close_notes,closed_at,closed_by,cmdb_ci,contact_type,description,impact,location,made_sla,number,opened_at,opened_by,"
			+ "priority,request_state,requested_date,requested_for,rfc,short_description,sla_due,stage,state,subcategory,sys_class_name,sys_created_by,sys_created_on,sys_id,"
			+ "sys_updated_by,sys_updated_on,u_affected_user,u_business_service,u_caused_by,u_classification,u_comments_and_work_notes,u_copy_comments,u_escalated,u_first_deadline,"
			+ "u_initial_assignment,u_instructions,u_knowledge_available,u_resolved_by,u_resolved_by_workgroup,u_resolver,u_second_deadline,u_support_structure,u_third_line_date,"
			+ "u_users_affected,urgency,work_effort,work_notes";
	
	public static final String TBL_TASK                = "task";
	
	public static final String TBL_INCIDENT_METRIC     = "incident_metric";
	public static final String FIELDS_INCIDENT_METRIC  = "inc_assigned_to,inc_assignment_group,inc_category,inc_close_notes,inc_closed_at,inc_closed_by,inc_cmdb_ci,inc_company,"
			+ "inc_contact_type,inc_description,inc_impact,inc_location,inc_made_sla,inc_number,inc_opened_at,inc_opened_by,inc_priority,"
			+ "inc_resolved_at,inc_resolved_by,inc_severity,inc_short_description,inc_sla_due,inc_state,inc_subcategory,inc_sys_class_name,"
			+ "inc_sys_created_by,inc_sys_created_on,inc_sys_id,inc_sys_updated_by,inc_sys_updated_on,inc_u_affected_user,inc_u_business_service,"
			+ "inc_u_caused_by,inc_u_classification,inc_u_created_by_workgroup,inc_u_escalated,inc_u_initial_assignment,inc_u_knowledge_available,"
			+ "inc_u_resolved_by,inc_u_resolved_by_workgroup,inc_u_sites_affected,inc_u_support_structure,inc_u_users_affected,inc_urgency,inc_work_notes,"
			+ "inc_u_application_code,inc_u_batch_step,inc_u_job_number,inc_u_instructions,inc_u_third_party_reference,"
			+ "md_field,mi_calculation_complete,mi_end,mi_field_value,mi_start,mi_value";
	
	public static final String TBL_INCIDENT_SLA        = "incident_sla";
	public static final String TBL_PROBLEM_METRIC      = "problem_metric";
	
	public static final String TBL_REQUEST_METRIC      = "sc_request_metric";
	public static final String FIELDS_REQUEST_METRIC   = "scr_assigned_to,scr_assignment_group,scr_category,scr_close_code,scr_close_notes,scr_closed_at,scr_closed_by,scr_cmdb_ci,scr_contact_type,scr_description,"
			+ "scr_impact,scr_location,scr_made_sla,scr_number,scr_opened_at,scr_opened_by,scr_priority,scr_request_state,scr_requested_date,scr_requested_for,scr_rfc,"
			+ "scr_short_description,scr_sla_due,scr_stage,scr_state,scr_subcategory,scr_sys_class_name,scr_sys_created_by,scr_sys_created_on,scr_sys_id,scr_sys_updated_by,"
			+ "scr_sys_updated_on,scr_u_affected_user,scr_u_business_service,scr_u_caused_by,scr_u_classification,scr_u_comments_and_work_notes,scr_u_copy_comments,scr_u_escalated,"
			+ "scr_u_first_deadline,scr_u_initial_assignment,scr_u_instructions,scr_u_knowledge_available,scr_u_resolved_by,scr_u_resolved_by_workgroup,scr_u_resolver,"
			+ "scr_u_second_deadline,scr_u_support_structure,scr_u_third_line_date,scr_u_users_affected,scr_urgency,scr_work_effort,scr_work_notes,"	
			+ "md_field,mi_calculation_complete,mi_end,mi_field_value,mi_start,mi_value";
	
	public static final String TBL_REQUEST_SLA         = "sc_request_sla";
	
	public static final String TBL_U_ASTC_INCIDENT        = "u_astc_incident";
	public static final String TBL_U_ASTC_INCIDENT_UPDATE = "u_astc_incident_update";
	
	public static final String TBL_CMDB_CI_BUSINESS_APP = "cmdb_ci_business_app";
	public static final String FIELDS_CMDB_CI_BUSINESS_APP = "sys_id,name,u_eai_id,u_application_code,it_application_owner,business_criticality,u_business_function,u_environment,u_it_lead,emergency_tier,u_integration_source,operational_status,u_app_use,active";
	
	public static final String TBL_CMDB_CI_DATABASE = "cmdb_ci_database";
	
}
