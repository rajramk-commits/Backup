package com.fedex.emea.sd.ovo.processor;

import com.fedex.emea.sd.da.dao.ExternalInterfaceDao;
import com.fedex.emea.sd.da.dao.OvoMessagesDao;
import com.fedex.emea.sd.da.helpers.Utilities;
import com.fedex.emea.sd.da.logger.ApplicationLogger;
//import com.fedex.emea.sd.da.objects.AppsOnServer;
import com.fedex.emea.sd.da.objects.ExternalInterface;
//import com.fedex.emea.sd.da.objects.NetworkEquipments;
import com.fedex.emea.sd.da.objects.OvoMessages;
import com.fedex.emea.sd.da.objects.OvoObject;
import com.fedex.emea.sd.da.objects.SupportTicketClassification;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.dao.DataAccessException;

public class InterfaceRecordCreator {
	private static final boolean IN_PRODUCTION = false;

	private static ApplicationLogger logger = ApplicationLogger.getInstance();

	private static ExternalInterfaceDao externalInterfaceDao;

	private static OvoMessagesDao ovoMessagesDao;

	private static SupportTicketClassification supportTicketClassificatorForExternalInterface;

	private static long MAX_ALERT_INTERVAL = 28800L;

	private static long PRODUCTION_ALERT_INTERVAL = 28800L;

	private static long NON_PRODUCTION_ALERT_INTERVAL = 259200L;

	public static void main(String[] args) {
		logger.logInfo("OBM Side Agent started...");
		String completeOVO;
		OvoObject ovoObject=null;
		try {
			completeOVO = getCompleteOVO(args);
			ovoObject = new OvoObject(completeOVO);
			
			if (alertToProcess(ovoObject)) {
				logger.logInfo("Processing OBM Alert: " + completeOVO);
				if (processAlert(ovoObject)) {
					logger.logInfo("External Interface Record successfully created for OBM Alert ID="
							+ ovoObject.getMessageID());
				} else {
					logger.logDebug("Skipped OBM Alert: " + completeOVO);
				}
			} else {
				logger.logDebug("Skipped OBM Alert: " + completeOVO);
			}
		} catch (DataAccessException e) {
			logger.logInfo("External Interface Record NOT created (OBM Alert ID=" + ovoObject.getMessageID()
					+ "). See Error.log for details");
			logger.logError("External Interface Record NOT created (Data Access): " + e.getMessage());
		} catch (SQLException e) {
			logger.logInfo("External Interface Record NOT created (OBM Alert ID=" + ovoObject.getMessageID()
					+ "). See Error.log for details");
			logger.logError("External Interface Record NOT created (SQL): " + e.getMessage());
		} catch (IOException e) {
			logger.logInfo("External Interface Record NOT created (OBM Alert ID=" + ovoObject.getMessageID()
					+ "). See Error.log for details");
			logger.logError("External Interface Record NOT created (I/O): " + e.getMessage());
		} catch (Exception e) {
			logger.logInfo("External Interface Record NOT created (OBM Alert ID=" + ovoObject.getMessageID()
					+ "). See Error.log for details");
			logger.logError("External Interface Record NOT created (Other): " + e.getMessage());
		} finally {
			logger.logInfo("OBM Side Agent completed.");
		}
	}

	private static String getCompleteOVO(String[] args) {
		String OvoString = "";
		for (int i = 0; i < args.length; i++) {
			if (i > 0)
				OvoString = String.valueOf(OvoString) + " ";
			OvoString = String.valueOf(OvoString) + args[i];
		}
		return OvoString;
	}

	private static boolean alertToProcess(OvoObject ovoObject) {
		boolean alertToBeProcessed = false;
		String ovoMsgSeverity = ovoObject.getMessageSeverity().toUpperCase();
		alertToBeProcessed = ovoMsgSeverity.equals("CRITICAL");
		return alertToBeProcessed;
	}

	private static boolean processAlert(OvoObject ovoObject)
			throws DataAccessException, SQLException, IOException, Exception {
		boolean alertProcessed = false;
		ClassPathResource classPathResource = new ClassPathResource("spring-config.xml");
		XmlBeanFactory beanFactory = new XmlBeanFactory((Resource) classPathResource);
		
		if (IN_PRODUCTION) {
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesDao");
		} else {
			externalInterfaceDao = (ExternalInterfaceDao) beanFactory.getBean("externalInterfaceTestDao");
			ovoMessagesDao       = (OvoMessagesDao)       beanFactory.getBean("ovoMessagesTestDao");
		}
		
		supportTicketClassificatorForExternalInterface = assignTicketClassificationForExternalInterface(ovoObject);
		ExternalInterface externalInterfaceRecord = new ExternalInterface(ovoObject, supportTicketClassificatorForExternalInterface);
		OvoMessages ovoMessagesRecord = new OvoMessages(ovoObject, supportTicketClassificatorForExternalInterface.getCaseId());
		ovoMessagesDao.create(ovoMessagesRecord);
		externalInterfaceDao.create(externalInterfaceRecord);
		alertProcessed = true;
		return alertProcessed;
	}

	private static SupportTicketClassification assignTicketClassificationForExternalInterface(OvoObject ovoObject) {
		StringBuffer newCaseDescription = new StringBuffer();
		StringBuffer appsOnImpactedServerDescription = new StringBuffer();
		StringBuffer productionStatusDescription = new StringBuffer();
		boolean isProductionServer = false;
		//boolean isRegisteredInCMDB = false;
		//NetworkEquipments impactedServer = null;
		//String serverOStype = "";
		String providerGroup = "";
		supportTicketClassificatorForExternalInterface = new SupportTicketClassification();
		String[] elements = ovoObject.getObjectName().split(" \\+ ");
		if (validOvoObject(elements)) {
			supportTicketClassificatorForExternalInterface.setCaseASCF(elements[0], elements[1], elements[2],
					elements[3]);
		} else {
			supportTicketClassificatorForExternalInterface.setCaseASCF("ITD", "UNDEF", "UNDEF", "UNDEF");
		}
		String serverName = ovoObject.getMessageNodeName().substring(0, ovoObject.getMessageNodeName().indexOf("."))
				.toUpperCase();
		try {
			isProductionServer = ServerDetail.getServerDetails(serverName);
			providerGroup = ServerDetail.getSupportGroupName(serverName);
			if (isProductionServer) {
				MAX_ALERT_INTERVAL = PRODUCTION_ALERT_INTERVAL;
				productionStatusDescription.append("Server Status in CMDB : PRODUCTION\n");
				//productionStatusDescription.append("Server Function : " + impactedServer.getServerFunction() + "\n");
				//productionStatusDescription.append("Applications hosted : " + impactedServer.getApplicationHosted() + "\n");
				productionStatusDescription
						.append("___________________________________________________________________________________"
								+ System.getProperty("line.separator"));
				supportTicketClassificatorForExternalInterface.setCaseBusinessUnit("SDESK");
				supportTicketClassificatorForExternalInterface.setCaseStatus("OPEN");
				supportTicketClassificatorForExternalInterface.setCaseType("INCID");
				if (ovoObject.getMessageSeverity().toUpperCase().equals("CRITICAL")) {
					supportTicketClassificatorForExternalInterface.setCasePriority("TOOHIGH");
					supportTicketClassificatorForExternalInterface.setCaseProviderGroup("ATLAS");
				}
				if (ovoObject.getMessageSeverity().toUpperCase().equals("MAJOR"))
					logger.logInfo("Major Alerts received but not processed at this moment");
				if (ovoObject.getMessageSeverity().toUpperCase().equals("MINOR"))
					logger.logInfo("Minor Alerts received but not processed at this moment");
			} else {
				logger.logDebug("Non Prod server :" + serverName + " assigning to SSA");
				MAX_ALERT_INTERVAL = NON_PRODUCTION_ALERT_INTERVAL;
				productionStatusDescription.append("Server Status in CMDB : NON-PRODUCTION\n");
				supportTicketClassificatorForExternalInterface.setCasePriority("MED");
				
				productionStatusDescription
						.append("___________________________________________________________________________________"
								+ System.getProperty("line.separator"));
				supportTicketClassificatorForExternalInterface.setCaseBusinessUnit("SSA");
				supportTicketClassificatorForExternalInterface.setCaseStatus("OPEN");
				supportTicketClassificatorForExternalInterface.setCaseType("INCID");
				supportTicketClassificatorForExternalInterface.setCaseProviderGroup(providerGroup);
			}
			newCaseDescription.append(productionStatusDescription.toString());
			newCaseDescription.append(appsOnImpactedServerDescription.toString());
			supportTicketClassificatorForExternalInterface.setCaseDescription(newCaseDescription.toString());
		} catch (Exception e) {
			logger.logError("Unable to process for Server information. " + e.getMessage());
			supportTicketClassificatorForExternalInterface.setCaseBusinessUnit("SDESK");
			supportTicketClassificatorForExternalInterface.setCaseStatus("OPEN");
			supportTicketClassificatorForExternalInterface.setCaseType("INCID");
			if (ovoObject.getMessageSeverity().toUpperCase().equals("CRITICAL"))
				supportTicketClassificatorForExternalInterface.setCasePriority("TOOHIGH");
			if (ovoObject.getMessageSeverity().toUpperCase().equals("MAJOR"))
				supportTicketClassificatorForExternalInterface.setCasePriority("MED");
			if (ovoObject.getMessageSeverity().toUpperCase().equals("MINOR"))
				supportTicketClassificatorForExternalInterface.setCasePriority("LOW");
			supportTicketClassificatorForExternalInterface.setCaseProviderGroup("ATLAS");
			supportTicketClassificatorForExternalInterface.setCaseDescription("\nNo data available from CMDB.\n");
		}
		supportTicketClassificatorForExternalInterface.setCaseSource("OBM");
		supportTicketClassificatorForExternalInterface
				.setCaseSummary("GA/OBM Alert on " + ovoObject.getMessageReceiveDate_ManagementServer() + " at "
						+ ovoObject.getMessageReceiveTime_ManagementServer() + " GMT");
		supportTicketClassificatorForExternalInterface.setCaseId(null);
		supportTicketClassificatorForExternalInterface.setCaseSysId(null);
		supportTicketClassificatorForExternalInterface.setCaseNumber(null);
		supportTicketClassificatorForExternalInterface.setIntervalForSimilar(0L);
		try {
			ExternalInterface supportTicket = getSupportTicketForSameAlert(ovoObject);
			if (supportTicket != null) {
				supportTicketClassificatorForExternalInterface.setCaseSource("ADD-NOTE");
				supportTicketClassificatorForExternalInterface.setCaseSummary("Similar Alert received");
				supportTicketClassificatorForExternalInterface.setCaseId(supportTicket.getCaseId());
				supportTicketClassificatorForExternalInterface
						.setIntervalForSimilar(supportTicket.getSameCaseInterval());
				supportTicketClassificatorForExternalInterface.setCaseNumber(supportTicket.getCaseId());
				supportTicketClassificatorForExternalInterface.setCaseSysId(supportTicket.getCaseSysId());
				logger.logInfo("Similar Support Ticket found in External_Interface NOT older enough. Incident "
						+ supportTicket.getCaseId() + " (" + supportTicket.getSameCaseInterval()
						+ " seconds ago) => Note added.");
			}
		} catch (SQLException e) {
			logger.logInfo("Unable to check for existing Alert. New Support Ticket will be created (OBM Alert ID="
					+ ovoObject.getMessageID() + "). See Error.log for details");
			logger.logError("Unable to check for existing Alert. " + e.getMessage());
		}
		return supportTicketClassificatorForExternalInterface;
	}

	private static ExternalInterface getSupportTicketForSameAlert(OvoObject ovoObject) throws SQLException {
		ExternalInterface supportTicket = null;
		long minimumInterval = 999999999L;
		String selectedMessageId = "";
		List<OvoMessages> ovoMessagesList = ovoMessagesDao.loadSimilarObjectFromExternalInterface(
				ovoObject.getMessageNodeName(), ovoObject.getMessageGroup(), ovoObject.getApplicationName(),
				ovoObject.getObjectName());
		for (Iterator<?> iter = ovoMessagesList.iterator(); iter.hasNext();) {
			OvoMessages element = (OvoMessages) iter.next();
			if (Utilities.getIntervalTimeUntilNow(element.getCreationTime()) < minimumInterval) {
				minimumInterval = Utilities.getIntervalTimeUntilNow(element.getCreationTime());
				selectedMessageId = element.getOvoMessageId();
			}
		}
		if (!selectedMessageId.trim().equals("") && minimumInterval <= MAX_ALERT_INTERVAL) {
			supportTicket = externalInterfaceDao.getObjectByRecordSourceId(selectedMessageId);
			supportTicket.setSameCaseInterval(minimumInterval);
		}
		return supportTicket;
	}

	private static boolean validOvoObject(String[] alertObjectElements) {
		boolean isValid = true;
		if (alertObjectElements == null) {
			isValid = false;
		} else if (alertObjectElements.length != 4) {
			isValid = false;
		} else if (alertObjectElements[0].length() > 10 || alertObjectElements[1].length() > 10
				|| alertObjectElements[2].length() > 10 || alertObjectElements[3].length() > 10) {
			isValid = false;
		}
		return isValid;
	}
	
}
