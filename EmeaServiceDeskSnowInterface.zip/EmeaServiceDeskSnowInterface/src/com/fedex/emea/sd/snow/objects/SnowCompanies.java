package com.fedex.emea.sd.snow.objects;

import java.io.Serializable;
import java.util.HashMap;

import org.json.JSONObject;

import com.fedex.emea.sd.snow.utilities.SnowUtilities;

public class SnowCompanies implements Serializable {

	private static final long serialVersionUID = 1501714001969142180L;
	
	private String snowAppleIcon;
	private String snowBannerImage;
	private String snowBannerImageLight;
	private String snowBannerText;
	private String snowCity;
	private String snowContact;
	private String snowCustomer;
	private String snowDiscount;
	private String snowFaxPhone;
	private String snowFiscalYear;
	private String snowLatLongError;
	private String snowLatitude;
	private String snowLatitudeOld;
	private String snowLongitude;
	private String snowLongitudeOld;
	private String snowManufacturer;
	private String snowMarketCap;
	private String snowName;
	private String snowNotes;
	private String snowNumEmployees;
	private String snowParent;
	private String snowPhone;
	private String snowPrimary;
	private String snowProfits;
	private String snowPubliclyTraded;
	private String snowRankTier;
	private String snowRevenuePerYear;
	private String snowSsoSource;
	private String snowState;
	private String snowStockPrice;
	private String snowStockSymbol;
	private String snowStreet;
	private String snowSysClassName;
	private String snowSysCreatedBy;
	private String snowSysCreatedOn;
	private String snowSysId;
	private String snowSysModCount;
	private String snowSysTags;
	private String snowSysUpdatedBy;
	private String snowSysUpdatedOn;
	private String snowU_Active;
	private String snowU_AutocloseClosed;
	private String snowU_AutocloseConfirmation;
	private String snowU_AwaitingConfirmation;
	private String snowU_Blocked;
	private String snowU_BusinessType;
	private String snowU_Closed;
	private String snowU_Contact;
	private String snowU_CountryIcsManager;
	private String snowU_Footer;
	private String snowU_FtfWorkgroup;
	private String snowU_KnowledgeApprovalConfirmat;
	private String snowU_KnowledgeAwaitingApproval;
	private String snowU_KnowledgeRepublished;
	private String snowU_LocalHelpdesk;
	private String snowU_LocalIsRep;
	private String snowU_Location;
	private String snowU_Manager;
	private String snowU_NetworkSiteType;
	private String snowU_Now92Site;
	private String snowU_OrganisationAccountNumber;
	private String snowU_OrganisationCategory;
	private String snowU_OrganisationControllingDep;
	private String snowU_OrganisationCostCentre;
	private String snowU_OrganisationEmail;
	private String snowU_OrganisationLevel;
	private String snowU_OrganisationLocalIsRepNa;
	private String snowU_OrganisationLocalIsRepSe;
	private String snowU_OrganisationName2;
	private String snowU_OrganisationSearchcode;
	private String snowU_OrganisationSourceId;
	private String snowU_OrganisationTelephoneShort;
	private String snowU_RegionalDirector;
	private String snowU_RegionalIcsManager;
	private String snowU_RegionalServiceDeliveryMa;
	private String snowU_RegisteredEmail;
	private String snowU_ReportingLevel1;
	private String snowU_ReportingLevel2;
	private String snowU_ReportingLevel3;
	private String snowU_RequestResolved;
	private String snowU_SourceId;
	private String snowU_SspDefaultRole;
	private String snowU_SurveyFooter;
	private String snowU_SurveyHeader;
	private String snowU_TimeZone;
	private String snowU_TntSiteType;
	private String snowU_TopLayer;
	private String snowVendor;
	private String snowVendorManager;
	private String snowVendorType;
	private String snowWebsite;
	private String snowZip;
	
	public SnowCompanies() {
	}
	
	public SnowCompanies(HashMap<String, Object> jsonValues) {
		snowAppleIcon = SnowUtilities.getStringValueFromObject(jsonValues.get("apple_icon"));
		snowBannerImage = SnowUtilities.getStringValueFromObject(jsonValues.get("banner_image"));
		snowBannerImageLight = SnowUtilities.getStringValueFromObject(jsonValues.get("banner_image_light"));
		snowBannerText = SnowUtilities.getStringValueFromObject(jsonValues.get("banner_text"));
		snowCity = SnowUtilities.getStringValueFromObject(jsonValues.get("city"));
		snowContact = SnowUtilities.getStringValueFromObject(jsonValues.get("contact"));
		snowCustomer = SnowUtilities.getStringValueFromObject(jsonValues.get("customer"));
		snowDiscount = SnowUtilities.getStringValueFromObject(jsonValues.get("discount"));
		snowFaxPhone = SnowUtilities.getStringValueFromObject(jsonValues.get("fax_phone"));
		snowFiscalYear = SnowUtilities.getStringValueFromObject(jsonValues.get("fiscal_year"));
		snowLatLongError = SnowUtilities.getStringValueFromObject(jsonValues.get("lat_long_error"));
		snowLatitude = SnowUtilities.getStringValueFromObject(jsonValues.get("latitude"));
		snowLatitudeOld = SnowUtilities.getStringValueFromObject(jsonValues.get("latitude_old"));
		snowLongitude = SnowUtilities.getStringValueFromObject(jsonValues.get("longitude"));
		snowLongitudeOld = SnowUtilities.getStringValueFromObject(jsonValues.get("longitude_old"));
		snowManufacturer = SnowUtilities.getStringValueFromObject(jsonValues.get("manufacturer"));
		snowMarketCap = SnowUtilities.getStringValueFromObject(jsonValues.get("market_cap"));
		snowName = SnowUtilities.getStringValueFromObject(jsonValues.get("name"));
		snowNotes = SnowUtilities.getStringValueFromObject(jsonValues.get("notes"));
		snowNumEmployees = SnowUtilities.getStringValueFromObject(jsonValues.get("num_employees"));
		snowParent = SnowUtilities.getStringValueFromObject(jsonValues.get("parent"));
		snowPhone = SnowUtilities.getStringValueFromObject(jsonValues.get("phone"));
		snowPrimary = SnowUtilities.getStringValueFromObject(jsonValues.get("primary"));
		snowProfits = SnowUtilities.getStringValueFromObject(jsonValues.get("profits"));
		snowPubliclyTraded = SnowUtilities.getStringValueFromObject(jsonValues.get("publicly_traded"));
		snowRankTier = SnowUtilities.getStringValueFromObject(jsonValues.get("rank_tier"));
		snowRevenuePerYear = SnowUtilities.getStringValueFromObject(jsonValues.get("revenue_per_year"));
		snowSsoSource = SnowUtilities.getStringValueFromObject(jsonValues.get("sso_source"));
		snowState = SnowUtilities.getStringValueFromObject(jsonValues.get("state"));
		snowStockPrice = SnowUtilities.getStringValueFromObject(jsonValues.get("stock_price"));
		snowStockSymbol = SnowUtilities.getStringValueFromObject(jsonValues.get("stock_symbol"));
		snowStreet = SnowUtilities.getStringValueFromObject(jsonValues.get("street"));
		snowSysClassName = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_class_name"));
		snowSysCreatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_by"));
		snowSysCreatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_created_on"));
		snowSysId = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_id"));
		snowSysModCount = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_mod_count"));
		snowSysTags = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_tags"));
		snowSysUpdatedBy = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_by"));
		snowSysUpdatedOn = SnowUtilities.getStringValueFromObject(jsonValues.get("sys_updated_on"));
		snowU_Active = SnowUtilities.getStringValueFromObject(jsonValues.get("u_active"));
		snowU_AutocloseClosed = SnowUtilities.getStringValueFromObject(jsonValues.get("u_autoclose_closed"));
		snowU_AutocloseConfirmation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_autoclose_confirmation"));
		snowU_AwaitingConfirmation = SnowUtilities.getStringValueFromObject(jsonValues.get("u_awaiting_confirmation"));
		snowU_Blocked = SnowUtilities.getStringValueFromObject(jsonValues.get("u_blocked"));
		snowU_BusinessType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_business_type"));
		snowU_Closed = SnowUtilities.getStringValueFromObject(jsonValues.get("u_closed"));
		snowU_Contact = SnowUtilities.getStringValueFromObject(jsonValues.get("u_contact"));
		snowU_CountryIcsManager = SnowUtilities.getStringValueFromObject(jsonValues.get("u_country_ics_manager"));
		snowU_Footer = SnowUtilities.getStringValueFromObject(jsonValues.get("u_footer"));
		snowU_FtfWorkgroup = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ftf_workgroup"));
		snowU_KnowledgeApprovalConfirmat = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_approval_confirmat"));
		snowU_KnowledgeAwaitingApproval = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_awaiting_approval"));
		snowU_KnowledgeRepublished = SnowUtilities.getStringValueFromObject(jsonValues.get("u_knowledge_republished"));
		snowU_LocalHelpdesk = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_helpdesk"));
		snowU_LocalIsRep = SnowUtilities.getStringValueFromObject(jsonValues.get("u_local_is_rep"));
		snowU_Location = SnowUtilities.getStringValueFromObject(jsonValues.get("u_location"));
		snowU_Manager = SnowUtilities.getStringValueFromObject(jsonValues.get("u_manager"));
		snowU_NetworkSiteType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_network_site_type"));
		snowU_Now92Site = SnowUtilities.getStringValueFromObject(jsonValues.get("u_now92_site"));
		snowU_OrganisationAccountNumber = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_account_number"));
		snowU_OrganisationCategory = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_category"));
		snowU_OrganisationControllingDep = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_controlling_dep"));
		snowU_OrganisationCostCentre = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_cost_centre"));
		snowU_OrganisationEmail = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_email"));
		snowU_OrganisationLevel = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_level"));
		snowU_OrganisationLocalIsRepNa = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_local_is_rep_na"));
		snowU_OrganisationLocalIsRepSe = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_local_is_rep_se"));
		snowU_OrganisationName2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_name_2"));
		snowU_OrganisationSearchcode = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_searchcode"));
		snowU_OrganisationSourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_source_id"));
		snowU_OrganisationTelephoneShort = SnowUtilities.getStringValueFromObject(jsonValues.get("u_organisation_telephone_short"));
		snowU_RegionalDirector = SnowUtilities.getStringValueFromObject(jsonValues.get("u_regional_director"));
		snowU_RegionalIcsManager = SnowUtilities.getStringValueFromObject(jsonValues.get("u_regional_ics_manager"));
		snowU_RegionalServiceDeliveryMa = SnowUtilities.getStringValueFromObject(jsonValues.get("u_regional_service_delivery_ma"));
		snowU_RegisteredEmail = SnowUtilities.getStringValueFromObject(jsonValues.get("u_registered_email"));
		snowU_ReportingLevel1 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_1"));
		snowU_ReportingLevel2 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_2"));
		snowU_ReportingLevel3 = SnowUtilities.getStringValueFromObject(jsonValues.get("u_reporting_level_3"));
		snowU_RequestResolved = SnowUtilities.getStringValueFromObject(jsonValues.get("u_request_resolved"));
		snowU_SourceId = SnowUtilities.getStringValueFromObject(jsonValues.get("u_source_id"));
		snowU_SspDefaultRole = SnowUtilities.getStringValueFromObject(jsonValues.get("u_ssp_default_role"));
		snowU_SurveyFooter = SnowUtilities.getStringValueFromObject(jsonValues.get("u_survey_footer"));
		snowU_SurveyHeader = SnowUtilities.getStringValueFromObject(jsonValues.get("u_survey_header"));
		snowU_TimeZone = SnowUtilities.getStringValueFromObject(jsonValues.get("u_time_zone"));
		snowU_TntSiteType = SnowUtilities.getStringValueFromObject(jsonValues.get("u_tnt_site_type"));
		snowU_TopLayer = SnowUtilities.getStringValueFromObject(jsonValues.get("u_top_layer"));
		snowVendor = SnowUtilities.getStringValueFromObject(jsonValues.get("vendor"));
		snowVendorManager = SnowUtilities.getStringValueFromObject(jsonValues.get("vendor_manager"));
		snowVendorType = SnowUtilities.getStringValueFromObject(jsonValues.get("vendor_type"));
		snowWebsite = SnowUtilities.getStringValueFromObject(jsonValues.get("website"));
		snowZip = SnowUtilities.getStringValueFromObject(jsonValues.get("zip"));
	}
	
	public JSONObject toJSON() {
		JSONObject jsonObject = new JSONObject();

		if (snowAppleIcon != null && !snowAppleIcon.toString().isEmpty()) jsonObject.put("apple_icon", snowAppleIcon);
		if (snowBannerImage != null && !snowBannerImage.toString().isEmpty()) jsonObject.put("banner_image", snowBannerImage);
		if (snowBannerImageLight != null && !snowBannerImageLight.toString().isEmpty()) jsonObject.put("banner_image_light", snowBannerImageLight);
		if (snowBannerText != null && !snowBannerText.toString().isEmpty()) jsonObject.put("banner_text", snowBannerText);
		if (snowCity != null && !snowCity.toString().isEmpty()) jsonObject.put("city", snowCity);
		if (snowContact != null && !snowContact.toString().isEmpty()) jsonObject.put("contact", snowContact);
		if (snowCustomer != null && !snowCustomer.toString().isEmpty()) jsonObject.put("customer", snowCustomer);
		if (snowDiscount != null && !snowDiscount.toString().isEmpty()) jsonObject.put("discount", snowDiscount);
		if (snowFaxPhone != null && !snowFaxPhone.toString().isEmpty()) jsonObject.put("fax_phone", snowFaxPhone);
		if (snowFiscalYear != null && !snowFiscalYear.toString().isEmpty()) jsonObject.put("fiscal_year", snowFiscalYear);
		if (snowLatLongError != null && !snowLatLongError.toString().isEmpty()) jsonObject.put("lat_long_error", snowLatLongError);
		if (snowLatitude != null && !snowLatitude.toString().isEmpty()) jsonObject.put("latitude", snowLatitude);
		if (snowLatitudeOld != null && !snowLatitudeOld.toString().isEmpty()) jsonObject.put("latitude_old", snowLatitudeOld);
		if (snowLongitude != null && !snowLongitude.toString().isEmpty()) jsonObject.put("longitude", snowLongitude);
		if (snowLongitudeOld != null && !snowLongitudeOld.toString().isEmpty()) jsonObject.put("longitude_old", snowLongitudeOld);
		if (snowManufacturer != null && !snowManufacturer.toString().isEmpty()) jsonObject.put("manufacturer", snowManufacturer);
		if (snowMarketCap != null && !snowMarketCap.toString().isEmpty()) jsonObject.put("market_cap", snowMarketCap);
		if (snowName != null && !snowName.toString().isEmpty()) jsonObject.put("name", snowName);
		if (snowNotes != null && !snowNotes.toString().isEmpty()) jsonObject.put("notes", snowNotes);
		if (snowNumEmployees != null && !snowNumEmployees.toString().isEmpty()) jsonObject.put("num_employees", snowNumEmployees);
		if (snowParent != null && !snowParent.toString().isEmpty()) jsonObject.put("parent", snowParent);
		if (snowPhone != null && !snowPhone.toString().isEmpty()) jsonObject.put("phone", snowPhone);
		if (snowPrimary != null && !snowPrimary.toString().isEmpty()) jsonObject.put("primary", snowPrimary);
		if (snowProfits != null && !snowProfits.toString().isEmpty()) jsonObject.put("profits", snowProfits);
		if (snowPubliclyTraded != null && !snowPubliclyTraded.toString().isEmpty()) jsonObject.put("publicly_traded", snowPubliclyTraded);
		if (snowRankTier != null && !snowRankTier.toString().isEmpty()) jsonObject.put("rank_tier", snowRankTier);
		if (snowRevenuePerYear != null && !snowRevenuePerYear.toString().isEmpty()) jsonObject.put("revenue_per_year", snowRevenuePerYear);
		if (snowSsoSource != null && !snowSsoSource.toString().isEmpty()) jsonObject.put("sso_source", snowSsoSource);
		if (snowState != null && !snowState.toString().isEmpty()) jsonObject.put("state", snowState);
		if (snowStockPrice != null && !snowStockPrice.toString().isEmpty()) jsonObject.put("stock_price", snowStockPrice);
		if (snowStockSymbol != null && !snowStockSymbol.toString().isEmpty()) jsonObject.put("stock_symbol", snowStockSymbol);
		if (snowStreet != null && !snowStreet.toString().isEmpty()) jsonObject.put("street", snowStreet);
		if (snowSysClassName != null && !snowSysClassName.toString().isEmpty()) jsonObject.put("sys_class_name", snowSysClassName);
		if (snowSysCreatedBy != null && !snowSysCreatedBy.toString().isEmpty()) jsonObject.put("sys_created_by", snowSysCreatedBy);
		if (snowSysCreatedOn != null && !snowSysCreatedOn.toString().isEmpty()) jsonObject.put("sys_created_on", snowSysCreatedOn);
		if (snowSysId != null && !snowSysId.toString().isEmpty()) jsonObject.put("sys_id", snowSysId);
		if (snowSysModCount != null && !snowSysModCount.toString().isEmpty()) jsonObject.put("sys_mod_count", snowSysModCount);
		if (snowSysTags != null && !snowSysTags.toString().isEmpty()) jsonObject.put("sys_tags", snowSysTags);
		if (snowSysUpdatedBy != null && !snowSysUpdatedBy.toString().isEmpty()) jsonObject.put("sys_updated_by", snowSysUpdatedBy);
		if (snowSysUpdatedOn != null && !snowSysUpdatedOn.toString().isEmpty()) jsonObject.put("sys_updated_on", snowSysUpdatedOn);
		if (snowU_Active != null && !snowU_Active.toString().isEmpty()) jsonObject.put("u_active", snowU_Active);
		if (snowU_AutocloseClosed != null && !snowU_AutocloseClosed.toString().isEmpty()) jsonObject.put("u_autoclose_closed", snowU_AutocloseClosed);
		if (snowU_AutocloseConfirmation != null && !snowU_AutocloseConfirmation.toString().isEmpty()) jsonObject.put("u_autoclose_confirmation", snowU_AutocloseConfirmation);
		if (snowU_AwaitingConfirmation != null && !snowU_AwaitingConfirmation.toString().isEmpty()) jsonObject.put("u_awaiting_confirmation", snowU_AwaitingConfirmation);
		if (snowU_Blocked != null && !snowU_Blocked.toString().isEmpty()) jsonObject.put("u_blocked", snowU_Blocked);
		if (snowU_BusinessType != null && !snowU_BusinessType.toString().isEmpty()) jsonObject.put("u_business_type", snowU_BusinessType);
		if (snowU_Closed != null && !snowU_Closed.toString().isEmpty()) jsonObject.put("u_closed", snowU_Closed);
		if (snowU_Contact != null && !snowU_Contact.toString().isEmpty()) jsonObject.put("u_contact", snowU_Contact);
		if (snowU_CountryIcsManager != null && !snowU_CountryIcsManager.toString().isEmpty()) jsonObject.put("u_country_ics_manager", snowU_CountryIcsManager);
		if (snowU_Footer != null && !snowU_Footer.toString().isEmpty()) jsonObject.put("u_footer", snowU_Footer);
		if (snowU_FtfWorkgroup != null && !snowU_FtfWorkgroup.toString().isEmpty()) jsonObject.put("u_ftf_workgroup", snowU_FtfWorkgroup);
		if (snowU_KnowledgeApprovalConfirmat != null && !snowU_KnowledgeApprovalConfirmat.toString().isEmpty()) jsonObject.put("u_knowledge_approval_confirmat", snowU_KnowledgeApprovalConfirmat);
		if (snowU_KnowledgeAwaitingApproval != null && !snowU_KnowledgeAwaitingApproval.toString().isEmpty()) jsonObject.put("u_knowledge_awaiting_approval", snowU_KnowledgeAwaitingApproval);
		if (snowU_KnowledgeRepublished != null && !snowU_KnowledgeRepublished.toString().isEmpty()) jsonObject.put("u_knowledge_republished", snowU_KnowledgeRepublished);
		if (snowU_LocalHelpdesk != null && !snowU_LocalHelpdesk.toString().isEmpty()) jsonObject.put("u_local_helpdesk", snowU_LocalHelpdesk);
		if (snowU_LocalIsRep != null && !snowU_LocalIsRep.toString().isEmpty()) jsonObject.put("u_local_is_rep", snowU_LocalIsRep);
		if (snowU_Location != null && !snowU_Location.toString().isEmpty()) jsonObject.put("u_location", snowU_Location);
		if (snowU_Manager != null && !snowU_Manager.toString().isEmpty()) jsonObject.put("u_manager", snowU_Manager);
		if (snowU_NetworkSiteType != null && !snowU_NetworkSiteType.toString().isEmpty()) jsonObject.put("u_network_site_type", snowU_NetworkSiteType);
		if (snowU_Now92Site != null && !snowU_Now92Site.toString().isEmpty()) jsonObject.put("u_now92_site", snowU_Now92Site);
		if (snowU_OrganisationAccountNumber != null && !snowU_OrganisationAccountNumber.toString().isEmpty()) jsonObject.put("u_organisation_account_number", snowU_OrganisationAccountNumber);
		if (snowU_OrganisationCategory != null && !snowU_OrganisationCategory.toString().isEmpty()) jsonObject.put("u_organisation_category", snowU_OrganisationCategory);
		if (snowU_OrganisationControllingDep != null && !snowU_OrganisationControllingDep.toString().isEmpty()) jsonObject.put("u_organisation_controlling_dep", snowU_OrganisationControllingDep);
		if (snowU_OrganisationCostCentre != null && !snowU_OrganisationCostCentre.toString().isEmpty()) jsonObject.put("u_organisation_cost_centre", snowU_OrganisationCostCentre);
		if (snowU_OrganisationEmail != null && !snowU_OrganisationEmail.toString().isEmpty()) jsonObject.put("u_organisation_email", snowU_OrganisationEmail);
		if (snowU_OrganisationLevel != null && !snowU_OrganisationLevel.toString().isEmpty()) jsonObject.put("u_organisation_level", snowU_OrganisationLevel);
		if (snowU_OrganisationLocalIsRepNa != null && !snowU_OrganisationLocalIsRepNa.toString().isEmpty()) jsonObject.put("u_organisation_local_is_rep_na", snowU_OrganisationLocalIsRepNa);
		if (snowU_OrganisationLocalIsRepSe != null && !snowU_OrganisationLocalIsRepSe.toString().isEmpty()) jsonObject.put("u_organisation_local_is_rep_se", snowU_OrganisationLocalIsRepSe);
		if (snowU_OrganisationName2 != null && !snowU_OrganisationName2.toString().isEmpty()) jsonObject.put("u_organisation_name_2", snowU_OrganisationName2);
		if (snowU_OrganisationSearchcode != null && !snowU_OrganisationSearchcode.toString().isEmpty()) jsonObject.put("u_organisation_searchcode", snowU_OrganisationSearchcode);
		if (snowU_OrganisationSourceId != null && !snowU_OrganisationSourceId.toString().isEmpty()) jsonObject.put("u_organisation_source_id", snowU_OrganisationSourceId);
		if (snowU_OrganisationTelephoneShort != null && !snowU_OrganisationTelephoneShort.toString().isEmpty()) jsonObject.put("u_organisation_telephone_short", snowU_OrganisationTelephoneShort);
		if (snowU_RegionalDirector != null && !snowU_RegionalDirector.toString().isEmpty()) jsonObject.put("u_regional_director", snowU_RegionalDirector);
		if (snowU_RegionalIcsManager != null && !snowU_RegionalIcsManager.toString().isEmpty()) jsonObject.put("u_regional_ics_manager", snowU_RegionalIcsManager);
		if (snowU_RegionalServiceDeliveryMa != null && !snowU_RegionalServiceDeliveryMa.toString().isEmpty()) jsonObject.put("u_regional_service_delivery_ma", snowU_RegionalServiceDeliveryMa);
		if (snowU_RegisteredEmail != null && !snowU_RegisteredEmail.toString().isEmpty()) jsonObject.put("u_registered_email", snowU_RegisteredEmail);
		if (snowU_ReportingLevel1 != null && !snowU_ReportingLevel1.toString().isEmpty()) jsonObject.put("u_reporting_level_1", snowU_ReportingLevel1);
		if (snowU_ReportingLevel2 != null && !snowU_ReportingLevel2.toString().isEmpty()) jsonObject.put("u_reporting_level_2", snowU_ReportingLevel2);
		if (snowU_ReportingLevel3 != null && !snowU_ReportingLevel3.toString().isEmpty()) jsonObject.put("u_reporting_level_3", snowU_ReportingLevel3);
		if (snowU_RequestResolved != null && !snowU_RequestResolved.toString().isEmpty()) jsonObject.put("u_request_resolved", snowU_RequestResolved);
		if (snowU_SourceId != null && !snowU_SourceId.toString().isEmpty()) jsonObject.put("u_source_id", snowU_SourceId);
		if (snowU_SspDefaultRole != null && !snowU_SspDefaultRole.toString().isEmpty()) jsonObject.put("u_ssp_default_role", snowU_SspDefaultRole);
		if (snowU_SurveyFooter != null && !snowU_SurveyFooter.toString().isEmpty()) jsonObject.put("u_survey_footer", snowU_SurveyFooter);
		if (snowU_SurveyHeader != null && !snowU_SurveyHeader.toString().isEmpty()) jsonObject.put("u_survey_header", snowU_SurveyHeader);
		if (snowU_TimeZone != null && !snowU_TimeZone.toString().isEmpty()) jsonObject.put("u_time_zone", snowU_TimeZone);
		if (snowU_TntSiteType != null && !snowU_TntSiteType.toString().isEmpty()) jsonObject.put("u_tnt_site_type", snowU_TntSiteType);
		if (snowU_TopLayer != null && !snowU_TopLayer.toString().isEmpty()) jsonObject.put("u_top_layer", snowU_TopLayer);
		if (snowVendor != null && !snowVendor.toString().isEmpty()) jsonObject.put("vendor", snowVendor);
		if (snowVendorManager != null && !snowVendorManager.toString().isEmpty()) jsonObject.put("vendor_manager", snowVendorManager);
		if (snowVendorType != null && !snowVendorType.toString().isEmpty()) jsonObject.put("vendor_type", snowVendorType);
		if (snowWebsite != null && !snowWebsite.toString().isEmpty()) jsonObject.put("website", snowWebsite);
		if (snowZip != null && !snowZip.toString().isEmpty()) jsonObject.put("zip", snowZip);
		
		return jsonObject;
	}

	public String getSnowAppleIcon() {
		return snowAppleIcon;
	}

	public void setSnowAppleIcon(String snowAppleIcon) {
		this.snowAppleIcon = snowAppleIcon;
	}

	public String getSnowBannerImage() {
		return snowBannerImage;
	}

	public void setSnowBannerImage(String snowBannerImage) {
		this.snowBannerImage = snowBannerImage;
	}

	public String getSnowBannerImageLight() {
		return snowBannerImageLight;
	}

	public void setSnowBannerImageLight(String snowBannerImageLight) {
		this.snowBannerImageLight = snowBannerImageLight;
	}

	public String getSnowBannerText() {
		return snowBannerText;
	}

	public void setSnowBannerText(String snowBannerText) {
		this.snowBannerText = snowBannerText;
	}

	public String getSnowCity() {
		return snowCity;
	}

	public void setSnowCity(String snowCity) {
		this.snowCity = snowCity;
	}

	public String getSnowContact() {
		return snowContact;
	}

	public void setSnowContact(String snowContact) {
		this.snowContact = snowContact;
	}

	public String getSnowCustomer() {
		return snowCustomer;
	}

	public void setSnowCustomer(String snowCustomer) {
		this.snowCustomer = snowCustomer;
	}

	public String getSnowDiscount() {
		return snowDiscount;
	}

	public void setSnowDiscount(String snowDiscount) {
		this.snowDiscount = snowDiscount;
	}

	public String getSnowFaxPhone() {
		return snowFaxPhone;
	}

	public void setSnowFaxPhone(String snowFaxPhone) {
		this.snowFaxPhone = snowFaxPhone;
	}

	public String getSnowFiscalYear() {
		return snowFiscalYear;
	}

	public void setSnowFiscalYear(String snowFiscalYear) {
		this.snowFiscalYear = snowFiscalYear;
	}

	public String getSnowLatLongError() {
		return snowLatLongError;
	}

	public void setSnowLatLongError(String snowLatLongError) {
		this.snowLatLongError = snowLatLongError;
	}

	public String getSnowLatitude() {
		return snowLatitude;
	}

	public void setSnowLatitude(String snowLatitude) {
		this.snowLatitude = snowLatitude;
	}

	public String getSnowLatitudeOld() {
		return snowLatitudeOld;
	}

	public void setSnowLatitudeOld(String snowLatitudeOld) {
		this.snowLatitudeOld = snowLatitudeOld;
	}

	public String getSnowLongitude() {
		return snowLongitude;
	}

	public void setSnowLongitude(String snowLongitude) {
		this.snowLongitude = snowLongitude;
	}

	public String getSnowLongitudeOld() {
		return snowLongitudeOld;
	}

	public void setSnowLongitudeOld(String snowLongitudeOld) {
		this.snowLongitudeOld = snowLongitudeOld;
	}

	public String getSnowManufacturer() {
		return snowManufacturer;
	}

	public void setSnowManufacturer(String snowManufacturer) {
		this.snowManufacturer = snowManufacturer;
	}

	public String getSnowMarketCap() {
		return snowMarketCap;
	}

	public void setSnowMarketCap(String snowMarketCap) {
		this.snowMarketCap = snowMarketCap;
	}

	public String getSnowName() {
		return snowName;
	}

	public void setSnowName(String snowName) {
		this.snowName = snowName;
	}

	public String getSnowNotes() {
		return snowNotes;
	}

	public void setSnowNotes(String snowNotes) {
		this.snowNotes = snowNotes;
	}

	public String getSnowNumEmployees() {
		return snowNumEmployees;
	}

	public void setSnowNumEmployees(String snowNumEmployees) {
		this.snowNumEmployees = snowNumEmployees;
	}

	public String getSnowParent() {
		return snowParent;
	}

	public void setSnowParent(String snowParent) {
		this.snowParent = snowParent;
	}

	public String getSnowPhone() {
		return snowPhone;
	}

	public void setSnowPhone(String snowPhone) {
		this.snowPhone = snowPhone;
	}

	public String getSnowPrimary() {
		return snowPrimary;
	}

	public void setSnowPrimary(String snowPrimary) {
		this.snowPrimary = snowPrimary;
	}

	public String getSnowProfits() {
		return snowProfits;
	}

	public void setSnowProfits(String snowProfits) {
		this.snowProfits = snowProfits;
	}

	public String getSnowPubliclyTraded() {
		return snowPubliclyTraded;
	}

	public void setSnowPubliclyTraded(String snowPubliclyTraded) {
		this.snowPubliclyTraded = snowPubliclyTraded;
	}

	public String getSnowRankTier() {
		return snowRankTier;
	}

	public void setSnowRankTier(String snowRankTier) {
		this.snowRankTier = snowRankTier;
	}

	public String getSnowRevenuePerYear() {
		return snowRevenuePerYear;
	}

	public void setSnowRevenuePerYear(String snowRevenuePerYear) {
		this.snowRevenuePerYear = snowRevenuePerYear;
	}

	public String getSnowSsoSource() {
		return snowSsoSource;
	}

	public void setSnowSsoSource(String snowSsoSource) {
		this.snowSsoSource = snowSsoSource;
	}

	public String getSnowState() {
		return snowState;
	}

	public void setSnowState(String snowState) {
		this.snowState = snowState;
	}

	public String getSnowStockPrice() {
		return snowStockPrice;
	}

	public void setSnowStockPrice(String snowStockPrice) {
		this.snowStockPrice = snowStockPrice;
	}

	public String getSnowStockSymbol() {
		return snowStockSymbol;
	}

	public void setSnowStockSymbol(String snowStockSymbol) {
		this.snowStockSymbol = snowStockSymbol;
	}

	public String getSnowStreet() {
		return snowStreet;
	}

	public void setSnowStreet(String snowStreet) {
		this.snowStreet = snowStreet;
	}

	public String getSnowSysClassName() {
		return snowSysClassName;
	}

	public void setSnowSysClassName(String snowSysClassName) {
		this.snowSysClassName = snowSysClassName;
	}

	public String getSnowSysCreatedBy() {
		return snowSysCreatedBy;
	}

	public void setSnowSysCreatedBy(String snowSysCreatedBy) {
		this.snowSysCreatedBy = snowSysCreatedBy;
	}

	public String getSnowSysCreatedOn() {
		return snowSysCreatedOn;
	}

	public void setSnowSysCreatedOn(String snowSysCreatedOn) {
		this.snowSysCreatedOn = snowSysCreatedOn;
	}

	public String getSnowSysId() {
		return snowSysId;
	}

	public void setSnowSysId(String snowSysId) {
		this.snowSysId = snowSysId;
	}

	public String getSnowSysModCount() {
		return snowSysModCount;
	}

	public void setSnowSysModCount(String snowSysModCount) {
		this.snowSysModCount = snowSysModCount;
	}

	public String getSnowSysTags() {
		return snowSysTags;
	}

	public void setSnowSysTags(String snowSysTags) {
		this.snowSysTags = snowSysTags;
	}

	public String getSnowSysUpdatedBy() {
		return snowSysUpdatedBy;
	}

	public void setSnowSysUpdatedBy(String snowSysUpdatedBy) {
		this.snowSysUpdatedBy = snowSysUpdatedBy;
	}

	public String getSnowSysUpdatedOn() {
		return snowSysUpdatedOn;
	}

	public void setSnowSysUpdatedOn(String snowSysUpdatedOn) {
		this.snowSysUpdatedOn = snowSysUpdatedOn;
	}

	public String getSnowU_Active() {
		return snowU_Active;
	}

	public void setSnowU_Active(String snowU_Active) {
		this.snowU_Active = snowU_Active;
	}

	public String getSnowU_AutocloseClosed() {
		return snowU_AutocloseClosed;
	}

	public void setSnowU_AutocloseClosed(String snowU_AutocloseClosed) {
		this.snowU_AutocloseClosed = snowU_AutocloseClosed;
	}

	public String getSnowU_AutocloseConfirmation() {
		return snowU_AutocloseConfirmation;
	}

	public void setSnowU_AutocloseConfirmation(String snowU_AutocloseConfirmation) {
		this.snowU_AutocloseConfirmation = snowU_AutocloseConfirmation;
	}

	public String getSnowU_AwaitingConfirmation() {
		return snowU_AwaitingConfirmation;
	}

	public void setSnowU_AwaitingConfirmation(String snowU_AwaitingConfirmation) {
		this.snowU_AwaitingConfirmation = snowU_AwaitingConfirmation;
	}

	public String getSnowU_Blocked() {
		return snowU_Blocked;
	}

	public void setSnowU_Blocked(String snowU_Blocked) {
		this.snowU_Blocked = snowU_Blocked;
	}

	public String getSnowU_BusinessType() {
		return snowU_BusinessType;
	}

	public void setSnowU_BusinessType(String snowU_BusinessType) {
		this.snowU_BusinessType = snowU_BusinessType;
	}

	public String getSnowU_Closed() {
		return snowU_Closed;
	}

	public void setSnowU_Closed(String snowU_Closed) {
		this.snowU_Closed = snowU_Closed;
	}

	public String getSnowU_Contact() {
		return snowU_Contact;
	}

	public void setSnowU_Contact(String snowU_Contact) {
		this.snowU_Contact = snowU_Contact;
	}

	public String getSnowU_CountryIcsManager() {
		return snowU_CountryIcsManager;
	}

	public void setSnowU_CountryIcsManager(String snowU_CountryIcsManager) {
		this.snowU_CountryIcsManager = snowU_CountryIcsManager;
	}

	public String getSnowU_Footer() {
		return snowU_Footer;
	}

	public void setSnowU_Footer(String snowU_Footer) {
		this.snowU_Footer = snowU_Footer;
	}

	public String getSnowU_FtfWorkgroup() {
		return snowU_FtfWorkgroup;
	}

	public void setSnowU_FtfWorkgroup(String snowU_FtfWorkgroup) {
		this.snowU_FtfWorkgroup = snowU_FtfWorkgroup;
	}

	public String getSnowU_KnowledgeApprovalConfirmat() {
		return snowU_KnowledgeApprovalConfirmat;
	}

	public void setSnowU_KnowledgeApprovalConfirmat(String snowU_KnowledgeApprovalConfirmat) {
		this.snowU_KnowledgeApprovalConfirmat = snowU_KnowledgeApprovalConfirmat;
	}

	public String getSnowU_KnowledgeAwaitingApproval() {
		return snowU_KnowledgeAwaitingApproval;
	}

	public void setSnowU_KnowledgeAwaitingApproval(String snowU_KnowledgeAwaitingApproval) {
		this.snowU_KnowledgeAwaitingApproval = snowU_KnowledgeAwaitingApproval;
	}

	public String getSnowU_KnowledgeRepublished() {
		return snowU_KnowledgeRepublished;
	}

	public void setSnowU_KnowledgeRepublished(String snowU_KnowledgeRepublished) {
		this.snowU_KnowledgeRepublished = snowU_KnowledgeRepublished;
	}

	public String getSnowU_LocalHelpdesk() {
		return snowU_LocalHelpdesk;
	}

	public void setSnowU_LocalHelpdesk(String snowU_LocalHelpdesk) {
		this.snowU_LocalHelpdesk = snowU_LocalHelpdesk;
	}

	public String getSnowU_LocalIsRep() {
		return snowU_LocalIsRep;
	}

	public void setSnowU_LocalIsRep(String snowU_LocalIsRep) {
		this.snowU_LocalIsRep = snowU_LocalIsRep;
	}

	public String getSnowU_Location() {
		return snowU_Location;
	}

	public void setSnowU_Location(String snowU_Location) {
		this.snowU_Location = snowU_Location;
	}

	public String getSnowU_Manager() {
		return snowU_Manager;
	}

	public void setSnowU_Manager(String snowU_Manager) {
		this.snowU_Manager = snowU_Manager;
	}

	public String getSnowU_NetworkSiteType() {
		return snowU_NetworkSiteType;
	}

	public void setSnowU_NetworkSiteType(String snowU_NetworkSiteType) {
		this.snowU_NetworkSiteType = snowU_NetworkSiteType;
	}

	public String getSnowU_Now92Site() {
		return snowU_Now92Site;
	}

	public void setSnowU_Now92Site(String snowU_Now92Site) {
		this.snowU_Now92Site = snowU_Now92Site;
	}

	public String getSnowU_OrganisationAccountNumber() {
		return snowU_OrganisationAccountNumber;
	}

	public void setSnowU_OrganisationAccountNumber(String snowU_OrganisationAccountNumber) {
		this.snowU_OrganisationAccountNumber = snowU_OrganisationAccountNumber;
	}

	public String getSnowU_OrganisationCategory() {
		return snowU_OrganisationCategory;
	}

	public void setSnowU_OrganisationCategory(String snowU_OrganisationCategory) {
		this.snowU_OrganisationCategory = snowU_OrganisationCategory;
	}

	public String getSnowU_OrganisationControllingDep() {
		return snowU_OrganisationControllingDep;
	}

	public void setSnowU_OrganisationControllingDep(String snowU_OrganisationControllingDep) {
		this.snowU_OrganisationControllingDep = snowU_OrganisationControllingDep;
	}

	public String getSnowU_OrganisationCostCentre() {
		return snowU_OrganisationCostCentre;
	}

	public void setSnowU_OrganisationCostCentre(String snowU_OrganisationCostCentre) {
		this.snowU_OrganisationCostCentre = snowU_OrganisationCostCentre;
	}

	public String getSnowU_OrganisationEmail() {
		return snowU_OrganisationEmail;
	}

	public void setSnowU_OrganisationEmail(String snowU_OrganisationEmail) {
		this.snowU_OrganisationEmail = snowU_OrganisationEmail;
	}

	public String getSnowU_OrganisationLevel() {
		return snowU_OrganisationLevel;
	}

	public void setSnowU_OrganisationLevel(String snowU_OrganisationLevel) {
		this.snowU_OrganisationLevel = snowU_OrganisationLevel;
	}

	public String getSnowU_OrganisationLocalIsRepNa() {
		return snowU_OrganisationLocalIsRepNa;
	}

	public void setSnowU_OrganisationLocalIsRepNa(String snowU_OrganisationLocalIsRepNa) {
		this.snowU_OrganisationLocalIsRepNa = snowU_OrganisationLocalIsRepNa;
	}

	public String getSnowU_OrganisationLocalIsRepSe() {
		return snowU_OrganisationLocalIsRepSe;
	}

	public void setSnowU_OrganisationLocalIsRepSe(String snowU_OrganisationLocalIsRepSe) {
		this.snowU_OrganisationLocalIsRepSe = snowU_OrganisationLocalIsRepSe;
	}

	public String getSnowU_OrganisationName2() {
		return snowU_OrganisationName2;
	}

	public void setSnowU_OrganisationName2(String snowU_OrganisationName2) {
		this.snowU_OrganisationName2 = snowU_OrganisationName2;
	}

	public String getSnowU_OrganisationSearchcode() {
		return snowU_OrganisationSearchcode;
	}

	public void setSnowU_OrganisationSearchcode(String snowU_OrganisationSearchcode) {
		this.snowU_OrganisationSearchcode = snowU_OrganisationSearchcode;
	}

	public String getSnowU_OrganisationSourceId() {
		return snowU_OrganisationSourceId;
	}

	public void setSnowU_OrganisationSourceId(String snowU_OrganisationSourceId) {
		this.snowU_OrganisationSourceId = snowU_OrganisationSourceId;
	}

	public String getSnowU_OrganisationTelephoneShort() {
		return snowU_OrganisationTelephoneShort;
	}

	public void setSnowU_OrganisationTelephoneShort(String snowU_OrganisationTelephoneShort) {
		this.snowU_OrganisationTelephoneShort = snowU_OrganisationTelephoneShort;
	}

	public String getSnowU_RegionalDirector() {
		return snowU_RegionalDirector;
	}

	public void setSnowU_RegionalDirector(String snowU_RegionalDirector) {
		this.snowU_RegionalDirector = snowU_RegionalDirector;
	}

	public String getSnowU_RegionalIcsManager() {
		return snowU_RegionalIcsManager;
	}

	public void setSnowU_RegionalIcsManager(String snowU_RegionalIcsManager) {
		this.snowU_RegionalIcsManager = snowU_RegionalIcsManager;
	}

	public String getSnowU_RegionalServiceDeliveryMa() {
		return snowU_RegionalServiceDeliveryMa;
	}

	public void setSnowU_RegionalServiceDeliveryMa(String snowU_RegionalServiceDeliveryMa) {
		this.snowU_RegionalServiceDeliveryMa = snowU_RegionalServiceDeliveryMa;
	}

	public String getSnowU_RegisteredEmail() {
		return snowU_RegisteredEmail;
	}

	public void setSnowU_RegisteredEmail(String snowU_RegisteredEmail) {
		this.snowU_RegisteredEmail = snowU_RegisteredEmail;
	}

	public String getSnowU_ReportingLevel1() {
		return snowU_ReportingLevel1;
	}

	public void setSnowU_ReportingLevel1(String snowU_ReportingLevel1) {
		this.snowU_ReportingLevel1 = snowU_ReportingLevel1;
	}

	public String getSnowU_ReportingLevel2() {
		return snowU_ReportingLevel2;
	}

	public void setSnowU_ReportingLevel2(String snowU_ReportingLevel2) {
		this.snowU_ReportingLevel2 = snowU_ReportingLevel2;
	}

	public String getSnowU_ReportingLevel3() {
		return snowU_ReportingLevel3;
	}

	public void setSnowU_ReportingLevel3(String snowU_ReportingLevel3) {
		this.snowU_ReportingLevel3 = snowU_ReportingLevel3;
	}

	public String getSnowU_RequestResolved() {
		return snowU_RequestResolved;
	}

	public void setSnowU_RequestResolved(String snowU_RequestResolved) {
		this.snowU_RequestResolved = snowU_RequestResolved;
	}

	public String getSnowU_SourceId() {
		return snowU_SourceId;
	}

	public void setSnowU_SourceId(String snowU_SourceId) {
		this.snowU_SourceId = snowU_SourceId;
	}

	public String getSnowU_SspDefaultRole() {
		return snowU_SspDefaultRole;
	}

	public void setSnowU_SspDefaultRole(String snowU_SspDefaultRole) {
		this.snowU_SspDefaultRole = snowU_SspDefaultRole;
	}

	public String getSnowU_SurveyFooter() {
		return snowU_SurveyFooter;
	}

	public void setSnowU_SurveyFooter(String snowU_SurveyFooter) {
		this.snowU_SurveyFooter = snowU_SurveyFooter;
	}

	public String getSnowU_SurveyHeader() {
		return snowU_SurveyHeader;
	}

	public void setSnowU_SurveyHeader(String snowU_SurveyHeader) {
		this.snowU_SurveyHeader = snowU_SurveyHeader;
	}

	public String getSnowU_TimeZone() {
		return snowU_TimeZone;
	}

	public void setSnowU_TimeZone(String snowU_TimeZone) {
		this.snowU_TimeZone = snowU_TimeZone;
	}

	public String getSnowU_TntSiteType() {
		return snowU_TntSiteType;
	}

	public void setSnowU_TntSiteType(String snowU_TntSiteType) {
		this.snowU_TntSiteType = snowU_TntSiteType;
	}

	public String getSnowU_TopLayer() {
		return snowU_TopLayer;
	}

	public void setSnowU_TopLayer(String snowU_TopLayer) {
		this.snowU_TopLayer = snowU_TopLayer;
	}

	public String getSnowVendor() {
		return snowVendor;
	}

	public void setSnowVendor(String snowVendor) {
		this.snowVendor = snowVendor;
	}

	public String getSnowVendorManager() {
		return snowVendorManager;
	}

	public void setSnowVendorManager(String snowVendorManager) {
		this.snowVendorManager = snowVendorManager;
	}

	public String getSnowVendorType() {
		return snowVendorType;
	}

	public void setSnowVendorType(String snowVendorType) {
		this.snowVendorType = snowVendorType;
	}

	public String getSnowWebsite() {
		return snowWebsite;
	}

	public void setSnowWebsite(String snowWebsite) {
		this.snowWebsite = snowWebsite;
	}

	public String getSnowZip() {
		return snowZip;
	}

	public void setSnowZip(String snowZip) {
		this.snowZip = snowZip;
	}
	
}
