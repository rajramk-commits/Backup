package com.fedex.emea.sd.da.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import com.fedex.emea.sd.da.objects.NetworkEquipments;

public final class NetworkEquipmentSecondRowMapper implements RowMapper {
	
	public Object mapRow(ResultSet rs, int rowNum) throws SQLException {		
		NetworkEquipments networkEquipment = new NetworkEquipments();
		
		networkEquipment.setServerName(rs.getString("ServerName"));
		networkEquipment.setServerOs(rs.getString("OperatingSystem"));
		networkEquipment.setServerOsVersion(rs.getString("OperatingSystemVersion"));
		networkEquipment.setServerStatus(rs.getString("ServerStatus"));
		networkEquipment.setServerOsRevision(rs.getString("OperatingSystemRevision"));
		networkEquipment.setApplicationHosted(rs.getString("AppHosted"));
		networkEquipment.setServerFunction(rs.getString("ServerFunction"));
		
		return networkEquipment;	
	}
}
