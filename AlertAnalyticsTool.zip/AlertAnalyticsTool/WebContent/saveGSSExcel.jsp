<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    <%@page import="javax.mail.*"%>
    <%@page import="java.util.*"%> 
    <%@page import="com.fedex.emea.sabreReport.model.*"%>
  <jsp:useBean id="ReportService" class="com.fedex.emea.sabreReport.service.ReportService" scope="page"/>
  <jsp:useBean id="ProcessGSSData" class="com.fedex.emea.sabreReport.util.ProcessGSSData" scope="page"/>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta charset="ISO-8859-1">
<title>Alert Analytics Tool</title>
</head>
<body>
<%
String dateStr = "";
@SuppressWarnings("unchecked")
	List<SabreBean> data = (List<SabreBean>) request.getSession().getAttribute("gssList");
String SDate = (String)request.getSession().getAttribute("SDate");
String EDate = (String)request.getSession().getAttribute("EDate");
System.out.println("SDate:"+SDate+", EDate :"+EDate);

if(SDate.length()>15 && EDate.length()>15)
{
	SDate = SDate.substring(0, 15);
	EDate = EDate.substring(0, 15);
}
dateStr = SDate+"_"+EDate;

if(data != null && data.size() != 0)
{
	request.getSession().setAttribute("gssList",data);
	try
	{
	String path = ProcessGSSData.saveData(data, dateStr);
	//String path ="/opt/automationtools/Deployments/AAT_Reports/GSS/"+"GSSReport_"+dateStr+".xlsx";
	String res  = "";
	if(path != null)
	{
		String newPath = path.replace("\\", "/");
		res  = "Successfully created report under path :"+newPath;
		
	}
	/* else
	{
		res  = "Unable to store the data";
	} */
	System.out.println("Result :"+res);
	response.sendRedirect("reportType.jsp?status="+res);
	}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
	}
}
else
	response.sendRedirect("reportType.jsp?status=No Data found to store");
%>
</body>
</html>