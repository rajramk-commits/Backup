package com.fedex.emea.onlinequiz.test;

import java.io.IOException;

public class Test {

	public static void main(String[] args) throws IOException {
		
		/*StringBuilder emailattachment = new StringBuilder();
		emailattachment.append("vimal");
		emailattachment.append("\r\n \r\n");
		
		 String strPath = "WebContent/image/example.txt";
		 File strFile = new File(strPath);
		 
		 boolean fileCreated = strFile.createNewFile();
		 //File appending
		 Writer objWriter = new BufferedWriter(new FileWriter(strFile));
		 objWriter.write(emailattachment.toString());
		 objWriter.flush();
		 objWriter.close();*/
		
		
		
	}

	

}
